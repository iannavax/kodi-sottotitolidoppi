// Sottotitoli Doppi per Stremio - add-on di sottotitoli (Node.js 18+, nessuna dipendenza)
// Avvio: node server.js   →   poi apri http://127.0.0.1:7000/configure
"use strict";
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const T = require("./translate");

const VERSION = "1.3.0";
const PORT = Number(process.env.PORT) || 7000;
const HOST = process.env.HOST || "127.0.0.1";
const PUBLIC_URL = (process.env.PUBLIC_URL || "").replace(/\/+$/, "");
const OPENSUBS = (process.env.SD_OPENSUBS_URL || "https://opensubtitles-v3.strem.io").replace(/\/+$/, "");
const CINEMETA = (process.env.SD_CINEMETA_URL || "https://v3-cinemeta.strem.io").replace(/\/+$/, "");
// Stremio aspetta il file solo pochi secondi: se non arriva, il sottotitolo non si seleziona.
// Quindi aspetto al massimo WAIT_MS la traduzione "bella", poi completo con Google e rispondo comunque entro FILL_MS.
const WAIT_MS = Number(process.env.SD_WAIT_MS) || 3000;
const FILL_MS = Number(process.env.SD_FILL_MS) || 6000;
const CACHE = path.join(__dirname, "cache");
fs.mkdirSync(CACHE, { recursive: true });

// Lingue: codice a 2 lettere (traduzione) ↔ codici di OpenSubtitles
const LANGS = {
  en: ["eng", "en"], it: ["ita", "it"], es: ["spa", "es", "spn", "ea"], fr: ["fre", "fra", "fr"], de: ["ger", "deu", "de"],
  pt: ["por", "pob", "pt", "pb", "pt-br"], nl: ["dut", "nld", "nl"], pl: ["pol", "pl"], ro: ["rum", "ron", "ro"], ru: ["rus", "ru"],
  uk: ["ukr", "uk"], tr: ["tur", "tr"], ar: ["ara", "ar"], ja: ["jpn", "ja"], ko: ["kor", "ko"], zh: ["chi", "zho", "zh", "zht", "zhs"],
  el: ["gre", "ell", "el"], hu: ["hun", "hu"], cs: ["cze", "ces", "cs"], sv: ["swe", "sv"], da: ["dan", "da"], no: ["nor", "nob", "nno", "no", "nb", "nn"],
  fi: ["fin", "fi"], he: ["heb", "he"], hi: ["hin", "hi"], id: ["ind", "id"], th: ["tha", "th"], vi: ["vie", "vi"], bg: ["bul", "bg"],
  hr: ["hrv", "scc", "hr"], sr: ["srp", "sr"], sl: ["slv", "sl"], sk: ["slo", "slk", "sk"], fa: ["per", "fas", "fa"], ms: ["may", "msa", "ms"],
  ca: ["cat", "ca"], et: ["est", "et"], lv: ["lav", "lv"], lt: ["lit", "lt"], is: ["ice", "isl", "is"],
};
const NAMES = { en: "Inglese", it: "Italiano", es: "Spagnolo", fr: "Francese", de: "Tedesco", pt: "Portoghese", nl: "Olandese",
  pl: "Polacco", ro: "Rumeno", ru: "Russo", uk: "Ucraino", tr: "Turco", ar: "Arabo", ja: "Giapponese", ko: "Coreano", zh: "Cinese",
  el: "Greco", hu: "Ungherese", cs: "Ceco", sv: "Svedese", da: "Danese", no: "Norvegese", fi: "Finlandese", he: "Ebraico",
  hi: "Hindi", id: "Indonesiano", th: "Thailandese", vi: "Vietnamita", bg: "Bulgaro", hr: "Croato", sr: "Serbo", sl: "Sloveno",
  sk: "Slovacco", fa: "Persiano", ms: "Malese", ca: "Catalano", et: "Estone", lv: "Lettone", lt: "Lituano", is: "Islandese" };
const TARGETS = ["it", "en", "es", "fr", "de", "pt", "nl", "pl", "ro", "ru", "uk", "tr", "ar", "ja", "ko", "zh"];
const code2 = (c) => Object.keys(LANGS).find((k) => LANGS[k].includes(String(c || "").toLowerCase())) || "";

// ---------------------------------------------------------------- lingua in cui è parlato il film
// Stremio (Cinemeta) dice il paese del film e a volte la lingua: da lì capisco la lingua originale,
// così la versione doppia giusta compare per prima e viene preparata subito.
const LANG_NAMES = { english: "en", italian: "it", spanish: "es", castilian: "es", french: "fr", german: "de", portuguese: "pt",
  dutch: "nl", flemish: "nl", polish: "pl", romanian: "ro", russian: "ru", ukrainian: "uk", turkish: "tr", arabic: "ar",
  japanese: "ja", korean: "ko", chinese: "zh", mandarin: "zh", cantonese: "zh", greek: "el", hungarian: "hu", czech: "cs",
  swedish: "sv", danish: "da", norwegian: "no", "norwegian bokmål": "no", "norwegian nynorsk": "no", finnish: "fi", hebrew: "he",
  hindi: "hi", indonesian: "id", thai: "th", vietnamese: "vi", bulgarian: "bg", croatian: "hr", serbian: "sr", slovenian: "sl",
  slovak: "sk", persian: "fa", farsi: "fa", malay: "ms", catalan: "ca", estonian: "et", latvian: "lv", lithuanian: "lt", icelandic: "is" };
const COUNTRY_LANG = {
  "united states": "en", usa: "en", "united kingdom": "en", uk: "en", ireland: "en", canada: "en", australia: "en", "new zealand": "en",
  italy: "it", spain: "es", mexico: "es", argentina: "es", colombia: "es", chile: "es", peru: "es", venezuela: "es", cuba: "es", uruguay: "es",
  france: "fr", germany: "de", "west germany": "de", "east germany": "de", austria: "de", portugal: "pt", brazil: "pt",
  netherlands: "nl", poland: "pl", romania: "ro", russia: "ru", "soviet union": "ru", ukraine: "uk", turkey: "tr", "türkiye": "tr",
  egypt: "ar", "saudi arabia": "ar", lebanon: "ar", syria: "ar", morocco: "ar", tunisia: "ar", algeria: "ar", jordan: "ar",
  japan: "ja", "south korea": "ko", korea: "ko", china: "zh", taiwan: "zh", "hong kong": "zh", greece: "el", hungary: "hu",
  "czech republic": "cs", czechia: "cs", czechoslovakia: "cs", sweden: "sv", denmark: "da", norway: "no", finland: "fi", iceland: "is",
  israel: "he", indonesia: "id", thailand: "th", vietnam: "vi", bulgaria: "bg", croatia: "hr", serbia: "sr", yugoslavia: "sr",
  slovenia: "sl", slovakia: "sk", iran: "fa", estonia: "et", latvia: "lv", lithuania: "lt", malaysia: "ms" };
const filmLangCache = new Map();

function firstKnown(value, table) {
  const items = (Array.isArray(value) ? value : String(value || "").split(/[,/|]/)).map((x) => String(x).trim().toLowerCase()).filter(Boolean);
  for (const x of items) if (table[x]) return table[x];
  return "";
}

async function filmLanguage(type, id) {
  const imdb = String(id).split(":")[0];
  if (!/^tt\d+$/.test(imdb)) return "";
  if (filmLangCache.has(imdb)) return filmLangCache.get(imdb);
  let lang = "";
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 4000);
    const r = await fetch(`${CINEMETA}/meta/${type === "series" ? "series" : "movie"}/${imdb}.json`, { signal: ctl.signal });
    clearTimeout(timer);
    if (r.ok) {
      const meta = (await r.json()).meta || {};
      // prima la lingua dichiarata (se c'è), poi il primo paese di produzione
      lang = firstKnown(meta.language || meta.languages || meta.spoken_languages, LANG_NAMES) || firstKnown(meta.country, COUNTRY_LANG);
    }
  } catch (e) {
    console.log("Non riesco a sapere la lingua del film:", e.message);
  }
  if (filmLangCache.size > 2000) filmLangCache.clear();
  filmLangCache.set(imdb, lang);
  return lang;
}

// source "all": una versione doppia per ogni lingua disponibile (scegli tu nel lettore quella del film)
const DEFAULT_CFG = { target: "it", source: "all", perLang: 1, engine: "google", key: "", model: "", url: "", color: "FFFF00", layout: "orig_top", plain: false, prepare: "file" };

function decodeCfg(s) {
  try { return { ...DEFAULT_CFG, ...JSON.parse(Buffer.from(String(s), "base64url").toString("utf8")) }; } catch { return null; }
}
const encodeCfg = (c) => Buffer.from(JSON.stringify(c)).toString("base64url");

function manifest(cfg) {
  const t = cfg ? NAMES[cfg.target] || cfg.target : "la tua lingua";
  return {
    id: "community.sottotitolidoppi",
    version: VERSION,
    name: "Sottotitoli Doppi",
    description: cfg
      ? `Sottotitoli ${cfg.source === "all" ? "in qualsiasi lingua originale" : "in " + (NAMES[cfg.source] || cfg.source)} con la traduzione in ${t} sotto ogni riga.`
      : "Sottotitoli originali con la traduzione sotto ogni riga. Configura la lingua e il servizio di traduzione.",
    logo: (PUBLIC_URL || `http://${HOST}:${PORT}`) + "/logo.png",
    resources: ["subtitles"],
    types: ["movie", "series"],
    idPrefixes: ["tt"],
    catalogs: [],
    behaviorHints: { configurable: true, configurationRequired: !cfg },
  };
}

// ---------------------------------------------------------------- lavori di traduzione (con salvataggio)
const jobs = new Map();
const jobKey = (src, cfg) => crypto.createHash("sha1").update([src, cfg.target, cfg.engine, cfg.model].join("|")).digest("hex").slice(0, 20);
const sourceOf = (cfg, sl) => (sl !== undefined ? sl : cfg.source === "all" ? "" : cfg.source);

async function fetchText(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("il servizio dei sottotitoli ha risposto " + r.status);
  const buf = Buffer.from(await r.arrayBuffer());
  let text = buf.toString("utf8");
  if ((text.match(/\uFFFD/g) || []).length > 5) text = buf.toString("latin1");   // vecchi file non UTF-8
  return text;
}

// File originali già scaricati (gratis) all'apertura del film, senza tradurli: la traduzione parte solo quando scegli i doppi
const prefetched = new Map();
function prefetch(src) {
  if (prefetched.has(src)) return;
  const p = fetchText(src).catch(() => null);
  prefetched.set(src, p);
  p.then((t) => { if (!t) prefetched.delete(src); });
  setTimeout(() => prefetched.delete(src), 30 * 60 * 1000);
  while (prefetched.size > 50) prefetched.delete(prefetched.keys().next().value);
}

function getJob(src, cfg, sl) {
  const key = jobKey(src, cfg);
  if (jobs.has(key)) return jobs.get(key);
  const file = path.join(CACHE, key + ".json");
  const job = { key, cues: null, trans: [], final: [], complete: false, done: 0, error: "", started: Date.now() };
  jobs.set(key, job);
  job.promise = (async () => {
    if (fs.existsSync(file)) {
      const saved = JSON.parse(fs.readFileSync(file, "utf8"));
      Object.assign(job, { cues: saved.cues, trans: saved.trans, final: saved.trans.map(() => true), complete: true, done: saved.trans.length, engineUsed: saved.engine });
      return;
    }
    job.cues = T.parseSubs(await (prefetched.get(src) || fetchText(src)));
    if (!job.cues.length) throw new Error("nel file dei sottotitoli non ci sono frasi");
    job.trans = new Array(job.cues.length).fill("");
    job.final = new Array(job.cues.length).fill(false);
    await T.translateAll(job, job.cues, { ...cfg, sourceLang: sourceOf(cfg, sl) });
    if (job.complete) fs.writeFileSync(file, JSON.stringify({ cues: job.cues, trans: job.trans, engine: job.engineUsed }));
  })().catch((e) => { job.error = String(e.message || e); jobs.delete(key); });
  return job;
}

// ---------------------------------------------------------------- risposte
function send(res, status, body, type = "application/json; charset=utf-8", extra = {}) {
  const data = typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(status, { "Content-Type": type, "Content-Length": Buffer.byteLength(data), "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "*", "Cache-Control": "no-cache", ...extra });
  res.end(data);
}

function baseUrl(req) {
  if (PUBLIC_URL) return PUBLIC_URL;
  const proto = req.headers["x-forwarded-proto"] || "http";
  return `${proto}://${req.headers.host || HOST + ":" + PORT}`;
}

async function subtitles(req, res, cfg, cfgStr, type, id, extra) {
  // sottotitoli nella lingua originale dal servizio OpenSubtitles di Stremio
  // l'identificativo resta com'è (le puntate sono "tt0903747:1:2"); i dati extra restano codificati come li manda Stremio
  const url = `${OPENSUBS}/subtitles/${type}/${id}${extra ? "/" + extra : ""}.json`;
  let list = [];
  const [, filmLang] = await Promise.all([
    (async () => {
      try {
        const r = await fetch(url);
        if (r.ok) list = (await r.json()).subtitles || [];
      } catch (e) {
        console.log("OpenSubtitles non risponde:", e.message);
      }
    })(),
    cfg.source === "all" || !cfg.source ? filmLanguage(type, id) : Promise.resolve(""),
  ]);
  // raggruppo per lingua, tolgo quella in cui traduci
  const targetCodes = LANGS[cfg.target] || [cfg.target];
  const groups = new Map();
  for (const s of list) {
    const l = String(s.lang || "").toLowerCase();
    if (!l || !s.url || targetCodes.includes(l)) continue;
    if (!groups.has(l)) groups.set(l, []);
    groups.get(l).push(s);
  }
  let langs = [...groups.keys()];
  if (cfg.source && cfg.source !== "all") {
    const wanted = LANGS[cfg.source] || [cfg.source];
    langs = langs.filter((l) => wanted.includes(l));
  }
  // prima la lingua in cui è parlato il film, poi le lingue con più sottotitoli.
  // Nessun limite al numero di lingue: prima ne tenevo 12 e nei film con molti sottotitoli
  // la lingua originale (norvegese, ceco…) finiva esclusa.
  const isFilm = (l) => !!filmLang && code2(l) === filmLang;
  langs.sort((a, b) => isFilm(b) - isFilm(a) || groups.get(b).length - groups.get(a).length);
  const per = Math.max(1, Math.min(3, Number(cfg.perLang) || 1));
  const base = baseUrl(req);
  const tName = NAMES[cfg.target] || cfg.target.toUpperCase();
  const subs = [];
  for (const l of langs) {
    const two = code2(l);
    const name = (NAMES[two] || l.toUpperCase()) + (isFilm(l) ? " (lingua del film)" : "");
    groups.get(l).slice(0, per).forEach((s, i) => {
      const k = jobKey(s.url, cfg);
      subs.push({
        id: "sd-" + k,
        // tutto nel percorso, che finisce con ".srt": alcuni lettori di Stremio riconoscono il formato
        // solo dalla fine dell'indirizzo (prima finiva con "&sl=…" e il sottotitolo non si selezionava)
        url: `${base}/${cfgStr}/dual/${two || "-"}/${Buffer.from(s.url).toString("base64url")}.srt`,
        lang: `Doppi: ${name} → ${tName}${per > 1 ? " " + (i + 1) : ""}`,
      });
    });
  }
  // Stremio chiede l'elenco a ogni film che apri, anche se poi non scegli i doppi. Di serie scarico soltanto il file
  // originale più probabile (gratis), così quando lo scegli la traduzione parte subito; con "prepare: full" lo traduco
  // già tutto in anticipo (più veloce la prima volta, ma consuma la quota del servizio anche per i film in cui non li usi).
  const already = langs[0] && fs.existsSync(path.join(CACHE, jobKey(groups.get(langs[0])[0].url, cfg) + ".json"));
  if (langs[0] && (cfg.prepare === "full" || already)) getJob(groups.get(langs[0])[0].url, cfg, code2(langs[0]));
  else if (langs[0]) prefetch(groups.get(langs[0])[0].url);
  console.log(`elenco: ${langs.length} lingue` + (filmLang ? `, lingua del film: ${NAMES[filmLang] || filmLang}` +
    (langs.some(isFilm) ? "" : " (ma OpenSubtitles non ha sottotitoli in questa lingua)") : ", lingua del film non riconosciuta"));
  send(res, 200, { subtitles: subs, cacheMaxAge: 3600 });
}

async function dual(req, res, cfg, src, sl) {
  if (!/^https?:\/\//.test(src)) return send(res, 400, "indirizzo dei sottotitoli non valido", "text/plain; charset=utf-8");
  const SRT = "application/x-subrip; charset=utf-8";
  // alcuni lettori controllano prima il file con una richiesta HEAD: rispondo subito
  if (req.method === "HEAD") { getJob(src, cfg, sl); return send(res, 200, "", SRT); }
  const t0 = Date.now();
  const job = getJob(src, cfg, sl);
  const deadline = t0 + WAIT_MS;
  while (!job.complete && !job.error && Date.now() < deadline) await new Promise((r) => setTimeout(r, 200));
  // il file originale non è ancora stato scaricato: lo aspetto ancora un po'
  const dl = t0 + WAIT_MS + FILL_MS;
  while (!job.cues && !job.error && Date.now() < dl) await new Promise((r) => setTimeout(r, 200));
  if (!job.cues) {
    console.log("file doppio non pronto:", job.error || "il file originale non arriva");
    return send(res, 502, "Sottotitoli Doppi: " + (job.error || "il file dei sottotitoli non arriva"), "text/plain; charset=utf-8");
  }
  if (!job.complete) await Promise.race([T.fillMissing(job, job.cues, { ...cfg, sourceLang: sourceOf(cfg, sl) }), new Promise((r) => setTimeout(r, Math.max(1500, dl - Date.now())))]);
  const missing = job.trans.filter((t) => !t).length;
  console.log(`file doppio inviato a Stremio in ${((Date.now() - t0) / 1000).toFixed(1)} s: ${job.cues.length} frasi, tradotte con ${job.engineUsed || "?"}` +
    `${job.complete ? "" : ` (${job.done} con il servizio scelto, il resto con Google per ora)`}${missing ? `, ${missing} ancora senza traduzione` : ""}`);
  send(res, 200, T.dualSrt(job.cues, job.trans, cfg), SRT);
}

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, "http://x");
    const parts = u.pathname.split("/").filter(Boolean).map(decodeURIComponent);
    if (parts[1] === "dual" || parts[1] === "subtitles") console.log(`${new Date().toLocaleTimeString("it-IT")} Stremio chiede: ${parts[1] === "dual" ? "file doppio" : "elenco sottotitoli"} (${req.method})`);
    if (req.method === "OPTIONS") return send(res, 204, "");
    if (!parts.length) return send(res, 302, "", "text/plain", { Location: "/configure" });
    if (parts[0] === "logo.png") return send(res, 200, fs.readFileSync(path.join(__dirname, "logo.png")), "image/png");
    if (parts[0] === "configure" || parts[1] === "configure") {
      const cfg = parts[1] === "configure" ? decodeCfg(parts[0]) : null;
      return send(res, 200, configurePage(cfg || DEFAULT_CFG), "text/html; charset=utf-8");
    }
    if (parts[0] === "manifest.json") return send(res, 200, manifest(null));
    const cfg = decodeCfg(parts[0]);
    if (!cfg) return send(res, 404, { error: "configurazione non valida" });
    if (parts[1] === "manifest.json") return send(res, 200, manifest(cfg));
    if (parts[1] === "subtitles" && parts.length >= 4) {
      const raw = u.pathname.split("/").filter(Boolean);
      const type = parts[2];
      const id = parts[3].replace(/\.json$/, "");
      const extra = raw[4] ? raw[4].replace(/\.json$/, "") : "";
      return subtitles(req, res, cfg, parts[0], type, id, extra);
    }
    if (parts[1] === "dual" && parts.length >= 4) {
      // nuovo formato: /dual/<lingua>/<indirizzo in base64url>.srt
      let src = "";
      try { src = Buffer.from(parts[3].replace(/\.srt$/, ""), "base64url").toString("utf8"); } catch {}
      return dual(req, res, cfg, src, parts[2] === "-" ? "" : parts[2]);
    }
    // formato della versione 1.1 (indirizzi già salvati da Stremio)
    if (parts[1] === "dual") return dual(req, res, cfg, u.searchParams.get("src") || "", u.searchParams.has("sl") ? u.searchParams.get("sl") : undefined);
    send(res, 404, { error: "non trovato" });
  } catch (e) {
    console.log("errore:", e);
    send(res, 500, { error: String(e.message || e) });
  }
});

// ---------------------------------------------------------------- pagina di configurazione
function configurePage(c) {
  const opt = (list, val) => list.map(([v, l]) => `<option value="${v}"${v === val ? " selected" : ""}>${l}</option>`).join("");
  const langs = TARGETS.map((k) => [k, NAMES[k]]);
  const sources = [["all", "Tutte quelle disponibili (scegli tu nel lettore quella del film)"], ...Object.entries(NAMES).sort((a, b) => a[1].localeCompare(b[1]))];
  const engines = [["google", "Google Traduttore (gratis, senza chiave)"], ["gemini", "Gemini (gratis con chiave, consigliato)"], ["groq", "Groq (gratis con chiave)"],
    ["openrouter", "OpenRouter, modelli :free (con chiave)"], ["deepl", "DeepL (piano gratuito con chiave)"], ["claude", "Claude (a pagamento)"], ["local", "Modello sul computer (Ollama / LM Studio)"]];
  return `<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sottotitoli Doppi per Stremio</title><link rel="icon" href="/logo.png">
<style>
:root{--ink:#1d2430;--panel:#262f3d;--paper:#eef1f5;--soft:#c8cfda;--muted:#8a94a6;--gold:#f5c84b;--line:#3a4557}
*{box-sizing:border-box}body{margin:0;background:var(--ink);color:var(--paper);font:15px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:620px;margin:0 auto;padding:28px 20px 60px}h1{margin:0 0 4px;font-size:26px;display:flex;gap:12px;align-items:center}h1 img{width:40px;height:40px}
p{color:var(--soft)}label{display:grid;gap:4px;margin:12px 0}select,input{background:var(--panel);color:var(--paper);border:1px solid var(--line);border-radius:8px;padding:8px 10px;font:inherit;width:100%}
input[type=checkbox]{width:auto}.row{display:flex;gap:10px;align-items:center}.card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin-top:18px}
a.btn,button{display:inline-block;background:var(--gold);color:var(--ink);border:0;border-radius:8px;padding:10px 16px;font:inherit;font-weight:700;cursor:pointer;text-decoration:none}
button.ghost{background:transparent;color:var(--soft);border:1px solid var(--line);font-weight:500}code{word-break:break-all;color:var(--soft);font-size:13px}.small{color:var(--muted);font-size:13px}
:focus-visible{outline:2px solid var(--gold);outline-offset:2px}
</style></head><body><main>
<h1><img src="/logo.png" alt="">Sottotitoli Doppi</h1>
<p>Sottotitoli nella lingua originale con la traduzione sotto ogni riga, per film e serie in Stremio.</p>
<label>Traduci in<select id="target">${opt(langs, c.target)}</select></label>
<label>Lingue originali da proporre<select id="source">${opt(sources, c.source)}</select></label>
<p class="small" style="margin-top:-6px">Con "Tutte", per ogni film trovi nell'elenco dei sottotitoli una versione doppia per ogni lingua disponibile (per esempio "Doppi: Francese → Italiano"): scegli quella della lingua in cui è parlato il film. L'add-on la riconosce da solo (dal paese del film) e la mette per prima con la scritta "(lingua del film)".</p>
<label>Versioni per ogni lingua<select id="perLang">${opt([["1", "1 (consigliato)"], ["2", "2"], ["3", "3 (utile se i sottotitoli sono spesso fuori sincrono)"]], String(c.perLang || 1))}</select></label>
<label>Quando tradurre<select id="prepare">${opt([["file", "Quando scegli i doppi nel lettore (consigliato: nessuna quota sprecata)"], ["full", "In anticipo, appena apri un film (più veloce la prima volta, ma consuma quota anche se non li usi)"]], c.prepare || "file")}</select></label>
<p class="small" style="margin-top:-6px">Stremio chiede i sottotitoli a ogni film che apri. Con la prima scelta l'add-on traduce solo quando scegli una versione "Doppi": i primi secondi arrivano tradotti con Google e il resto con il servizio scelto; riscegliendo la traccia (o rivedendo il film) è tutto con il servizio scelto, già salvato.</p>
<label>Servizio di traduzione<select id="engine">${opt(engines, c.engine)}</select></label>
<label id="keyRow">Chiave del servizio<input id="key" type="password" value="${(c.key || "").replace(/"/g, "&quot;")}" autocomplete="off" placeholder="Incolla qui la chiave"></label>
<label id="modelRow">Modello (vuoto = quello consigliato)<input id="model" value="${(c.model || "").replace(/"/g, "&quot;")}" placeholder="es. gemini-flash-lite-latest"></label>
<label id="urlRow">Indirizzo del modello sul computer<input id="url" value="${(c.url || "").replace(/"/g, "&quot;")}" placeholder="http://localhost:11434/v1"></label>
<label>Disposizione<select id="layout">${opt([["orig_top", "Originale sopra, traduzione sotto"], ["trans_top", "Traduzione sopra, originale sotto"], ["trans_only", "Solo la traduzione"]], c.layout)}</select></label>
<label>Colore della traduzione<input id="color" type="color" value="#${String(c.color || "FFFF00").replace(/[^0-9a-f]/gi, "").slice(0, 6) || "FFFF00"}" style="height:42px"></label>
<label class="row"><input id="plain" type="checkbox"${c.plain ? " checked" : ""}> Traduzione senza colore (se il tuo lettore mostra dei codici strani)</label>
<div class="card">
  <a class="btn" id="install" href="#">Installa in Stremio</a>
  <button class="ghost" id="copy" type="button">Copia l'indirizzo</button>
  <p class="small">Indirizzo dell'add-on (in Stremio: Add-on → incolla nella barra di ricerca in alto):</p>
  <code id="addr"></code>
  <p class="small">La chiave resta dentro questo indirizzo: non condividerlo.</p>
</div>
</main><script>
const $=(i)=>document.getElementById(i);
function cfg(){return{source:$("source").value,perLang:Number($("perLang").value),target:$("target").value,engine:$("engine").value,key:$("key").value.trim(),model:$("model").value.trim(),url:$("url").value.trim(),layout:$("layout").value,color:$("color").value.slice(1),plain:$("plain").checked,prepare:$("prepare").value}}
function b64(s){return btoa(unescape(encodeURIComponent(s))).replace(/\\+/g,"-").replace(/\\//g,"_").replace(/=+$/,"")}
function update(){const e=$("engine").value;$("keyRow").style.display=e==="google"||e==="local"?"none":"";$("urlRow").style.display=e==="local"?"":"none";$("modelRow").style.display=e==="google"||e==="deepl"?"none":"";
const a=location.origin+"/"+b64(JSON.stringify(cfg()))+"/manifest.json";$("addr").textContent=a;$("install").href=a.replace(/^https?:/,"stremio:")}
document.querySelectorAll("select,input").forEach(x=>x.addEventListener("input",update));
$("copy").addEventListener("click",async()=>{try{await navigator.clipboard.writeText($("addr").textContent);$("copy").textContent="Copiato ✓"}catch{}});
update();
</script></body></html>`;
}

server.on("error", (e) => {
  if (e.code === "EADDRINUSE") {
    console.log(`La porta ${PORT} è già in uso: probabilmente Sottotitoli Doppi è già avviato (lascia aperta quella finestra), ` +
      `oppure avvialo su un'altra porta, per esempio: PORT=7001 node server.js`);
  } else console.log("Errore del server:", e.message);
  process.exit(1);
});

server.listen(PORT, HOST, () => {
  console.log(`Sottotitoli Doppi per Stremio ${VERSION}`);
  console.log(`Configura e installa: http://${HOST === "0.0.0.0" ? "127.0.0.1" : HOST}:${PORT}/configure`);
});

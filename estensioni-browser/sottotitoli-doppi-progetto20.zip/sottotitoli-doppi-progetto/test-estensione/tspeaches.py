# 1.4.6: Whisper sul computer (Speaches in Docker) con il nome di modello di Groq: prima «il modello scelto non esiste
# più» a ogni pezzo e nessun sottotitolo; ora l'estensione legge i modelli del server, sceglie turbo e continua
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
SHOWN = "(document.querySelector('.dualsub-overlay:not([hidden]) .dualsub-orig')||{}).textContent||''"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, stt:'local', sttUrl:'http://localhost:8000/v1', sttModel:'whisper-large-v3-turbo'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/embed/direttaJa1?autoplay=1"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        seen = set()
        for _ in range(100):
            t = await pg.evaluate(SHOWN)
            if t: seen.add(t)
            await pg.wait_for_timeout(200)
        print("1. frasi viste:", len(seen), "| rifiuti 404:", len(log.get("speaches_404", [])), "| pezzi trascritti:", len(log["groq"]))
        print("   modello salvato:", await sw.evaluate("chrome.storage.sync.get('sttModel').then(r=>r.sttModel)"))
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append(str(e)))
        await sw.evaluate("chrome.storage.sync.set({sttModel:'whisper-large-v3-turbo'})")
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1500)
        print("2. popup:", await pp.evaluate("[document.getElementById('sttModel').value, document.getElementById('sttMsg').textContent, document.getElementById('sttLoad').hidden]"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

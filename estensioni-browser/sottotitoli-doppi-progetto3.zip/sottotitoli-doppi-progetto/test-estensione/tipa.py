import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', hoverPause:true})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console: " + m.text) if m.type == "error" else None)
        await pg.goto("https://www.youtube.com/watch?v=ipaTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("document.querySelectorAll('.dualsub-ipa .dualsub-ipaw').length>1", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
        print("1. originale:", await pg.inner_text(".dualsub-orig"))
        print("   IPA     :", await pg.inner_text(".dualsub-ipa"))
        reqs = log.get("ipa", [])
        print("   richieste IPA:", [(w, len(x)) for w, x in reqs], "| parole nella prima:", reqs[0][1][:20] if reqs else None)
        n_orig = await pg.evaluate("document.querySelectorAll('.dualsub-orig .dualsub-word').length")
        n_ipa = await pg.evaluate("document.querySelectorAll('.dualsub-ipa .dualsub-ipaw').length")
        print("   parole:", n_orig, "pronunce:", n_ipa, "OK" if n_orig == n_ipa else "DIVERSE!")
        # 2. passo su una parola: si illumina la sua pronuncia
        await pg.locator(".dualsub-orig .dualsub-word").nth(1).hover(); await pg.wait_for_timeout(1200)
        print("2. illuminata:", await pg.evaluate("[...document.querySelectorAll('.dualsub-ipaw.dualsub-ipa-hl')].map(x=>x.textContent)"),
              "| scheda:", await pg.evaluate("(document.querySelector('.dualsub-card-ipa')||{}).textContent"))
        # 3. salvo nel vocabolario: la pronuncia va anche lì (e nell'esportazione per Anki)
        await pg.locator(".dualsub-orig .dualsub-word").nth(1).click(); await pg.wait_for_timeout(9000)
        await pg.locator(".dualsub-star").click(); await pg.wait_for_timeout(800)
        v = await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab||{}).map(e=>[e.word,e.ipa]))")
        print("3. vocabolario:", v)
        await pg.keyboard.press("Escape"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(800)
        # 4. vado avanti nel video: nessuna richiesta nuova (parole già chieste in anticipo)
        before = len(log.get("ipa", []))
        await pg.evaluate("document.querySelector('video').currentTime=7.5; document.querySelector('video').play()"); await pg.wait_for_timeout(2500)
        await pg.evaluate("document.querySelector('video').pause()")
        print("4. più avanti:", await pg.inner_text(".dualsub-orig"), "→", await pg.inner_text(".dualsub-ipa"), "| richieste nuove:", len(log.get("ipa", [])) - before)
        # 5. pulsante IPA: spengo
        await pg.locator(".dualsub-orig").hover(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-ipabtn").click(); await pg.wait_for_timeout(800)
        st = await sw.evaluate("chrome.storage.sync.get('ipa').then(r=>r.ipa)")
        print("5. spenta: impostazione", st, "| riga:", repr(await pg.evaluate("document.querySelector('.dualsub-ipa').textContent")),
              "| pulsante:", await pg.evaluate("document.querySelector('.dualsub-ipabtn').className"))
        await pg.locator(".dualsub-ipabtn").click(); await pg.wait_for_timeout(800)
        print("   riaccesa:", await pg.inner_text(".dualsub-ipa"))
        # 6. riapro la pagina: le pronunce sono salvate, nessuna richiesta
        await pg.wait_for_timeout(2000)
        before = len(log.get("ipa", []))
        pg2 = await ctx.new_page(); await pg2.goto("https://www.youtube.com/watch?v=ipaTest"); await pg2.wait_for_timeout(1200)
        await pg2.evaluate("document.querySelector('video').play()")
        await pg2.wait_for_function("document.querySelectorAll('.dualsub-ipa .dualsub-ipaw').length>1", timeout=30000)
        print("6. riaperta:", await pg2.inner_text(".dualsub-ipa"), "| richieste nuove:", len(log.get("ipa", [])) - before)
        await pg2.close()
        print("errori:", errs, log["errors"])
        await ctx.close()
    # 7. con la chiave di Groq e traduzione con Gemini: la pronuncia la chiede a Groq
    log["ipa"] = []
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it'})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk-test'}}))""")
        pg = await ctx.new_page()
        await pg.goto("https://www.youtube.com/watch?v=ipaTest2"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("document.querySelectorAll('.dualsub-ipa .dualsub-ipaw').length>1", timeout=40000)
        print("7. servizi usati:", [w for w, _ in log["ipa"]])
        await ctx.close()
    # 8. senza chiavi: nessuna riga, messaggio, nessun errore
    log["ipa"] = []
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ipaTest3"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(5000)
        print("8. senza chiavi: riga", repr(await pg.evaluate("document.querySelector('.dualsub-ipa').textContent")), "| richieste", len(log["ipa"]),
              "| stato:", await sw.evaluate("chrome.storage.local.get('status').then(r=>JSON.stringify(r.status||'').slice(0,160))"), "| errori", errs)
        await ctx.close()
asyncio.run(main())

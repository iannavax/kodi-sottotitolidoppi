LOGINFO = 1
LOG = []
def log(msg, level=0): LOG.append(msg)
class Monitor:
    def abortRequested(self): return True
    def waitForAbort(self, t=0): return True
class Player:
    playing_file = ""
    time = 0.0
    playing = True
    subs = []
    def isPlayingVideo(self): return Player.playing
    def getPlayingFile(self): return Player.playing_file
    def getTime(self): return Player.time
    total = 0.0
    def getTotalTime(self): return Player.total
    def setSubtitles(self, p): Player.subs.append(p)
    def showSubtitles(self, v): pass
    sub_lang = ""
    def getSubtitles(self): return Player.sub_lang
    item_props = {}
    def getPlayingItem(self):
        class _Item:
            def getProperty(_s, k): return Player.item_props.get(k, "")
        return _Item()
BUILTINS = []
def executebuiltin(cmd, wait=False): BUILTINS.append(cmd)
def sleep(ms):
    import time as _t; _t.sleep(ms / 1000.0)

INFO = {}
def getInfoLabel(k): return INFO.get(k, "")
ENGLISH_NAME = 2
def convertLanguage(code, fmt):
    return {"en": "English", "eng": "English", "it": "Italian", "ita": "Italian", "es": "Spanish"}.get(code, "")
RPC = []
RPC_HANDLER = None
def executeJSONRPC(text):
    RPC.append(text)
    import json as _j
    if RPC_HANDLER:
        return _j.dumps(RPC_HANDLER(_j.loads(text)))
    return _j.dumps({"error": {"message": "non disponibile"}})
ISO_639_1 = 0
KODI_LANG = {0: "es", 2: "Spanish"}
def getLanguage(fmt=2, region=False): return KODI_LANG.get(fmt, "")
LOGERROR = 4; LOGWARNING = 3; LOGDEBUG = 0

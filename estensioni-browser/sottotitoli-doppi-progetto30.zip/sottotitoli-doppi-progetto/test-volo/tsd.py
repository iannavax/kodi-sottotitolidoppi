# Parole al Volo 1.12: la scheda resta attaccata alla parola anche se scorri la pagina mentre si aggiorna (foto, ecc.)
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
async def handle(route, request):
    if ".wiktionary.org/" in request.url or request.url.startswith("https://jisho.org/"): return await charness.handle(route, request)
    return await tvolo.handle(route, request)
POS = "(()=>{const c=document.querySelector('.pav-card'); return c ? [c.style.top, Math.round(c.getBoundingClientRect().top)] : null})()"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        await pg.evaluate("document.body.insertAdjacentHTML('beforeend', '<div style=\"height:3000px\"></div>')")
        b = await tvolo.hover(pg, "en", "bread", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        print("1. aperta (top nella pagina, top sullo schermo):", await pg.evaluate(POS))
        await pg.evaluate("window.scrollBy(0, 400)"); await pg.wait_for_timeout(200)
        print("   CARD:", await pg.evaluate("[...document.querySelectorAll('.pav-card')].map(c=>c.getBoundingClientRect().top+' '+c.textContent.slice(0,300))"), await pg.evaluate("[...document.querySelectorAll('.pav-card .dsx-btn')].map(b=>b.textContent)"))
        print("   scrollY:", await pg.evaluate("[window.scrollY, document.documentElement.scrollHeight]"))
        for i in range(3):
            await pg.evaluate("[...document.querySelectorAll('.pav-card .dsx-btn')].find(b=>/conosco/.test(b.textContent)).click()"); await pg.wait_for_timeout(300)
        print("   scrollY dopo:", await pg.evaluate("window.scrollY"))
        print("2. dopo lo scorrimento di 400 px e 3 aggiornamenti:", await pg.evaluate(POS))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("""chrome.storage.local.set({vocab:{
          'en|bread':{id:'en|bread',word:'bread',lang:'en',meaning:'pane',ipa:'bɹɛd',etym:'Old English',sentence:'I like bread.',sentenceTrans:'Mi piace il pane.',gender:'neutro',status:'learning',added:2,videoId:'abc',time:12},
          'cs|chleba':{id:'cs|chleba',word:'chleba',lang:'cs',meaning:'pane',status:'learning',added:1}}})""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/vocab.html"); await pg.wait_for_timeout(900)
        print("1.", await pg.inner_text("#count"), "| lingue:", await pg.evaluate("[...document.querySelectorAll('#langFilter option')].map(o=>o.textContent)"))
        print("   prima voce:", (await pg.locator(".entry").first.inner_text()).replace("\n", " | ")[:250])
        await pg.locator(".entry").first.locator("button", has_text="🔊").click(); await pg.wait_for_timeout(1500)
        print("2. 🔊:", await pg.locator(".entry").first.locator("button.icon").nth(1).get_attribute("title"), "| audio:", log.get("audio"))
        await pg.select_option("#langFilter", "cs"); await pg.wait_for_timeout(300)
        print("3. filtro ceco:", await pg.locator(".entry .word").all_inner_texts())
        await pg.select_option("#langFilter", ""); await pg.click("#view summary")
        await pg.locator("#opts label", has_text="Pronuncia IPA").locator("input").uncheck(); await pg.wait_for_timeout(300)
        print("4. senza IPA:", await pg.evaluate("document.querySelectorAll('.entry .ipa').length"), "| salvato:", await sw.evaluate("chrome.storage.local.get('vocabView')"))
        await pg.locator(".entry").first.locator("button", has_text="Manda ad Anki").click(); await pg.wait_for_timeout(1500)
        print("5. una ad Anki:", await pg.inner_text("#ankiMsg"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

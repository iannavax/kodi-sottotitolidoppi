import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', transcribeMode:'live', cleanTranscript:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsGap"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent", timeout=40000)
        await pg.wait_for_timeout(6000)
        await pg.evaluate("document.querySelector('video').pause()")
        d = await pg.evaluate("document.querySelector('video').duration")
        # punto vuoto: dopo l'ultima frase
        await pg.evaluate("document.querySelector('video').currentTime = Math.max(0, document.querySelector('video').duration - 0.05)")
        await pg.wait_for_timeout(1500)
        print("riquadro vuoto:", repr(await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent")), "| ⚑ nascosto (opacity):", await pg.evaluate("getComputedStyle(document.querySelector('.dualsub-flagbtn')).opacity"))
        box = await pg.evaluate("(()=>{const r=document.querySelector('#movie_player').getBoundingClientRect(); return [r.left,r.top,r.width,r.height]})()")
        await pg.mouse.move(box[0]+box[2]/2, box[1]+box[3]*0.9); await pg.wait_for_timeout(500)
        print("mouse in basso → ⚑ opacity:", await pg.evaluate("getComputedStyle(document.querySelector('.dualsub-flagbtn')).opacity"))
        n0 = len(log["groq"])
        await pg.locator(".dualsub-flagbtn").click(); await pg.wait_for_timeout(500)
        b = pg.locator(".dualsub-fixcard button", has_text="Riascolta")
        print("pulsante:", [await b.nth(i).text_content() for i in range(await b.count())])
        await b.first.click(); await pg.wait_for_timeout(9000)
        print("stato:", await sw.evaluate("chrome.storage.local.get('status').then(r=>(r.status||{}).text)"), "| richieste Groq nuove:", len(log["groq"]) - n0)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

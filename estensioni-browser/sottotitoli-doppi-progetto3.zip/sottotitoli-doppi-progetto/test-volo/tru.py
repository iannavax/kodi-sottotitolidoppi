import asyncio, os, sys, json, urllib.parse
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
orig = tvolo.handle
PAGE = """<!doctype html><html lang="ru"><head><meta charset="utf-8"></head><body style="margin:40px;font:20px/2 sans-serif">
<p id="a">Дорефо́рменная орфогра́фия и совреме́нная.</p>
<p id="b">Дореформенная орфография и Современная.</p>
<p id="c">Доре&shy;формен&shy;ная и Совре&shy;менная.</p>
<table><tr><th id="d">Дореформенная</th><th id="e">Современная</th></tr></table>
</body></html>"""
async def handle(route, request):
    if request.url.startswith("https://example.test/"):
        return await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=PAGE)
    return await orig(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, etym:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        for pid, w in [("a", "Дорефо"), ("b", "Дореформенная"), ("c", "Доре"), ("d", "Дореформенная"), ("e", "Современная"), ("a", "совреме")]:
            await tvolo.hover(pg, pid, w, 1800)
            print(pid, w, "→ word:", repr(await pg.evaluate("(document.querySelector('.pav-word')||{}).textContent")), "| textcard:", await pg.evaluate("!!document.querySelector('.pav-textcard')"),
                  "| meaning:", await pg.evaluate("(document.querySelector('.pav-meaning')||{}).textContent"))
            await pg.keyboard.press("Escape")
        # doppio clic
        b = await tvolo.word_box(pg, "b", "Дореформенная")
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        print("dblclick → word:", repr(await pg.evaluate("(document.querySelector('.pav-word')||{}).textContent")), "| textcard:", await pg.evaluate("!!document.querySelector('.pav-textcard')"), "| sel:", repr(await pg.evaluate("String(getSelection())")))
        print("google:", [t for d, t in tvolo.log["google"]][:12])
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

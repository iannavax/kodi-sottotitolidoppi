# 1.10.1: costo dell'analisi della pagina (parole salvate + 1500 modi di dire) su una pagina grande, e cosa succede nelle altre schede
import asyncio, os, sys, json, time
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
FILL = "".join(f'<p lang="en">We went to the market and bought some fresh bread number {i}; he kicked the bucket and she spilled the beans, then they broke the ice and walked home slowly.</p>' for i in range(2500))
tvolo.PAGE = tvolo.PAGE.replace("</body>", FILL + "</body>")
IDIOMS = {f"idiom{i}": {"text": f"piece of cake {i} number", "meaning": "x", "lang": "en", "at": 1} for i in range(1500)}
IDIOMS["kick"] = {"text": "kicked the bucket", "meaning": "morire", "lang": "en", "at": 1}
VOCAB = {f"en|w{i}": {"id": f"en|w{i}", "word": f"fresh{i}", "lang": "en", "status": "learning"} for i in range(400)}
VOCAB["en|bread"] = {"id": "en|bread", "word": "bread", "lang": "en", "status": "learning"}
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, viewport={"width": 1100, "height": 650},
                                                         args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'google', pavEngine:'google', idiomPage:true, savedPage:true})")
        pages = []
        for i in range(3):
            pg = await ctx.new_page(); await pg.goto("https://example.test/p.html"); pages.append(pg)
        await pages[0].wait_for_timeout(3500)
        for pg in pages:
            await pg.evaluate("window.__lt=[]; try{ new PerformanceObserver(l=>{for(const e of l.getEntries()) window.__lt.push(Math.round(e.duration))}).observe({entryTypes:['longtask']}) }catch(e){}")
        cdps = []
        for pg in pages:
            c = await ctx.new_cdp_session(pg); await c.send("Performance.enable"); cdps.append(c)
        async def script(c):
            m = await c.send("Performance.getMetrics"); d = {x["name"]: x["value"] for x in m["metrics"]}
            return d["ScriptDuration"], d["TaskDuration"], d["JSHeapUsedSize"]
        a = [await script(c) for c in cdps]
        prof = cdps[0]; await prof.send("Profiler.enable"); await prof.send("Profiler.setSamplingInterval", {"interval": 500}); await prof.send("Profiler.start")
        # cambia il vocabolario e i modi di dire (come succede aprendo una scheda): le altre pagine devono reagire il meno possibile
        t0 = time.time()
        await sw.evaluate("chrome.storage.local.set({pavIdioms: %s, vocab: %s})" % (json.dumps(IDIOMS), json.dumps(VOCAB)))
        await pages[0].bring_to_front()
        await pages[0].wait_for_timeout(9000)
        pr = (await prof.send("Profiler.stop"))["profile"]
        nodes = {n["id"]: n for n in pr["nodes"]}; self_t = {}
        dts = pr["timeDeltas"]
        for sid, dt in zip(pr["samples"], dts):
            cf = nodes[sid]["callFrame"]; k = f'{cf["functionName"] or "(anon)"} {cf["url"].split("/")[-1]}:{cf["lineNumber"]}'
            self_t[k] = self_t.get(k, 0) + dt
        print("più costosi:", [(k, round(v / 1000)) for k, v in sorted(self_t.items(), key=lambda x: -x[1])[:8]])
        b = [await script(c) for c in cdps]
        for i, pg in enumerate(pages):
            hl = await pg.evaluate("[...CSS.highlights.keys()].map(k=>k+':'+CSS.highlights.get(k).size).join(' ')")
            print(f"scheda {i} ({'in primo piano' if i == 0 else 'in secondo piano'}): script {b[i][0]-a[i][0]:.2f}s, attività {b[i][1]-a[i][1]:.2f}s, memoria +{(b[i][2]-a[i][2])//1024} KB | longtask {await pg.evaluate('window.__lt')} | evidenziazioni: {hl}")
        print("errori:", tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

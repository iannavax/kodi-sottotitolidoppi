# 1.7.4: Speaches vuole il campo «voice» (422): lo mando; se non lo accetta provo altri valori
import asyncio, os, sys, json
os.environ["PIPER_SPEACHES"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def run(p, ok_voice):
    if ok_voice: os.environ["SPEACHES_VOICE_OK"] = ok_voice
    else: os.environ.pop("SPEACHES_VOICE_OK", None)
    log.pop("speaches_tts", None)
    ctx, sw = await launch(p, "", None)
    eid = sw.url.split("/")[2]
    await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'en', ttsLang:'it', ttsSpeaches:true, ttsVoice:'speaches:it_IT-riccardo-x_low'})")
    pp = await ctx.new_page(); errs = []
    pp.on("pageerror", lambda e: errs.append(str(e)))
    await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1200)
    await pp.evaluate("document.getElementById('dTts').open=true"); await pp.wait_for_timeout(1500)
    await pp.click("#ttsTest"); await pp.wait_for_timeout(3000)
    info = await pp.inner_text("#ttsInfo")
    voices = [json.loads(x).get("voice") for x in log.get("speaches_tts", [])]
    await ctx.close()
    return info, voices, errs
async def main():
    async with async_playwright() as p:
        i1, v1, e1 = await run(p, "")
        print("1. server che accetta qualsiasi voce:", i1, "| voci inviate:", v1)
        i2, v2, e2 = await run(p, "default")
        print("2. server che accetta solo «default»:", i2, "| voci inviate:", v2)
        ok = "Speaches" in i1 and v1 == ["riccardo"] and "Speaches" in i2 and v2 == ["riccardo", "default"]
        print("errori:", (e1 + e2) if ok else e1 + e2 + ["voce di Speaches non va"])
asyncio.run(main())

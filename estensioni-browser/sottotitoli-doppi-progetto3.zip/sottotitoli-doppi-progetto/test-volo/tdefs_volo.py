# 1.10: definizioni nella lingua della parola anche da Wiktionary (edizione della lingua, poi inglese), con "traduci"; ⚑ modi di dire
import asyncio, os, sys, json, re
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
OTHER = ("https://tatoeba.org/", "https://api.tatoeba.org/", "https://api.languagetool.org/", "https://raw.githubusercontent.com/",
         "https://commons.wikimedia.org/", "https://upload.wikimedia.org/", "https://audio.tatoeba.org/")
async def handle(route, request):
    if request.url.startswith(OTHER) or re.match(r"https://[a-z-]+\.wiktionary\.org/", request.url): return await charness.handle(route, request)
    return await tvolo.handle(route, request)
DEFS = "(document.querySelector('.pav-card .dsx-defs')||{}).innerText||'(nessuna)'"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false, learnFreq:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/pagina.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "ru", "Кошка", 4000)
        print("1. кошка (Google senza definizioni → ru.wiktionary):\n  ", (await pg.evaluate(DEFS)).replace("\n", " | "))
        print("   richieste ru:", [x for x in charness.log.get("wikt_other", []) if x[0] == "ru"])
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.locator(".pav-card .dsx-defs .dsx-btn", has_text="traduci").first.click(); await pg.wait_for_timeout(1500)
        print("2. dopo traduci:", (await pg.evaluate(DEFS)).replace("\n", " | "))
        await tvolo.hover(pg, "en", "bread", 3500)
        print("3. bread (Google + Wiktionary inglese):\n  ", (await pg.evaluate(DEFS)).replace("\n", " | "))
        await sw.evaluate("chrome.storage.sync.set({gdDefs:false})"); await pg.wait_for_timeout(300)
        await tvolo.hover(pg, "en", "bread", 2500)
        print("4. spente:", await pg.evaluate(DEFS))
        print("errori:", errs, tvolo.log["errors"], charness.log.get("errors"))
        await ctx.close()
asyncio.run(main())

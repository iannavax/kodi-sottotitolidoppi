#!/bin/bash
# Scarica da npm i componenti di Piper che il pacchetto include (non stanno nel repository: pesano ~30 MB).
# Uso: ./fetch-piper.sh [cartella]   (di serie /home/claude/vendor-piper, o $PIPER_VENDOR)
#   @diffusionstudio/piper-wasm 1.0.0  → piper_phonemize.{js,wasm,data}   (espeak-ng + piper-phonemize in WebAssembly, MIT/GPL-3 per espeak-ng)
#   onnxruntime-web 1.18.0             → ort.wasm.min.js, ort-wasm-simd.wasm (solo WebAssembly, un thread)    (MIT)
set -e; D=${1:-${PIPER_VENDOR:-/home/claude/vendor-piper}}; mkdir -p "$D"; T=$(mktemp -d); cd "$T"
npm pack @diffusionstudio/piper-wasm@1.0.0 onnxruntime-web@1.18.0 >/dev/null
for f in *.tgz; do mkdir x-${f%.tgz}; tar xzf $f -C x-${f%.tgz}; done
cp x-diffusionstudio-piper-wasm-*/package/build/piper_phonemize.{js,wasm,data} "$D"/
cp x-onnxruntime-web-*/package/dist/ort.wasm.min.js x-onnxruntime-web-*/package/dist/ort-wasm-simd.wasm "$D"/
cp x-diffusionstudio-piper-wasm-*/package/package.json "$D"/PIPER-WASM-package.json; cp x-onnxruntime-web-*/package/package.json "$D"/ORT-package.json
rm -rf "$T"; ls -la "$D"

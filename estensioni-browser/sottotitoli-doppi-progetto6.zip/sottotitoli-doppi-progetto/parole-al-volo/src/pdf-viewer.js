// Lettore PDF di Parole al Volo: il lettore del browser non lascia entrare le estensioni, quindi i PDF si aprono qui
// (pdf.js di Mozilla). Ogni pagina è disegnata con sopra il suo testo vero (trasparente): la scheda passando il
// mouse, la selezione e la traduzione funzionano come sulle pagine web (volo.js è caricato in questa pagina).
import * as pdfjsLib from "./pdfjs/pdf.min.mjs";
pdfjsLib.GlobalWorkerOptions.workerSrc = "./pdfjs/pdf.worker.min.mjs";

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
let scale = 1.4, doc = null, gen = 0;
try { scale = Number(localStorage.getItem("pavPdfScale")) || 1.4; } catch {}

function message(html) { $("pages").innerHTML = `<div class="msg">${html}</div>`; }

async function openData(data, name) {
  const my = ++gen;
  $("name").textContent = name || "PDF";
  document.title = (name || "PDF") + " — Parole al Volo";
  $("pages").textContent = "";
  message("Apro il PDF…");
  try {
    doc = await pdfjsLib.getDocument({ data, isEvalSupported: false }).promise;
  } catch (e) {
    if (my === gen) message(`<b>Non riesco ad aprire questo PDF.</b><br>${String(e && e.message || e).replace(/</g, "&lt;")}`);
    return;
  }
  if (my !== gen) return;
  $("count").textContent = doc.numPages + (doc.numPages === 1 ? " pagina" : " pagine");
  await layout(my);
}

// Le pagine si preparano tutte (misure giuste per scorrere), ma si disegnano solo quando arrivano sullo schermo
async function layout(my) {
  $("pages").textContent = "";
  $("zoom").textContent = Math.round(scale * 100) + "%";
  const obs = new IntersectionObserver((entries) => {
    for (const en of entries) if (en.isIntersecting) { obs.unobserve(en.target); drawPage(en.target, my).catch((e) => console.error("Parole al Volo, pagina del PDF:", e)); }
  }, { rootMargin: "800px 0px" });
  for (let n = 1; n <= doc.numPages; n++) {
    const page = await doc.getPage(n);
    if (my !== gen) return;
    const vp = page.getViewport({ scale });
    const div = document.createElement("div");
    div.className = "page";
    div.dataset.n = n;
    div.style.width = Math.floor(vp.width) + "px";
    div.style.height = Math.floor(vp.height) + "px";
    div.style.setProperty("--scale-factor", String(scale));
    div.style.setProperty("--total-scale-factor", String(scale));
    div.style.setProperty("--user-unit", "1");
    const num = document.createElement("span"); num.className = "num"; num.textContent = n;
    div.append(num);
    $("pages").append(div);
    obs.observe(div);
  }
}

async function drawPage(div, my) {
  const page = await doc.getPage(Number(div.dataset.n));
  if (my !== gen) return;
  const vp = page.getViewport({ scale });
  const ratio = window.devicePixelRatio || 1;
  const canvas = document.createElement("canvas");
  canvas.width = Math.floor(vp.width * ratio);
  canvas.height = Math.floor(vp.height * ratio);
  div.prepend(canvas);
  await page.render({ canvas, canvasContext: canvas.getContext("2d"), viewport: vp, transform: ratio !== 1 ? [ratio, 0, 0, ratio, 0, 0] : null }).promise;
  if (my !== gen) return;
  const tl = document.createElement("div");
  tl.className = "textLayer";
  div.append(tl);
  await new pdfjsLib.TextLayer({ textContentSource: page.streamTextContent(), container: tl, viewport: vp }).render();
}

async function openUrl(url) {
  $("orig").href = url; $("orig").hidden = false;
  const name = decodeURIComponent((url.split("?")[0].split("/").pop() || "PDF"));
  message("Scarico il PDF…");
  try {
    const r = await fetch(url, { credentials: "include" });
    if (!r.ok) throw new Error("il sito ha risposto " + r.status);
    await openData(new Uint8Array(await r.arrayBuffer()), name);
  } catch (e) {
    const local = /^file:/i.test(url);
    message(`<b>Non riesco a leggere questo PDF da qui</b> (${String(e && e.message || e).replace(/</g, "&lt;")}).<br><br>` +
      (local ? "È un file del computer: premi <b>📂 Apri un PDF…</b> qui sopra e sceglilo (oppure, in Edge/Chrome, nella pagina delle estensioni attiva «Consenti l'accesso agli URL dei file» per Parole al Volo)."
        : "Scaricalo e aprilo con <b>📂 Apri un PDF…</b> qui sopra."));
  }
}

$("file").addEventListener("change", async () => {
  const f = $("file").files[0];
  if (!f) return;
  $("orig").hidden = true;
  history.replaceState(null, "", location.pathname);
  await openData(new Uint8Array(await f.arrayBuffer()), f.name);
});
const rezoom = (k) => {
  if (!doc) return;
  scale = Math.min(4, Math.max(0.5, Math.round(scale * k * 10) / 10));
  try { localStorage.setItem("pavPdfScale", String(scale)); } catch {}
  const top = window.scrollY / Math.max(1, document.body.scrollHeight);
  layout(++gen).then(() => window.scrollTo(0, top * document.body.scrollHeight));
};
$("zoomIn").addEventListener("click", () => rezoom(1.15));
$("zoomOut").addEventListener("click", () => rezoom(1 / 1.15));

const file = params.get("file");
if (file) openUrl(file);
else message("Premi <b>📂 Apri un PDF…</b> qui sopra per leggere un PDF del computer con Parole al Volo: passa il mouse sulle parole per la loro scheda, evidenzia un pezzo per tradurlo.<br><br>" +
  "I PDF aperti nel browser si aprono qui anche dal popup («📄 Apri questo PDF con Parole al Volo») o da soli, se lo scegli nel popup.");

# 5.19.1: diretta in cui YouTube ricarica il flusso (nuova MediaSource, l'orologio del video riparte indietro):
# prima l'audio nuovo veniva scartato come "già trascritto" e i sottotitoli non tornavano più (neanche spegnendo e riaccendendo)
import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
RESTART = """(async () => { const v = document.querySelector('video'); const ms = new MediaSource(); v.src = URL.createObjectURL(ms);
  await new Promise(r => ms.addEventListener('sourceopen', r, { once: true }));
  const sb = ms.addSourceBuffer('audio/webm; codecs="opus"'); const data = await (await fetch('/media/speech.webm')).arrayBuffer();
  sb.appendBuffer(data); await new Promise(r => sb.addEventListener('updateend', r, { once: true })); try { ms.duration = Infinity; } catch (e) {}
  v.currentTime = 2; await v.play(); })()"""
SHOWN = "(document.querySelector('.dualsub-overlay:not([hidden]) .dualsub-orig')||{}).textContent||''"
async def watch(pg, secs):
    seen = set()
    for _ in range(secs * 5):
        t = await pg.evaluate(SHOWN)
        if t: seen.add(t)
        await pg.wait_for_timeout(200)
    return seen
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/embed/direttaJa1?autoplay=1"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        first = await watch(pg, 30)
        t1 = await pg.evaluate("document.querySelector('video').currentTime")
        n1 = len(log["groq"])
        print(f"1. prima del ricaricamento ({t1:.0f} s): frasi viste {len(first)}, pezzi a Whisper {n1}")
        await pg.evaluate(RESTART); await pg.wait_for_timeout(500)
        print("   orologio dopo il ricaricamento:", round(await pg.evaluate("document.querySelector('video').currentTime"), 1))
        second = await watch(pg, 30)
        print(f"2. dopo: frasi viste {len(second)}, pezzi nuovi a Whisper {len(log['groq']) - n1}")
        print("   stato:", await pg.evaluate("(document.querySelector('.dualsub-status')||{}).textContent||''"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

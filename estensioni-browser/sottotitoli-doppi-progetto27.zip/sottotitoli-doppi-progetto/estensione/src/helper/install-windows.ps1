# Sottotitoli Doppi - installazione del programma per yt-dlp (Windows)
# Installa, solo per il tuo utente e senza permessi di amministratore:
#   yt-dlp (scarica l'audio), Deno (serve a yt-dlp per YouTube), il programma di appoggio,
#   e lo registra in Edge, Chrome, Brave e Firefox.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$ExtId    = '__EXTID__'
$GeckoId  = 'sottotitoli-doppi@estensione.local'
$GeckoUnico = 'sottotitoli-parole@estensione.local'
$HostName = 'com.sottotitolidoppi.helper'
$Dir      = Join-Path $env:LOCALAPPDATA 'SottotitoliDoppi'
$Utf8     = New-Object System.Text.UTF8Encoding $false

function Say($t) { Write-Host $t }

function Try-Py($exe, $pyargs) {
  # In Windows PowerShell 5.1, con 'Stop' qualsiasi scritta sul canale degli errori diventa un errore grave
  $ErrorActionPreference = 'Continue'
  try {
    $out = & $exe @pyargs -c "import sys; print(sys.executable)" 2>$null
    if ($LASTEXITCODE -eq 0 -and $out) {
      $p = ([string]($out | Select-Object -Last 1)).Trim()
      if ($p -and (Test-Path $p)) { return $p }
    }
  } catch {}
  return $null
}

function Find-Python {
  $p = Try-Py 'py' @('-3')
  if (-not $p) { $p = Try-Py 'python' @() }
  if (-not $p) { $p = Try-Py 'python3' @() }
  if (-not $p) {
    $f = Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python3*\python.exe') -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($f) { $p = $f.FullName }
  }
  return $p
}

try {
  Say ''
  Say '=== Sottotitoli Doppi: programma per yt-dlp ==='
  Say ''
  New-Item -ItemType Directory -Force -Path $Dir | Out-Null

  Say '1/5  Cerco Python...'
  $Py = Find-Python
  if (-not $Py) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
      Say '     Python non c''e'': lo installo con winget (potrebbe chiedere una conferma)...'
      winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
      $Py = Find-Python
    }
  }
  if (-not $Py) {
    Say ''
    Say 'Non riesco a trovare o installare Python.'
    Say 'Scaricalo da https://www.python.org/downloads/ (spunta "Add python.exe to PATH"), poi rilancia questo file.'
    return
  }
  Say "     Python: $Py"

  Say '2/5  Scarico yt-dlp...'
  Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe' -OutFile (Join-Path $Dir 'yt-dlp.exe')

  Say '3/5  Scarico Deno...'
  $zip = Join-Path $env:TEMP 'sottotitoli-doppi-deno.zip'
  Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip' -OutFile $zip
  Expand-Archive -Path $zip -DestinationPath $Dir -Force
  Remove-Item $zip -Force

  # ffmpeg: serve solo per le dirette in anticipo. Se non si riesce a scaricarlo, il resto funziona lo stesso.
  if (-not (Test-Path (Join-Path $Dir 'ffmpeg.exe')) -and -not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
    Say '     Scarico ffmpeg (per le dirette sincronizzate, circa 100 MB: un po'' di pazienza)...'
    try {
      $fz = Join-Path $env:TEMP 'sottotitoli-doppi-ffmpeg.zip'
      Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip' -OutFile $fz
      Add-Type -AssemblyName System.IO.Compression.FileSystem
      $za = [IO.Compression.ZipFile]::OpenRead($fz)
      try {
        $entry = $za.Entries | Where-Object { $_.FullName -like '*/bin/ffmpeg.exe' } | Select-Object -First 1
        if ($entry) { [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, (Join-Path $Dir 'ffmpeg.exe'), $true) }
      } finally { $za.Dispose() }
      Remove-Item $fz -Force
    } catch {
      Say '     ffmpeg non scaricato: le dirette sincronizzate non funzioneranno (il resto si'').'
    }
  }

  Say '4/5  Installo il programma di appoggio...'
  [IO.File]::WriteAllBytes((Join-Path $Dir 'sd_host.py'), [Convert]::FromBase64String('__HOSTB64__'))
  # Nel file .bat uso %LOCALAPPDATA% invece del percorso completo, cosi' funziona anche con nomi utente accentati
  $PyBat = $Py
  if ($PyBat.StartsWith($env:LOCALAPPDATA, [StringComparison]::OrdinalIgnoreCase)) { $PyBat = '%LOCALAPPDATA%' + $PyBat.Substring($env:LOCALAPPDATA.Length) }
  elseif ($PyBat.StartsWith($env:USERPROFILE, [StringComparison]::OrdinalIgnoreCase)) { $PyBat = '%USERPROFILE%' + $PyBat.Substring($env:USERPROFILE.Length) }
  $bat = Join-Path $Dir 'sd_host.bat'
  $batText = '@echo off' + "`r`n" + '"' + $PyBat + '" -u "%~dp0sd_host.py" %*' + "`r`n"
  [IO.File]::WriteAllText($bat, $batText, [Text.Encoding]::ASCII)

  # Manifesto per Edge/Chrome/Brave (tengo gli identificativi gia' registrati)
  $chromeManifest = Join-Path $Dir 'host-chrome.json'
  $origins = New-Object System.Collections.ArrayList
  if (Test-Path $chromeManifest) {
    try { foreach ($o in (Get-Content $chromeManifest -Raw | ConvertFrom-Json).allowed_origins) { [void]$origins.Add([string]$o) } } catch {}
  }
  if ($ExtId -and -not $origins.Contains("chrome-extension://$ExtId/")) { [void]$origins.Add("chrome-extension://$ExtId/") }
  $cm = [ordered]@{ name = $HostName; description = 'Sottotitoli Doppi: audio con yt-dlp'; path = $bat; type = 'stdio'; allowed_origins = @($origins.ToArray()) }
  [IO.File]::WriteAllText($chromeManifest, (ConvertTo-Json -InputObject $cm -Depth 4), $Utf8)

  $ffManifest = Join-Path $Dir 'host-firefox.json'
  $fm = [ordered]@{ name = $HostName; description = 'Sottotitoli Doppi: audio con yt-dlp'; path = $bat; type = 'stdio'; allowed_extensions = @($GeckoId, $GeckoUnico) }
  [IO.File]::WriteAllText($ffManifest, (ConvertTo-Json -InputObject $fm -Depth 4), $Utf8)

  foreach ($k in @('HKCU:\Software\Microsoft\Edge\NativeMessagingHosts',
                   'HKCU:\Software\Google\Chrome\NativeMessagingHosts',
                   'HKCU:\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts',
                   'HKCU:\Software\Chromium\NativeMessagingHosts')) {
    $key = Join-Path $k $HostName
    New-Item -Path $key -Force | Out-Null
    Set-Item -Path $key -Value $chromeManifest
  }
  $key = Join-Path 'HKCU:\Software\Mozilla\NativeMessagingHosts' $HostName
  New-Item -Path $key -Force | Out-Null
  Set-Item -Path $key -Value $ffManifest

  Say '5/5  Verifico...'
  $v = & (Join-Path $Dir 'yt-dlp.exe') --version
  Say "     yt-dlp $v"
  $d = & (Join-Path $Dir 'deno.exe') --version | Select-Object -First 1
  Say "     $d"
  if ((Test-Path (Join-Path $Dir 'ffmpeg.exe')) -or (Get-Command ffmpeg -ErrorAction SilentlyContinue)) { Say '     ffmpeg: si''' } else { Say '     ffmpeg: no (niente dirette sincronizzate)' }
  if ($origins.Count -eq 0) {
    Say ''
    Say 'Nota: installatore scaricato da Firefox. Se usi l''estensione anche in Edge o Chrome,'
    Say 'scarica e lancia l''installatore anche da li''.'
  }
  Say ''
  Say 'Fatto! Torna nel browser e premi "Verifica di nuovo".'
  Say "(Tutto e' nella cartella $Dir)"
} catch {
  Say ''
  Say ('Errore: ' + $_.Exception.Message)
  Say 'Controlla la connessione a Internet e rilancia questo file. Se l''errore si ripete, mandalo a chi ti ha dato l''estensione.'
}

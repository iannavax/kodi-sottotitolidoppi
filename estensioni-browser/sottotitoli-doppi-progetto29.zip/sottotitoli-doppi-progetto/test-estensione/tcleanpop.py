# 1.6.0: tendina (solo frasi incerte / tutte / spenta). 5.21: correzione della trascrizione con Gemini/Groq, accendibile dal riquadro in cima al popup
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk'}})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(900)
        print("1. senza trascrizione:", await pp.evaluate("document.getElementById('cleanQuick').hidden"))
        await pp.evaluate("updateLive({onVideo:true, running:true})"); await pp.wait_for_timeout(200)
        print("2. trascrizione in corso:", await pp.evaluate("[document.getElementById('cleanQuick').hidden, document.getElementById('cleanMode2').value]"), "|", await pp.inner_text("#cleanInfo2"))
        await pp.select_option("#cleanMode2", "off"); await pp.wait_for_timeout(300)
        st = await sw.evaluate("chrome.storage.sync.get(['cleanTranscript','cleanMode']).then(r=>JSON.stringify(r))")
        sec = await pp.eval_on_selector("#cleanMode", "e=>e.value")
        print("3. spenta:", st, "| tendina nella sezione:", sec, "|", await pp.inner_text("#cleanInfo2"))
        await pp.evaluate("document.getElementById('dLive').open = true"); await pp.select_option("#cleanMode", "all"); await pp.wait_for_timeout(300)
        print("4. tutte:", await sw.evaluate("chrome.storage.sync.get(['cleanTranscript','cleanMode']).then(r=>JSON.stringify(r))"), "|", await pp.eval_on_selector("#cleanMode2", "e=>e.value"))
        ok = '"cleanMode":"off"' in st and sec == "off"
        print("errori:", errs if ok else errs + ["tendina della correzione non va"])
        await ctx.close()
asyncio.run(main())

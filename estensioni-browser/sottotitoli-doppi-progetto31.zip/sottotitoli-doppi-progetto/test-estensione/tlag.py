# 1.6.3: la trascrizione va avanti ma la traduzione del modello resta indietro: dopo 5 s le frasi già passate ricevono la traduzione rapida di Google
import asyncio, sys, json, os
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', transcribeMode:'live', cleanMode:'off', vodBack:0, ipa:false}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsLag1"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        seen = []
        for _ in range(60):
            await pg.wait_for_timeout(1000)
            tr = await pg.evaluate("[(document.querySelector('.dualsub-trans')||{}).textContent||'', (document.querySelector('.dualsub-trans')||{}).className||'']")
            org = await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent||''")
            if org and tr[0] and tr[0] != "…": seen.append((org[:30], tr[0][:30], "quick" in tr[1]))
            if len(seen) >= 3: break
        print("1. con Gemini lentissimo (", os.environ.get("GEM_SLOW"), "s), frasi mostrate con traduzione:", seen[:3])
        print("   richieste Gemini:", len(log.get("gcalls", [])), "| Google:", log["google"])
        ok = bool(seen) and all(t.startswith("IT[") or q for _, t, q in seen)
        print("errori:", errs if ok else errs + ["traduzione rapida di recupero non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

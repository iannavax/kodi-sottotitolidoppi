# -*- coding: utf-8 -*-
# Sottotitoli di testo dentro un file .mkv in streaming, letti SENZA scaricare il film.
# Un .mkv ha un indice (Cues) che dice dove si trova ogni sottotitolo dentro il file: leggo l'inizio del file,
# le tracce e l'indice, poi solo i pezzettini con le frasi (poche centinaia di byte l'uno), con richieste "Range".
# Funziona se l'indice contiene anche i sottotitoli (lo fa mkvmerge, il programma con cui sono fatti quasi tutti i .mkv
# dei film). Se l'indice non li contiene, i sottotitoli si potrebbero leggere solo scaricando tutto il file.
import re
import struct
import time
import zlib
from concurrent.futures import ThreadPoolExecutor

ID_EBML, ID_SEGMENT, ID_SEEKHEAD, ID_SEEK, ID_SEEKID, ID_SEEKPOS = 0x1A45DFA3, 0x18538067, 0x114D9B74, 0x4DBB, 0x53AB, 0x53AC
ID_INFO, ID_TCSCALE, ID_TRACKS, ID_TRACKENTRY = 0x1549A966, 0x2AD7B1, 0x1654AE6B, 0xAE
ID_TRACKNUM, ID_TRACKTYPE, ID_CODEC, ID_LANG, ID_LANGBCP, ID_NAME, ID_FORCED, ID_DEFAULT = 0xD7, 0x83, 0x86, 0x22B59C, 0x22B59D, 0x536E, 0x55AA, 0x88
ID_CONTENTENCODINGS, ID_CONTENTCOMP, ID_COMPALGO = 0x6D80, 0x5034, 0x4254
ID_CUES, ID_CUEPOINT, ID_CUETIME, ID_CUETRACKPOS, ID_CUETRACK, ID_CUECLUSTER, ID_CUEREL, ID_CUEDUR = 0x1C53BB6B, 0xBB, 0xB3, 0xB7, 0xF7, 0xF1, 0xF0, 0xB2
ID_CLUSTER, ID_TIMECODE, ID_SIMPLEBLOCK, ID_BLOCKGROUP, ID_BLOCK, ID_BLOCKDUR = 0x1F43B675, 0xE7, 0xA3, 0xA0, 0xA1, 0x9B
TEXT_CODECS = ("S_TEXT/UTF8", "S_TEXT/ASS", "S_TEXT/SSA", "S_TEXT/WEBVTT", "S_ASS", "S_SSA")


class NotSupported(Exception):
    pass


def _vint(buf, pos, keep_marker=False):
    b = buf[pos]
    for n in range(8):
        if b & (0x80 >> n):
            break
    else:
        raise ValueError("vint non valido")
    length = n + 1
    val = b if keep_marker else b & (0xFF >> length)
    for i in range(1, length):
        val = (val << 8) | buf[pos + i]
    unknown = not keep_marker and val == (1 << (7 * length)) - 1
    return val, length, unknown


def _header(buf, pos):
    eid, l1, _ = _vint(buf, pos, True)
    size, l2, unknown = _vint(buf, pos + l1)
    return eid, None if unknown else size, l1 + l2


def _children(buf, start, end):
    pos = start
    while pos < end and pos + 2 <= len(buf):
        try:
            eid, size, hl = _header(buf, pos)
        except (ValueError, IndexError):
            return
        data = pos + hl
        if size is None:
            size = end - data
        yield eid, data, size
        pos = data + size


def _uint(buf, a, n):
    v = 0
    for i in range(n):
        v = (v << 8) | buf[a + i]
    return v


def _str(buf, a, n):
    return bytes(buf[a:a + n]).split(b"\x00")[0].decode("utf-8", "replace")


class MkvSubtitles(object):
    """read(offset, length) -> bytes: lettura di un pezzo del file (richiesta Range)"""

    def __init__(self, read, log=None):
        self.total, self.missing = 0, 0
        self.read = read
        self.log = log or (lambda m: None)

    def _element(self, abs_pos, want=None, max_len=8 << 20):
        head = self.read(abs_pos, 16)
        eid, size, hl = _header(head, 0)
        if want is not None and eid != want:
            raise NotSupported("elemento inatteso a %d" % abs_pos)
        if size is None or size > max_len:
            raise NotSupported("elemento troppo grande (%s byte)" % size)
        return eid, self.read(abs_pos + hl, size)

    def open(self):
        head = self.read(0, 65536)
        eid, size, hl = _header(head, 0)
        if eid != ID_EBML:
            raise NotSupported("non è un file .mkv")
        pos = hl + size
        eid, size, hl = _header(head, pos)
        if eid != ID_SEGMENT:
            raise NotSupported("struttura .mkv non riconosciuta")
        self.seg = pos + hl
        seek, self.scale = {}, 1000000
        tracks_buf = None
        for eid, data, sz in _children(head, self.seg, len(head)):
            if eid == ID_SEEKHEAD and data + sz <= len(head):
                for e2, d2, s2 in _children(head, data, data + sz):
                    if e2 != ID_SEEK:
                        continue
                    sid = spos = None
                    for e3, d3, s3 in _children(head, d2, d2 + s2):
                        if e3 == ID_SEEKID:
                            sid = _uint(head, d3, s3)
                        elif e3 == ID_SEEKPOS:
                            spos = _uint(head, d3, s3)
                    if sid is not None and spos is not None:
                        seek.setdefault(sid, spos)
            elif eid == ID_INFO and data + sz <= len(head):
                self._info(head, data, sz)
            elif eid == ID_TRACKS and data + sz <= len(head):
                tracks_buf = bytes(head[data:data + sz])
            elif eid == ID_CLUSTER:
                break
        if ID_INFO in seek and self.scale == 1000000:
            try:
                _, b = self._element(self.seg + seek[ID_INFO], ID_INFO)
                self._info(b, 0, len(b))
            except Exception:
                pass
        if tracks_buf is None:
            if ID_TRACKS not in seek:
                raise NotSupported("tracce non trovate")
            _, tracks_buf = self._element(self.seg + seek[ID_TRACKS], ID_TRACKS)
        self.tracks = self._tracks(tracks_buf)
        self.cues_pos = seek.get(ID_CUES)
        return self

    def _info(self, buf, data, sz):
        for e, d, s in _children(buf, data, data + sz):
            if e == ID_TCSCALE:
                self.scale = _uint(buf, d, s) or 1000000

    def _tracks(self, buf):
        out = []
        for e, d, s in _children(buf, 0, len(buf)):
            if e != ID_TRACKENTRY:
                continue
            t = {"lang": "eng", "name": "", "codec": "", "type": 0, "num": 0, "zlib": False, "forced": False}
            for e2, d2, s2 in _children(buf, d, d + s):
                if e2 == ID_TRACKNUM:
                    t["num"] = _uint(buf, d2, s2)
                elif e2 == ID_TRACKTYPE:
                    t["type"] = _uint(buf, d2, s2)
                elif e2 == ID_CODEC:
                    t["codec"] = _str(buf, d2, s2)
                elif e2 == ID_LANG:
                    t["lang"] = _str(buf, d2, s2)
                elif e2 == ID_LANGBCP:
                    t["lang"] = _str(buf, d2, s2).split("-")[0]
                elif e2 == ID_NAME:
                    t["name"] = _str(buf, d2, s2)
                elif e2 == ID_FORCED:
                    t["forced"] = bool(_uint(buf, d2, s2))
                elif e2 == ID_CONTENTENCODINGS:
                    t["zlib"] = self._is_zlib(buf, d2, s2)
            out.append(t)
        return out

    def _is_zlib(self, buf, d, s):
        found = False
        for e, d2, s2 in _children(buf, d, d + s):
            for e3, d3, s3 in _children(buf, d2, d2 + s2):
                if e3 == ID_CONTENTCOMP:
                    algo = 0
                    for e4, d4, s4 in _children(buf, d3, d3 + s3):
                        if e4 == ID_COMPALGO:
                            algo = _uint(buf, d4, s4)
                    found = found or algo == 0
        return found

    def subtitle_tracks(self):
        """Tracce di sottotitoli di testo: [{"num", "lang", "name", "codec", "forced"}]"""
        return [t for t in self.tracks if t["type"] == 0x11 and t["codec"] in TEXT_CODECS]

    def cue_points(self, tracknum):
        """Dall'indice: [(tempo_ms, cluster, posizione_relativa o None, durata_ms o None)] della traccia"""
        if self.cues_pos is None:
            raise NotSupported("il file non ha l'indice (Cues)")
        _, buf = self._element(self.seg + self.cues_pos, ID_CUES, max_len=64 << 20)
        out = []
        for e, d, s in _children(buf, 0, len(buf)):
            if e != ID_CUEPOINT:
                continue
            time_ = None
            for e2, d2, s2 in _children(buf, d, d + s):
                if e2 == ID_CUETIME:
                    time_ = _uint(buf, d2, s2)
                elif e2 == ID_CUETRACKPOS:
                    tr = cl = rel = dur = None
                    for e3, d3, s3 in _children(buf, d2, d2 + s2):
                        if e3 == ID_CUETRACK:
                            tr = _uint(buf, d3, s3)
                        elif e3 == ID_CUECLUSTER:
                            cl = _uint(buf, d3, s3)
                        elif e3 == ID_CUEREL:
                            rel = _uint(buf, d3, s3)
                        elif e3 == ID_CUEDUR:
                            dur = _uint(buf, d3, s3)
                    if tr == tracknum and cl is not None and time_ is not None:
                        ms = lambda v: None if v is None else int(v * self.scale / 1000000)
                        out.append((ms(time_), cl, rel, ms(dur)))
        return out

    def _block_text(self, buf, pos, end, track, want_tc=None):
        """Cerca nel pezzo letto il blocco della traccia: (testo, durata_ms o None, timecode relativo)"""
        for e, d, s in _children(buf, pos, end):
            if e in (ID_SIMPLEBLOCK, ID_BLOCKGROUP):
                bd, bs, dur = (d, s, None)
                if e == ID_BLOCKGROUP:
                    bd = None
                    for e2, d2, s2 in _children(buf, d, min(d + s, len(buf))):
                        if e2 == ID_BLOCK:
                            bd, bs = d2, s2
                        elif e2 == ID_BLOCKDUR:
                            dur = int(_uint(buf, d2, s2) * self.scale / 1000000)
                    if bd is None:
                        continue
                if bd + 4 > len(buf):
                    return None
                tn, l, _ = _vint(buf, bd)
                tc = struct.unpack(">h", bytes(buf[bd + l:bd + l + 2]))[0]
                if tn == track and (want_tc is None or tc == want_tc):
                    payload = bytes(buf[bd + l + 3:min(bd + bs, len(buf))])
                    return payload, dur, tc
                if want_tc is None:
                    continue
        return None

    def read_track(self, track, workers=5, rounds=3, progress=None, known=None):
        """Frasi della traccia: [{"s", "e", "t"}] (tempi in millisecondi).
        known: frasi già lette in un tentativo precedente ({chiave del punto: frase o None}), non si rileggono.
        Dopo: self.known = tutte quelle lette (da salvare se la lettura non è completa)."""
        t = next((x for x in self.tracks if x["num"] == track), None)
        if not t:
            raise NotSupported("traccia %d non trovata" % track)
        points = self.cue_points(track)
        if not points:
            raise NotSupported("l'indice del file non contiene i sottotitoli")
        self.log("mkv: %d sottotitoli nell'indice della traccia %d" % (len(points), track))
        cluster_hdr = {}
        hdr_len = {}        # lunghezza dell'intestazione dei cluster vista finora → quante volte
        FAIL = object()
        import threading
        count = {"n": 0}
        lock = threading.Lock()
        report = progress or (lambda done, total: None)

        def cluster_data_start(cl):
            if cl not in cluster_hdr:
                b = self.read(self.seg + cl, 12)
                eid, size, hl = _header(b, 0)
                cluster_hdr[cl] = self.seg + cl + hl if eid == ID_CLUSTER else None
                if eid == ID_CLUSTER:
                    with lock:
                        hdr_len[hl] = hdr_len.get(hl, 0) + 1
            return cluster_hdr[cl]

        def direct(cl, rel):
            """Una sola richiesta per frase: l'intestazione del cluster è lunga quasi sempre uguale (5–12 byte),
            quindi leggo dal punto in cui comincerebbe il blocco con l'intestazione più corta e provo le lunghezze
            già viste. Il blocco vale solo se è un blocco della traccia giusta; altrimenti None (→ metodo sicuro)."""
            if not hdr_len:
                return None
            base = self.seg + cl + rel
            buf = self.read(base + 5, 2048 + 7)
            for h in sorted(hdr_len, key=lambda k: -hdr_len[k]):
                o = h - 5
                try:
                    eid, size, hl = _header(buf, o)
                except Exception:
                    continue
                if eid not in (ID_SIMPLEBLOCK, ID_BLOCKGROUP) or size is None or size > 1 << 20:
                    continue
                if o + hl + size > len(buf):
                    b2 = self.read(base + h, hl + size)     # frase lunga: rileggo il blocco intero
                    got = self._block_text(b2, 0, len(b2), track)
                else:
                    got = self._block_text(buf, o, o + hl + size, track)
                if got:
                    return got
            return None

        def one(p):
            r = one_inner(p)
            if r is not FAIL:
                with lock:
                    count["n"] += 1
            return r

        def progress_here():
            # l'avanzamento si comunica SOLO da questo thread (quello che ha chiesto la lettura), mai dai thread
            # che leggono: le chiamate all'interfaccia di Kodi da più thread insieme possono farla bloccare
            try:
                report(count["n"], len(points))
            except Exception as e:
                if type(e).__name__ == "Cancelled":
                    raise           # hai chiesto altro: smetto di leggere

        def one_inner(p):
            ms, cl, rel, cdur = p
            try:
                got = direct(cl, rel) if rel is not None and cl not in cluster_hdr else None
                start = None if got else cluster_data_start(cl)
                if got:
                    pass
                elif start is None:
                    return None
                elif rel is not None:
                    buf = self.read(start + rel, 2048)
                    try:
                        eid, size, hl = _header(buf, 0)
                        if size is not None and hl + size > len(buf) and size < 1 << 20:
                            buf = self.read(start + rel, hl + size)     # frase lunga: rileggo il blocco intero
                    except Exception:
                        pass
                    got = self._block_text(buf, 0, len(buf), track)
                else:
                    buf = self.read(start, 262144)
                    got = self._block_text(buf, 0, len(buf), track)
                if not got:
                    return None
                payload, dur, tc = got
                if t["zlib"]:
                    try:
                        payload = zlib.decompress(payload)
                    except Exception:
                        pass
                text = _clean(payload.decode("utf-8", "replace"), t["codec"])
                if not text:
                    return None
                d = dur or cdur or 0
                return {"s": ms, "e": ms + d if d else None, "t": text}
            except Exception as e:
                if "non più valido" in str(e) or "non permette" in str(e):
                    raise
                return FAIL     # errore di rete: la riprovo dopo

        # le frasi che non arrivano (il server chiude la connessione, risponde troppo piano…) si riprovano,
        # con meno richieste insieme e una pausa sempre più lunga: un sottotitolo non deve mai sparire in silenzio
        key = lambda p: "%s:%s:%s" % (p[0], p[1], p[2])
        known = dict(known or {})
        res = [known[key(p)] for p in points if key(p) in known and known[key(p)]]
        todo = [p for p in points if key(p) not in known]
        if len(todo) < len(points):
            self.log("mkv: %d frasi già lette l'altra volta, ne leggo %d" % (len(points) - len(todo), len(todo)))
            count["n"] = len(points) - len(todo)
        close_all = getattr(self.read, "close_all", lambda: None)
        for rnd in range(rounds):
            close_all()     # connessioni dei giri precedenti chiuse: il server ne conta meno
            if rnd:
                self.log("mkv: %d frasi non lette, riprovo (giro %d)" % (len(todo), rnd + 1))
                time.sleep(2 * rnd)
            from concurrent.futures import wait, FIRST_COMPLETED
            with ThreadPoolExecutor(max_workers=max(2, workers >> rnd)) as ex:
                futs = [ex.submit(one, p_) for p_ in todo]
                pending = set(futs)
                try:
                    while pending:
                        done_, pending = wait(pending, timeout=1.0, return_when=FIRST_COMPLETED)
                        progress_here()
                except BaseException:
                    for f in pending:
                        f.cancel()
                    raise
                got = [f.result() for f in futs]
            for p_, r in zip(todo, got):
                if r is not FAIL:
                    known[key(p_)] = dict(r) if r else None
            res += [r for r in got if r and r is not FAIL]
            todo = [p for p, r in zip(todo, got) if r is FAIL]
            if not todo:
                break
        self.total, self.missing, self.known = len(points), len(todo), known
        if todo:
            self.log("mkv: %d frasi su %d non lette dopo %d giri" % (len(todo), len(points), rounds))
        res.sort(key=lambda c: c["s"])
        for i, c in enumerate(res):
            if not c["e"]:
                nxt = res[i + 1]["s"] if i + 1 < len(res) else c["s"] + 4000
                c["e"] = min(c["s"] + max(1200, 60 * len(c["t"])), nxt - 50) if nxt > c["s"] + 300 else c["s"] + 1500
        return res


def _clean(text, codec):
    if codec in ("S_TEXT/ASS", "S_TEXT/SSA", "S_ASS", "S_SSA"):
        parts = text.split(",", 8)
        text = parts[8] if len(parts) > 8 else text
        text = re.sub(r"\{[^}]*\}", "", text).replace("\\N", " ").replace("\\n", " ")
    text = re.sub(r"<[^>]+>", "", text)
    return re.sub(r"\s+", " ", text).strip()

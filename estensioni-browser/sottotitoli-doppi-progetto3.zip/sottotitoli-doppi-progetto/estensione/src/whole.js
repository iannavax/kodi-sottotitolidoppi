// Trascrizione di un file audio/video intero con Whisper (Groq o server locale).
// Usata dalla pagina "Trascrizione e traduzione" e dalla modalità "Completa" sul video.
//
// I file vengono divisi in pezzi da circa 3 minuti, tagliati nei silenzi, perché:
//  - Whisper sceglie la lingua dai primi secondi e poi la usa per tutto: con pezzi piccoli,
//    se il video cambia lingua, ogni pezzo viene trascritto nella sua;
//  - sui file lunghi Whisper a volte salta interi minuti dopo una musica o un silenzio;
//  - i sottotitoli arrivano man mano, cominciando dal punto in cui stai guardando.
// Solo i file brevi (fino a 2 minuti e mezzo) vanno in un'unica richiesta.
var DS_WHOLE = (() => {
  const GROQ_MAX = 24 * 1024 * 1024;   // limite di Groq per un singolo file (gratuito: 25 MB)
  const PIECE = 16000 * 180;           // pezzi da 3 minuti (16 kHz)
  const SINGLE_MAX_SEC = 150;          // sotto questa durata basta una richiesta
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const MIME = { mp3: "audio/mpeg", m4a: "audio/mp4", mp4: "video/mp4", webm: "audio/webm", weba: "audio/webm", opus: "audio/ogg",
    ogg: "audio/ogg", wav: "audio/wav", flac: "audio/flac", mpeg: "video/mpeg", mpg: "video/mpeg", mov: "video/quicktime", mkv: "video/x-matroska", aac: "audio/aac" };

  function mimeFor(name, blob) {
    const ext = String(name || "").split(".").pop().toLowerCase();
    return (blob && blob.type) || MIME[ext] || "application/octet-stream";
  }

  function toBase64(blob) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(",")[1] || "");
      r.onerror = () => rej(r.error);
      r.readAsDataURL(blob);
    });
  }

  function mapLang(l) {
    const x = String(l || "").toLowerCase();
    return DS_CONFIG.WHISPER_LANGS[x] || (x.length <= 3 ? x : "");
  }

  async function request(blob, filename, prompt, language, s, onStatus, valid) {
    for (let attempt = 0; attempt < 4; attempt++) {
      if (!valid()) throw new Error("annullato");
      const r = await DS_EXT.runtime.sendMessage({
        type: "transcribe", audio: await toBase64(blob), mime: mimeFor(filename, blob), filename,
        stt: s.stt, key: (s.keys && s.keys.groq) || "", model: s.sttModel, url: s.sttUrl, language, prompt
      });
      if (r && r.rateLimited) {
        const err = String(r.error || "");
        const lim = Number((err.match(/Limit:?\s*(\d+)/i) || [])[1]) || 0;
        const hours = lim ? ` (${String(Math.round((lim / 3600) * 10) / 10).replace(".", ",")} ore di audio)` : "";
        const mins = (sec) => { const m = Math.ceil(sec / 60); return m >= 60 ? `${Math.floor(m / 60)} ore e ${m % 60} minuti` : `${m} minut${m === 1 ? "o" : "i"}`; };
        // quota del giorno o dell'ora finita: non serve aspettare qui, lo dico subito
        if (r.daily) throw quotaError(`Groq: hai finito i minuti di trascrizione gratuiti di oggi${hours}. ` +
          (r.retryAfter ? `Si libera di nuovo tra circa ${mins(r.retryAfter)}.` : "Si libera poco a poco nelle prossime ore."));
        if (r.hourly || r.retryAfter > 120) throw quotaError(`Groq: hai raggiunto il limite di audio trascritto in un'ora${hours}. ` +
          `Riprova tra ${mins(r.retryAfter || 3600)}.`);
        const wait = Math.min(Math.max(r.retryAfter || 0, 5), 120);
        onStatus(`Groq: limite di richieste raggiunto, riprovo tra ${wait} secondi…`);
        await sleep(wait * 1000);
        continue;
      }
      if (!r || r.error) throw new Error((r && r.error) || "nessuna risposta");
      return r;
    }
    throw quotaError("Groq continua a rifiutare le richieste: riprova più tardi.");
  }

  function quotaError(message) {
    const e = new Error(message);
    e.quota = true;
    return e;
  }

  function clean(segments, offsetMs, words) {
    const recent = [];
    const good = (segments || []).filter((s) => {
      const junk = DualSubs.isJunk(s, recent.slice(-4));
      if (!junk) recent.push(String(s.text || "").trim());
      return !junk;
    });
    const out = [];
    for (const c of DualSubs.fromWhisper(good, words || [], offsetMs, 1)) {
      const prev = out[out.length - 1];
      if (prev && prev.text === c.text) continue;
      out.push({ start: c.start, end: c.end, text: c.text, trans: "" });
    }
    return out;
  }

  function wav(pcm) {
    const buf = new ArrayBuffer(44 + pcm.length * 2);
    const v = new DataView(buf);
    const str = (o, t) => { for (let i = 0; i < t.length; i++) v.setUint8(o + i, t.charCodeAt(i)); };
    str(0, "RIFF"); v.setUint32(4, 36 + pcm.length * 2, true); str(8, "WAVE"); str(12, "fmt ");
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, 16000, true);
    v.setUint32(28, 32000, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); str(36, "data"); v.setUint32(40, pcm.length * 2, true);
    for (let i = 0; i < pcm.length; i++) { const x = Math.max(-1, Math.min(1, pcm[i])); v.setInt16(44 + i * 2, x < 0 ? x * 0x8000 : x * 0x7fff, true); }
    return new Blob([buf], { type: "audio/wav" });
  }

  // Punto più silenzioso negli ultimi 20 secondi prima del limite: lì taglio il pezzo
  function cutPoint(pcm, from, to) {
    const win = 1600;
    let best = to, bestE = Infinity;
    for (let i = Math.max(from, to - 16000 * 20); i + win <= to; i += win) {
      let e = 0;
      for (let j = i; j < i + win; j++) e += pcm[j] * pcm[j];
      if (e < bestE) { bestE = e; best = i + win / 2; }
    }
    return Math.floor(best);
  }

  async function decode(blob) {
    const ac = new OfflineAudioContext(1, 16000, 16000);
    const audio = await ac.decodeAudioData(await blob.arrayBuffer());
    const n = audio.length;
    const pcm = new Float32Array(n);
    for (let ch = 0; ch < audio.numberOfChannels; ch++) {
      const d = audio.getChannelData(ch);
      for (let i = 0; i < n; i++) pcm[i] += d[i] / audio.numberOfChannels;
    }
    return pcm;
  }

  // opts: { settings, language, durationSec, startAtSec, onProgress(pct, text), onPiece(cues, [startMs, endMs]), isValid() }
  async function transcribe(blob, filename, opts) {
    const s = opts.settings;
    const onProgress = opts.onProgress || (() => {});
    const onPiece = opts.onPiece || (() => {});
    const valid = opts.isValid || (() => true);
    const status = (t) => onProgress(null, t);
    const forced = opts.language || s.sttLang || "";

    const single = async () => {
      onProgress(60, `Trascrivo tutto il file (${(blob.size / 1048576).toFixed(1)} MB)…`);
      const r = await request(blob, filename, "", forced, s, status, valid);
      const cues = clean(r.segments, 0, r.words);
      onPiece(cues, [0, (opts.durationSec || 1e7) * 1000]);
      return { cues, lang: mapLang(r.language) || forced };
    };

    // File breve (o server sul computer, senza limiti di dimensione): una sola richiesta
    const short = opts.durationSec && opts.durationSec <= SINGLE_MAX_SEC;
    if ((short && blob.size <= GROQ_MAX) || s.stt === "local") return single();

    onProgress(50, "Preparo l'audio…");
    let pcm;
    try {
      pcm = await decode(blob);
    } catch {
      // il browser non sa leggere questo formato: se il file è piccolo lo mando così com'è
      if (blob.size > GROQ_MAX) throw new Error("il browser non riesce a leggere l'audio di questo file (formato non supportato o file troppo grande)");
      return single();
    }
    if (pcm.length <= SINGLE_MAX_SEC * 16000 && blob.size <= GROQ_MAX) return single();

    // Pezzi da ~3 minuti tagliati nei silenzi
    const pieces = [];
    for (let pos = 0; pos < pcm.length;) {
      const end = pos + PIECE >= pcm.length ? pcm.length : cutPoint(pcm, pos, pos + PIECE);
      pieces.push([pos, end]);
      pos = end;
    }
    // Prima il pezzo in cui sei, poi quelli dopo, poi quelli prima
    const at = Math.max(0, (opts.startAtSec || 0) * 16000);
    let k = pieces.findIndex(([a, b]) => at >= a && at < b);
    if (k < 0) k = 0;
    const order = [...pieces.slice(k), ...pieces.slice(0, k).reverse()];

    // Lingua: si stabilisce una volta sola (dal primo pezzo con abbastanza parlato) e poi viene imposta a Whisper
    // per tutti i pezzi: senza, Whisper a volte cambia lingua o scrive la traduzione in inglese invece di trascrivere
    let dom = forced;
    const all = [];
    let done = 0;
    const text = (r) => (r.segments || []).map((x) => x.text || "").join(" ");
    for (const [a, b] of order) {
      done++;
      onProgress(55 + Math.round((40 * (done - 1)) / order.length), `Trascrivo il pezzo ${done} di ${order.length}…`);
      const audio = wav(pcm.subarray(a, b));
      const prev = all.filter((c) => c.end <= (a / 16000) * 1000).slice(-4).map((c) => c.text).join(" ");
      let r = await request(audio, `parte-${done}.wav`, prev, dom, s, status, valid);
      let det = dom || mapLang(r.language);
      if (!dom && det && text(r).trim().length >= 150) {
        dom = det;
        // ha scritto in una lingua diversa da quella riconosciuta: rifaccio imponendola
        const g = DualSubs.guessLang(text(r));
        if (g && g !== det) r = await request(audio, `parte-${done}.wav`, "", dom, s, status, valid);
      }
      // testo in inglese in un video non inglese = Whisper ha tradotto: rifaccio senza il testo precedente come suggerimento
      // testo in un'altra lingua o alfabeto: riprovo senza suggerimento, poi con il modello migliore; se resta
      // sbagliato il pezzo lo salto (meglio un buco che la traduzione inglese al posto della trascrizione)
      if (dom && DualSubs.wrongLang(text(r), dom)) {
        let ok = null;
        for (const model of s.stt === "local" ? [s.sttModel] : [s.sttModel, "whisper-large-v3"]) {
          const again = await request(audio, `parte-${done}.wav`, "", dom, { ...s, sttModel: model }, status, valid);
          if (!DualSubs.wrongLang(text(again), dom)) { ok = again; break; }
        }
        if (!ok) { status(`Il pezzo ${done} veniva scritto in un'altra lingua: l'ho saltato.`); onPiece([], [(a / 16000) * 1000, (b / 16000) * 1000]); continue; }
        r = ok;
      }
      const cues = clean(r.segments, (a / 16000) * 1000, r.words);
      cues.forEach((c) => { c.lang = det || dom; });
      all.push(...cues);
      all.sort((x, y) => x.start - y.start);
      onPiece(cues, [(a / 16000) * 1000, (b / 16000) * 1000]);
    }
    return { cues: all, lang: dom };
  }

  return { transcribe, mimeFor, GROQ_MAX };
})();

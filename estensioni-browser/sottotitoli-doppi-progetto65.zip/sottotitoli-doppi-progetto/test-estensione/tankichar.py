# 1.7.7: kanji/hanzi/hanja in un sottomazzo a parte + spostamento di quelli già in Anki (e annullamento)
import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
E = lambda w, lang: {"id": lang + "|" + w, "word": w, "lang": lang, "lemma": "", "pos": "", "meaning": "significato", "explanation": "", "ipa": "", "sentence": "", "sentenceTrans": "", "etym": "", "added": 1}
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({ankiAudio:false, ankiPerLang:true, ankiLangDeck:'Lingue::{lingua}'})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1000)
        decks = lambda: {n["Fronte"][:0] + str(i): n.get("deck") for i, n in log.get("anki_notes", {}).items()}
        def by_word():
            out = {}
            for n in log.get("anki_notes", {}).values():
                import re
                m = re.search(r'data-f="word"[^>]*>([^<]+)<', n["Fronte"]); out[(m.group(1) if m else n["Fronte"][:12]).strip()] = n.get("deck")
            return out
        r = await pp.evaluate("(es) => chrome.runtime.sendMessage({type:'ankiAdd', entries: es})", [E("勉", "ja"), E("勉強", "ja"), E("学", "zh"), E("한", "ko"), E("本", "ja")])
        print("1. nuove carte:", json.dumps(by_word(), ensure_ascii=False), "| errori:", r.get("errors"))
        ok1 = by_word().get("勉") == "Lingue::Giapponese::Kanji" and by_word().get("勉強") == "Lingue::Giapponese" and by_word().get("学") == "Lingue::Cinese::Hanzi" and by_word().get("本") == "Lingue::Giapponese::Kanji"
        # vecchio comportamento: sottomazzo spento → mazzo della lingua; poi lo sposto
        await sw.evaluate("chrome.storage.sync.set({ankiCharDeck:false})")
        await pp.evaluate("(es) => chrome.runtime.sendMessage({type:'ankiAdd', entries: es})", [E("強", "ja"), E("語", "zh")])
        print("2. con il sottomazzo spento:", json.dumps({k: v for k, v in by_word().items() if k in ("強", "語")}, ensure_ascii=False))
        await sw.evaluate("chrome.storage.sync.set({ankiCharDeck:true})")
        d = await pp.evaluate("chrome.runtime.sendMessage({type:'ankiMoveChars', dry:true})")
        print("3. conteggio (senza spostare):", d)
        m = await pp.evaluate("chrome.runtime.sendMessage({type:'ankiMoveChars'})")
        print("4. spostate:", m, "|", json.dumps({k: v for k, v in by_word().items() if k in ("強", "語")}, ensure_ascii=False))
        u = await pp.evaluate("chrome.runtime.sendMessage({type:'ankiMoveUndo'})")
        print("5. annullato:", u, "|", json.dumps({k: v for k, v in by_word().items() if k in ("強", "語")}, ensure_ascii=False))
        ok = ok1 and d.get("found", 0) >= 2 and d.get("moved") == 0 and m.get("moved") == 2 and by_word().get("強") == "Lingue::Giapponese" and u.get("restored") == 2
        # popup: casella e pulsanti
        await pp.reload(); await pp.wait_for_timeout(1000)
        await pp.evaluate("document.getElementById('dAnki').open=true")
        print("6. popup: casella", await pp.is_checked("#ankiCharDeck"), "| pulsante", await pp.is_visible("#ankiMoveChars"))
        print("errori:", errs if ok else errs + ["sottomazzo dei caratteri non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

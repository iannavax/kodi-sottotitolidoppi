## Dove funziona

- **YouTube**, come prima.
- **Qualsiasi sito con un video o un audio**, per esempio Vimeo, VK, siti di notizie, podcast e corsi online. Se il video ha già dei sottotitoli propri, li usa e li traduce. Se non li ha, apri il popup e premi **Trascrivi l'audio di questo video**.
- **File aperti direttamente nel browser**, da un link o dal computer: mp4, webm, mp3, m4a, ogg, wav, flac e gli altri formati che il browser sa riprodurre. Qui la trascrizione parte da sola appena premi Play.
- **Siti con contenuti protetti** (Netflix, Disney+, Prime Video e simili): il browser non permette alle estensioni di ascoltarne l'audio. Se provi, la riga di stato te lo dice.
- Se su un sito l'estensione dà fastidio, nel popup, sezione **Altro**, togli **Attiva su** quel sito.
- Nel popup trovi anche **Carica sottotitoli da file (.srt, .vtt)** dentro la pagina della trascrizione: utile per i film scaricati con i sottotitoli a parte.

## Trascrizione e traduzione (pagina completa)

Dal popup, **Trascrizione e traduzione** apre una pagina con tutto il testo del video:
- **Testo unico**, da leggere e copiare, con l'originale e la traduzione paragrafo per paragrafo, oppure solo uno dei due. C'è anche la vista **frase per frase con i tempi**.
- **Copia il testo**, oppure scaricalo come .txt, o come sottotitoli .srt: originali, tradotti, o doppi (originale e traduzione insieme).
- **Trascrivere un file intero:** tutto il file in una volta, senza doverlo guardare. Puoi usare il file del video aperto nella scheda, se il sito permette di scaricarlo, oppure un file dal computer. I file fino a 24 MB vanno a Groq in un'unica richiesta. Quelli più grandi vengono divisi in pezzi da 8 minuti, tagliati nei silenzi. Il risultato compare anche sul video.
- **Rifai la traduzione** e **Rifai la trascrizione:** se qualcosa è venuto male, cancellano quello che è salvato per quel video e lo rifanno.

Si può aprire anche senza nessun video: scegli un file dal computer e ottieni trascrizione e traduzione da copiare o scaricare.

## Aspetto dei sottotitoli

Nel popup, sezione **Aspetto dei sottotitoli**, puoi scegliere:
- cosa mostrare: entrambe le righe, solo l'originale o solo la traduzione;
- la traduzione sopra o sotto l'originale;
- la dimensione del testo e quella della traduzione;
- i colori delle due righe e quanto è scuro lo sfondo;
- l'altezza sul video e il carattere.

Le modifiche si vedono subito sul video. **Ripristina l'aspetto predefinito** rimette tutto com'era.

## Correzioni di questa versione

- **Pausa a metà parola:** il pezzo di audio non viene più chiuso quando metti in pausa, ma continua quando riparti. Tornando indietro o andando avanti, l'audio viene tagliato solo in una pausa del parlato, e la parte interrotta verrà trascritta di nuovo.
- **Traduzione uguale all'originale:** Whisper, su pezzi brevi, a volte sbagliava lingua e scriveva direttamente in italiano. Ora, dopo i primi pezzi, la lingua del video viene bloccata e i pezzi venuti nella lingua sbagliata vengono rifatti. Inoltre una "traduzione" identica all'originale viene riconosciuta: non viene salvata e viene sostituita con quella di Google. Anche le traduzioni sbagliate salvate dalle versioni precedenti vengono scartate da sole.
- **Numeri "1. 2. 3." davanti alle traduzioni:** le frasi vengono mandate al modello in un formato che non usa numeri, e gli eventuali numeri vengono tolti.
- **"Risposta del modello non leggibile":** ora la risposta viene letta anche se è troncata o sporca. Se proprio non si legge, il pezzo viene diviso e riprovato, o tradotto da Google, e si va avanti invece di fermarsi.
- **Parole non tradotte al passaggio del mouse:** se Google restituisce la parola uguale, riprova lasciandogli riconoscere la lingua. Se ancora non la traduce (succede con nomi ed espressioni), te lo dice e il clic dà la spiegazione nel contesto.

## Parole interattive

- **Passa il mouse su una parola** dei sottotitoli originali: il video si mette in pausa e dopo un attimo compare una scheda. Contiene il significato *in quella frase*, la forma base (per esempio "went" → "go"), il tipo di parola, una spiegazione quando serve e un esempio.
- **Clicca la parola** per fissare la scheda, così non sparisce quando sposti il mouse. Si chiude con × o con Esc.
- 🔊 fa sentire la pronuncia nella lingua della parola (la sigla accanto, per esempio ES, indica quale). **↺ Riascolta la frase** riporta il video all'inizio della frase e lo ferma alla fine.
- Quando sposti il mouse via dai sottotitoli, il video riparte da solo. Se preferisci che non si fermi, togli "Pausa quando passi sulle parole" nel popup.
- Passando il mouse vedi subito il significato dal dizionario di Google, che è gratis e non consuma richieste. **Cliccando** la parola ottieni la spiegazione nel contesto della frase con il servizio che hai scelto (Gemini, Groq, Claude o un modello locale). È una richiesta sola, e solo quando la vuoi davvero.

## Pronuncia

La lingua viene presa in automatico dalla parola o dal video. Per la voce, l'estensione usa quella del computer per quella lingua, preferendo le voci "Natural" di Edge. Se sul computer manca una voce per quella lingua, cosa frequente con Firefox su Windows, usa la voce online di Google, che le ha tutte.

Nel popup, alla voce **Pronuncia delle parole**, puoi:
- scegliere la **lingua** a mano (utile se il video mescola lingue o se quella rilevata è sbagliata);
- scegliere la **voce**: automatica, sempre quella di Google, oppure una voce precisa installata sul computer;
- premere **Prova la voce** per sentire come suona.

## Vocabolario personale

- Nella scheda di una parola premi la **stella ☆** per salvarla, insieme alla frase, alla traduzione e al punto del video.
- Le parole salvate compaiono **in azzurro sottolineate** nei sottotitoli di tutti i video.
- Dal popup, **Il mio vocabolario** apre la lista. Da lì puoi cercare, riaprire il video nel punto giusto, segnare una parola come imparata (smette di essere evidenziata) o eliminarla.
- **Esporta per Anki** scarica un file di testo. In Anki: File → Importa → scegli il file. Il tipo di nota "Base" va bene: sul fronte trovi la parola con la frase, sul retro il significato, la traduzione e il link al video.

## Video senza sottotitoli: trascrizione dell'audio

Se un video non ha nessun sottotitolo, nemmeno automatico, l'estensione ascolta l'audio e lo trascrive con Whisper. Le frasi trascritte vengono tradotte e compaiono nella solita doppia riga, e anche le loro parole sono interattive.

**Preparazione (una volta sola):** crea una chiave gratuita su console.groq.com/keys, senza carta. Incollala nel popup, nella sezione "Video senza sottotitoli", e premi Invio.

**Come funziona:**
- L'audio viene registrato senza interruzioni e tagliato nelle pause del parlato, così le frasi non vengono spezzate a metà e non si perdono pezzi.
- Le frasi arrivano con qualche secondo di ritardo. L'ultima frase resta visibile finché non arriva la successiva. Se torni indietro, le rivedi perfettamente sincronizzate.
- La traduzione compare subito in una versione rapida di Google, un po' trasparente. Poi viene sostituita da quella contestuale del servizio che hai scelto, per esempio Gemini. Se il servizio è lento, le frasi arretrate vengono tradotte tutte insieme.
- Se Groq segnala di aver raggiunto il limite di richieste, l'estensione aspetta e riprova, senza saltare pezzi.
- Se il video è in una lingua sola, impostare "Lingua parlata" rende la trascrizione più stabile.
- **Firefox:** per catturare l'audio Firefox deve ammutolire il video, e l'estensione lo rimanda subito alle casse. Se non senti l'audio o la trascrizione non parte, clicca una volta sul video.

**Trascrivere sul tuo computer invece che con Groq:** serve un server Whisper compatibile con l'API di OpenAI, per esempio Speaches. Nel popup scegli "Server sul tuo computer", scrivi l'indirizzo (di solito `http://localhost:8000/v1`) e il nome del modello.

## Se vedi "limite di richieste raggiunto"

Non è un problema di connessione: significa che il servizio ha ricevuto la richiesta e l'ha rifiutata perché hai superato la quota gratuita. I servizi gratuiti hanno due limiti:

- **Al minuto:** l'estensione distanzia da sola le richieste, anche tra più schede aperte. Se il servizio rifiuta comunque, aspetta e riprova. Le traduzioni già fatte sono salvate man mano, quindi non si perde niente.
- **Al giorno:** quando è esaurito, l'estensione te lo dice chiaramente e continua con Google Traduttore. Il limite di Gemini si azzera verso le 9 del mattino, ora italiana.

Per consumare meno:
- Con Gemini il modello predefinito è **gemini-flash-lite-latest**, quello con più richieste gratuite al giorno. Punta sempre all'ultima versione di Flash-Lite, quindi non va aggiornato a mano.
- Riguardare un video non costa nuove richieste: le traduzioni e le trascrizioni restano salvate, anche se l'avevi guardato solo in parte.
- Quanto hai usato lo vedi su Google AI Studio (aistudio.google.com), nella sezione sull'utilizzo.


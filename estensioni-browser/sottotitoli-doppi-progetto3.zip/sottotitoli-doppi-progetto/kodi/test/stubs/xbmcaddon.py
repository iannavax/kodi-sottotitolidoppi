import os
SETTINGS = {}
PROFILE = "/tmp/kodi-profile/"
class Addon:
    def __init__(self, addon_id=None): self.id = addon_id
    def getSetting(self, k): return SETTINGS.get(k, "")
    def getAddonInfo(self, k): return {"name": "Sottotitoli Doppi", "icon": "icon.png", "profile": PROFILE, "path": "/home/claude/kodi/script.sottotitolidoppi"}[k]
    def openSettings(self): pass
    def setSetting(self, k, v): SETTINGS[k] = v

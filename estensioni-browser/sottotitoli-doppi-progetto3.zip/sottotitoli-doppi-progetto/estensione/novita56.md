## Novità della 5.6.5: vedere e copiare le chiavi

Accanto alle caselle delle chiavi nel popup (quella del servizio di traduzione e la **Chiave Groq** in "Video senza sottotitoli") ci sono due pulsanti:
- **Mostra** fa vedere la chiave al posto dei puntini (premi **Nascondi** per coprirla di nuovo);
- **Copia** la copia negli appunti, così puoi incollarla altrove (per esempio nella configurazione dell'add-on per Stremio o in Kodi).

Attenzione: chi vede la chiave la può usare a tuo nome, quindi non mostrarla in video o in foto.

## Novità della 5.6.4: "Ritrascrivi" si ferma quando ha finito

- **🎙 Ritrascrivi** su una frase già salvata (quando il suo audio non è più in memoria) fa tornare il video all'inizio della frase e la riascolta. Prima, dopo averla rifatta, la trascrizione restava accesa e continuava a ritrascrivere con il modello più lento. Ora, appena la frase è rifatta, **si ferma e torni alla trascrizione già fatta** (il popup scrive "Frase ritrascritta"). Se nel frattempo sposti il video altrove, la richiesta viene annullata.
- Corretto un errore della 5.6.3: in alcuni casi l'estensione ricollegava l'audio di continuo, e questo poteva spezzare la trascrizione in pezzi più corti del dovuto.

## Novità della 5.6.3: la trascrizione non si ferma più da sola

- **Trascrizione che si fermava dopo qualche minuto.** YouTube a volte cambia la "sorgente" del video mentre guardi (quando cambia la qualità, dopo una pubblicità…). L'audio che l'estensione ascoltava si interrompeva e la trascrizione restava muta, senza avvisare. Ora se ne accorge e riprende ad ascoltare da sola.
- **Video con sottotitoli sbagliati** (per esempio i sottotitoli automatici in portoghese su un video in ceco): se avvii tu la trascrizione dal popup, la scelta viene **ricordata per quel video**. Riaprendolo, la trascrizione riparte da sola e non tornano i sottotitoli sbagliati. Premendo "Ferma la trascrizione" tornano quelli di YouTube.
- **"Rifai la trascrizione"** (pagina Trascrizione e traduzione) ora riparte subito, anche se la trascrizione era ferma. Prima cancellava la vecchia trascrizione e poi non ripartiva.
- **Limiti di Groq spiegati meglio.** Groq gratis permette un certo numero di ore di audio all'ora e al giorno (il numero esatto lo dice Groq nel messaggio). Se finisce la quota **dell'ora**, il popup dice tra quanto riprende e la trascrizione riparte da sola. Se finisce quella **del giorno**, la trascrizione si ferma con un messaggio chiaro, invece di riprovare all'infinito.

Nota: il pulsante **🎙 Ritrascrivi** nella scheda di una frase rifà **solo quella frase** (per questo vengono poche parole). Per rifare tutto il video usa "Rifai la trascrizione" nella pagina Trascrizione e traduzione.

## Novità della 5.6.2: tutte le lingue anche per la pronuncia

Anche **Pronuncia delle parole → Lingua** ora ha tutte le 98 lingue, con la stessa casella di ricerca della lingua parlata.

- Se il computer ha una voce per quella lingua viene usata quella; altrimenti la voce online di Google. Sotto il menu compare un avviso se una lingua non ha voce né sul computer né su Google (per esempio alcune lingue rare): in quel caso puoi aggiungere una voce in Windows (**Impostazioni → Ora e lingua → Voce**).
- "Prova la voce" funziona con ogni lingua: per quelle senza una frase di prova pronuncia il nome della lingua.
- Ora vengono riconosciute anche le voci di Windows con codici diversi per la stessa lingua (per esempio il norvegese "nb-NO").

## Novità della 5.6.1: tutte le lingue per la trascrizione

In **Video senza sottotitoli → Lingua parlata** ora ci sono **tutte le 98 lingue** che Whisper sa trascrivere (prima erano 17), con i nomi in italiano e nella lingua originale (per esempio "Norvegese · norsk").

- Sopra l'elenco c'è una **casella di ricerca**: scrivi una parte del nome (in italiano, in inglese o nella lingua stessa, oppure il codice come "cs") e l'elenco mostra solo le lingue che corrispondono. Premi **Invio** per scegliere la prima, oppure clicca quella che vuoi.
- Accanto a "Lingua parlata" vedi sempre quella scelta. "Rileva da sola" resta la scelta predefinita e va bene nella maggior parte dei casi: conviene indicare la lingua solo se Whisper la sbaglia.

## Novità della 5.6: modi di dire e trascrizione più corretta

### Modi di dire ed espressioni di più parole
Alcune espressioni non si traducono parola per parola ("break the ice", "give up", "tomar el pelo"). Ora l'estensione le tratta come un blocco unico.

- **Sottolineate da sole** (con Gemini, Groq, Claude o un modello locale): quando ti fermi con il mouse sulle parole della riga originale, dopo un attimo l'estensione chiede al modello i modi di dire di quella frase. Le espressioni trovate vengono **sottolineate con un'onda arancione**. Passandoci sopra **si illumina tutta l'espressione** e la scheda mostra il suo significato vero, senza altre richieste. **Cliccando** arriva la spiegazione completa nel contesto. Nella scheda c'è anche "Solo la parola …", se ti serve il significato della singola parola.
- La richiesta è **una sola per frase** ed è la stessa che allinea la traduzione con l'originale (quella della 5.5): se poi passi sulle parole tradotte, non ne parte un'altra. Parte solo se ti fermi sulle parole: se passi sopra per andare al pulsante delle correzioni, non consuma niente.
- **Selezione a mano** (funziona anche con Google, gratis): **tieni premuto sulla prima parola e trascina fino all'ultima**. Le parole diventano verdi e si apre la scheda con la traduzione dell'**espressione intera**. Con un modello, la spiegazione è nel contesto della frase.
- Anche cliccando una singola parola, se il modello si accorge che fa parte di un modo di dire, la scheda lo dice ("Modo di dire: «…» = …") e l'espressione viene sottolineata nella frase.
- Le espressioni si possono salvare nel **vocabolario** con la stellina, come le parole.
- Si può spegnere in **Altro → Evidenzia i modi di dire**. La selezione a mano resta sempre disponibile.

### Trascrizione corretta da Gemini
Whisper a volte capisce male le parole, sbaglia le desinenze o salta articoli e preposizioni. Ora le frasi trascritte vengono **corrette** (parole capite male, grammatica, punteggiatura, nomi) prima di essere tradotte, senza riscrivere il senso.

- **Se traduci con Gemini, Groq, Claude o un modello locale**: la correzione si fa già nella stessa richiesta della traduzione (nessuna richiesta in più). Le regole di correzione ora sono più decise: prima correggeva quasi solo la punteggiatura.
- **Se traduci con Google o DeepL**: la correzione la fa **Gemini** se hai inserito la chiave Gemini, altrimenti **Groq** (la stessa chiave della trascrizione). Le frasi vengono corrette **a gruppi** (una richiesta ogni 10-30 frasi, non una per frase): intanto vedi subito la traduzione rapida, che dopo pochi secondi viene rifatta sul testo corretto.
- Una correzione viene accettata solo se la frase resta riconoscibile: il modello non può inventare frasi diverse.
- Se Gemini (o Groq) finisce le richieste gratuite del giorno, la correzione si sospende da sola e la traduzione continua normalmente.
- Si può spegnere in **Video senza sottotitoli → Correggi la grammatica della trascrizione**; sotto la casella c'è scritto chi la fa e quante richieste usa.


// Trascrizione dell'audio per i video senza sottotitoli.
// L'audio viene registrato in continuo (nessun buco tra un pezzo e l'altro) e tagliato
// nelle pause del parlato, così le frasi non vengono spezzate a metà.
// Usa: settings, setStatus, askTranslate, liveEngine, baseLang, sleep, currentVideoId, getVideo (da content.js)

const LIVE_MIN_MS = 3500;    // un pezzo si chiude in una pausa solo dopo almeno 3,5 s
const LIVE_MAX_MS = 9000;    // oltre 9 s si taglia comunque, nel punto più silenzioso (prima 14 s: le frasi arrivavano 4-5 alla volta e in ritardo)
const LIVE_QUIET_MS = 350;   // durata di una pausa che chiude il pezzo
const LIVE_RATE = 16000;     // Whisper lavora a 16 kHz
// Frasi che Whisper "inventa" spesso durante musica o silenzio
const LIVE_HALLUCINATION = /(sottotitoli (creati|a cura)|amara\.org|thanks? (you )?for watching|grazie (per|della) (la )?visione|iscriviti al canale|subtitles by|please subscribe|продолжение следует|ご視聴ありがとう)/i;

// ---------- Registro della diretta (popup → «📋 Copia il registro»): cosa è successo, per capire i problemi ----------
const dsLiveLogBuf = [];
function dsLiveLog(text) {
  try {
    const v = typeof live !== "undefined" && live.el;
    const line = new Date().toTimeString().slice(0, 8) + (v ? " [video " + v.currentTime.toFixed(1) + " s" + (v.paused ? ", fermo" : "") + "]" : "") + " " + text;
    if (dsLiveLogBuf.length && dsLiveLogBuf[dsLiveLogBuf.length - 1].endsWith("] " + text)) return;
    dsLiveLogBuf.push(line);
    if (dsLiveLogBuf.length > 500) dsLiveLogBuf.splice(0, dsLiveLogBuf.length - 500);
  } catch {}
}

const live = {
  running: false, videoId: null, gen: 0, el: null, audio: null,
  frames: [], framesMs: 0,
  cues: [], covered: [],
  queue: [], busy: false, errors: 0, lastText: "", lang: "",
  pendingTr: [], retry: [], trBusy: false, llmBlocked: false,
  redo: [],          // parti da ritrascrivere perché segnalate come sbagliate
  recentItems: [],   // ultimi pezzi di audio tenuti in memoria (per ritrascrivere subito)
  saveTimer: 0, dirty: false, loadedFor: null,
  full: false, votes: {}, domLang: "", lockLang: "", switchTo: "", switchCount: 0, zeroMs: 0, silentWarned: false, autoTried: null,
  fullBusy: false, fullText: "", fullGen: 0, modes: {}
};

// Modalità di trascrizione scelte per i singoli video (le altre seguono quella predefinita)
DS_EXT.storage.local.get({ modes: {} }).then((r) => { live.modes = r.modes || {}; });
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.modes) live.modes = ch.modes.newValue || {}; });

function liveModeFor(v) {
  return live.modes[v] || (settings.autoTranscribe === false ? "off" : settings.transcribeMode || "live");
}

async function liveSetMode(v, mode) {
  const { modes = {} } = await DS_EXT.storage.local.get({ modes: {} });
  if (mode) modes[v] = mode; else delete modes[v];
  const keys = Object.keys(modes);
  if (keys.length > 400) for (const k of keys.slice(0, keys.length - 400)) delete modes[k];
  live.modes = modes;
  await DS_EXT.storage.local.set({ modes });
}

// La modalità predefinita è cambiata (o per questo video hai scelto "Come quella predefinita"):
// la applico subito, senza ricaricare la pagina
function liveApplyDefault(v) {
  const mode = liveModeFor(v);
  if (mode === "off") { live.fullGen++; live.fullBusy = false; if (live.running) liveStop("Trascrizione spenta."); return; }
  if (mode === "live" && live.running) return;
  if (mode === "full" && (live.fullBusy || (live.full && live.videoId === v))) return;
  liveAutoStart(v);
}

// Il video non ha sottotitoli: decido cosa fare in base alla modalità
function liveAutoStart(v, reason) {
  if (settings && settings.enabled === false) return;   // sottotitoli doppi spenti dal pulsante DS o dal popup
  const mode = liveModeFor(v);
  if (mode === "off") {
    setStatus("Questo video non ha sottotitoli (trascrizione spenta: la puoi avviare dal popup).");
    return;
  }
  if (mode === "full" && dsIsLiveStream(getVideo())) {
    setStatus("È una diretta: non si può scaricare tutta, la trascrivo mentre la guardi.");
    liveStart(false);
    return;
  }
  if (mode === "full") {
    const m = getVideo();
    const tooLong = m && isFinite(m.duration) && m.duration > (Number(settings.fullMaxMin) || 60) * 60 && !live.modes[v];
    if (!tooLong) { liveFull(); return; }
    setStatus(`Il video dura più di ${settings.fullMaxMin} minuti: lo trascrivo mentre lo guardi (per trascriverlo tutto, scegli "Completa" per questo video nel popup).`);
  }
  liveStart(false);
}

function liveState() {
  const v = currentVideoId();
  return { running: live.running, hasCaptions: v ? hasCaptions[v] : undefined, onVideo: !!v,
    mode: v ? live.modes[v] || "" : "", defaultMode: settings ? liveModeFor("__nessuno__") : "live",
    fullBusy: live.fullBusy, fullText: live.fullText, full: live.full && live.videoId === v,
    live: dsIsLiveStream(live.el || getVideo()), yt: DS_IS_YT, aheadOn: !!(settings && settings.liveAhead),
    ahead: typeof aheadInfo === "function" ? aheadInfo() : null };
}

// Lingua parlata scelta a mano per un singolo video (pulsante della lingua accanto ai sottotitoli o ⚑):
// vince su quella del popup e sul riconoscimento automatico. storage.local "videoLang" = { video: sigla }
let dsVideoLang = {};
DS_EXT.storage.local.get({ videoLang: {} }).then((r) => { dsVideoLang = r.videoLang || {}; }).catch(() => {});
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.videoLang) dsVideoLang = ch.videoLang.newValue || {}; });
function dsSttLang(v = live.videoId || currentVideoId()) {
  return (v && dsVideoLang[v]) || (settings && settings.sttLang) || "";
}
async function liveSetVideoLang(code) {
  const v = live.videoId || currentVideoId();
  if (!v) return;
  const map = { ...dsVideoLang };
  if (code) map[v] = code; else delete map[v];
  const keys = Object.keys(map);
  if (keys.length > 500) for (const k of keys.slice(0, keys.length - 500)) delete map[k];
  dsVideoLang = map;
  await DS_EXT.storage.local.set({ videoLang: map });
  live.votes = {}; live.lockLang = code || ""; live.domLang = code || ""; live.lang = code || "";
  await liveRedo("transcript");
  setStatus(code ? `Trascrizione rifatta in ${dsLangName(code)}: da ora questo video si trascrive sempre in questa lingua.`
    : "Lingua di nuovo automatica per questo video: rifaccio la trascrizione.");
}
function dsLangName(code) {
  try { return new Intl.DisplayNames(["it"], { type: "language" }).of(code) || code; } catch { return code; }
}

// Lingua dell'audio secondo i sottotitoli automatici di YouTube (se ci sono): la trascrizione resta sempre in quella
// lingua, anche con "automatica" (prima Whisper a volte passava all'inglese, cioè traduceva, e poi ci restava)
function liveHintLang(v = live.videoId || currentVideoId()) {
  const a = v && typeof dsAsrInfo !== "undefined" ? dsAsrInfo[v] : null;
  return a && a.lang ? a.lang : "";
}
// i sottotitoli automatici di YouTube in quel punto, come suggerimento a Whisper (stessa lingua, parole giuste)
function liveYtPrompt(item) {
  const v = live.videoId || currentVideoId();
  const a = v && typeof dsAsrInfo !== "undefined" ? dsAsrInfo[v] : null;
  if (!a || !a.segments || !item) return "";
  return a.segments.filter((sg) => sg.end > item.s - 15000 && sg.start < item.s).map((sg) => sg.text).join(" ").slice(-300);
}
const liveLangNow = () => dsSttLang() || liveHintLang() || live.lockLang || "";

function liveSourceLang() {
  return dsSttLang() || liveHintLang() || live.domLang || live.lang || "";
}

// ---------- Cattura dell'audio ----------
function liveSetupAudio(video) {
  if (live.audio && !live.audio.stale && live.audio.video === video) return live.audio;
  let src, firefox = false;
  if (typeof video.captureStream === "function") {
    src = video.captureStream(); // Chrome, Edge: il video continua a suonare normalmente
  } else if (typeof video.mozCaptureStream === "function") {
    src = video.mozCaptureStream(); // Firefox: il video si ammutolisce e lo rimando alle casse
    firefox = true;
  } else {
    throw new Error("questo browser non permette di catturare l'audio del video");
  }
  const tracks = src.getAudioTracks();
  if (!tracks.length) return null;
  // Il sito può cambiare la sorgente del video mentre guardi (YouTube lo fa quando cambia qualità,
  // dopo una pubblicità…): la traccia audio catturata finisce e ne arriva un'altra. Allora ricatturo.
  // (solo la fine della traccia audio: "addtrack" scatta anche per la traccia video appena creata
  // e farebbe ricatturare all'infinito)
  const setupAt = Date.now();
  const recapture = () => {
    if (!live.audio || live.audio.src !== src || Date.now() - setupAt < 1000) return;
    live.audio.stale = true;
    if (live.running) setTimeout(() => liveEnsureAudio(), 300);
  };
  tracks.forEach((t) => t.addEventListener("ended", recapture));

  liveTeardownAudio();
  const ctx = new AudioContext();
  const source = ctx.createMediaStreamSource(new MediaStream(tracks));
  if (firefox) source.connect(ctx.destination);
  const proc = ctx.createScriptProcessor(4096, 1, 1);
  const mute = ctx.createGain();
  mute.gain.value = 0;
  source.connect(proc);
  proc.connect(mute);
  mute.connect(ctx.destination);
  proc.onaudioprocess = (e) => liveOnAudio(e.inputBuffer.getChannelData(0), ctx.sampleRate);
  live.audio = { video, ctx, source, proc, firefox, src, stale: false };
  liveResumeAudio();
  return live.audio;
}

function liveTeardownAudio() {
  if (!live.audio) return;
  try { live.audio.proc.onaudioprocess = null; } catch {}
  try { live.audio.ctx.close(); } catch {}
  live.audio = null;
}

function liveResumeAudio() {
  const a = live.audio;
  if (a && a.ctx.state === "suspended") a.ctx.resume().catch(() => {});
}

// Il browser a volte blocca l'audio finché non si clicca sulla pagina
document.addEventListener("click", liveResumeAudio, true);
document.addEventListener("keydown", liveResumeAudio, true);

function liveAttachVideo(video) {
  if (live.el === video) return;
  live.el = video;
  video.addEventListener("playing", () => {
    liveResumeAudio();
    if (live.running) liveEnsureAudio();
  });
  video.addEventListener("seeking", () => { live.seekAt = Date.now(); live.hold = null; live.cues.forEach((c) => { c.late = false; c.availVt = null; }); });
  // nuova sorgente nello stesso lettore: al prossimo "playing" l'audio viene ricatturato
  for (const ev of ["emptied", "loadstart"]) video.addEventListener(ev, () => {
    if (live.audio && live.audio.video === video) live.audio.stale = true;
    // diretta: YouTube ricarica il flusso (rete, buffering, qualità, il nostro salto indietro) e l'orologio del video
    // PUÒ ripartire da un altro punto. Prima qui cancellavo subito tutti i sottotitoli: succedeva spesso e le dirette
    // "si rompevano" (e la diretta sincronizzata perdeva l'allineamento). Ora controllo al prossimo pezzo d'audio se
    // l'orologio è saltato davvero (liveCheckReload); se no, non tocco niente.
    if (live.isLive && live.running) { dsLiveLog("il lettore ha ricaricato il video (" + ev + ")"); live.reloadAt = Date.now(); }
  });
}

function liveEnsureAudio(attempt = 0) {
  const video = live.el;
  if (!live.running || !video) return;
  let a;
  try { a = liveSetupAudio(video); } catch (e) { liveStop("Trascrizione non possibile: " + e.message); return; }
  if (!a) {
    if (attempt < 8) setTimeout(() => liveEnsureAudio(attempt + 1), 1000);
    else if (!video.paused) liveStop("Non riesco a catturare l'audio di questo video.");
    return;
  }
  setTimeout(() => {
    if (live.running && !video.paused && (video.muted || video.volume === 0)) {
      setStatus("Il video è senza audio (muto): attivalo, altrimenti la trascrizione non sente niente.");
    }
    if (live.running && live.audio && live.audio.ctx.state === "suspended" && !video.paused) {
      setStatus("Trascrizione pronta: clicca una volta sul video per attivare l'audio.");
    }
  }, 1500);
}

function liveStart(manual, opts = {}) {
  if (!settings) return false;
  const video = getVideo();
  const v = currentVideoId();
  if (!video || !v) { setStatus("Apri un video di YouTube per trascrivere l'audio."); return false; }
  if (settings.stt === "groq" && !settings.keys.groq) {
    setStatus("Per trascrivere l'audio serve la chiave Groq: inseriscila nel popup, nella sezione dei video senza sottotitoli.");
    return false;
  }
  if (live.videoId !== v) liveReset();
  live.videoId = v;
  live.running = true;
  if (!opts.fill) live.full = false;
  live.errors = 0;
  liveAttachVideo(video);
  // ogni avvio ricattura l'audio da capo (prima, dopo 3 tentativi falliti non riprovava più fino al ricaricamento della pagina)
  live.recaptures = 0; live.zeroMs = 0; live.silentWarned = false;
  if (live.audio) live.audio.stale = true;
  live.isLive = dsIsLiveStream(video);
  live.lastVt = null;
  live.lastAudioAt = 0;
  if (live.busy && live.busySince && Date.now() - live.busySince > 70000) { live.busy = false; live.busySince = 0; }
  if (live.queue.length) setTimeout(liveProcessQueue, 0);
  if (live.isLive && !opts.fill && live.cues.length) liveTimelineReset();
  if (manual) live.aheadOff = null;   // riaccesa a mano: la diretta in anticipo si riprova
  // le dirette non si salvano e non si ricaricano: ogni volta è un'altra trasmissione
  if (live.loadedFor !== v) { live.loadedFor = v; if (!dsIsLiveStream(video)) liveLoadCache(v); }
  liveEnsureAudio();
  if (!opts.quiet) setStatus((manual ? "" : "Questo video non ha sottotitoli. ") +
    "Trascrizione dell'audio attiva: le frasi arrivano con qualche secondo di ritardo.");
  return true;
}

// Avvio dal popup: su un video che ha già sottotitoli (magari sbagliati) ricordo la scelta,
// così riaprendolo la trascrizione riparte da sola invece di tornare ai sottotitoli del sito
function liveManualStart(v) {
  const ok = liveStart(true);
  if (ok && v && hasCaptions[v] !== false && !live.modes[v]) liveSetMode(v, "live").catch(() => {});
  return ok;
}

// L'hai scelta tu per questo video (dal popup): vale anche se il video ha i suoi sottotitoli
const liveChosen = (v) => !!v && (live.modes[v] === "live" || live.modes[v] === "full");

function liveStop(message) {
  dsLiveLog("trascrizione fermata" + (message ? ": " + message : ""));
  if (typeof aheadStop === "function") aheadStop();
  liveCutClean();
  liveFlushClean();
  live.running = false;
  if (live.audio && !live.audio.firefox) live.audio.ctx.suspend().catch(() => {});
  if (message) setStatus(message);
}

function liveReset() {
  if (typeof aheadStop === "function") aheadStop();
  liveSaveNow();
  live.running = false;
  live.loadedFor = null;
  live.llmBlocked = false;
  live.cleanBlocked = false;
  clearTimeout(live.cleanTimer);
  live.cleanWait = [];
  live.gen++;
  if (live.audio) live.audio.stale = true; // al prossimo video ricatturo l'audio da capo
  live.videoId = null;
  live.frames = [];
  live.framesMs = 0;
  live.cues = [];
  live.covered = [];
  live.queue = [];
  live.pendingTr = [];
  live.retry = [];
  live.redo = [];
  live.redoAutoStarted = false;
  live.recentItems = [];
  live.lastText = "";
  live.lang = "";
  live.hold = null;
  live.full = false;
  live.votes = {};
  live.domLang = "";
  live.lockLang = "";
  live.switchTo = "";
  live.switchCount = 0;
  live.zeroMs = 0;
  live.silentWarned = false;
}

// Diretta: le frasi e i tratti "già trascritti" valgono solo per l'orologio di adesso. Se il flusso viene ricaricato o
// l'orologio torna indietro, l'audio nuovo cadeva nei tratti già coperti e veniva scartato come "già trascritto":
// i sottotitoli sparivano e non tornavano più (neanche spegnendo e riaccendendo; solo ricaricando la pagina).
// Lingua e voti restano: è la stessa trasmissione.
function liveTimelineReset(message) {
  dsLiveLog("sottotitoli della diretta ripartiti da qui" + (message ? ": " + message : " (orologio del video tornato indietro)"));
  live.gen++;
  if (typeof ahead !== "undefined" && ahead) { ahead.offset = null; ahead.pEnv = []; ahead.pCarry = null; ahead.hold = []; }
  live.lastVt = null;
  live.cues = [];
  live.covered = [];
  live.queue = [];
  live.pendingTr = [];
  live.retry = [];
  live.redo = [];
  live.recentItems = [];
  live.frames = [];
  live.framesMs = 0;
  live.hold = null;
  live.zeroMs = 0;
  live.recaptures = 0;
  live.silentWarned = false;
  if (live.audio) live.audio.stale = true;
  if (live.running) setTimeout(() => liveEnsureAudio(), 300);
  if (message) setStatus(message);
}

// Controllo continuo (dal tick, quando torni sulla scheda e quando riaccendi): se l'audio catturato non arriva più
// o la coda della trascrizione è bloccata, riparto da solo invece di restare fermo fino al ricaricamento della pagina
function liveWatchdog(force) {
  const video = live.el;
  if (!live.running || !video) return;
  const now = Date.now();
  if (!force && now - (live.wdAt || 0) < 3000) return;
  live.wdAt = now;
  if (live.busy && live.busySince && now - live.busySince > 300000) {
    dsLiveLog("coda della trascrizione bloccata da 5 minuti: la sblocco");
    live.busy = false; live.busySince = 0;
    if (live.queue.length) liveProcessQueue();
  }
  // diretta in anticipo: parte appena si sa che è una diretta (la durata infinita a volte arriva dopo)
  if (typeof aheadWanted === "function" && !ahead && aheadWanted(video) && live.aheadOff !== live.videoId) aheadStart();
  if (video.paused || video.ended || video.seeking) return;
  const a = live.audio;
  if (!a || a.stale) { if (now - (live.wdFixAt || 0) > 5000) { live.wdFixAt = now; dsLiveLog("audio non catturato: lo ricatturo"); liveEnsureAudio(); } return; }
  if (a.ctx.state === "suspended") { dsLiveLog("audio sospeso dal browser: lo riprendo"); liveResumeAudio(); return; }
  if (live.lastAudioAt && now - live.lastAudioAt > 6000 && now - (live.wdFixAt || 0) > 10000) {
    dsLiveLog("nessun audio da " + Math.round((now - live.lastAudioAt) / 1000) + " s: lo ricatturo");
    live.wdFixAt = now;
    a.stale = true;
    liveEnsureAudio();
  }
}
document.addEventListener("visibilitychange", () => { if (!document.hidden) liveWatchdog(true); });

// ---------- Taglio dell'audio nelle pause ----------
function liveOnAudio(data, sampleRate) {
  live.lastAudioAt = Date.now();
  const video = live.el;
  if (!live.running || !video || live.audio.video !== video) return;
  // In pausa il pezzo in corso NON viene chiuso: quando riparti continua da dove era,
  // così una parola interrotta dalla pausa non viene tagliata
  if (video.paused || video.seeking || video.ended) return;
  const rate = video.playbackRate || 1;
  const realMs = (data.length / sampleRate) * 1000;
  const vtStart = video.currentTime * 1000 - realMs * rate;

  // Salto nel video (torni indietro, vai avanti, pubblicità): chiudo il pezzo in un punto pulito
  const last = live.frames[live.frames.length - 1];
  if (last && Math.abs(vtStart - (last.vt + last.realMs * last.rate)) > 1500) liveCutClean();
  if (dsIsLiveStream(video)) {
    live.isLive = true;
    // diretta con l'orologio tornato indietro (flusso ricaricato, o sei tornato indietro nella diretta): si riparte da qui
    // (non quando torni indietro tu, per esempio per riascoltare: lì le frasi già trascritte restano)
    // (anche subito dopo uno spostamento, se nel frattempo YouTube ha ricaricato il flusso: l'orologio è ripartito da
    // un altro punto. Non quando lo spostamento è il nostro della diretta sincronizzata)
    const ourSeek = typeof ahead !== "undefined" && ahead && ahead.seeking;
    if (live.lastVt != null && vtStart < live.lastVt - 5000 && (Date.now() - (live.seekAt || 0) > 3000 || (live.reloadAt && !ourSeek))) { const back = Math.round((live.lastVt - vtStart) / 1000); live.lastVt = null; live.reloadAt = 0; liveTimelineReset("l'orologio del video è tornato indietro di " + back + " s senza uno spostamento"); return; }
    // flusso ricaricato da YouTube: riparto solo se l'orologio è saltato in avanti di molto rispetto a quanto è passato
    if (live.reloadAt && live.lastVt != null && live.lastVtAt) {
      const expected = live.lastVt + (Date.now() - live.lastVtAt);
      const jump = vtStart - expected;
      live.reloadAt = 0;
      if (jump > 30000 && Date.now() - (live.seekAt || 0) > 3000) { live.lastVt = null; liveTimelineReset("Il video in diretta è stato ricaricato più avanti: la trascrizione riparte da qui."); return; }
    } else if (live.reloadAt && Date.now() - live.reloadAt > 60000) live.reloadAt = 0;
    live.lastVt = vtStart;
    live.lastVtAt = Date.now();
  }

  const factor = sampleRate / LIVE_RATE;
  const n = Math.floor(data.length / factor);
  const pcm = new Float32Array(n);
  let sum = 0;
  for (let i = 0; i < n; i++) {
    const a = Math.floor(i * factor), b = Math.min(data.length, Math.floor((i + 1) * factor));
    let acc = 0;
    for (let j = a; j < b; j++) acc += data[j];
    const v = acc / Math.max(1, b - a);
    pcm[i] = v;
    sum += v * v;
  }
  const rms = Math.sqrt(sum / Math.max(1, n));
  if (rms === 0 && !video.muted && video.volume > 0) {
    live.zeroMs += realMs;
    // silenzio assoluto mentre il video suona: di solito la traccia catturata non riceve più niente
    // (il sito ha cambiato la sorgente). Provo a ricatturare l'audio, al massimo 3 volte di fila.
    if (live.zeroMs > 2500 && (live.recaptures || 0) < 3 && Date.now() - (live.recaptureAt || 0) > 2000) {
      live.recaptures = (live.recaptures || 0) + 1;
      live.recaptureAt = Date.now();
      live.audio.stale = true;
      setTimeout(() => liveEnsureAudio(), 0);
      return;
    }
    if (live.zeroMs > 8000 && !live.silentWarned && (live.recaptures || 0) >= 3) {
      live.silentWarned = true;
      setStatus("Questo sito non permette di catturare l'audio del video (protezione dei contenuti). " +
        "Se è un file che puoi scaricare, apri \"Trascrizione e traduzione\" dal popup e trascrivilo da lì.");
    }
  } else if (rms > 0) { live.zeroMs = 0; live.recaptures = 0; }
  // diretta in anticipo (ahead.js): l'audio del video serve solo a metterla a tempo; quando funziona, niente Whisper qui
  if (typeof aheadOnPlayerAudio === "function" && aheadOnPlayerAudio(pcm, vtStart, realMs, rate)) return;
  live.frames.push({ pcm, rms, vt: vtStart, realMs, rate });
  if (live.redo.length) { liveRedoPrune(vtStart); if (!live.running) return; }
  live.framesMs += realMs;
  liveDecideCut();
}

function liveDecideCut() {
  const fr = live.frames;
  if (live.framesMs < LIVE_MIN_MS) return;
  const mean = fr.reduce((a, f) => a + f.rms, 0) / fr.length;
  const thr = Math.max(0.0015, mean * 0.35);

  let quietMs = 0;
  for (let i = fr.length - 1; i >= 0 && fr[i].rms < thr; i--) quietMs += fr[i].realMs;
  if (quietMs >= LIVE_QUIET_MS) { liveFlush(); return; }

  if (live.framesMs >= LIVE_MAX_MS) {
    // Nessuna pausa netta: taglio nel punto più silenzioso degli ultimi 4 secondi
    let acc = 0, best = -1, bestRms = Infinity;
    for (let i = fr.length - 1; i > 0; i--) {
      acc += fr[i].realMs;
      if (acc < 300) continue;
      if (acc > 4000) break;
      if (fr[i].rms < bestRms) { bestRms = fr[i].rms; best = i; }
    }
    liveFlush(best < 0 ? fr.length : best + 1);
  }
}

// Chiude il pezzo in corso senza tagliare parole: manda l'audio fino all'ultima pausa,
// butta via il resto (che verrà trascritto di nuovo quando ci ripasserai)
function liveCutClean() {
  const fr = live.frames;
  if (!fr.length) return;
  if (live.framesMs >= 1500) {
    const mean = fr.reduce((a, f) => a + f.rms, 0) / fr.length;
    const thr = Math.max(0.0015, mean * 0.35);
    let quiet = 0;
    for (let i = fr.length - 1; i > 0; i--) {
      if (fr[i].rms < thr) quiet += fr[i].realMs; else quiet = 0;
      if (quiet >= 200) { liveFlush(i + 1); break; }
    }
  }
  live.frames = [];
  live.framesMs = 0;
}

function liveFlush(count = live.frames.length) {
  const out = live.frames.splice(0, count);
  live.framesMs = live.frames.reduce((a, f) => a + f.realMs, 0);
  if (!out.length) return;
  const realMs = out.reduce((a, f) => a + f.realMs, 0);
  const meanRms = out.reduce((a, f) => a + f.rms, 0) / out.length;
  if (realMs < 700 || meanRms < 0.002) return; // troppo corto o solo silenzio
  const s = out[0].vt, rate = out[0].rate, e = s + realMs * rate;
  if (liveCoveredFraction(s, e) > 0.6 && !liveOverlapsRedo(s, e)) return; // già trascritto (hai rivisto un pezzo)

  const total = out.reduce((a, f) => a + f.pcm.length, 0);
  const pcm = new Float32Array(total);
  let off = 0;
  for (const f of out) { pcm.set(f.pcm, off); off += f.pcm.length; }
  live.queue.push({ pcm, s, e, rate, gen: live.gen });
  liveProcessQueue();
}

function liveCoveredFraction(s, e) {
  let covered = 0;
  for (const [a, b] of live.covered) covered += Math.max(0, Math.min(b, e) - Math.max(a, s));
  return covered / Math.max(1, e - s);
}

function liveWav(pcm) {
  const buf = new ArrayBuffer(44 + pcm.length * 2);
  const v = new DataView(buf);
  const str = (o, t) => { for (let i = 0; i < t.length; i++) v.setUint8(o + i, t.charCodeAt(i)); };
  str(0, "RIFF"); v.setUint32(4, 36 + pcm.length * 2, true); str(8, "WAVE");
  str(12, "fmt "); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, LIVE_RATE, true); v.setUint32(28, LIVE_RATE * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  str(36, "data"); v.setUint32(40, pcm.length * 2, true);
  for (let i = 0; i < pcm.length; i++) {
    const x = Math.max(-1, Math.min(1, pcm[i]));
    v.setInt16(44 + i * 2, x < 0 ? x * 0x8000 : x * 0x7fff, true);
  }
  return new Blob([buf], { type: "audio/wav" });
}

function liveBase64(blob) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result).split(",")[1] || "");
    r.onerror = () => rej(r.error);
    r.readAsDataURL(blob);
  });
}

// ---------- Invio a Whisper ----------
const liveOverlapsRedo = (s, e) => live.redo.some((r) => Math.min(r.b, e) - Math.max(r.a, s) > 300);

// Frasi da ritrascrivere (🎙 Ritrascrivi senza audio in memoria): una volta riascoltate si torna
// alla trascrizione già fatta. Una richiesta è finita quando i pezzi trascritti arrivano alla sua fine,
// quando il video si è allontanato da lì, o dopo 2 minuti al massimo: così non resta mai attiva per sempre.
function liveRedoPrune(vt) {
  if (!live.redo.length) return;
  const now = Date.now();
  const before = live.redo.length;
  live.redo = live.redo.filter((r) => {
    if (r.done >= r.b - 700) return false;
    if (now - r.at > 120000) return false;
    if (vt != null && now - r.at > 5000 && (vt > r.b + 15000 || vt < r.a - 8000)) return false;
    return true;
  });
  if (before && !live.redo.length) {
    if (live.redoAutoStarted) {
      // la trascrizione era ferma: l'avevo avviata solo per questa frase, la rifermo
      live.redoAutoStarted = false;
      liveStop("Frase ritrascritta: continuo con la trascrizione già fatta.");
    } else setStatus("Frase ritrascritta.");
  }
}

// risposta del sottofondo con un tempo massimo: una richiesta rimasta appesa (rete cambiata, scheda in sottofondo,
// estensione sospesa dal browser) bloccava la coda per sempre e i sottotitoli non tornavano più
function liveSend(msg, ms = 60000) {
  let timer;
  const late = new Promise((ok) => { timer = setTimeout(() => ok({ error: `nessuna risposta entro ${Math.round(ms / 1000)} s`, timeout: true }), ms); });
  return Promise.race([DS_EXT.runtime.sendMessage(msg), late]).finally(() => clearTimeout(timer));
}

async function liveRequest(item, language, model, noPrompt) {
  try {
    // suggerimento: i sottotitoli automatici di YouTube in quel punto (stessa lingua), altrimenti le ultime frasi
    const lastOk = live.lastText && !(language && DualSubs.wrongLang(live.lastText, language));
    const prompt = noPrompt ? "" : (liveYtPrompt(item) || (lastOk ? live.lastText : ""));
    return await liveSend({
      type: "transcribe", audio: await liveBase64(liveWav(item.pcm)), mime: "audio/wav",
      stt: settings.stt, key: settings.keys.groq || "",
      model: model || (liveOverlapsRedo(item.s, item.e) ? liveBetterModel() : settings.sttModel),
      url: settings.sttUrl, language, prompt
    });
  } catch (err) {
    return { error: String(err.message || err) };
  }
}

const liveMapLang = (l) => { const x = String(l || "").toLowerCase(); return C.WHISPER_LANGS[x] || (x.length <= 3 ? x : ""); };

async function liveProcessQueue() {
  if (live.busy) return;
  live.busy = true;
  while (live.queue.length) {
    const item = live.queue.shift();
    if (item.gen !== live.gen) continue;
    live.busySince = Date.now();
    // diretta: un pezzo rimasto indietro di più di un minuto (per esempio mentre la scheda era in sottofondo) non serve più
    const vNow = live.el ? live.el.currentTime * 1000 : 0;
    if (live.isLive && vNow && item.e < vNow - 60000) continue;
    // Lingua imposta a Whisper: quella scelta nel popup, oppure quella del video appena stabilita (vedi sotto).
    // Senza lingua imposta Whisper a volte "traduce": scrive in inglese quello che sente in un'altra lingua.
    const forced = liveLangNow();
    let resp = await liveRequest(item, forced);
    if (item.gen !== live.gen) continue;
    if (!resp || resp.error) {
      const err = (resp && resp.error) || "nessuna risposta";
      // quanto audio permette Groq (lo dice nel messaggio di errore: "Limit 28800" = secondi)
      const lim = Number((String(err).match(/Limit:?\s*(\d+)/i) || [])[1]) || 0;
      const limTxt = lim ? ` (${Math.round((lim / 3600) * 10) / 10} ore di audio)` : "";
      if (resp && resp.fatal) {
        // chiave sbagliata o credito dell'account finito: inutile riprovare
        liveStop(err + " Le frasi già trascritte restano.");
        live.queue = [];
      } else if (resp && resp.rateLimited && resp.daily) {
        liveStop(`Groq: è finita la quota gratuita di trascrizione di oggi${limTxt}. Contano anche le richieste di confronto ` +
          "della lingua e le ritrascrizioni. La quota si libera nelle prossime ore: poi riavviala dal popup. Le frasi già trascritte restano.");
        live.queue = [];
      } else if (resp && resp.rateLimited) {
        // rimetto il pezzo in coda e aspetto: così non si perdono frasi
        live.queue.unshift(item);
        const secs = Math.min(Math.max(resp.retryAfter || 0, 5), 3600);
        const hour = resp.hourly || /hour|ASPH/i.test(err);
        for (let left = secs; left > 0 && item.gen === live.gen; left -= 5) {
          setStatus(hour
            ? `Groq: raggiunto il limite di audio trascritto nell'ultima ora${limTxt}. Riprendo da solo tra ${left >= 60 ? Math.ceil(left / 60) + " min" : left + " s"}.`
            : `Trascrizione: limite di richieste di Groq raggiunto, riprovo tra ${left} s.`);
          await sleep(Math.min(5, left) * 1000);
        }
      } else if (resp && resp.timeout) {
        dsLiveLog("Whisper non ha risposto in tempo");
        setStatus("Whisper non ha risposto in tempo: passo al pezzo dopo.");
      } else if (dsLiveLog("errore di trascrizione: " + err), ++live.errors >= 3 && live.isLive) {
        // diretta: non mi fermo per sempre (la rete a volte si blocca un attimo); aspetto e riprendo da qui
        setStatus("Trascrizione: ripetuti errori (" + err + "). Riprovo tra 20 s.");
        live.errors = 0;
        live.queue = live.queue.slice(-2);
        await sleep(20000);
      } else if (live.errors >= 3) {
        liveStop("Trascrizione fermata dopo ripetuti errori: " + err);
        live.queue = [];
      } else {
        setStatus("Errore di trascrizione: " + err);
      }
      continue;
    }
    live.errors = 0;
    // Controllo: testo in inglese anche se la lingua imposta è un'altra = Whisper ha tradotto. Rifaccio il pezzo
    // senza il testo precedente come suggerimento (se quello era inglese, trascinava anche questo in inglese).
    const respText = (r) => (r && r.segments || []).map((x) => x.text || "").join(" ");
    // ...o in un altro alfabeto. Riprovo senza suggerimento, poi con il modello migliore; se è ancora sbagliato
    // il pezzo lo salto: meglio un buco che la traduzione inglese al posto della trascrizione
    if (forced && DualSubs.wrongLang(respText(resp), forced)) {
      let fixed = null;
      for (const model of [null, liveBetterModel()]) {
        const again = await liveRequest(item, forced, model, true);
        if (item.gen !== live.gen) break;
        if (again && !again.error && !DualSubs.wrongLang(respText(again), forced)) { fixed = again; break; }
      }
      if (item.gen !== live.gen) continue;
      if (!fixed) {
        item.lang = forced;
        liveAddCues(item, [], []);
        setStatus(`Un pezzo di audio veniva scritto in un'altra lingua invece che in ${dsLangName(forced)}: l'ho saltato.`);
        continue;
      }
      resp = fixed;
    }
    let det = forced && !dsSttLang() ? forced : liveMapLang(resp.language);
    // Lingua fissata ma Whisper è poco sicuro: forse il video ha cambiato davvero lingua. Lo riascolto senza imporla:
    // se riconosce con sicurezza un'altra lingua (non l'inglese: scrivere in inglese è proprio l'errore da evitare)
    // e il testo è davvero in quella lingua, tengo quella; dopo due pezzi di fila diventa la nuova lingua del video.
    if (live.lockLang && !dsSttLang() && !liveHintLang() && DualSubs.meanLogprob(resp.segments) < -0.7) {
      const free = await liveRequest(item, "");
      if (item.gen !== live.gen) continue;
      const d2 = free && !free.error ? liveMapLang(free.language) : "";
      const g = d2 ? DualSubs.guessLang(respText(free)) : "";
      if (d2 && d2 !== live.lockLang && d2 !== "en" && (!g || g === d2) &&
          DualSubs.meanLogprob(free.segments) > DualSubs.meanLogprob(resp.segments) + 0.2) {
        resp = free; det = d2;
        if (live.switchTo === d2 && ++live.switchCount >= 2) {
          live.lockLang = live.domLang = d2; live.switchCount = 0;
          setStatus(`Il video ora è in un'altra lingua (${d2}): la trascrizione continua in questa lingua.`);
        } else if (live.switchTo !== d2) { live.switchTo = d2; live.switchCount = 1; }
      } else live.switchCount = 0;
    }
    // Prima che la lingua sia stabilita: ogni pezzo "vota" la lingua riconosciuta da Whisper (solo se ha abbastanza
    // parlato) e la lingua del video è quella con più voti. Con 3 voti la lingua si fissa e da lì in poi viene imposta:
    // così Whisper non cambia più lingua da un pezzo all'altro e non scrive la traduzione in inglese al posto della trascrizione.
    if (!forced && det) {
      if (respText(resp).trim().length >= 40) live.votes[det] = (live.votes[det] || 0) + 1;
      // anche le frasi brevi dicono se il video non è in inglese
      else if (det !== "en" && respText(resp).trim().length >= 12 && !live.votes[det]) live.votes[det] = 0.5;
      // l'inglese insieme a un'altra lingua è quasi sempre Whisper che traduce: conta l'altra lingua
      const others = Object.entries(live.votes).filter(([l]) => l !== "en");
      const pool = others.length ? others : Object.entries(live.votes);
      const top = pool.sort((x, y) => y[1] - x[1])[0];
      live.domLang = top ? top[0] : live.domLang || det;
      const total = Object.values(live.votes).reduce((a, b) => a + b, 0);
      if (top && (top[1] >= 3 || (others.length && top[1] >= 0.5 && total >= 2.5)) && pool.every(([l, n]) => l === top[0] || n < top[1])) {
        live.lockLang = top[0];
        setStatus(`Lingua del video: ${top[0]}. Da qui in poi la trascrizione resta in questa lingua.`);
        setTimeout(() => liveRedoOtherLang(top[0]), 0);   // i primi pezzi venuti in un'altra lingua li rifaccio
      }
    }
    if (det) live.lang = det;
    item.lang = det;
    liveAddCues(item, resp.segments || [], resp.words || []);
    live.recentItems.push(item);
    while (live.recentItems.length > 20) { const old = live.recentItems.shift(); delete old.pcm; }
  }
  live.busy = false;
  live.busySince = 0;
}

// Dopo aver fissato la lingua: i pezzi ancora in memoria trascritti in un'altra lingua (di solito Whisper che ha tradotto
// in inglese) li ritrascrivo nella lingua del video e sostituisco le loro frasi
async function liveRedoOtherLang(lang) {
  const gen = live.gen;
  for (const item of live.recentItems.slice()) {
    if (!item.pcm || !item.lang || item.lang === lang) continue;
    const txt = (x) => (x && x.segments || []).map((y) => y.text || "").join(" ");
    let r = await liveRequest(item, lang, null, true);
    if (gen !== live.gen) return;
    if (r && !r.error && DualSubs.wrongLang(txt(r), lang)) { r = await liveRequest(item, lang, liveBetterModel(), true); if (gen !== live.gen) return; }
    if (!r || r.error) continue;
    if (DualSubs.wrongLang(txt(r), lang)) r = { segments: [] };   // ancora nella lingua sbagliata: tolgo il pezzo
    live.cues = live.cues.filter((c) => c.item !== item);
    live.pendingTr = live.pendingTr.filter((c) => c.item !== item);
    live.covered = live.covered.filter((x) => x !== item.range);
    item.lang = lang;
    liveAddCues(item, r.segments || [], r.words || []);
  }
}

function liveAddCues(item, segs, words = []) {
  const inRedo = (t) => live.redo.some((r) => t >= r.a && t < r.b);
  const isCovered = (t) => !inRedo(t) && live.covered.some(([a, b]) => t >= a && t < b);
  const recent = live.cues.slice(-4).map((c) => c.text);
  const good = segs.filter((seg) => {
    const junk = DualSubs.isJunk(seg, recent);   // musica, rumore, frasi inventate da Whisper
    if (!junk) recent.push(String(seg.text || "").trim());
    return !junk;
  });
  const fresh = [];
  for (const c of DualSubs.fromWhisper(good, words, item.s, item.rate)) {
    const end = Math.min(item.e + 300, c.end);
    if (isCovered((c.start + end) / 2)) continue;
    const prev = fresh[fresh.length - 1] || live.cues[live.cues.length - 1];
    if (prev && prev.text === c.text && c.start - prev.start < 8000) continue; // ripetizione
    fresh.push({ start: c.start, end: Math.max(end, c.start + 800), text: c.text, trans: null, quick: false, late: false, item, lang: item.lang || "" });
  }
  item.range = [item.s, item.e];
  live.covered.push(item.range);
  // parti da rifare: segno fin dove sono state riascoltate (anche se la frase è finita in due pezzi)
  for (const r of live.redo) {
    if (Math.min(r.b, item.e) - Math.max(r.a, item.s) > 0) r.done = Math.max(r.done, item.e);
    if (r.a >= item.s - 1000 && r.b <= item.e + 1000) r.done = r.b;
  }
  liveRedoPrune();
  if (!fresh.length) { liveScheduleSave(); return; }

  // Se la frase arriva quando il video l'ha già superata, la mostro in ritardo per la sua durata
  const video = live.el;
  const now = video ? video.currentTime * 1000 : 0;
  const shift = now - fresh[0].start;
  if (shift > 0 && now < item.e + 30000) {
    for (const c of fresh) c.availVt = now;   // arrivate in ritardo: si mostrano da adesso, in ordine (liveSchedule)
  }
  live.cues.push(...fresh);
  live.cues.sort((a, b) => a.start - b.start);
  live.lastText = (live.lastText + " " + fresh.map((c) => c.text).join(" ")).slice(-400);
  if (live.running) setStatus(`Trascrizione dell'audio attiva: ${live.cues.length} frasi finora.`);
  liveScheduleSave();
  liveQueueTranslation(fresh);
}

// ---------- Traduzione: subito una versione rapida, poi quella contestuale ----------
function liveQueueTranslation(cues) {
  // le frasi già nella lingua in cui traduci non vanno tradotte (conta la lingua della singola frase)
  const same = (c) => { const l = baseLang(c.lang || liveSourceLang()); return l && l === baseLang(settings.targetLang); };
  cues.filter(same).forEach((c) => { c.trans = ""; });
  cues = cues.filter((c) => !same(c) && !c.removed);
  if (!cues.length) return;
  const e = liveEngine();
  const cleaner = e.E.kind !== "openai" && e.E.kind !== "claude" && !live.cleanBlocked && cleanerEngine();
  if (e.id !== "google" || cleaner) liveQuickTranslate(cues);
  if (live.llmBlocked) return; // limite giornaliero: resta la traduzione rapida
  if (cleaner) {
    // correzione con Gemini/Groq: raccolgo le frasi in gruppi (intanto si vede la traduzione rapida),
    // così basta una richiesta ogni 10 frasi circa invece di una per ogni pezzo d'audio
    live.cleanWait = (live.cleanWait || []).concat(cues);
    clearTimeout(live.cleanTimer);
    if (live.cleanWait.length >= 10) liveFlushClean();
    else live.cleanTimer = setTimeout(liveFlushClean, 25000);
    return;
  }
  live.pendingTr.push(...cues);
  liveProcessTranslations();
}

function liveFlushClean() {
  clearTimeout(live.cleanTimer);
  const cues = (live.cleanWait || []).filter((c) => live.cues.includes(c) && !c.removed);
  live.cleanWait = [];
  if (!cues.length) return;
  live.pendingTr.push(...cues);
  liveProcessTranslations();
}

async function liveQuickTranslate(cues, force = false) {
  const gen = live.gen;
  for (let i = 0; i < cues.length; i += 12) {
    const part = cues.slice(i, i + 12);
    let resp;
    try {
      resp = await DS_EXT.runtime.sendMessage({
        type: "translate", engine: "google", target: settings.targetLang,
        source: new Set(part.map((c) => c.lang)).size === 1 ? part[0].lang || liveSourceLang() : "", texts: part.map((c) => c.text)
      });
    } catch { return; }
    if (gen !== live.gen || !resp || resp.error) return;
    part.forEach((c, k) => {
      if (!(c.trans == null || force || c.quick)) return;
      const t = resp.translations[k];
      if (t && !dsIsEcho(c.text, t)) {
        c.trans = t; c.quick = true;
        // frase breve che anche Google lascia uguale: è un nome, va bene così (controllata e salvata)
        if (force && dsIsCopy(c.text, t)) { dsMarkCopyOk(c.text, settings.targetLang); c.quick = false; c.saved = true; }
      }
      else if (c.trans == null || force) { c.trans = ""; c.quick = false; }
    });
  }
}

async function liveProcessTranslations() {
  if (live.trBusy) return;
  live.trBusy = true;
  while (live.pendingTr.length || live.retry.length) {
    const gen = live.gen;
    const e = dsUsable(liveEngine());
    const name = e.E.label.split(" (")[0];
    if ((e.E.needsKey && !e.key) || (e.E.kind === "openai" && !e.model)) {
      setStatus(`Trascrizione attiva. Per tradurre con ${name} manca la chiave o il modello nel popup: uso la traduzione rapida.`);
      live.pendingTr = [];
  live.retry = [];
      break;
    }
    // Tutte le frasi arrivate nel frattempo vanno in un'unica richiesta,
    // cominciando da quelle che stanno per arrivare nel video
    const vid = getVideo();
    const now = vid ? vid.currentTime * 1000 - 2000 : 0;
    live.pendingTr.sort((a, b) => (a.end < now) - (b.end < now) || a.start - b.start);
    const batch = live.retry.length ? live.retry.shift() : live.pendingTr.splice(0, Math.min(80, (e.E.chunk && e.E.chunk.count) || 30));
    const idx = live.cues.indexOf(batch[0]);
    const before = live.cues.slice(Math.max(0, idx - 6), Math.max(0, idx)).map((c) => c.text);
    const langs = new Set(batch.map((c) => c.lang).filter(Boolean));
    const clean = e.E.kind === "openai" || e.E.kind === "claude";
    // Si traduce con Google o DeepL: prima faccio correggere la trascrizione da Gemini (o Groq), una richiesta ogni 30 frasi
    if (!clean && !live.cleanBlocked) {
      const ce = cleanerEngine();
      const toClean = batch.filter((c) => !c.cleanTried);
      if (ce && toClean.length) {
        toClean.forEach((c) => { c.cleanTried = true; });
        const cr = await liveCleanOnly(ce, toClean, before);
        if (gen !== live.gen) break;
        if (cr && cr.sources && !cr.misaligned) liveApplySources(toClean, cr.sources, null);
        else if (cr && (cr.daily || cr.fatal)) {
          live.cleanBlocked = true;
          setStatus(`Correzione della trascrizione sospesa (${ce.E.label.split(" (")[0].split(",")[0]}: ${cr.error}). La traduzione continua.`);
        }
        batch.splice(0, batch.length, ...batch.filter((c) => !c.removed));
        if (!batch.length) { liveScheduleSave(); continue; }
      }
    }
    const resp = await askTranslate(e, batch.map((c) => c.text), before, [], () => gen === live.gen, "",
      langs.size === 1 ? [...langs][0] : langs.size ? "" : liveSourceLang(), clean);
    if (!resp) break;
    if (resp.daily && e.id !== "google") {
      dsMarkBlocked(e.id);
      const next = dsNextEngine(e.id);
      if (next) {
        // il prossimo giro del ciclo usa da solo il servizio di riserva (dsUsable)
        live.retry.unshift(batch);
        setStatus(`${name} ha finito le richieste gratuite di oggi: continuo con ${next.E.label.split(" (")[0]}.`);
        continue;
      }
    }
    if (resp.daily) {
      live.llmBlocked = true;
      live.pendingTr = [];
      live.retry = [];
      if (e.id !== "google") liveQuickTranslate(batch.filter((c) => c.trans == null));
      setStatus(DAILY_MSG(name).replace("Intanto traduco con Google Traduttore", "Intanto resta la traduzione rapida di Google"));
      break;
    }
    if (resp.error) {
      setStatus("Errore di traduzione: " + resp.error + " (resta la traduzione rapida)");
      if (resp.fatal) { live.llmBlocked = true; live.pendingTr = [];
  live.retry = []; }
      if (e.id !== "google") liveQuickTranslate(batch.filter((c) => c.trans == null));
      continue;
    }
    // Traduzione sfasata (una frase finita sotto quella accanto): ritraduco il blocco diviso a metà
    if (resp.misaligned && batch.length > 1) {
      const mid = Math.ceil(batch.length / 2);
      live.retry.unshift(batch.slice(0, mid), batch.slice(mid));
      continue;
    }
    // Il modello ha anche ripulito la trascrizione: correggo le parole capite male
    // e tolgo i pezzi che non sono parlato (frasi inventate durante musica o rumore)
    if (resp.sources) liveApplySources(batch, resp.sources, resp.translations);
    // Una "traduzione" identica all'originale (o nella lingua sbagliata) non è una traduzione: non la salvo e uso Google
    const echoed = [];
    batch.forEach((c, k) => {
      if (c.removed) return;
      const t = resp.translations[k];
      if (t && !dsIsEcho(c.text, t) && !dsUncheckedCopy(c.text, t, settings.targetLang)) { c.trans = t; c.quick = false; c.saved = true; }
      else echoed.push(c);
    });
    if (echoed.length) liveQuickTranslate(echoed, true);
    liveScheduleSave();
  }
  live.trBusy = false;
}

// Correzioni proposte dal modello: accetto solo quelle che lasciano la frase riconoscibile,
// e tolgo i pezzi che non sono parlato (frasi inventate durante musica o rumore)
function liveApplySources(batch, sources, translations) {
  batch.forEach((c, k) => {
    const src = sources[k];
    if (src == null) return;
    if (!src && !(translations ? (translations[k] || "").trim() : "")) {
      if (c.text.split(/\s+/).length <= 12) { c.removed = true; c.saved = true; c.trans = ""; }
      return;
    }
    // solo correzioni piccole (parole capite male, punteggiatura), nella stessa lingua: niente frasi riscritte
    if (src && src !== c.text && DualSubs.charSimilarity(c.text, src) >= 0.72 && !DualSubs.wrongLang(src, c.lang || liveSourceLang())) { c.text = src; c.cleaned = true; }
  });
}

// Solo correzione (con attesa sui limiti come per la traduzione)
async function liveCleanOnly(ce, batch, before) {
  const gen = live.gen;
  for (let waits = 0; waits < 4; waits++) {
    let r;
    try {
      r = await DS_EXT.runtime.sendMessage({ type: "cleanText", engine: ce.id, key: ce.key, model: ce.model, localUrl: ce.localUrl,
        texts: batch.map((c) => c.text), before, after: [] });
    } catch (err) { r = { error: String(err.message || err) }; }
    if (gen !== live.gen) return null;
    if (r && r.rateLimited && !r.daily) { await sleep(Math.min(60, Math.max(r.retryAfter || 0, 8 * (waits + 1))) * 1000); continue; }
    return r || null;
  }
  return null;
}

// Se cambi servizio o lingua, ritraduco quello che è già stato trascritto
// (prima guardo se quella combinazione era già salvata)
async function liveRetranslate() {
  if (!live.cues.length || !live.videoId) return;
  const gen = live.gen;
  live.cues.forEach((c) => { c.trans = null; c.quick = false; c.saved = false; });
  live.pendingTr = [];
  live.retry = [];
  live.llmBlocked = false;
  const map = (await DS_EXT.storage.local.get(liveTransKey(live.videoId)))[liveTransKey(live.videoId)] || {};
  if (gen !== live.gen) return;
  liveApplyTranslations(map);
}

// ---------- Salvataggio: rivedere un video non costa nuove richieste ----------
const liveCuesKey = (v) => `live:${v}`;
function liveTransKey(v) {
  const e = liveEngine();
  return `livetr:${v}|${settings.targetLang}|${e.id}|${e.model}`;
}

function liveScheduleSave() {
  live.dirty = true;
  clearTimeout(live.saveTimer);
  live.saveTimer = setTimeout(liveSaveNow, 2000);
}

function liveSaveNow() {
  clearTimeout(live.saveTimer);
  if (!live.dirty || !live.videoId || !live.cues.length) return;
  if (dsIsLiveStream(live.el || getVideo())) { live.dirty = false; return; }
  live.dirty = false;
  const v = live.videoId;
  const cues = live.cues.map((c) => ({ s: Math.round(c.start), e: Math.round(c.end), t: c.text, ...(c.removed ? { x: 1 } : {}), ...(c.lang ? { l: c.lang } : {}) }));
  const trans = {};
  for (const c of live.cues) if (c.saved && c.trans) trans[Math.round(c.start)] = c.trans;
  saveCache(liveCuesKey(v), { cues, covered: live.covered, lang: live.domLang || live.lang, full: live.full }).catch(() => {});
  if (Object.keys(trans).length) saveCache(liveTransKey(v), trans).catch(() => {});
}

async function liveLoadCache(v) {
  const gen = live.gen;
  const ck = liveCuesKey(v), tk = liveTransKey(v);
  const got = await DS_EXT.storage.local.get([ck, tk]);
  if (gen !== live.gen || live.videoId !== v) return;
  const saved = got[ck];
  if (!saved || !Array.isArray(saved.cues) || !saved.cues.length) return;
  // trascrizione salvata in un'altra lingua (per esempio inglese su un video russo: Whisper aveva tradotto): la butto e la rifaccio
  const want = dsSttLang(v) || liveHintLang(v);
  if (want && ((saved.lang && saved.lang !== want) || saved.cues.filter((c) => !c.x && DualSubs.wrongLang(c.t, want)).length > saved.cues.length * 0.2)) {
    await liveRemoveCache(v, "transcript");
    setStatus(`La trascrizione salvata di questo video non era in ${dsLangName(want)}: la rifaccio.`);
    return;
  }
  const isCovered = (t) => live.covered.some(([a, b]) => t >= a && t < b);
  const add = saved.cues
    .filter((c) => !isCovered((c.s + c.e) / 2))
    .map((c) => ({ start: c.s, end: c.e, text: c.t, trans: c.x ? "" : null, quick: false, late: false, removed: !!c.x, saved: !!c.x, lang: c.l || "" }));
  live.cues.push(...add);
  live.cues.sort((a, b) => a.start - b.start);
  live.covered.push(...(saved.covered || []));
  if (!live.lang && saved.lang) live.lang = saved.lang;
  if (saved.lang && !live.domLang) live.domLang = saved.lang;
  if (saved.lang && add.length >= 5 && !live.lockLang) live.lockLang = saved.lang;   // lingua già stabilita per questo video   // lingua già stabilita per questo video
  if (saved.full) live.full = true;
  setStatus(`Trascrizione attiva: ${add.length} frasi di questo video erano già salvate e non verranno richieste di nuovo.`);
  await dsCopyOkReady;
  liveApplyTranslations(got[tk] || {}, add);
}

function liveApplyTranslations(map, cues = live.cues) {
  const missing = [];
  for (const c of cues) {
    if (c.removed) continue;
    const t = map[Math.round(c.start)];
    if (t && !dsBadSaved(c.text, t)) { c.trans = t; c.quick = false; c.saved = true; } else missing.push(c);
  }
  liveQueueTranslation(missing);
}

// Quando mostrare ogni frase. Le frasi arrivano a gruppi (un pezzo di audio alla volta), quindi spesso quando
// arrivano il video le ha già superate: invece di saltarle (la riga restava ferma e poi ripartiva 4-5 frasi dopo)
// le mostro tutte, in ordine, a partire da quando sono arrivate. Per recuperare il ritardo accorcio un po' i tempi
// (al massimo del 30%), ma ogni frase resta almeno il tempo per leggerla; nelle pause del parlato il ritardo sparisce.
const LIVE_MAX_LAG = 12000;
function liveSchedule() {
  const list = live.cues.filter((c) => !c.removed);
  for (let i = 0; i < list.length; i++) {
    const c = list[i], prev = list[i - 1];
    let at = c.start;
    // diretta sincronizzata: la frase è pronta prima che il video arrivi lì, quindi va mostrata esattamente al suo
    // momento. Il tempo minimo per leggere qui faceva slittare le frasi una dopo l'altra (fino a 12 s) nel parlato fitto
    if (c.item && c.item.ahead && c.availVt == null) { c.dispStart = c.start; continue; }
    if (c.availVt != null && c.availVt > at) at = c.availVt;
    if (prev) {
      const lag = prev.dispStart - prev.start;
      const nat = c.start - prev.start;
      const floor = Math.max(1100, Math.min(2500, DualSubs.readMs(prev.text) * 0.6));
      // accorcio solo se dietro ci sono già altre frasi pronte: altrimenti vado al ritmo naturale
      // (accelerare e poi restare fermi ad aspettare il pezzo dopo sarebbe peggio)
      const dwell = lag > 300 && list.length - i >= 2 ? Math.max(nat * 0.75, floor) : nat;
      at = Math.max(at, prev.dispStart + dwell);
    }
    // mai più di 12 s dopo il momento in cui la frase c'è: con il parlato fitto il ritardo non si accumula all'infinito
    c.dispStart = Math.min(at, Math.max(c.start, c.availVt || 0) + LIVE_MAX_LAG);
  }
  for (let i = 0; i < list.length; i++) {
    const c = list[i], next = list[i + 1];
    const own = DualSubs.showEnd(c) - c.start;      // durata naturale (almeno il tempo per leggerla)
    if (!next) { c.dispEnd = c.dispStart + own + (live.running && c.availVt != null ? 6000 : 0); continue; }   // arrivata in ritardo: la lascio mentre arriva il pezzo dopo
    const natEnd = c.dispStart + (c.end - c.start);
    c.dispEnd = next.dispStart - natEnd <= 4000 ? next.dispStart : Math.min(c.dispStart + own, next.dispStart);
  }
  return list;
}

function liveFind(t) {
  const list = liveSchedule();
  let found = null;
  for (const c of list) {
    if (c.dispStart > t) break;
    if (t < c.dispEnd) found = c;
  }
  return found;
}

// ---------- Rifare, e trascrizione completa arrivata dalla pagina "Trascrizione e traduzione" ----------
async function liveRemoveCache(v, what) {
  const all = await DS_EXT.storage.local.get(null);
  const keys = Object.keys(all).filter((k) =>
    (what !== "translation" && k === liveCuesKey(v)) || k.startsWith(`livetr:${v}|`));
  if (keys.length) await DS_EXT.storage.local.remove(keys);
}

async function liveRedo(what) {
  const v = live.videoId || currentVideoId();
  if (!v) return;
  if (what === "translation") {
    await liveRemoveCache(v, what);
    live.cues.forEach((c) => { c.saved = false; });
    liveRetranslate();
    return;
  }
  // prima fermo tutto (salvataggio in sospeso e pezzi in arrivo), poi cancello: altrimenti il salvataggio
  // automatico poteva riscrivere la trascrizione vecchia subito dopo averla cancellata, e veniva ricaricata
  live.dirty = false;
  clearTimeout(live.saveTimer);
  liveReset();
  await liveRemoveCache(v, what);
  // la rifaccio subito, anche se la trascrizione era ferma (prima ripartiva solo se era attiva)
  if (live.modes[v] === "full") { setStatus("Trascrizione cancellata: la rifaccio per intero."); liveFull(); return; }
  liveManualStart(v);
  setStatus("Trascrizione cancellata: la rifaccio da capo mentre guardi il video.");
}

function liveSetTranscript(p) {
  const v = currentVideoId();
  if (!p || p.mediaId !== v) return false;
  if (live.videoId !== v) liveReset();
  live.videoId = v;
  live.loadedFor = v;
  live.full = true;
  live.lang = live.domLang = p.lang || live.lang;
  live.cues = (p.cues || []).map((c) => ({
    start: c.start, end: c.end, text: c.text, trans: c.trans || null, quick: false, saved: !!c.trans, late: false, lang: c.lang || ""
  }));
  live.covered = DualSubs.coverFromCues(live.cues);
  live.dirty = true;
  liveSaveNow();
  liveQueueTranslation(live.cues.filter((c) => !c.trans));
  setStatus(`Trascrizione completa del file caricata: ${live.cues.length} frasi.`);
  liveFillGaps();
  return true;
}

// Le parti senza frasi (buchi lunghi, per esempio dopo una musica) vengono riascoltate
// quando il video ci passa: l'ascolto è attivo ma non manda niente per le parti già coperte
function liveFillGaps() {
  const m = getVideo();
  if (!m || live.running || dsIsLiveStream(m)) return;
  liveStart(true, { fill: true, quiet: true });
}

// Pezzo della trascrizione completa appena arrivato: lo metto subito sul video
function liveAddPiece(cues, range) {
  const [a, b] = range;
  live.cues = live.cues.filter((c) => c.start < a || c.start >= b);   // tolgo quelle eventualmente trascritte dal vivo
  const fresh = cues.map((c) => ({ start: c.start, end: c.end, text: c.text, trans: null, quick: false, late: false, lang: c.lang || "" }));
  live.cues.push(...fresh);
  live.cues.sort((x, y) => x.start - y.start);
  live.covered = live.covered.filter(([x, y]) => y <= a || x >= b).concat(
    DualSubs.coverFromCues(fresh).map(([x, y]) => [Math.max(a, x), Math.min(b, y)]));
  live.dirty = true;
  liveScheduleSave();
  liveQueueTranslation(fresh);
}

// ---------- Modalità "Completa": tutto il video subito ----------
// Scarica l'audio intero (file diretto, oppure yt-dlp con il programma di appoggio),
// lo trascrive in poche richieste e poi traduce tutto, a partire dal punto in cui sei.
async function liveFull() {
  const v = currentVideoId();
  const m = getVideo();
  if (!v || !m || live.fullBusy) return;
  if (dsIsLiveStream(m)) {
    setStatus("È una diretta: non si può scaricare tutta, la trascrivo mentre la guardi.");
    if (!live.running) liveStart(true);
    return;
  }
  if (settings.stt === "groq" && !settings.keys.groq) {
    setStatus("Per trascrivere serve la chiave Groq: inseriscila nel popup, nella sezione dei video senza sottotitoli.");
    return;
  }
  if (live.videoId !== v) liveReset();
  live.videoId = v;
  // già trascritto per intero in passato?
  if (live.loadedFor !== v) { live.loadedFor = v; await liveLoadCache(v); }
  if (live.full) {
    setStatus("Questo video è già trascritto per intero: nessuna richiesta necessaria (riascolto solo eventuali parti mancanti).");
    liveFillGaps();
    return;
  }

  const gen = ++live.fullGen;
  const valid = () => gen === live.fullGen && currentVideoId() === v;
  live.fullBusy = true;
  live.fullText = "Preparo la trascrizione completa…";
  const show = (t) => { live.fullText = t; setStatus(t); };
  // Ponte: scaricare e trascrivere tutto può richiedere minuti (e yt-dlp a volte si blocca). Se dopo 12 secondi
  // non è ancora arrivato niente, intanto trascrivo mentre guardi le parti non ancora coperte, così i sottotitoli
  // non restano fermi. Le parti che poi arrivano dalla trascrizione completa sostituiscono quelle.
  const bridge = setTimeout(() => {
    if (!valid() || !live.fullBusy || live.running) return;
    liveStart(true, { fill: true, quiet: true });
    show(live.fullText + " (intanto trascrivo mentre guardi)");
  }, 12000);
  const url = DS_IS_YT ? `https://www.youtube.com/watch?v=${v}` : location.href;
  const src = dsMediaSrc();

  let fail = null;
  try {
    const got = await new Promise((resolve, reject) => {
      const port = DS_EXT.runtime.connect({ name: "sd-full" });
      const parts = [];
      let meta = {}, lastMsg = Date.now();
      // se lo scaricamento non va più avanti per 90 secondi lo interrompo (prima si poteva aspettare per sempre)
      const dog = setInterval(() => {
        if (!valid()) { clearInterval(dog); return; }
        if (Date.now() - lastMsg > 90000) {
          clearInterval(dog);
          try { port.disconnect(); } catch {}
          reject(new Error("lo scaricamento dell'audio è fermo da un minuto e mezzo (yt-dlp non riesce a scaricare questo video)"));
        }
      }, 5000);
      port.onDisconnect.addListener(() => clearInterval(dog));
      port.onMessage.addListener((msg) => {
        lastMsg = Date.now();
        if (msg.type === "done" || msg.type === "error") clearInterval(dog);
        if (!valid()) { port.disconnect(); reject(new Error("annullato")); return; }
        if (msg.type === "status") show(msg.text);
        else if (msg.type === "progress" && msg.pct >= 0) show(`Scarico l'audio… ${msg.pct}%`);
        else if (msg.type === "meta") meta = msg;
        else if (msg.type === "chunk") {
          const bin = atob(msg.data);
          const a = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i);
          parts.push(a);
        } else if (msg.type === "done") { port.disconnect(); resolve({ parts, meta }); }
        else if (msg.type === "error") { port.disconnect(); const e = new Error(msg.message); e.code = msg.code; reject(e); }
      });
      port.onDisconnect.addListener(() => reject(new Error("collegamento interrotto")));
      port.postMessage({ url: /^https?:/.test(url) ? url : "", src });
    });
    const ext = (got.meta.ext || "").replace(/[^a-z0-9]/gi, "") || "webm";
    const blob = new Blob(got.parts, { type: DS_WHOLE.mimeFor("a." + ext) });
    const vid = getVideo();
    const result = await DS_WHOLE.transcribe(blob, "audio." + ext, {
      settings, language: liveLangNow(), isValid: valid,
      durationSec: got.meta.duration || (vid && isFinite(vid.duration) ? vid.duration : 0),
      startAtSec: vid ? vid.currentTime : 0,
      onProgress: (pct, t) => { if (t) show(t); },
      // ogni pezzo compare subito sul video, a partire da quello che stai guardando
      onPiece: (cues, range) => { if (valid()) liveAddPiece(cues, range); }
    });
    if (!valid()) return;
    if (!result.cues.length) throw new Error("nel file non ho trovato parlato da trascrivere");
    live.full = true;
    live.lang = live.domLang = result.lang || live.domLang;
    if (live.running) { live.dirty = true; liveSaveNow(); }
    else { live.dirty = true; liveSaveNow(); liveFillGaps(); }
    show(`Trascrizione completa: ${result.cues.length} frasi. Le traduco partendo dal punto in cui sei.`);
  } catch (e) {
    if (!valid()) return;
    fail = e;
  } finally {
    clearTimeout(bridge);
    if (gen === live.fullGen) { live.fullBusy = false; live.fullText = ""; }
  }
  if (fail && fail.quota) {
    // quota di Groq finita: inutile ripartire con la trascrizione mentre guardi (finirebbe sulla stessa quota)
    setStatus(fail.message);
    return;
  }
  if (fail) {
    const why = fail.code === "nohelper"
      ? "Per trascrivere tutto il video serve il programma per yt-dlp (popup → Video senza sottotitoli → Programma per yt-dlp)."
      : "Trascrizione completa non riuscita: " + fail.message + ".";
    setStatus(why + " Intanto trascrivo mentre guardi.");
    if (!live.running) liveStart(true, { quiet: true });
  }
}

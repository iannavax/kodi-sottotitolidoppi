## I servizi di traduzione (si scelgono dal popup, alla voce "Come tradurre")

| Servizio | Costo | Qualità | Cosa serve |
|---|---|---|---|
| Google Traduttore, frasi intere | gratis | discreta | niente |
| **Gemini** (consigliato) | gratis | ottima, capisce il discorso | chiave da aistudio.google.com/apikey, senza carta |
| Groq | gratis | buona, molto veloce | chiave da console.groq.com/keys, senza carta |
| OpenRouter (modelli :free) | gratis | varia secondo il modello | chiave da openrouter.ai/keys; poche richieste al giorno |
| DeepL | gratis fino a un limite mensile | molto alta | chiave "API Free" da deepl.com/pro-api; chiede una carta per verifica |
| Modello sul tuo computer | gratis, senza limiti | dipende dal modello e dal PC | Ollama o LM Studio installato (vedi sotto) |
| Claude | a pagamento, pochi centesimi a video | ottima | chiave da console.anthropic.com |
| YouTube riga per riga | gratis | scarsa | niente |

Come si usa una chiave: scegli il servizio, incolla la chiave e premi Invio. Il modello viene scelto da solo. Se vuoi cambiarlo, premi **Carica modelli** e clicca nel campo Modello per vedere l'elenco.

I servizi gratuiti hanno un limite di richieste al minuto. Se lo superi, l'estensione aspetta e riprova da sola, e nella riga di stato vedi il conto alla rovescia. La parte di video che stai guardando viene tradotta per prima. Le traduzioni fatte con i servizi con chiave vengono salvate, quindi se riapri lo stesso video la traduzione è subito pronta.

Nota su Gemini gratuito: Google può usare i testi inviati per migliorare i suoi modelli. Qui sono solo sottotitoli di video pubblici.

## Modello sul tuo computer

### Con Ollama
1. Installa Ollama da ollama.com.
2. Scarica un modello. Per esempio, da terminale o prompt dei comandi: `ollama pull gemma3:12b` (serve un PC con almeno 16 GB di RAM), oppure `ollama pull gemma3:4b` se il PC è meno potente.
3. Permetti le richieste dalle estensioni del browser. Senza questo passaggio Ollama le rifiuta.
   - **Windows**: apri il prompt dei comandi e scrivi `setx OLLAMA_ORIGINS "chrome-extension://*,moz-extension://*"`. Poi chiudi Ollama (icona vicino all'orologio, Quit) e riaprilo.
   - **Mac**: nel Terminale scrivi `launchctl setenv OLLAMA_ORIGINS "chrome-extension://*,moz-extension://*"`, poi chiudi e riapri Ollama.
   - **Linux**: `sudo systemctl edit ollama`, aggiungi le righe `[Service]` e `Environment="OLLAMA_ORIGINS=chrome-extension://*,moz-extension://*"`, poi `sudo systemctl restart ollama`.
4. Nel popup scegli "Modello sul tuo computer". L'indirizzo è già `http://localhost:11434/v1`. Poi premi **Carica modelli**.

### Con LM Studio
1. In LM Studio scarica un modello, poi nella sezione Developer avvia il server e attiva **Enable CORS** nelle impostazioni del server.
2. Nel popup scrivi come indirizzo `http://localhost:1234/v1` e premi **Carica modelli**.

## Se qualcosa non va
Leggi la riga di stato in fondo al popup.
- "Nessun segnale da YouTube": l'estensione non gira sulla pagina. Premi **Concedi accesso** se compare, poi ricarica YouTube.
- "Attiva su YouTube" ma non succede nulla quando premi CC: nell'ingranaggio del video cambia lingua dei sottotitoli e poi rimetti quella giusta.
- Gli altri errori indicano il servizio e il motivo, per esempio chiave non valida o limite raggiunto.

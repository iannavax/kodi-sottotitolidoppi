#!/usr/bin/env python3
# Crea il repository Kodi di Sottotitoli Doppi (da pubblicare su GitHub Pages).
# Uso: python3 crea_repository.py [nome_utente_github]   ->  cartella "kodi-sottotitolidoppi"
import hashlib, os, re, shutil, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
USER = sys.argv[1] if len(sys.argv) > 1 else "iannavax"
REPO_NAME = "kodi-sottotitolidoppi"
URL = "https://%s.github.io/%s/" % (USER, REPO_NAME)
OUT = os.path.join(HERE, REPO_NAME)
REPO_ID, REPO_VER = "repository.sottotitolidoppi", "1.0.0"

REPO_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="%(id)s" name="Sottotitoli Doppi (repository)" version="%(ver)s" provider-name="%(user)s">
  <extension point="xbmc.addon.repository" name="Sottotitoli Doppi (repository)">
    <dir>
      <info compressed="false">%(url)saddons.xml</info>
      <checksum>%(url)saddons.xml.md5</checksum>
      <datadir zip="true">%(url)s</datadir>
    </dir>
  </extension>
  <extension point="xbmc.addon.metadata">
    <summary lang="it_IT">Repository dell'add-on Sottotitoli Doppi</summary>
    <summary lang="en_GB">Repository for the Sottotitoli Doppi add-on</summary>
    <description lang="it_IT">Installa e aggiorna da solo l'add-on Sottotitoli Doppi.</description>
    <description lang="en_GB">Installs and updates the Sottotitoli Doppi add-on.</description>
    <platform>all</platform>
    <assets>
      <icon>icon.png</icon>
    </assets>
  </extension>
</addon>
"""


def version_of(addon_xml):
    return re.search(r'<addon[^>]*\sversion="([^"]+)"', addon_xml).group(1)


def zip_dir(src, addon_id, dest):
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(src):
            dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git")]
            for f in files:
                if f.endswith((".pyc", ".pyo")):
                    continue
                full = os.path.join(root, f)
                z.write(full, os.path.join(addon_id, os.path.relpath(full, src)))


def main():
    shutil.rmtree(OUT, ignore_errors=True)
    os.makedirs(OUT)
    tmp = os.path.join(OUT, "_tmp_" + REPO_ID)
    os.makedirs(tmp)
    open(os.path.join(tmp, "addon.xml"), "w", encoding="utf-8").write(
        REPO_XML % {"id": REPO_ID, "ver": REPO_VER, "user": USER, "url": URL})
    shutil.copy(os.path.join(HERE, "script.sottotitolidoppi", "icon.png"), os.path.join(tmp, "icon.png"))

    addons = [(REPO_ID, tmp), ("script.sottotitolidoppi", os.path.join(HERE, "script.sottotitolidoppi")),
              ("service.subtitles.sottotitolidoppi", os.path.join(HERE, "service.subtitles.sottotitolidoppi")),
              ("service.subtitles.subdl", os.path.join(HERE, "service.subtitles.subdl"))]
    xmls = []
    for addon_id, src in addons:
        xml = open(os.path.join(src, "addon.xml"), encoding="utf-8").read()
        ver = version_of(xml)
        d = os.path.join(OUT, addon_id)
        os.makedirs(d)
        zip_dir(src, addon_id, os.path.join(d, "%s-%s.zip" % (addon_id, ver)))
        shutil.copy(os.path.join(src, "icon.png"), os.path.join(d, "icon.png"))
        xmls.append(re.sub(r"^<\?xml[^>]*\?>\s*", "", xml.strip()))
        print("  %s %s" % (addon_id, ver))
    # il file da scegliere in Kodi ("Installa da file zip") sta anche nella cartella principale
    shutil.copy(os.path.join(OUT, REPO_ID, "%s-%s.zip" % (REPO_ID, REPO_VER)), OUT)
    shutil.rmtree(tmp)

    addons_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<addons>\n' + "\n".join(xmls) + "\n</addons>\n"
    open(os.path.join(OUT, "addons.xml"), "w", encoding="utf-8").write(addons_xml)
    open(os.path.join(OUT, "addons.xml.md5"), "w").write(hashlib.md5(addons_xml.encode("utf-8")).hexdigest())

    # pagina con il collegamento: Kodi legge i link di questa pagina quando aggiungi la "sorgente"
    zipname = "%s-%s.zip" % (REPO_ID, REPO_VER)
    open(os.path.join(OUT, "index.html"), "w", encoding="utf-8").write(
        '<!DOCTYPE html>\n<html><head><meta charset="utf-8"><title>Sottotitoli Doppi per Kodi</title></head><body>\n'
        '<h1>Sottotitoli Doppi per Kodi</h1>\n<p>In Kodi: Impostazioni &rarr; File manager &rarr; Aggiungi sorgente &rarr; '
        '<code>%s</code>. Poi Add-on &rarr; Installa da file zip &rarr; scegli questo file:</p>\n'
        '<a href="%s">%s</a>\n</body></html>\n' % (URL, zipname, zipname))
    open(os.path.join(OUT, ".nojekyll"), "w").write("")
    print("Repository pronto in %s\nIndirizzo da usare in Kodi: %s" % (OUT, URL))


if __name__ == "__main__":
    main()

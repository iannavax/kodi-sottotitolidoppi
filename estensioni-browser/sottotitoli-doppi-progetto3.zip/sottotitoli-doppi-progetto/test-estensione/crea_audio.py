# Crea i file audio usati dalle prove: /tmp/speech.wav, /tmp/big.wav, /tmp/speech.webm, /tmp/fakedeno.zip
import wave, struct, math, random, os, subprocess, zipfile
random.seed(1)
sr = 44100; out = []
for dur in [2.6, 3.8, 1.9, 5.2, 3.1, 16.0, 2.4, 4.4, 3.0, 2.2, 3.6, 2.8, 4.0, 3.3]:
    for n in range(int(dur * sr)):
        env = 0.5 + 0.5 * math.sin(2 * math.pi * 3.7 * n / sr)
        out.append(0.25 * env * (math.sin(2 * math.pi * 180 * n / sr) + 0.5 * math.sin(2 * math.pi * 420 * n / sr)) + 0.02 * random.uniform(-1, 1))
    out.extend([0.0005 * random.uniform(-1, 1) for _ in range(int(0.6 * sr))])
frames = b"".join(struct.pack("<h", int(max(-1, min(1, x)) * 32767)) for x in out)
for path, reps in (("/tmp/speech.wav", 1), ("/tmp/big.wav", 5)):
    w = wave.open(path, "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
    for _ in range(reps): w.writeframes(frames)
    w.close()
subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", "/tmp/speech.wav", "-c:a", "libopus", "-b:a", "48k", "-f", "webm", "/tmp/speech.webm"], check=True)
here = os.path.dirname(os.path.abspath(__file__))
with zipfile.ZipFile("/tmp/fakedeno.zip", "w") as z:
    z.write(os.path.join(here, "fake", "deno"), "deno")
print("creati: /tmp/speech.wav, /tmp/big.wav, /tmp/speech.webm, /tmp/fakedeno.zip")

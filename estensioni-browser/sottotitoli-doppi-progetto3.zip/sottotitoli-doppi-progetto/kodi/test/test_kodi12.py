# Prove della 1.10.8: sottotitoli di OpenSubtitles fuori fase (altra edizione, 25 fps) messi in fase con l'audio del film;
# servizio OpenSubtitles.com senza più quota: non richiamato di continuo
import sys, os, json, time, shutil, re, urllib.parse, threading, http.server, socketserver
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
if not os.path.isfile("/tmp/synct/film.mkv"):
    os.system("python3 /home/claude/kodi/test/crea_film_sync.py")
TRUTH = json.load(open("/tmp/synct/truth.json"))
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def handle(self):
        try: super().handle()
        except Exception: pass
    def do_GET(self):
        path = "/tmp/synct/film.mkv"; size = os.path.getsize(path)
        m = re.match(r"bytes=(\d+)-(\d*)", self.headers.get("Range", ""))
        a = int(m.group(1)) if m else 0; b = min(int(m.group(2)) if m and m.group(2) else size - 1, size - 1)
        self.send_response(206 if m else 200); self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(b - a + 1)); self.send_header("Content-Range", "bytes %d-%d/%d" % (a, b, size)); self.end_headers()
        with open(path, "rb") as f:
            f.seek(a); self.wfile.write(f.read(b - a + 1))
srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), H); srv.daemon_threads = True
threading.Thread(target=srv.serve_forever, daemon=True).start()
URL = "http://127.0.0.1:%d/d/XYZ/Good.Bye.Lenin.2003.1080p.mkv" % srv.server_address[1]
def srt(cues):
    f = lambda ms: "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)
    return "\n".join("%d\n%s --> %s\n%s\n" % (i + 1, f(c["s"]), f(c["e"]), c["t"]) for i, c in enumerate(cues))
def shifted(a, b):    # sottotitoli di un'altra edizione: tempo nel film = a·t + b
    return [dict(c, s=int((c["s"] / 1000 - b) / a * 1000), e=int((c["e"] / 1000 - b) / a * 1000)) for c in TRUTH]
VERSIONS = {"v1": shifted(25 / 23.976, 3.2)}
from resources.lib import core
def fake_http(url, data=None, headers=None, timeout=90):
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + l + "]" for l in q.split("\n")), q]], None, "de"]).encode(), {}
    if "opensubtitles-v3" in url:
        subs = [{"id": k, "url": "https://dl.os.example/%s.srt" % k, "lang": "ger"} for k in VERSIONS]
        return 200, json.dumps({"subtitles": subs}).encode(), {}
    m = re.match(r"https://dl\.os\.example/(\w+)\.srt", url)
    if m:
        return 200, srt(VERSIONS[m.group(1)]).encode(), {}
    if "cinemeta" in url:
        return 200, b'{"metas": [], "meta": {}}', {}
    return 404, b"", {}
core.http = fake_http
from resources.lib import runner
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra",
                           "trans_color": "FFFF00", "auto": "true", "source_mode": "file (solo sottotitoli, mai trascrizione)",
                           "trans_mode": "nuova (x)"})
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.IMDBNumber": "tt0301357", "VideoPlayer.AudioLanguage": "ger"})
def play():
    xbmc.Player.playing = True; xbmc.Player.playing_file = URL; xbmc.Player.total = 972.0
    xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": URL, "at": time.time() - 20})
    xbmc.Player.subs.clear(); xbmcgui.NOTES.clear(); xbmc.LOG.clear()
def errors():
    t = open(xbmc.Player.subs[-1], encoding="utf-8").read()
    got = {}
    for b in t.strip().split("\n\n"):
        L = b.split("\n")
        m = re.match(r"(\d+):(\d+):(\d+),(\d+)", L[1])
        got[L[2]] = (int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))) * 1000 + int(m.group(4))
    errs = sorted(abs(got[c["t"]] - c["s"]) for c in TRUTH if c["t"] in got)
    return errs[len(errs) // 2] if errs else None, len(errs)
# 1. una sola versione su OpenSubtitles, di un'altra edizione (25 fps e 3,2 s di differenza): messa in fase
play(); t0 = time.time()
runner.run(xbmc.Player(), interactive=True)
med, n = errors()
print("1. errore mediano: %s ms su %d frasi (%.1f s) | avvisi: %s" % (med, n, time.time() - t0, [x for x in xbmcgui.NOTES if "fase" in x]))
print("   ", [l for l in xbmc.LOG if "messa in fase" in l][:2])
ok1 = med is not None and med < 250 and n > 200
# 2. più versioni: sceglie quella che va con l'audio
core._OS_CACHE.clear(); VERSIONS.clear(); VERSIONS.update({"a": shifted(1.0, -20.0), "b": shifted(1.0, 0.0), "c": shifted(23.976 / 25, 1.0)})
for f in os.listdir(runner.CACHE):
    if not f.startswith("energia-"): os.remove(os.path.join(runner.CACHE, f))
for f in os.listdir(runner.PROFILE):
    if f.startswith("scelte"): os.remove(os.path.join(runner.PROFILE, f))
play(); runner.run(xbmc.Player(), interactive=True)
med2, n2 = errors()
print("2. tre versioni: errore mediano %s ms | avvisi: %s" % (med2, xbmcgui.NOTES[:3]))
ok2 = med2 is not None and med2 < 250
# 3. già in fase: non sposta niente (e l'audio non si rilegge: è salvato)
print("3. energia salvata:", any(f.startswith("energia-") for f in os.listdir(runner.CACHE)))
ok3 = any(f.startswith("energia-") for f in os.listdir(runner.CACHE))
# 4. servizio OpenSubtitles.com senza quota: segnato e non richiamato
calls = []
def rpc(req):
    calls.append(req["params"].get("directory", req["method"]))
    if req["method"] == "Addons.GetAddons":
        return {"result": {"addons": [{"addonid": "service.subtitles.opensubtitles-com", "name": "OpenSubtitles.com"}]}}
    d = req["params"].get("directory", "")
    if "action=search" in d:
        return {"result": {"files": [{"label": "Italian", "file": "plugin://service.subtitles.opensubtitles-com/?action=download&id=1"},
                                     {"label": "Italian", "file": "plugin://service.subtitles.opensubtitles-com/?action=download&id=2"}]}}
    return {"result": {"files": []}}          # quota finita: nessun file
xbmc.RPC_HANDLER = rpc
o = {"k": "service", "u": "plugin://service.subtitles.opensubtitles-com/?action=download&id=1", "l": "it", "src": "OpenSubtitles.com"}
try:
    runner.fetch_online(o)
except Exception as e:
    print("4. primo tentativo:", e)
print("   segnato:", runner.service_down("service.subtitles.opensubtitles-com"), "| servizi ancora usati:", runner.subtitle_services())
ok4 = runner.service_down("service.subtitles.opensubtitles-com") and runner.subtitle_services() == []
print("ESITO:", bool(ok1 and ok2 and ok3 and ok4))
srv.shutdown()

import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini'}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_CHIAVE_DI_PROVA_123', gemini:'AIza-prova'}}))")
        ext = sw.url.split('/')[2]
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.set_viewport_size({"width": 360, "height": 640})
        await pp.goto(f"chrome-extension://{ext}/popup.html"); await pp.wait_for_timeout(800)
        await pp.evaluate("document.querySelectorAll('details').forEach(d=>d.open=true); const w=navigator.clipboard.writeText.bind(navigator.clipboard); navigator.clipboard.writeText=(t)=>{window.__copied=t; return w(t).catch(()=>{})}")
        box = pp.locator("#groqKey").locator("xpath=..")
        print("1. tipo casella Groq:", await pp.get_attribute("#groqKey", "type"), "| pulsanti:", await box.locator("button").all_inner_texts())
        await box.locator("button", has_text="Mostra").click()
        print("2. dopo 'Mostra':", await pp.get_attribute("#groqKey", "type"), await pp.input_value("#groqKey"))
        await box.locator("button", has_text="Copia").click(); await pp.wait_for_timeout(300)
        print("3. dopo 'Copia':", await box.locator("button").nth(1).inner_text(), "| appunti:", await pp.evaluate("window.__copied"))
        kb = pp.locator("#key-gemini").locator("xpath=..")
        await kb.locator("button", has_text="Copia").click(); await pp.wait_for_timeout(300)
        print("4. chiave Gemini copiata:", await pp.evaluate("window.__copied"))
        print("5. chiave ancora salvata:", await sw.evaluate("chrome.storage.local.get('keys').then(r=>r.keys.groq)"))
        r = await pp.evaluate("""(()=>{const W=document.body.clientWidth; return [...document.querySelectorAll('input,button')].filter(e=>{const b=e.getBoundingClientRect(); return b.width>0 && b.right>W+1}).map(e=>e.id||e.textContent)})()""")
        print("6. fuori dal popup:", r, "| errori:", errs)
        await pp.evaluate("document.getElementById('groqKey').scrollIntoView({block:'center'})")
        await pp.screenshot(path="/tmp/claude-0/key.png")
        await ctx.close()
asyncio.run(main())

# -*- coding: utf-8 -*-
# Sottotitoli Doppi per Kodi - collegamento con Kodi (lettore, file, finestre, impostazioni)
import base64
import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import core

ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name")
ICON = ADDON.getAddonInfo("icon")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CACHE = os.path.join(PROFILE, "cache")
_busy = threading.Lock()


def log(msg):
    xbmc.log("[%s] %s" % (NAME, msg), xbmc.LOGINFO)


def notify(msg, ms=5000):
    xbmcgui.Dialog().notification(NAME, msg, ICON, ms)


def settings():
    a = xbmcaddon.Addon()
    keys = ["target", "engine", "layout", "trans_color", "auto", "transcribe", "transcribe_always", "stt", "stt_url",
            "stt_model", "stt_lang", "groq_key", "openai_key", "ffmpeg"]
    for e in ("gemini", "groq", "openrouter", "deepl", "claude", "local"):
        keys += [e + "_key", e + "_model", e + "_url"]
    s = {k: a.getSetting(k) for k in keys}
    s["target"] = (s["target"] or "it").split(" ")[0]
    s["engine"] = (s["engine"] or "google").split(" ")[0]
    s["stt_lang"] = (s["stt_lang"] or "").split(" ")[0] if s["stt_lang"] not in ("", "auto") else ""
    s["auto"] = s["auto"] != "false"
    s["transcribe"] = s["transcribe"] == "true"
    s["transcribe_always"] = s["transcribe_always"] == "true"
    s["stt"] = (s["stt"] or "groq").split(" ")[0]
    s["layout"] = {"Originale sopra": "orig_top", "Traduzione sopra": "trans_top", "Solo traduzione": "trans_only"}.get(
        s["layout"], s["layout"] or "orig_top")
    s["groq_key"] = s["groq_key"] or s.get("groq_key", "")
    return s


# ---------------------------------------------------------------------- file
def read_text(path):
    f = xbmcvfs.File(path)
    try:
        data = f.readBytes()
    finally:
        f.close()
    data = bytes(data)
    for enc in ("utf-8-sig", "utf-16", "cp1252", "latin-1"):
        try:
            text = data.decode(enc)
            if enc == "utf-16" and "-->" not in text and "Dialogue" not in text:
                continue
            return text
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "replace")


VIDEO_EXT = (".mkv", ".mp4", ".avi", ".mov", ".m4v", ".wmv", ".ts", ".m2ts", ".webm", ".mpg", ".mpeg", ".flv")


def list_subs(folder, max_age_h=None, strict=False):
    """strict: file da accettare solo se scaricati adesso o con il nome del video (vedi core.pick_subtitle)"""
    out = []
    try:
        _, files = xbmcvfs.listdir(folder)
    except Exception:
        return out
    now = time.time()
    for f in files:
        if not f.lower().endswith(core.SUB_EXT):
            continue
        p = folder.rstrip("/\\") + ("\\" if "\\" in folder and "://" not in folder else "/") + f
        try:
            mtime = xbmcvfs.Stat(p).st_mtime()
        except Exception:
            mtime = 0
        if max_age_h and mtime and now - mtime > max_age_h * 3600:
            continue
        out.append((p, mtime, strict))
    return out


def _many_videos(folder):
    try:
        _, files = xbmcvfs.listdir(folder)
    except Exception:
        return False
    return sum(1 for f in files if f.lower().endswith(VIDEO_EXT)) > 1


def candidates(video):
    found = []
    if video and not video.startswith(("http://", "https://", "plugin://", "pvr://")):
        folder = os.path.dirname(video) if "://" not in video else video.rsplit("/", 1)[0]
        # in una cartella con più film, un sottotitolo con un altro nome può essere di un altro film
        shared = _many_videos(folder)
        found += list_subs(folder, strict=shared)
        found += list_subs(folder.rstrip("/\\") + "/Subs", strict=shared) + list_subs(folder.rstrip("/\\") + "/subs", strict=shared)
    # sottotitoli scaricati con gli add-on di Kodi (OpenSubtitles & co.): solo quelli di questo film
    for t in ("special://temp/", "special://temp/subtitles/"):
        found += list_subs(t, max_age_h=12, strict=True)
    return found


# ---------------------------------------------------------------------- video in corso
START_PROP = "sottotitolidoppi.start"


def mark_start(player):
    """Chiamata dal servizio all'avvio di ogni video: ricordo quando è cominciato e quale file è"""
    try:
        xbmcgui.Window(10000).setProperty(START_PROP, json.dumps({"file": player.getPlayingFile(), "at": time.time()}))
    except Exception:
        pass


def playback_since(player, video):
    """Da quando stai guardando questo video (meno 2 minuti di margine per i sottotitoli scaricati all'avvio)"""
    at = 0
    try:
        p = json.loads(xbmcgui.Window(10000).getProperty(START_PROP) or "{}")
        if p.get("file") == video:
            at = p.get("at", 0)
    except Exception:
        pass
    if not at:
        try:
            at = time.time() - player.getTime()
        except Exception:
            at = time.time()
    return at - 120


def current_sub_lang(player):
    """Lingua dei sottotitoli scelti nel lettore (per preferire il file in quella lingua)"""
    try:
        return core.FILE_TAGS.get((player.getSubtitles() or "").lower().split("-")[0], "")
    except Exception:
        return ""


def find_source(player, video, target):
    return core.pick_subtitle(candidates(video), video, target, since=playback_since(player, video),
                              prefer_lang=current_sub_lang(player))


def embedded_streams(video, s):
    """Tracce di sottotitoli di testo dentro il file (solo file sul dispositivo, serve ffmpeg)"""
    if not video or ("://" in video and not video.startswith("special://")):
        return []
    ffmpeg = core.find_ffmpeg(s.get("ffmpeg", ""))
    if not ffmpeg:
        return []
    real = xbmcvfs.translatePath(video) if "://" in video else video
    return [x for x in core.list_sub_streams(ffmpeg, real) if x[3]]


def extract_stream(video, s, index):
    """Salva la traccia incorporata come .srt nella cache e ne restituisce il percorso"""
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, "traccia-%s-%d.srt" % (core.cache_key(video), index))
    if not os.path.isfile(path):
        real = xbmcvfs.translatePath(video) if "://" in video else video
        text = core.extract_sub_stream(core.find_ffmpeg(s.get("ffmpeg", "")), real, index)
        open(path, "w", encoding="utf-8").write(text)
    return path


# ---------------------------------------------------------------------- lavoro principale
def run(player, manual_path=None, force_transcribe=False, interactive=False, upgrade=False):
    """upgrade: chiamata dal menu dei sottotitoli del lettore dopo la versione veloce di Google:
    traduce con il servizio scelto e cambia i sottotitoli solo alla fine, senza versioni a metà."""
    if not _busy.acquire(False):
        if interactive:
            notify("Sto già preparando i sottotitoli doppi…")
        return
    progress = None
    try:
        if not player.isPlayingVideo():
            if interactive:
                notify("Avvia prima un video")
            return
        video = player.getPlayingFile()
        s = settings()
        target = s["target"]
        os.makedirs(CACHE, exist_ok=True)

        # trascrizione dell'audio: chiesta dal menu, impostata "sempre" (i sottotitoli originali a volte
        # non corrispondono a quello che si sente), oppure perché mancano i sottotitoli
        always = not manual_path and (force_transcribe or s["transcribe_always"])
        source = None if always else (manual_path or find_source(player, video, target))
        if not source and not always:
            # nessun file: provo le tracce di sottotitoli dentro il video (quella nella lingua scelta nel lettore)
            streams = embedded_streams(video, s)
            if streams:
                want = current_sub_lang(player)
                pick = next((x for x in streams if want and x[1] == want), None) or \
                    next((x for x in streams if x[1] != target), None)
                if pick:
                    try:
                        source = extract_stream(video, s, pick[0])
                    except Exception as e:
                        log("traccia incorporata non letta: %r" % e)
        use_whisper = always or (not source and s["transcribe"])
        if not source and not use_whisper:
            if interactive or s["auto"]:
                notify("Nessun sottotitolo trovato per questo video: scaricane uno con un add-on di sottotitoli, "
                       "oppure apri Sottotitoli Doppi per sceglierlo o trascrivere l'audio.", 9000)
            return

        progress = xbmcgui.DialogProgressBG()
        progress.create(NAME, "Preparo i sottotitoli…")

        # --- testo originale
        if source:
            cues = core.parse_subs(read_text(source))
            src_lang = core.lang_from_filename(source) or core.guess_lang_cues(cues)
            src_id = source + "|" + str(len(cues))
        else:
            extra = () if s["stt"] == "groq" and s.get("stt_model", "") in ("", "whisper-large-v3-turbo") else (s["stt"], s.get("stt_model", ""))
            tkey = core.cache_key("trascrizione", video, s.get("stt_lang", ""), *extra)
            tpath = os.path.join(CACHE, tkey + ".json")
            if os.path.isfile(tpath):
                saved = json.load(open(tpath, encoding="utf-8"))
                cues, src_lang = saved["cues"], saved["lang"]
            else:
                work = os.path.join(CACHE, "audio-" + tkey)
                os.makedirs(work, exist_ok=True)
                try:
                    cues, src_lang = core.transcribe(
                        video, s, work,
                        on_progress=lambda n, tot: progress.update(int(5 + 45 * n / max(1, tot)), NAME,
                                                                   "Trascrivo l'audio: pezzo %d di %d" % (n + 1, tot)),
                        should_stop=lambda: not player.isPlayingVideo())
                finally:
                    for f in os.listdir(work):
                        os.remove(os.path.join(work, f))
                    os.rmdir(work)
                json.dump({"cues": cues, "lang": src_lang}, open(tpath, "w", encoding="utf-8"), ensure_ascii=False)
            src_id = "trascrizione"
        if not cues:
            notify("Nei sottotitoli non ho trovato frasi da tradurre.")
            return
        if src_lang and src_lang == target:
            notify("I sottotitoli sono già nella lingua in cui traduci.")
            return

        # --- traduzione (salvata: rivedendo il video è subito pronta)
        model = s.get(s["engine"] + "_model", "")
        key = core.cache_key(video, src_id, target, s["engine"], model)
        jpath = os.path.join(CACHE, key + ".json")
        out = os.path.join(CACHE, "%s.doppi.%s.srt" % (key, target))
        write = lambda trans: open(out, "w", encoding="utf-8").write(
            core.make_dual_srt(cues, trans, s["layout"], s["trans_color"] or "FFFF00"))

        if os.path.isfile(jpath):
            trans = json.load(open(jpath, encoding="utf-8"))["trans"]
        else:
            state = {"shown": False}

            def on_batch(partial):
                # appena è pronto il pezzo che stai guardando, carico già i sottotitoli
                # (non quando migliora una versione già completa fatta con Google)
                if not state["shown"] and not upgrade:
                    state["shown"] = True
                    write([t or "" for t in partial])
                    player.setSubtitles(out)
                    player.showSubtitles(True)

            start_ms = int(player.getTime() * 1000) if player.isPlayingVideo() else 0
            trans = core.translate_all(
                cues, s, target, src_lang, start_ms,
                on_progress=lambda d, tot: progress.update(int(50 + 50 * d / max(1, tot)), NAME, "Traduco: %d di %d frasi" % (d, tot)),
                on_batch=on_batch, should_stop=lambda: not player.isPlayingVideo())
            if player.isPlayingVideo():
                json.dump({"trans": trans}, open(jpath, "w", encoding="utf-8"), ensure_ascii=False)
        write(trans)
        if player.isPlayingVideo() and (not upgrade or player.getPlayingFile() == video):
            player.setSubtitles(out)
            player.showSubtitles(True)
            notify(("Traduzione migliorata con %s pronta" % s["engine"].capitalize()) if upgrade
                   else "Sottotitoli doppi pronti (%d frasi)" % len(cues), 3000)
    except core.Fatal as e:
        notify(str(e), 8000)
    except Exception as e:
        log("errore: %r" % e)
        notify("Errore: %s" % e, 8000)
    finally:
        if progress:
            progress.close()
        _busy.release()

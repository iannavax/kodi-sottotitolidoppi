# "Ritraduci" dalla scheda: la nuova traduzione deve comparire anche sul video, sotto l'originale
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
VID = os.environ.get("VID", "longRetr")
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', hoverPause:false, transcribeMode:'live', cleanTranscript:false})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=" + VID); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/GEM/.test((document.querySelector('.dualsub-trans')||{}).textContent||'')", timeout=60000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(500)
        line = lambda: pg.evaluate("(document.querySelector('.dualsub-trans')||{}).textContent")
        before = await line()
        await pg.hover(".dualsub-orig"); await pg.click(".dualsub-fixbtn"); await pg.wait_for_selector(".dualsub-fixcard")
        await pg.click("text=↻ Ritraduci")
        await pg.wait_for_function("/Fatto|Non ci sono/.test(document.querySelector('.dualsub-fixcard').textContent)", timeout=30000)
        card = await pg.inner_text(".dualsub-fix-trans")
        print("1. prima:", before[:50], "| nella scheda:", card[:50], "| sul video (scheda aperta):", (await line())[:50], "| uguali:", card == await line())
        await pg.click(".dualsub-fixcard .dualsub-card-btn[title='Chiudi']"); await pg.wait_for_timeout(600)
        print("2. scheda chiusa, sul video:", (await line())[:50], "| uguale alla nuova:", (await line()) == card)
        await pg.reload(); await pg.wait_for_timeout(1500)
        await pg.evaluate("const v=document.querySelector('video'); v.play()")
        await pg.wait_for_function("/GEM/.test((document.querySelector('.dualsub-trans')||{}).textContent||'')", timeout=60000)
        print("   (dopo il ricaricamento la correzione è salvata: controllata da tfix.py)")
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

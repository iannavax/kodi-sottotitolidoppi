# 1.5.1: modi di dire. «Non è un modo di dire» si annulla dalla scheda di una sua parola (🚫 … annulla); «✎ Correggi
# il modo di dire» cambia l'espressione stessa (non solo il significato).
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
os.environ["ALIGN_WHOLE"] = "1"
from charness import *
IDI = "[...document.querySelectorAll('.dualsub-orig .dualsub-idiom')].map(x=>x.textContent)"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', ipa:false, hoverPause:true, idioms:true, learnExamples:false, learnSpell:false})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=sd515"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        W = lambda t: words.nth(texts.index(t))
        await W("fresh").hover(); await pg.wait_for_timeout(6000)
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(900)
        a = await pg.evaluate(IDI); print("1. sottolineati:", a)
        await W("fresh").hover(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-card .dualsub-idiom-fix .dualsub-card-link").first.click(); await pg.wait_for_timeout(300)
        print("   opzioni:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-idiom-fixbox button')].map(b=>b.textContent)"))
        await pg.locator(".dualsub-card .dualsub-idiom-fixbox button", has_text="Non è un modo di dire").click(); await pg.wait_for_timeout(600)
        b = await pg.evaluate(IDI); print("2. dopo «non è un modo di dire»:", b)
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(900)
        await W("fresh").click(); await pg.wait_for_timeout(1500)
        row = await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-idiom-flagged')||{}).innerText||''")
        print("3. scheda di «fresh»:", row)
        await pg.locator(".dualsub-card .dualsub-idiom-flagged .dualsub-card-link", has_text="annulla").first.click(); await pg.wait_for_timeout(800)
        c = await pg.evaluate(IDI); print("4. dopo «annulla»:", c)
        # correggo l'espressione stessa
        await pg.keyboard.press("Escape"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(900)
        await W("fresh").hover(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-card .dualsub-idiom-fix .dualsub-card-link").first.click(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-card .dualsub-idiom-fixbox button", has_text="Correggi il modo di dire").click(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-card .dualsub-idiom-fixbox input.dsx-input").fill("really fresh bread")
        await pg.locator(".dualsub-card .dualsub-idiom-fixbox textarea.dsx-input").last.fill("pane appena sfornato")
        await pg.locator(".dualsub-card .dualsub-idiom-fixbox button", has_text="Salva").last.click(); await pg.wait_for_timeout(800)
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(900)
        d = await pg.evaluate(IDI); print("5. dopo la correzione:", d)
        await W("bread").hover(); await pg.wait_for_timeout(1500)
        card = (await pg.evaluate("(document.querySelector('.dualsub-card')||{}).innerText||''")).replace("\n", " | ")
        print("   scheda di «bread»:", card[:200])
        ok = a and not b and "annulla" in row and c and sorted(c) == sorted(a) and "really" in d and "pane appena sfornato" in card
        print("errori:", errs if ok else errs + ["correzioni dei modi di dire non vanno"], log["errors"])
        await ctx.close()
asyncio.run(main())

import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:true, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(4000)
        rows = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-dialrow')].map(r=>r.innerText.replace(/\\n/g,' '))")
        print("varianti:", rows)
        print("IPA principale:", await pg.evaluate("(document.querySelector('.dualsub-card-ipa')||{}).textContent"))
        # menu del popup: nascondo l'americano e le altre etichette
        eid = sw.url.split("/")[2]
        pp = await ctx.new_page(); await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1200)
        await pp.evaluate("for (let e = document.getElementById('ipaVarBox'); e; e = e.parentElement) if (e.tagName === 'DETAILS') e.open = true")
        print("menu varianti inglese:", await pp.evaluate("[...document.querySelectorAll('#ipaVarList label')].map(l=>l.textContent.trim()).slice(0,6)"))
        await pp.locator("#ipaVarList label", has_text="americano").locator("input").uncheck(); await pp.wait_for_timeout(600)
        print("   salvato:", await sw.evaluate("chrome.storage.sync.get('ipaVar').then(r=>JSON.stringify(r.ipaVar))"))
        await pg.keyboard.press("Escape"); await pg.mouse.click(5, 5); await pg.wait_for_timeout(500)
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(3500)
        rows2 = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-dialrow')].map(r=>r.innerText.replace(/\\n/g,' '))")
        print("senza americano:", rows2)
        print("errori:", errs if len(rows) >= 4 and len(rows2) == len(rows) - 1 and not any("americano" in r for r in rows2) else errs + ["varianti non mostrate / menu non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

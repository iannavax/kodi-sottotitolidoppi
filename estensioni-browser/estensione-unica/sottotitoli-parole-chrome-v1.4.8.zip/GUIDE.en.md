*Version 1.4.8*

# Sottotitoli Doppi + Parole al Volo — browser extension

*Versione italiana → [LEGGIMI](LEGGIMI.md)*

**Learn languages by watching videos and reading.** One extension for two things:

- **🎬 in videos** (Sottotitoli Doppi): under the original subtitles you see the translation in your language, in a different colour. Every word can be hovered to see its meaning in that sentence, hear it and save it to your personal vocabulary. It works on YouTube and on almost every website with video or audio; if a video has no subtitles, the extension listens to the audio and writes them itself;
- **📄 on web pages and PDFs** (Parole al Volo): hover a word on any page to get its card; select some text to translate it all at once.

Vocabulary, known words, service keys, voices and Anki are shared by both.

Browsers: **Edge, Chrome, Brave** (and other Chromium-based browsers) and **Firefox**.

> **Interface language.** The extension's menus are in Italian. Tick **Interfaccia in questa lingua** (*interface in this language*) under **Traduci in** (*translate into*) in the popup and the whole interface — popup, cards, pages — is shown in the language you translate into (translated once with Google Translate and remembered). In this guide buttons are written as they appear in Italian, in **bold**, followed by their meaning.

---

## Contents

1. [What it does](#1-what-it-does)
2. [Installing and updating](#2-installing-and-updating)
3. [Getting started (5 minutes)](#3-getting-started-5-minutes)
4. [The popup: Video and Pages](#4-the-popup-video-and-pages)
5. [Where it works](#5-where-it-works)
6. [Subtitles on the video](#6-subtitles-on-the-video)
7. [Learning with words](#7-learning-with-words)
8. [On web pages](#8-on-web-pages)
9. [PDF files](#9-pdf-files)
10. [Your vocabulary](#10-your-vocabulary)
11. [Videos without subtitles: transcribing the audio](#11-videos-without-subtitles-transcribing-the-audio)
12. [The "Trascrizione e traduzione" page](#12-the-trascrizione-e-traduzione-page)
13. [Translation services](#13-translation-services)
14. [Using fewer free requests](#14-using-fewer-free-requests)
15. [A translation model on your own computer](#15-a-translation-model-on-your-own-computer)
16. [Troubleshooting](#16-troubleshooting)
17. [Privacy](#17-privacy)

---

## 1. What it does

| Feature | What you get |
|---|---|
| 🎬 **Two lines** | Original on top, translation below (or the other way round), right on the video. |
| 🧠 **Translation that follows the conversation** | With Gemini and the other AI models, each line is translated with the surrounding lines in mind. |
| 👆 **Interactive words** | Hover a word to see its meaning; **✨ Spiega con…** (*explain with…*) gives the full explanation in that sentence. |
| 🔗 **Translation ↔ original** | Hover a translated word and the original word it comes from lights up. Articles and prepositions that only the translation needs are marked. |
| 🗣️ **Pronunciation** | Hear any word; the video volume drops automatically while it speaks. |
| ⭐ **Vocabulary** | Save words and expressions with their sentence and the moment in the video; export everything to Anki. |
| 🎙️ **Audio transcription** | Video without subtitles? The audio is transcribed with Whisper (free with a Groq key). |
| 📄 **Full text** | A page with the whole text of the video, to read, copy or download (.txt, .srt). |
| ✏️ **Corrections** | Redo or fix a badly translated or transcribed line with one click. |
| 💸 **Low usage** | Everything is saved: watching a video again costs nothing. If a free service runs out of requests, another one takes over automatically. |
| 📄 **Web pages** | On any page: word card on hover, translation of the text you select. |
| 📕 **PDF** | A PDF reader of its own with the same cards (scanned books too, when they contain recognised text). |

---

## 2. Installing and updating

### Edge, Chrome, Brave
1. Unzip `sottotitoli-parole-chrome-vX.Y.Z.zip` into a folder you **won't delete** (for example `Documents\Sottotitoli Doppi`).
2. Open `edge://extensions` (in Chrome: `chrome://extensions`).
3. Turn on **Developer mode**.
4. Click **Load unpacked** and choose the folder from step 1.
5. Pin the extension icon to the toolbar (puzzle icon → pin) so the popup is one click away.

### Firefox
1. Unsigned extensions only install in **Firefox Nightly** or **Developer Edition**: in `about:config` set `xpinstall.signatures.required` to **false**.
2. Open `about:addons`, click the gear ⚙ → **Install Add-on From File…** and choose `sottotitoli-parole-firefox-vX.Y.Z.xpi`.
3. In `about:addons` → the extension → **Permissions**, "Access your data for all websites" must be on. If **Concedi accesso** (*grant access*) appears in the popup, click it.

### Updating without losing anything
- **Edge/Chrome:** unzip the new version **into the same folder**, replacing the old files, then click ↻ on the extension's card in `edge://extensions` and reload open tabs.
- **Firefox:** install the new .xpi over the old one.

> ⚠️ **Never remove the extension to update it**: removing it also deletes your keys, saved translations and vocabulary.

### Videos and audio files on your computer
For files opened in the browser (addresses starting with `file:///`): in `edge://extensions` open the extension's **Details** and turn on **Allow access to file URLs**.

### If you used the two separate extensions
Sottotitoli Doppi and Parole al Volo are no longer released separately: this one replaces both. It starts empty:
1. install it next to the old ones (don't remove them yet);
2. bring over your **known words** and **vocabulary**: here press **⇄ Sincronizza adesso** on the **Parole che conosco** page and **⇄ Sincronizza con le altre estensioni** in the vocabulary (needs Sottotitoli Doppi 5.20.1 / Parole al Volo 1.13.1 or later), or use **Esporta in un file** in the old one and **Importa da un file…** here;
3. **keys** and **settings** come along with ⇄ (only those you haven't set here yet);
4. for the yt-dlp helper: open its page from the popup (🎬 Video → Video senza sottotitoli → Programma per yt-dlp) and run the installer again;
5. when everything works, remove the old two: with both active, cards appear twice.

---

## 3. Getting started (5 minutes)

1. **Open the popup** (click the extension icon) and at the top choose **Traduci in** (*translate into*): your language.
2. Under **Traduzione → Come tradurre** (*translation → how to translate*) leave **Google Traduttore** to start straight away, with no keys.
3. Open a YouTube video in the language you're learning and turn on subtitles (**CC**). The two lines appear.
4. Hover a word in the original line: the video pauses and a card shows its meaning.

**For much better translations (recommended, free):**
1. Go to **aistudio.google.com/apikey** with your Google account and click *Create API key* (no credit card needed).
2. In the popup choose **Come tradurre → Gemini**, paste the key into **Chiave API** (*API key*) and press Enter. The model is chosen automatically.

**For videos without subtitles** you also need a free **Groq** key: see [section 11](#11-videos-without-subtitles-transcribing-the-audio).

---

## 4. The popup: Video and Pages

The extension button opens the popup with two tabs at the top; it reopens on the last tab you used.

- **🎬 Video**: everything about videos (subtitles, appearance, transcription, live streams, subtitle translation service, pronunciation, Anki…).
- **📄 Pagine** (*pages*): web pages and PDFs (card on hover, translation of selected text, PDF reader, service for explaining words…). See [section 8](#8-on-web-pages).

Shared by both: service keys, the language you translate into (and the interface language), **vocabulary**, **known words**, voices, Anki, the yt-dlp helper. Separate: the chosen service (in videos it translates subtitles, on pages it explains words; until you pick one under Pages, the Video one is used), disabled sites, the single Anki deck, the colour of known words on pages, the «Aa» Latin letters.

---

## 5. Where it works

- **YouTube**, including YouTube videos embedded in other websites.
- **Any website with video or audio**: Vimeo, VK, news sites, podcasts, online courses, live TV sites. If the video has its own subtitles they are used and translated; otherwise you can have them transcribed.
- **Media files opened directly in the browser**, from a link or from your computer (mp4, webm, mp3, m4a, ogg, wav, flac…): transcription starts by itself when you press Play.
- **It does not work** on DRM-protected sites (Netflix, Disney+, Prime Video…): the browser doesn't let extensions listen to their audio. The popup's status line tells you.
- To turn the extension off on a particular site: popup → **Altro** (*more*) → turn off activation on that site.

---

## 6. Subtitles on the video

### Turning them on and off: the DS button
- **On YouTube** there's a **DS** button in the player's control bar, next to CC. **On other sites** it's a small "DS" in the top-right corner of the video.
- **On** (yellow border): dual subtitles are shown. **Off**: they disappear and transcription stops, so no quota is used.
- If the dual subtitles disappear for any reason, press DS and they come back.
- The same switch is in the popup: **Altro → Sottotitoli doppi attivi**.

### The two buttons next to the subtitles
Hover the subtitles and two buttons appear on the right:
- **⚑ — Wrong line?** Opens a card with:
  - **↻ Ritraduci** (*translate again*): asks for that line's translation again (it jumps the queue);
  - **🎙 Ritrascrivi** (*transcribe again*, only for transcribed lines): Whisper listens to that line again with its most accurate model;
  - **✎ Correggi a mano** (*correct by hand*): type the right original and/or translation yourself;
  - **✕ Togli** (*remove*): for invented lines, e.g. during music.

  Corrections are saved with the video and are included in downloaded files.
- **⧉ — Copy or look up the line.** Pauses the video and shows the line, which you can select with the mouse:
  - **Copia originale**, **Copia traduzione**, **Copia tutte e due** (*copy original / translation / both*): if you select part of the text, only that part is copied;
  - **Apri in: Google Traduttore · DeepL · Reverso** (*open in*): the line (or the selected part) opens in a new tab with the languages already set. Reverso shows words inside many real sentences. For language pairs Reverso can't open directly (e.g. Czech), the text is copied: just paste it into Reverso's box.

### Appearance
Popup → **Aspetto dei sottotitoli** (*subtitle appearance*): what to show (both lines, original only, translation only), translation above or below, text size and translation size, colours, background, height on the video, font. Changes show immediately; **Ripristina l'aspetto predefinito** restores the defaults.

Popup → **Altro → Nascondi i sottotitoli del sito**: hides the site's own subtitles so you don't see them twice.

---

## 7. Learning with words

### The word card
- **Hover** a word in the original line: the video pauses and a card shows its meaning from Google's dictionary (free, no quota used).
- **Click** the word: the card stays open, with Google's meaning (no tokens used).
- **✨ Spiega con …** (*explain with…*, the button in the card): asks your chosen service (Gemini, Groq, Mistral, Claude…) for **its meaning in that sentence**: base form (e.g. *went → go*), part of speech, explanation and an example, plus pronunciation and etymology if missing. One request, **only when you press the button**: the model never starts by itself.
- On the card:
  - **🔈** pronunciation with the synthetic voice (the code next to it, e.g. *DA*, shows the language); when a real recording of the word exists (Wiktionary), **🔊** appears next to it. Everywhere: **🔊** = real recording, **🔈** = synthetic voice;
  - **☆** save to your vocabulary;
  - **↺ Riascolta la frase** (*replay the line*): goes back to the start of the line and stops at the end;
  - **Copia la parola / Copia la frase** (*copy word / line*);
  - **Apri in:** Google Translate, DeepL, Reverso, **WordReference** (between English and Italian, Spanish, French, German, Portuguese) and **Wiktionary** (explains almost any word in almost any language).
- Close the card with **×** or **Esc**. When you move the mouse away from the subtitles the video resumes (you can turn this off: **Altro → Pausa quando passi sulle parole**).
- Explanations are saved even after closing the browser: the same word in the same sentence is never requested twice.

### Learning tools
**Google dictionary** (same request as the translation, free): translations ranked by usage with reverse translations on hover, definitions in the word's own language, synonyms and "see also", and "Did you mean…" in the spelling check. Definitions also come from the Wiktionary edition of the word's language (or English Wiktionary), each with **translate**. **Aa** next to the subtitles shows Latin letters above each letter of Cyrillic, Greek, Armenian, Georgian, Hebrew, Japanese kana and Korean (above each word for Arabic, Persian, Urdu, Hindi): built-in tables, no service; kanji/Chinese lines get a whole-line reading from Google (free). Anki images can be checked and changed before saving (‹ ›, «altre…», ✕) and in the vocabulary (🖼); sources in popup → Anki. **Parole che conosco** (popup) opens the frequency list with import/export and **⇄ Sincronizza adesso** (direct sync of known words with Parole al Volo, no file); **⇄** in the vocabulary page moves vocabulary and known words to and from Parole al Volo. Level badges are clickable: «livello ≈ B1 ›» (indicative A1–C2 from the frequency rank) opens the words of that level, and for Japanese «JLPT N5 ›» opens the whole JLPT level word list (Jisho). **Kanji / Chinese characters one by one**: in the card of a Japanese or Chinese word, «Kanji uno per uno» has a button per character; it shows that character alone (meaning, readings in every language — on/kun, pinyin, Cantonese, Korean, Vietnamese —, clickable parts and radical, simplified/traditional form, strokes, JLPT/grade, HSK, Korean school hanja) with «scheda del carattere ›» to open it as a word (vocabulary, Anki) and «‹ Torna alla parola» to go back. Free (built-in Unihan/KANJIDIC/HSK data + Google), no model requests; «☆ salva il kanji» / «☆ salva tutti i kanji» save the single characters to the vocabulary. **↺** left of the subtitles replays the sentence, or (yellow) jumps back to the sentence you were reading while the video moved on. **Live streams ahead of time** (popup → videos without subtitles): on YouTube live streams the video is kept a few seconds behind while yt-dlp reads the audio ahead, so transcribed subtitles appear on time (needs the yt-dlp helper with ffmpeg). An orange **🔊\*** means the recording is of another form of the word. **⚑ Wrong translation?** under the meaning lets you redo it with Google or the model, or fix it by hand.

Below the meaning, the word card shows extra help, all **free and without keys**; each one can be switched off in the popup → **Strumenti per imparare**: word **frequency**, **"la conosco?"** (known words turn green in the subtitles and the popup shows what percentage of the video's words you know), noun **gender**, a **spelling check** (LanguageTool or the dictionary; when you click the word, the model also gives a 0-100 score in the same request), the word's **etymology**, a **native speaker recording** (the 🔊 button at the top of the card) and a **conjugation/declension table** (Wiktionary), and up to 3 **real example sentences** (Tatoeba). Clicking the word, the single request to the model also brings **false friends** and **related words**. Next to "↺ Riascolta la frase" there are **🐢 slow** and **🔁 ×3**. Optional (off by default): an **image** from Wikimedia Commons on your Anki cards.

### From the translation back to the original
- **Hover a word in the translation**: the original word it comes from lights up and a label shows it. Click → card for the original word.
- By default Google makes the link (free, approximate: the label says "circa"). Turn on **Altro → Modi di dire e collegamento preciso con il modello** in the popup to have the AI model make it precise (one request every 8 lines, while hovering).
- **Particles**: articles, prepositions and auxiliaries that the translation adds but that don't translate any original word are **dotted-underlined**. Hover one and the "particella" label tells you which part of the original it belongs to.
- **The other way round**: hovering an original word highlights its translation (particles more faintly); without the model, Google dictionary translations of the word are used, matched even with a different ending.

### Phrases and expressions
- **Idioms**: with an AI model, expressions that can't be translated word by word (*break the ice*, *give up*…) are **underlined in orange**. Hover one and the whole expression lights up with its real meaning. (Only with the option above turned on; off by default.)
- **Select in the original**: press on the first word and drag to the last → card with the meaning of the whole expression.
- **Select in the translation**: drag across several translated words → the matching part of the original lights up; the label offers **Spiega** (*explain*), **Copia** (*copy*) and the lookup links. Close with Esc.

### Pronunciation
**Voice per language**: ⚙ next to 🔈 in the word card lets you pick the voice for that language (saved). **Azure Speech** (free key, 500,000 characters a month): Microsoft's "Natural" voices in any browser, Firefox included — popup → Pronuncia delle parole.

The language is taken from the word or the video. The voice is your computer's (Edge's "Natural" voices are excellent); if missing, Google's online voice is used. While it speaks, the video is turned down and then restored.

Popup → **Pronuncia delle parole** (*word pronunciation*): language (searchable list of 98 languages), voice, **Prova la voce** (*test the voice*).

---

## 8. On web pages

On any page (articles, Wikipedia, online books…) words in another language have their card. Over video subtitles these cards don't appear: the ones from [section 7](#7-learning-with-words) are already there.

- **Hover a word** (stay still a moment): the card shows the word, its translation and Google's dictionary, **IPA pronunciation** and Latin-letter transcription for other alphabets, **etymology** from Wiktionary (following the chain back to the root, even through other languages; for inflected forms taken from the parent word when the link is certain), the **sentence** with its translation, 🔈/🔊 to listen, ☆ to save, copy buttons and links to Google Translate, DeepL, Reverso, WordReference and Wiktionary, plus the same learning tools as in videos.
- With a **Gemini or Groq** key, **"Spiega con Gemini"** (*explain with…*, one request) gives the meaning *in that sentence*, the base form, whether it's part of an idiom, an example, and in the same request etymology, IPA, false friends (only real ones, compared with words of your language), related words and a spelling score. Everything is written in the language you translate into: an answer in the wrong language is asked again or dropped.
- **Idioms**: the card reports the idiom the word belongs to (the other words get a light dashed underline); it is remembered, and **☆ Salva il modo di dire** (*save the idiom*) puts it in your vocabulary.
- **Selecting several words** opens a panel with the translation of the whole text, transcription, IPA on request, listening, ☆ and Anki; with a model also **"Traduci meglio"** (*translate better*).
- **⚑ Traduzione sbagliata?** (*wrong translation?*): redo with Google or with the model, correct by hand (saved), or change the detected language (also for the whole site).
- Popup → 📄 Pagine: master switch (**Alt+Shift+Y**), **card on hover** (**Alt+Shift+M**) and **translation when selecting** (**Alt+Shift+S**), per-site switch, text language, when the card appears and after how long, colour of the words you know.
- Requests: Google is free; the model only when you press its buttons.

---

## 9. PDF files

The browser's PDF viewer doesn't let extensions in, so the extension has its own reader (Mozilla's pdf.js) with the same cards and selection translation.

- Popup → 📄 Pagine → **«📄 Apri questo PDF con Parole al Volo»** when the tab shows a PDF, or **«📄 Lettore PDF»** → «📂 Apri un PDF…» for a file on your computer; **«Apri sempre i PDF con Parole al Volo»** opens every PDF there automatically.
- **Wrong characters** («Pøíliš», «P¯ÌliöÌ», «Ïðèâåò» instead of «Příliš», «Привет»): many older PDFs store text in one encoding but declare another. The reader notices and fixes it by itself (Central European, Cyrillic, Greek, Turkish, Baltic, Hebrew, Arabic, Thai, Vietnamese, Mac and DOS encodings, double-encoded UTF-8, Chinese/Japanese/Korean); the bar says which encoding it fixed, and **«Caratteri»** lets you choose by hand. Accents written separately (LaTeX: «ˇcesk´y») are joined to their letter.
- **Scanned books** (archive.org, Google Books…): the pages are images (JBIG2, JPEG 2000) and are shown; when the PDF contains the recognised text (OCR), cards work too.

---

## 10. Your vocabulary

- On a word or expression card press **☆**: it's saved with the sentence, its translation and the moment in the video.
- Saved words are **underlined in light blue** in the subtitles of every video.
- Popup → **Il mio vocabolario** (*my vocabulary*): search, reopen the video at the right moment, mark a word as learned (it's no longer highlighted) or delete it.
- **Esporta per Anki** (*export for Anki*): downloads a text file. In Anki: *File → Import* → choose the file (note type "Basic"). Front: the word with its sentence; back: meaning, translation and link to the video.

---

## 11. Videos without subtitles: transcribing the audio

If a video has no subtitles, the extension listens to the audio and transcribes it with **Whisper**; the lines are then translated like any others, with interactive words.

### One-time setup
1. Create a free key at **console.groq.com/keys** (no credit card).
2. Popup → **Video senza sottotitoli → Chiave Groq** (*videos without subtitles → Groq key*): paste it and press Enter.

### Three ways to transcribe (popup → Video senza sottotitoli)
- **Mentre guardo** (*while watching*): transcribes what you're watching, a few seconds behind. A quick Google translation appears first (slightly transparent) and is then replaced by your chosen service's translation.
- **Completa** (*complete*): as soon as you open the video, the whole audio is downloaded and transcribed in chunks, starting from where you are. Subtitles stay in sync even when you skip around. On YouTube, Vimeo and similar sites it needs the **yt-dlp helper** (below); direct media files don't.
- **Spenta** (*off*): doesn't start by itself; start it with **Trascrivi l'audio di questo video** (*transcribe this video's audio*).

You can choose a **default mode** and a different one **for this video**. "Completa solo fino a… minuti" (*complete only up to… minutes*) prevents a long film opened by mistake from using up your quota.

### The yt-dlp helper (only for "Completa" on YouTube and similar)
Browsers don't let extensions download audio from YouTube, so a small helper program is installed once.
1. Popup → **Video senza sottotitoli → Programma per yt-dlp**.
2. Download the installer and run it (on Windows double-click; if Windows warns you: *More info → Run anyway*).
3. Go back to the page and press the check button: it must say it is installed and working.

It updates itself. The audio is only used for transcription and then deleted (YouTube's terms don't allow downloading videos).

### Transcription language
- **Lingua parlata** (*spoken language*): leave it on automatic detection. The extension decides the language from the first chunks with enough speech and then **forces it on Whisper**, so it doesn't switch languages or write an English translation instead of a transcription. Real language changes in the video are still followed.
- If Whisper gets a video's language wrong, choose it yourself (the list has a search box).

### Corrected transcription
**Correggi la grammatica della trascrizione** (*correct the transcription's grammar*, on by default): misheard words are fixed before translation. With Gemini and the other AI models this happens in the same request as the translation; with Google or DeepL, Gemini (or Groq) does it in batches.

### Transcribing on your own computer
With a Whisper server compatible with the OpenAI API (e.g. Speaches): **Trascrizione con → Server sul tuo computer**, its address (usually `http://localhost:8000/v1`) and model.

### Firefox
To capture audio Firefox has to mute the video; the extension immediately sends the sound back to your speakers. If you hear nothing or transcription doesn't start, click the video once.

---

## 12. The "Trascrizione e traduzione" page

Open it from the popup with **Trascrizione e traduzione** (*transcription and translation*). It contains the whole text of the current video.

- **Testo unico** (*single text*): original and translation in paragraphs (or just one of them), for reading.
- **Frase per frase (e correzioni)** (*line by line, with corrections*): every line with its time and the buttons **⧉** (copy), **↻** (translate again), **🎙** (transcribe again), **✎** (correct), **✕** (remove).
- **Select and copy**: select part of the text with the mouse → a bar appears above it with **Copia** (*copy*) and links to Google Translate, DeepL, Reverso (if you select in the translation, the direction is reversed). The page never redraws while you're selecting.
- **Copia il testo** (*copy the text*), **Scarica testo (.txt)**, **Sottotitoli originali / tradotti / doppi (.srt)**: to keep them or use them in another player.
- **Trascrivere un file intero** (*transcribe a whole file*): from your computer or from the tab's video, without watching it. Works even with no video open.
- **Carica sottotitoli da file (.srt, .vtt)**: for films that come with separate subtitle files.
- **Rifai la traduzione / Rifai la trascrizione** (*redo the translation / transcription*): deletes what's saved for the video and does it again (your manual corrections are kept).

### Translating with a chat, without using any quota
1. Press **Copia trascrizione** (*copy transcription*): it copies the numbered lines with instructions (long videos in parts of 250 lines: the button tells you which part it will copy).
2. Paste them into a chat (ChatGPT, Claude, Gemini…) and copy its answer.
3. Press **Incolla traduzione** (*paste translation*), paste the answer and confirm. The extension reads the numbered lines, checks that it really is a translation and uses it on the video. It stays saved.

---

## 13. Translation services

Choose in the popup: **Traduzione → Come tradurre**. Pick the service, paste its key into **Chiave API**, press Enter: the model is chosen automatically (to change it: **Carica modelli**, *load models*).

| Service | Cost | Quality | What you need |
|---|---|---|---|
| Google Translate | free | fair | nothing |
| **Gemini** ⭐ recommended | free | excellent, follows the conversation | key from aistudio.google.com/apikey |
| Groq | free | good, very fast | key from console.groq.com/keys (the same as for transcription) |
| Mistral | free | good, great for European languages | key from console.mistral.ai |
| OpenRouter | free (":free" models) | varies | key from openrouter.ai/keys |
| Microsoft Translator | free up to 2 million characters a month | very good | Azure account, "Translator" resource on the F0 plan: key and **region** (e.g. *westeurope*) |
| DeepL | free up to a monthly limit | very high | "API Free" key from deepl.com/pro-api (asks for a card for verification) |
| Model on your computer | free, unlimited | depends on your PC | Ollama or LM Studio ([section 15](#15-a-translation-model-on-your-own-computer)) |
| Claude | paid (a few cents per video) | excellent | key from console.anthropic.com |
| YouTube line by line | free | poor | nothing |

Gemini, Groq, Mistral, OpenRouter, Claude and local models are **AI language models**: besides translating, they understand the conversation, explain words in context, find idioms and correct transcriptions. Google, Microsoft and DeepL are **classic translators**: they translate well but don't do the rest.

Keys can be shown and copied with the **Mostra** (*show*) and **Copia** (*copy*) buttons next to the box (handy for the Kodi add-on). Don't show them in videos or screenshots: anyone who sees a key can use it.

### Backup services
With **Se finiscono le richieste gratuite, continua con un altro servizio di cui hai la chiave** (*if free requests run out, continue with another service you have a key for*, on by default), when a service uses up its daily quota the extension carries on with the first other service you've entered a key for, in the order set under **Ordine dei servizi** (by default **Gemini → Groq → Mistral → OpenRouter → Ollama/LM Studio → Claude → Microsoft → DeepL**), and finally **Google**. The exhausted service is skipped until the next day.

### Model for each task
At the top of the section there is one menu per job: **video subtitles**, **page and PDF text**, **audio transcription**, **explanations («✨ Spiega con…»)**, **transcript correction**, **IPA for selected text** and **word and idiom linking**. «Automatico» uses the first ready model in the queue below; if the chosen model doesn't answer or is out of requests for today, the first ready one replaces it.

### Service order
Below, **Ordine dei servizi** (*service order*) lists every service with its state (ready, key missing, model missing, used up for today):
- **↑ ↓** change the order; unticking the **box** removes a service from the queue;
- **Usa adesso** (*use now*) moves it to the top and selects it right away for translating too, then runs a test;
- **Prova** (*test*) translates a sample sentence and shows *✓ Funziona* (with the translation and the seconds taken) or *✗ Non funziona* with the reason (for Ollama: program not running, OLLAMA_ORIGINS missing, no model chosen…).

The order is used for backup services, for **✨ Spiega con…** (when translating with Google, DeepL or Microsoft, the first ready model in the queue — only when you press the button), for IPA pronunciation and for transcript correction. To try Ollama: choose «Modello sul tuo computer», press «Carica modelli», then **Usa adesso**.

**Spiegazioni («✨ Spiega con…») con** (*explanations with*): a model used only for explanations, different from the subtitle one. For example subtitles with **Gemini** (fast) and explanations with **Ollama** (on your computer: no limits, no requests used up). If the chosen model doesn't answer or is out of requests for today, the first ready model in the queue explains instead, and the card says so; after 5 minutes the chosen one is tried again.

Models that "think" before answering (Gemma 4, Qwen 3…: Ollama shows "Thinking…") answer without the reasoning when used by the extension, much faster. If your computer struggles (fans, external screen dropping out), use a smaller model such as `gemma4:e2b`.

To enter several keys: choose a service, paste its key, then switch back to your preferred service. Below the box you'll see which backup services are ready and which are used up for today.

---

## 14. Using fewer free requests

- **Nothing is translated twice**: translations, transcriptions, explanations and corrections are all saved. Watching a video again, even one you only partly watched, costs nothing.
- Translations are requested in **groups of 120 lines**: a two-hour film costs about 12 Gemini requests.
- Hovering uses Google's free dictionary; the AI model is only used when you click.
- Gemini's default model is **gemini-flash-lite-latest**, the one with the most free daily requests.
- Gemini quotas reset at midnight Pacific Time. You can see your usage at aistudio.google.com.
- For a whole film without touching any quota: **Copia trascrizione / Incolla traduzione** with a chat ([section 12](#12-the-trascrizione-e-traduzione-page)).

---

## 15. A translation model on your own computer

Free, unlimited and private. You need a reasonably powerful PC (16 GB of RAM recommended).

### With Ollama
1. Install Ollama from **ollama.com**.
2. Download a model: `ollama pull gemma3:12b` (or `gemma3:4b` on a less powerful PC).
3. Allow requests from the browser (without this Ollama refuses them):
   - **Windows**: in a command prompt `setx OLLAMA_ORIGINS "chrome-extension://*,moz-extension://*"`, then quit Ollama (icon near the clock → Quit) and start it again;
   - **Mac**: `launchctl setenv OLLAMA_ORIGINS "chrome-extension://*,moz-extension://*"`, then restart Ollama;
   - **Linux**: `sudo systemctl edit ollama`, add `[Service]` and `Environment="OLLAMA_ORIGINS=chrome-extension://*,moz-extension://*"`, then `sudo systemctl restart ollama`.
4. In the popup choose **Modello sul tuo computer** (*model on your computer*, address `http://localhost:11434/v1`) and press **Carica modelli**.

### With LM Studio
Download a model, start the server in the *Developer* section and turn on **Enable CORS**. In the popup enter the address `http://localhost:1234/v1` and press **Carica modelli**.

---

## 16. Troubleshooting

First look at the **status line at the bottom of the popup**: it says what the extension is doing and why it stopped.

| What you see | What to do |
|---|---|
| "Nessun segnale da YouTube" (*no signal from YouTube*) | Press **Concedi accesso** (*grant access*) if it appears, then reload the page. |
| Dual subtitles don't appear | Check that **DS** is on and the video's subtitles (CC) are on. On YouTube, if that's not enough, change the subtitle language in the gear menu and switch it back. |
| "Hai finito i minuti di trascrizione" (*transcription minutes used up*, Groq) | Groq's free Whisper quota is used up (hourly or daily): the message says when it frees up. Lines already transcribed stay. |
| "Limite di richieste raggiunto" (*request limit reached*) | The service refused because you exceeded its quota: the extension waits and retries (per-minute limit) or switches to a backup service (daily limit). Nothing is lost. |
| "Chiave non valida" (*invalid key*) | Copy the key again (use **Mostra** to check it). |
| Transcription in the wrong language | Set **Lingua parlata**, then on the "Trascrizione e traduzione" page press **Rifai la trascrizione**. |
| A line is badly translated or transcribed | **⚑** button on the subtitles → translate again, transcribe again or correct by hand. |
| Netflix, Disney+, Prime Video | Not possible: the browser protects these sites' audio. |
| Firefox: the video stays muted | Click the video once. |
| No card on web pages | Check in popup → 📄 Pagine the master switch, card on hover, translation when selecting and the per-site switch; reload pages that were open before installing. Browser internal pages don't allow extensions. |
| A PDF opens without cards | Open it in the extension's reader ([section 9](#9-pdf-files)); if words look wrong try «Caratteri»; a scan without recognised text has no words to read. |
| Cards appear twice | The old separate extensions are still on: remove them. |

---

## 17. Privacy

- Your keys and everything you save (translations, vocabulary, corrections) stay **in your browser**. There is no server behind the extension.
- Text is only sent to the services you choose (Google, Gemini, Groq…). On free plans some services (e.g. Gemini) may use the text to improve their models.
- The yt-dlp helper downloads audio only to transcribe it and deletes it straight away.

---

## What's new

- **1.4.8**: **📈 usage over time** shows again: on pages the curve disappeared and the years were black (the cards' base style wiped the drawing), and sites with their own drawing rules (YouTube too) could do the same; now colours and shapes are fixed on the chart. removed the «/no_think» added in 1.4.7: Ollama's `qwen3:4b` is the Qwen 3 version that always reasons and took it as text to translate. Now **Prova**, when the local model is slow because it reasons before every answer, says so and suggests a model without reasoning (e.g. `gemma3:4b`).
- **1.4.7**: **Qwen 3 on your computer** no longer "thinks" before answering (before, with some Ollama versions, it wrote thousands of words of reasoning and took over a minute even for «good morning»): the extension adds Qwen's own switch, `/no_think`, which works with every version.
- **1.4.6**: **Whisper on your computer** (Speaches, faster-whisper-server…): if the server doesn't know the model name (the default one is Groq's: before, every chunk failed with «il modello scelto non esiste più» and no subtitles appeared), the extension reads the server's models, picks the best (turbo) and remembers it; the popup has **Carica modelli** for transcription too. **Model on your computer** (Ollama, LM Studio): if the model written in the popup is gone (e.g. deleted), it picks an installed one and remembers it; if there is none it says so, with the command to download one.
- **1.4.5**: **📈 usage over time** like the real chart: data from the 2022 Google Books collection (the one Ngram Viewer shows, up to 2022), a smooth curve instead of straight segments (no more steps and climbs that looked like glitches). **Modello per ogni compito** (*model for each task*) in the popup (above «Ordine dei servizi»): one menu per job, i.e. video subtitles, page and PDF text, audio transcription (Groq's Whisper or on your computer), explanations, transcript correction, IPA for selected text, word and idiom linking. «Automatico» uses the first ready model in the queue; a chosen model that doesn't answer or is out of requests is replaced by the first ready one. For example: subtitles with Gemini, explanations and pronunciation with Ollama, correction with Groq.
- **1.4.4**: **📈 usage over time**: bigger, readable years, and the source below (Google Books Ngram Viewer) with «Apri il grafico completo ↗» (*open the full chart*). **🌳 real Wiktionary etymology trees** in every language, read from the data Wiktionary puts in the page (before, it came out empty, e.g. for *embarazado*). It reads top to bottom, from the oldest origin to the word: each step with the language, the word, the transliteration and the meaning, and between steps how it came (borrowing, learned borrowing, inherited, derived…); compound words («embarazado è formata da: embarazar + -ado») have each part's origin in a box that opens; influences are shown apart. **Synced live**: if yt-dlp sends no audio, after 20 s the log says so (with yt-dlp's last message) and after 60 s the mode stops and the video goes back to live, instead of staying half-way forever; the yt-dlp helper (1.3, re-run the installer) updates yt-dlp before reading a live stream.
- **1.4.3**: **synced live**: subtitles no longer drift later during fast speech (each sentence appears exactly at its moment) and, when the audio read by yt-dlp shifts, sentences already prepared are re-timed too; the ⏱ notice above the subtitles is no longer squeezed (it wrapped after every word); when YouTube only jumps back part of the way, the rest is made up with a short pause (before, the video ended up too far behind), and alignment is no longer interrupted by a second jump too early. **📈 uso nel tempo** (*usage over time*) is clearer: years under the chart in the right place, a scale («times per million words»), a summary (peak year, trend over the last 50 years) and, on hover, each year's value.
- **1.4.2**: **Service order** in the popup: move models up and down, turn them off, **Usa adesso** selects a service immediately (e.g. Ollama) and **Prova** tells you whether it answers. The **📖 Google dictionary** is removed (Google no longer provides it: it answered «400»); **📈 uso nel tempo** (*usage over time*) stays as its own button. **Spiegazioni con** (*explanations with*) a model different from the subtitle one (e.g. Gemini for subtitles and Ollama for explanations). Explanations from slow models (Ollama on your computer) no longer stop with «Receiving end does not exist»: the extension waits even for minutes. In the etymology tree, the parts of a word (e.g. на- + -чина́ть) go in a «formata da: …» line and are no longer mixed with the ancestors. **synced live**: when YouTube won't jump back, the video pauses for those seconds (with a countdown) and resumes behind the live edge instead of turning the mode off; live streams no longer restart from scratch (losing the subtitles) every time YouTube reloads the stream. **🌳 Etymology tree** almost always (built from Wiktionary's etymology chain, with cognates). **Recordings from the lemma** (and from the Google dictionary). **🔍 cerca radice** also suggests words with the same root and the "see also" words. The **📖 Google dictionary** now says why when it doesn't answer.
- **1.4.1**: **🌳 etymology trees** from Wiktionary in the card (branches from the oldest root down to the word; the Google dictionary image when Wiktionary has none); no more Groq error «max_tokens must be less than or equal to 4096» (it retries with the model's limit by itself); an **idiom** is shown only if it really is part of the sentence, in its language (never a translated expression); **the model never starts by itself**: in videos the explanation comes only with the **✨ Spiega con …** (*explain with…*) button (before, clicking a word asked the model); model-based translation↔original linking and idioms are off by default (turn them on in the popup), and without the model hovering an original word still highlights its translation (Google dictionary). **📖 Google dictionary** in the card (the one in Google Search, Oxford Languages data): recorded pronunciation, meanings with examples, synonyms and antonyms, word forms, origin with the etymology tree when available, and **📈 uso nel tempo** (*use over time*, Google Books Ngram); its origin is used when Wiktionary has no etymology (🌳 tree button). Not an official Google service: if Google changes it, the row simply doesn't appear. Also: etymology taken from the parent word for inflected forms (cases, verb tenses: *подошве* → *подошва*), only when the link is certain — Wiktionary says it's a form of it, or the form really appears in the parent word's declension/conjugation table. The card says where it comes from; **⚑ → lemma sbagliato?** (*wrong lemma?*) lets you type the right one, or none; **🔍 cerca radice** (*search for the root*) lists the Wiktionary words containing that form, with ✓ on the certain ones, to pick with one click.
- **1.4.0** (from now on only this extension is released, with this single guide):
  - **Interface in the language you translate into** (tick **Interfaccia in questa lingua** in the popup).
  - **Explanations always in your language**: an answer in another language is asked again or dropped; a false friend appears only when it is real and concerns a word of your language.
  - **Idioms remembered** in the card even when a redone explanation leaves them out, and **☆ Salva il modo di dire** to save them.
  - **Fuller etymologies**: the Wiktionary chain is followed back to the root, across languages too.
  - **PDF**: wrong characters fixed for all common encodings (including PDFs made with Word on the Mac); scanned books from archive.org no longer show blank pages.
- **1.3.0**: translations in the wrong language (e.g. Arabic) are rejected, with "redo the whole translation" in ⚑; sturdier synced live streams; first fix for Czech PDFs.

# 1.7.5: la scheda dei sottotitoli si ridimensiona dai bordi e dagli angoli; grandezza ricordata; doppio clic sulla maniglia ⠿ = come prima
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
BOX = "(() => { const c = document.querySelector('.dualsub-card'); if (!c) return null; const r = c.getBoundingClientRect(); return {l: r.left, t: r.top, w: r.width, h: r.height}; })()"
async def drag(pg, idx, dx, dy):
    b = await pg.locator(".dsx-rzh").nth(idx).bounding_box()
    x, y = b["x"] + b["width"] / 2, b["y"] + b["height"] / 2
    await pg.mouse.move(x, y); await pg.mouse.down(); await pg.mouse.move(x + dx / 2, y + dy / 2, steps=4); await pg.mouse.move(x + dx, y + dy, steps=4); await pg.mouse.up()
    await pg.wait_for_timeout(500)
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2000)
        n = await pg.locator(".dsx-rzh").count()
        b0 = await pg.evaluate(BOX)
        print("1. maniglie:", n, "| scheda:", {k: round(v) for k, v in b0.items()})
        await drag(pg, 7, 90, 70)   # angolo in basso a destra
        b1 = await pg.evaluate(BOX)
        print("2. angolo in basso a destra +90/+70:", {k: round(v) for k, v in b1.items()}, "| l uguale:", abs(b1["l"] - b0["l"]) < 2)
        await drag(pg, 3, -60, 0)   # bordo sinistro verso sinistra: più larga, il bordo destro resta
        b2 = await pg.evaluate(BOX)
        print("3. bordo sinistro -60:", {k: round(v) for k, v in b2.items()}, "| bordo destro fermo:", abs((b2["l"] + b2["w"]) - (b1["l"] + b1["w"])) < 2)
        await drag(pg, 0, 0, 40)    # bordo alto verso il basso: più bassa, il bordo in basso resta
        b3 = await pg.evaluate(BOX)
        print("4. bordo alto +40:", {k: round(v) for k, v in b3.items()}, "| fondo fermo:", abs((b3["t"] + b3["h"]) - (b2["t"] + b2["h"])) < 2)
        u = await sw.evaluate("chrome.storage.local.get('cardUser').then(r => r.cardUser)")
        print("5. salvato:", u)
        # un'altra scheda: stessa grandezza
        await pg.mouse.click(5, 5); await pg.wait_for_timeout(500)
        await pg.keyboard.press("Escape"); await pg.wait_for_timeout(300)
        other = texts[0] if texts[0] != "bread" else texts[1]
        await words.nth(texts.index(other)).click(); await pg.wait_for_timeout(2000)
        b4 = await pg.evaluate(BOX)
        print("6. scheda di «%s»:" % other, {k: round(v) for k, v in b4.items()})
        # doppio clic sulla maniglia ⠿: grandezza e posizione di prima
        await pg.locator(".dualsub-card-grip").dblclick(); await pg.wait_for_timeout(800)
        b5 = await pg.evaluate(BOX)
        print("7. dopo il doppio clic su ⠿:", {k: round(v) for k, v in b5.items()}, "| grandezza ricordata:", await sw.evaluate("chrome.storage.local.get('cardUser').then(r => r.cardUser)"))
        # chiusa la scheda, le maniglie spariscono
        await pg.mouse.click(5, 5); await pg.keyboard.press("Escape"); await pg.wait_for_timeout(500)
        ok = n == 8 and b1["w"] - b0["w"] > 60 and b1["h"] - b0["h"] > 40 and abs(b1["l"] - b0["l"]) < 2 and b2["w"] - b1["w"] > 40 and abs((b2["l"] + b2["w"]) - (b1["l"] + b1["w"])) < 2 \
            and b1["h"] - b3["h"] > 20 and u and u.get("video", {}).get("w") and abs(b4["w"] - b3["w"]) < 3 and b5["w"] < b4["w"] - 40
        print("maniglie rimaste dopo la chiusura:", await pg.locator(".dsx-rzh").count())
        print("errori:", errs if ok else errs + ["ridimensionamento non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

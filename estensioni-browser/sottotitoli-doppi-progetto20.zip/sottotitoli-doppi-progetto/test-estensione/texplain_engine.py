# 1.4.2: sottotitoli con Gemini, spiegazioni con Ollama («Spiegazioni con»); Ollama spento → la fila
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
MEAN = "(document.querySelector('.dualsub-card .dualsub-card-meaning')||{}).textContent"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', models:{local:'gemma4:e4b'}, targetLang:'it', ipa:false, learnExamples:false, learnSpell:false, learnFreq:false, learnLlmExtra:false})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1200)
        print("1. scelte:", await pp.evaluate("[...document.querySelector('.ds-explain-engine').options].map(o=>o.textContent)"))
        await pp.select_option(".ds-explain-engine", "local"); await pp.wait_for_timeout(400)
        print("   salvato:", await sw.evaluate("chrome.storage.sync.get(['explainEngine','engine']).then(r=>[r.explainEngine, r.engine])"))
        await pp.close()
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        print("2. sottotitolo tradotto:", await pg.evaluate("(document.querySelector('.dualsub-trans')||{}).textContent"))
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        print("3. pulsante:", await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-explainbtn')||{}).textContent"))
        n0 = len(log.get("ollama", []))
        await spiega(pg, 4000)
        await pg.wait_for_timeout(4000)
        print("4. spiegazione:", await pg.evaluate(MEAN), "| richieste a Ollama:", len(log.get("ollama", [])) - n0, "| a Gemini:", len([c for c in log.get("gcalls", []) if c[1] == 200]))
        print("   scheda:", (await pg.evaluate("(document.querySelector('.dualsub-card')||{}).innerText||''")).replace("\n", " | ")[:400])
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

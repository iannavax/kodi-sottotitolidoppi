# 1.4.5: «Pronuncia IPA del testo selezionato» con il modello scelto nel popup (ipaEngine = Ollama finto)
import asyncio, os, sys, json, re
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
OLL = []
async def handle(route, request):
    if request.url.startswith("http://localhost:11434/"):
        OLL.append(request.url)
        b = json.loads(request.post_data or "{}")
        user = " ".join(m.get("content", "") for m in b.get("messages", []) if m.get("role") == "user")
        words = sorted(set(re.findall(r"[A-Za-z]{2,}", user)))
        return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": json.dumps({"ipa": {w: "/" + w.lower() + "/" for w in words}})}}]}))
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza'}}).then(()=>chrome.storage.sync.set({targetLang:'it', ipa:true, ipaEngine:'local', models:{local:'gemma4:e4b'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/pagina.html"); await pg.wait_for_timeout(800)
        b1 = await tvolo.word_box(pg, "long", "The"); b2 = await tvolo.word_box(pg, "long", "fire")
        await pg.mouse.move(b1["l"] + 1, b1["y"]); await pg.mouse.down(); await pg.mouse.move(b2["r"], b2["y"], steps=8); await pg.mouse.up()
        await pg.wait_for_timeout(2500)
        btn = pg.get_by_role("button", name="Pronuncia IPA")
        print("1. pulsante:", await btn.count())
        if await btn.count(): await btn.first.click(); await pg.wait_for_timeout(2500)
        print("2. richieste a Ollama:", len(OLL), "| riquadro:", (await tvolo.card_text(pg)).replace("\n", " | ")[:250])
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

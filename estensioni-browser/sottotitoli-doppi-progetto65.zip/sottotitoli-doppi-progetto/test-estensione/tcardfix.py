# 1.7.24: con la scheda aperta, la barra di YouTube che si nasconde non fa scendere la scheda
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
BOX = "(() => { const c = document.querySelector('.dualsub-card'); if (!c) return null; const r = c.getBoundingClientRect(); return [Math.round(r.top), Math.round(r.bottom)]; })()"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2000)
        a = await pg.evaluate(BOX)
        await pg.evaluate("document.getElementById('movie_player').classList.add('ytp-autohide')"); await pg.wait_for_timeout(900)
        b = await pg.evaluate(BOX)
        print("scheda con i comandi visibili:", a, "| dopo che YouTube li nasconde:", b)
        await pg.evaluate("document.querySelector('.dualsub-overlay').classList.remove('dualsub-cardopen')"); await pg.wait_for_timeout(900)
        print("(controllo: senza la regola nuova la scheda si sposta)", await pg.evaluate(BOX))
        print("errori:", errs if a == b else errs + ["la scheda si è mossa"], log["errors"])
        await ctx.close()
asyncio.run(main())

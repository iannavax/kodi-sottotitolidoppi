import sys, time, json
sys.argv = [sys.argv[0]] + sys.argv[1:]
from harness import *

with sync_playwright() as p:
    ctx, sw = launch(p)
    ext_id = sw.url.split("/")[2]
    sw.evaluate("chrome.storage.sync.set({engine:'google', hoverPause:true, targetLang:'it'})")
    page = ctx.new_page()
    errs = []
    page.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errs.append("PAGEERROR " + str(e)))
    page.goto("https://www.youtube.com/watch?v=capsA")
    page.evaluate("document.querySelector('video').play()")
    page.wait_for_selector(".dualsub-orig .dualsub-word", timeout=15000)
    page.wait_for_function("document.querySelector('.dualsub-trans') && document.querySelector('.dualsub-trans').textContent.includes('IT[')", timeout=15000)
    print("1. originale:", page.inner_text(".dualsub-orig"))
    print("   traduzione:", page.inner_text(".dualsub-trans"))
    print("   nativi nascosti:", page.evaluate("getComputedStyle(document.querySelector('.ytp-caption-window-container')).display"))

    # passo il mouse su una parola
    word = page.locator(".dualsub-orig .dualsub-word").nth(1)
    wtext = word.inner_text()
    word.hover()
    page.wait_for_selector(".dualsub-card-meaning", timeout=10000)
    print("2. scheda per", repr(wtext), "->", page.inner_text(".dualsub-card-meaning"), "| fonte:", page.inner_text(".dualsub-card-source"))
    print("   video in pausa durante hover:", page.evaluate("document.querySelector('video').paused"))

    # clic sulla parola: non deve arrivare al player
    clicks_before = page.evaluate("window.__playerClicks||0")
    word.click()
    print("   clic arrivati al player:", page.evaluate("window.__playerClicks||0") - clicks_before, "| video ancora in pausa:", page.evaluate("document.querySelector('video').paused"))

    # salvo nel vocabolario
    page.click(".dualsub-star")
    page.wait_for_function("document.querySelector('.dualsub-star').textContent === '★'", timeout=5000)
    vocab = sw.evaluate("chrome.storage.local.get('vocab').then(r => r.vocab)")
    e = list(vocab.values())[0]
    print("3. salvata:", e["word"], "|", e["meaning"], "| frase:", e["sentence"], "| t=", e["time"])
    page.wait_for_selector(".dualsub-word.dualsub-saved", timeout=5000)
    print("   parola evidenziata nei sottotitoli:", page.locator(".dualsub-word.dualsub-saved").first.inner_text())

    # chiudo la scheda e sposto il mouse fuori: il video riparte
    page.click(".dualsub-card-btn[title='Chiudi']")
    page.mouse.move(500, 100)
    page.wait_for_timeout(900)
    print("4. scheda chiusa:", page.locator(".dualsub-card").count() == 0, "| video ripartito:", not page.evaluate("document.querySelector('video').paused"))

    # riascolta la frase
    page.wait_for_selector(".dualsub-orig .dualsub-word", timeout=10000)
    page.locator(".dualsub-orig .dualsub-word").first.click()
    page.wait_for_selector(".dualsub-card-replay")
    t_before = page.evaluate("document.querySelector('video').currentTime")
    page.click(".dualsub-card-replay")
    page.mouse.move(500, 100)
    page.wait_for_timeout(300)
    print("5. riascolta: da", round(t_before, 1), "s a", round(page.evaluate("document.querySelector('video').currentTime"), 1), "s")

    # pagina del vocabolario ed esportazione Anki
    vp = ctx.new_page()
    vp.goto(f"chrome-extension://{ext_id}/vocab.html")
    vp.wait_for_selector(".entry")
    print("6. vocabolario:", vp.inner_text("#count"), "|", vp.inner_text(".entry .word"), vp.inner_text(".entry .meaning"))
    with vp.expect_download() as dl:
        vp.click("#export")
    path = dl.value.path()
    print("   file Anki:", dl.value.suggested_filename)
    print("   " + open(path, encoding="utf-8").read().replace("\n", "\n   "))

    # popup
    pp = ctx.new_page()
    perr = []
    pp.on("pageerror", lambda e: perr.append(str(e)))
    pp.goto(f"chrome-extension://{ext_id}/popup.html")
    pp.wait_for_timeout(800)
    print("7. popup:", pp.inner_text("#vocabBtn"), "| errori popup:", perr)
    print("errori nella pagina:", [x for x in errs if "favicon" not in x], "| errori mock:", log["errors"])
    ctx.close()

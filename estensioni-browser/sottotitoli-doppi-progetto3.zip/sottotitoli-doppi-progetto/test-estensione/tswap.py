# Video CON sottotitoli (nella lingua sbagliata): trascrizione avviata a mano, poi il sito cambia la sorgente
# del video (come YouTube quando cambia qualità o dopo una pubblicità). La trascrizione deve continuare.
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', transcribeMode:'live', cleanTranscript:false})
          .then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e))); msgs = []; pg.on("console", lambda m: msgs.append(m.text) if "SD-" in m.text else None)
        await pg.goto("https://www.youtube.com/watch?v=capsSwap"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(1500)
        tid = await sw.evaluate("chrome.tabs.query({}).then(t=>t.find(x=>(x.url||'').includes('capsSwap')).id)")
        send = lambda m: sw.evaluate(f"chrome.tabs.sendMessage({tid}, {json.dumps(m)})")
        st = await send({"type": "live", "action": "start"})
        print("1. avvio a mano su video con sottotitoli:", st.get("running"))
        await pg.wait_for_timeout(16000)
        n1 = len(log["groq"])
        print("   richieste a Groq dopo 17 s:", n1, "| sul video:", await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent"))
        # il sito sostituisce la sorgente del video (stesso punto)
        await pg.evaluate("""(async()=>{const v=document.querySelector('video'); const t=v.currentTime;
            const b=await (await fetch('/media/speech.wav')).blob(); v.src=URL.createObjectURL(b);
            await new Promise(r=>v.addEventListener('loadedmetadata',r,{once:true})); v.currentTime=t; await v.play();})()""")
        await pg.wait_for_timeout(22000); print("   eventi:", msgs)
        n2 = len(log["groq"])
        print("2. dopo il cambio di sorgente, richieste nuove a Groq in 22 s:", n2 - n1, "| sul video:", await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent"))
        print("   stato:", await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)"))
        # ricarico la pagina: la scelta di trascrivere questo video deve restare
        await pg.reload(); await pg.wait_for_timeout(1500)
        await pg.evaluate("const v=document.querySelector('video'); v.currentTime=3; v.play()"); await pg.wait_for_timeout(4000)
        st = await send({"type": "liveState"})
        print("3. dopo aver ricaricato: trascrizione attiva:", st.get("running"), "| modalità del video:", st.get("mode"),
              "| sul video:", await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent"))
        # fermo: tornano i sottotitoli di YouTube; rifaccio la trascrizione da capo
        await send({"type": "live", "action": "stop"}); await pg.wait_for_timeout(800)
        print("4. fermata: sul video:", await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent"))
        n3 = len(log["groq"])
        await send({"type": "redo", "what": "transcription"}); await pg.wait_for_timeout(12000)
        st = await send({"type": "liveState"})
        print("5. 'Rifai la trascrizione' con la trascrizione ferma: attiva:", st.get("running"), "| richieste nuove:", len(log["groq"]) - n3,
              "| stato:", await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

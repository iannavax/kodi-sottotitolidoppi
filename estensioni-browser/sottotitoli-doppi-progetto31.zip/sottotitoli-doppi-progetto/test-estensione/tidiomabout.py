# 1.6.3: 🔎 «Modi di dire con questa parola» in generale (dizionario + modello), parole cliccabili, errore momentaneo ripetuto
import asyncio, sys, os
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false, hoverPause:true, learnNgram:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("market")).click(); await pg.wait_for_timeout(2500)
        await pg.locator(".dualsub-card .dualsub-idiomask").click()
        await pg.wait_for_selector(".dualsub-card .dsx-iditem", timeout=40000)
        print("1. richieste:", log.get("idiomsAbout"), "(503 una volta:", bool(os.environ.get("IDIOM_503_ONCE")), ")")
        items = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-iditem')].map(x=>x.innerText.replace(/\\n/g,' | '))")
        print("   elenco:", items)
        print("   dizionario:", await pg.evaluate("(document.querySelector('.dualsub-card .dsx-iddict')||{}).innerText"))
        print("   sottolineato nella frase:", await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-idiom, .dualsub-orig [class*=idiom]')].length"))
        # una parola dentro un modo di dire trovato: cerco altri modi di dire con quella
        await pg.locator(".dualsub-card .dsx-iditem .dsx-idw", has_text="flea").first.click()
        for _ in range(60):
            if any(w == "flea" for w, _m in log.get("idiomsAbout", [])): break
            await pg.wait_for_timeout(500)
        await pg.wait_for_selector(".dualsub-card .dsx-idhead:has-text('flea')", timeout=20000)
        await pg.wait_for_timeout(1500)
        print("2. dopo «flea»:", await pg.evaluate("(document.querySelector('.dualsub-card .dsx-idpanel')||{}).innerText").__await__().__next__() if False else (await pg.evaluate("(document.querySelector('.dualsub-card .dsx-idpanel')||{}).innerText||''")).replace("\n", " | "))
        ok = len(items) >= 2 and any(w == "flea" for w, _m in log["idiomsAbout"])
        print("errori:", errs if ok else errs + ["modi di dire non vanno"], log["errors"])
        await ctx.close()
asyncio.run(main())

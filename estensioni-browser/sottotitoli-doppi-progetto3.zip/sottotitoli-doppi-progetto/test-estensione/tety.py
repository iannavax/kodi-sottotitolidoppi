import asyncio, json
from playwright.async_api import async_playwright
SRC = open("/home/claude/sottotitoli-doppi-progetto/estensione/src/etym.js").read()
H = lambda l, t: f'<div class="mw-heading mw-heading{l}"><h{l}>{t}</h{l}></div>'
html = '<div class="mw-parser-output">' + H(2, "Czech") + H(3, "Etymology") + '<p>From <i class="Latn mention" lang="cs">ten</i> (“that”) + <i class="Latn mention" lang="cs">-to</i>. Compare <span class="etyl">Slovak</span> <i class="Latn mention" lang="sk">tento</i>.</p>' + H(3, "Pronoun") + '<p><b>tento</b></p></div>'
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(channel="chromium", headless=True); pg = await b.new_page()
        await pg.set_content("<html><body></body></html>")
        for mode in ["ok", "lose"]:
            await pg.evaluate("""(mode)=>{ window.SENT=[]; window.DS_EXT={storage:{local:{get:()=>Promise.resolve({}),set:()=>Promise.resolve()}},runtime:{sendMessage:(m)=>{
              if (m.type==='etymPage') return Promise.resolve({html: window.HTML, title:'tento'});
              if (m.type==='translate') { SENT.push(m.texts[0]); let t=m.texts[0].replace('From','Da').replace('that','quello').replace('Compare','Confronta').replace('Slovak','slovacco');
                 if (mode==='lose') t=t.replace(/⟦0⟧/,'dieci'); return Promise.resolve({translations:[t]}); }
              return Promise.resolve({}); }}} }""", mode)
            await pg.evaluate("(h)=>{window.HTML=h}", html)
            await pg.add_script_tag(content=SRC + "\nwindow.E=DS_ETYM;")
            r = await pg.evaluate("E.get('tento','cs','it')")
            print(mode, "| inglese:", r["text"], "\n   tradotta:", r["trans"], "\n   mandato:", await pg.evaluate("SENT"))
        await b.close()
asyncio.run(main())

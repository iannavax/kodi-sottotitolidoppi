import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(900)
        async def S(**m):
            return await pp.evaluate("m => chrome.runtime.sendMessage({type:'imageSearch', n:4, ...m})", m)
        r = await S(query="pane", lang="it", source="wikipedia")
        print("1. di serie (lingua della parola):", r.get("query"), r.get("qlang"), log.get("wphost"), log.get("wp"))
        r = await S(query="pane", lang="it", source="wikipedia", qlang="en")
        print("2. inglese:", r.get("query"), r.get("qlang"), log.get("wphost")[-1])
        r = await S(query="pane", lang="it", source="wikipedia", qlang="ui")
        print("3. la mia lingua (it):", r.get("query"), r.get("qlang"))
        r = await S(query="bread", lang="en", source="google")
        print("4. Google:", [(i["url"], i["thumb"]) for i in r["items"]], r.get("error"), log.get("gimg"))
        await pp.evaluate("chrome.storage.sync.set({ankiImageLang:'en'})"); await pp.wait_for_timeout(200)
        r = await S(query="pane", lang="it", source="wikipedia")
        print("5. preferenza inglese:", r.get("query"), r.get("qlang"))
        r = await S(query="pane", lang="it", source="all")
        print("6. tutte:", [i["source"] for i in r["items"]], r.get("error"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# 1.7.20: carte Anki di frasi/modi di dire («text») con la pronuncia, e la lingua sul retro
import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ankiAudio:true})")
        log["anki_notes"] = {7001: {"Fronte": "<b>upozorňuji vás</b>", "Retro": "<b>vi avviso</b>"}}
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1000)
        r = await pp.evaluate("""chrome.runtime.sendMessage({type:'ankiUpdate', id:7001, cards:[], names:['Fronte','Retro'], model:'Base',
            entry:{word:'upozorňuji vás', lang:'cs', kind:'text', meaning:'vi avviso'}, audio:true, keep:[]})""")
        n = log["anki_notes"][7001] if isinstance(log["anki_notes"].get(7001), dict) else {}
        print("risposta:", {k: (v if k in ("how", "audioNote", "error") else "…") for k, v in (r or {}).items()})
        print("fronte:", (r or {}).get("front", "")[:400])
        print("retro ha la lingua:", "Ceco" in ((r or {}).get("back") or ""), "| file audio:", [m for m in log.get("anki_media", []) if "tts" in m or "rec" in m])
        ok = r and "[sound:" in (r.get("front") or "") and "Ceco" in (r.get("back") or "")
        print("errori:", errs if ok else errs + ["manca audio o lingua"], log["errors"])
        await ctx.close()
asyncio.run(main())

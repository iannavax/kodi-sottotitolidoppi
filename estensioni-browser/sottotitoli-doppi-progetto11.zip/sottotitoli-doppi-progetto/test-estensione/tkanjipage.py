# 5.21: distintivi del kanji cliccabili (pagina "Kanji e caratteri" al livello giusto) e ordine dei tratti nella scheda
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true}).then(()=>chrome.storage.local.set({knownWords:{ja:'強'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=jaKanjiPage"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/勉強/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        await pg.locator(".dualsub-orig .dualsub-word", has_text="勉強").first.click()
        await pg.wait_for_selector(".dualsub-card .dsx-hanchip", timeout=8000)
        await pg.locator(".dualsub-card .dsx-hanchip", has_text="勉").first.click()
        await pg.wait_for_function("/tratti/.test((document.querySelector('.dualsub-card .dsx-hanpanel')||{}).textContent||'')", timeout=8000)
        print("1. distintivi cliccabili:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-hanpanel .dsx-badges button')].map(b=>b.textContent)"))
        await pg.locator(".dualsub-card .dsx-hanpanel button", has_text="tratti").first.click(); await pg.wait_for_timeout(1500)
        print("2. ordine dei tratti:", await pg.evaluate("(()=>{const i=document.querySelector('.dualsub-card .dsx-hanorder'); return i ? i.src.slice(0,22) : (document.querySelector('.dualsub-card .dsx-hanpanel').textContent.match(/Cerco|non disponibile/)||['niente'])[0]})()"), "| richieste:", log.get("strokeorder"))
        async with ctx.expect_page() as np:
            await pg.locator(".dualsub-card .dsx-hanpanel button", has_text="JLPT").first.click()
        kp = await np.value; kp.on("pageerror", lambda e: errs.append("kanji: " + str(e)))
        await kp.wait_for_selector(".grid .ch", timeout=10000); await kp.wait_for_timeout(500)
        print("3. pagina:", kp.url.split("/")[-1][:60])
        print("   titolo:", await kp.inner_text("#title"), "| livelli:", await kp.evaluate("[...document.querySelectorAll('#levels button')].map(b=>b.textContent)"))
        print("   caratteri:", await kp.evaluate("document.querySelectorAll('.grid .ch').length"), "| evidenziato:", await kp.evaluate("(document.querySelector('.grid .ch.me b')||{}).textContent"), "| conosciuti in verde:", await kp.evaluate("[...document.querySelectorAll('.grid .ch.known b')].map(b=>b.textContent).slice(0,5)"))
        print("   scheda:", (await kp.inner_text("#detail")).replace("\n", " | ")[:300])
        await kp.locator("#detail .badge", has_text="tratti").click(); await kp.wait_for_timeout(500)
        print("4. tratti ›:", await kp.inner_text("#title"), "| caratteri:", await kp.evaluate("document.querySelectorAll('.grid .ch').length"))
        await kp.locator("#detail button", has_text="lo conosco?").click(); await kp.wait_for_timeout(500)
        print("5. lo conosco:", await sw.evaluate("chrome.storage.local.get('knownWords').then(r=>r.knownWords.ja)"))
        await kp.fill("#q", "water"); await kp.wait_for_timeout(600)
        print("6. cerca 'water':", await kp.evaluate("[...document.querySelectorAll('.grid .ch b')].map(b=>b.textContent).slice(0,8)"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

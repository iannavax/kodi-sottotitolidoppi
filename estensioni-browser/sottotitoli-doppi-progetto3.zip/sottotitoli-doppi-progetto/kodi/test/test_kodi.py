import sys, os, json, re, shutil, urllib.parse, importlib
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui
from resources.lib import core
calls = []
tr = lambda x: " ".join(w[::-1] for w in x.split())
MODE = {"gem": ""}

def fake_http(url, data=None, headers=None, timeout=90):
    calls.append(url.split("?")[0])
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + tr(l) + "]" for l in q.split("\n")), q]], None, "en"]).encode(), {}
    if "generativelanguage" in url:
        segs = json.loads(json.loads(data)["messages"][1]["content"])["segments"]
        if MODE["gem"] == "shift" and len(segs) > 1:
            t = ["GEM[" + tr(" ".join(segs)) + "]"] + [""] * (len(segs) - 1)
        elif MODE["gem"] == "echo":
            t = segs
        else:
            t = ["GEM[" + tr(s) + "]" for s in segs]
        return 200, json.dumps({"choices": [{"message": {"content": json.dumps({"t": t})}}]}).encode(), {}
    if "audio/transcriptions" in url:
        n = len([c for c in calls if "audio/transcriptions" in c])
        segs = [{"start": k * 6 + 0.2, "end": k * 6 + 5.5, "text": " parte %d frase %d. Seconda frase qui." % (n, k + 1),
                 "no_speech_prob": 0.02, "avg_logprob": -0.3} for k in range(5)]
        segs.append({"start": 31, "end": 33, "text": " I'm sorry.", "no_speech_prob": 0.5, "avg_logprob": -0.8})
        return 200, json.dumps({"language": "english", "segments": segs}).encode(), {}
    return 404, b"", {}
core.http = fake_http
from resources.lib import runner

# ---------- 1. lettura dei formati
srt = "1\n00:00:01,000 --> 00:00:03,500\n<i>Hello there, my friend.</i>\n\n2\n00:00:04,000 --> 00:00:06,000\nHow are you\ndoing today?\n"
vtt = "WEBVTT\n\n00:01.000 --> 00:03.500\nHello there\n\n00:04.000 --> 00:06.000 align:start\nHow are you?\n"
ass = "[Script Info]\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:01.00,0:00:03.50,Default,,0,0,0,,{\\i1}Hello, there\\Nfriend{\\i0}\n"
for name, t in (("srt", srt), ("vtt", vtt), ("ass", ass)):
    print("1. formato %s:" % name, core.parse_subs(t))

# ---------- 2. film con i sottotitoli accanto: scelta del file giusto e file doppio
shutil.rmtree("/tmp/kodi-film", ignore_errors=True); shutil.rmtree("/tmp/kodi-profile", ignore_errors=True)
os.makedirs("/tmp/kodi-film"); os.makedirs("/tmp/kodi-temp", exist_ok=True)
open("/tmp/kodi-film/Il film (2024).mkv", "w").write("x")
lines = ["we went to the market yesterday morning", "and bought some really fresh bread for everyone", "then we walked home slowly together",
         "it was a beautiful day in the city", "everyone was happy and smiling", "the end of our little trip"]
open("/tmp/kodi-film/Il film (2024).en.srt", "w", encoding="utf-8").write(
    "\n".join("%d\n00:00:%02d,000 --> 00:00:%02d,500\n%s\n" % (i + 1, i * 4, i * 4 + 3, l) for i, l in enumerate(lines)))
open("/tmp/kodi-film/Il film (2024).it.srt", "w").write("1\n00:00:01,000 --> 00:00:02,000\ngià in italiano\n")
xbmc.Player.playing_file = "/tmp/kodi-film/Il film (2024).mkv"
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra", "trans_color": "FFFF00", "auto": "true"})
calls.clear()
runner.run(xbmc.Player(), interactive=True)
out = xbmc.Player.subs[-1]
print("2. file scelto: .en.srt | caricato nel lettore:", os.path.basename(out))
print("   " + open(out, encoding="utf-8").read().split("\n\n")[1].replace("\n", " / "))
print("   avvisi:", xbmcgui.NOTES[-1:])

# ---------- 3. Gemini che sbaglia (frasi spostate), poi rivedo il film: nessuna richiesta
xbmcaddon.SETTINGS.update({"engine": "gemini (gratis con chiave, consigliato)", "gemini_key": "AIza-test", "gemini_model": "gemini-flash-lite-latest"})
core.ENGINES["gemini"]["gap"] = 0
MODE["gem"] = "shift"; calls.clear()
runner.run(xbmc.Player(), interactive=True)
text = open(xbmc.Player.subs[-1], encoding="utf-8").read()
ok = sum(1 for l in lines if ("GEM[" + tr(l) + "]") in text)
print("3. Gemini che sposta le frasi: traduzioni allineate %d/%d | richieste a Gemini: %d" % (ok, len(lines), calls.count("https://generativelanguage.googleapis.com/v1beta/openai/chat/completions")))
calls.clear()
runner.run(xbmc.Player(), interactive=True)
print("   rivisto: richieste %d" % len(calls))

# ---------- 4. Gemini che ricopia l'originale → Google al suo posto
shutil.rmtree("/tmp/kodi-profile", ignore_errors=True)
MODE["gem"] = "echo"; calls.clear()
runner.run(xbmc.Player(), interactive=True)
text = open(xbmc.Player.subs[-1], encoding="utf-8").read()
print("4. Gemini che ricopia: righe con traduzione di Google", sum(1 for l in lines if ("IT[" + tr(l) + "]") in text), "| righe ricopiate", sum(1 for l in lines if ('#FFFF00">' + l) in text))

# ---------- 5. nessun sottotitolo e trascrizione spenta → avviso
os.makedirs("/tmp/kodi-video2", exist_ok=True); open("/tmp/kodi-video2/clip.mp4", "w").write("x")
xbmc.Player.playing_file = "/tmp/kodi-video2/clip.mp4"
runner.run(xbmc.Player(), interactive=True)
print("5. senza sottotitoli:", xbmcgui.NOTES[-1][:80])

# ---------- 6. trascrizione con Whisper (ffmpeg vero) e traduzione
xbmc.Player.playing_file = "/tmp/speech.wav"
xbmcaddon.SETTINGS.update({"engine": "google (gratis, senza chiave)", "transcribe": "true", "groq_key": "gsk_test", "stt": "groq", "stt_lang": "auto"})
calls.clear()
runner.run(xbmc.Player(), interactive=True)
text = open(xbmc.Player.subs[-1], encoding="utf-8").read()
blocks = text.strip().split("\n\n")
print("6. trascrizione: richieste a Whisper", calls.count("https://api.groq.com/openai/v1/audio/transcriptions"), "| frasi", len(blocks), "| \"I'm sorry\" scartato:", "sorry" not in text.lower())
print("   " + blocks[0].replace("\n", " / "))
print("   avvisi:", xbmcgui.NOTES[-1:])

# ---------- 7. sottotitoli presenti ma "trascrivi sempre": si usa l'audio, non il file
shutil.rmtree("/tmp/kodi-film2", ignore_errors=True); os.makedirs("/tmp/kodi-film2")
shutil.copy("/tmp/speech.wav", "/tmp/kodi-film2/Film2.wav")
open("/tmp/kodi-film2/Film2.en.srt", "w").write("1\n00:00:01,000 --> 00:00:02,000\nsottotitolo sbagliato del file\n")
xbmc.Player.playing_file = "/tmp/kodi-film2/Film2.wav"
xbmcaddon.SETTINGS.update({"transcribe": "false", "transcribe_always": "false"})
calls.clear(); runner.run(xbmc.Player(), interactive=True)
t0 = open(xbmc.Player.subs[-1], encoding="utf-8").read()
print("7. normale: usa il file:", "sottotitolo sbagliato" in t0, "| Whisper:", sum("audio/transcriptions" in c for c in calls))
xbmcaddon.SETTINGS.update({"transcribe_always": "true"})
calls.clear(); runner.run(xbmc.Player(), interactive=True)
t1 = open(xbmc.Player.subs[-1], encoding="utf-8").read()
print("   trascrivi sempre: usa il file:", "sottotitolo sbagliato" in t1, "| Whisper:", sum("audio/transcriptions" in c for c in calls), "| frasi:", len(t1.strip().split("\n\n")))
xbmcaddon.SETTINGS.update({"transcribe_always": "false"})
shutil.rmtree("/tmp/kodi-profile", ignore_errors=True)
calls.clear(); runner.run(xbmc.Player(), force_transcribe=True, interactive=True)
print("   dal menu (Trascrivi l'audio):", "sottotitolo sbagliato" not in open(xbmc.Player.subs[-1], encoding="utf-8").read(), "| Whisper:", sum("audio/transcriptions" in c for c in calls))

# ---------- 8. trascrizione con OpenAI
orig_http = core.http
seen = {}
def spy(url, data=None, headers=None, timeout=90):
    if "audio/transcriptions" in url:
        seen["url"] = url; seen["model"] = re.search(rb'name="model"\r\n\r\n([^\r]+)', data).group(1).decode(); seen["auth"] = headers.get("Authorization")
    return orig_http(url, data, headers, timeout)
core.http = spy
for k in os.listdir(runner.CACHE) if os.path.isdir(runner.CACHE) else []:
    os.remove(os.path.join(runner.CACHE, k))
xbmcaddon.SETTINGS.update({"stt": "openai (a pagamento)", "openai_key": "", "stt_model": "whisper-large-v3-turbo"})
runner.run(xbmc.Player(), force_transcribe=True, interactive=True)
print("8. OpenAI senza chiave:", xbmcgui.NOTES[-1])
xbmcaddon.SETTINGS.update({"openai_key": "sk-test"})
runner.run(xbmc.Player(), force_transcribe=True, interactive=True)
print("   OpenAI:", seen.get("url"), seen.get("model"), seen.get("auth"), "|", xbmcgui.NOTES[-1])
core.http = orig_http

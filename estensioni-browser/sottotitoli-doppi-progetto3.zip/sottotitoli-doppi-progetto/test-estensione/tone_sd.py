import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ruOne"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').currentTime=6.2; document.querySelector('video').play()")
        await pg.wait_for_function("/доме/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        print("parole:", texts)
        for w in ["в", "Я"]:
            await pg.mouse.move(5, 5); await pg.wait_for_timeout(600)
            await words.nth(texts.index(w)).hover(); await pg.wait_for_timeout(2000)
            print(w, "→ scheda:", (await pg.evaluate("(document.querySelector('.dualsub-card')||{}).innerText||'(niente)'"))[:50].replace("\n", " | "))
        await words.nth(texts.index("в")).click(); await pg.wait_for_timeout(1500)
        print("clic в → ", (await pg.evaluate("(document.querySelector('.dualsub-card')||{}).innerText||'(niente)'"))[:50].replace("\n", " | "))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        ext = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:false, hideLine:'orig'})")
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}, dsUsage:{day:(new Date()).toLocaleDateString('en-CA',{timeZone:'America/Los_Angeles'}), n:{gemini:124, whisper:18}}, vocab:{'en|bread':{id:'en|bread',word:'bread',lang:'en',status:'learning',meaning:'pane',sentence:'I like bread.',sentenceTrans:'Mi piace il pane.'},'en|loaf':{id:'en|loaf',word:'loaf',lang:'en',status:'learning',meaning:'pagnotta'}}})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        op = lambda: pg.evaluate("getComputedStyle(document.querySelector('.dualsub-orig')).opacity")
        a = await op()
        await pg.locator(".dualsub-orig").hover(force=True) if False else await pg.mouse.move(5, 5)
        print("1. originale nascosto:", a, end=" | ")
        box = await pg.locator(".dualsub-orig").bounding_box()
        await pg.mouse.move(box["x"] + 5, box["y"] + 5); await pg.wait_for_timeout(300)
        print("col mouse sopra:", await op())
        # dimensione per sito
        pop = await ctx.new_page(); await pop.goto(f"chrome-extension://{ext}/popup.html"); await pop.wait_for_timeout(1500)
        print("2. contatore:", await pop.evaluate("document.getElementById('usageBadge').hidden + ' ' + document.getElementById('usageBadge').textContent"))
        await pop.evaluate("""chrome.storage.sync.set({siteStyle:{'www.youtube.com':{fontSize:34}}})"""); await pg.wait_for_timeout(1200)
        print("   grandezza sul sito YouTube:", await pg.evaluate("document.querySelector('.dualsub-overlay').style.getPropertyValue('--dualsub-size')"))
        # prova chiave
        r = await pop.evaluate("chrome.runtime.sendMessage({type:'testKey', engine:'gemini', key:'AIza-test'})")
        print("3. prova chiave Gemini:", r)
        # esporta/importa
        exp = await pop.evaluate("""(async()=>{ const sync = await chrome.storage.sync.get(null); return Object.keys(sync).length })()""")
        imp = await pop.evaluate("""dsImportSettings(JSON.stringify({format:'sd-settings-1', sync:{fontSize:30, hideLine:''}, local:{cardUser:{video:{fx:1}}}})).then(r=>r)""")
        print("4. importa:", imp, "| fontSize ora:", await sw.evaluate("chrome.storage.sync.get('fontSize').then(r=>r.fontSize)"))
        # ripasso
        vp = await ctx.new_page(); await vp.goto(f"chrome-extension://{ext}/vocab.html"); await vp.wait_for_timeout(1500)
        await vp.click("#reviewBtn"); await vp.wait_for_timeout(400)
        print("5. ripasso, fronte:", await vp.evaluate("document.querySelector('.rvfront').textContent"), "|", await vp.evaluate("document.getElementById('rvCount').textContent"))
        await vp.keyboard.press("Space"); await vp.wait_for_timeout(300)
        print("   retro:", await vp.evaluate("document.querySelector('.rvback').textContent"))
        await vp.keyboard.press("3"); await vp.wait_for_timeout(500)
        print("   dopo «La so»:", await vp.evaluate("document.querySelector('.rvfront').textContent"), "| rev:", await sw.evaluate("chrome.storage.local.get('vocab').then(r=>JSON.stringify(Object.values(r.vocab).map(e=>[e.word,e.rev&&e.rev.box])))"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

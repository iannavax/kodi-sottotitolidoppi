// Correzioni delle singole frasi: ritraduci, ritrascrivi, correggi a mano, togli.
// Le correzioni restano salvate con il video ("fix:<video>") e hanno la precedenza su tutto il resto,
// anche su "Rifai la traduzione".
// Usa: settings, live, track, segTrans, transCues, askTranslate, liveEngine, trackEngine, GOOGLE_ENGINE,
//      wordsCard*, el, wordsPlace, wordsCloseCard, getVideo, currentVideoId, setStatus (dagli altri moduli)

let dsFixes = {};
let dsFixVid = null;
let dsFixLoading = null;

const fixKey = (start) => String(Math.round(start / 100));   // tolleranza di un decimo di secondo

function fixLoad(v) {
  if (dsFixVid === v && !dsFixLoading) return Promise.resolve();
  if (dsFixVid === v && dsFixLoading) return dsFixLoading;
  dsFixVid = v;
  dsFixes = {};
  dsFixLoading = DS_EXT.storage.local.get(`fix:${v}`).then((r) => {
    if (dsFixVid === v) dsFixes = r[`fix:${v}`] || {};
    dsFixLoading = null;
  });
  return dsFixLoading;
}

// Frase come va mostrata, tenendo conto delle correzioni salvate
function fixApply(v, start, text, trans) {
  if (!v) return { text, trans };
  if (dsFixVid !== v) { fixLoad(v); return { text, trans }; }
  const f = dsFixes[fixKey(start)];
  if (!f) return { text, trans };
  const tr = f.tr && f.tr[settings.targetLang];
  // traduzione incollata da una chat (Copia trascrizione → Incolla traduzione): vale come le altre correzioni,
  // ma non è segnata come "corretta a mano" frase per frase
  const onlyChat = f.chat && f.chat[settings.targetLang] && f.t == null && !f.x;
  return { text: f.t != null ? f.t : text, trans: tr != null ? tr : trans, gone: !!f.x, fixed: !onlyChat, chat: !!onlyChat };
}

// Molte traduzioni insieme (incollate da una chat): una sola scrittura in memoria
async function fixSaveMany(v, items) {
  await fixLoad(v);
  let n = 0;
  for (const it of items) {
    if (!it || it.trans == null || !String(it.trans).trim()) continue;
    const k = fixKey(it.start);
    const f = { ...(dsFixes[k] || {}) };
    if (f.tr && f.tr[settings.targetLang] != null && !(f.chat && f.chat[settings.targetLang])) continue;   // corretta a mano: resta
    f.tr = { ...(f.tr || {}), [settings.targetLang]: String(it.trans).trim() };
    f.chat = { ...(f.chat || {}), [settings.targetLang]: 1 };
    dsFixes[k] = f;
    n++;
  }
  await saveCache(`fix:${v}`, dsFixes);
  return n;
}

async function fixSave(v, start, patch) {
  await fixLoad(v);
  const k = fixKey(start);
  const f = { ...(dsFixes[k] || {}) };
  if ("t" in patch) { if (patch.t == null) delete f.t; else f.t = patch.t; }
  if ("tr" in patch) {
    f.tr = { ...(f.tr || {}) };
    if (patch.tr == null) delete f.tr[settings.targetLang]; else f.tr[settings.targetLang] = patch.tr;
  }
  if ("x" in patch) { if (patch.x) f.x = 1; else delete f.x; }
  if (Object.keys(f).length && !(Object.keys(f).length === 1 && f.tr && !Object.keys(f.tr).length)) dsFixes[k] = f;
  else delete dsFixes[k];
  await saveCache(`fix:${v}`, dsFixes);
}

// ---------- Trovare la frase ----------
function fixFind(start) {
  const near = (x) => Math.abs(x - start) < 60;
  if (liveActive()) {
    const i = live.cues.findIndex((c) => near(c.start));
    if (i >= 0) return { kind: "live", i, cue: live.cues[i], list: live.cues };
  }
  if (track) {
    const line = trackEngine().E.kind === "youtube";
    const list = line ? track.cues : track.segments;
    const i = list.findIndex((c) => near(c.start));
    if (i >= 0) return { kind: line ? "line" : "segment", i, cue: list[i], list };
  }
  return null;
}

function fixCurrent(ref) {
  const f = fixApply(currentVideoId(), ref.cue.start, ref.cue.text, "");
  return f.text;
}

// ---------- Ritraduci ----------
async function fixRetranslate(start) {
  const v = currentVideoId();
  const ref = fixFind(start);
  if (!ref) return { ok: false, error: "frase non trovata" };
  const text = fixCurrent(ref);
  const ctx = (a, b) => ref.list.slice(Math.max(0, a), Math.max(0, b)).filter((c) => !c.removed).map((c) => c.text);
  const e0 = ref.kind === "live" ? liveEngine() : trackEngine();
  const e = e0.E.kind === "youtube" ? GOOGLE_ENGINE : e0;
  const lang = ref.cue.lang || (ref.kind === "live" ? liveSourceLang() : (track && track.lang) || "");
  let r = await askTranslate(e, [text], ctx(ref.i - 4, ref.i), ctx(ref.i + 1, ref.i + 3), () => true, "", lang, false, true);
  let t = r && !r.error ? (r.translations[0] || "") : "";
  if (!t || dsIsEcho(text, t) || dsUncheckedCopy(text, t, settings.targetLang)) {
    // il servizio scelto non ha dato una traduzione valida (o ha ricopiato la frase): provo con Google
    const g = await askTranslate(GOOGLE_ENGINE, [text], [], [], () => true, "", lang);
    const gt = g && !g.error ? (g.translations[0] || "") : "";
    if (gt && !dsIsEcho(text, gt)) {
      if (dsIsCopy(text, gt)) dsMarkCopyOk(text, settings.targetLang);   // anche Google la lascia uguale: è un nome
      t = gt; r = { via: "Google" };
    }
  }
  if (!t) return { ok: false, error: (r && r.error) || "nessuna traduzione valida" };
  await fixSave(v, ref.cue.start, { tr: t });
  if (ref.kind === "live") { ref.cue.trans = t; ref.cue.quick = false; ref.cue.saved = true; liveScheduleSave(); }
  return { ok: true, trans: t };
}

// ---------- Ritrascrivi (solo trascrizione di Whisper) ----------
async function fixRetranscribe(start) {
  const v = currentVideoId();
  const ref = fixFind(start);
  if (!ref || ref.kind !== "live") return { ok: false, error: "si possono ritrascrivere solo le frasi trascritte dall'audio" };
  const c = ref.cue;
  await fixSave(v, c.start, { t: null, tr: null, x: false });
  // 1) l'audio di quella frase è ancora in memoria: la ritrascrivo subito, con il modello più preciso
  const item = c.item && c.item.pcm ? c.item : null;
  if (item) {
    const r = await liveRequest(item, dsSttLang() || c.lang || live.domLang || "", liveBetterModel());
    if (r && !r.error) {
      const fresh = DualSubs.fromWhisper((r.segments || []).filter((s) => !DualSubs.isJunk(s)), r.words || [], item.s, item.rate)
        .filter((n) => (n.start + n.end) / 2 >= c.start - 400 && (n.start + n.end) / 2 <= c.end + 400)
        .map((n) => ({ start: n.start, end: n.end, text: n.text, trans: null, quick: false, late: false, item, lang: c.lang }));
      live.cues = live.cues.filter((x) => x === c ? false : !((x.start + x.end) / 2 >= c.start && (x.start + x.end) / 2 <= c.end && x.item === item));
      if (!fresh.length) { live.dirty = true; liveScheduleSave(); return { ok: true, text: "", note: "Whisper non ha sentito parlato in quel punto: la frase è stata tolta." }; }
      live.cues.push(...fresh);
      live.cues.sort((a, b) => a.start - b.start);
      live.dirty = true;
      liveScheduleSave();
      liveQueueTranslation(fresh);
      return { ok: true, text: fresh.map((x) => x.text).join(" ") };
    }
  }
  // 2) audio non più in memoria: torno all'inizio della frase e la riascolto
  const a = c.start - 500, b = c.end + 500;
  live.cues = live.cues.filter((x) => x !== c);
  live.covered = live.covered.flatMap(([x, y]) => (y <= a || x >= b ? [[x, y]] : [[x, a], [b, y]].filter(([p, q]) => q - p > 500)));
  live.redo = live.redo.filter((r) => r.b <= a || r.a >= b);   // la stessa frase chiesta due volte: una sola
  live.redo.push({ a, b, done: a, at: Date.now() });
  live.dirty = true;
  liveScheduleSave();
  const video = getVideo();
  if (!live.running) { live.redoAutoStarted = true; liveStart(true, { fill: true, quiet: true }); }
  if (video) { video.currentTime = Math.max(0, c.start / 1000 - 1); video.play().catch(() => {}); }
  setStatus("Riascolto la frase per ritrascriverla con il modello più preciso…");
  return { ok: true, pending: true, note: "Il video torna all'inizio della frase e la riascolta: la nuova versione compare tra pochi secondi." };
}

function liveBetterModel() {
  // su Groq, il modello non "turbo" è più lento ma più preciso
  return settings.stt === "groq" ? "whisper-large-v3" : settings.sttModel;
}

// ---------- Correggi a mano / togli ----------
async function fixEdit(start, text, trans) {
  const v = currentVideoId();
  const ref = fixFind(start);
  if (!ref) return { ok: false, error: "frase non trovata" };
  const patch = {};
  const oldText = fixCurrent(ref);
  if (text != null && text.trim() && text.trim() !== oldText) patch.t = text.trim();
  if (trans != null && trans.trim()) patch.tr = trans.trim();
  if (!Object.keys(patch).length) return { ok: true };
  await fixSave(v, ref.cue.start, patch);
  if (ref.kind === "live") {
    if (patch.t) ref.cue.text = patch.t;
    if (patch.tr) { ref.cue.trans = patch.tr; ref.cue.saved = true; }
    live.dirty = true;
    liveScheduleSave();
  }
  // originale corretto senza una traduzione nuova: la rifaccio io
  if (patch.t && !patch.tr) return fixRetranslate(ref.cue.start);
  return { ok: true };
}

async function fixRemove(start) {
  const v = currentVideoId();
  const ref = fixFind(start);
  if (!ref) return { ok: false, error: "frase non trovata" };
  await fixSave(v, ref.cue.start, { x: true });
  if (ref.kind === "live") { ref.cue.removed = true; live.dirty = true; liveScheduleSave(); }
  return { ok: true };
}

async function fixDo(action, start, text, trans) {
  try {
    if (action === "retranslate") return await fixRetranslate(start);
    if (action === "retranscribe") return await fixRetranscribe(start);
    if (action === "edit") return await fixEdit(start, text, trans);
    if (action === "remove") return await fixRemove(start);
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
  return { ok: false, error: "azione sconosciuta" };
}

// Mentre la scheda è aperta i sottotitoli restano fermi: dopo una correzione ridisegno subito la frase
// sul video, così la nuova traduzione si vede sotto l'originale (non solo nella scheda)
function fixRefreshLine(s) {
  wordsOrigKey = "";
  wordsTransKey = "";
  wordsRenderOriginal(s.text, s.lang);
  if (s.trans && s.trans !== "…") wordsRenderTrans(s.trans);
  else setText(lineTrans, s.trans || "");
  lineTrans.classList.remove("dualsub-quick");
}

// ---------- Scheda sul video ----------
function fixOpenCard(anchor) {
  if (!wordsCurrent || !overlay) return;
  if (wordsCard) wordsCard.remove();
  wordsCardState = { pinned: true, word: null, fix: true, sentence: wordsCurrent, data: null };
  wordsCard = el("div", "dualsub-card dualsub-fixcard");
  overlay.append(wordsCard);
  fixFillCard();
  wordsPlace(anchor);
}

function fixFillCard(message) {
  const st = wordsCardState;
  if (!wordsCard || !st) return;
  const s = st.sentence;
  wordsCard.textContent = "";
  const head = el("div", "dualsub-card-head");
  head.append(el("div", "dualsub-card-title", "Questa frase è sbagliata?"));
  const close = el("button", "dualsub-card-btn", "×");
  close.title = "Chiudi";
  close.addEventListener("click", wordsCloseCard);
  head.append(close);
  wordsCard.append(head, el("div", "dualsub-card-expl", s.text), el("div", "dualsub-card-meaning dualsub-fix-trans", s.trans || "—"));

  const busy = (label) => { fixFillCard(label); };
  const run = async (action, label, text, trans) => {
    busy(label);
    const r = await fixDo(action, s.start, text, trans);
    if (!wordsCardState || wordsCardState.sentence !== s) return;
    if (!r.ok) { fixFillCard("Non ci sono riuscito: " + r.error); return; }
    if (r.pending) { wordsCloseCard(); return; }
    const now = fixApply(currentVideoId(), s.start, r.text != null && r.text !== "" ? r.text : s.text, r.trans != null ? r.trans : s.trans);
    s.text = now.text; s.trans = now.trans;
    fixRefreshLine(s);
    fixFillCard(r.note || "Fatto ✓");
  };

  const actions = el("div", "dualsub-fix-actions");
  const b1 = el("button", "dualsub-card-replay", "↻ Ritraduci");
  b1.title = "Chiede di nuovo la traduzione di questa frase, con le frasi vicine come contesto";
  b1.addEventListener("click", () => run("retranslate", "Ritraduco…"));
  actions.append(b1);
  if (s.live) {
    const bl = el("button", "dualsub-card-replay", `🌐 Lingua sbagliata? (ora: ${dsLangName(liveSourceLang() || "") || "automatica"})`);
    bl.title = "Se la trascrizione è in un'altra lingua (per esempio in inglese invece che in ceco): scegli la lingua parlata in questo video";
    bl.addEventListener("click", () => fixLangPicker());
    actions.append(bl);
    const b2 = el("button", "dualsub-card-replay", "🎙 Ritrascrivi");
    b2.title = "Fa riascoltare questa frase a Whisper, con il modello più preciso";
    b2.addEventListener("click", () => run("retranscribe", "Ritrascrivo…"));
    actions.append(b2);
  }
  const b3 = el("button", "dualsub-card-replay", "✎ Correggi a mano");
  b3.addEventListener("click", () => fixEditForm());
  const b4 = el("button", "dualsub-card-replay", "✕ Togli questa frase");
  b4.title = "Per le frasi inventate (per esempio durante la musica)";
  b4.addEventListener("click", async () => { await fixDo("remove", s.start); wordsCloseCard(); });
  actions.append(b3, b4);
  wordsCard.append(actions);
  if (message) wordsCard.append(el("div", "dualsub-card-source", message));
}

function fixEditForm() {
  const st = wordsCardState;
  if (!wordsCard || !st) return;
  const s = st.sentence;
  wordsCard.textContent = "";
  wordsCard.append(el("div", "dualsub-card-title", "Correggi a mano"));
  const t1 = el("textarea", "dualsub-fix-input");
  t1.value = s.text;
  const t2 = el("textarea", "dualsub-fix-input");
  t2.value = s.trans && s.trans !== "…" ? s.trans : "";
  t2.placeholder = "Traduzione (se la lasci vuota e cambi l'originale, la rifaccio io)";
  for (const t of [t1, t2]) t.addEventListener("keydown", (e) => e.stopPropagation()); // i tasti non vanno al lettore
  const save = el("button", "dualsub-card-replay", "Salva");
  save.addEventListener("click", async () => {
    fixFillCard("Salvo…");
    const r = await fixDo("edit", s.start, t1.value, t2.value);
    if (r.ok) {
      const now = fixApply(currentVideoId(), s.start, s.text, r.trans != null ? r.trans : s.trans);
      s.text = now.text; s.trans = now.trans;
      fixRefreshLine(s);
    }
    fixFillCard(r.ok ? "Salvato ✓" : "Non ci sono riuscito: " + r.error);
  });
  const back = el("button", "dualsub-card-replay", "Annulla");
  back.addEventListener("click", () => fixFillCard());
  wordsCard.append(el("div", "dualsub-card-source", "Originale"), t1, el("div", "dualsub-card-source", "Traduzione"), t2, save, back);
  t1.focus();
}

// ---------- Lingua parlata nel video (trascrizione in una lingua sbagliata, per esempio in inglese) ----------
const DS_LANG_TOP = ["cs", "en", "it", "de", "fr", "es", "pt", "ru", "pl", "sk", "uk", "nl", "da", "sv", "no", "fi", "hu", "ro", "el", "tr", "ja", "zh", "ko", "ar", "he", "hi"];
function fixLangOpen(anchor) {
  if (!overlay) return;
  if (wordsCard) wordsCard.remove();
  wordsCardState = { pinned: true, word: null, fix: true, sentence: wordsCurrent || { text: "", start: 0 }, data: null };
  wordsCard = el("div", "dualsub-card dualsub-fixcard");
  overlay.append(wordsCard);
  fixLangPicker();
  wordsPlace(anchor);
}
function fixLangPicker() {
  if (!wordsCard || !wordsCardState) return;
  const v = live.videoId || currentVideoId();
  const chosen = (v && dsVideoLang[v]) || "";
  wordsCard.textContent = "";
  const head = el("div", "dualsub-card-head");
  head.append(el("div", "dualsub-card-title", "Lingua parlata in questo video"));
  const close = el("button", "dualsub-card-btn", "×");
  close.addEventListener("click", wordsCloseCard);
  head.append(close);
  wordsCard.append(head);
  const now = liveSourceLang();
  wordsCard.append(el("div", "dualsub-card-expl", (now ? `La trascrizione adesso è in ${dsLangName(now)}` : "Lingua riconosciuta da sola") +
    (chosen ? " (scelta da te)." : ". Se è sbagliata (succede soprattutto con le canzoni: Whisper scrive in inglese), scegli quella giusta: la trascrizione di questo video viene rifatta in quella lingua.")));
  const q = el("input", "dualsub-fix-input dualsub-lang-search");
  q.placeholder = "Cerca: ceco, czech, čeština…";
  q.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") { const b = list.querySelector("button"); if (b) b.click(); } });
  const list = el("div", "dualsub-lang-list");
  const names = Object.keys(C.STT_LANGS).map((code) => {
    let native = "";
    try { native = new Intl.DisplayNames([code], { type: "language" }).of(code) || ""; } catch {}
    const it = dsLangName(code);
    return { code, label: it + (native && native.toLowerCase() !== it.toLowerCase() ? " · " + native : ""), key: [code, it, native, C.STT_LANGS[code]].join(" ").toLowerCase() };
  });
  const fill = () => {
    const t = q.value.trim().toLowerCase();
    list.textContent = "";
    const shown = t ? names.filter((n) => n.key.includes(t)) : DS_LANG_TOP.map((c) => names.find((n) => n.code === c)).filter(Boolean);
    if (!t || "automatica".includes(t)) {
      const a = el("button", "dualsub-card-replay", (chosen ? "" : "► ") + "Automatica (la riconosce da sola)");
      a.addEventListener("click", () => fixLangApply(""));
      list.append(a);
    }
    for (const n of shown.slice(0, 40)) {
      const b = el("button", "dualsub-card-replay", (n.code === chosen ? "► " : "") + n.label);
      b.addEventListener("click", () => fixLangApply(n.code));
      list.append(b);
    }
    if (!t) list.append(el("div", "dualsub-card-source", "Scrivi nella casella per le altre lingue (98 in tutto)."));
  };
  q.addEventListener("input", fill);
  wordsCard.append(q, list);
  fill();
  setTimeout(() => q.focus(), 0);
}
async function fixLangApply(code) {
  if (wordsCard) {
    wordsCard.textContent = "";
    wordsCard.append(el("div", "dualsub-card-expl", code ? `Rifaccio la trascrizione in ${dsLangName(code)}…` : "Torno alla lingua automatica…"));
  }
  await liveSetVideoLang(code);
  wordsCloseCard();
}

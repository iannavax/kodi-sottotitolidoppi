# Prove della 1.10: sottotitoli dentro il .mkv in streaming, letti a pezzetti (richieste Range) senza scaricare il film
import sys, os, json, time, shutil, threading, http.server, socketserver, re, urllib.parse
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
FILM = "/tmp/mkvt/film.mkv"
STATS = {"req": 0, "bytes": 0}
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        if not self.path.startswith("/d/XYZ/"):
            self.send_response(404); self.end_headers(); return
        size = os.path.getsize(FILM)
        m = re.match(r"bytes=(\d+)-(\d*)", self.headers.get("Range", ""))
        a = int(m.group(1)) if m else 0
        b = min(int(m.group(2)) if m and m.group(2) else size - 1, size - 1)
        with open(FILM, "rb") as f:
            f.seek(a); data = f.read(b - a + 1)
        STATS["req"] += 1; STATS["bytes"] += len(data)
        self.send_response(206 if m else 200)
        self.send_header("Content-Length", str(len(data))); self.send_header("Content-Range", "bytes %d-%d/%d" % (a, b, size))
        self.end_headers(); self.wfile.write(data)
srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), H); srv.daemon_threads = True
threading.Thread(target=srv.serve_forever, daemon=True).start()
URL = "http://127.0.0.1:%d/d/XYZ/Festen.1998.Danish.1080p.mkv" % srv.server_address[1]
from resources.lib import core
tr = lambda x: " ".join(w[::-1] for w in x.split())
real_http = core.http
def fake_http(url, data=None, headers=None, timeout=90):
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + tr(l) + "]" for l in q.split("\n")), q]], None, "da"]).encode(), {}
    if "opensubtitles" in url or "cinemeta" in url:
        return 200, b'{"subtitles": [{"id": "1", "url": "https://dl.os.example/1.srt", "lang": "dan"}], "metas": []}', {}
    return 404, b"", {}
core.http = fake_http
from resources.lib import runner, subtitles
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra",
                           "trans_color": "FFFF00", "auto": "true", "source_mode": "auto (file)", "trans_mode": "nuova (x)"})
xbmc.Player.playing = True; xbmc.Player.playing_file = URL; xbmc.Player.subs.clear(); xbmc.Player.sub_lang = "dan"
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": URL, "at": time.time() - 20})
size = os.path.getsize(FILM)
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
blocks = [b.split("\n") for b in t.strip().split("\n\n") if b.strip()]
print("1. sottotitoli dentro il .mkv in streaming:", len(blocks), "frasi |", blocks[0][1:3] if blocks else None)
print("   letti", STATS["bytes"], "byte su", size, "(%.1f%% del file) in %d richieste" % (100.0 * STATS["bytes"] / size, STATS["req"]))
print("   avviso:", [n for n in xbmcgui.NOTES if "dal video" in n][:1])
# 2. nel menu del lettore compaiono per primi
xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "1", "?action=search"])
print("2. menu del lettore:", [li.label2 for u, li in xbmcplugin.ITEMS][:3])
# 3. controllo
xbmcgui.TEXTS.clear()
runner.check_menu(xbmc.Player())
print("3. controllo:\n   " + xbmcgui.TEXTS[-1].replace("\n", "\n   "))
# 4. nuovo indirizzo di Real-Debrid per lo stesso film: già in cache, nessuna lettura
STATS["req"] = 0
xbmc.Player.playing_file = URL.replace("/d/XYZ/", "/d/XYZ/")  # stesso nome
xbmc.Player.subs.clear()
runner.run(xbmc.Player(), interactive=True)
print("4. rivisto: richieste al file", STATS["req"])
srv.shutdown()

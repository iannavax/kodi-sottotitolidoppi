# Parole al Volo 1.4 (prova): strumenti per imparare nella scheda, colore delle parole conosciute, %, immagine per Anki
import asyncio, os, sys, json
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
OTHER = ("https://en.wiktionary.org/", "https://tatoeba.org/", "https://api.tatoeba.org/", "https://api.languagetool.org/", "https://raw.githubusercontent.com/",
         "https://commons.wikimedia.org/", "https://upload.wikimedia.org/", "https://audio.tatoeba.org/")
async def handle(route, request):
    if request.url.startswith(OTHER): return await charness.handle(route, request)
    return await tvolo.handle(route, request)
DSX = "(document.querySelector('.pav-card .dsx')||{}).innerText"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, ankiImage:true, learnKnownPage:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/pagina.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "en", "bread", 3500)
        print("1. bread:\n" + await pg.evaluate(DSX))
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        async with ctx.expect_page() as np: await pg.locator(".pav-card .dsx-freqbtn").first.click()
        fp = await np.value; await fp.wait_for_timeout(1200)
        print("1b. elenco frequenze:", await fp.inner_text("#where")); await pg.bring_to_front()
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        print("2. pulsanti in alto:", await pg.evaluate("[...document.querySelectorAll('.pav-card .pav-tools .pav-btn')].map(b=>b.textContent)"), "| in basso:", await pg.evaluate("[...document.querySelectorAll('.pav-card .pav-actions .pav-btn')].map(b=>b.textContent)"))
        await pg.locator(".pav-card .pav-tools .pav-btn", has_text="🔊").click(); await pg.wait_for_timeout(1200)
        print("   clic 🔊: audio", charness.log.get("audio"))
        await pg.locator(".pav-card .dsx-btn", has_text="la conosco?").click(); await pg.wait_for_timeout(1500)
        print("3. conosciuta:", await pg.locator(".pav-card .dsx-known-on").inner_text(),
              "| colorate sulla pagina:", await pg.evaluate("CSS.highlights.has('pav-known') ? [...CSS.highlights.get('pav-known')].map(r=>r.toString()) : []"))
        await sw.evaluate("chrome.storage.sync.set({ankiAuto:true})"); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card .pav-star").click(); await pg.wait_for_timeout(3000)
        v = await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab).map(e=>({w:e.word, etym:e.etym, gender:e.gender, freq:e.freq, image:e.image})))")
        print("4. vocabolario:", v)
        add = [x[1] for x in tvolo.log["anki"] if x[0] == "addNote"]
        print("5. Anki addNote:", json.dumps(add[-1]["note"].get("picture"), ensure_ascii=False) if add else None, "| retro:", add[-1]["note"]["fields"]["Retro"][:160] if add else "")
        print("   🐢 frase:", await pg.locator(".pav-card .pav-btn", has_text="🔈 lenta").count())
        await pg.keyboard.press("Escape")
        # walked: tabella
        await tvolo.hover(pg, "en", "walked", 3500)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.locator(".pav-card .dsx-btn", has_text="tabella").click(); await pg.wait_for_timeout(500)
        print("6. walked tabella:", await pg.evaluate("[...document.querySelectorAll('.pav-card .dsx-table tr')].map(r=>r.innerText.replace(/\\s+/g,' '))"))
        await pg.keyboard.press("Escape")
        # Gemini: una richiesta con falsi amici e voto alla scrittura
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', pavEngine:'gemini'}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza'}}))"); await pg.wait_for_timeout(300)
        await tvolo.hover(pg, "en", "market", 3000)
        print("7. market prima:", (await pg.evaluate(DSX))[:200].replace("\n", " | "))
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.get_by_role("button", name="Spiega con Gemini").click(); await pg.wait_for_timeout(3500)
        print("   dopo:\n" + await pg.evaluate(DSX))
        print("   richieste define:", len([x for x in tvolo.log["gem"] if x[0] == "define"]), "con extra:", tvolo.log.get("extra"))
        await pg.keyboard.press("Escape")
        # percentuale nel popup
        tab = await sw.evaluate("chrome.tabs.query({}).then(t=>t.find(x=>/example.test/.test(x.url)).id)")
        print("8. percentuale:", await sw.evaluate(f"chrome.tabs.sendMessage({tab}, {{type:'pavComp'}})"))
        # tutto spento
        await sw.evaluate("chrome.storage.sync.set({etym:false, learnFreq:false, learnKnown:false, learnExamples:false, learnAudio:false, learnTable:false, learnGender:false, learnSpell:false, learnLlmExtra:false, gdAlt:false, gdDefs:false, gdSyn:false})")
        await pg.wait_for_timeout(800)
        c = (len(charness.log.get("tatoeba", [])), len(charness.log.get("lt", [])), len(charness.log.get("wikt", [])))
        await tvolo.hover(pg, "long", "weather", 3000)
        print("9. spento: dsx =", repr(await pg.evaluate(DSX)), "| richieste nuove", (len(charness.log.get("tatoeba", [])) - c[0], len(charness.log.get("lt", [])) - c[1], len(charness.log.get("wikt", [])) - c[2]),
              "| colorate:", await pg.evaluate("CSS.highlights.has('pav-known')"))
        print("errori:", errs, tvolo.log["errors"], charness.log["errors"])
        await ctx.close()
asyncio.run(main())

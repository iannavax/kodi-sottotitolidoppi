# Sincronizzazione diretta delle parole conosciute (e del vocabolario) tra le due estensioni, senza file
import asyncio, os, sys, json
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import charness
SD, PAV = sys.argv[1], sys.argv[2]
async def main():
    errs = []
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={SD},{PAV}", f"--load-extension={SD},{PAV}"])
        await ctx.route("**/*", charness.handle)
        await asyncio.sleep(2)
        sws = ctx.service_workers
        ids = {}
        for sw in sws:
            name = await sw.evaluate("chrome.runtime.getManifest().name"); ids[name] = (sw, sw.url.split("/")[2])
        sd, sdid = ids["Sottotitoli Doppi"]; pav, pavid = ids["Parole al Volo"]
        await sd.evaluate("chrome.storage.local.set({knownWords:{en:'you\\nthe', ru:'кошка'}, vocab:{'en|bread':{id:'en|bread', word:'bread', lang:'en', meaning:'pane', status:'learning'}}})")
        await pav.evaluate("chrome.storage.local.set({knownWords:{en:'home\\nthe', cs:'ahoj'}, vocab:{'cs|pivo':{id:'cs|pivo', word:'pivo', lang:'cs', meaning:'birra', status:'known', kind:'word'}}})")
        fp = await ctx.new_page(); fp.on("pageerror", lambda e: errs.append(str(e)))
        await fp.goto(f"chrome-extension://{sdid}/freq.html?lang=en"); await fp.wait_for_timeout(1200)
        print("1. pagina:", await fp.inner_text("#swapTitle"), "| pulsanti:", await fp.evaluate("[...document.querySelectorAll('#swap button')].map(b=>b.textContent)"))
        # nel banco di prova il permesso non si può concedere: l'indirizzo dell'altra lo do io
        await fp.evaluate(f"dsSiblingId = async () => '{pavid}'")
        await fp.click("#sync"); await fp.wait_for_timeout(1500)
        print("2. sincronizza:", await fp.inner_text("#impMsg"))
        print("   SD conosciute:", await sd.evaluate("chrome.storage.local.get('knownWords').then(r=>r.knownWords)"))
        print("   PAV conosciute:", await pav.evaluate("chrome.storage.local.get('knownWords').then(r=>r.knownWords)"))
        vp = await ctx.new_page(); vp.on("pageerror", lambda e: errs.append(str(e)))
        await vp.goto(f"chrome-extension://{pavid}/vocab.html"); await vp.wait_for_timeout(800)
        print("3. vocabolario PAV pulsante:", await vp.inner_text("#swapSync"))
        await vp.evaluate(f"dsSiblingId = async () => '{sdid}'")
        await vp.click("#swapSync"); await vp.wait_for_timeout(1500)
        print("   ", await vp.inner_text("#ankiMsg"))
        print("   SD voci:", sorted(await sd.evaluate("chrome.storage.local.get('vocab').then(r=>Object.keys(r.vocab))")), "| PAV voci:", sorted(await pav.evaluate("chrome.storage.local.get('vocab').then(r=>Object.keys(r.vocab))")))
        await vp.click("#swapSync"); await vp.wait_for_timeout(1500)
        print("4. di nuovo:", await vp.inner_text("#ankiMsg"))
        r = await fp.evaluate(f"chrome.runtime.sendMessage('{pavid}', {{type:'dsSync', data:{{from:'Altro', knownWords:{{en:['x']}}}}}})")
        print("5. estraneo:", r)
        print("errori:", errs, charness.log.get("errors"))
        await ctx.close()
asyncio.run(main())

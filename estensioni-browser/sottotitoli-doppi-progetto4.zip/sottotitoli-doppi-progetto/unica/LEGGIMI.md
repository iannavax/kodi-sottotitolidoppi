# Sottotitoli Doppi + Parole al Volo — le due estensioni in una

Questa è **una sola estensione** che fa tutto quello che fanno Sottotitoli Doppi (sottotitoli doppi nei video, trascrizione, scheda delle parole, dirette) e Parole al Volo (scheda delle parole e traduzione su qualsiasi pagina web). Le due estensioni separate continuano a esistere: questa è un'alternativa, per chi preferisce averne una sola.

## Come si usa
- Il pulsante dell'estensione apre il popup con due schede in alto: **🎬 Video** (le impostazioni di Sottotitoli Doppi) e **📄 Pagine** (quelle di Parole al Volo). Il popup si riapre sull'ultima scheda che hai usato.
- Nei video funziona come Sottotitoli Doppi; sulle pagine come Parole al Volo. Sopra i sottotitoli dei video le schede di Parole al Volo non compaiono (ci sono già quelle dei sottotitoli).
- Le scorciatoie da tastiera di Parole al Volo restano: Alt+Maiusc+Y (accendi/spegni), Alt+Maiusc+M (scheda passando il mouse), Alt+Maiusc+S (traduzione quando evidenzi).

## Cosa è in comune e cosa no
- **In comune**: le chiavi dei servizi (Gemini, Groq…), la lingua in cui traduci, il **vocabolario**, le **parole che conosci**, le voci della pronuncia, Anki, il programma per yt-dlp.
- **Separati** (perché hanno lo stesso nome ma servono a cose diverse): il servizio scelto (nei video traduce i sottotitoli, sulle pagine spiega le parole), i siti in cui è spenta, il mazzo di Anki unico, il colore delle parole che conosci sulla pagina, le lettere latine «Aa».

## Passare dalle due estensioni a questa
È un'estensione nuova, quindi parte vuota:
1. installala accanto alle due vecchie (non toglierle subito);
2. apri **Parole che conosco** (dal popup) e premi **⇄ Sincronizza adesso**, poi nel **vocabolario** premi **⇄ Sincronizza**: vocabolario e parole conosciute arrivano dalle estensioni vecchie;
3. inserisci di nuovo le **chiavi** (Gemini, Groq…) nel popup;
4. per il programma yt-dlp: apri la sua pagina dal popup (Video → Video senza sottotitoli → Programma per yt-dlp) e rilancia l'installatore, così riconosce anche questa estensione;
5. quando tutto funziona, puoi togliere le due vecchie. Non usare le vecchie e la nuova insieme sulle stesse pagine: le schede comparirebbero due volte.

## Aggiornare
Come per le altre: su Edge sostituisci i file nella stessa cartella e premi ↻; su Firefox installa il nuovo .xpi sopra quello vecchio. Non rimuovere l'estensione, perderesti chiavi, vocabolario e parole conosciute.

Per tutto il resto valgono le guide delle due estensioni.

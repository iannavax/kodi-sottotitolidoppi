# 1.7.28: correzione dei sottotitoli automatici a video aperto (opzione accesa dopo, o pulsante ✨ nella scheda ⚑)
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def setup(p):
    ctx, sw = await launch(p, "", None)
    await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
    await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:false, cleanAsr:false, cleanMode:'off'})")
    pg = await ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
    await pg.evaluate("document.querySelector('video').play()")
    await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
    await pg.evaluate("document.querySelector('video').pause()")
    return ctx, sw, pg, errs
T = "(document.querySelector('.dualsub-orig')||{}).textContent"
async def main():
    async with async_playwright() as p:
        ctx, sw, pg, errs = await setup(p)
        a = await pg.evaluate(T)
        await sw.evaluate("chrome.storage.sync.set({cleanAsr:true})"); await pg.wait_for_timeout(6000)
        b = await pg.evaluate(T)
        print("1. prima:", repr(a), "| acceso dopo:", repr(b), "|", await sw.evaluate("chrome.storage.local.get('status').then(r => (r.status||{}).text)"))
        await sw.evaluate("chrome.storage.sync.set({cleanAsr:false})"); await pg.wait_for_timeout(2500)
        c = await pg.evaluate(T)
        print("2. spento di nuovo:", repr(c))
        await ctx.close()
        ctx, sw, pg, errs2 = await setup(p)
        await pg.locator(".dualsub-orig").hover(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-flagbtn").evaluate("x=>x.click()"); await pg.wait_for_timeout(500)
        btn = pg.locator(".dualsub-fixcard button", has_text="Correggili con il modello")
        print("3. pulsante nella scheda ⚑:", await btn.count())
        await btn.first.click(); await pg.wait_for_timeout(7000)
        d = await pg.evaluate(T)
        print("   dopo il clic:", repr(d), "| opzione ancora spenta:", not await sw.evaluate("chrome.storage.sync.get('cleanAsr').then(r=>r.cleanAsr)"))
        ok = a != b and b[:1].isupper() and c == a and d != a and d[:1].isupper()
        print("errori:", errs + errs2 if ok else errs + errs2 + ["correzione non applicata"], log["errors"])
        await ctx.close()
asyncio.run(main())

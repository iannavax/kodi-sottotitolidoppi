## Novità della 5.18.5
- **Due grandezze separate** nel popup → Aspetto: «Lettere sopra i caratteri» (la trascrizione di ogni carattere o sillaba) e «Lettura della riga (romaji)» (la lettura di tutta la riga sopra il sottotitolo, per kanji e cinese). Si regolano ognuna per conto suo e cambiano subito.

## Novità della 5.18.4
- **Giapponese**: alcune sillabe (per esempio は "wa", い "i") non si potevano evidenziare né cliccare, perché in Firefox lo spezzatore di parole non le considera "parole". Ora ogni pezzo con una lettera è una parola cliccabile. Lo stesso in Parole al Volo (1.11.2).

## Novità della 5.18.3
- **Modi di dire e parola singola**: cliccando una parola sottolineata si apre tutto il modo di dire; cliccandola di nuovo si apre la parola da sola, e al clic dopo di nuovo l'espressione. Nella scheda ci sono anche «Solo la parola «…»» e «Tutto il modo di dire «…» ›». Prima, dopo l'analisi, non si riusciva più a guardare la parola da sola.

## Novità della 5.18.2
- **La trascrizione resta nella lingua del video**: se il video ha i sottotitoli automatici di YouTube, la loro lingua viene imposta a Whisper fin dall'inizio, e quei sottotitoli gli vengono dati come suggerimento (parole più giuste). Prima, con la lingua "automatica", Whisper poteva cominciare a scrivere la traduzione inglese invece della trascrizione e poi restarci.
- **Controllo di ogni pezzo**: se un pezzo arriva in inglese o in un altro alfabeto (per esempio lettere latine in un video russo), si rifà senza suggerimento, poi con il modello più preciso; se è ancora sbagliato si salta. Anche senza sottotitoli di YouTube, l'inglese che compare insieme a un'altra lingua non fa più diventare "inglese" il video.
- Una trascrizione salvata in una lingua diversa da quella del video viene buttata e rifatta.
- La correzione automatica della trascrizione (con Gemini/Groq) ora accetta solo piccole correzioni nella stessa lingua: niente frasi riscritte "con lo stesso senso".
- **Pulsante DS**: se YouTube non manda il testo dei sottotitoli, i CC si spengono e riaccendono una volta sola (prima lampeggiavano a ogni clic); poi il messaggio dice di ricaricare la pagina.

## Novità della 5.18.1
- **⇄ Sincronizza adesso** nella pagina delle parole più usate: le parole che conosci passano da Sottotitoli Doppi a Parole al Volo e viceversa con un clic, senza file (si uniscono, non si cancella niente). Nel vocabolario **⇄ Sincronizza con Parole al Volo** fa lo stesso anche con le voci del vocabolario. Serve l'altra estensione installata, accesa e aggiornata; su Edge/Chrome la prima volta il browser chiede il permesso di vedere le estensioni installate (per trovarla). Restano anche **Esporta in un file** e **Importa da un file…**, ora sempre in vista.

## Novità della 5.18
- **JLPT cliccabile**: nella scheda di una parola giapponese il segno «JLPT N5 ›» (N4, N3…) apre la nuova pagina **Parole del JLPT**: tutte le parole di quel livello (dal dizionario Jisho, gratis), con lettura, significato, la parola da cui arrivi evidenziata, «la conosco?» e quante ne conosci. Si passa da un livello all'altro con le schede N5…N1.
- **Livelli per tutte le lingue**: accanto alla frequenza c'è «livello ≈ B1 ›» (da A1 a C2), che apre l'elenco delle parole più usate proprio a quel livello. È indicativo: viene solo dalla posizione nell'elenco (A1 = le prime 500 parole, A2 fino a 1000, B1 fino a 2000, B2 fino a 4000, C1 fino a 8000, C2 fino a 16.000), non da un elenco ufficiale.
- Nella pagina delle parole più usate: barra dei livelli A1…C2 (passando il mouse, quante ne conosci per ognuno) e, per il giapponese, i collegamenti ai livelli JLPT.


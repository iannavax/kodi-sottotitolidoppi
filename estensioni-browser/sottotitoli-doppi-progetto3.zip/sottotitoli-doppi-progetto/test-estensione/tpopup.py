import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'openrouter', models:{openrouter:'meta-llama/llama-3.3-70b-instruct:free-molto-lungo-per-prova'}})")
        pp = await ctx.new_page()
        await pp.set_viewport_size({"width": 360, "height": 600})
        await pp.goto(f"chrome-extension://{sw.url.split('/')[2]}/popup.html"); await pp.wait_for_timeout(800)
        # opzione lunga come i nomi delle voci di Windows
        await pp.evaluate("""const g=document.getElementById('ttsVoices'); const o=document.createElement('option');
          o.textContent='Microsoft Elvira Online (Natural) - Spanish (Spain) (es-ES)'; g.append(o);
          document.querySelectorAll('details').forEach(d=>d.open=true)""")
        await pp.wait_for_timeout(300)
        r = await pp.evaluate("""(()=>{const W=document.body.clientWidth; const bad=[...document.querySelectorAll('select,input,button,label,p')]
          .filter(e=>{const b=e.getBoundingClientRect(); return b.width>0 && b.right>W+1}).map(e=>(e.id||e.tagName)+':'+Math.round(e.getBoundingClientRect().right));
          return {larghezzaPagina: document.documentElement.scrollWidth, finestra: innerWidth, elementiFuori: bad.slice(0,8)}})()""")
        print(sys.argv[1].split('/')[-2], r)
        await ctx.close()
asyncio.run(main())

# 1.4.13: interfaccia nella lingua di «Traduci in» sulle pagine: cosa resta in italiano nella scheda della parola?
# (qui Google finto risponde «IT[…]», anche per le scritte dell'interfaccia)
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo, urllib.parse, json
EXT = sys.argv[1]
LEFT = """() => {
  const SKIP = ".pav-word, .pav-meaning, .pav-sentence, .pav-sentrans, .pav-example, .pav-sel-text, .dsx-ex-item, .dsx-def-text, .pav-saved-mean, .dsui-skip, textarea";
  const out = new Set();
  for (const root of document.querySelectorAll('.pav-root')) {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let n;
    while ((n = w.nextNode())) { const p = n.parentElement, t = n.nodeValue.trim();
      if (!p || p.closest(SKIP) || !p.offsetParent || !/[a-zà-ù]{3}/i.test(t) || /UI-de<|IT\\[/.test(t)) continue; out.add(t.slice(0, 80)); }
    for (const e of root.querySelectorAll('[title]')) if (!e.closest(SKIP) && e.offsetParent && /[a-zà-ù]{4}/i.test(e.title) && !/UI-de</.test(e.title)) out.add("title: " + e.title.slice(0, 80));
  }
  return [...out];
}"""
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        async def handle(route, request):
            u = request.url
            if u.startswith("https://translate.googleapis.com/translate_a/single") and urllib.parse.parse_qs(urllib.parse.urlparse(u).query).get("sl", [""])[0] == "it":
                q = urllib.parse.parse_qs(urllib.parse.urlparse(u).query); text = q.get("q", [""])[0]
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps([[["\n".join("UI-de<" + l + ">" for l in text.split("\n")), text]], None, "it"]))
            return await tvolo.handle(route, request)
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'de', uiLang:true, ipa:true, engine:'groq', pavEngine:'groq'}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "bread", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(5000)
        a = await pg.evaluate(LEFT)
        await pg.locator(".pav-card button.pav-main").first.click(); await pg.wait_for_timeout(6000)
        c = await pg.evaluate(LEFT)
        left = sorted(set(a + c))
        print("rimasti in italiano:", len(left))
        for t in left: print("   -", t)
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

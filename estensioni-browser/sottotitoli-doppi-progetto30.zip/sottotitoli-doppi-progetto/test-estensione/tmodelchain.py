# 1.6.1: un modello di Gemini finisce le richieste di oggi → si blocca solo quel modello e si continua con l'altro
# modello di Gemini (prima si fermava tutto Gemini). Nel popup: l'elenco dei modelli per compito, con lo stato.
import asyncio, os, sys, json
os.environ["GEM_DAILY_MODEL"] = "gemini-flash-lite-latest"
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false, learnExamples:false, learnSpell:false, learnFreq:false, learnLlmExtra:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/GEM\\[/.test((document.querySelector('.dualsub-trans')||{}).textContent||'')", timeout=40000)
        tr = await pg.evaluate("(document.querySelector('.dualsub-trans')||{}).textContent")
        st = await sw.evaluate("chrome.storage.local.get(['status','dsBlocked']).then(r=>JSON.stringify([r.status&&r.status.text, Object.keys(r.dsBlocked||{})]))")
        print("1. traduzione:", tr[:50], "| modelli chiesti:", log.get("gmodels"), "| stato e blocchi:", st)
        # spiegazione: Flash (non finito) risponde
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(1500)
        await spiega(pg, 5000)
        mean = await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-card-meaning')||{}).textContent")
        print("2. spiegazione:", mean, "| ultimo modello:", log.get("gmodels", [])[-1:])
        # popup: elenco dei modelli per la traduzione, con lo stato di oggi
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1500)
        await pp.evaluate("document.querySelectorAll('details').forEach(d=>d.open=true)"); await pp.wait_for_timeout(800)
        rows = await pp.evaluate("(()=>{const l=document.querySelector('.ds-tasks .ds-task-video').closest('label'); let n=l.nextElementSibling; while(n&&!n.classList.contains('ds-task-model')) n=n.nextElementSibling; return n ? [...n.querySelectorAll('.ds-task-mrow')] : []})().map(r=>r.innerText.replace(/\\n/g,' '))")
        ban = await pp.evaluate("(document.getElementById('blockedBox')||{}).innerText||''")
        print("3. popup, sottotitoli:", rows, "| avviso:", ban[:160])
        # ↑ sul secondo: diventa primo
        await pp.evaluate("(()=>{const l=document.querySelector('.ds-tasks .ds-task-video').closest('label'); let n=l.nextElementSibling; while(n&&!n.classList.contains('ds-task-model')) n=n.nextElementSibling; return n ? [...n.querySelectorAll('.ds-task-mrow')] : []})()[1].querySelector('button').click()"); await pp.wait_for_timeout(800)
        tm = await sw.evaluate("chrome.storage.sync.get('taskModels').then(r=>JSON.stringify(r.taskModels['engine|gemini']))")
        print("4. dopo ↑:", tm)
        ok = "GEM[" in tr and "gemini-flash-latest" in (log.get("gmodels") or []) and any("gemini|gemini-flash-lite-latest" in x for x in [st]) and '"gemini"' not in st.split("]")[0].split("[")[-1] \
             and mean and rows and "finito oggi" in rows[0] and tm.startswith('["gemini-flash-latest"')
        print("errori:", errs if ok else errs + ["catena dei modelli non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

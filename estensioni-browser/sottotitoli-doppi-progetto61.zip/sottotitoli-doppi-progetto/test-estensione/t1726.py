# 1.7.26: lettura parola per parola (mouse → parola nell'originale), «Tieni fermo il testo», ⚑ sempre visibile, vocabolario per lingua
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def video(pg, vid, first):
    await pg.goto("https://www.youtube.com/watch?v=" + vid); await pg.wait_for_timeout(1200)
    await pg.evaluate("document.querySelector('video').play()")
    await pg.wait_for_function(f"/{first}/.test((document.querySelector('.dualsub-orig')||{{}}).textContent||'')", timeout=40000)
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:false, roman:true, romanHan:true})")
        # vocabolario: «привет» salvato come ucraino (non deve sottolineare il russo) e «дела» come russo (sì)
        await sw.evaluate("""chrome.storage.local.set({vocab:{'uk|привет':{id:'uk|привет',word:'привет',lang:'uk',status:'learning'},'ru|дела':{id:'ru|дела',word:'дела',lang:'ru',status:'learning'}}})""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await video(pg, "ruRoman", "Привет")
        await pg.evaluate("document.querySelector('video').pause()")
        s = await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-word')].map(w=>w.textContent.replace(/\\s/g,'')+':'+w.classList.contains('dualsub-saved'))")
        print("1. vocabolario per lingua (russo):", s)
        await video(pg, "jaRoman", "日本語")
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(1500)
        row = pg.locator(".dualsub-romaline .dsr-w")
        n = await row.count()
        print("2. parole nella lettura:", n, "|", await pg.evaluate("(document.querySelector('.dualsub-romaline')||{}).textContent"))
        await row.nth(0).hover(); await pg.wait_for_timeout(200)
        print("   mouse sulla 1ª lettura → evidenziata:", await pg.evaluate("[...document.querySelectorAll('.dualsub-word.dualsub-hl')].map(w=>w.textContent.replace(/\\s|[a-z]/g,''))"))
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(500)
        # ⚑ senza frase: porto il video oltre l'ultima frase
        await pg.evaluate("(()=>{const v=document.querySelector('video'); v.currentTime=Math.max(0,v.duration-0.2)||60;})()"); await pg.wait_for_timeout(1500)
        info = await pg.evaluate("(()=>{const o=document.querySelector('.dualsub-overlay'),b=document.querySelector('.dualsub-flagbtn'); return {hidden:o&&o.hidden, line:o&&o.classList.contains('dualsub-has-line'), flag:b&&getComputedStyle(b).display}})()")
        print("3. senza frase: ", info)
        if info.get("flag") and info["flag"] != "none":
            await pg.locator(".dualsub-flagbtn").evaluate("x=>x.click()"); await pg.wait_for_timeout(400)
            print("   scheda ⚑:", (await pg.evaluate("(document.querySelector('.dualsub-fixcard')||{}).innerText||''"))[:200].replace("\n", " | "))
        # tieni fermo il testo
        await sw.evaluate("chrome.storage.sync.set({holdOnHover:true})")
        await pg.keyboard.press("Escape")
        await pg.evaluate("(()=>{const v=document.querySelector('video'); v.currentTime=0.2; v.play();})()")
        await pg.wait_for_function("/日本語/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=20000)
        await pg.locator(".dualsub-orig").hover()
        t0 = await pg.evaluate("document.querySelector('.dualsub-orig').textContent")
        await pg.wait_for_timeout(5500)
        t1 = await pg.evaluate("document.querySelector('.dualsub-orig').textContent")
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(1200)
        t2 = await pg.evaluate("document.querySelector('.dualsub-orig').textContent")
        print("4. fermo col mouse sopra:", t0 == t1, "| dopo aver tolto il mouse cambia:", t2 != t1, "|", repr(t0[:12]), repr(t2[:12]))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# 1.5.1: modi di dire sulle pagine: «non è un modo di dire» si annulla dalla scheda (🚫 … annulla) e «✎ Correggi il modo
# di dire» cambia l'espressione stessa
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
IDI = "(document.querySelector('.pav-card .pav-idiom')||{}).innerText||'(nessuno)'"
async def run(p, expr):
    os.environ["IDIOM"] = expr
    ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
    await ctx.route("**/*", tvolo.handle)
    sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
    try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
    except Exception: pass
    await sw.evaluate("chrome.storage.sync.set({targetLang:'it', engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
    pg = await ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
    async def explain():
        await tvolo.hover(pg, "en", "bread", 2500)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.get_by_role("button", name="Spiega con Groq").click(); await pg.wait_for_timeout(3000)
    await explain()
    return ctx, sw, pg, errs, explain
async def main():
    async with async_playwright() as p:
        ctx, sw, pg, errs, explain = await run(p, "fresh bread")
        a = (await pg.evaluate(IDI)).replace("\n", " | "); print("1.", a)
        await pg.locator(".pav-card button", has_text="⚑ modo di dire sbagliato?").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card button", has_text="Non è un modo di dire").click(); await pg.wait_for_timeout(500)
        b = await pg.evaluate(IDI); row = await pg.evaluate("(document.querySelector('.pav-card .pav-flagged')||{}).innerText||''")
        print("2. tolto:", b, "| riga:", row.replace("\n", " "))
        await pg.locator(".pav-card .pav-flagged button", has_text="annulla").first.click(); await pg.wait_for_timeout(600)
        c = (await pg.evaluate(IDI)).replace("\n", " | "); print("3. annullato:", c)
        await pg.locator(".pav-card button", has_text="⚑ modo di dire sbagliato?").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card button", has_text="Correggi il modo di dire").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card .pav-idiom input.pav-fixinput").fill("some fresh bread")
        await pg.locator(".pav-card .pav-idiom textarea.pav-fixinput").last.fill("un po' di pane fresco")
        await pg.locator(".pav-card .pav-idiom").get_by_role("button", name="Salva", exact=True).last.click(); await pg.wait_for_timeout(600)
        st = await sw.evaluate("chrome.storage.local.get(['idiomFlags','pavIdioms']).then(r=>JSON.stringify([Object.keys(r.idiomFlags||{}), Object.keys(r.pavIdioms||{})]))")
        print("4. corretto:", st)
        ok = "fresh bread" in a and b == "(nessuno)" and "annulla" in row and "fresh bread" in c and "some fresh bread" in st
        print("errori:", errs if ok else errs + ["correzioni dei modi di dire non vanno"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

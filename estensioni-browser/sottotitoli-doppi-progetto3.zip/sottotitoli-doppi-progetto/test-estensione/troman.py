# 5.17: lettere latine sopra le lettere nei sottotitoli (roman.js), pulsante Aa, riga kanji da Google
import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
R = "[...document.querySelectorAll('.dualsub-orig .dualsub-word')].map(w=>[...w.querySelectorAll('.dsr')].map(x=>x.dataset.r||'·').join('-')).join(' ')"
async def video(pg, vid, first):
    await pg.goto("https://www.youtube.com/watch?v=" + vid); await pg.wait_for_timeout(1200)
    await pg.evaluate("document.querySelector('video').play()")
    await pg.wait_for_function(f"/{first}/.test((document.querySelector('.dualsub-orig')||{{}}).textContent||'')", timeout=40000)
    await pg.evaluate("document.querySelector('video').pause()")
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await video(pg, "ruRoman", "Привет")
        await pg.locator(".dualsub-orig").hover(); await pg.wait_for_timeout(300)
        b = pg.locator(".dualsub-romabtn")
        print("1. spento: pulsante visibile", await b.is_visible(), "| lettere:", await pg.evaluate(R))
        await b.evaluate("x=>x.click()"); await pg.wait_for_timeout(300)
        print("2. Aa:", await pg.evaluate(R), "| testo:", repr(await pg.evaluate("document.querySelector('.dualsub-orig').textContent")), "| salvato:", await sw.evaluate("chrome.storage.sync.get('roman').then(r=>r.roman)"))
        words = pg.locator(".dualsub-orig .dsr").first
        await words.click(); await pg.wait_for_timeout(1500)
        print("3. clic su una lettera → scheda:", (await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-card-title')||document.querySelector('.dualsub-card')||{}).textContent||''"))[:60])
        await pg.keyboard.press("Escape"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-orig").hover(); await pg.wait_for_timeout(200)
        await b.evaluate("x=>x.click()"); await pg.wait_for_timeout(300)
        print("4. spento di nuovo:", repr(await pg.evaluate(R)))
        await b.evaluate("x=>x.click()"); await pg.wait_for_timeout(200)
        await video(pg, "jaRoman", "日本語")
        await pg.wait_for_timeout(1200)
        print("5. giapponese:", await pg.evaluate(R), "| riga:", await pg.evaluate("(document.querySelector('.dualsub-romaline')||{}).textContent"))
        await sw.evaluate("chrome.storage.sync.set({romanHan:false})"); await pg.wait_for_timeout(1500)
        print("6. senza riga Google:", await pg.evaluate("(()=>{const r=document.querySelector('.dualsub-romaline'); return r? r.hidden : 'nessuna'})()"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

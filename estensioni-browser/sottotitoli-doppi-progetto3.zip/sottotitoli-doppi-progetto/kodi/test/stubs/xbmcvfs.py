import os
def translatePath(p): return p.replace("special://temp/", "/tmp/kodi-temp/").replace("special://profile/", "/tmp/kodi-userdata/")
def listdir(p):
    p = translatePath(p)
    if not os.path.isdir(p): raise OSError(p)
    items = os.listdir(p)
    return [i for i in items if os.path.isdir(os.path.join(p, i))], [i for i in items if os.path.isfile(os.path.join(p, i))]
class Stat:
    def __init__(self, p): self.p = translatePath(p)
    def st_mtime(self): return os.path.getmtime(self.p)
class File:
    def __init__(self, p, mode="r"): self.f = open(translatePath(p), "wb" if mode == "w" else "rb")
    def readBytes(self): return bytearray(self.f.read())
    def write(self, data): self.f.write(data if isinstance(data, (bytes, bytearray)) else data.encode("utf-8")); return True
    def close(self): self.f.close()

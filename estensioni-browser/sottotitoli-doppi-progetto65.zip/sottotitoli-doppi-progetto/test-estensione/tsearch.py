import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        ext = sw.url.split("/")[2]
        pop = await ctx.new_page(); errs = []
        pop.on("pageerror", lambda e: errs.append(str(e)))
        await pop.goto(f"chrome-extension://{ext}/popup.html"); await pop.wait_for_timeout(1500)
        for q in ["tieni fermo", "kokoro", "anki immagini", "zzzz"]:
            await pop.fill("#optSearch", q); await pop.wait_for_timeout(400)
            print(repr(q), await pop.evaluate("[...document.querySelectorAll('#optSearchRes button, #optSearchRes .small')].map(b=>b.textContent)"))
        await pop.fill("#optSearch", "tieni fermo"); await pop.wait_for_timeout(400)
        before = await pop.evaluate("document.querySelector('#holdOnHover').closest('details').open")
        await pop.locator("#optSearchRes button").first.click(); await pop.wait_for_timeout(700)
        print("sezione aperta prima/dopo:", before, await pop.evaluate("document.querySelector('#holdOnHover').closest('details').open"), "| evidenziata:", await pop.evaluate("document.querySelector('#holdOnHover').closest('label').style.outline"))
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

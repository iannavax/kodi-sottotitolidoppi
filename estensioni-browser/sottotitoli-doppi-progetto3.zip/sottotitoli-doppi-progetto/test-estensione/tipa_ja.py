# 5.9.1: riga IPA con sottotitoli giapponesi (il modello riscrive le chiavi), e motivo visibile quando manca
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def run(keys, note):
    log["ipa"] = []
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("(k) => chrome.storage.sync.set({engine:'google', targetLang:'it'}).then(()=>chrome.storage.local.set({keys:k}))", keys)
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=jaIpa"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        try: await pg.wait_for_function("document.querySelectorAll('.dualsub-ipa .dualsub-ipaw').length>0 || document.querySelector('.dualsub-ipa-hint')", timeout=25000)
        except Exception: pass
        await pg.evaluate("document.querySelector('video').pause()")
        await pg.locator(".dualsub-orig").hover(); await pg.wait_for_timeout(400)
        print(note, "| originale:", await pg.inner_text(".dualsub-orig"), "| IPA:", await pg.inner_text(".dualsub-ipa"),
              "| parole:", await pg.evaluate("document.querySelectorAll('.dualsub-orig .dualsub-word').length"), "pronunce:", await pg.evaluate("document.querySelectorAll('.dualsub-ipaw:not(.dualsub-ipa-none)').length"),
              "| richieste:", [(w, len(x)) for w, x in log["ipa"]], "| errori:", errs, log["errors"])
        await ctx.close()
async def main():
    await run({"groq": "gsk-test"}, "1. con Groq")
    await run({}, "2. senza chiavi")
asyncio.run(main())

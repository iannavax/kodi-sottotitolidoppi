// Scelta del servizio di traduzione nel popup — comune a Sottotitoli Doppi e Parole al Volo (stesso aspetto, stessi
// servizi, stesse chiavi). Usa: DS_EXT, DS_CONFIG (config.js).
// DS_ENGINES_UI.mount(box, { purpose }) disegna tutto; DS_ENGINES_UI.banner(box, id) solo l'avviso "richieste finite".
var DS_ENGINES_UI = (() => {
  const C = DS_CONFIG;
  const mk = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const nameOf = (id) => (C.ENGINES[id] ? C.ENGINES[id].label.split(" (")[0].split(",")[0] : id);
  const pacificDay = () => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return new Date().toISOString().slice(0, 10); } };
  // ora italiana (del computer) in cui si azzerano le quote di Gemini: mezzanotte di Los Angeles
  const resetTime = () => {
    try {
      const now = new Date();
      const la = new Date(now.toLocaleString("en-US", { timeZone: "America/Los_Angeles" }));
      const ms = (24 * 3600e3) - ((la.getHours() * 3600 + la.getMinutes() * 60 + la.getSeconds()) * 1000);
      return new Date(now.getTime() + ms).toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
    } catch { return "domani mattina"; }
  };

  // Avviso: il servizio scelto ha finito le richieste gratuite di oggi → quale si usa al suo posto, e "Riprova adesso"
  async function banner(box, id, onChange) {
    if (!box) return;
    box.textContent = "";
    const r = await DS_EXT.storage.local.get({ dsBlocked: {}, keys: {} });
    const s = await DS_EXT.storage.sync.get({ fallback: true });
    const b = (r.dsBlocked || {})[id];
    if (!b || b.day !== pacificDay()) { box.hidden = true; return; }
    const ord = await DS_EXT.storage.sync.get({ engineOrder: [], engineOff: [] });
    const next = s.fallback === false ? null : C.engineOrder(ord).find((x) => x !== id && C.ENGINES[x] && (r.keys || {})[x] && !((r.dsBlocked || {})[x] && r.dsBlocked[x].day === pacificDay()));
    box.hidden = false;
    box.append(mk("b", null, "⚠ " + nameOf(id) + " ha finito le richieste gratuite di oggi."),
      document.createTextNode(" Tornano verso le " + resetTime() + ". Intanto " + (next ? "uso " + nameOf(next) + " (servizio di riserva)." : "uso Google Traduttore.") + " "));
    const retry = mk("button", "ghost", "Riprova " + nameOf(id) + " adesso");
    retry.type = "button";
    retry.title = "Se pensi che le richieste ci siano di nuovo (per esempio hai cambiato chiave o modello), riprova subito";
    retry.addEventListener("click", async () => {
      const cur = (await DS_EXT.storage.local.get({ dsBlocked: {} })).dsBlocked || {};
      delete cur[id];
      await DS_EXT.storage.local.set({ dsBlocked: cur });
      banner(box, id, onChange);
      if (onChange) onChange();
    });
    box.append(retry);
  }

  // Tutta la sezione: servizio, nota, chiave, area (Microsoft), indirizzo (locale), modello, riserva
  function mount(box, opts = {}) {
    // dove stanno le impostazioni (l'estensione unica dà a Parole al Volo un archivio suo per "engine")
    const ST = (opts && opts.store) || DS_EXT.storage.sync;
    if (!box) return;
    let s = {}, keys = {};
    const ids = Object.keys(C.ENGINES).filter((id) => !(opts.exclude || ["youtube"]).includes(id));
    box.textContent = "";
    const sel = mk("select"); sel.id = "engine";
    for (const id of ids) sel.append(new Option(C.ENGINES[id].label, id));
    const lab = mk("label", "stack", opts.label || "Come tradurre"); lab.append(sel);
    const note = mk("p", "small");
    const purpose = mk("p", "small");
    const urlRow = mk("label", "stack", "Indirizzo del programma"); const url = mk("input"); url.type = "text"; url.spellcheck = false; urlRow.append(url);
    const urlHint = mk("p", "small", "Ollama: http://localhost:11434/v1. LM Studio: http://localhost:1234/v1");
    const keyRow = mk("label", "stack", "Chiave API");
    const keyLine = mk("span", "keyline");
    const key = mk("input"); key.type = "password"; key.placeholder = "Incolla qui la chiave"; key.autocomplete = "off"; key.spellcheck = false;
    const show = mk("button", "ghost", "Mostra"); show.type = "button";
    show.addEventListener("click", (e) => { e.preventDefault(); key.type = key.type === "password" ? "text" : "password"; show.textContent = key.type === "password" ? "Mostra" : "Nascondi"; });
    keyLine.append(key, show); keyRow.append(keyLine);
    const regRow = mk("label", "stack", "Area della risorsa (per esempio westeurope)"); const reg = mk("input"); reg.type = "text"; reg.placeholder = "westeurope"; reg.spellcheck = false; regRow.append(reg);
    const link = mk("a", "small", "Crea una chiave"); link.target = "_blank"; link.rel = "noopener";
    const modelBox = mk("div", "stack");
    const model = mk("input"); model.type = "text"; model.spellcheck = false; model.setAttribute("list", "dsModelList");
    const list = mk("datalist"); list.id = "dsModelList";
    const load = mk("button", "ghost", "Carica modelli"); load.type = "button";
    const mrow = mk("span", "keyline"); mrow.append(model, load);
    const mmsg = mk("p", "small");
    modelBox.append(mk("span", null, "Modello"), mrow, list, mmsg);
    const fbRow = mk("label", "row", "Se finiscono le richieste gratuite, continua con un altro servizio di cui hai la chiave ");
    const fb = mk("input"); fb.type = "checkbox"; fbRow.append(fb);
    const fbInfo = mk("p", "small");
    const warn = mk("div", "small ds-blocked"); warn.hidden = true;
    const ordBox = mk("div", "ds-order");
    box.append(lab, warn, note, purpose, urlRow, urlHint, keyRow, regRow, link, modelBox, fbRow, fbInfo, ordBox);
    order(ordBox, { store: ST, defaultEngine: opts.defaultEngine, onUse: (id) => { s.engine = id; render(); } });

    const cur = () => (C.ENGINES[s.engine] && ids.includes(s.engine) ? s.engine : "google");
    function render() {
      const id = cur(), E = C.ENGINES[id];
      sel.value = id;
      note.textContent = E.note || "";
      purpose.textContent = opts.purpose ? opts.purpose(id, E) : "";
      purpose.hidden = !purpose.textContent;
      keyRow.hidden = link.hidden = !E.needsKey;
      if (E.keyUrl) link.href = E.keyUrl;
      key.value = keys[id] || "";
      urlRow.hidden = urlHint.hidden = !E.local;
      url.value = s.localUrl || C.SYNC_DEFAULTS.localUrl;
      regRow.hidden = E.kind !== "microsoft";
      reg.value = s.msRegion || "";
      const hasModel = E.kind === "openai" || E.kind === "claude";
      modelBox.hidden = !hasModel;
      model.value = (s.models || {})[id] || E.defaultModel || "";
      list.innerHTML = "";
      (E.staticModels || []).forEach((m) => list.append(new Option(m, m)));
      mmsg.textContent = "";
      fb.checked = s.fallback !== false;
      const ready = C.engineOrder(s).filter((x) => keys[x] || (C.ENGINES[x] && C.ENGINES[x].local && (s.models || {})[x]));
      fbInfo.textContent = s.fallback === false ? "" : ready.length
        ? "Servizi con la chiave, in quest'ordine: " + ready.map(nameOf).join(", ") + ". Poi Google Traduttore."
        : "Per avere servizi di riserva, scegli Groq, Mistral o OpenRouter qui sopra e inserisci la loro chiave gratuita (poi torna al servizio che preferisci).";
      banner(warn, id, render);
      if (opts.onChange) opts.onChange(id, E);
    }
    async function loadModels(auto) {
      const id = cur(), E = C.ENGINES[id];
      if (E.kind !== "openai") return;
      if (E.needsKey && !keys[id]) { if (!auto) mmsg.textContent = "Inserisci prima la chiave."; return; }
      mmsg.textContent = "Cerco i modelli disponibili…";
      let r;
      try { r = await DS_EXT.runtime.sendMessage({ type: "listModels", engine: id, key: keys[id] || "", localUrl: s.localUrl }); } catch (e) { r = { error: String(e.message || e) }; }
      if (cur() !== id) return;
      if (!r || r.error) { mmsg.textContent = "Errore: " + ((r && r.error) || "nessuna risposta"); return; }
      list.innerHTML = "";
      r.models.forEach((m) => list.append(new Option(m, m)));
      mmsg.textContent = r.models.length ? `${r.models.length} modelli trovati: clicca nel campo per sceglierne un altro.` : "Nessun modello trovato.";
      if (!model.value && r.suggested) { model.value = r.suggested; saveModel(r.suggested); }
    }
    function saveModel(m) { s.models = { ...(s.models || {}), [cur()]: m }; ST.set({ models: s.models }); }
    sel.addEventListener("change", () => { s.engine = sel.value; ST.set({ engine: s.engine }); render(); if (!model.value) loadModels(true); });
    key.addEventListener("change", async () => {
      keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
      keys[cur()] = key.value.trim();
      await DS_EXT.storage.local.set({ keys });
      render();
      if (!model.value) loadModels(true);
    });
    url.addEventListener("change", () => { s.localUrl = url.value.trim() || C.SYNC_DEFAULTS.localUrl; ST.set({ localUrl: s.localUrl }); loadModels(true); });
    reg.addEventListener("change", () => { s.msRegion = reg.value.trim(); ST.set({ msRegion: s.msRegion }); });
    model.addEventListener("change", () => saveModel(model.value.trim()));
    load.addEventListener("click", () => loadModels(false));
    fb.addEventListener("change", () => { s.fallback = fb.checked; ST.set({ fallback: fb.checked }); render(); });
    (async () => {
      s = await ST.get({ engine: opts.defaultEngine || "google", models: {}, localUrl: C.SYNC_DEFAULTS.localUrl, msRegion: "", fallback: true, engineOrder: [], engineOff: [] });
      keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
      render();
    })();
  }
  // «Ordine dei servizi»: la fila dei servizi con la chiave (o il modello sul computer). Si sposta su e giù, si spegne,
  // «Usa adesso» lo mette primo e lo sceglie subito, «Prova» manda una frase di prova e dice se risponde (e cosa sbaglia).
  // L'ordine vale per i servizi di riserva, per «✨ Spiega con…» (se il servizio scelto non è un modello), per la
  // pronuncia e per la correzione della trascrizione. opts.store: dove sta "engine" (Parole al Volo nell'unica ne ha uno suo).
  function order(box, opts = {}) {
    if (!box) return;
    const SY = DS_EXT.storage.sync, ST = opts.store || SY;
    const tests = {};   // id → esito dell'ultima prova
    let busy = false;
    async function state() {
      const s = await SY.get({ engineOrder: [], engineOff: [], models: {}, localUrl: C.SYNC_DEFAULTS.localUrl, msRegion: "", targetLang: "it", explainEngine: "" });
      const e = await ST.get({ engine: opts.defaultEngine || "google" });
      const l = await DS_EXT.storage.local.get({ keys: {}, dsBlocked: {} });
      return { s, engine: e.engine, keys: l.keys || {}, blocked: l.dsBlocked || {} };
    }
    function status(id, st) {
      const E = C.ENGINES[id];
      const b = st.blocked[id];
      if (E.needsKey && !st.keys[id]) return { ok: false, t: "manca la chiave" };
      if ((E.kind === "openai" || E.kind === "claude") && !((st.s.models || {})[id] || E.defaultModel)) return { ok: false, t: "manca il modello: sceglilo qui sopra («Carica modelli»)" };
      if (b && b.day === pacificDay()) return { ok: true, t: "richieste finite per oggi" };
      return { ok: true, t: E.local ? "pronto (se il programma è avviato)" : "pronto" };
    }
    async function save(list, off) {
      await SY.set({ engineOrder: list, engineOff: off });
    }
    async function test(id) {
      const st = await state();
      const E = C.ENGINES[id];
      tests[id] = { t: "Provo…" }; render();
      const t0 = Date.now();
      // i secondi che passano (un modello sul computer può metterci molto, soprattutto la prima volta)
      const tick = setInterval(() => {
        const n = Math.round((Date.now() - t0) / 1000);
        tests[id] = { t: "Provo… " + n + " s" + (E.local && n >= 10 ? " (la prima volta il programma carica il modello in memoria: può volerci un minuto)" : "") };
        const row = [...box.querySelectorAll(".ds-order-row")].find((x) => x.dataset.id === id);
        const line = row && row.querySelector(".ds-order-test");
        if (line) line.textContent = tests[id].t;
      }, 1000);
      let r;
      try {
        r = await dsSendLong({ type: "translate", engine: id, key: st.keys[id] || "", model: (st.s.models || {})[id] || E.defaultModel || "",
          localUrl: st.s.localUrl, region: st.s.msRegion, target: st.s.targetLang || "it", source: "en", texts: ["Good morning, how are you today?"], priority: true });
      } catch (e) { r = { error: String((e && e.message) || e) }; }
      clearInterval(tick);
      const sec = ((Date.now() - t0) / 1000).toFixed(1).replace(".", ",");
      const out = r && !r.error && r.translations && r.translations[0];
      const slow = (Date.now() - t0) / 1000;
      const hint = !out || !E.local ? "" : slow > 15 ? " — lento: per i sottotitoli usa un modello più piccolo (per esempio gemma4:e4b) o un servizio online; riprova una seconda volta, la prima carica il modello" : slow > 5 ? " — va bene per le spiegazioni, per i sottotitoli è un po' lento" : "";
      tests[id] = out ? { ok: true, t: `✓ Funziona (${sec} s): «${out}»` + hint } : { ok: false, t: "✗ Non funziona: " + ((r && r.error) || "nessuna risposta") };
      render();
    }
    async function render() {
      if (busy) return;
      busy = true;
      try {
        const st = await state();
        const all = C.engineOrder(st.s, true).filter((id) => C.ENGINES[id]);
        const off = new Set(st.s.engineOff || []);
        box.textContent = "";
        box.append(mk("b", null, "Ordine dei servizi"),
          mk("p", "small", "Il primo pronto si usa per «✨ Spiega con…» quando traduci con Google, e quando un servizio finisce le richieste si passa al successivo. «Usa adesso» lo sceglie subito anche per tradurre; «Prova» controlla se risponde."));
        // un modello solo per le spiegazioni (per esempio Ollama), diverso da quello dei sottotitoli
        const exRow = mk("label", "stack", "Spiegazioni («✨ Spiega con…») con");
        const exSel = mk("select"); exSel.className = "ds-explain-engine";
        exSel.append(new Option("lo stesso servizio dei sottotitoli (o il primo modello pronto della fila)", ""));
        for (const id of all) {
          const E = C.ENGINES[id];
          if (E.kind !== "openai" && E.kind !== "claude") continue;
          const stt = status(id, st);
          exSel.append(new Option((E.local ? "Ollama o LM Studio (sul computer)" : nameOf(id)) + (stt.ok ? "" : " — " + stt.t), id));
        }
        exSel.value = st.s.explainEngine && C.ENGINES[st.s.explainEngine] ? st.s.explainEngine : "";
        exSel.addEventListener("change", () => SY.set({ explainEngine: exSel.value }));
        const exNote = mk("p", "small", st.s.explainEngine ? "Se non risponde o ha finito le richieste di oggi, la spiegazione la fa il primo modello pronto della fila." : "");
        exRow.append(exSel);
        box.append(exRow, exNote);
        all.forEach((id, i) => {
          const row = mk("div", "ds-order-row"); row.dataset.id = id;
          row.style.cssText = "display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin:3px 0;padding:3px 0;border-top:1px solid rgba(127,127,127,.25)";
          const on = mk("input"); on.type = "checkbox"; on.checked = !off.has(id); on.title = "Spunta tolta: questo servizio non si usa mai da solo";
          on.addEventListener("change", async () => { const o = new Set(st.s.engineOff || []); if (on.checked) o.delete(id); else o.add(id); await save(all, [...o]); render(); });
          const name = mk("span", null, (i + 1) + ". " + (C.ENGINES[id].local ? "Ollama o LM Studio (sul computer)" : nameOf(id))); name.style.fontWeight = "600";
          const stt = status(id, st);
          const info = mk("span", "small", (st.engine === id ? "in uso · " : "") + stt.t); info.style.flex = "1 1 120px"; info.style.opacity = stt.ok ? ".8" : ".6";
          const up = mk("button", "ghost", "↑"); up.type = "button"; up.title = "Più su"; up.disabled = i === 0;
          const down = mk("button", "ghost", "↓"); down.type = "button"; down.title = "Più giù"; down.disabled = i === all.length - 1;
          const move = async (d) => { const l = all.slice(); [l[i], l[i + d]] = [l[i + d], l[i]]; await save(l, [...off]); render(); };
          up.addEventListener("click", () => move(-1)); down.addEventListener("click", () => move(1));
          const use = mk("button", "ghost", st.engine === id ? "✓ in uso" : "Usa adesso"); use.type = "button";
          use.title = "Lo metto primo nella fila e lo scelgo subito (anche per tradurre)";
          use.addEventListener("click", async () => {
            const l = [id, ...all.filter((x) => x !== id)];
            const o = new Set(off); o.delete(id);
            await save(l, [...o]);
            await ST.set({ engine: id });
            if (opts.onUse) opts.onUse(id);
            render();
            if (stt.ok) test(id);
          });
          const tryb = mk("button", "ghost", "Prova"); tryb.type = "button"; tryb.title = "Traduce una frase di prova con questo servizio (una richiesta)";
          tryb.addEventListener("click", () => test(id));
          [up, down, use, tryb].forEach((b) => { b.style.padding = "1px 6px"; });
          row.append(on, name, info, up, down, use, tryb);
          if (tests[id]) { const r = mk("div", "small ds-order-test", tests[id].t); r.style.cssText = "flex-basis:100%;" + (tests[id].ok === false ? "color:#d9534f" : ""); row.append(r); }
          box.append(row);
        });
      } finally { busy = false; }
    }
    DS_EXT.storage.onChanged.addListener((ch, area) => {
      if (ch.engineOrder || ch.engineOff || ch.explainEngine || ch.engine || ch.pavEngine || ch.models || ch.keys || ch.dsBlocked) render();
    });
    render();
    return { render };
  }
  return { mount, banner, nameOf, order };
})();

# 5.17.1: grandezza delle lettere latine (popup → Aspetto), cambia subito
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
LS = "parseFloat(getComputedStyle(document.querySelector('.dualsub-romaline')).fontSize)"
FS = "(()=>{const x=document.querySelector('.dualsub-orig .dsr:not(.dsr-han)'); const w=x.closest('.dualsub-word'); return [parseFloat(getComputedStyle(w).fontSize), parseFloat(getComputedStyle(x,'::before').fontSize)]})()"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, roman:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=jaRoman"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/日本語/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(800)
        print("1. predefinita (testo, romaji):", await pg.evaluate(FS))
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(900)
        print("2. popup:", await pp.evaluate("[document.getElementById('romanSize').value, document.getElementById('romanSizeVal').textContent]"))
        await pp.evaluate("const r=document.getElementById('romanSize'); r.value=100; r.dispatchEvent(new Event('input'))"); await pp.wait_for_timeout(800)
        print("3. al 100%:", await pg.evaluate(FS), "| etichetta:", await pp.inner_text("#romanSizeVal"))
        await pp.evaluate("document.getElementById('resetLook').click()"); await pp.wait_for_timeout(800)
        print("4. ripristina:", await pg.evaluate(FS), "| riga:", await pg.evaluate(LS))
        await pp.evaluate("const r=document.getElementById('romanLineSize'); r.value=130; r.dispatchEvent(new Event('input'))"); await pp.wait_for_timeout(800)
        print("4b. riga al 130%:", await pg.evaluate(LS), "| caratteri invariati:", await pg.evaluate(FS))
        await pp.evaluate("const r=document.getElementById('romanSize'); r.value=90; r.dispatchEvent(new Event('input'))"); await pp.wait_for_timeout(800)
        await pg.bring_to_front(); await pg.locator(".dualsub-overlay").screenshot(path="/tmp/ja90.png")
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

// Pronuncia delle parole: voce del sistema nella lingua giusta, altrimenti la voce online di Google.
// Usata dalla scheda delle parole (pagina) e dal pulsante "Prova la voce" (popup).
var DS_TTS = (() => {
  let ctx = null;
  const norm = (l) => String(l || "").trim().replace(/_/g, "-");
  // stessi codici per le stesse lingue (le voci di Windows usano nb-NO, he-IL, fil-PH, jv-ID…)
  const SAME = { nb: "no", iw: "he", fil: "tl", jv: "jw", in: "id" };
  const base = (l) => { const b = norm(l).split("-")[0].toLowerCase(); return SAME[b] || b; };

  // L'elenco delle voci arriva in ritardo: lo chiedo subito al caricamento e lo tengo aggiornato,
  // così al clic su 🔊 è già pronto (aspetto al massimo una volta, e poco)
  // voce scelta per ogni lingua ({ cs: "voiceURI" | "google" | "azure:cs-CZ-VlastaNeural" }) e Azure acceso
  let my = { ttsVoices: {}, azureTts: false, ttsSpeaches: false, sttUrl: "" };
  try {
    DS_EXT.storage.sync.get({ ttsVoices: {}, azureTts: false, ttsSpeaches: false, sttUrl: "" }).then((r) => { my = r; }).catch(() => {});
    DS_EXT.storage.onChanged.addListener((ch, area) => {
      if (area !== "sync") return;
      if (ch.ttsVoices) my.ttsVoices = ch.ttsVoices.newValue || {};
      if (ch.azureTts) my.azureTts = !!ch.azureTts.newValue;
      if (ch.ttsSpeaches) my.ttsSpeaches = !!ch.ttsSpeaches.newValue;
      if (ch.sttUrl) my.sttUrl = ch.sttUrl.newValue || "";
    });
  } catch {}

  let cached = [];
  let waited = false;
  if (window.speechSynthesis) {
    cached = speechSynthesis.getVoices();
    speechSynthesis.addEventListener("voiceschanged", () => { cached = speechSynthesis.getVoices(); });
  }
  function voicesReady() {
    return new Promise((res) => {
      if (!window.speechSynthesis) return res([]);
      if (!cached.length) cached = speechSynthesis.getVoices();
      if (cached.length || waited) return res(cached);
      waited = true;
      let done = false;
      const finish = () => { if (!done) { done = true; cached = speechSynthesis.getVoices(); res(cached); } };
      speechSynthesis.addEventListener("voiceschanged", finish, { once: true });
      setTimeout(finish, 600);
    });
  }

  // La voce migliore per una lingua: stessa variante regionale, poi voci "naturali"/online
  function pickVoice(voices, lang) {
    const b = base(lang);
    if (!b) return null;
    const full = norm(lang).toLowerCase();
    const cands = voices.filter((v) => base(v.lang) === b);
    if (!cands.length) return null;
    // prima le voci "Natural", poi quelle online/neurali, poi la variante regionale giusta
    const score = (v) =>
      (/natural/i.test(v.name) ? 6 : /neural|online|google|premium|enhanced/i.test(v.name) ? 3 : 0) +
      (norm(v.lang).toLowerCase() === full ? 2 : 0) +
      (v.default ? 1 : 0);
    return cands.sort((x, y) => score(y) - score(x))[0];
  }

  let speakRate = 0.9;   // velocità della voce (0,6 = lenta), scelta a ogni speak
  // Restituisce una promessa che si risolve quando la voce ha finito di parlare
  function speakSystem(text, voice, lang) {
    return new Promise((res) => {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      if (voice) u.voice = voice;
      u.lang = voice ? voice.lang : norm(lang);
      u.rate = speakRate;
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        // libero subito la sintesi vocale: tenerla aperta può lasciare abbassati gli altri suoni
        setTimeout(() => { try { if (!speechSynthesis.speaking) speechSynthesis.cancel(); } catch {} }, 150);
        res();
      };
      u.onend = u.onerror = finish;
      speechSynthesis.speak(u);
      setTimeout(finish, 10000);
    });
  }

  function b64ToBuffer(b64) {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes.buffer;
  }

  async function speakGoogle(text, lang) {
    const r = await DS_EXT.runtime.sendMessage({ type: "tts", text, lang });
    if (!r || r.error) throw new Error((r && r.error) || "nessuna risposta");
    return playB64(r.audio);
  }
  // voci naturali di Microsoft (Azure Speech, con la tua chiave): le scarica il background
  async function speakAzure(text, lang, voice) {
    const r = await DS_EXT.runtime.sendMessage({ type: "azureTts", text, lang, voice: voice || "" });
    if (!r || r.error) throw new Error((r && r.error) || "nessuna risposta");
    return { voice: r.voice, ended: playB64(r.audio) };
  }
  async function playB64(audio, raw) {
    ctx = ctx || new AudioContext();
    if (ctx.state === "suspended") await ctx.resume();
    const buf = await ctx.decodeAudioData(b64ToBuffer(audio));
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = raw ? 1 : speakRate / 0.9;   // Piper/Speaches: la velocità è già nella sintesi
    src.connect(ctx.destination);
    return new Promise((res) => {
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        // spengo il canale audio quando ha finito, invece di lasciarlo aperto
        setTimeout(() => { if (ctx && ctx.state === "running") ctx.suspend().catch(() => {}); }, 300);
        res();
      };
      src.onended = finish;
      src.start();
      setTimeout(finish, buf.duration * 1000 + 2000);
    });
  }

  // 1.7.0: voci Piper gratuite (sul computer, pagina nascosta dell'estensione) e voci Piper del server Speaches
  const piperFam = (key) => base(String(key).split("_")[0]);
  const QUAL = { x_low: "molto leggera", low: "leggera", medium: "media", high: "alta" };
  const QRANK = { high: 0, medium: 1, low: 2, x_low: 3 };
  const pretty = (n) => String(n).replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());
  const kfmt = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M" : n >= 1e4 ? Math.round(n / 1e3) + "k" : n >= 1e3 ? (n / 1e3).toFixed(1).replace(/\.0$/, "") + "k" : String(n));
  const mb = (n) => (n ? Math.max(1, Math.round(n / 1048576)) + " MB" : "");
  // prima la sintesi (qui un errore fa passare alla voce successiva), poi l'ascolto: restituisce l'audio in base64
  async function synthPiper(text, key) {
    const r = await dsSendLong({ type: "piper", op: "speak", key, text, rate: speakRate });
    if (!r || r.error) throw new Error((r && r.error) || "nessuna risposta");
    return r.audio;
  }
  async function synthSpeaches(text, key) {
    const r = await DS_EXT.runtime.sendMessage({ type: "speachesTts", op: "speak", key, text, rate: speakRate, url: my.sttUrl || undefined });
    if (!r || r.error) throw new Error((r && r.error) || "nessuna risposta");
    return r.audio;
  }
  let piperMemo = null, piperErr = "";   // piperErr: perché le voci Piper non sono disponibili (si mostra nel popup e nel menu)
  // le voci Piper di una lingua, dalla migliore: { key, label, have, size }
  async function piperVoices(lang) {
    const b = base(lang);
    if (!piperMemo || Date.now() - piperMemo.at > 30000) {
      try {
        const r = await DS_EXT.runtime.sendMessage({ type: "piper", op: "voices" });
        piperErr = r && r.error ? String(r.error) : (r && r.voices ? "" : "nessuna risposta dalla pagina delle voci");
        piperMemo = { at: Date.now() - (piperErr ? 25000 : 0), list: (r && r.voices) || [] };   // se è un errore riprovo tra 5 secondi
      } catch (e) { piperErr = String((e && e.message) || e); piperMemo = { at: Date.now() - 25000, list: [] }; }
    }
    const same = piperMemo.list.filter((v) => base(v.family) === b);
    const topDl = Math.max(0, ...same.map((v) => v.dl || 0));
    // le più usate prima (quando il dato c'è), poi per qualità; la più usata della lingua ha la stella
    return same
      .sort((x, y) => ((y.dl || 0) - (x.dl || 0)) || (QRANK[x.quality] - QRANK[y.quality]) || x.region.localeCompare(y.region) || x.name.localeCompare(y.name))
      .map((v) => ({ ...v, label: `${pretty(v.name)} (${v.code.replace("_", "-")}, ${QUAL[v.quality]}${v.size ? ", " + mb(v.size) : ""})` + (v.dl >= 0 ? ` · ${v.dl >= topDl && topDl > 0 ? "★ " : ""}⬇ ${kfmt(v.dl)}` : "") }));
  }
  // le voci che Speaches ha davvero come pacchetto (speaches-ai/piper-…): quelle con un numero di download; se l'elenco non è arrivato, tutte
  async function speachesVoices(lang) {
    const all = await piperVoices(lang);
    const known = piperMemo && piperMemo.list.some((v) => v.dl >= 0);
    return known ? all.filter((v) => v.dl >= 0) : all;
  }
  async function speachesInstalled() {
    try { const r = await DS_EXT.runtime.sendMessage({ type: "speachesTts", op: "list", url: my.sttUrl || undefined }); return (r && r.installed) || null; } catch { return null; }
  }
  const piperInvalidate = () => { piperMemo = null; };

  // Ordine: la voce scelta per quella lingua (⚙ nella scheda o popup) → Azure, se acceso → la voce migliore del
  // computer per la lingua (prima le "Natural") → la voce online di Google.
  // prefs.voice: voce scelta nel popup ("google" = sempre Google; una voce del computer vale solo per la sua lingua)
  // prefs.lang: lingua scelta a mano (vince su quella rilevata)
  async function speak(text, lang, prefs = {}) {
    speakRate = prefs.rate || 0.9;
    const want = norm(prefs.lang || lang);
    const b = base(want);
    const voices = await voicesReady();
    let choice = (b && (my.ttsVoices || {})[b]) || "";
    if (!choice && prefs.voice) {
      if (prefs.voice === "google") choice = "google";
      else if (/^(piper|speaches):/.test(prefs.voice)) { if (!b || piperFam(prefs.voice.replace(/^[a-z]+:/, "")) === b) choice = prefs.voice; }
      else { const v = voices.find((x) => x.voiceURI === prefs.voice); if (v && (!b || base(v.lang) === b)) choice = prefs.voice; }
    }
    let note = "";
    // "done" si risolve quando la pronuncia è finita (serve per rialzare il volume del video)
    if (/^(piper|speaches):/.test(choice)) {
      const kind = choice.split(":")[0], key = choice.slice(kind.length + 1);
      if (!b || piperFam(key) === b) {
        try {
          const audio = await (kind === "piper" ? synthPiper(text, key) : synthSpeaches(text, key));
          const nm = pretty(key.split("-")[1] || key);
          return { how: kind === "piper" ? `voce Piper "${nm}" (gratuita, sul computer)` : `voce Piper "${nm}" (dal tuo server Speaches)`, done: playB64(audio, true), voice: "Piper " + nm };
        } catch (e) { note = ` (${kind === "piper" ? "Piper" : "Speaches"} non disponibile: ${e.message})`; }
      }
      choice = "";
    }
    if (want && (choice.startsWith("azure:") || (!choice && my.azureTts))) {
      try {
        const a = await speakAzure(text, want, choice.startsWith("azure:") ? choice.slice(6) : "");
        await Promise.race([a.ended.then(() => 0), new Promise((r) => setTimeout(r, 50))]);
        return { how: `voce Microsoft "${a.voice}" (Azure)`, done: a.ended, voice: a.voice };
      } catch (e) { note = " (Azure non disponibile: " + e.message + ")"; }
    }
    if (choice && choice !== "google" && !choice.startsWith("azure:")) {
      const v = voices.find((x) => x.voiceURI === choice);
      if (v) return { how: `voce "${v.name}"` + note, done: speakSystem(text, v), voice: v.name };
    }
    if (choice !== "google" && want) {
      const v = pickVoice(voices, want);
      if (v) return { how: `voce "${v.name}"` + note, done: speakSystem(text, v), voice: v.name };
    }
    if (want || choice === "google") {
      try {
        const ended = speakGoogle(text, want || "en");
        await Promise.race([ended.then(() => 0), new Promise((r) => setTimeout(r, 50))]);
        return { how: "voce online di Google" + note, done: ended, voice: "Google" };
      } catch (e) { if (choice === "google") return { how: "voce di Google non disponibile: " + e.message, done: Promise.resolve() }; }
    }
    if (window.speechSynthesis) {
      return { how: "voce predefinita del sistema" + (want ? ` (nessuna voce per "${want}")` : "") + note, done: speakSystem(text, null, want) };
    }
    return { how: "nessuna voce disponibile", done: Promise.resolve() };
  }

  // Le voci tra cui scegliere per una lingua (⚙ nella scheda, popup): { value, label, kind }
  async function voiceOptions(lang) {
    const b = base(lang);
    const out = [{ value: "", label: "Automatica (la migliore disponibile)", kind: "auto" }];
    const sys = (await voicesReady()).filter((v) => base(v.lang) === b)
      .sort((x, y) => (/natural/i.test(y.name) - /natural/i.test(x.name)) || x.name.localeCompare(y.name));
    for (const v of sys) out.push({ value: v.voiceURI, label: v.name + " (" + v.lang + ")", kind: "system" });
    if (my.azureTts) {
      try {
        const r = await DS_EXT.runtime.sendMessage({ type: "azureVoices" });
        for (const v of (r && r.list) || []) if (base(v.locale) === b) out.push({ value: "azure:" + v.name, label: "Azure: " + v.label + " (" + v.locale + (v.gender ? ", " + v.gender : "") + ")", kind: "azure" });
      } catch {}
    }
    try {
      for (const v of await piperVoices(lang)) out.push({ value: "piper:" + v.key, label: "Piper: " + v.label + (v.have ? " ✓" : " — da scaricare"), kind: "piper" });
      if (piperErr) out.push({ value: "", label: "Voci Piper non disponibili: " + piperErr, kind: "note" });
      if (my.ttsSpeaches) {
        const inst = await speachesInstalled();
        for (const v of await speachesVoices(lang)) out.push({ value: "speaches:" + v.key, label: "Speaches: " + v.label + (inst && inst.includes(v.key) ? " ✓" : " — da installare sul server"), kind: "speaches" });
      }
    } catch {}
    out.push({ value: "google", label: "Voce online di Google", kind: "google" });
    return out;
  }
  const voiceFor = (lang) => ((my.ttsVoices || {})[base(lang)] || "");
  async function setVoice(lang, value) {
    const b = base(lang);
    if (!b) return;
    const m = { ...(my.ttsVoices || {}) };
    if (value) m[b] = value; else delete m[b];
    my.ttsVoices = m;
    await DS_EXT.storage.sync.set({ ttsVoices: m }).catch(() => {});
  }

  // Piccolo menu "voce per questa lingua" (⚙ accanto a 🔈 nella scheda). onPick(value) dopo la scelta.
  function voiceMenu(lang, onPick) {
    const box = document.createElement("div");
    box.className = "ds-voicemenu";
    const t = document.createElement("div");
    t.className = "ds-voicemenu-title";
    try { const n = new Intl.DisplayNames([dsUiLocale()], { type: "language" }).of(base(lang)); t.textContent = "Voce per: " + n; } catch { t.textContent = "Voce per: " + base(lang); }
    box.append(t);
    const list = document.createElement("div");
    list.className = "ds-voicemenu-list";
    list.textContent = "…";
    box.append(list);
    voiceOptions(lang).then((opts) => {
      list.textContent = "";
      const cur = voiceFor(lang);
      for (const o of opts) {
        const btn = document.createElement("button");
        if (o.kind === "note") { const n = document.createElement("div"); n.className = "ds-voicemenu-note"; n.textContent = o.label; list.append(n); continue; }
        btn.type = "button";
        btn.className = "ds-voicemenu-item" + (o.value === cur ? " ds-on" : "");
        btn.textContent = (o.value === cur ? "● " : "") + o.label;
        btn.addEventListener("click", async (e) => {
          e.preventDefault(); e.stopPropagation();
          await setVoice(lang, o.value);
          if (onPick) onPick(o.value);
        });
        list.append(btn);
      }
      if (opts.filter((o) => o.kind === "system").length === 0) {
        const n = document.createElement("div");
        n.className = "ds-voicemenu-note";
        n.textContent = "Sul computer non c'è una voce per questa lingua: si aggiunge da Windows → Impostazioni → Ora e lingua → Voce. Oppure usa Azure (popup).";
        list.append(n);
      }
    });
    return box;
  }

  return { speak, voicesReady, pickVoice, base, voiceOptions, voiceFor, setVoice, voiceMenu, piperVoices, speachesVoices, piperError: () => piperErr, speachesInstalled, piperInvalidate, piperFam, pretty, mb, QUAL };
})();

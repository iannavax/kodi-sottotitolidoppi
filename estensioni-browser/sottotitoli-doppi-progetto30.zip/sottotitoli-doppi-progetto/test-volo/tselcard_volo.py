# 1.6.2: il testo dentro la scheda di una parola (pagine) si seleziona con il mouse
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "bread", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        # la riga della frase nella scheda
        box = await pg.evaluate("(()=>{const e=document.querySelector('.pav-card .pav-sentence div') || document.querySelector('.pav-card .pav-trans') || document.querySelector('.pav-card .pav-meaning') || [...document.querySelectorAll('.pav-card div')].find(d=>d.children.length===0 && d.textContent.trim().length>3); if(!e) return null; const r=e.getBoundingClientRect(); return {x:r.left,y:r.top,w:r.width,h:r.height,t:e.textContent}})()")
        print("elemento:", box)
        await pg.mouse.move(box["x"] + 2, box["y"] + box["h"] / 2); await pg.mouse.down()
        await pg.mouse.move(box["x"] + min(box["w"], 200) - 2, box["y"] + box["h"] / 2, steps=8); await pg.mouse.up()
        await pg.wait_for_timeout(700)
        sel = await pg.evaluate("String(window.getSelection())")
        still = await pg.evaluate("!!document.querySelector('.pav-card')")
        kind = await pg.evaluate("(document.querySelector('.pav-card')||{}).innerText.slice(0,60)")
        print("selezionato:", repr(sel[:80]), "| scheda ancora aperta:", still, "| scheda:", kind.replace("\n"," | "))
        await pg.wait_for_timeout(1500); kind2 = await pg.evaluate("(document.querySelector('.pav-card')||{}).innerText.slice(0,60)")
        print("   dopo un attimo:", kind2.replace("\n"," | "))
        ok = len(sel.strip()) >= 2 and still and kind2.startswith("bread")
        print("errori:", errs if ok else errs + ["testo della scheda delle pagine non selezionabile"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

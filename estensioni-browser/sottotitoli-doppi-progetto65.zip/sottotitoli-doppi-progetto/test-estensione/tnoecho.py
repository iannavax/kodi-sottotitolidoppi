# 1.7.18: sotto ci va sempre la traduzione: mai il testo originale (o corretto) nemmeno per un attimo
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
NORM = "s => s.toLowerCase().replace(/[^\\p{L}\\p{N}]+/gu, ' ').trim()"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, cleanAsr:true, cleanMode:'off'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(800)
        await pg.evaluate("window.__bad = []; window.__n = 0; const n = " + NORM + "; setInterval(() => { const o = document.querySelector('.dualsub-orig'), t = document.querySelector('.dualsub-trans'); if (!o || !t) return; const a = n(o.textContent), b = n(t.textContent); window.__n++; if (a && b && a === b) window.__bad.push([o.textContent, t.textContent]); }, 30)")
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_timeout(9000)
        bad = await pg.evaluate("window.__bad"); n = await pg.evaluate("window.__n")
        print("controlli:", n, "| righe sotto uguali a quelle sopra:", bad[:3])
        print("errori:", errs if not bad else errs + ["la traduzione è uguale all'originale"], log["errors"])
        await ctx.close()
asyncio.run(main())

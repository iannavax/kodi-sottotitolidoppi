# 1.7.3: sottolineature sulla pagina: analisi intera una volta, poi solo il testo nuovo (niente ripassi inutili)
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
HL = "(n) => CSS.highlights.has(n) ? [...CSS.highlights.get(n)].map(r => r.toString()) : []"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, savedPage:true, idiomPage:true}).then(()=>chrome.storage.local.set({vocab:{'en|market':{id:'en|market', word:'market', lang:'en', kind:'word', status:'learning', meaning:'mercato'}}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(3500)
        a = await pg.evaluate(HL, "pav-saved")
        print("1. salvate all'inizio:", a)
        # testo nuovo (come uno scorrimento infinito)
        await pg.evaluate("""() => { const d = document.createElement('div'); d.id = 'nuovo'; d.innerHTML = '<p>We went to the market again, and the market was closed.</p>'; document.body.append(d); }""")
        await pg.wait_for_timeout(3500)
        b = await pg.evaluate(HL, "pav-saved")
        print("2. dopo testo nuovo:", b)
        # testo modificato
        await pg.evaluate("document.querySelector('#nuovo p').firstChild.nodeValue = 'No more words here.'"); await pg.wait_for_timeout(3500)
        c = await pg.evaluate(HL, "pav-saved")
        print("3. dopo aver cambiato il testo nuovo:", c)
        # testo tolto: l'intervallo non conta più (dopo la pulizia)
        await pg.evaluate("document.querySelector('#nuovo').remove()"); await pg.wait_for_timeout(2500)
        d = await pg.evaluate("[...(CSS.highlights.get('pav-saved')||[])].filter(r => r.startContainer.isConnected).length")
        print("4. intervalli ancora sulla pagina:", d)
        ok = len(a) >= 1 and len(b) == len(a) + 2 and len(c) == len(a) and d == len(a)
        print("errori:", errs if ok else errs + ["sottolineature incrementali non vanno"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

# 1.6.6: costo della scheda aperta: tempo di script, stile e layout in 5 s con la scheda aperta (video) + quante volte si ridisegna
import asyncio, sys, os
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def metrics(cdp):
    m = await cdp.send("Performance.getMetrics")
    return {x["name"]: x["value"] for x in m["metrics"]}
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        cdp = await ctx.new_cdp_session(pg); await cdp.send("Performance.enable")
        await pg.evaluate("""(() => { window.__mut = {card: 0, line: 0}; const o = document.querySelector('.dualsub-overlay');
          new MutationObserver((l) => { for (const m of l) { if (m.target.closest && m.target.closest('.dualsub-card')) window.__mut.card += m.addedNodes.length + m.removedNodes.length; else window.__mut.line += m.addedNodes.length + m.removedNodes.length; } }).observe(o, {childList: true, subtree: true}); })()""")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        a = await metrics(cdp)
        await words.nth(texts.index("bread")).click()
        await pg.wait_for_timeout(5000)
        b = await metrics(cdp)
        mut = await pg.evaluate("window.__mut")
        d = lambda k: round((b[k] - a[k]) * 1000)
        print(f"script {d('ScriptDuration')} ms | stile {d('RecalcStyleDuration')} ms | layout {d('LayoutDuration')} ms | task {d('TaskDuration')} ms | nodi DOM nella scheda {mut['card']} | nodi nella riga dei sottotitoli {mut['line']} | ricalcoli stile {int(b['RecalcStyleCount']-a['RecalcStyleCount'])} layout {int(b['LayoutCount']-a['LayoutCount'])}")
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

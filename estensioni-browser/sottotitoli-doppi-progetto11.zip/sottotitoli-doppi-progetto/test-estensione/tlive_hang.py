# 5.19.1: una richiesta a Whisper resta appesa (rete, scheda in sottofondo): prima la coda restava bloccata per sempre
# e i sottotitoli non tornavano più; ora dopo 60 s si passa al pezzo dopo
import asyncio, os, sys
os.environ.setdefault("GROQ_HANG_AT", "2")
sys.path.insert(0, "/home/claude/e2e")
from charness import *
STATUS = "(document.querySelector('.dualsub-status')||{}).textContent||''"
SHOWN = "(document.querySelector('.dualsub-overlay:not([hidden]) .dualsub-orig')||{}).textContent||''"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/embed/direttaHang?autoplay=1"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        seen = []
        for i in range(115):
            t = await pg.evaluate(SHOWN)
            if t and (not seen or seen[-1][1] != t): seen.append((i, t))
            if i % 20 == 0:
                stv = await pg.evaluate(STATUS)
                print(f"  {i:3d} s: pezzi a Whisper {len(log['groq'])} (appesi {log.get('groq_hung')}) | stato: {stv[:70]}")
            await pg.wait_for_timeout(1000)
        print("frasi viste (secondo, testo):", [(i, t[:25]) for i, t in seen])
        print("pezzi a Whisper:", len(log["groq"]), "| frasi viste dopo 70 s:", len([1 for i, _ in seen if i > 70]))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# Passando il mouse su una parola dell'originale si illumina la sua traduzione anche senza il modello (dizionario di
# Google: «bread» → pane, pagnotta; nella traduzione «pani» con un'altra desinenza). Uso: python3 treverse.py <estensione>
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnFreq:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'') && document.querySelectorAll('.dualsub-tword').length>3", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(500)
        # la traduzione finta del simulatore è a parole rovesciate: metto due parole vere
        await pg.evaluate("(()=>{const t=[...document.querySelectorAll('.dualsub-tword')]; t[1].textContent='pani'; t[2].textContent='casa';})()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).hover(); await pg.wait_for_timeout(1500)
        print("   twords:", await pg.evaluate("[...document.querySelectorAll('.dualsub-tword')].map(x=>x.textContent).slice(0,5)"), "hover:", await pg.evaluate("!!document.querySelector('.dualsub-word:hover')"))
        print("1. su «bread» si illumina:", await pg.evaluate("[...document.querySelectorAll('.dualsub-tword.dualsub-hl')].map(x=>x.textContent)"))
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(500)
        print("2. via il mouse:", await pg.evaluate("document.querySelectorAll('.dualsub-tword.dualsub-hl').length"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

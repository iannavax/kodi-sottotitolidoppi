# Dizionario di Google (Oxford) nella scheda: sezione con pronuncia (🔊), significati, esempi, sinonimi, forme, origine,
# albero etimologico e uso nel tempo; l'etimologia di Google si usa quando Wiktionary non ce l'ha (market).
# Uso: python3 tgweb.py <estensione>
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
GW = "(document.querySelector('.dualsub-card .dsx-gw')||{}).innerText||'(nessuna)'"
ETYM = "(document.querySelector('.dualsub-card .dsx-etym')||{}).innerText||'(nessuna)'"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnFreq:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("market")).click(); await pg.wait_for_timeout(3500)
        print("1. chiusa:", await pg.evaluate(GW))
        print("   etimologia (Wiktionary non ce l'ha):", (await pg.evaluate(ETYM)).replace("\n", " | "))
        await pg.locator(".dualsub-card .dsx-gwhead").click(); await pg.wait_for_timeout(1500)
        print("2. aperta:", (await pg.evaluate(GW)).replace("\n", " | "))
        await pg.locator(".dualsub-card .dsx-gw button", has_text="traduci").first.click(); await pg.wait_for_timeout(1200)
        print("3. definizione tradotta:", await pg.evaluate("(document.querySelector('.dualsub-card .dsx-gwtrans')||{}).textContent"))
        await pg.locator(".dualsub-card .dsx-gwhw button", has_text="🔊").click(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-card .dsx-gw button", has_text="uso nel tempo").click(); await pg.wait_for_timeout(1500)
        print("4. albero:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-gwtree img')].map(i=>i.src.slice(0,22))"),
              "| grafico:", await pg.evaluate("!!document.querySelector('.dualsub-card .dsx-spark polyline')"), "| richieste:", log.get("gweb"), log.get("ngram"), len(log.get("gstatic", [])))
        await pg.locator(".dualsub-card .dsx-etym button", has_text="albero").click(); await pg.wait_for_timeout(800)
        print("5. 🌳 nella riga dell'etimologia:", await pg.evaluate("!!document.querySelector('.dualsub-card .dsx-etym .dsx-gwtree img')"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

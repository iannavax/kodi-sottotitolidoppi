// Strumenti per imparare nella scheda della parola (Sottotitoli Doppi e Parole al Volo) — versione di prova.
// Tutti gratis e senza chiavi: frequenza della parola (elenchi FrequencyWords), parole che conosci, genere,
// pronuncia registrata da madrelingua e tabelle di coniugazione/declinazione (Wiktionary), frasi d'esempio
// (Tatoeba), controllo della scrittura (LanguageTool / dizionario). Le parti del modello (falsi amici, parole
// parenti, voto alla scrittura) arrivano nella stessa richiesta della spiegazione, senza richieste in più.
// Usa: DS_EXT, DS_ETYM (etym.js), DS_TTS (tts.js).

// ---------- Parole che conosci ----------
var DS_KNOWN = (() => {
  let map = {};          // lingua → Set di parole (minuscole)
  let version = 0;
  const base = (l) => String(l || "").split("-")[0].toLowerCase() || "?";
  const load = (obj) => { map = {}; for (const [l, s] of Object.entries(obj || {})) map[l] = new Set(String(s || "").split("\n").filter(Boolean)); version++; };
  const ready = DS_EXT.storage.local.get({ knownWords: {} }).then((r) => load(r.knownWords)).catch(() => {});
  DS_EXT.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.knownWords) load(ch.knownWords.newValue); });
  let timer = 0;
  const save = () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      const out = {};
      for (const [l, s] of Object.entries(map)) out[l] = [...s].slice(-50000).join("\n");
      DS_EXT.storage.local.set({ knownWords: out }).catch(() => {});
    }, 300);
  };
  function has(lang, w) {
    w = String(w || "").toLowerCase();
    const b = base(lang);
    if (b !== "?") return !!(map[b] && map[b].has(w));
    return Object.values(map).some((s) => s.has(w));
  }
  function set(lang, w, on) {
    const b = base(lang);
    w = String(w || "").toLowerCase().trim();
    if (!w) return;
    if (!map[b]) map[b] = new Set();
    if (on) map[b].add(w); else map[b].delete(w);
    version++;
    save();
  }
  // quante parole di un testo conosci (contando le ripetizioni) e quante parole diverse
  function stats(words, lang) {
    let known = 0;
    const uniq = new Set(), uniqKnown = new Set();
    for (const w0 of words) {
      const w = String(w0).toLowerCase();
      if (!/\p{L}/u.test(w)) continue;
      uniq.add(w);
      if (has(lang, w)) { known++; uniqKnown.add(w); }
    }
    const total = words.filter((w) => /\p{L}/u.test(w)).length;
    return { known, total, pct: total ? Math.round((known * 100) / total) : 0, unique: uniq.size, uniqueKnown: uniqKnown.size };
  }
  return { ready, has, set, stats, get version() { return version; }, count: (lang) => base(lang) === "?" ? Object.values(map).reduce((n, x) => n + x.size, 0) : (map[base(lang)] || new Set()).size };
})();

// ---------- Frequenza delle parole ----------
var DS_FREQ = (() => {
  const lists = new Map();      // lingua → Map(parola → posizione) | null (non disponibile) | Promise
  const base = (l) => String(l || "").split("-")[0].toLowerCase();
  async function load(lang) {
    const b = base(lang);
    if (!b) return null;
    if (lists.has(b)) return lists.get(b);
    const p = (async () => {
      const key = "freq:" + b;
      const got = await DS_EXT.storage.local.get({ [key]: null, freqFail: {} }).catch(() => ({}));
      let text = got && got[key];
      if (!text) {
        const fail = (got && got.freqFail) || {};
        if (fail[b] && Date.now() - fail[b] < 86400e3) return null;   // non c'era: riprovo domani
        try {
          const r = await DS_EXT.runtime.sendMessage({ type: "freqList", lang: b });
          if (!r || r.error || !r.list) throw new Error((r && r.error) || "vuoto");
          text = r.list;
          await DS_EXT.storage.local.set({ [key]: text }).catch(() => {});
        } catch {
          await DS_EXT.storage.local.set({ freqFail: { ...fail, [b]: Date.now() } }).catch(() => {});
          return null;
        }
      }
      const m = new Map();
      text.split("\n").forEach((w, i) => { if (w && !m.has(w)) m.set(w, i + 1); });
      return m;
    })();
    lists.set(b, p);
    const m = await p;
    lists.set(b, m);
    return m;
  }
  async function rank(word, lang) {
    const m = await load(lang);
    if (!m) return null;
    return m.get(String(word || "").toLowerCase()) || 0;
  }
  function label(r) {
    if (r == null) return "";
    if (!r) return "molto rara (o un nome)";
    if (r <= 1000) return "molto comune · tra le 1000 più usate";
    if (r <= 5000) return "comune · tra le 5000 più usate";
    if (r <= 15000) return "poco comune · n. " + r;
    return "rara · n. " + r;
  }
  return { rank, label, load };
})();

// ---------- La parte della scheda ----------
var DS_LEARN = (() => {
  const exCache = new Map(), ltCache = new Map();
  let ctxAudio = null;
  const mk = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const btn = (label, title, fn, cls) => {
    const b = mk("button", "dsx-btn" + (cls ? " " + cls : ""), label);
    b.type = "button";
    if (title) b.title = title;
    b.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); fn(b); });
    return b;
  };

  // url: un indirizzo o un elenco (si prova il successivo se il primo non va)
  async function playUrl(url, btnEl) {
    const urls = (Array.isArray(url) ? url : [url]).filter(Boolean);
    if (btnEl) btnEl.textContent = "…";
    let err = "audio non disponibile";
    for (const u of urls) {
      try {
        const r = await DS_EXT.runtime.sendMessage({ type: "fetchB64", url: u });
        if (!r || r.error) throw new Error((r && r.error) || "audio non disponibile");
        const bin = atob(r.b64), bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        ctxAudio = ctxAudio || new AudioContext();
        if (ctxAudio.state === "suspended") await ctxAudio.resume();
        const buf = await ctxAudio.decodeAudioData(bytes.buffer);
        const src = ctxAudio.createBufferSource();
        src.buffer = buf; src.connect(ctxAudio.destination);
        const done = new Promise((res) => { src.onended = res; setTimeout(res, (buf.duration + 1) * 1000); });
        src.start();
        if (btnEl) btnEl.textContent = btnEl.dataset.label || "🔊";
        return { done };
      } catch (e) { err = e.message || String(e); }
    }
    if (btnEl) { btnEl.textContent = "✕"; btnEl.title = "Registrazione non riproducibile: " + err; }
    return false;
  }

  const GENDER = [[/^m|masc/i, "maschile", "dsx-m"], [/^f|fem/i, "femminile", "dsx-f"], [/^n|neut/i, "neutro", "dsx-n"], [/^c|common/i, "comune", "dsx-c"]];
  function genderInfo(g, lang) {
    if (!g) return null;
    const hit = GENDER.find(([re]) => re.test(g.trim()));
    if (!hit) return null;
    const art = String(lang).startsWith("de") ? { maschile: "der", femminile: "die", neutro: "das" }[hit[1]] : "";
    const plural = /\bpl|plural/i.test(g) ? " plurale" : "";
    return { text: hit[1] + plural + (art ? " · " + art : ""), cls: hit[2] };
  }

  // risultato di LanguageTool per la parola cliccata dentro la frase
  function ltForWord(lt, sentence, word) {
    if (!lt || !lt.matches) return null;
    const s = String(sentence || ""), w = String(word || "");
    const at = s.toLowerCase().indexOf(w.toLowerCase());
    if (at < 0) return { ok: !lt.matches.length };
    const m = lt.matches.find((x) => x.offset < at + w.length && x.offset + x.length > at);
    return m ? { ok: false, message: m.message || m.short, repl: m.repl } : { ok: true };
  }

  function load(ctx) {
    const st = ctx.st, p = ctx.prefs;
    if (st.learnStarted) return;
    st.learnStarted = true;
    setTimeout(() => {
      if (ctx.stale()) { st.learnStarted = false; return; }
      const done = () => { if (!ctx.stale()) ctx.rerender(); };
      const needWikt = p.etym !== false || p.learnAudio !== false || p.learnTable !== false || p.learnGender !== false || p.learnSpell !== false || p.gdDefs !== false;
      // la registrazione: se il Wiktionary inglese non l'ha per questa parola, la cerco nelle altre edizioni
      const moreAudio = () => {
        const exact = recordingInfo({ wikt: st.wikt }, ctx.word, p);
        if (p.learnAudio === false || st.audio2 || (exact && !exact.form) || !/^[a-z]{2,3}$/.test(String(ctx.lang || "").split("-")[0])) return;
        st.audio2 = { wait: true };
        DS_ETYM.audioOther(ctx.word, ctx.lang, ctx.target).then((r) => { st.audio2 = r || { audio: [] }; done(); }).catch(() => { st.audio2 = { audio: [] }; });
      };
      if (needWikt && !st.wikt) DS_ETYM.get(ctx.word, ctx.lang, ctx.target, ctx.lemma).then((r) => { st.wikt = r || { none: true }; done(); moreAudio(); });
      else if (st.wikt) moreAudio();
      // definizioni nella lingua della parola dal Wiktionary di quella lingua (gratis): per le parole non inglesi
      if (p.gdDefs !== false && !st.wdefs && typeof DS_ETYM.defsNative === "function" && /^[a-z]{2,3}$/.test(String(ctx.lang || "").split("-")[0]) && !/^en/.test(String(ctx.lang))) {
        st.wdefs = { wait: true, defs: [] };
        DS_ETYM.defsNative(ctx.word, ctx.lang).then((r) => { st.wdefs = r || { defs: [] }; done(); }).catch(() => { st.wdefs = { defs: [] }; done(); });
      }
      if (p.learnFreq !== false && st.freq === undefined) DS_FREQ.rank(ctx.word, ctx.lang).then((r) => { st.freq = r; done(); }).catch(() => { st.freq = null; done(); });
      if (p.learnExamples !== false && !st.examples) {
        const k = [ctx.lang, ctx.word.toLowerCase(), ctx.target].join("|");
        const have = exCache.get(k);
        (have ? Promise.resolve(have) : DS_EXT.runtime.sendMessage({ type: "tatoeba", word: ctx.word, lang: ctx.lang, target: ctx.target }))
          .then((r) => { if (r && !r.error) exCache.set(k, r); st.examples = r || { items: [] }; done(); })
          .catch((e) => { st.examples = { error: String(e.message || e) }; done(); });
      }
      // immagine per Anki (solo con l'opzione accesa): la vedi e la cambi prima di salvare
      if (p.ankiImage && !st.img && ctx.word) {
        st.img = { list: [], i: 0 };
        loadImages(st.img, ctx.lemma || ctx.word, ctx.lang, null, false, done);
      }
      if (p.learnJisho !== false && /^ja/.test(String(ctx.lang || "")) && !st.jisho) {
        DS_EXT.runtime.sendMessage({ type: "jisho", word: ctx.word }).then((r) => { st.jisho = r && !r.error ? r : { items: [], error: (r && r.error) || "" }; done(); })
          .catch((e) => { st.jisho = { items: [], error: String(e.message || e) }; done(); });
      }
      if (p.learnSpell !== false && !st.lt && ctx.sentence) {
        const k = ctx.lang + "|" + ctx.sentence;
        const have = ltCache.get(k);
        (have ? Promise.resolve(have) : DS_EXT.runtime.sendMessage({ type: "langtool", text: ctx.sentence, lang: ctx.lang }))
          .then((r) => { if (r && !r.error) ltCache.set(k, r); st.lt = r || {}; done(); })
          .catch(() => { st.lt = { error: true }; done(); });
      }
    }, 800);
  }

  // traduzione veloce con Google (gratis) di una parola o di una definizione
  const qtCache = new Map();
  async function quickTrans(text, from, to) {
    const k = [from, to, text].join("|");
    if (qtCache.has(k)) return qtCache.get(k);
    try {
      const r = await DS_EXT.runtime.sendMessage({ type: "translate", engine: "google", texts: [text], target: to, source: String(from || "").split("-")[0] });
      const t = (r && r.translations && r.translations[0]) || "";
      if (t) qtCache.set(k, t);
      return t;
    } catch { return ""; }
  }

  // ⚑ sull'etimologia: originale inglese, rifarla con il modello, correggerla a mano (resta salvata)
  function etymFixBox(ctx, st, w) {
    const box = mk("div", "dsx-fix");
    const e = ctx.engine ? ctx.engine() : null;
    if (w.text && w.text !== w.trans) box.append(btn(st.etymOrig ? "nascondi l'originale" : "mostra l'originale (inglese)", "Il testo di Wiktionary prima della traduzione automatica", () => { st.etymOrig = !st.etymOrig; ctx.rerender(); }));
    if (w.text && w.text !== w.trans) box.append(btn(st.etymWait === "g" ? "…" : "ritraduci (Google)", "Una nuova traduzione automatica del testo di Wiktionary", async () => {
      if (st.etymWait) return;
      st.etymWait = "g"; ctx.rerender();
      const r = await DS_ETYM.retranslate(ctx.word, ctx.lang, ctx.target);
      st.etymWait = false;
      if (r && r.trans) { st.wikt = { ...st.wikt, ...r }; st.etymFix = false; }
      if (!ctx.stale()) ctx.rerender();
    }));
    if (e) box.append(btn(st.etymWait ? "…" : "rifai con " + (e.name || "il modello"), "Una richiesta al modello: etimologia scritta direttamente nella tua lingua; resta salvata", async () => {
      if (st.etymWait) return;
      st.etymWait = true; ctx.rerender();
      const r = await DS_ETYM.fromModel(e, ctx.word, ctx.lang, ctx.target, ctx.sentence);
      st.etymWait = false;
      if (r && !r.error) { st.wikt = { ...st.wikt, ...r }; st.etymFix = false; }
      else st.etymErr = (r && r.error) || "nessuna risposta";
      if (!ctx.stale()) ctx.rerender();
    }));
    box.append(btn("✎ correggi a mano", "Scrivi tu l'etimologia giusta: resta salvata", () => { st.etymEdit = !st.etymEdit; ctx.rerender(); }));
    if (w.fixed) box.append(btn("togli la correzione", "Torna all'etimologia di Wiktionary", () => { st.wikt = { ...st.wikt, ...DS_ETYM.override(ctx.word, ctx.lang, ctx.target, "") }; st.etymFix = false; ctx.rerender(); }));
    if (st.etymErr) box.append(mk("div", "dsx-muted", "Non riesco: " + st.etymErr));
    if (st.etymEdit) {
      const t = mk("textarea", "dsx-input");
      t.rows = 3; t.value = w.trans || "";
      t.addEventListener("keydown", (ev) => ev.stopPropagation());
      t.addEventListener("keyup", (ev) => ev.stopPropagation());
      box.append(t, btn("salva", "", () => {
        st.wikt = { ...st.wikt, ...DS_ETYM.override(ctx.word, ctx.lang, ctx.target, t.value) };
        st.etymEdit = false; st.etymFix = false; ctx.rerender();
      }, "dsx-known-on"));
      setTimeout(() => t.focus(), 0);
    }
    return box;
  }

  // ctx: { word, lemma, lang, target, sentence, prefs, llm, st, rerender, stale, speak(text, lang, rate), etymHint, engine() }
  // ---------- Kanji e caratteri cinesi uno per uno (si impara anche il singolo carattere, non solo la parola) ----------
  // Prima si apre la parola intera (come per le altre lingue); nella scheda ogni carattere si può isolare con un clic.
  const HAN = /\p{Script=Han}/u;
  const hanChars = (w) => [...new Set(Array.from(String(w || "")).filter((c) => HAN.test(c)))];
  const hanName = (lang) => (/^ja/.test(lang) ? "Kanji" : /^ko/.test(lang) ? "Hanja" : "Caratteri");
  function hanLoad(ctx, ch) {
    const st = ctx.st;
    st.han = st.han || {};
    if (st.han[ch]) return;
    st.han[ch] = { wait: true };
    DS_EXT.runtime.sendMessage({ type: "hanChar", ch, lang: ctx.lang, target: ctx.target })
      .then((r) => { st.han[ch] = r || { error: "nessuna risposta" }; if (!ctx.stale()) ctx.rerender(); })
      .catch((e) => { st.han[ch] = { error: String(e.message || e) }; if (!ctx.stale()) ctx.rerender(); });
  }
  const GRADE = { 1: "1ª elementare", 2: "2ª elementare", 3: "3ª elementare", 4: "4ª elementare", 5: "5ª elementare", 6: "6ª elementare", 8: "jōyō (scuole medie)", 9: "jinmeiyō (nomi di persona)", 10: "jinmeiyō (nomi di persona)" };
  function hanBox(ctx) {
    const st = ctx.st, lang = String(ctx.lang || "");
    const chars = hanChars(ctx.word);
    const single = Array.from(String(ctx.word).trim()).length === 1;
    if (!chars.length) return null;
    const wrap = mk("div", "dsx-han");
    if (single) st.hanSel = chars[0];
    else {
      const row = mk("div", "dsx-hanrow");
      row.append(mk("b", null, hanName(lang) + " uno per uno: "));
      for (const ch of chars) {
        const known = DS_KNOWN.has(lang, ch);
        row.append(btn(ch + (known ? "✓" : ""), `Solo «${ch}»: significato, letture, tratti` + (known ? " (lo conosci)" : ""),
          () => { st.hanSel = st.hanSel === ch ? "" : ch; if (st.hanSel) hanLoad(ctx, ch); ctx.rerender(); },
          "dsx-hanchip" + (st.hanSel === ch ? " dsx-on" : "") + (known ? " dsx-known-on" : "")));
      }
      wrap.append(row);
    }
    const ch = st.hanSel;
    if (!ch || !chars.includes(ch)) return wrap;
    hanLoad(ctx, ch);
    const h = st.han[ch] || { wait: true };
    const panel = mk("div", "dsx-hanpanel");
    const top = mk("div", "dsx-hantop");
    top.append(mk("span", "dsx-hanbig", ch));
    const info = mk("div", "dsx-haninfo");
    if (h.wait) info.append(mk("span", "dsx-muted", "Cerco il carattere…"));
    else if (h.error) info.append(mk("span", "dsx-muted", "Non trovo informazioni su questo carattere: " + h.error));
    else {
      const line = (label, text, title) => { if (!text) return; const d = mk("div", "dsx-hanline"); d.append(mk("b", null, label + ": "), document.createTextNode(text)); if (title) d.title = title; info.append(d); };
      if (!single) line("Significato", [h.meaning, ...(h.alt || [])].filter(Boolean).join(", "), "Google, con il carattere da solo");
      if (h.meaningsEn && h.meaningsEn.length) line(single ? "Significati del kanji" : "Come kanji", h.meaningsTr || h.meaningsEn.join(", "), "KANJIDIC (inglese): " + h.meaningsEn.join(", "));
      if (h.on && h.on.length) line("on (lettura cinese)", h.on.join("、"), "Lettura on'yomi: di solito nelle parole composte da più kanji");
      if (h.kun && h.kun.length) line("kun (lettura giapponese)", h.kun.join("、"), "Lettura kun'yomi: di solito quando il kanji è da solo o seguito da kana (il punto separa la parte scritta in kana)");
      if (!(h.on && h.on.length) && h.reading) line("lettura", h.reading);
      const b = mk("div", "dsx-badges");
      if (h.strokes) b.append(mk("span", "dsx-badge", h.strokes + " tratti"));
      if (h.jlpt) { const j = mk("span", "dsx-badge dsx-jlpt", "JLPT " + h.jlpt); j.title = "Livello del kanji nel JLPT secondo KANJIDIC (può seguire la vecchia scala da 4, il più facile, a 1)"; b.append(j); }
      if (h.grade && GRADE[h.grade]) { const g = mk("span", "dsx-badge" + (h.grade <= 6 ? " dsx-common" : ""), GRADE[h.grade]); g.title = "Quando si studia nelle scuole giapponesi (i kanji delle elementari sono i più comuni)"; b.append(g); }
      if (b.childNodes.length) info.append(b);
    }
    top.append(info);
    panel.append(top);
    const tools = mk("div", "dsx-tools");
    if (ctx.speak) tools.append(btn("🔈", "Ascolta (voce sintetica: da solo un kanji può avere più letture)", () => ctx.speak(ch, lang)));
    if (!single) {
      const known = DS_KNOWN.has(lang, ch);
      tools.append(btn(known ? "✓ lo conosco" : "lo conosco?", known ? "Togli dai caratteri che conosci" : "Segna questo carattere come conosciuto",
        () => { DS_KNOWN.set(lang, ch, !known); ctx.rerender(); if (ctx.onKnown) ctx.onKnown(); }, known ? "dsx-known-on" : ""));
      if (ctx.openWord) tools.append(btn("scheda del carattere ›", `Apri «${ch}» come una parola: esempi, etimologia, salvataggio nel vocabolario e in Anki`, () => ctx.openWord(ch)));
    }
    const link = (label, href, title) => { const a = mk("a", "dsx-link", label); a.href = href; a.target = "_blank"; a.rel = "noopener noreferrer"; if (title) a.title = title; tools.append(a); };
    const q = encodeURIComponent(ch);
    if (/^ja/.test(lang)) {
      link("Jisho", "https://jisho.org/search/" + q + "%20%23kanji", "Scheda del kanji su Jisho: radicale, parti, ordine dei tratti");
      link("parole con " + ch, "https://jisho.org/search/*" + q + "*", "Parole che contengono questo kanji (Jisho)");
    }
    link("Wiktionary", "https://en.wiktionary.org/wiki/" + q, "Wiktionary (inglese): origine, radicale, ordine dei tratti, letture in tutte le lingue");
    panel.append(tools);
    if (h.sources && h.sources.length) panel.append(mk("div", "dsx-muted dsx-small", "Fonte: " + h.sources.join(", ")));
    wrap.append(panel);
    return wrap;
  }

  function render(ctx) {
    const p = ctx.prefs || {}, st = ctx.st, llm = ctx.llm || null;
    const box = mk("div", "dsx");
    load(ctx);
    const w = st.wikt;

    // 1. frequenza, genere, "la so"
    const badges = mk("div", "dsx-badges");
    if (p.learnFreq !== false) {
      if (st.freq === undefined) badges.append(mk("span", "dsx-badge dsx-muted", "frequenza …"));
      else if (st.freq !== null) {
        // cliccando: l'elenco delle parole più usate della lingua, con la posizione di questa parola
        const b = btn(DS_FREQ.label(st.freq) + " ›", "Apri l'elenco delle parole più usate in questa lingua, con la posizione di questa parola",
          () => DS_EXT.runtime.sendMessage({ type: "openFreq", lang: ctx.lang, word: ctx.word, target: ctx.target }).catch(() => {}),
          "dsx-badge dsx-freq dsx-freqbtn" + (st.freq && st.freq <= 5000 ? " dsx-common" : ""));
        badges.append(b);
        // livello indicativo (A1…C2, solo dalla frequenza): apre l'elenco a quel livello
        const lv = typeof dsLevelOf === "function" && dsLevelOf(st.freq);
        if (lv) badges.append(btn("livello ≈ " + lv.id + " ›", `Livello indicativo dalla frequenza (parole n. ${lv.from}–${lv.to}). Apri le parole di questo livello`,
          () => DS_EXT.runtime.sendMessage({ type: "openFreq", lang: ctx.lang, target: ctx.target, level: lv.id }).catch(() => {}), "dsx-badge dsx-freqbtn dsx-level"));
      }
    }
    if (p.learnGender !== false && w && w.gender) {
      const g = genderInfo(w.gender, ctx.lang);
      if (g) badges.append(mk("span", "dsx-badge " + g.cls, g.text));
    }
    if (p.learnKnown !== false) {
      const known = DS_KNOWN.has(ctx.lang, ctx.word);
      badges.append(btn(known ? "✓ la conosco" : "la conosco?", known ? "Togli dalle parole che conosci" : "Segna come parola che conosci (conta nella percentuale e viene colorata)",
        () => { DS_KNOWN.set(ctx.lang, ctx.word, !known); ctx.rerender(); if (ctx.onKnown) ctx.onKnown(); }, known ? "dsx-known-on" : ""));
    }
    if (badges.childNodes.length) box.append(badges);

    // giapponese: lettura, livello JLPT e significato dal dizionario Jisho (gratis)
    if (p.learnJisho !== false && /^ja/.test(String(ctx.lang || ""))) {
      const j = st.jisho, it = j && j.items && j.items[0];
      const row = mk("div", "dsx-jisho");
      if (!j) row.append(mk("span", "dsx-muted", "Jisho …"));
      else if (!it) row.append(mk("span", "dsx-muted", j.error ? "Jisho non disponibile" : "Non trovata su Jisho"));
      else {
        const b2 = mk("div", "dsx-badges");
        if (it.reading && it.reading !== ctx.word) b2.append(mk("span", "dsx-badge dsx-common", "lettura: " + it.reading));
        // livello JLPT: apre l'elenco delle parole di quel livello (Jisho)
        if (it.jlpt && it.jlpt.length) b2.append(btn("JLPT " + it.jlpt[0] + " ›", "Apri le parole del livello " + it.jlpt[0] + " del JLPT, con questa parola",
          () => DS_EXT.runtime.sendMessage({ type: "openJlpt", level: it.jlpt[0], word: it.word || ctx.word, target: ctx.target }).catch(() => {}), "dsx-badge dsx-freqbtn dsx-jlpt"));
        if (it.common) b2.append(mk("span", "dsx-badge", "parola comune"));
        row.append(b2);
        if (it.meanings && it.meanings.length) {
          const m = mk("div", "dsx-muted");
          m.textContent = "Jisho (inglese): " + it.meanings.join(", ") + (it.pos && it.pos.length ? " — " + it.pos.join(", ") : "") + (it.word && it.word !== ctx.word ? " · voce: " + it.word : "");
          row.append(m);
        }
      }
      box.append(row);
    }

    // kanji e caratteri cinesi: ogni carattere si può isolare (per impararli anche uno per uno)
    if (p.learnHan !== false) { const hb = hanBox(ctx); if (hb) box.append(hb); }

    // dizionario di Google (arriva con la traduzione della parola, nessuna richiesta in più)
    const gd = ctx.gdict;
    if (gd) {
      const lname = (() => { try { return new Intl.DisplayNames(["it"], { type: "language" }).of(String(ctx.lang || "").split("-")[0]) || ""; } catch { return ""; } })();
      if (p.gdAlt !== false && gd.alt && gd.alt.length) {
        const d = mk("div", "dsx-gd dsx-alt");
        d.append(mk("b", null, "Traduzioni: "));
        for (const g of gd.alt.slice(0, 3)) {
          const grp = mk("span", "dsx-altgrp");
          if (g.pos) grp.append(mk("span", "dsx-muted", g.pos + " "));
          g.items.slice(0, 5).forEach((it, i) => {
            const w = mk("span", "dsx-altw" + (i === 0 && it.score >= 0.05 ? " dsx-main" : ""), it.word);
            const bar = mk("span", "dsx-bar");
            bar.style.width = Math.max(3, Math.round(Math.min(1, it.score || 0) * 28)) + "px";
            w.append(bar);
            w.title = (it.rev.length ? "Al contrario: " + it.rev.join(", ") : "") + (it.score ? (it.rev.length ? " · " : "") + "uso: " + (it.score >= 0.1 ? "comune" : it.score >= 0.01 ? "meno comune" : "raro") : "");
            grp.append(w);
          });
          d.append(grp);
        }
        box.append(d);
      }
      if (p.gdSyn !== false && ((gd.syn && gd.syn.length) || (gd.related && gd.related.length))) {
        const d = mk("div", "dsx-gd");
        // parole cliccabili: la loro traduzione compare qui sotto (Google, gratis), con 🔈 e Wiktionary
        const wordsRow = (list) => {
          const span = mk("span");
          list.forEach((w, i) => {
            if (i) span.append(document.createTextNode(", "));
            const a = btn(w, "Traduci «" + w + "»", async () => {
              if (st.peek && st.peek.word === w) { st.peek = null; ctx.rerender(); return; }
              st.peek = { word: w, trans: null }; ctx.rerender();
              const t = await quickTrans(w, ctx.lang, ctx.target);
              if (st.peek && st.peek.word === w) { st.peek.trans = t || "—"; if (!ctx.stale()) ctx.rerender(); }
            }, "dsx-wordlink" + (st.peek && st.peek.word === w ? " dsx-on" : ""));
            span.append(a);
          });
          return span;
        };
        if (gd.syn && gd.syn.length) { d.append(mk("b", null, "Sinonimi: ")); d.append(wordsRow(gd.syn.slice(0, 2).flatMap((g) => g.words.slice(0, 6)))); }
        if (gd.related && gd.related.length) { if (gd.syn && gd.syn.length) d.append(mk("br")); d.append(mk("b", null, "Vedi anche: ")); d.append(wordsRow(gd.related.slice(0, 6))); }
        if (st.peek) {
          const pk = mk("div", "dsx-peek");
          pk.append(mk("b", null, st.peek.word), document.createTextNode(" = " + (st.peek.trans === null ? "…" : st.peek.trans) + " "));
          pk.append(btn("🔈", "Ascolta (voce sintetica)", () => ctx.speak && ctx.speak(st.peek.word, ctx.lang)));
          const a = mk("a", "dsx-link", "Wiktionary"); a.href = "https://en.wiktionary.org/wiki/" + encodeURIComponent(st.peek.word); a.target = "_blank"; a.rel = "noopener noreferrer";
          pk.append(document.createTextNode(" "), a);
          d.append(pk);
        }
        box.append(d);
      }
    }

    // definizioni: Google (nella lingua della parola, quando c'è), poi Wiktionary nella lingua della parola, poi
    // Wiktionary inglese. Tutto gratis, ognuna con "traduci" (Google). Le prime 3, le altre con "altre".
    if (p.gdDefs !== false) {
      const lname = (code) => { try { return new Intl.DisplayNames(["it"], { type: "language" }).of(String(code || "").split("-")[0]) || ""; } catch { return ""; } };
      const isEn = /^en/.test(String(ctx.lang || ""));
      const groups = [];
      const seen = new Set();
      const push = (list, source, from, url) => {
        for (const g of list || []) {
          const items = (g.items || []).filter((it) => { const k = it.def.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim(); if (!k || seen.has(k)) return false; seen.add(k); return true; });
          if (items.length) groups.push({ pos: g.pos || "", items, source, from, url });
        }
      };
      if (gd && gd.defs) push(gd.defs, "Google", ctx.lang);
      const wd = st.wdefs;
      if (wd && wd.defs) push(wd.defs, "Wiktionary", ctx.lang, wd.url);
      const english = !groups.length || isEn;   // le definizioni inglesi: per l'inglese, o se mancano le altre
      if (english && w && w.defs) push(w.defs, "Wiktionary", "en", w.url);
      const waiting = (!w || (wd && wd.wait)) && !groups.length;
      if (groups.length || waiting) {
        const d = mk("div", "dsx-gd dsx-defs");
        const inEn = groups.length && groups.every((g) => g.from === "en") && !isEn;
        const ln = lname(inEn ? "en" : ctx.lang);
        const srcs = [...new Set(groups.map((g) => g.source))];
        d.append(mk("b", null, "Definizioni" + (ln ? " in " + ln : "") + ": "));
        if (srcs.length) d.append(mk("span", "dsx-muted", "(" + srcs.join(" e ") + ") "));
        if (waiting) d.append(mk("span", "dsx-muted", "…"));
        st.defTr = st.defTr || {};
        const all = [];
        for (const g of groups) for (const it of g.items) all.push({ g, it });
        const max = st.defsAll ? 10 : 3;
        let lastPos = null;
        for (const { g, it } of all.slice(0, max)) {
          const li = mk("div", "dsx-def");
          if (g.pos && g.pos !== lastPos) li.append(mk("span", "dsx-muted", g.pos + " · "));
          lastPos = g.pos;
          li.append(document.createTextNode(it.def + " "));
          // traduzione della definizione nella tua lingua (Google, gratis), solo se la chiedi
          const k = it.def;
          const tr = st.defTr[k];
          if (String(g.from).split("-")[0] !== String(ctx.target).split("-")[0]) {
            li.append(btn(tr === undefined ? "traduci" : tr === null ? "…" : "nascondi", "Traduci la definizione nella tua lingua (Google, gratis)", async () => {
              if (tr) { delete st.defTr[k]; ctx.rerender(); return; }
              if (tr === null) return;
              st.defTr[k] = null; ctx.rerender();
              st.defTr[k] = await quickTrans(it.def + (it.ex ? "\n" + it.ex : ""), g.from, ctx.target) || "";
              if (!ctx.stale()) ctx.rerender();
            }, "dsx-mini"));
          }
          if (it.ex) li.append(mk("div", "dsx-muted dsx-defex", "«" + it.ex + "»"));
          if (tr) li.append(mk("div", "dsx-deftr", tr.replace(/\n/g, " — ")));
          d.append(li);
        }
        if (all.length > 3) d.append(btn(st.defsAll ? "meno" : "altre " + (Math.min(all.length, 10) - 3) + " ›", st.defsAll ? "Mostra solo le prime" : "Mostra le altre definizioni",
          () => { st.defsAll = !st.defsAll; ctx.rerender(); }, "dsx-mini"));
        if (gd && gd.examples && gd.examples.length && !all.some((x) => x.it.ex)) d.append(mk("div", "dsx-muted dsx-defex", "«" + gd.examples[0] + "»"));
        box.append(d);
      }
    }

    // 2. scrittura corretta?
    if (p.learnSpell !== false) {
      const row = mk("div", "dsx-spell");
      const sp = llm && llm.spelling && isFinite(llm.spelling.score) ? llm.spelling : null;
      const lt = ltForWord(st.lt, ctx.sentence, ctx.word);
      const dym = p.gdSpell !== false && gd && gd.didYouMean && gd.didYouMean.toLowerCase() !== String(ctx.word).toLowerCase() ? gd.didYouMean : "";
      if (dym && !(sp && sp.score >= 90)) {
        row.classList.add("dsx-warn");
        row.textContent = "⚠ Forse cercavi: " + dym + " (Google)";
      } else if (sp) {
        const ok = sp.score >= 90;
        row.classList.add(ok ? "dsx-ok" : "dsx-warn");
        row.textContent = (ok ? "✓ Scritta correttamente" : "⚠ Scrittura") + ` (${Math.max(0, Math.min(100, Math.round(sp.score)))}/100)` +
          (sp.correct && sp.correct.toLowerCase() !== ctx.word.toLowerCase() ? ` → forma corretta: ${sp.correct}` : "") + (sp.note ? ". " + sp.note : "");
      } else if (lt && !lt.ok) {
        row.classList.add("dsx-warn");
        row.textContent = "⚠ Possibile errore: " + (lt.message || "") + (lt.repl && lt.repl.length ? " → " + lt.repl.join(", ") : "") + " (LanguageTool)";
      } else if (lt && lt.ok) {
        row.classList.add("dsx-ok");
        row.textContent = "✓ Nessun errore trovato (LanguageTool)";
      } else if (w && "exists" in w && (!st.lt || st.lt.unsupported || st.lt.error)) {
        row.classList.add(w.exists ? "dsx-ok" : "dsx-warn");
        row.textContent = w.exists ? "✓ Parola presente nel dizionario (Wiktionary)" : "? Non trovata nel dizionario: forse scritta male, rara o un nome";
      } else row.append(mk("span", "dsx-muted", "Controllo della scrittura …"));
      box.append(row);
    }

    // 3. etimologia, audio di madrelingua, tabella
    if (p.etym !== false || p.learnTable !== false) {
      const row = mk("div", "dsx-etym");
      if (!w) row.append(mk("span", "dsx-muted", "Wiktionary …"));
      else if (w.error) row.append(mk("span", "dsx-muted", "Wiktionary non disponibile: " + w.error));
      else {
        if (p.etym !== false) {
          if (w.trans) {
            row.append(mk("b", null, "Etimologia: "), document.createTextNode(w.trans + " "));
            if (w.fixed && w.source === "corretta da te") row.append(mk("span", "dsx-muted", "(✎ corretta da te) "));
            else if (w.source && w.source !== "Wiktionary") row.append(mk("span", "dsx-muted", "(" + w.source + ") "));
            if (st.etymOrig && w.text && w.text !== w.trans) row.append(mk("div", "dsx-muted dsx-orig", "Originale (Wiktionary, inglese): " + w.text));
          } else row.append(mk("span", "dsx-muted", "Etimologia: non trovata su Wiktionary. " + (ctx.etymHint || "")));
          if (w.trans) st.etymText = w.trans;
        }
        const tools = mk("span", "dsx-tools");
        if (p.learnTable !== false && w.table) tools.append(btn(st.showTable ? "nascondi tabella" : "▦ tabella", "Coniugazione o declinazione (Wiktionary)" + (w.tableTitle && w.tableTitle !== ctx.word ? ` di «${w.tableTitle}»` : ""), () => { st.showTable = !st.showTable; ctx.rerender(); }));
        if (w.url) { const a = mk("a", "dsx-link", "Wiktionary"); a.href = w.url; a.target = "_blank"; a.rel = "noopener noreferrer"; tools.append(a); }
        // il testo com'è scritto su Wiktionary (prima della traduzione automatica), sempre a portata di clic
        if (p.etym !== false && w.trans && w.text && w.text !== w.trans) tools.append(btn(st.etymOrig ? "nascondi originale" : "originale", "Mostra l'etimologia com'è scritta su Wiktionary (in inglese), senza traduzione automatica", () => { st.etymOrig = !st.etymOrig; ctx.rerender(); }));
        if (p.etym !== false && w.trans) tools.append(btn(st.etymFix ? "chiudi" : "⚑", "Etimologia sbagliata o tradotta male? Rifalla o correggila", () => { st.etymFix = !st.etymFix; st.etymEdit = false; ctx.rerender(); }));
        if (tools.childNodes.length) row.append(tools);
      }
      box.append(row);
      if (st.etymFix && w && w.trans) box.append(etymFixBox(ctx, st, w));
      if (st.showTable && w && w.table) {
        const t = mk("table", "dsx-table");
        for (const r of w.table) {
          const tr = mk("tr");
          for (const c of r) {
            const td = mk(c.h ? "th" : "td", null, c.t);
            if (c.tr && c.tr !== c.t) td.append(mk("span", "dsx-tr", c.tr));   // traslitterazione, sotto e separata
            if (c.cs > 1) td.colSpan = c.cs; if (c.rs > 1) td.rowSpan = c.rs; tr.append(td);
          }
          t.append(tr);
        }
        const wrap = mk("div", "dsx-tablewrap");
        if (w.tableTitle && w.tableTitle !== ctx.word) wrap.append(mk("div", "dsx-muted", "Forma base: " + w.tableTitle));
        wrap.append(t);
        box.append(wrap);
      }
    }

    // 4. dal modello, nella stessa richiesta della spiegazione: falsi amici e parole parenti
    if (p.learnLlmExtra !== false && llm) {
      if (llm.falseFriend) box.append(mk("div", "dsx-false", "⚠ " + llm.falseFriend));
      if (llm.related) { const d = mk("div", "dsx-related"); d.append(mk("b", null, "Parole parenti: "), document.createTextNode(llm.related)); box.append(d); }
    }

    // 5. frasi d'esempio vere (Tatoeba)
    if (p.learnExamples !== false) {
      const ex = mk("div", "dsx-ex");
      const r = st.examples;
      if (!r) ex.append(mk("span", "dsx-muted", "Esempi …"));
      else if (r.error) ex.append(mk("span", "dsx-muted", "Esempi non disponibili (Tatoeba)"));
      else if (!r.items || !r.items.length) ex.append(mk("span", "dsx-muted", "Nessun esempio su Tatoeba"));
      else {
        ex.append(mk("div", "dsx-ex-title", "Esempi veri (Tatoeba)"));
        if (!r.items.some((x) => x.audio)) ex.append(mk("div", "dsx-muted", "Per questa parola Tatoeba non ha frasi registrate da un madrelingua: 🔈 = voce sintetica." + (r.err ? " (" + r.err + ")" : "")));
        for (const it of r.items) {
          const li = mk("div", "dsx-ex-item");
          const play = it.audio ? btn("🔊", "Registrata da un madrelingua (Tatoeba)", (el) => playUrl([it.audio, ...(it.audioAlt || [])], el)) :
            btn("🔈", "Questa frase non è registrata su Tatoeba: voce sintetica", () => ctx.speak && ctx.speak(it.text, ctx.lang));
          li.append(play, mk("span", "dsx-ex-text", it.text));
          if (it.trans) li.append(mk("div", "dsx-ex-trans", it.trans + (it.google ? " (Google)" : "")));
          ex.append(li);
        }
      }
      box.append(ex);
    }
    // 6. immagine per la carta di Anki (con l'opzione accesa nel popup → Anki)
    if (p.ankiImage && st.img) box.append(imagePicker(st.img, { word: ctx.lemma || ctx.word, lang: ctx.lang, rerender: ctx.rerender, onPick: ctx.onImage }));
    return box;
  }

  // ---------- Pulsante di ascolto della scheda: registrazione vera se c'è, altrimenti voce sintetica ----------
  // 🔊 = registrazione di una persona (Wiktionary), 🔈 = voce sintetica
  const ICON_REC = "🔊", ICON_TTS = "🔈";
  // la registrazione della parola: prima quella della parola esatta (Wiktionary inglese, poi le altre edizioni);
  // se c'è solo quella di un'altra forma (гордую → гордый), si usa lo stesso ma con form = quella forma (va segnalata)
  function recordingInfo(st, word, prefs) {
    if (!st || (prefs && prefs.learnAudio === false)) return null;
    const same = (a, b) => DS_ETYM.sameWord(a, b);
    const otherFile = (list) => { const f = DS_ETYM.fileWord(list[0]); return f && !same(f, word) ? f : ""; };
    const w = st.wikt, a2 = st.audio2;
    const enOk = w && w.audio && w.audio.length;
    if (enOk && same(w.audioTitle, word) && !otherFile(w.audio)) return { audio: w.audio, form: "" };
    if (a2 && a2.audio && a2.audio.length && !a2.form) return { audio: a2.audio, form: "" };
    if (a2 && a2.wait) return null;
    if (enOk) return { audio: w.audio, form: otherFile(w.audio) || w.audioTitle || "?" };
    if (a2 && a2.audio && a2.audio.length) return { audio: a2.audio, form: a2.form };
    return null;
  }
  function recordingOf(st, word, prefs) { const r = recordingInfo(st, word, prefs); return r ? r.audio : null; }
  // titolo e classe del pulsante 🔊: un'altra forma della parola si vede (colore diverso) e si dice quale
  function recordingLabel(st, word, prefs) {
    const r = recordingInfo(st, word, prefs);
    if (!r) return null;
    return r.form ? { form: r.form, title: `Registrazione di «${r.form}», un'altra forma della parola (non di «${word}» esatta): Wiktionary`, cls: "dsx-recform" }
      : { form: "", title: "Ascolta la registrazione di un madrelingua (Wiktionary)", cls: "" };
  }
  // o: { word, lang, target, lemma, st, prefs, tts: () => Promise }  → "rec" | "tts"
  async function playWord(o) {
    const p = o.prefs || {};
    if (p.learnAudio !== false && o.st && !o.st.wikt) {
      try { o.st.wikt = await Promise.race([DS_ETYM.get(o.word, o.lang, o.target, o.lemma), new Promise((r) => setTimeout(() => r(null), 4000))]) || undefined; } catch {}
    }
    const rec = recordingOf(o.st, o.word, p);
    if (rec) {
      const r = await playUrl(rec, null);
      if (r) { if (o.onRec) o.onRec(r); return "rec"; }
    }
    if (o.tts) await o.tts();
    return "tts";
  }

  // per il vocabolario e Anki
  function entryExtras(st, lang) {
    const w = st.wikt || {};
    const g = genderInfo(w.gender, lang || "");
    return { etym: st.etymText || "", gender: g ? g.text : "", freq: st.freq || 0 };
  }

  // ---------- Immagine per la carta di Anki: Wikipedia, Wikimedia Commons, Openverse (gratis) ----------
  // Si sceglie da dove nel popup → Anki; nella scheda e nel vocabolario si cambia con ‹ ›, si cerca altro, si
  // incolla un indirizzo o si toglie. im = { list, i, none, wait, q, error, open, loaded }
  let imgSrcPref = "auto";
  DS_EXT.storage.sync.get({ ankiImageSource: "auto" }).then((r) => { imgSrcPref = r.ankiImageSource || "auto"; }).catch(() => {});
  DS_EXT.storage.onChanged.addListener((ch, a) => { if (a === "sync" && ch.ankiImageSource) imgSrcPref = ch.ankiImageSource.newValue || "auto"; });
  const imgCache = new Map();
  async function searchImages(query, lang, source, raw) {
    const k = [source, lang, query, raw ? 1 : 0].join("|");
    if (imgCache.has(k)) return imgCache.get(k);
    let r;
    try { r = await DS_EXT.runtime.sendMessage({ type: "imageSearch", query, lang, source, raw, n: 8 }); } catch (e) { r = { error: String(e.message || e) }; }
    r = r || {};
    if (!Array.isArray(r.items)) r.items = [];
    if (r.items.length) imgCache.set(k, r);
    return r;
  }
  async function image(word, lang) {
    const r = await searchImages(word, lang, imgSrcPref);
    return (r.items[0] && r.items[0].url) || "";
  }
  // l'immagine scelta: un indirizzo, "" = nessuna, undefined = non ancora decisa (allora la cerca chi salva)
  function chosenImage(im) {
    if (!im || im.wait) return undefined;
    if (im.none) return "";
    const it = im.list && im.list[im.i || 0];
    return it ? it.url : undefined;
  }
  function loadImages(im, query, lang, source, raw, done, keep) {
    im.wait = true; im.error = "";
    searchImages(query, lang, source || imgSrcPref, raw).then((r) => {
      const list = (keep || []).concat(r.items.filter((x) => !(keep || []).some((k) => k.url === x.url)));
      Object.assign(im, { wait: false, loaded: true, list, i: 0, q: r.query || query, error: r.error || "", none: false });
      done();
    });
  }
  // o: { word, lang, rerender, onPick(url) }
  function imagePicker(im, o) {
    const row = mk("div", "dsx-img");
    const pick = () => { const u = chosenImage(im); if (o.onPick && u !== undefined) o.onPick(u); o.rerender(); };
    const ensure = (then) => {
      if (im.loaded || im.wait) return then();
      loadImages(im, o.word, o.lang, null, false, () => { im.i = 0; then(); o.rerender(); }, im.list && im.list.length ? im.list.slice(0, 1) : []);
      o.rerender();
    };
    if (o.autoload && !im.loaded && !im.wait) setTimeout(() => ensure(() => {}), 0);
    const head = mk("div", "dsx-imghead");
    head.append(mk("b", null, "Immagine per Anki: "));
    const cur = im.none ? null : im.list && im.list[im.i || 0];
    if (im.wait && !cur) head.append(mk("span", "dsx-muted", "cerco… "));
    else if (im.none) {
      head.append(mk("span", "dsx-muted", "nessuna "));
      head.append(btn("rimetti", "Rimetti un'immagine", () => { im.none = false; ensure(() => {}); pick(); }, "dsx-mini"));
    } else if (!cur) head.append(mk("span", "dsx-muted", (im.error ? "non trovata (" + im.error.slice(0, 60) + ") " : "non trovata ")));
    if (cur) {
      const n = im.list.length;
      head.append(btn("‹", "Immagine precedente", () => ensure(() => { im.i = ((im.i || 0) - 1 + im.list.length) % im.list.length; pick(); }), "dsx-mini"));
      head.append(mk("span", "dsx-muted", " " + ((im.i || 0) + 1) + "/" + (im.loaded ? n : n + "+") + " "));
      head.append(btn("›", "Immagine successiva", () => ensure(() => { im.i = ((im.i || 0) + 1) % im.list.length; pick(); }), "dsx-mini"));
      head.append(btn("✕", "Nessuna immagine per questa carta", () => { im.none = true; pick(); }, "dsx-mini"));
    }
    if (!im.none) head.append(btn(im.open ? "chiudi" : "altre…", "Tutte le immagini trovate, cerca con altre parole o incolla un indirizzo", () => { im.open = !im.open; if (im.open) ensure(() => {}); o.rerender(); }, "dsx-mini"));
    row.append(head);
    if (cur && !im.open) {
      const img = mk("img", "dsx-imgthumb"); img.src = cur.thumb || cur.url; img.alt = ""; img.loading = "lazy"; img.referrerPolicy = "no-referrer";
      img.title = (cur.source ? cur.source + ": " : "") + (cur.title || "") + " — clic per vederle tutte";
      img.addEventListener("click", (e) => { e.stopPropagation(); im.open = true; ensure(() => {}); o.rerender(); });
      img.addEventListener("error", () => { img.replaceWith(mk("span", "dsx-muted", "(l'immagine non si carica: prova ›)")); });
      row.append(img);
    }
    if (im.open) {
      const grid = mk("div", "dsx-imggrid");
      (im.list || []).slice(0, 16).forEach((it, k) => {
        const g = mk("img", "dsx-imgcell" + (k === (im.i || 0) && !im.none ? " dsx-on" : "")); g.src = it.thumb || it.url; g.alt = ""; g.loading = "lazy"; g.referrerPolicy = "no-referrer";
        g.title = (it.source ? it.source + ": " : "") + (it.title || "");
        g.addEventListener("click", (e) => { e.stopPropagation(); im.i = k; im.none = false; im.open = false; pick(); });
        g.addEventListener("error", () => g.remove());
        grid.append(g);
      });
      if (im.wait) grid.append(mk("span", "dsx-muted", "cerco…"));
      row.append(grid);
      const tools = mk("div", "dsx-imgtools");
      const q = mk("input", "dsx-input"); q.type = "text"; q.placeholder = "Cerca altro (" + (im.q || o.word) + ")…"; q.spellcheck = false;
      const src = mk("select", "dsx-input");
      [["auto", "Wikipedia e Commons"], ["wikipedia", "Wikipedia"], ["commons", "Wikimedia Commons"], ["openverse", "Openverse (foto)"], ["all", "Tutte"]].forEach(([v, l]) => src.append(new Option(l, v)));
      src.value = im.src || imgSrcPref;
      const go = () => {
        const text = q.value.trim();
        im.src = src.value;
        // scritto da te: si cerca così com'è (in inglese si trova di più)
        loadImages(im, text || o.word, o.lang, src.value, !!text, () => { pick(); });
        o.rerender();
      };
      q.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") go(); });
      src.addEventListener("change", (e) => { e.stopPropagation(); go(); });
      src.addEventListener("click", (e) => e.stopPropagation());
      q.addEventListener("click", (e) => e.stopPropagation());
      const url = mk("input", "dsx-input"); url.type = "url"; url.placeholder = "…oppure incolla l'indirizzo di un'immagine (https://…)"; url.spellcheck = false;
      url.addEventListener("click", (e) => e.stopPropagation());
      url.addEventListener("keydown", (e) => {
        e.stopPropagation();
        if (e.key !== "Enter") return;
        const u = url.value.trim();
        if (!/^https:\/\/\S+$/.test(u)) { url.value = ""; url.placeholder = "Serve un indirizzo che inizia con https://"; return; }
        im.list = [{ url: u, thumb: u, source: "indirizzo tuo", title: "" }].concat((im.list || []).filter((x) => x.url !== u));
        im.i = 0; im.none = false; im.open = false; pick();
      });
      tools.append(q, src, btn("Cerca", "Cerca le immagini", go, "dsx-mini"), url);
      row.append(tools);
    }
    return row;
  }

  return { render, hanChars, entryExtras, image, chosenImage, imagePicker, playUrl, genderInfo, recordingOf, recordingInfo, recordingLabel, playWord, ICON_REC, ICON_TTS };
})();

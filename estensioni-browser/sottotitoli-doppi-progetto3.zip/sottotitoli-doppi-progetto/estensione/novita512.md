## Novità della 5.12
- **Voce per ogni lingua**: nella scheda della parola, ⚙ accanto a 🔈 apre le voci disponibili per quella lingua; quella che scegli resta salvata e si usa sempre per quella lingua. Le stesse scelte sono nel popup → Pronuncia delle parole → "Voce per ogni lingua". Senza scelta l'estensione prende da sola la migliore: prima le voci "Natural", poi quelle online, poi le altre del computer, poi Google. Passando il mouse su 🔈 dopo averlo premuto leggi quale voce ha parlato.
- **Voci naturali di Microsoft anche in Firefox (Azure Speech)**: con una chiave gratuita di Azure Speech (500.000 caratteri al mese gratis) le parole si leggono con le stesse voci "Natural" di Edge, in quasi tutte le lingue. Popup → Pronuncia delle parole → chiave, regione e "Prova la chiave".
- La voce scelta nel popup per una lingua non legge più le parole delle altre lingue.
- Tolta la dicitura "prova": gli strumenti per imparare sono nella versione normale.

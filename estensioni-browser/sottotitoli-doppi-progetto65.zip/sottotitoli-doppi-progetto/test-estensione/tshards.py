# 1.7.3: le cache a pezzi: migrazione delle vecchie chiavi (etymCache, ipaCache, explSaved) e scritture piccole
import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        old_etym = {"ru|кошка|it": {"text": "origine", "trans": "origine corretta da me", "fixed": True, "tv": 11}, "ru|собака|it": {"text": "x", "trans": "y", "tv": 11}, "en|bread|it": {"text": "e", "trans": "t", "tv": 11}}
        old_expl = {"en|bread": [{"s": "I like bread.", "e": "Gemini", "m": "m1", "at": 1, "d": {"meaning": "pane", "explanation": "SPIEGAZIONE-VECCHIA"}}], "ru|кошка": [{"s": "Это кошка.", "e": "Gemini", "m": "m1", "at": 2, "d": {"meaning": "gatto"}}]}
        await sw.evaluate("(a) => chrome.storage.local.set({etymCache: a[0], explSaved: a[1], ipaCache: {'en|bread': 'brɛd'}})", [old_etym, old_expl])
        await sw.evaluate("dsMigrateShards()")
        await asyncio.sleep(0.5)
        keys = await sw.evaluate("chrome.storage.local.get(null).then(o => Object.keys(o).filter(k => /^(etym|expl|ipa)/.test(k)).sort())")
        print("1. chiavi dopo la migrazione:", keys)
        e = await sw.evaluate("chrome.storage.local.get('etym:ru').then(o => o['etym:ru'])")
        x = await sw.evaluate("chrome.storage.local.get('expl:en').then(o => o['expl:en'])")
        print("2. etimologia ru:", list(e), "| corretta da me conservata:", e["ru|кошка|it"].get("fixed"), "| spiegazione en:", x["en|bread"][0]["d"]["explanation"])
        ok = "etymCache" not in keys and "explSaved" not in keys and "ipaCache" not in keys and "etym:ru" in keys and "expl:en" in keys and e["ru|кошка|it"].get("fixed") and "ipa:en" not in keys
        # una scheda nuova: legge solo il suo pezzo e scrive solo il suo pezzo
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:true, hoverPause:true})")
        await sw.evaluate("self.__st = []; chrome.storage.onChanged.addListener((ch, area) => { for (const [k, v] of Object.entries(ch)) { let n = 0; try { n = JSON.stringify(v.newValue).length; } catch {} self.__st.push([k, n]); } });")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(3500)
        card = await pg.evaluate("(document.querySelector('.dualsub-card')||{}).innerText||''")
        print("3. scheda di «bread»: spiegazione salvata (🗂) vista:", "SPIEGAZIONE-VECCHIA" in card or "🗂" in card)
        st = await sw.evaluate("self.__st")
        print("4. scritture:", sorted(set((k, n) for k, n in st)))
        print("errori:", errs if ok else errs + ["migrazione non riuscita"], log["errors"])
        await ctx.close()
asyncio.run(main())

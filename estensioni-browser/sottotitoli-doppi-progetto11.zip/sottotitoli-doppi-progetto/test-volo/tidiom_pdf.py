# PDF ceco (Hrabal, p. 4: «Pro krásnou ženu…») con il modo di dire «krásnou ženu» già noto (arancione): selezionando
# l'una o l'altra parola deve comparire la scheda. Uso: python3 tidiom_pdf.py <estensione> [file.pdf]
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
PDF = sys.argv[2] if len(sys.argv) > 2 else "/tmp/hrabal.pdf"
async def handle(route, request):
    if request.url.split("?")[0].endswith(".pdf"):
        return await route.fulfill(status=200, content_type="application/pdf", body=open(PDF, "rb").read())
    return await tvolo.handle(route, request)
FIND = """(w)=>{for (const t of document.querySelectorAll('.textLayer')){const tw=document.createTreeWalker(t, NodeFilter.SHOW_TEXT); let n;
  while((n=tw.nextNode())){const i=n.nodeValue.indexOf(w); if(i>=0){n.parentElement.scrollIntoView({block:'center'}); const r=document.createRange(); r.setStart(n,i); r.setEnd(n,i+w.length); const b=r.getBoundingClientRect(); return {l:b.left, r:b.right, x:b.x+b.width/2, y:b.y+b.height/2};}}} return null}"""
CARD = "(document.querySelector('.pav-root .pav-card')||{}).innerText||'(niente)'"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        eid = sw.url.split("/")[2]
        await sw.evaluate("""chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnFreq:false, learnSpell:false})
          .then(()=>chrome.storage.local.set({pavIdioms: {'krasnou zenu': {text:'krásnou ženu', meaning:'una bella donna', lang:'cs', at: Date.now()}}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/pdf.html?file=https%3A%2F%2Fexample.test%2Fx.pdf"); await pg.wait_for_timeout(3000)
        for _ in range(8):
            await pg.mouse.wheel(0, 900); await pg.wait_for_timeout(300)
        await pg.wait_for_timeout(1500)
        for w in ("krásnou", "ženu"):
            await pg.mouse.click(5, 5); await pg.wait_for_timeout(300)
            b = await pg.evaluate(FIND, w); await pg.wait_for_timeout(500); b = await pg.evaluate(FIND, w)
            if not b: print("non trovata:", w); continue
            # selezione trascinando sulla parola
            await pg.mouse.move(b["l"] + 1, b["y"]); await pg.mouse.down(); await pg.mouse.move(b["r"] - 1, b["y"], steps=6); await pg.mouse.up(); await pg.wait_for_timeout(2500)
            print(f"selezione «{w}»: testo selezionato =", repr(await pg.evaluate("String(getSelection())")), "| scheda:", (await pg.evaluate(CARD)).replace("\n", " | ")[:160])
            await pg.keyboard.press("Escape"); await pg.wait_for_timeout(300)
            await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(2500)
            print(f"doppio clic «{w}»: testo selezionato =", repr(await pg.evaluate("String(getSelection())")), "| scheda:", (await pg.evaluate(CARD)).replace("\n", " | ")[:160])
            await pg.keyboard.press("Escape"); await pg.wait_for_timeout(300)
        print("arancione:", await pg.evaluate("CSS.highlights.has('pav-idiom') ? [...CSS.highlights.get('pav-idiom')].map(r=>r.toString()) : []"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

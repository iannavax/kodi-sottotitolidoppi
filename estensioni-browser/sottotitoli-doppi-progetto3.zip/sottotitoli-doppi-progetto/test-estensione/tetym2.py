# 5.10.1: una sola richiesta al modello per spiegazione + etimologia (solo se Wiktionary non la ha) + IPA (solo se accesa)
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', ipa:false, hoverPause:true, idioms:false})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=etymUna"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'') && document.querySelectorAll('.dualsub-tword').length>1", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        W = lambda t: words.nth(texts.index(t))
        # 1. market: Wiktionary non la ha → la scheda invita a cliccare
        await W("market").hover(); await pg.wait_for_timeout(2500)
        print("1. passando su market:", await pg.evaluate("(document.querySelector('.dualsub-card .dsx-etym')||{}).innerText"))
        await W("market").click(); await pg.wait_for_timeout(9000)
        print("2. clic su market:", await pg.evaluate("(document.querySelector('.dualsub-card .dsx-etym')||{}).innerText"), "| richieste di spiegazione (parola, con etimologia, con IPA):", log.get("define"))
        await pg.keyboard.press("Escape"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(600)
        # 3. bread: Wiktionary la ha → la richiesta al modello non la chiede
        await W("bread").hover(); await pg.wait_for_timeout(2500)
        await W("bread").click(); await pg.wait_for_timeout(9000)
        print("3. clic su bread:", (await pg.evaluate("(document.querySelector('.dualsub-card .dsx-etym')||{}).innerText"))[:70], "| richieste:", log.get("define"))
        await pg.keyboard.press("Escape")
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

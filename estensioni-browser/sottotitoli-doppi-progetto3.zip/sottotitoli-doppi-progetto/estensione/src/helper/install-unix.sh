#!/bin/sh
# Sottotitoli Doppi - installazione del programma per yt-dlp (Mac e Linux)
# Installa per il tuo utente: yt-dlp, Deno, il programma di appoggio, e lo registra nei browser.
set -e
EXT_ID='__EXTID__'
GECKO='sottotitoli-doppi@estensione.local'
NAME='com.sottotitolidoppi.helper'
OS=$(uname -s)
ARCH=$(uname -m)
if [ "$OS" = "Darwin" ]; then
  DIR="$HOME/Library/Application Support/SottotitoliDoppi"
  BASE="$HOME/Library/Application Support"
  CHROME_DIRS="$BASE/Microsoft Edge/NativeMessagingHosts:$BASE/Google/Chrome/NativeMessagingHosts:$BASE/BraveSoftware/Brave-Browser/NativeMessagingHosts:$BASE/Chromium/NativeMessagingHosts"
  FF_DIRS="$BASE/Mozilla/NativeMessagingHosts"
  YT_URL=${SD_YTDLP_URL:-https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos}
  DENO_TARGET=apple-darwin
else
  DIR="${XDG_DATA_HOME:-$HOME/.local/share}/sottotitoli-doppi"
  CHROME_DIRS="$HOME/.config/microsoft-edge/NativeMessagingHosts:$HOME/.config/google-chrome/NativeMessagingHosts:$HOME/.config/BraveSoftware/Brave-Browser/NativeMessagingHosts:$HOME/.config/chromium/NativeMessagingHosts"
  FF_DIRS="$HOME/.mozilla/native-messaging-hosts"
  YT_URL=${SD_YTDLP_URL:-https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp}
  DENO_TARGET=unknown-linux-gnu
fi
[ -n "$SD_EXTRA_CHROME_DIRS" ] && CHROME_DIRS="$CHROME_DIRS:$SD_EXTRA_CHROME_DIRS"
case "$ARCH" in arm64|aarch64) DENO_ARCH=aarch64 ;; *) DENO_ARCH=x86_64 ;; esac
DENO_URL=${SD_DENO_URL:-https://github.com/denoland/deno/releases/latest/download/deno-$DENO_ARCH-$DENO_TARGET.zip}

echo ""
echo "=== Sottotitoli Doppi: programma per yt-dlp ==="
PY=$(command -v python3 || true)
if [ -z "$PY" ]; then
  echo "Serve Python 3. Su Mac: installalo da https://www.python.org/downloads/ ; su Linux: dal gestore dei pacchetti (python3). Poi rilancia."
  exit 1
fi
mkdir -p "$DIR"
echo "1/4  Scarico yt-dlp..."
curl -fsSL --retry 2 -o "$DIR/yt-dlp" "$YT_URL"
chmod +x "$DIR/yt-dlp"
echo "2/4  Scarico Deno..."
curl -fsSL --retry 2 -o "$DIR/deno.zip" "$DENO_URL"
"$PY" -m zipfile -e "$DIR/deno.zip" "$DIR/"
rm -f "$DIR/deno.zip"
chmod +x "$DIR/deno"
echo "3/4  Installo il programma di appoggio e lo registro nei browser..."
"$PY" - "$DIR" "$PY" "$EXT_ID" "$GECKO" "$NAME" "$CHROME_DIRS" "$FF_DIRS" << 'PYEOF'
import base64, json, os, stat, sys
d, py, ext_id, gecko, name, chrome_dirs, ff_dirs = sys.argv[1:8]
open(os.path.join(d, "sd_host.py"), "wb").write(base64.b64decode("__HOSTB64__"))
wrapper = os.path.join(d, "sd_host.sh")
open(wrapper, "w").write('#!/bin/sh\nexec "%s" -u "%s" "$@"\n' % (py, os.path.join(d, "sd_host.py")))
os.chmod(wrapper, 0o755)
cm_path = os.path.join(d, "host-chrome.json")
origins = []
try:
    origins = json.load(open(cm_path)).get("allowed_origins", [])
except Exception:
    pass
if ext_id and "chrome-extension://%s/" % ext_id not in origins:
    origins.append("chrome-extension://%s/" % ext_id)
cm = {"name": name, "description": "Sottotitoli Doppi: audio con yt-dlp", "path": wrapper, "type": "stdio", "allowed_origins": origins}
fm = {"name": name, "description": "Sottotitoli Doppi: audio con yt-dlp", "path": wrapper, "type": "stdio", "allowed_extensions": [gecko]}
json.dump(cm, open(cm_path, "w"), indent=2)
for dirs, m in ((chrome_dirs, cm), (ff_dirs, fm)):
    for x in dirs.split(":"):
        if not x:
            continue
        os.makedirs(x, exist_ok=True)
        json.dump(m, open(os.path.join(x, name + ".json"), "w"), indent=2)
print("     registrato per:", len([x for x in chrome_dirs.split(":") if x]), "browser Chromium e Firefox")
PYEOF
echo "4/4  Verifico..."
echo "     yt-dlp $("$DIR/yt-dlp" --version)"
echo "     $("$DIR/deno" --version | head -n 1)"
echo ""
echo "Fatto! Torna nel browser e premi \"Verifica di nuovo\". (Tutto e' in $DIR)"

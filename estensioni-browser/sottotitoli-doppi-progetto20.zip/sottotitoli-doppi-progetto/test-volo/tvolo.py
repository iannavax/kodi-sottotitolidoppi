# Prova di Parole al Volo con servizi simulati (Google, Gemini, Groq, AnkiConnect)
import asyncio, os, sys, json, re, urllib.parse, io, wave
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
EXT = sys.argv[1]
log = {"google": [], "gem": [], "ipa": [], "anki": [], "errors": []}
CYR = re.compile("[а-яА-Я]")
def translit(t):
    m = {"привет": "privet", "мир": "mir", "кошка": "koshka"}
    return " ".join(m.get(w.lower().strip(".,!"), "x") for w in t.split())
def detect(t):
    if CYR.search(t): return "ru"
    if re.search(r"[\u3040-\u30ff\u4e00-\u9fff]", t): return "ja"
    if re.search(r"\b(il|gatto|della|sono|casa)\b", t, re.I): return "it"
    if re.search(r"\b(hermana|está|muy|embaraz\w*|hoy)\b", t, re.I): return "es"
    return "en"
PAGE = """<!doctype html><html lang="en"><head><title>Pagina di prova</title></head><body style="margin:40px;font:18px/1.6 Georgia">
<h1>An English page</h1>
<p id="en">We went to the market and bought some fresh bread. Then we walked home slowly.</p>
<p id="it" lang="it">Il gatto della vicina dorme sempre sul divano di casa.</p>
<p id="ru" lang="ru">Привет мир. Кошка спит.</p>
<p id="ja" lang="ja">日本語を勉強しています。</p>
<p id="long">The weather was cold. Everyone stayed inside and read books by the fire.</p>
<input id="inp" value="text in an input box">
</body></html>"""
def wavbytes():
    b = io.BytesIO(); w = wave.open(b, "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000); w.writeframes(b"\x00\x10" * 8000); w.close(); return b.getvalue()

async def handle(route, request):
    url = request.url
    if not url.startswith("http"):
        return await route.continue_()
    try:
        if url.startswith("https://example.test/"):
            return await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=PAGE)
        if "/translate_tts" in url:
            return await route.fulfill(status=200, content_type="audio/mpeg", body=wavbytes())
        if url.startswith("https://translate.googleapis.com/translate_a/single"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            text = q.get("q", [""])[0]; dts = q.get("dt", [])
            log["google"].append((dts, text))
            lang = detect(text)
            parts = [["IT[" + text + "]", text]]
            if "rm" in dts and lang == "ru": parts.append([None, None, None, translit(text)])
            body = [parts, [["sostantivo", ["pane", "pagnotta"]]] if "bd" in dts else None, lang]
            if "md" in dts:
                sys.path.insert(0, "/home/claude/e2e"); import charness as _c
                body = _c.gdict_body(text, "IT[" + text + "]", lang); body[0] = parts
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
        if url.startswith("https://generativelanguage.googleapis.com/") or url.startswith("https://api.groq.com/openai/v1/chat"):
            who = "groq" if "groq" in url else "gemini"
            if who == "gemini" and os.environ.get("GEM_DAILY_429"):
                log.setdefault("gem429", []).append(1)
                return await route.fulfill(status=429, content_type="application/json", body='[{"error":{"code":429,"message":"You exceeded your current quota","status":"RESOURCE_EXHAUSTED","details":[{"@type":"type.googleapis.com/google.rpc.QuotaFailure","violations":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel-FreeTier"}]}]}}]')
            p = json.loads(request.post_data or "{}")
            sysm, user = p["messages"][0]["content"], p["messages"][1]["content"]
            log.setdefault("maxtok", []).append((who, p.get("max_tokens")))
            # Groq con un modello che accetta al massimo 4096 token di risposta (errore vero di Groq)
            lim = int(os.environ.get("GROQ_MAXTOK", "0") or 0)
            if who == "groq" and lim and (p.get("max_tokens") or 0) > lim:
                log.setdefault("maxtok400", []).append(p.get("max_tokens"))
                return await route.fulfill(status=400, content_type="application/json", body=json.dumps({"error": {"message": f"`max_tokens` must be less than or equal to `{lim}`, the maximum value for `max_tokens` is less than the `context_window` for this model", "type": "invalid_request_error"}}))
            if who == "groq" and (p.get("max_tokens") or 0) + (len(sysm) + len(user)) // 4 > 6000:   # come Groq: max_tokens conta nel limite al minuto
                return await route.fulfill(status=413, content_type="application/json", body=json.dumps({"error": {"message": f"Request too large for model `llama-3.1-8b-instant` in organization `org` service tier `on_demand` on tokens per minute (TPM): Limit 6000, Requested {p.get('max_tokens') + 900}, please reduce your message size and try again.", "type": "tokens", "code": "rate_limit_exceeded"}}))
            if sysm.startswith("You are an expert phonetician"):
                u = json.loads(user); words = u["words"]; log["ipa"].append((who, words, "sentence" in u))
                if any(re.search(r"[\u3040-\u30ff\u4e00-\u9fff]", w) for w in words):
                    log["ja_calls"] = log.get("ja_calls", 0) + 1
                    if log["ja_calls"] == 1:   # prima volta: il modello salta "勉強"
                        content = json.dumps({"ipa": {w: "ja-" + w for w in words if w != "勉強"}})
                    else:                       # poi risponde, ma con le chiavi cambiate (in kana), nello stesso ordine
                        content = json.dumps({"ipa": {"かな" + str(i): "ja-" + w for i, w in enumerate(words)}})
                else:
                    content = json.dumps({"ipa": {w: "ˈ" + w.lower() for w in words}})
            elif sysm.startswith("You find idioms"):
                sent = json.loads(user)["sentence"]; log.setdefault("idiomsFind", []).append(sent)
                ids = [{"text": "walked home", "meaning": "tornare a piedi"}] if "walked home" in sent else []
                content = json.dumps({"idioms": ids})
            elif sysm.startswith("You are a friendly language tutor"):
                log["gem"].append(("define", user, '"etymology"' in sysm, '"ipa"' in sysm))
                o = {"lemma": "bread", "pos": "sostantivo", "meaning": "pane (nel contesto)", "explanation": "Spiegazione finta.", "example": "I like bread.", "example_translation": "Mi piace il pane.", "lang": "en", "ipa": "brɛd"}
                bad = os.environ.get("BAD_DEFINE")
                if bad and (bad == "always" or "IMPORTANT" not in sysm):
                    w0 = user.split('"')[1]
                    o.update({"meaning": w0, "explanation": "ملاحظة توضيحية في النص", "pos": "اسم"})
                if os.environ.get("IDIOM"): o.update({"expression": os.environ["IDIOM"], "expression_meaning": "pane appena fatto"})
                log.setdefault("define_sys", []).append("IMPORTANT" in sysm)
                if '"etymology"' in sysm: o["etymology"] = "ETIM[" + user.split('"')[1] + "]"
                if '"sentence_translation"' in sysm: o["sentence_translation"] = "FRASE-GEM[frase tradotta in italiano dal modello, con la correzione]"
                if '"false_friend"' in sysm:
                    o["false_friend"] = "FALSO[" + user.split('"')[1] + "]"; o["related"] = "PARENTI[" + user.split('"')[1] + "]"; o["spelling"] = {"score": 95, "correct": "", "note": ""}
                log.setdefault("extra", []).append('"false_friend"' in sysm)
                content = json.dumps(o)
            else:
                segs = json.loads(user)["segments"]; log["gem"].append(("translate", segs))
                content = json.dumps({"t": ["GEM[" + s + "]" for s in segs]})
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": content}}]}))
        if url.startswith("https://api-free.deepl.com/v2/translate"):
            b = json.loads(request.post_data or "{}"); log.setdefault("deepl", []).append(b.get("text"))
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"translations": [{"text": "DEEPL[" + t + "]"} for t in b.get("text", [])]}))
        if url.startswith("http://127.0.0.1:8765"):
            r = json.loads(request.post_data or "{}"); a = r.get("action"); par = r.get("params", {})
            log["anki"].append((a, par))
            res = {"requestPermission": {"permission": "granted", "requireApikey": False, "version": 6}, "version": 6,
                   "modelNames": ["Base", "Cloze"], "modelFieldNames": ["Fronte", "Retro"], "createDeck": 1, "deckNames": ["Default", "Parole al Volo"],
                   "addNote": 1000 + len(log["anki"])}.get(a)
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"result": res, "error": None}))
        return await route.fulfill(status=404, body="")
    except Exception as e:
        log["errors"].append(f"{url}: {e}")
        try: return await route.fulfill(status=500, body=str(e))
        except Exception: pass

async def word_box(pg, pid, word):
    return await pg.evaluate("""([pid, word]) => { const p = document.getElementById(pid); const tw = document.createTreeWalker(p, NodeFilter.SHOW_TEXT);
      for (let n = tw.nextNode(); n; n = tw.nextNode()) { const i = n.data.indexOf(word); if (i >= 0) { const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + word.length);
      const b = r.getBoundingClientRect(); return {x: b.left + b.width / 2, y: b.top + b.height / 2, l: b.left, r: b.right}; } } return null; }""", [pid, word])

async def hover(pg, pid, word, wait=1500):
    await pg.mouse.move(5, 5); await pg.wait_for_timeout(500)
    b = await word_box(pg, pid, word)
    await pg.mouse.move(b["x"], b["y"], steps=4); await pg.wait_for_timeout(wait)
    return b

card_text = lambda pg: pg.evaluate("(document.querySelector('.pav-card')||{}).innerText||''")

async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True,
            args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/riscaldamento').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', engine:'gemini', pavEngine:'gemini'}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console: " + m.text) if m.type == "error" else None)
        await pg.goto("https://example.test/pagina.html"); await pg.wait_for_timeout(800)
        # 1. passo su "bread"
        await hover(pg, "en", "bread", 2500)
        t = await card_text(pg)
        print("1. scheda:", t.replace("\n", " | ")[:400])
        print("   richieste IPA:", [(w, len(x)) for w, x, _ in log["ipa"]], "| prima:", log["ipa"][0][1] if log["ipa"] else None)
        print("   evidenziata:", await pg.evaluate("CSS.highlights && CSS.highlights.has('pav-word')"))
        # 2. altra parola della stessa frase: la pronuncia è già salvata
        n = len(log["ipa"])
        await hover(pg, "en", "market", 2000)
        print("2. market:", (await pg.evaluate("(document.querySelector('.pav-ipa')||{}).textContent")), "| richieste IPA nuove:", len(log["ipa"]) - n)
        # 3. paragrafo in italiano: niente scheda (è già la tua lingua), e la seconda volta nessuna richiesta
        await hover(pg, "it", "gatto", 1500)
        c1 = await pg.evaluate("!!document.querySelector('.pav-card')")
        g = len(log["google"])
        await hover(pg, "it", "divano", 1500)
        print("3. italiano: scheda", c1, await pg.evaluate("!!document.querySelector('.pav-card')"), "| richieste a Google la seconda volta:", len(log["google"]) - g)
        # 4. russo: trascrizione in caratteri latini
        await hover(pg, "ru", "Кошка", 2000)
        print("4. russo:", (await card_text(pg)).replace("\n", " | ")[:200])
        # 4b. giapponese: il modello salta la parola, poi la dà con le chiavi cambiate → il pulsante funziona
        await hover(pg, "ja", "勉強", 9000)
        t = await card_text(pg)
        print("4b. giapponese:", t.replace("\n", " | ")[:120], "| frase mandata:", [x[2] for x in log["ipa"] if any("勉" in w for w in x[1])])
        box = await pg.locator(".pav-card").bounding_box()
        await pg.mouse.move(box["x"] + 20, box["y"] + 20, steps=3)
        btn = pg.get_by_text("Mostra la pronuncia IPA")
        print("    pulsante:", await btn.count())
        if await btn.count():
            await btn.click(); await pg.wait_for_timeout(9000)
        await pg.wait_for_timeout(1500)
        print("    cache:", await sw.evaluate("chrome.storage.local.get('ipaCache').then(r=>JSON.stringify(Object.fromEntries(Object.entries(r.ipaCache||{}).filter(([k])=>k.startsWith('ja')))))"))
        print("    richieste ja:", [x[1] for x in log["ipa"] if any(("勉" in w or "日" in w) for w in x[1])])
        print("    dopo il clic:", await pg.evaluate("(document.querySelector('.pav-word')||{}).textContent"), await pg.evaluate("(document.querySelector('.pav-card .pav-ipa')||{}).textContent"), "| nota:", await pg.evaluate("(document.querySelector('.pav-note')||{}).textContent"))
        await pg.keyboard.press("Escape")
        # 5. stella e Anki
        await hover(pg, "en", "bread", 2000)
        box = await pg.locator(".pav-card").bounding_box()
        await pg.mouse.move(box["x"] + 20, box["y"] + 20, steps=3); await pg.wait_for_timeout(300)
        await sw.evaluate("chrome.storage.sync.set({ankiAuto:true})"); await pg.wait_for_timeout(300)
        await pg.locator(".pav-star").click(); await pg.wait_for_timeout(1800)
        await sw.evaluate("chrome.storage.sync.set({ankiAuto:false})")
        v = await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab||{}))")
        print("5. vocabolario:", [(e["word"], e["ipa"], e["meaning"], e.get("anki")) for e in v])
        notes = [p for a, p in log["anki"] if a == "addNote"]
        print("   Anki:", [a for a, _ in log["anki"]], "| nota:", json.dumps(notes[0]["note"], ensure_ascii=False)[:300] if notes else None)
        # 6. spiegazione nel contesto con Gemini
        await pg.get_by_role("button", name="Spiega con Gemini").click(); await pg.wait_for_timeout(2000)
        print("6. spiegazione:", (await card_text(pg)).replace("\n", " | ")[:300])
        await pg.keyboard.press("Escape"); await pg.wait_for_timeout(300)
        print("   Esc chiude:", not await pg.evaluate("!!document.querySelector('.pav-card')"))
        # 7. selezione di due frasi: tradotte insieme
        b1 = await word_box(pg, "long", "The"); b2 = await word_box(pg, "long", "fire")
        await pg.mouse.move(b1["l"] + 1, b1["y"]); await pg.mouse.down(); await pg.mouse.move(b2["r"], b2["y"], steps=8); await pg.mouse.up()
        await pg.wait_for_timeout(2500)
        print("7. selezione:", (await card_text(pg)).replace("\n", " | ")[:400])
        await pg.get_by_text("Traduci meglio").click(); await pg.wait_for_timeout(2000)
        print("   meglio:", await pg.evaluate("(document.querySelector('.pav-trans')||{}).textContent"), "| a Gemini:", [x for x in log["gem"] if x[0] == "translate"])
        await pg.locator(".pav-star").click(); await pg.wait_for_timeout(500)
        # il pannello resta mentre muovi il mouse sulla pagina
        await pg.mouse.move(10, 300, steps=3); await pg.wait_for_timeout(1200)
        print("   resta aperto muovendo il mouse:", await pg.evaluate("!!document.querySelector('.pav-textcard')"))
        await pg.mouse.click(10, 10); await pg.wait_for_timeout(300)
        print("   clic fuori lo chiude:", not await pg.evaluate("!!document.querySelector('.pav-card')"))
        # 8. casella di testo: niente
        b = await pg.locator("#inp").bounding_box()
        await pg.mouse.move(b["x"] + 20, b["y"] + 8, steps=3); await pg.wait_for_timeout(1200)
        print("8. casella di testo: scheda", await pg.evaluate("!!document.querySelector('.pav-card')"))
        # 9. vocabolario e invio ad Anki delle voci non mandate
        vp = await ctx.new_page()
        ext_id = sw.url.split("/")[2]
        await vp.goto(f"chrome-extension://{ext_id}/vocab.html"); await vp.wait_for_timeout(800)
        print("9. vocabolario:", (await vp.inner_text("#count")), "|", [x.strip()[:60] for x in await vp.locator(".entry .word").all_inner_texts()])
        await vp.click("#send"); await vp.wait_for_timeout(1500)
        print("   manda ad Anki:", await vp.inner_text("#ankiMsg"))
        # 10. popup
        pp = await ctx.new_page(); perr = []
        pp.on("pageerror", lambda e: perr.append(str(e)))
        await pp.goto(f"chrome-extension://{ext_id}/{'popup-pagine.html' if __import__('os').path.exists(EXT + '/popup-pagine.html') else 'popup.html'}"); await pp.wait_for_timeout(800)
        await pp.click("#hover"); await pp.wait_for_timeout(500)
        await pp.click("#dAnki summary"); await pp.click("#ankiTest"); await pp.wait_for_timeout(1200)
        print("10. popup: lingue", await pp.locator("#targetLang option").count(), "| Anki:", await pp.inner_text("#ankiStatus"), "| errori", perr)
        await pg.bring_to_front()
        await hover(pg, "en", "walked", 1500)
        print("    modalità 'niente': scheda", await pg.evaluate("!!document.querySelector('.pav-card')"))
        # 11. interruttori: riaccendo il mouse, poi lo spengo dal pulsante dentro la scheda
        await sw.evaluate("chrome.storage.sync.set({mode:'hover', hover:true, selection:true})"); await pg.wait_for_timeout(500)
        await hover(pg, "en", "walked", 2000)
        box = await pg.locator(".pav-card").bounding_box()
        await pg.mouse.move(box["x"] + 20, box["y"] + 20, steps=3)
        await pg.get_by_text("Spegni la scheda al passaggio del mouse").click(); await pg.wait_for_timeout(500)
        print("11. spenta dalla scheda:", await sw.evaluate("chrome.storage.sync.get('hover').then(r=>r.hover)"), "| avviso:", await pg.evaluate("(document.querySelector('.pav-toast:not([hidden])')||{}).textContent"))
        await hover(pg, "en", "home", 1500)
        print("    passando il mouse: scheda", await pg.evaluate("!!document.querySelector('.pav-card')"))
        b = await word_box(pg, "en", "bread")
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        print("    doppio clic funziona ancora:", await pg.evaluate("(document.querySelector('.pav-word')||{}).textContent"))
        await pg.keyboard.press("Escape")
        # 12. traduzione quando evidenzi: spenta dal pannello
        b1 = await word_box(pg, "long", "The"); b2 = await word_box(pg, "long", "cold")
        await pg.mouse.move(b1["l"] + 1, b1["y"]); await pg.mouse.down(); await pg.mouse.move(b2["r"], b2["y"], steps=6); await pg.mouse.up(); await pg.wait_for_timeout(1500)
        await pg.get_by_text("Spegni la traduzione quando evidenzi").click(); await pg.wait_for_timeout(500)
        await pg.mouse.click(5, 5)
        await pg.mouse.move(b1["l"] + 1, b1["y"]); await pg.mouse.down(); await pg.mouse.move(b2["r"], b2["y"], steps=6); await pg.mouse.up(); await pg.wait_for_timeout(1500)
        print("12. selezione spenta:", await sw.evaluate("chrome.storage.sync.get('selection').then(r=>r.selection)"), "| pannello:", await pg.evaluate("!!document.querySelector('.pav-textcard')"))
        # 13. popup: interruttori in alto
        await pp.reload(); await pp.wait_for_timeout(800)
        print("13. popup: mouse", await pp.is_checked("#hover"), "| evidenzia", await pp.is_checked("#selection"), "| riga 'compare' nascosta:", await pp.evaluate("document.getElementById('modeRow').hidden"))
        await pp.click("#hover"); await pp.click("#selection"); await pp.wait_for_timeout(500)
        await pg.bring_to_front(); await hover(pg, "en", "home", 2000)
        print("    riaccesi dal popup: scheda", await pg.evaluate("!!document.querySelector('.pav-card')"))
        print("errori pagina:", errs, "| simulatore:", log["errors"])
        await ctx.close()
if __name__ == '__main__':
    asyncio.run(main())

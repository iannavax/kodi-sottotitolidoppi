// Etimologia delle parole (usata da Sottotitoli Doppi e da Parole al Volo).
// Fonte gratuita: Wiktionary in inglese (la pagina la scarica il background, qui si estrae la sezione
// "Etymology" della lingua giusta), poi tradotta con Google nella tua lingua. Se Wiktionary non la ha,
// si può chiedere a Gemini o Groq (solo premendo il pulsante). Tutto resta salvato: una parola, una volta.
var DS_ETYM = (() => {
  const cache = new Map();          // "lingua|parola|arrivo" → { text, trans, url, lemma, source } oppure { none, at }
  let saveTimer = 0;
  const ready = DS_EXT.storage.local.get({ etymCache: {} }).then((r) => {
    for (const [k, v] of Object.entries(r.etymCache || {})) if (!cache.has(k)) cache.set(k, v);
  }).catch(() => {});
  // le correzioni fatte da te si salvano subito (non dopo un attimo), così non si perdono ricaricando la pagina
  function saveNow() {
    clearTimeout(saveTimer);
    while (cache.size > 3000) cache.delete(cache.keys().next().value);
    return DS_EXT.storage.local.set({ etymCache: Object.fromEntries(cache) }).catch(() => {});
  }
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      while (cache.size > 3000) cache.delete(cache.keys().next().value);
      DS_EXT.storage.local.set({ etymCache: Object.fromEntries(cache) }).catch(() => {});
    }, 1500);
  }
  const base = (l) => { const b = String(l || "").split("-")[0].toLowerCase(); return ({ iw: "he", jw: "jv", in: "id", nb: "no", fil: "tl" })[b] || b; };

  // Nomi inglesi delle lingue come li usa Wiktionary per le sezioni ("Czech", "Norwegian Bokmål"…)
  function enNames(code) {
    const b = base(code);
    const extra = { no: ["Norwegian Bokmål", "Norwegian Nynorsk", "Norwegian"], zh: ["Chinese", "Mandarin"], he: ["Hebrew"], fa: ["Persian"],
      sr: ["Serbo-Croatian", "Serbian"], hr: ["Serbo-Croatian", "Croatian"], bs: ["Serbo-Croatian", "Bosnian"], ms: ["Malay"], tl: ["Tagalog"],
      el: ["Greek"], ar: ["Arabic"], ku: ["Kurdish", "Northern Kurdish"], ne: ["Nepali"] }[b] || [];
    let n = "";
    try { n = new Intl.DisplayNames(["en"], { type: "language" }).of(b) || ""; } catch {}
    return [...new Set([...extra, n].filter(Boolean))];
  }

  // Titolo e livello di un elemento se è un'intestazione (vecchio e nuovo HTML di MediaWiki)
  function heading(el) {
    let h = null;
    if (/^H[2-6]$/.test(el.tagName)) h = el;
    else if (el.classList && el.classList.contains("mw-heading")) h = el.querySelector("h2,h3,h4,h5,h6");
    if (!h) return null;
    const span = h.querySelector(".mw-headline");
    const text = (span || h).textContent.replace(/\[\s*edit\s*\]/gi, "").trim();
    return { level: Number(h.tagName[1]), text, id: (span && span.id) || h.id || "" };
  }
  const clean = (n) => {
    n.querySelectorAll("sup, .mw-editsection, style, script, .etymtree, .NavFrame, table, .maintenance-line").forEach((x) => x.remove());
    return n.textContent.replace(/\s+/g, " ").trim();
  };

  // Definizioni da un elenco numerato di Wiktionary (<ol><li>), in qualsiasi edizione: il testo della definizione
  // senza esempi, citazioni e sottoelenchi; il primo esempio a parte.
  const EX_SEL = ".h-usage-example, .e-example, [class*='example'], [class*='Example'], i.example";
  function defItem(li) {
    const exEl = li.querySelector(EX_SEL);
    const ex = exEl ? exEl.textContent.replace(/\s+/g, " ").replace(/^[◆▪•\s]+/, "").trim().slice(0, 200) : "";
    const x = li.cloneNode(true);
    x.querySelectorAll("ul, dl, ol, sup, .reference, style, script, table, .mw-editsection, .citation-whole, .cited-source, .HQToggle, .nyms, .synonym, .antonym, " + EX_SEL).forEach((n) => n.remove());
    const def = x.textContent.replace(/\s+/g, " ").replace(/^\s*\[?\d+\]?\s*/, "").replace(/\s+([,.;:])/g, "$1").replace(/[◆▪•]\s*$/, "").trim().slice(0, 300);
    return def.length > 1 && /\p{L}/u.test(def) ? { def, ex: ex !== def ? ex : "" } : null;
  }
  function defsOfList(ol) {
    if (!ol || ol.closest(".references, .mw-references-wrap, .reflist, .NavFrame, .navbox")) return [];
    if (ol.classList && ol.classList.contains("references")) return [];
    return [...ol.children].filter((li) => li.tagName === "LI").map(defItem).filter(Boolean);
  }
  const POS_EN = /^(noun|proper noun|verb|adjective|adverb|pronoun|preposition|conjunction|interjection|particle|numeral|determiner|article|participle|postposition|phrase|prepositional phrase|proverb|idiom|classifier|counter|suffix|prefix|letter|contraction)\b/i;

  // Dalla pagina, nella sezione della lingua: il paragrafo "Etymology", il lemma se è una forma flessa, l'audio
  // registrato (madrelingua), il genere del nome, la prima tabella di coniugazione o declinazione
  function tableRows(t) {
    const rows = [];
    for (const r of [...t.rows].slice(0, 40)) {
      const cells = [...r.cells].slice(0, 12).map((c) => {
        // la traslitterazione in alfabeto latino (Wiktionary la mette in .tr dentro la cella) va tenuta a parte,
        // altrimenti si attacca alla parola: "исто́чникistóčnik"
        const x = c.cloneNode(true);
        x.querySelectorAll("sup, .mw-editsection, style, script").forEach((n) => n.remove());
        const trEls = [...x.querySelectorAll(".tr, [lang$='-Latn'], .mention-tr")];
        const tr = trEls.map((n) => n.textContent.replace(/\s+/g, " ").trim()).filter(Boolean);
        trEls.forEach((n) => n.remove());
        x.querySelectorAll("br").forEach((n) => n.replaceWith(", "));
        const t = x.textContent.replace(/\s+/g, " ").replace(/(,\s*)+/g, ", ").replace(/^[,\s]+|[,\s]+$/g, "").trim();
        return { t: t.slice(0, 60), tr: [...new Set(tr)].join(", ").slice(0, 60), h: c.tagName === "TH", cs: Math.min(c.colSpan || 1, 12), rs: Math.min(c.rowSpan || 1, 40) };
      });
      if (cells.some((c) => c.t || c.tr)) rows.push(cells);
    }
    return rows.length >= 2 ? rows : null;
  }
  // Registrazioni in un pezzo di pagina: <audio> con le sue <source> (meglio l'mp3, che tutti i browser leggono),
  // altrimenti il nome del file (data-mwtitle, o un collegamento "File:…ogg/wav/mp3"), scaricato da Commons
  const AUDIO_EXT = /\.(ogg|oga|opus|wav|mp3|flac|m4a|webm)$/i;
  const filePath = (name) => "https://commons.wikimedia.org/wiki/Special:FilePath/" + encodeURIComponent(String(name).replace(/^(File|Fichier|Datei|Файл|Soubor|Plik|Archivo|File|Bestand|Fil):/i, "").replace(/ /g, "_"));
  function audioIn(el) {
    const out = [];
    for (const a of (el.matches && el.matches("audio") ? [el] : []).concat([...el.querySelectorAll("audio")])) {
      const srcs = [...a.querySelectorAll("source[src]")].map((x) => ({ src: x.getAttribute("src"), type: x.getAttribute("type") || "" }));
      if (a.getAttribute("src")) srcs.push({ src: a.getAttribute("src"), type: "" });
      const pick = srcs.find((x) => /mpeg|mp3/.test(x.type + x.src)) || srcs.find((x) => /ogg|vorbis|opus/.test(x.type + x.src)) || srcs[0];
      if (pick && pick.src) out.push(pick.src.replace(/^\/\//, "https://"));
      else if (a.getAttribute("data-mwtitle")) out.push(filePath(a.getAttribute("data-mwtitle")));
      if (out.length) return out;
    }
    for (const l of el.querySelectorAll("a[href]")) {
      const h = decodeURIComponent(l.getAttribute("href") || "");
      const m = h.match(/(?:\/wiki\/|title=)((?:[^/:?#&]+):[^?#&]+)$/);
      if (m && AUDIO_EXT.test(m[1])) return [filePath(m[1])];
      if (/upload\.wikimedia\.org\/.+\.(ogg|oga|opus|wav|mp3|flac)$/i.test(h)) return [h.replace(/^\/\//, "https://")];
    }
    return [];
  }

  // section: nome della sezione di Wiktionary da leggere ("Portuguese"), quando si segue un'etimologia in un'altra lingua
  // Albero etimologico di Wiktionary ({{etymon}}/«Etymology tree»: elenchi annidati dentro .etymtree): diventa
  // [{ text, kids: [...] }] — dalla radice più antica fino alla parola
  // L'albero di {{etymon|…|tree=1}} (Wiktionary, dal 2024): caselle .etytree-block una sotto l'altra dentro le
  // colonne .etytree-branch; le colonne di un .etytree-branch-group si uniscono nella casella che viene dopo (le parti
  // di una parola composta: embarazar + -ado → embarazado). L'etichetta di una casella (abbr: «loanword», «derived
  // terms», «learned borrowing»…) dice come la casella sotto viene da questa; senza etichetta: ereditata (o, nella stessa
  // lingua, semplicemente «da»). Le caselle .etytree-duplicate ripetono una parola già nell'albero (senza i suoi antenati).
  // Risultato: { ety: nodo della parola } con nodo = { lang, code, term, tr, gloss, rel, unc, dup, parents: [nodi] }.
  function parseEtytree(root) {
    const body = root.querySelector(".etytree-body");
    if (!body) return null;
    let count = 0;
    const block = (b) => {
      const t = b.querySelector(".etytree-term");
      if (!t) return null;   // casella vuota (solo per disegnare l'unione)
      const m = t.querySelector("[lang]:not(.mention-tr):not(.tr)") || t.querySelector("strong, b") || t;
      const labBox = b.querySelector(".etytree-label");
      const lab = labBox && (labBox.querySelector("abbr[title]") || labBox);
      const g = t.querySelector(".mention-gloss");
      const tr = t.querySelector(".mention-tr, .tr");
      count++;
      return {
        lang: ((b.querySelector(".etyl") || {}).textContent || "").trim(),
        code: (m.getAttribute && m.getAttribute("lang")) || "",
        term: (m.textContent || "").replace(/\s+/g, " ").trim(),
        tr: tr ? tr.textContent.trim() : "",
        gloss: g ? g.textContent.trim() : "",
        rel: lab ? (lab.getAttribute("title") || lab.textContent || "").trim() : "",
        unc: !!b.querySelector(".etytree-unc"),
        dup: b.classList.contains("etytree-duplicate"),
        self: !!t.querySelector(".selflink"),
        parents: []
      };
    };
    const seq = (box, depth) => {
      let cur = [];
      for (const ch of box.children) {
        if (count > 150 || depth > 30) break;
        if (ch.classList.contains("etytree-block")) {
          const n = block(ch);
          if (n) { n.parents = cur; cur = [n]; }
        } else if (ch.classList.contains("etytree-branch-group")) {
          cur = [...ch.children].filter((b) => b.classList.contains("etytree-branch")).map((b) => seq(b, depth + 1)).filter(Boolean);
        }
      }
      return cur.length === 1 ? cur[0] : cur.length ? { term: "", parents: cur, merge: true } : null;
    };
    const top = seq(body, 0);
    return top && top.term ? { ety: top } : null;
  }
  // Lo stesso albero come dati: {{etymon}} mette nella pagina <ul class="etymonid" data-ety-tree-json="…"> (c'è anche
  // senza il disegno). Ogni parola: { term, alt, lang, lang_name, transliteration, gloss, is_duplicate, children: [gruppi] };
  // ogni gruppo: { keyword (bor, inherited, derived, from, affix, influence, lbor…), is_group, is_uncertain, is_invisible,
  // terms: [parole da cui viene] }. Le parti di un composto sono i terms di un gruppo «affix»; «influence» (e simili) non è
  // un antenato ma un'influenza: va a parte. «root» e «afeq» sono nascosti anche su Wiktionary.
  const ETY_SIDE = new Set(["influence", "contamination"]);
  const ETY_PARTS = new Set(["affix", "af", "blend", "sa-af", "vrd-af", "compound"]);
  function etyFromJson(ul) {
    let d;
    try { d = JSON.parse(ul.getAttribute("data-ety-tree-json") || ""); } catch { return null; }
    if (!d || typeof d !== "object") return null;
    let count = 0;
    const conv = (t, depth) => {
      count++;
      const n = { lang: t.lang_name || "", code: t.lang || "", term: t.alt || t.term || "", tr: t.transliteration || "", gloss: t.gloss || "",
        dup: !!t.is_duplicate, parents: [], side: [], parts: false };
      if (depth > 30 || count > 250) return n;
      for (const g of t.children || []) {
        const kw = String(g.keyword || "from");
        if (g.is_invisible || kw === "root" || kw === "afeq") continue;
        const ps = (g.terms || []).map((x) => conv(x, depth + 1));
        for (const p of ps) { p.rel = kw; if (g.is_uncertain) p.unc = true; }
        if (ETY_SIDE.has(kw)) n.side.push(...ps);
        else { n.parents.push(...ps); if (ETY_PARTS.has(kw) || (g.is_group && ps.length > 1)) n.parts = true; }
      }
      return n;
    };
    const root = conv({ ...d, term: ul.getAttribute("data-title") || d.term || "", lang: ul.getAttribute("data-lang") || d.lang || "" }, 0);
    root.self = true;
    return root.parents.length || root.side.length ? { ety: root } : null;
  }
  function parseTree(root) {
    if (root.matches && root.matches("[data-ety-tree-json]")) return etyFromJson(root);
    if (root.querySelector(".etytree-body")) return parseEtytree(root);
    const ul = root.querySelector("ul, ol");
    if (!ul) {
      const lines = root.textContent.split(/\n+/).map((x) => x.replace(/\s+/g, " ").trim()).filter((x) => x && !/^etymology tree$/i.test(x));
      return lines.length >= 2 ? lines.slice(0, 20).map((text) => ({ text, kids: [] })) : null;
    }
    let n = 0;
    const walk = (list, depth) => [...list.children].filter((li) => li.tagName === "LI").slice(0, 12).map((li) => {
      const x = li.cloneNode(true);
      x.querySelectorAll("ul, ol, sup, .mw-editsection, style, script").forEach((k) => k.remove());
      const text = x.textContent.replace(/\s+/g, " ").trim();
      const sub = [...li.children].find((k) => k.tagName === "UL" || k.tagName === "OL");
      n++;
      return { text, kids: sub && depth < 12 && n < 80 ? walk(sub, depth + 1) : [] };
    }).filter((it) => it.text || it.kids.length);
    const t = walk(ul, 0);
    return t.length ? t : null;
  }
  // Catena dell'etimologia dal testo di Wiktionary: «From Middle English breed, from Old English brēad, from
  // Proto-Germanic *braudą. Cognate with German Brot» → antenati [{lang, term, gloss}] (dal più recente al più antico)
  // e parenti (cognate, compare, doublet). Le parole citate hanno l'attributo lang; la lingua è il nome scritto prima.
  function etyChain(p, lang, chain) {
    const ments = [...p.querySelectorAll("[lang]")].filter((m) => {
      const l = (m.getAttribute("lang") || "").toLowerCase();
      if (!l || m.closest(".mention-gloss, .mention-gloss-paren, .mention-tr, sup")) return false;
      if (/^en(-|$)/.test(l) && base(lang) === "en") return false;   // parole inglesi nel testo inglese
      const outer = m.parentElement && m.parentElement.closest("[lang]");
      return !(outer && !/^en(-|$)/.test(outer.getAttribute("lang") || ""));   // non dentro un'altra parola citata
    });
    // il testo fra due parole citate, senza traslitterazioni e significati tra parentesi o virgolette
    const between = (a, b) => {
      const r = document.createRange();
      if (a) r.setStartAfter(a); else r.setStart(p, 0);
      if (b) r.setEndBefore(b); else r.setEnd(p, p.childNodes.length);
      return r.toString().replace(/\([^)]*\)/g, "").replace(/[“"«][^”"»]*[”"»]/g, "").replace(/\s+/g, " ").trim();
    };
    const first = chain.length;
    for (let i = 0; i < ments.length; i++) {
      const m = ments[i];
      const term = m.textContent.replace(/\s+/g, " ").trim();
      if (!term || term.length > 60 || chain.some((c) => c.term === term)) continue;
      const r = document.createRange();
      r.setStart(p, 0); r.setEndBefore(m);
      const before = r.toString().replace(/\s+/g, " ");
      const sents = before.split(/[.;]\s/);
      const sentence = sents.pop();
      const kin = /cognat|compare|doublet|related to|see also|akin to|parallel/i.test(sentence);
      // pezzi della parola («на- + -чина́ть», «pa + rola», prefissi e suffissi): dicono come è fatta, non da dove
      // viene. Non sono antenati: nell'albero vanno sotto la parola che compongono (quella della stessa frase
      // prima di loro, altrimenti la parola della pagina)
      const part = !kin && (/^\*?-|-$/.test(term) || /\+$/.test(between(ments[i - 1], m)) || /^\+/.test(between(m, ments[i + 1])));
      const lm = /((?:[A-Z][\w'-]*|of|the)(?:[ -](?:[A-Z][\w'-]*|Proto|Old|Middle))*)\s*$/.exec(before.trimEnd().replace(/[,(:]\s*$/, ""));
      let lname = lm ? lm[1].replace(/^(?:of|the)\s+/i, "") : "";
      if (!/^[A-Z]/.test(lname) || /^(From|Borrowed|Inherited|Learned|Compare|Cognate|Doublet|See|Akin|Related|Equivalent|Calque|Semantic|Ultimately|Possibly|Probably|Perhaps)$/.test(lname)) {
        try { lname = new Intl.DisplayNames(["en"], { type: "language" }).of((m.getAttribute("lang") || "").split("-")[0]) || ""; } catch { lname = ""; }
      }
      lname = lname.replace(/^(?:From|Borrowed from|Inherited from|Compare|Cognate with)\s+/i, "");
      // significato tra parentesi subito dopo la parola («“fragment, morsel”»): il primo .mention-gloss che segue
      let g = "", n = m.nextElementSibling;
      for (let k = 0; n && k < 5 && !n.matches("[lang]"); k++, n = n.nextElementSibling) {
        if (n.classList.contains("mention-gloss")) { g = n.textContent.trim(); break; }
        const inner = n.querySelector && n.querySelector(".mention-gloss");
        if (inner) { g = inner.textContent.trim(); break; }
      }
      let of = "";
      if (part) {
        const owner = chain.slice(first).reverse().find((c) => !c.kin && !c.part && c.sent === sents.length);
        of = owner ? owner.term : "";
      }
      chain.push({ lang: lname, term, gloss: g, kin, part, of, sent: sents.length });
      if (chain.length >= 16) break;
    }
  }
  // l'albero dalla catena: dalla radice più antica giù fino alla parola; i parenti come ramo a parte
  function chainTree(chain, word, lang) {
    const anc = chain.filter((c) => !c.kin && !c.part && !c.via), kin = chain.filter((c) => c.kin), parts = chain.filter((c) => c.part);
    if (!anc.length && !parts.length) return null;
    let lname = "";
    try { lname = new Intl.DisplayNames(["en"], { type: "language" }).of(base(lang)) || ""; } catch {}
    const label = (c) => (c.lang ? c.lang + " " : "") + c.term + (c.gloss ? " «" + c.gloss + "»" : "");
    // i pezzi di ogni parola dell'albero: «formata da: на- + -чина́ть»
    const used = new Set();
    const partsOf = (term, leaf) => {
      const ps = parts.filter((c) => !used.has(c) && (formKey(c.of) === formKey(term) || (leaf && !anc.some((a) => formKey(a.term) === formKey(c.of)))));
      ps.forEach((c) => used.add(c));
      // con l'origine del pezzo, se Wiktionary la dà: «baraço (← Old Galician-Portuguese … ← Arabic مَرَسَة)»
      const from = (c) => { const v = chain.filter((d) => d.via === c.term); return v.length ? " (← " + v.map(label).join(" ← ") + ")" : ""; };
      return ps.length ? [{ text: "formata da: " + ps.map((c) => c.term + (c.gloss ? " «" + c.gloss + "»" : "") + from(c)).join(" + "), kids: [], parts: true }] : [];
    };
    let node = { text: (lname ? lname + " " : "") + word, kids: [] };
    node.kids = partsOf(word, false);
    for (const c of anc) { const kids = partsOf(c.term, false); node = { text: label(c), kids: [node, ...kids] }; }
    // pezzi rimasti (di nessuna parola dell'albero): sotto la parola
    const rest = partsOf("", true);
    if (rest.length) { let leaf = node; while (leaf.kids.length && !leaf.kids[0].parts) leaf = leaf.kids[0]; leaf.kids.push(...rest); }
    if (kin.length) node.kids.push({ text: "parenti: " + kin.map(label).join(", "), kids: [] });
    return [node];
  }
  // forma senza accenti tonici (подо́шве = подошве) e in minuscolo, per confrontare le parole delle tabelle
  const formKey = (w) => String(w || "").normalize("NFD").replace(/[\u0300\u0301]/g, "").normalize("NFC").toLowerCase().replace(/^[^\p{L}]+|[^\p{L}]+$/gu, "");
  function extract(html, lang, section) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const root = doc.querySelector(".mw-parser-output") || doc.body;
    const names = section ? [String(section).toLowerCase()] : lang ? enNames(lang).map((x) => x.toLowerCase()) : [];
    const kids = [...root.children];
    let inLang = false, seenLang = false, inEty = false, etyLevel = 0, etyDone = false;
    const parts = [], marked = [], mentions = [];
    const out = { text: "", lemma: "", audio: [], gender: "", table: null, exists: false, ipa: "", defs: [], etyLinks: [], forms: new Set(), wtree: null, chain: [] };
    let pos = "";
    for (const el of kids) {
      const h = heading(el);
      if (h) {
        if (h.level === 2) {
          if (seenLang) break;   // finita la sezione della lingua
          const t = (h.text || h.id.replace(/_/g, " ")).toLowerCase();
          inLang = !names.length || names.some((n) => t === n || t.startsWith(n));
          if (inLang) { seenLang = true; out.exists = true; }
          inEty = false;
          continue;
        }
        if (!inLang) continue;
        if (inEty && h.level <= etyLevel) { inEty = false; if (parts.length) etyDone = true; }
        if (/^etymology/i.test(h.text) && !etyDone && !parts.length) { inEty = true; etyLevel = h.level; }
        pos = POS_EN.test(h.text) ? h.text.replace(/\s*\d+$/, "") : "";
        continue;
      }
      if (!inLang || !el.querySelector) continue;
      // l'albero etimologico (prima che la pulizia del testo lo tolga)
      if (!out.wtree || !out.wtreeJson) {
        // prima i dati (ul.etymonid con data-ety-tree-json: precisi, ci sono anche senza disegno), poi il disegno
        const JSEL = "[data-ety-tree-json]";
        const SEL = ".etymtree, .etymon-tree, .etytree, [class*='etymtree'], [class*='etymon-tree']";
        let tr = el.matches && el.matches(JSEL) ? el : el.querySelector(JSEL);
        if (tr && !etyFromJson(tr)) tr = null;
        if (!tr) tr = el.matches && el.matches(SEL) ? el : el.querySelector(SEL);
        // «Etymology tree» in un riquadro richiudibile (NavFrame) senza classe sua
        if (!tr) { const nh = [...el.querySelectorAll(".NavHead")].find((h) => /etymology tree/i.test(h.textContent)); if (nh) tr = nh.closest(".NavFrame"); }
        if (tr && tr.matches(JSEL)) { out.wtree = etyFromJson(tr); out.wtreeJson = true; }
        else if (tr && !out.wtree) out.wtree = parseTree(tr);
      }
      if (inEty && el.tagName === "P") {
        etyChain(el, lang, out.chain);
        // parole citate nell'etimologia, con la loro lingua ("Past participle of embarazar", "Borrowed from Portuguese
        // embaraçar"): si possono seguire per arrivare alla radice. Niente prefissi e suffissi (em-, -ado).
        for (const a of el.querySelectorAll("a[href]")) {
          const m = (a.getAttribute("href") || "").match(/^(?:\/wiki\/|\.\/)([^#?]+)(?:#(.+))?$/);
          if (!m) continue;
          const t = decodeURIComponent(m[1]).replace(/_/g, " ");
          if (/:/.test(t) || /^-|-$/.test(t) || out.etyLinks.some((x) => x.t === t)) continue;
          let sec = decodeURIComponent(m[2] || "").replace(/_/g, " ");
          const l = (a.closest("[lang]") && a.closest("[lang]").getAttribute("lang") || "").toLowerCase();
          if (!sec && l && lang && base(l) === base(lang)) sec = names[0] || "";
          if (!sec || /^etymology/i.test(sec)) continue;
          out.etyLinks.push({ t, sec });
        }
        const x = el.cloneNode(true);
        const t = clean(x.cloneNode(true));
        // le parole straniere citate (<i lang="cs">ten</i>) non vanno tradotte: le sostituisco con ⟦n⟧
        x.querySelectorAll("[lang]").forEach((m) => {
          const l = String(m.getAttribute("lang") || "").toLowerCase();
          if (!l || l === "en" || l.startsWith("en-") || m.closest(".mention-gloss")) return;
          if (m.parentElement && m.parentElement.closest("[lang]") && m.parentElement.closest("[lang]") !== m && !/^en/.test(m.parentElement.closest("[lang]").getAttribute("lang") || "")) return;
          const txt = m.textContent.replace(/\s+/g, " ").trim();
          if (!txt) return;
          mentions.push(txt);
          m.replaceWith(" ⟦" + (mentions.length - 1) + "⟧ ");
        });
        const tm = clean(x);
        if (t) { parts.push(t); marked.push(tm); }
      }
      if (el.tagName === "OL" && pos && out.defs.length < 4) {   // definizioni in inglese (stessa pagina, nessuna richiesta in più)
        const items = defsOfList(el).slice(0, 4);
        const g = out.defs.find((x) => x.pos === pos);
        if (g) g.items.push(...items); else if (items.length) out.defs.push({ pos, items });
      }
      if (!out.lemma) {
        // la parola madre: il collegamento del «form of», non quelli al glossario («past participle» → Appendix:Glossary)
        const ok = (x) => !/^(Appendix|Wiktionary|Category|Help|Template|Wikipedia|w|Thesaurus|Rhymes|Reconstruction):/i.test(x.getAttribute("title") || "");
        const a = [...el.querySelectorAll(".form-of-definition-link a[title]")].find(ok) || [...el.querySelectorAll(".form-of-definition a[title]")].find(ok);
        if (a) out.lemma = a.getAttribute("title").replace(/#.*$/, "");
      }
      if (!out.audio.length) out.audio = audioIn(el);
      if (!out.ipa) {   // pronuncia IPA (la prima trascrizione /…/ della sezione, altrimenti […])
        const all = [...el.querySelectorAll(".IPA")].map((x) => x.textContent.trim()).filter((t) => /^[\/\[].+[\/\]]$/.test(t));
        const pick = all.find((t) => t.startsWith("/")) || all[0];
        if (pick) out.ipa = pick.replace(/^[\/\[]\s*|\s*[\/\]]$/g, "").trim();
      }
      if (!out.gender) {
        const g = el.querySelector(".headword-line .gender abbr, span.gender abbr") || el.querySelector(".headword-line .gender, span.gender");
        if (g) out.gender = (g.getAttribute("title") || g.textContent || "").trim();
      }
      if (!out.table) {
        const t = el.tagName === "TABLE" ? el : el.querySelector("table.inflection-table, .NavFrame table, table.wikitable, table");
        if (t && !el.closest("p")) out.table = tableRows(t);
      }
      // tutte le forme delle tabelle (declinazioni, coniugazioni): servono a verificare il lemma
      for (const t of el.tagName === "TABLE" ? [el] : el.querySelectorAll("table")) {
        for (const cell of t.querySelectorAll("td, th")) {
          for (const f of cell.textContent.split(/[\s,;/()]+/)) { const n = formKey(f); if (n) out.forms.add(n); }
        }
      }
    }
    out.text = parts.join(" ").slice(0, 800);
    out.marked = marked.join(" ").replace(/\s+/g, " ").replace(/\s+([,.;:)])/g, "$1").slice(0, 900);
    out.mentions = mentions;
    return out;
  }

  // traduce l'etimologia (inglese) nella tua lingua, lasciando com'erano le parole straniere citate
  // (prima "ten" in ceco diventava "dieci"). Se Google perde un segnaposto, rifaccio senza.
  async function translate(text, target, marked, mentions, src) {
    const from = base(src) || "en";
    if (!text || base(target) === from) return text;
    const g = async (t) => {
      const r = await DS_EXT.runtime.sendMessage({ type: "translate", engine: "google", texts: [t], target, source: from });
      return (r && r.translations && r.translations[0]) || "";
    };
    try {
      if (marked && mentions && mentions.length) {
        const tr = await g(marked);
        const seen = new Set();
        const out = tr.replace(/[⟦⟧\[]\s*(\d+)\s*[⟦⟧\]]/g, (all, n) => { const m = mentions[+n]; if (m == null) return all; seen.add(+n); return m; });
        if (tr && seen.size === mentions.length) return out.replace(/\s+([,.;:)])/g, "$1").replace(/\(\s+/g, "(");
      }
      return (await g(text)) || text;
    } catch { return text; }
  }

  // { text (inglese), trans (nella tua lingua), url, lemma, source, audio, gender, table, exists } — none: senza etimologia
  // Parola madre scelta da te (⚑ → «lemma sbagliato?»): "lingua|parola" → lemma, "-" = nessuna
  let bases = {};
  const basesReady = DS_EXT.storage.local.get({ etymBase: {} }).then((r) => { bases = r.etymBase || {}; }).catch(() => {});
  const baseKey = (word, lang) => (base(lang) || "?") + "|" + String(word || "").toLowerCase();
  async function setBase(word, lang, target, b) {
    await basesReady;
    const k = baseKey(word, lang);
    b = String(b || "").trim();
    if (b) bases[k] = b; else delete bases[k];
    await DS_EXT.storage.local.set({ etymBase: bases }).catch(() => {});
    const key = [base(lang) || "?", String(word).toLowerCase(), base(target)].join("|");
    const c = cache.get(key);
    if (c && !c.fixed) cache.delete(key);
    return get(word, lang, target);
  }
  // Parola madre di una forma senza pagina sua (подошве → подошва, cantavamo → cantare): la cerco su Wiktionary e la
  // prendo solo se la forma è davvero nella sua tabella (declinazione, coniugazione). Così è sicura.
  // Ricerca a mano (pulsante «🔍 cerca radice»): le pagine che contengono la forma, le parole suggerite (lemma del
  // modello, «vedi anche» di Google) e quelle che cominciano con la stessa radice (cantavamo → cantav…, canta…).
  // Per ognuna: se la forma è nella sua tabella (sicura), se ha un'etimologia, e quanto è vicina (radice in comune).
  // Prima le sicure, poi le più vicine con un'etimologia.
  const commonPrefix = (a, b) => { let i = 0; while (i < a.length && i < b.length && a[i] === b[i]) i++; return i; };
  async function searchBases(word, lang, extra) {
    const want = formKey(word);
    const titles = [];
    const add = (list) => { for (const t of list || []) if (t && formKey(t) !== want && !/:/.test(t) && !titles.includes(t)) titles.push(t); };
    add((extra || []).filter(Boolean));
    let r, err = "";
    try { r = await DS_EXT.runtime.sendMessage({ type: "wiktSearch", q: word, limit: 10 }); if (r && r.error) err = r.error; else add(r && r.titles); } catch (e) { err = String(e.message || e); }
    // la radice: tolgo da 1 a 4 lettere dalla fine (almeno 3 restano)
    const letters = Array.from(word);
    for (let cut = 1; cut <= 4 && letters.length - cut >= 3; cut++) {
      try { const p = await DS_EXT.runtime.sendMessage({ type: "wiktSearch", q: letters.slice(0, letters.length - cut).join(""), prefix: true, limit: 8 }); add(p && p.titles); } catch {}
      if (titles.length >= 24) break;
    }
    if (!titles.length && err) return { error: err };
    const out = await Promise.all(titles.slice(0, 24).map(async (t) => {
      try {
        const page = await DS_EXT.runtime.sendMessage({ type: "etymPage", word: t });
        if (!page || !page.html) return null;
        const x = extract(page.html, lang);
        if (!x.exists) return null;
        const k = formKey(page.title || t);
        return { title: page.title || t, sure: x.forms.has(want), etym: !!x.text, model: (extra || []).includes(t),
          near: commonPrefix(k, want) / Math.max(k.length, want.length) };
      } catch { return null; }
    }));
    const list = out.filter(Boolean).filter((c) => c.sure || c.model || c.near >= 0.5 || c.etym);
    list.sort((a, b) => (b.sure - a.sure) || ((b.etym && b.near >= 0.5) - (a.etym && a.near >= 0.5)) || (b.near - a.near) || (b.etym - a.etym));
    return { list: list.slice(0, 12) };
  }
  async function findBase(word, lang) {
    let r;
    try { r = await DS_EXT.runtime.sendMessage({ type: "wiktSearch", q: word }); } catch { return null; }
    const want = formKey(word);
    for (const t of ((r && r.titles) || []).filter((t) => formKey(t) !== want && !/:/.test(t)).slice(0, 4)) {
      let page;
      try { page = await DS_EXT.runtime.sendMessage({ type: "etymPage", word: t }); } catch { continue; }
      if (!page || !page.html) continue;
      const x = extract(page.html, lang);
      if (x.exists && x.forms.has(want)) return { title: page.title || t, x };
    }
    return null;
  }

  async function get(word, lang, target, lemmaHint) {
    await ready; await basesReady;
    word = String(word || "").trim();
    if (!word) return { none: true };
    const key = [base(lang) || "?", word.toLowerCase(), base(target)].join("|");
    const c = cache.get(key);
    if (c && c.fixed) return c;
    if (c && c.tv === 11 && !(c.none && Date.now() - (c.at || 0) > 7 * 86400e3)) return c;
    const mine = bases[baseKey(word, lang)];   // scelta da te: vince su tutto
    const titles = [word];
    if (word.toLowerCase() !== word) titles.push(word.toLowerCase());
    // come è stata trovata il lemma: "forma" (Wiktionary: «forma di…»), "tabella" (nella sua tabella),
    // "modello" (dalla spiegazione del modello), "tu" (scelta da te)
    const how = {};
    if (mine && mine !== "-") { titles.push(mine); how[mine] = "tu"; }
    else if (!mine && lemmaHint && !titles.includes(lemmaHint)) { titles.push(lemmaHint); how[lemmaHint] = "modello"; }
    const info = { text: "", marked: "", mentions: [], etyLinks: [], chain: [], wtree: null, wtreeTitle: "", lemma: "", audio: [], audioTitle: "", ipa: "", ipaTitle: "", gender: "", table: null, exists: false, title: "", textTitle: "", defs: [], defsTitle: "" };
    for (let i = 0; i < titles.length && i < 5; i++) {
      const t = titles[i];
      let page;
      try { page = await DS_EXT.runtime.sendMessage({ type: "etymPage", word: t }); } catch (e) { return { error: String(e.message || e) }; }
      if (!page || page.error) return { error: (page && page.error) || "Wiktionary non risponde" };
      if (!page.html) continue;
      const x = extract(page.html, lang);
      if (!x.exists) continue;
      const title = page.title || t;
      if (!info.exists) { info.exists = true; info.title = title; }
      if (!info.text && x.text) { info.text = x.text; info.textTitle = title; info.marked = x.marked; info.mentions = x.mentions; info.etyLinks = x.etyLinks; info.chain = x.chain.slice(); }
      if (!info.audio.length && x.audio.length) { info.audio = x.audio; info.audioTitle = title; }
      if (!info.ipa && x.ipa) { info.ipa = x.ipa; info.ipaTitle = title; }   // anche questa vale solo per la sua pagina
      if (!info.gender && x.gender) info.gender = x.gender;
      if (!info.defs.length && x.defs.length) { info.defs = x.defs; info.defsTitle = title; }
      if (!info.table && x.table) { info.table = x.table; info.tableTitle = title; }
      if (!info.wtree && x.wtree) { info.wtree = x.wtree; info.wtreeTitle = title; }
      if (!mine && x.lemma && !titles.includes(x.lemma)) { titles.splice(i + 1, 0, x.lemma); how[x.lemma] = "forma"; if (!info.lemma) info.lemma = x.lemma; }
      if (info.text && info.table) break;
      if (info.text && !x.lemma) break;
    }
    // Etimologia che rimanda solo a un'altra parola della stessa lingua ("Past participle of embarazar", "Feminine of
    // embarazado", "From embarazar + -ada"): seguo il rimando (fino a 3 passi) e aggiungo la sua etimologia, che di
    // solito arriva alla radice vera (embarazar ← portoghese embaraçar ← baraço, "corda"). Così non serve il modello.
    // Etimologia corta che rimanda a un'altra parola ("Past participle of embarazar", "Feminine of embarazado", "Borrowed
    // from Portuguese embaraçar, from baraço"): seguo il rimando, anche in un'altra lingua, fino a 3 passi, e aggiungo
    // ogni pezzo nuovo. Vale per tutte le parole: la catena arriva alla radice senza chiedere al modello.
    // nessuna etimologia e nessuna «forma di…»: cerco il lemma nelle tabelle di Wiktionary
    if (!info.text && !mine && !info.lemma) {
      const f = await findBase(word, lang);
      if (f) {
        const { x, title } = f;
        how[title] = "tabella";
        if (!info.exists) { info.exists = true; info.title = title; }
        if (x.text) { info.text = x.text; info.textTitle = title; info.marked = x.marked; info.mentions = x.mentions; info.etyLinks = x.etyLinks; info.chain = x.chain.slice(); }
        if (!info.table && x.table) { info.table = x.table; info.tableTitle = title; }
        if (!info.wtree && x.wtree) { info.wtree = x.wtree; info.wtreeTitle = title; }
        if (!info.audio.length && x.audio.length) { info.audio = x.audio; info.audioTitle = title; }   // registrazione del lemma
        if (!info.gender && x.gender) info.gender = x.gender;
        if (!info.defs.length && x.defs.length) { info.defs = x.defs; info.defsTitle = title; }
        info.lemma = title;
      }
    }
    const seen = new Set(titles.map((t) => t.toLowerCase()));
    let links = info.etyLinks || [], hops = 0, lastLen = info.text.length;
    while (info.text && lastLen < 220 && info.text.length < 900 && links.length && hops < 3) {
      const next = links.find((x) => !seen.has((x.sec + "|" + x.t).toLowerCase()) && !seen.has(x.t.toLowerCase()));
      if (!next) break;
      seen.add((next.sec + "|" + next.t).toLowerCase()); hops++;
      let pg;
      try { pg = await DS_EXT.runtime.sendMessage({ type: "etymPage", word: next.t }); } catch { break; }
      if (!pg || !pg.html) break;
      const x = extract(pg.html, null, next.sec);
      if (!x.text) break;
      // niente di nuovo (la pagina ripete quello che c'è già): mi fermo
      const fresh = x.mentions.filter((m) => !info.mentions.includes(m) && m !== next.t);
      if (!fresh.length && info.text.includes(x.text.slice(0, 40))) break;
      const off = info.mentions.length;
      info.text += " " + (next.sec && !new RegExp("^" + next.sec, "i").test(x.text) && (!lang || !enNames(lang).includes(next.sec)) ? next.sec + " " + next.t + ": " : "") + x.text;
      info.marked += " " + (next.sec && (!lang || !enNames(lang).includes(next.sec)) ? next.sec + " ⟦" + (off + x.mentions.length) + "⟧: " : "") + x.marked.replace(/⟦(\d+)⟧/g, (a, n) => "⟦" + (+n + off) + "⟧");
      info.mentions = info.mentions.concat(x.mentions);
      // i pezzi senza padrone sono della parola di quella pagina
      // la pagina di un pezzo (baraço in em- + baraço): i suoi antenati sono del pezzo, non della parola intera
      const ofPart = info.chain.find((d) => d.part && formKey(d.term) === formKey(pg.title || next.t));
      for (const c of x.chain) {
        if (info.chain.some((d) => d.term === c.term)) continue;
        if (ofPart && !c.kin) { info.chain.push({ ...c, part: false, via: ofPart.term }); continue; }
        info.chain.push(c.part && !c.of ? { ...c, of: pg.title || next.t } : c);
      }
      if (!info.wtree && x.wtree) { info.wtree = x.wtree; info.wtreeTitle = pg.title || next.t; }
      if (next.sec && (!lang || !enNames(lang).includes(next.sec))) info.mentions.push(next.t);
      if (!info.lemma && (!lang || enNames(lang).includes(next.sec))) info.lemma = pg.title || next.t;
      links = x.etyLinks; lastLen = x.text.length;
    }
    // Wiktionary non ce l'ha: l'origine del dizionario di Google (Oxford), con l'albero etimologico se c'è
    let gw = null;
    if (!info.text && mine !== "-") {
      for (const t of [word, info.lemma].filter(Boolean)) {
        let r = null;
        try { r = await DS_EXT.runtime.sendMessage({ type: "googleWebDict", word: t, lang }); } catch {}
        const e = r && r.entries && r.entries.find((x) => x.origin);
        if (e) { gw = { text: e.origin, tree: e.tree || "", title: e.headword || t, src: r.corpus || "en" }; break; }
      }
      if (gw) { info.text = gw.text; info.textTitle = gw.title; info.marked = ""; info.mentions = []; }
    }
    const name = (enNames(lang)[0] || "").replace(/ /g, "_");
    const page = info.textTitle || info.title || word;
    const out = { ...info, tv: 11, none: !info.text, at: Date.now(), source: gw ? "Dizionario di Google (Oxford)" : info.text ? "Wiktionary" : "", tree: gw ? gw.tree : "", textLang: gw ? base(gw.src) : "en",
      url: info.exists ? "https://en.wiktionary.org/wiki/" + encodeURIComponent(page) + (name ? "#" + encodeURIComponent(name) : "") : "" };
    if (out.textTitle && out.textTitle.toLowerCase() !== word.toLowerCase()) out.lemma = out.textTitle;
    // niente albero vero su Wiktionary: lo costruisco dalla catena dell'etimologia (c'è quasi sempre)
    if (!out.wtree && out.chain && out.chain.filter((c) => !c.kin && !c.part && !c.via).length >= 1) { out.wtree = chainTree(out.chain, out.textTitle || word, lang); out.wtreeTitle = out.textTitle || word; out.wtreeFrom = "catena"; }
    // «(di «…», lemma)» solo se l'etimologia viene davvero da un'altra pagina (embarazado ha la sua: «From embarazar + -ado»)
    out.baseHow = out.lemma && out.lemma.toLowerCase() !== word.toLowerCase() && (!out.textTitle || out.textTitle.toLowerCase() !== word.toLowerCase()) ? (how[out.lemma] || how[out.textTitle] || "forma") : "";
    out.baseMine = mine || "";
    if (out.text) out.trans = await translate(out.text, target, out.marked, out.mentions, out.textLang);
    else if (c && c.trans && c.source) Object.assign(out, { text: c.text, trans: c.trans, source: c.source, none: false });   // etimologia del modello
    cache.set(key, out);
    save();
    return out;
  }

  // Dal modello (pulsante): salvata come le altre
  async function fromModel(e, word, lang, target, sentence) {
    const key = [base(lang) || "?", String(word).toLowerCase(), base(target)].join("|");
    const r = await dsSendLong({ type: "etymLlm", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, word, lang: base(lang), target, sentence });
    if (!r || r.error || !r.text) return { error: (r && r.error) || "nessuna risposta" };
    // resta salvata come una correzione (non viene sostituita da Wiktionary); "Togli la correzione" torna a prima
    const out = override(word, lang, target, r.text);
    out.source = r.source;
    if (!out.lemma && r.lemma) out.lemma = r.lemma;
    saveNow();
    return out;
  }

  // «✨ Spiegala meglio con …»: una spiegazione dell'etimologia del modello ACCANTO a quella di Wiktionary (non al posto):
  // nella scheda si passa dall'una all'altra con ‹ ›. Restano salvate (le ultime 3 per parola, una per servizio).
  let notes = null;
  const notesReady = DS_EXT.storage.local.get({ etymNotes: {} }).then((r) => { notes = r.etymNotes || {}; }).catch(() => { notes = {}; });
  const noteKey = (word, lang, target) => [base(lang) || "?", String(word).toLowerCase(), base(target)].join("|");
  function notesOf(word, lang, target) { return (notes && notes[noteKey(word, lang, target)]) || []; }
  async function askDeeper(e, word, lang, target, sentence, wikt) {
    const r = await dsSendLong({ type: "etymLlm", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, word, lang: base(lang), target, sentence, wikt: wikt || "" });
    if (!r || r.error || !r.text) return { error: (r && r.error) || "nessuna risposta" };
    await notesReady;
    const k = noteKey(word, lang, target);
    const list = (notes[k] || []).filter((x) => x.by !== r.source);
    list.push({ text: r.text, by: r.source, at: Date.now() });
    notes[k] = list.slice(-3);
    const ks = Object.keys(notes);
    for (const x of ks.slice(0, Math.max(0, ks.length - 1500))) delete notes[x];
    DS_EXT.storage.local.set({ etymNotes: notes }).catch(() => {});
    return { text: r.text, by: r.source };
  }
  // etimologia arrivata insieme alla spiegazione del modello (solo se Wiktionary non l'aveva)
  function put(word, lang, target, text, source) {
    if (!text) return;
    const key = [base(lang) || "?", String(word).toLowerCase(), base(target)].join("|");
    const c = cache.get(key);
    if (c && c.trans && c.source === "Wiktionary") return;
    cache.set(key, { ...(c || {}), text, trans: text, source, none: false });
    save();
  }
  // ---------- Pronuncia dalle altre edizioni di Wiktionary ----------
  // Ogni edizione ha il suo formato: cerco gli elementi con classe IPA/API/transcription e, se non ci sono,
  // il testo tra /…/, […] o \…\ con lettere dell'alfabeto fonetico. Solo nella sezione della lingua giusta
  // (titolo nella lingua dell'edizione: "Русский", "čeština", "Brot (Deutsch)", "Tchèque", "Ceco"…).
  const IPA_CH = /[ˈˌːˑəɛɔʃʒθðŋɪʊʌæɑɒɐɕʑʂʐɲʎʁʀɾɫɣχʔʲʷɨʉɯɤøœɜɞɘɵɦɧɥʋⱱɟɖʈɭɳɻɽɬɮβɸʝçħʕʡʢ̩̯̪̥̃]/;
  const ipaClean = (t) => String(t || "").replace(/\s+/g, " ").trim().replace(/^[\/\[\\]\s*|\s*[\/\]\\]$/g, "").trim();
  function ipaPlausible(t) {
    t = String(t || "").replace(/\s+/g, " ").trim();
    if (!t || t.length > 90) return "";
    const m = t.match(/[\/\[\\]([^\/\[\]\\]{1,60})[\/\]\\]/);
    const inner = (m ? m[1] : t).trim();
    if (!inner || /[0-9<>{}=:]/.test(inner) || inner.split(" ").length > 6) return "";
    return m || IPA_CH.test(inner) ? inner : "";
  }
  function langNames(lang, ed) {
    const out = [];
    for (const inL of [ed, "en"]) { try { const n = new Intl.DisplayNames([inL], { type: "language" }).of(base(lang)); if (n && n.toLowerCase() !== base(lang)) out.push(n.toLowerCase()); } catch {} }
    return [...new Set(out)];
  }
  // registrazione della parola in un'altra edizione (sezione della lingua giusta)
  function extractAudioAny(html, lang, ed) {
    const scope = sectionOf(html, lang, ed);
    if (!scope) return [];
    for (const el of scope) { if (!el.querySelectorAll) continue; const a = audioIn(el); if (a.length) return a; }
    return [];
  }
  function sectionOf(html, lang, ed) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const root = doc.querySelector(".mw-parser-output") || doc.body;
    const names = langNames(lang, ed);
    const kids = [...root.children];
    let start = -1, end = kids.length, top = 9;
    for (let i = 0; i < kids.length; i++) {
      const h = heading(kids[i]);
      if (!h) continue;
      const t = (h.text || h.id.replace(/_/g, " ")).toLowerCase();
      if (start < 0) {
        if (h.level <= 3 && names.some((n) => t.includes(n))) { start = i; top = h.level; }
      } else if (h.level <= top) { end = i; break; }
    }
    if (start < 0 && base(ed) !== base(lang)) return null;
    return start >= 0 ? kids.slice(start + 1, end) : kids;
  }
  function extractIpaAny(html, lang, ed) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const root = doc.querySelector(".mw-parser-output") || doc.body;
    const names = langNames(lang, ed);
    const kids = [...root.children];
    let start = -1, end = kids.length, top = 9;
    for (let i = 0; i < kids.length; i++) {
      const h = heading(kids[i]);
      if (!h) continue;
      const t = (h.text || h.id.replace(/_/g, " ")).toLowerCase();
      if (start < 0) {
        if (h.level <= 3 && names.some((n) => t.includes(n))) { start = i; top = h.level; }
      } else if (h.level <= top) { end = i; break; }
    }
    // senza sezione riconosciuta: solo nell'edizione della lingua della parola (spesso c'è una sola lingua)
    if (start < 0 && base(ed) !== base(lang)) return "";
    const scope = start >= 0 ? kids.slice(start + 1, end) : kids;
    for (const el of scope) {
      if (!el.querySelectorAll) continue;
      for (const x of el.querySelectorAll(".IPA, .ipa, .API, .api, [class*='IPA'], [class*='transcription'], [class*='Transcription'], [title*='IPA'], [title*='API']")) {
        const v = ipaPlausible(x.textContent);
        if (v) return v;
      }
    }
    const text = scope.map((el) => el.textContent || "").join("\n").slice(0, 30000);
    for (const m of text.matchAll(/[\/\[\\]([^\/\[\]\\\n]{1,60})[\/\]\\]/g)) {
      if (IPA_CH.test(m[1]) && !/[0-9<>{}=]/.test(m[1])) return m[1].trim();
    }
    return "";
  }
  // stessa parola? (senza accento tonico, ё = е, maiuscole)
  const normW = (w) => String(w || "").normalize("NFD").replace(/\p{M}/gu, "").replace(/ё/g, "е").replace(/Ё/g, "Е").toLowerCase().trim();
  const sameWord = (a, b) => normW(a) === normW(b);
  // la parola nel nome del file audio ("Ru-гордый.ogg" → "гордый"), se si riconosce
  function fileWord(url) {
    try {
      let n = decodeURIComponent(String(url || "").split("/").pop() || "").replace(/\.(ogg|oga|opus|wav|mp3|flac|m4a|webm)(\.mp3)?$/i, "").replace(/_/g, " ");
      n = n.replace(/^(File:|Fichier:|Datei:|Файл:)/i, "").replace(/^[a-z]{2,3}(-[a-z]{2,4})?-/i, "").replace(/^[a-z]{2,3}(-[a-z]{2,4})? /i, "").trim();
      const m = n.match(/^[\p{L}\p{M}'-]+/u);
      return m && m[0].length > 1 && !/^[a-z]+$/i.test(m[0]) ? m[0] : "";
    } catch { return ""; }
  }
  // edizioni da provare dopo quella inglese: la lingua della parola, la tua lingua, poi le più grandi
  // Pronuncia (IPA) e registrazione dalle altre edizioni: una volta per parola, salvate.
  // want: "ipa" o "audio" — ci si ferma appena c'è quello che serve, ma si prende anche l'altro se è sulla stessa pagina
  async function ipaOther(word, lang, target, want = "ipa") {
    const key = ["ipa4", base(lang) || "?", String(word).toLowerCase()].join("|");
    const c = cache.get(key);
    const fresh = c && Date.now() - (c.at || 0) < 7 * 86400e3;
    if (c && (c.done || (want === "ipa" ? c.ipa : (c.audio && c.audio.length))) && (fresh || c.ipa || (c.audio && c.audio.length))) return c;
    const map = { nb: "no", nn: "no", fil: "tl" };
    const eds = [...new Set([base(lang), base(target), "fr", "de", "ru"].map((x) => map[x] || x).filter((x) => x && x !== "en" && x !== "?"))];
    const out = { ipa: (c && c.ipa) || "", audio: (c && c.audio) || [], source: (c && c.source) || "", audioSource: (c && c.audioSource) || "", form: (c && c.form) || "", at: Date.now() };
    for (const ed of eds) {
      for (const t of [...new Set([word, String(word).toLowerCase()])]) {
        let page;
        try { page = await otherPage(t, ed); } catch { page = null; }
        if (!page || page.error || !page.html) continue;
        // la pagina può essere di un'altra forma (rimando: гордую → гордый): la pronuncia IPA no, la registrazione sì ma segnalata
        const same = sameWord(page.title || t, word);
        if (!out.ipa && same) { const v = extractIpaAny(page.html, lang, ed); if (v) { out.ipa = v; out.source = "Wiktionary " + ed; } }
        if (!out.audio.length || (out.form && same)) {
          const a = extractAudioAny(page.html, lang, ed);
          if (a.length) {
            const fw = fileWord(a[0]);
            const form = !same ? page.title : fw && !sameWord(fw, word) ? fw : "";
            if (!out.audio.length || !form) { out.audio = a; out.audioSource = "Wiktionary " + ed; out.form = form; }
          }
        }
        break;   // trovata la pagina di questa edizione: passo alla prossima solo se manca ancora qualcosa
      }
      if (want === "ipa" ? out.ipa : out.audio.length && !out.form) break;
    }
    out.done = true;   // edizioni già provate per questa parola
    out.none = !out.ipa && !out.audio.length;
    cache.set(key, out);
    save();
    return out;
  }
  // pagine delle altre edizioni appena scaricate: pronuncia e definizioni usano la stessa (una richiesta sola)
  const pages = new Map();
  function otherPage(title, ed) {
    const k = ed + "|" + title;
    if (!pages.has(k)) {
      pages.set(k, DS_EXT.runtime.sendMessage({ type: "etymPage", word: title, site: ed }).catch(() => null));
      while (pages.size > 30) pages.delete(pages.keys().next().value);
    }
    return pages.get(k);
  }
  // sezioni con elenchi numerati che non sono definizioni (sinonimi, traduzioni, derivati…), in molte lingue
  const NOT_DEFS = /синоним|антоним|гипер|гипон|холон|мероним|родствен|перевод|этимолог|фразеолог|библиограф|литератур|синонім|антонім|переклад|synonym|antonym|hyper|hypo|holo|mero|übersetz|oberbegriff|unterbegriff|gegenw|wortbild|redewend|sprichw|charakteristische|referenz|quellen|traduction|traduzion|sinonim|contrari|derivat|dériv|compos|apparent|homophon|paronym|vocabul|anagram|référen|sources|fonti|riferiment|voir aussi|vedi anche|překlad|související|odvozen|slovní spojení|tłumacz|pochodne|kolokacj|wyrazy|przysłow|traducci|relacionad|derivad|véase|tradu[cç]|relacionad|vertaling|afgeleid|synonie|antonie|översätt|käännök|çeviri|ετυμολ|μετάφρ|翻訳|類義|対義|派生|关联|同义|反义|翻译/i;

  // Definizioni nella lingua della parola, dall'edizione di Wiktionary in quella lingua (ru.wiktionary per il russo…):
  // gratis, una richiesta per parola, salvate. Elenchi numerati (quasi tutte le edizioni) o "Bedeutungen" (tedesco).
  function extractDefsAny(html, lang, ed) {
    const scope = sectionOf(html, lang, ed);
    if (!scope) return [];
    const out = [];
    let pos = "", dd = false, skip = false;
    const add = (items) => {
      if (!items.length) return;
      const g = out.find((x) => x.pos === pos);
      if (g) g.items.push(...items); else out.push({ pos, items });
    };
    for (const el of scope) {
      const h = heading(el);
      if (h) { dd = /^(bedeutung|significat|definici|signification|betekenis)/i.test(h.text); skip = NOT_DEFS.test(h.text); continue; }
      if (skip) continue;   // le intestazioni cambiano da un'edizione all'altra: niente parte del discorso
      if (!el.querySelectorAll || out.reduce((n, g) => n + g.items.length, 0) >= 8) continue;
      if (el.tagName === "P" && /^(Bedeutungen|Significati|Significato)\s*:?\s*$/i.test(el.textContent.trim())) { dd = true; continue; }
      const lists = el.tagName === "OL" ? [el] : [...el.querySelectorAll(":scope > ol, :scope > div > ol")];
      for (const ol of lists) add(defsOfList(ol));
      if (!lists.length && el.tagName === "DL" && dd) {   // tedesco: «[1] …» in <dl><dd>
        add([...el.querySelectorAll(":scope > dd")].map((d) => {
          const t = d.textContent.replace(/\s+/g, " ").trim();
          return { def: t.replace(/^\[\d+[a-z]?\]\s*/, "").slice(0, 300), ex: "" };
        }).filter((x) => x.def.length > 1 && /\p{L}/u.test(x.def)));
        dd = false;
      }
    }
    return out.map((g) => ({ ...g, items: g.items.slice(0, 5) })).slice(0, 4);
  }
  async function defsNative(word, lang) {
    await ready;
    const b = base(lang);
    const map = { nb: "no", nn: "no", fil: "tl" };
    const ed = map[b] || b;
    if (!ed || ed === "en" || ed === "?" || !/^[a-z]{2,3}$/.test(ed)) return { defs: [] };
    const key = ["defs1", b, String(word).toLowerCase()].join("|");
    const c = cache.get(key);
    if (c && (c.defs.length || Date.now() - (c.at || 0) < 7 * 86400e3)) return c;
    const out = { defs: [], ed, url: "", at: Date.now() };
    for (const t of [...new Set([word, String(word).toLowerCase()])]) {
      let page;
      try { page = await otherPage(t, ed); } catch { page = null; }
      if (!page || page.error || !page.html) continue;
      out.defs = extractDefsAny(page.html, lang, ed);
      out.url = `https://${ed}.wiktionary.org/wiki/` + encodeURIComponent(page.title || t);
      if (out.defs.length) break;
    }
    cache.set(key, out);
    save();
    return out;
  }
  // registrazione della parola esatta da un'altra edizione di Wiktionary (se quella inglese non l'ha)
  async function audioOther(word, lang, target) {
    try { const o = await ipaOther(word, lang, target, "audio"); return { audio: (o && o.audio) || [], source: (o && o.audioSource) || "", form: (o && o.form) || "" }; }
    catch { return { audio: [], source: "" }; }
  }

  // pronuncia IPA da Wiktionary della parola esatta (non della forma base): gratis, senza token.
  // Prima l'edizione inglese (la stessa pagina degli altri strumenti), poi le altre edizioni.
  async function ipa(word, lang, target, ms = 9000) {
    const until = Date.now() + ms;
    const left = () => Math.max(500, until - Date.now());
    const race = (p) => Promise.race([p, new Promise((ok) => setTimeout(() => ok(null), left()))]);
    let r = null;
    try { r = await race(get(word, lang, target)); } catch {}
    const ok = r && r.ipa && String(r.ipaTitle || "").toLowerCase() === String(word || "").toLowerCase();
    if (ok) return { ipa: r.ipa, info: r, source: "Wiktionary" };
    let o = null;
    try { o = await race(ipaOther(word, lang, target)); } catch {}
    return { ipa: (o && o.ipa) || "", info: r, source: (o && o.source) || "" };
  }
  // etimologia corretta da te (⚑ → Correggi a mano): vince su tutto e resta salvata; "" = togli la correzione
  function override(word, lang, target, text) {
    const key = [base(lang) || "?", String(word).toLowerCase(), base(target)].join("|");
    const c = cache.get(key) || {};
    if (text && String(text).trim()) cache.set(key, { ...c, trans: String(text).trim(), fixed: true, prevTrans: c.fixed ? c.prevTrans : c.trans, prevSource: c.fixed ? c.prevSource : c.source, source: "corretta da te", none: false });
    else if (c.fixed) cache.set(key, { ...c, trans: c.prevTrans || "", source: c.prevSource || "", fixed: false, none: !c.prevTrans });
    saveNow();
    return cache.get(key);
  }
  // ritraduce il testo di Wiktionary (senza segnaposto: a volte la prima traduzione è venuta male); toglie le correzioni
  async function retranslate(word, lang, target) {
    const key = [base(lang) || "?", String(word).toLowerCase(), base(target)].join("|");
    const c = cache.get(key);
    if (!c || !c.text) return c;
    const plain = await translate(c.text, target, null, null, c.textLang);
    const marked = await translate(c.text, target, c.marked, c.mentions, c.textLang);
    const out = { ...c, trans: c.trans === marked && plain ? plain : marked, fixed: false, source: c.tree != null && /Google/.test(c.source || "") ? c.source : "Wiktionary" };
    cache.set(key, out);
    saveNow();
    return out;
  }
  const peek = (word, lang, target) => cache.get([base(lang) || "?", String(word || "").toLowerCase(), base(target)].join("|"));
  return { get, setBase, searchBases, fromModel, askDeeper, notesOf, put, peek, extract, ipa, extractIpaAny, extractAudioAny, audioIn, override, retranslate, audioOther, defsNative, extractDefsAny, sameWord, fileWord };
})();

# 1.11: JLPT e livelli (A1…C2) cliccabili → elenchi delle parole
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
OTHER = ("https://jisho.org/", "https://raw.githubusercontent.com/", "https://tatoeba.org/", "https://api.tatoeba.org/", "https://api.languagetool.org/")
async def handle(route, request):
    if ".wiktionary.org/" in request.url or request.url.startswith(OTHER): return await charness.handle(route, request)
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "ja", "勉強", 3500)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        async with ctx.expect_page() as np: await pg.locator(".pav-card .dsx-jlpt").click()
        jp = await np.value; jp.on("pageerror", lambda e: errs.append(str(e))); await jp.wait_for_timeout(2500)
        print("1. JLPT:", jp.url.split("/")[-1], "|", await jp.inner_text("#where"), "|", await jp.inner_text("#stats"), "| righe:", await jp.locator("#list tr").count())
        print("   evidenziata:", await jp.evaluate("(document.getElementById('me')||{}).innerText"), "| schede:", await jp.evaluate("[...document.querySelectorAll('#tabs a')].map(a=>a.textContent+(a.className?'*':''))"))
        await jp.locator("#me .kbtn").click(); await jp.wait_for_timeout(400)
        print("2. segnata:", await jp.inner_text("#stats"), "| conosciute ja:", await sw.evaluate("chrome.storage.local.get('knownWords').then(r=>r.knownWords.ja)"))
        await pg.bring_to_front()
        await tvolo.hover(pg, "en", "bread", 3000)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        print("3. bread badge:", await pg.evaluate("[...document.querySelectorAll('.pav-card .dsx-badges .dsx-btn')].map(b=>b.textContent)"))
        async with ctx.expect_page() as np: await pg.locator(".pav-card .dsx-level").click()
        fp = await np.value; fp.on("pageerror", lambda e: errs.append(str(e))); await fp.wait_for_timeout(1500)
        print("4. livello:", fp.url.split("/")[-1], "| barra:", await fp.evaluate("[...document.querySelectorAll('#levels button,#levels a')].map(b=>b.textContent+(b.className==='on'?'*':''))"),
              "| prima riga visibile:", await fp.evaluate("document.querySelector('#list tr:not(:has(.band)) td.n').textContent"), "| separatore:", await fp.evaluate("(document.querySelector('.band')||{}).textContent"))
        fp2 = await ctx.new_page(); fp2.on("pageerror", lambda e: errs.append(str(e)))
        await fp2.goto(fp.url.split("?")[0] + "?lang=ja"); await fp2.wait_for_timeout(1200)
        print("5. giapponese freq: barra", await fp2.evaluate("[...document.querySelectorAll('#levels a')].map(a=>a.getAttribute('href'))"))
        print("errori:", errs, tvolo.log["errors"], charness.log["errors"])
        await ctx.close()
asyncio.run(main())

// Scelta del servizio di traduzione nel popup — comune a Sottotitoli Doppi e Parole al Volo (stesso aspetto, stessi
// servizi, stesse chiavi). Usa: DS_EXT, DS_CONFIG (config.js).
// DS_ENGINES_UI.mount(box, { purpose }) disegna tutto; DS_ENGINES_UI.banner(box, id) solo l'avviso "richieste finite".
var DS_ENGINES_UI = (() => {
  const C = DS_CONFIG;
  const mk = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const nameOf = (id) => (C.ENGINES[id] ? C.ENGINES[id].label.split(" (")[0].split(",")[0] : id);
  const pacificDay = () => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return new Date().toISOString().slice(0, 10); } };
  // ora italiana (del computer) in cui si azzerano le quote di Gemini: mezzanotte di Los Angeles
  const resetTime = () => {
    try {
      const now = new Date();
      const la = new Date(now.toLocaleString("en-US", { timeZone: "America/Los_Angeles" }));
      const ms = (24 * 3600e3) - ((la.getHours() * 3600 + la.getMinutes() * 60 + la.getSeconds()) * 1000);
      return new Date(now.getTime() + ms).toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
    } catch { return "domani mattina"; }
  };

  // Avviso: il servizio scelto ha finito le richieste gratuite di oggi → quale si usa al suo posto, e "Riprova adesso"
  async function banner(box, id, onChange) {
    if (!box) return;
    box.textContent = "";
    const r = await DS_EXT.storage.local.get({ dsBlocked: {}, keys: {} });
    const s = await DS_EXT.storage.sync.get({ fallback: true, models: {}, taskModels: C.SYNC_DEFAULTS.taskModels || {}, engineOrder: [], engineOff: [] });
    const day = pacificDay();
    const st = dsBlockState(r.dsBlocked, id, s, day);
    if (!st.all && !st.models.length) { box.hidden = true; return; }
    box.hidden = false;
    if (!st.all) {
      // 1.6.1: finito solo qualche modello: si continua con gli altri modelli dello stesso servizio
      const left = [...new Set([...dsModelChain(s, "engine", id), ...dsModelChain(s, "explainEngine", id)])].filter((m) => !st.models.includes(m));
      box.append(mk("b", null, "ℹ " + nameOf(id) + ": finite per oggi le richieste di " + st.models.join(", ") + "."),
        document.createTextNode(" Tornano verso le " + resetTime() + ". Intanto si usano gli altri modelli di " + nameOf(id) + (left.length ? " (" + left.join(", ") + ")" : "") + ". "));
    } else {
      const next = s.fallback === false ? null : C.engineOrder(s).find((x) => x !== id && C.ENGINES[x] && (r.keys || {})[x] && !dsBlockState(r.dsBlocked, x, s, day).all);
      box.append(mk("b", null, "⚠ " + nameOf(id) + " ha finito le richieste gratuite di oggi" + (st.models.length ? " (tutti i modelli: " + st.models.join(", ") + ")." : ".")),
        document.createTextNode(" Tornano verso le " + resetTime() + ". Intanto " + (next ? "uso " + nameOf(next) + " (servizio di riserva)." : "uso Google Traduttore.") + " "));
    }
    const retry = mk("button", "ghost", "Riprova " + nameOf(id) + " adesso");
    retry.type = "button";
    retry.title = "Se pensi che le richieste ci siano di nuovo (per esempio hai cambiato chiave o modello), riprova subito";
    retry.addEventListener("click", async () => {
      const cur = (await DS_EXT.storage.local.get({ dsBlocked: {} })).dsBlocked || {};
      await DS_EXT.storage.local.set({ dsBlocked: dsUnblock(cur, id) });
      banner(box, id, onChange);
      if (onChange) onChange();
    });
    box.append(retry);
  }

  // Tutta la sezione: servizio, nota, chiave, area (Microsoft), indirizzo (locale), modello, riserva
  function mount(box, opts = {}) {
    // dove stanno le impostazioni (l'estensione unica dà a Parole al Volo un archivio suo per "engine")
    const ST = (opts && opts.store) || DS_EXT.storage.sync;
    if (!box) return;
    let s = {}, keys = {};
    const ids = Object.keys(C.ENGINES).filter((id) => !(opts.exclude || ["youtube"]).includes(id));
    box.textContent = "";
    const sel = mk("select"); sel.id = "engine";
    for (const id of ids) sel.append(new Option(C.ENGINES[id].label, id));
    const lab = mk("label", "stack", opts.label || "Come tradurre"); lab.append(sel);
    const note = mk("p", "small");
    const purpose = mk("p", "small");
    const urlRow = mk("label", "stack", "Indirizzo del programma"); const url = mk("input"); url.type = "text"; url.spellcheck = false; urlRow.append(url);
    const urlHint = mk("p", "small", "Ollama: http://localhost:11434/v1. LM Studio: http://localhost:1234/v1");
    const keyRow = mk("label", "stack", "Chiave API");
    const keyLine = mk("span", "keyline");
    const key = mk("input"); key.type = "password"; key.placeholder = "Incolla qui la chiave"; key.autocomplete = "off"; key.spellcheck = false;
    const show = mk("button", "ghost", "Mostra"); show.type = "button";
    show.addEventListener("click", (e) => { e.preventDefault(); key.type = key.type === "password" ? "text" : "password"; show.textContent = key.type === "password" ? "Mostra" : "Nascondi"; });
    keyLine.append(key, show); keyRow.append(keyLine);
    const regRow = mk("label", "stack", "Area della risorsa (per esempio westeurope)"); const reg = mk("input"); reg.type = "text"; reg.placeholder = "westeurope"; reg.spellcheck = false; regRow.append(reg);
    const link = mk("a", "small", "Crea una chiave"); link.target = "_blank"; link.rel = "noopener";
    const modelBox = mk("div", "stack");
    const model = mk("input"); model.type = "text"; model.spellcheck = false; model.setAttribute("list", "dsModelList");
    const list = mk("datalist"); list.id = "dsModelList";
    const load = mk("button", "ghost", "Carica modelli"); load.type = "button";
    const mrow = mk("span", "keyline"); mrow.append(model, load);
    const mmsg = mk("p", "small");
    modelBox.append(mk("span", null, "Modello"), mrow, list, mmsg);
    const fbRow = mk("label", "row", "Se finiscono le richieste gratuite, continua con un altro servizio di cui hai la chiave ");
    const fb = mk("input"); fb.type = "checkbox"; fbRow.append(fb);
    const fbInfo = mk("p", "small");
    const warn = mk("div", "small ds-blocked"); warn.hidden = true;
    const ordBox = mk("div", "ds-order");
    box.append(lab, warn, note, purpose, urlRow, urlHint, keyRow, regRow, link, modelBox, fbRow, fbInfo, ordBox);
    order(ordBox, { store: ST, pages: true, defaultEngine: opts.defaultEngine, onUse: (id) => { s.engine = id; render(); } });

    const cur = () => (C.ENGINES[s.engine] && ids.includes(s.engine) ? s.engine : "google");
    function render() {
      const id = cur(), E = C.ENGINES[id];
      sel.value = id;
      note.textContent = E.note || "";
      purpose.textContent = opts.purpose ? opts.purpose(id, E) : "";
      purpose.hidden = !purpose.textContent;
      keyRow.hidden = link.hidden = !E.needsKey;
      if (E.keyUrl) link.href = E.keyUrl;
      key.value = keys[id] || "";
      urlRow.hidden = urlHint.hidden = !E.local;
      url.value = s.localUrl || C.SYNC_DEFAULTS.localUrl;
      regRow.hidden = E.kind !== "microsoft";
      reg.value = s.msRegion || "";
      const hasModel = E.kind === "openai" || E.kind === "claude";
      modelBox.hidden = !hasModel;
      model.value = (s.models || {})[id] || E.defaultModel || "";
      list.innerHTML = "";
      (E.staticModels || []).forEach((m) => list.append(new Option(m, m)));
      mmsg.textContent = "";
      fb.checked = s.fallback !== false;
      const ready = C.engineOrder(s).filter((x) => keys[x] || (C.ENGINES[x] && C.ENGINES[x].local && (s.models || {})[x]));
      fbInfo.textContent = s.fallback === false ? "" : ready.length
        ? "Servizi con la chiave, in quest'ordine: " + ready.map(nameOf).join(", ") + ". Poi Google Traduttore."
        : "Per avere servizi di riserva, scegli Groq, Mistral o OpenRouter qui sopra e inserisci la loro chiave gratuita (poi torna al servizio che preferisci).";
      banner(warn, id, render);
      if (opts.onChange) opts.onChange(id, E);
    }
    async function loadModels(auto) {
      const id = cur(), E = C.ENGINES[id];
      if (E.kind !== "openai") return;
      if (E.needsKey && !keys[id]) { if (!auto) mmsg.textContent = "Inserisci prima la chiave."; return; }
      mmsg.textContent = "Cerco i modelli disponibili…";
      let r;
      try { r = await DS_EXT.runtime.sendMessage({ type: "listModels", engine: id, key: keys[id] || "", localUrl: s.localUrl }); } catch (e) { r = { error: String(e.message || e) }; }
      if (cur() !== id) return;
      if (!r || r.error) { mmsg.textContent = "Errore: " + ((r && r.error) || "nessuna risposta"); return; }
      list.innerHTML = "";
      r.models.forEach((m) => list.append(new Option(m, m)));
      mmsg.textContent = r.models.length ? `${r.models.length} modelli trovati: clicca nel campo per sceglierne un altro.` : "Nessun modello trovato.";
      if (!model.value && r.suggested) { model.value = r.suggested; saveModel(r.suggested); }
    }
    function saveModel(m) { s.models = { ...(s.models || {}), [cur()]: m }; ST.set({ models: s.models }); }
    sel.addEventListener("change", () => { s.engine = sel.value; ST.set({ engine: s.engine }); render(); if (!model.value) loadModels(true); });
    key.addEventListener("change", async () => {
      keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
      keys[cur()] = key.value.trim();
      await DS_EXT.storage.local.set({ keys });
      render();
      if (!model.value) loadModels(true);
    });
    url.addEventListener("change", () => { s.localUrl = url.value.trim() || C.SYNC_DEFAULTS.localUrl; ST.set({ localUrl: s.localUrl }); loadModels(true); });
    reg.addEventListener("change", () => { s.msRegion = reg.value.trim(); ST.set({ msRegion: s.msRegion }); });
    model.addEventListener("change", () => saveModel(model.value.trim()));
    load.addEventListener("click", () => loadModels(false));
    fb.addEventListener("change", () => { s.fallback = fb.checked; ST.set({ fallback: fb.checked }); render(); });
    // servizio cambiato da un'altra parte del popup («Modello per ogni compito»): la tendina lo segue
    DS_EXT.storage.onChanged.addListener((ch, area) => {
      if (area !== "sync") return;
      const c = (opts.store && typeof PAV_SYNC !== "undefined") ? ch.pavEngine : ch.engine;
      if (c && c.newValue && c.newValue !== s.engine) { s.engine = c.newValue; render(); }
    });
    (async () => {
      s = await ST.get({ engine: opts.defaultEngine || "google", models: {}, localUrl: C.SYNC_DEFAULTS.localUrl, msRegion: "", fallback: true, engineOrder: [], engineOff: [] });
      keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
      render();
    })();
  }
  // «Ordine dei servizi»: la fila dei servizi con la chiave (o il modello sul computer). Si sposta su e giù, si spegne,
  // «Usa adesso» lo mette primo e lo sceglie subito, «Prova» manda una frase di prova e dice se risponde (e cosa sbaglia).
  // L'ordine vale per i servizi di riserva, per «✨ Spiega con…» (se il servizio scelto non è un modello), per la
  // pronuncia e per la correzione della trascrizione. opts.store: dove sta "engine" (Parole al Volo nell'unica ne ha uno suo).
  function order(box, opts = {}) {
    if (!box) return;
    const SY = DS_EXT.storage.sync, ST = opts.store || SY;
    const tests = {};   // id → esito dell'ultima prova
    let busy = false;
    // i due sottomenu restano aperti o chiusi come li hai lasciati (anche quando la fila si ridisegna)
    const opened = { tasks: false, order: false };
    try { Object.assign(opened, JSON.parse(localStorage.getItem("dsOrderOpen") || "{}")); } catch {}
    const sub = (key, title) => {
      const d = mk("details", "ds-sub"); d.open = !!opened[key];
      const s = mk("summary", null, title); d.append(s);
      d.addEventListener("toggle", () => { opened[key] = d.open; try { localStorage.setItem("dsOrderOpen", JSON.stringify(opened)); } catch {} });
      return d;
    };
    async function state() {
      const s = await SY.get({ engineOrder: [], engineOff: [], models: {}, localUrl: C.SYNC_DEFAULTS.localUrl, msRegion: "", targetLang: "it",
        explainEngine: "", cleanEngine: "", ipaEngine: "", alignEngine: "", engine: "google", pavEngine: "google", stt: "groq" });
      const e = await ST.get({ engine: opts.defaultEngine || "google" });
      const l = await DS_EXT.storage.local.get({ keys: {}, dsBlocked: {}, dsModelLists: {} });
      const t = await SY.get({ taskModels: C.SYNC_DEFAULTS.taskModels || {} });
      s.taskModels = t.taskModels || {};
      return { s, engine: e.engine, keys: l.keys || {}, blocked: l.dsBlocked || {}, lists: l.dsModelLists || {} };
    }
    function status(id, st) {
      const E = C.ENGINES[id];
      if (E.needsKey && !st.keys[id]) return { ok: false, t: "manca la chiave" };
      if ((E.kind === "openai" || E.kind === "claude") && !((st.s.models || {})[id] || E.defaultModel)) return { ok: false, t: "manca il modello: sceglilo in 🌐 Traduzione e modelli («Carica modelli»)" };
      const bs = dsBlockState(st.blocked, id, st.s, pacificDay());
      if (bs.all) return { ok: true, t: "richieste finite per oggi" };
      if (bs.models.length) return { ok: true, t: "pronto (finite per oggi: " + bs.models.join(", ") + ")" };
      return { ok: true, t: E.local ? "pronto (se il programma è avviato)" : "pronto" };
    }
    async function save(list, off) {
      await SY.set({ engineOrder: list, engineOff: off });
    }
    async function test(id) {
      const st = await state();
      const E = C.ENGINES[id];
      tests[id] = { t: "Provo…" }; render();
      const t0 = Date.now();
      // i secondi che passano (un modello sul computer può metterci molto, soprattutto la prima volta)
      const tick = setInterval(() => {
        const n = Math.round((Date.now() - t0) / 1000);
        tests[id] = { t: "Provo… " + n + " s" + (E.local && n >= 10 ? " (la prima volta il programma carica il modello in memoria: può volerci un minuto)" : "") };
        const row = [...box.querySelectorAll(".ds-order-row")].find((x) => x.dataset.id === id);
        const line = row && row.querySelector(".ds-order-test");
        if (line) line.textContent = tests[id].t;
      }, 1000);
      let r;
      try {
        r = await dsSendLong({ type: "translate", engine: id, key: st.keys[id] || "", model: (st.s.models || {})[id] || E.defaultModel || "",
          localUrl: st.s.localUrl, region: st.s.msRegion, target: st.s.targetLang || "it", source: "en", texts: ["Good morning, how are you today?"], priority: true });
      } catch (e) { r = { error: String((e && e.message) || e) }; }
      clearInterval(tick);
      const sec = ((Date.now() - t0) / 1000).toFixed(1).replace(".", ",");
      const out = r && !r.error && r.translations && r.translations[0];
      const slow = (Date.now() - t0) / 1000;
      const mname = String((st.s.models || {})[id] || "");
      // modelli che «ragionano» sempre prima di rispondere (Qwen 3 di serie, QwQ, DeepSeek-R1…): lentissimi per tradurre
      const thinker = /qwen3(?!.*instruct)|qwq|deepseek-r1|magistral|phi4-reasoning|thinking/i.test(mname);
      const hint = !out || !E.local ? "" : thinker && slow > 5 ? ` — lento perché «${mname}» ragiona prima di ogni risposta (non si spegne): per tradurre prendi un modello senza ragionamento, per esempio  ollama pull gemma3:4b  oppure una versione «instruct» di Qwen 3`
        : slow > 15 ? " — lento: per i sottotitoli usa un modello più piccolo (per esempio gemma3:4b) o un servizio online; riprova una seconda volta, la prima carica il modello" : slow > 5 ? " — va bene per le spiegazioni, per i sottotitoli è un po' lento" : "";
      tests[id] = out ? { ok: true, t: `✓ Funziona (${sec} s): «${out}»` + hint } : { ok: false, t: "✗ Non funziona: " + ((r && r.error) || "nessuna risposta") };
      render();
    }
    // «Modello per ogni compito»: per ogni lavoro il suo servizio. Per i compiti dei modelli «automatico» = il primo modello
    // pronto della fila qui sotto (e, per le spiegazioni, quello dei sottotitoli se è un modello). Nell'estensione unica le
    // pagine hanno il loro servizio (pavEngine); nelle estensioni separate «engine» è quello dell'estensione.
    const unica = typeof PAV_SYNC !== "undefined" || (() => { try { const n = DS_EXT.runtime.getManifest().name; return /Sottotitoli/.test(n) && /Parole/.test(n); } catch { return false; } })();
    function tasksPanel(st, all) {
      const wrap = mk("div", "ds-tasks");
      const label = (id) => (C.ENGINES[id].local ? "Ollama / LM Studio" : nameOf(id));
      const llms = all.filter((id) => C.ENGINES[id].kind === "openai" || C.ENGINES[id].kind === "claude");
      const trans = Object.keys(C.ENGINES).filter((id) => id !== "youtube");
      const isLlm = (id) => !!C.ENGINES[id] && (C.ENGINES[id].kind === "openai" || C.ENGINES[id].kind === "claude");
      const ready = (id) => isLlm(id) && status(id, st).ok && !(st.s.engineOff || []).includes(id);
      const firstLlm = (noLocal) => C.engineOrder(st.s).find((id) => ready(id) && !(noLocal && C.ENGINES[id].local)) || "";
      // il servizio che fa davvero il compito adesso (scelto, oppure «automatico»): il campo del modello vale per quello
      const effective = (task) => {
        const own = st.s[task];
        if (task === "engine" || task === "pavEngine") return isLlm(own) ? own : "";
        if (own && ready(own)) return own;
        if (task === "explainEngine" || task === "alignEngine") return ready(st.s.engine) ? st.s.engine : firstLlm();
        return firstLlm(task === "ipaEngine");
      };
      // 1.6.0: per ogni compito anche il modello preciso (taskModels["compito|servizio"]); vuoto = quello del servizio
      // 1.6.1: per ogni compito l'elenco dei modelli in ordine (taskModels["compito|servizio"] = [..]): se uno finisce le
      // richieste di oggi si passa al successivo. In fondo, come riserva, quello del servizio e i suggeriti (DS_MODEL_CHAINS).
      const modelField = (task, l) => {
        const id = effective(task);
        if (!id || C.ENGINES[id].local) return;
        const E = C.ENGINES[id];
        const base = (st.s.models || {})[id] || E.defaultModel || "";
        const key = task + "|" + id;
        const mine = dsTaskList(st.s, task, id);
        const chain = dsModelChain(st.s, task, id);
        const day = pacificDay();
        const done = (m) => !!(st.blocked[id + "|" + m] && st.blocked[id + "|" + m].day === day);
        const save = async (list) => {
          const tm = { ...((await SY.get({ taskModels: {} })).taskModels || {}) };
          const clean = [...new Set(list.map((x) => String(x || "").trim()).filter(Boolean))];
          if (clean.length) tm[key] = clean; else delete tm[key];
          await SY.set({ taskModels: tm });
        };
        const box = mk("div", "ds-task-model"); box.style.cssText = "margin:4px 0 10px;padding-left:6px;border-left:2px solid rgba(127,127,127,.35)";
        box.append(mk("div", "small", "Modelli di " + label(id) + " in ordine: se uno finisce le richieste di oggi si passa al successivo"));
        const first = chain.find((m) => !done(m));
        chain.forEach((m, i) => {
          const r = mk("div", "small ds-task-mrow"); r.style.cssText = "display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin:2px 0";
          const nm = mk("span", null, (i + 1) + ". " + m); nm.style.cssText = "font-weight:" + (m === first ? "700" : "400") + ";flex:1 1 140px;word-break:break-all";
          const tag = mines(m) ? "scelto da te" : m === base ? "del servizio" : "suggerito";
          const stt = mk("span", null, tag + " · " + (done(m) ? "finito oggi" : m === first ? "in uso" : "pronto"));
          stt.style.opacity = done(m) ? ".6" : ".85";
          const btn = (t, title, fn, dis) => { const x = mk("button", "ghost", t); x.type = "button"; x.title = title; x.disabled = !!dis; x.style.padding = "0 6px"; x.addEventListener("click", (ev) => { ev.preventDefault(); fn(); }); return x; };
          const move = (d) => { const l2 = chain.slice(); [l2[i], l2[i + d]] = [l2[i + d], l2[i]]; save(l2); };
          r.append(nm, stt, btn("↑", "Più su", () => move(-1), i === 0), btn("↓", "Più giù", () => move(1), i === chain.length - 1));
          if (mines(m)) r.append(btn("✕", "Toglilo dai tuoi (se è del servizio o suggerito resta in fondo come riserva)", () => save(mine.filter((x) => x !== m))));
          box.append(r);
        });
        function mines(m) { return mine.includes(m); }
        const add = mk("div"); add.style.cssText = "display:flex;gap:4px;align-items:center;margin-top:3px";
        const inp = mk("input"); inp.type = "text"; inp.placeholder = "aggiungi un modello…"; inp.spellcheck = false; inp.style.cssText = "flex:1 1 140px;min-width:0";
        const dl = mk("datalist"); dl.id = "dsTM-" + task;
        inp.setAttribute("list", dl.id);
        for (const m of new Set([...(DS_MODEL_HINTS[id] || []), ...(E.staticModels || []), ...(st.lists[id] || [])])) if (!chain.includes(m)) dl.append(new Option(m, m));
        const addBtn = mk("button", "ghost", "+ Aggiungi"); addBtn.type = "button"; addBtn.style.padding = "1px 6px";
        addBtn.title = "Lo mette primo per questo compito";
        const doAdd = () => { const v = inp.value.trim(); if (v) save([v, ...mine.filter((x) => x !== v)]); };
        addBtn.addEventListener("click", doAdd);
        inp.addEventListener("keydown", (ev) => { if (ev.key === "Enter") { ev.preventDefault(); doAdd(); } });
        const load = mk("button", "ghost", "↻"); load.type = "button"; load.title = "Carica l'elenco dei modelli di " + label(id);
        load.style.padding = "1px 6px";
        load.addEventListener("click", async () => {
          load.textContent = "…";
          try { await DS_EXT.runtime.sendMessage({ type: "listModels", engine: id, key: st.keys[id] || "", localUrl: st.s.localUrl }); } catch {}
          render();
        });
        add.append(inp, dl, addBtn, load);
        box.append(add);
        l.after(box);
      };
      const row = (text, hint, cls, options, value, onChange, task) => {
        const l = mk("label", "stack", text);
        l.style.marginBottom = "10px";
        const sel = mk("select"); if (cls) sel.className = cls;
        for (const [v, t] of options) sel.append(new Option(t, v));
        sel.value = options.some(([v]) => v === value) ? value : options[0][0];
        sel.addEventListener("change", () => onChange(sel.value));
        l.append(sel);
        if (hint) l.title = hint;
        wrap.append(l);
        if (task) modelField(task, l);
      };
      const llmOpts = (auto) => [["", auto], ...llms.map((id) => { const x = status(id, st); return [id, label(id) + (x.ok ? "" : " — " + x.t)]; })];
      const transOpts = trans.map((id) => [id, C.ENGINES[id].label]);
      const useOwn = (key, id) => { if (opts.onUse && ((key === "engine" && !opts.pages) || (opts.pages && key === (unica ? "pavEngine" : "engine")))) opts.onUse(id); };
      // il servizio dei sottotitoli si sceglie in «🌐 Traduzione e modelli» (niente tendina doppia): qui solo il modello preciso
      if (!opts.pages || unica) {
        const l = mk("div", "stack ds-task-video-info", "Sottotitoli dei video");
        l.style.marginBottom = "10px";
        const E = C.ENGINES[st.s.engine] || C.ENGINES.google;
        const who = mk("span", "small", (E.local ? "Ollama / LM Studio" : nameOf(st.s.engine)) + " — si sceglie in 🌐 Traduzione e modelli («Traduci i sottotitoli con»)");
        who.style.display = "block";
        l.append(who);
        wrap.append(l);
        modelField("engine", l);
      }
      if (opts.pages || unica) row("Testi delle pagine e PDF", "Il servizio di Parole al Volo: la traduzione delle parole e del testo selezionato", "ds-task-pages", transOpts,
        unica ? st.s.pavEngine : st.engine, (v) => { if (unica) SY.set({ pavEngine: v }); else ST.set({ engine: v }); useOwn(unica ? "pavEngine" : "engine", v); });
      // (la trascrizione dell'audio si sceglie in «🎙 Trascrizione dell'audio → Trascrizione con»)
      row("Spiegazioni («✨ Spiega con…»)", "Se non risponde o ha finito le richieste di oggi, la spiegazione la fa il primo modello pronto della fila", "ds-explain-engine",
        llmOpts("automatico: quello dei sottotitoli, se è un modello, o il primo della fila"), st.s.explainEngine, (v) => SY.set({ explainEngine: v }), "explainEngine");
      if (!opts.pages || unica) row("Correzione della trascrizione", "Corregge le parole sentite male da Whisper (quando traduci con Google, DeepL o Microsoft)", "ds-task-clean",
        llmOpts("automatico: il primo modello pronto della fila"), st.s.cleanEngine, (v) => SY.set({ cleanEngine: v }), "cleanEngine");
      // (nei video la pronuncia che manca arriva con «✨ Spiega con…»; sulle pagine c'è il pulsante «Pronuncia IPA» del testo selezionato)
      if (opts.pages || unica) row("Pronuncia IPA del testo selezionato (pagine)", "Il pulsante «Pronuncia IPA» nel riquadro del testo selezionato", "ds-task-ipa",
        llmOpts("automatico: il primo modello pronto della fila"), st.s.ipaEngine, (v) => SY.set({ ipaEngine: v }), "ipaEngine");
      row("Collegamento parole e modi di dire", "Quale parola della traduzione corrisponde a quale dell'originale, e i modi di dire della frase (solo se acceso nel popup)", "ds-task-align",
        llmOpts("automatico: come le spiegazioni"), st.s.alignEngine, (v) => SY.set({ alignEngine: v }), "alignEngine");
      wrap.append(mk("p", "small", "Per ogni compito, i modelli del servizio indicato in ordine: si usa il primo pronto (in grassetto); quando uno finisce le richieste di oggi si passa da soli al successivo. Su Gemini, Groq e Mistral i limiti gratuiti sono per modello: finito uno, gli altri si usano ancora. ↑ ↓ cambiano l'ordine, «+ Aggiungi» mette primo un altro modello (↻ carica l'elenco). Solo quando sono finiti tutti si passa al servizio successivo dell'«Ordine dei servizi»."));
      const d = sub("tasks", "Modello per ogni compito");
      d.append(wrap);
      return d;
    }
    async function render() {
      if (busy) return;
      busy = true;
      try {
        const st = await state();
        const all = C.engineOrder(st.s, true).filter((id) => C.ENGINES[id]);
        const off = new Set(st.s.engineOff || []);
        box.textContent = "";
        box.append(tasksPanel(st, all));
        const od = sub("order", "Ordine dei servizi");
        od.append(mk("p", "small", "Quando un servizio finisce le richieste gratuite si passa al successivo; il primo modello pronto fa anche le spiegazioni se traduci con Google. «Usa adesso» lo sceglie subito; «Prova» controlla se risponde."));
        box.append(od);
        all.forEach((id, i) => {
          const row = mk("div", "ds-order-row"); row.dataset.id = id;
          row.style.cssText = "display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin:3px 0;padding:3px 0;border-top:1px solid rgba(127,127,127,.25)";
          const on = mk("input"); on.type = "checkbox"; on.checked = !off.has(id); on.title = "Spunta tolta: questo servizio non si usa mai da solo";
          on.addEventListener("change", async () => { const o = new Set(st.s.engineOff || []); if (on.checked) o.delete(id); else o.add(id); await save(all, [...o]); render(); });
          const name = mk("span", null, (i + 1) + ". " + (C.ENGINES[id].local ? "Ollama / LM Studio" : nameOf(id))); name.style.fontWeight = "600";
          const stt = status(id, st);
          const info = mk("span", "small", (st.engine === id ? "in uso · " : "") + stt.t); info.style.flex = "1 1 120px"; info.style.opacity = stt.ok ? ".8" : ".6";
          const up = mk("button", "ghost", "↑"); up.type = "button"; up.title = "Più su"; up.disabled = i === 0;
          const down = mk("button", "ghost", "↓"); down.type = "button"; down.title = "Più giù"; down.disabled = i === all.length - 1;
          const move = async (d) => { const l = all.slice(); [l[i], l[i + d]] = [l[i + d], l[i]]; await save(l, [...off]); render(); };
          up.addEventListener("click", () => move(-1)); down.addEventListener("click", () => move(1));
          const use = mk("button", "ghost", st.engine === id ? "✓ in uso" : "Usa adesso"); use.type = "button";
          use.title = "Lo metto primo nella fila e lo scelgo subito (anche per tradurre)";
          use.addEventListener("click", async () => {
            const l = [id, ...all.filter((x) => x !== id)];
            const o = new Set(off); o.delete(id);
            await save(l, [...o]);
            await ST.set({ engine: id });
            if (opts.onUse) opts.onUse(id);
            render();
            if (stt.ok) test(id);
          });
          const tryb = mk("button", "ghost", "Prova"); tryb.type = "button"; tryb.title = "Traduce una frase di prova con questo servizio (una richiesta)";
          tryb.addEventListener("click", () => test(id));
          [up, down, use, tryb].forEach((b) => { b.style.padding = "1px 6px"; });
          // prima riga: casella, nome e stato; seconda riga: i pulsanti, sempre allineati
          const btns = mk("span"); btns.style.cssText = "display:flex;gap:4px;flex-basis:100%;padding-left:24px";
          btns.append(up, down, use, tryb);
          row.append(on, name, info, btns);
          if (tests[id]) { const r = mk("div", "small ds-order-test", tests[id].t); r.style.cssText = "flex-basis:100%;" + (tests[id].ok === false ? "color:#d9534f" : ""); row.append(r); }
          od.append(row);
        });
      } finally { busy = false; }
    }
    DS_EXT.storage.onChanged.addListener((ch, area) => {
      if (ch.engineOrder || ch.engineOff || ch.explainEngine || ch.cleanEngine || ch.ipaEngine || ch.alignEngine || ch.stt || ch.engine || ch.pavEngine || ch.models || ch.keys || ch.dsBlocked || ch.taskModels || ch.dsModelLists) render();
    });
    render();
    return { render };
  }
  return { mount, banner, nameOf, order };
})();

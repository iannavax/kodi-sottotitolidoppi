import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        day = await sw.evaluate("new Date().toLocaleDateString('en-CA', {timeZone:'America/Los_Angeles'})")
        await sw.evaluate(f"chrome.storage.sync.set({{engine:'gemini'}}).then(()=>chrome.storage.local.set({{keys:{{gemini:'AIza', groq:'gsk'}}, dsBlocked:{{gemini:{{day:'{day}', at:Date.now()}}}}}}))")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1000)
        print("1. avviso:", await pp.inner_text("#blockedBox"))
        await pp.locator("#blockedBox button").click(); await pp.wait_for_timeout(500)
        print("2. dopo Riprova:", await sw.evaluate("chrome.storage.local.get('dsBlocked')"), "| avviso nascosto:", await pp.evaluate("document.getElementById('blockedBox').hidden"))
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

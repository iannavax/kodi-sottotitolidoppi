// Scelta del servizio di traduzione nel popup — comune a Sottotitoli Doppi e Parole al Volo (stesso aspetto, stessi
// servizi, stesse chiavi). Usa: DS_EXT, DS_CONFIG (config.js).
// DS_ENGINES_UI.mount(box, { purpose }) disegna tutto; DS_ENGINES_UI.banner(box, id) solo l'avviso "richieste finite".
var DS_ENGINES_UI = (() => {
  const C = DS_CONFIG;
  const mk = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const nameOf = (id) => (C.ENGINES[id] ? C.ENGINES[id].label.split(" (")[0].split(",")[0] : id);
  const pacificDay = () => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return new Date().toISOString().slice(0, 10); } };
  // ora italiana (del computer) in cui si azzerano le quote di Gemini: mezzanotte di Los Angeles
  const resetTime = () => {
    try {
      const now = new Date();
      const la = new Date(now.toLocaleString("en-US", { timeZone: "America/Los_Angeles" }));
      const ms = (24 * 3600e3) - ((la.getHours() * 3600 + la.getMinutes() * 60 + la.getSeconds()) * 1000);
      return new Date(now.getTime() + ms).toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
    } catch { return "domani mattina"; }
  };

  // Avviso: il servizio scelto ha finito le richieste gratuite di oggi → quale si usa al suo posto, e "Riprova adesso"
  async function banner(box, id, onChange) {
    if (!box) return;
    box.textContent = "";
    const r = await DS_EXT.storage.local.get({ dsBlocked: {}, keys: {} });
    const s = await DS_EXT.storage.sync.get({ fallback: true });
    const b = (r.dsBlocked || {})[id];
    if (!b || b.day !== pacificDay()) { box.hidden = true; return; }
    const next = s.fallback === false ? null : C.FALLBACK.find((x) => x !== id && C.ENGINES[x] && (r.keys || {})[x] && !((r.dsBlocked || {})[x] && r.dsBlocked[x].day === pacificDay()));
    box.hidden = false;
    box.append(mk("b", null, "⚠ " + nameOf(id) + " ha finito le richieste gratuite di oggi."),
      document.createTextNode(" Tornano verso le " + resetTime() + ". Intanto " + (next ? "uso " + nameOf(next) + " (servizio di riserva)." : "uso Google Traduttore.") + " "));
    const retry = mk("button", "ghost", "Riprova " + nameOf(id) + " adesso");
    retry.type = "button";
    retry.title = "Se pensi che le richieste ci siano di nuovo (per esempio hai cambiato chiave o modello), riprova subito";
    retry.addEventListener("click", async () => {
      const cur = (await DS_EXT.storage.local.get({ dsBlocked: {} })).dsBlocked || {};
      delete cur[id];
      await DS_EXT.storage.local.set({ dsBlocked: cur });
      banner(box, id, onChange);
      if (onChange) onChange();
    });
    box.append(retry);
  }

  // Tutta la sezione: servizio, nota, chiave, area (Microsoft), indirizzo (locale), modello, riserva
  function mount(box, opts = {}) {
    if (!box) return;
    let s = {}, keys = {};
    const ids = Object.keys(C.ENGINES).filter((id) => !(opts.exclude || ["youtube"]).includes(id));
    box.textContent = "";
    const sel = mk("select"); sel.id = "engine";
    for (const id of ids) sel.append(new Option(C.ENGINES[id].label, id));
    const lab = mk("label", "stack", opts.label || "Come tradurre"); lab.append(sel);
    const note = mk("p", "small");
    const purpose = mk("p", "small");
    const urlRow = mk("label", "stack", "Indirizzo del programma"); const url = mk("input"); url.type = "text"; url.spellcheck = false; urlRow.append(url);
    const urlHint = mk("p", "small", "Ollama: http://localhost:11434/v1. LM Studio: http://localhost:1234/v1");
    const keyRow = mk("label", "stack", "Chiave API");
    const keyLine = mk("span", "keyline");
    const key = mk("input"); key.type = "password"; key.placeholder = "Incolla qui la chiave"; key.autocomplete = "off"; key.spellcheck = false;
    const show = mk("button", "ghost", "Mostra"); show.type = "button";
    show.addEventListener("click", (e) => { e.preventDefault(); key.type = key.type === "password" ? "text" : "password"; show.textContent = key.type === "password" ? "Mostra" : "Nascondi"; });
    keyLine.append(key, show); keyRow.append(keyLine);
    const regRow = mk("label", "stack", "Area della risorsa (per esempio westeurope)"); const reg = mk("input"); reg.type = "text"; reg.placeholder = "westeurope"; reg.spellcheck = false; regRow.append(reg);
    const link = mk("a", "small", "Crea una chiave"); link.target = "_blank"; link.rel = "noopener";
    const modelBox = mk("div", "stack");
    const model = mk("input"); model.type = "text"; model.spellcheck = false; model.setAttribute("list", "dsModelList");
    const list = mk("datalist"); list.id = "dsModelList";
    const load = mk("button", "ghost", "Carica modelli"); load.type = "button";
    const mrow = mk("span", "keyline"); mrow.append(model, load);
    const mmsg = mk("p", "small");
    modelBox.append(mk("span", null, "Modello"), mrow, list, mmsg);
    const fbRow = mk("label", "row", "Se finiscono le richieste gratuite, continua con un altro servizio di cui hai la chiave ");
    const fb = mk("input"); fb.type = "checkbox"; fbRow.append(fb);
    const fbInfo = mk("p", "small");
    const warn = mk("div", "small ds-blocked"); warn.hidden = true;
    box.append(lab, warn, note, purpose, urlRow, urlHint, keyRow, regRow, link, modelBox, fbRow, fbInfo);

    const cur = () => (C.ENGINES[s.engine] && ids.includes(s.engine) ? s.engine : "google");
    function render() {
      const id = cur(), E = C.ENGINES[id];
      sel.value = id;
      note.textContent = E.note || "";
      purpose.textContent = opts.purpose ? opts.purpose(id, E) : "";
      purpose.hidden = !purpose.textContent;
      keyRow.hidden = link.hidden = !E.needsKey;
      if (E.keyUrl) link.href = E.keyUrl;
      key.value = keys[id] || "";
      urlRow.hidden = urlHint.hidden = !E.local;
      url.value = s.localUrl || C.SYNC_DEFAULTS.localUrl;
      regRow.hidden = E.kind !== "microsoft";
      reg.value = s.msRegion || "";
      const hasModel = E.kind === "openai" || E.kind === "claude";
      modelBox.hidden = !hasModel;
      model.value = (s.models || {})[id] || E.defaultModel || "";
      list.innerHTML = "";
      (E.staticModels || []).forEach((m) => list.append(new Option(m, m)));
      mmsg.textContent = "";
      fb.checked = s.fallback !== false;
      const ready = C.FALLBACK.filter((x) => keys[x]);
      fbInfo.textContent = s.fallback === false ? "" : ready.length
        ? "Servizi con la chiave, in quest'ordine: " + ready.map(nameOf).join(", ") + ". Poi Google Traduttore."
        : "Per avere servizi di riserva, scegli Groq, Mistral o OpenRouter qui sopra e inserisci la loro chiave gratuita (poi torna al servizio che preferisci).";
      banner(warn, id, render);
      if (opts.onChange) opts.onChange(id, E);
    }
    async function loadModels(auto) {
      const id = cur(), E = C.ENGINES[id];
      if (E.kind !== "openai") return;
      if (E.needsKey && !keys[id]) { if (!auto) mmsg.textContent = "Inserisci prima la chiave."; return; }
      mmsg.textContent = "Cerco i modelli disponibili…";
      let r;
      try { r = await DS_EXT.runtime.sendMessage({ type: "listModels", engine: id, key: keys[id] || "", localUrl: s.localUrl }); } catch (e) { r = { error: String(e.message || e) }; }
      if (cur() !== id) return;
      if (!r || r.error) { mmsg.textContent = "Errore: " + ((r && r.error) || "nessuna risposta"); return; }
      list.innerHTML = "";
      r.models.forEach((m) => list.append(new Option(m, m)));
      mmsg.textContent = r.models.length ? `${r.models.length} modelli trovati: clicca nel campo per sceglierne un altro.` : "Nessun modello trovato.";
      if (!model.value && r.suggested) { model.value = r.suggested; saveModel(r.suggested); }
    }
    function saveModel(m) { s.models = { ...(s.models || {}), [cur()]: m }; DS_EXT.storage.sync.set({ models: s.models }); }
    sel.addEventListener("change", () => { s.engine = sel.value; DS_EXT.storage.sync.set({ engine: s.engine }); render(); if (!model.value) loadModels(true); });
    key.addEventListener("change", async () => {
      keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
      keys[cur()] = key.value.trim();
      await DS_EXT.storage.local.set({ keys });
      render();
      if (!model.value) loadModels(true);
    });
    url.addEventListener("change", () => { s.localUrl = url.value.trim() || C.SYNC_DEFAULTS.localUrl; DS_EXT.storage.sync.set({ localUrl: s.localUrl }); loadModels(true); });
    reg.addEventListener("change", () => { s.msRegion = reg.value.trim(); DS_EXT.storage.sync.set({ msRegion: s.msRegion }); });
    model.addEventListener("change", () => saveModel(model.value.trim()));
    load.addEventListener("click", () => loadModels(false));
    fb.addEventListener("change", () => { s.fallback = fb.checked; DS_EXT.storage.sync.set({ fallback: fb.checked }); render(); });
    (async () => {
      s = await DS_EXT.storage.sync.get({ engine: opts.defaultEngine || "google", models: {}, localUrl: C.SYNC_DEFAULTS.localUrl, msRegion: "", fallback: true });
      keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
      render();
    })();
  }
  return { mount, banner, nameOf };
})();

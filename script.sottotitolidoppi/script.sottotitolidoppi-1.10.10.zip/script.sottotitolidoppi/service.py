# -*- coding: utf-8 -*-
# Sottotitoli Doppi - servizio: quando parte un video, prepara da solo i sottotitoli doppi
import threading

import xbmc

from resources.lib import runner


class Player(xbmc.Player):
    def onAVStarted(self):
        runner.mark_start(self)   # serve a non confondere i sottotitoli scaricati con quelli del film di prima
        if not self.isPlayingVideo() or not runner.settings()["auto"]:
            return
        # piccola attesa: i sottotitoli scaricati automaticamente dagli add-on arrivano dopo l'avvio
        threading.Timer(4.0, lambda: runner.run(self)).start()


if __name__ == "__main__":
    monitor = xbmc.Monitor()
    player = Player()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break

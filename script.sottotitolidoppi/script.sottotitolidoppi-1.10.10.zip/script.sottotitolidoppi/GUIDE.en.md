# Sottotitoli Doppi for Kodi

*Versione italiana → [LEGGIMI](LEGGIMI.md)*

**Learn languages by watching films and series on Kodi.** The add-on creates **two-line** subtitles: the original line on top and the translation into your language below it, in a different colour.

It takes the original subtitles from wherever it finds them: inside the film you're watching (streaming too, e.g. with The Crew and Real-Debrid), from a file next to the video, from OpenSubtitles. If there are none, it listens to the audio and writes them with Whisper. Then it translates them with the service you choose, and saves everything: watching a film again costs nothing.

Works on Kodi 19 and later (Windows, Mac, Linux, Android boxes, Fire TV).

> **About the interface language.** The add-on's menus and settings are in Italian. In this guide every menu entry and setting is written exactly as it appears in Kodi, in **bold**, followed by its meaning. You can translate into any of 82 languages.

---

## Contents

1. [What it does](#1-what-it-does)
2. [Installing and updating](#2-installing-and-updating)
3. [Getting started (5 minutes)](#3-getting-started-5-minutes)
4. [How to use it](#4-how-to-use-it)
5. [Where the original subtitles come from](#5-where-the-original-subtitles-come-from)
6. [Translation](#6-translation)
7. [Audio transcription (Whisper)](#7-audio-transcription-whisper)
8. [Saving and sharing subtitles](#8-saving-and-sharing-subtitles)
9. [Translating with a chat, without quotas](#9-translating-with-a-chat-without-quotas)
10. [All settings](#10-all-settings)
11. [Troubleshooting](#11-troubleshooting)
12. [Limitations](#12-limitations)

---

## 1. What it does

| Feature | What you get |
|---|---|
| 🎬 **Two lines** | A subtitle file with the original and the coloured translation (or translation only, or translation on top). |
| 📦 **Subtitles inside streamed films** | Reads the subtitle tracks inside streamed .mkv files (Real-Debrid & co.) **without downloading the film**. |
| 🌐 **OpenSubtitles and Kodi services** | If the film has no subtitles, finds them online in the film's language. |
| 🎙️ **Audio transcription** | With Whisper (free with a Groq key), in the right language, resuming where it left off. |
| 🧠 **Translation** | Google (free) or AI models that follow the conversation: Gemini, Groq, Mistral, OpenRouter, Claude, a model on your computer; or Microsoft Translator and DeepL. |
| 🤝 **Human translations** | If the film's subtitles already exist in your language, they're synchronised with the original and used (free). |
| 💾 **Memory** | Every translated line is saved immediately: nothing is translated twice. |
| 🔁 **Backup services** | If a free service runs out of daily requests, the next one takes over automatically. |
| 🌍 **82 languages** | Translates into any language, including Kodi's own. |
| 💬 **With a chat** | Export the text, have ChatGPT/Claude/Gemini translate it, import the answer. |

---

## 2. Installing and updating

The add-on comes in two parts, both included: **Sottotitoli Doppi** (the add-on itself) and **Sottotitoli Doppi** for the player (an entry in the Subtitles menu, to choose them during the film). Install both.

### Installing
1. In Kodi: **Settings → System → Add-ons** and turn on **Unknown sources** (confirm the warning). This allows installing add-ons from a file.
2. Copy the two .zip files to a USB stick or a folder Kodi can see.
3. **Settings → Add-ons → Install from zip file**: first `script.sottotitolidoppi-….zip`, then `service.subtitles.sottotitolidoppi-….zip`.
4. Kodi confirms with a notification in the top-right corner. The add-on is in **Add-ons → Program add-ons → Sottotitoli Doppi**.

### Updating
Install the new version's zip **over** the old one, the same way: settings, translations and saved transcriptions are kept. Don't uninstall the add-on to update it.

### ffmpeg (only for audio transcription)
Kodi doesn't let add-ons read the audio, so transcription needs **ffmpeg**:
- **Windows**: `winget install ffmpeg` (or from gyan.dev). If the add-on doesn't find it, set the path to `ffmpeg.exe` in the settings.
- **Mac**: `brew install ffmpeg`. **Linux**: from your package manager.
- **Android boxes / Fire TV**: ffmpeg usually isn't available: use existing subtitles there.

---

## 3. Getting started (5 minutes)

1. Open the add-on's settings: **Add-ons → Program add-ons → Sottotitoli Doppi** → menu key (or right-click) → **Settings**.
2. **Generale → Traduci in** (*general → translate into*): your language.
3. **Traduzione → Servizio** (*translation → service*): leave **google** to start without keys, or (recommended, free):
   - create a key at **aistudio.google.com/apikey**;
   - choose **gemini** and paste the key into **Chiave Gemini** (*Gemini key*).
4. Start a film that has subtitles in its original language. After a few seconds the dual subtitles appear.

While the add-on is working, **a bar in the top right corner** says what it's doing (for example "Leggo i sottotitoli dentro il video: 120 su 987", *reading the subtitles inside the video: 120 of 987*, then the translation). While the bar is there, there's no need to start it again.

**For films without subtitles**: create a free key at **console.groq.com/keys**, paste it into **Traduzione → Chiave Groq**, install ffmpeg and turn on **Trascrizione → In automatico, se mancano i sottotitoli, trascrivi l'audio** (*transcription → automatically transcribe the audio if subtitles are missing*).

---

## 4. How to use it

### Automatically
With **Generale → Crea i sottotitoli doppi da solo quando parte un video** (*create dual subtitles automatically when a video starts*, on by default), a few seconds after a film starts the add-on finds the original subtitles, translates them **starting from where you are** and loads them into the player. The rest is completed while you watch.

### From the player's subtitle menu
During the film: **Subtitles → Download → Sottotitoli Doppi**. The list shows all the original subtitles found (e.g. "Doppi: danese → italiano · dentro il video: danese", *dual: Danish → Italian · inside the video: Danish*), plus audio transcription. Pick one: it's ready in a few seconds (immediately with Google; with Gemini a quick version first, then the better one by itself). Your choice is remembered for that film.

### From the add-on menu
**Add-ons → Program add-ons → Sottotitoli Doppi**, while the film is playing (you can map it to a remote button with "Keymap Editor"):

| Entry | What it does |
|---|---|
| **Crea i sottotitoli doppi per il video in riproduzione** | *Create dual subtitles for the playing video* — like the automatic mode, right now. |
| **Scegli originale e traduzione per questo video…** | *Choose original and translation for this video* — where the original comes from (automatic, transcription, a specific file) and which translation to use. Remembered for the film. |
| **Scegli i sottotitoli originali da tradurre…** | *Choose the original subtitles to translate* — the list of every original subtitle found (inside the video, downloaded, next to the video, OpenSubtitles, transcription) plus a file on the device: pick one and the translation starts from it right away. |
| **Controlla i sottotitoli dentro il video** | *Check the subtitles inside the video* — shows the film's subtitle tracks and whether they can be read. |
| **Rifai la trascrizione da capo** | *Redo the transcription from scratch* — if one came out wrong. |
| **Rifai la traduzione da capo** | *Redo the translation from scratch* — ignores the saved one and requests everything again (uses quota). |
| **Salva i sottotitoli (.srt)…** | *Save subtitles* — original, translation and dual in a folder ([section 8](#8-saving-and-sharing-subtitles)). |
| **Esporta trascrizione / Importa traduzione (.txt)** | *Export transcription / import translation* — translating with a chat ([section 9](#9-translating-with-a-chat-without-quotas)). |
| **Impostazioni** | *Settings* |

---

## 5. Where the original subtitles come from

**The film's original language always comes first**: the language it was shot in (from the catalogue: declared language or country of production). Among several tracks or files the add-on picks those in that language, even if a dub or another subtitle track is on in the player; in the manual-choice list they come first, marked **(lingua del film)** (*film's language*). Only if the film isn't recognised does it use the audio language reported by Kodi. **Automatically it never translates subtitles in another language** (e.g. those of the Russian dub a German film's file starts with): if it finds none in the film's language it tells you, and you choose from the menu.

Automatically, in this order (for streamed .mkv films it starts from point 2: the tracks inside the video are exactly those of the file you're watching):
1. **Subtitles the film already has**: files next to the video (`Film.en.srt`, also in a `Subs` folder), subtitles provided by the video add-on, subtitles recently downloaded with Kodi add-ons. Those already in your language are skipped.
2. **Inside the video file**:
   - films on the device: text tracks read with ffmpeg;
   - **streamed .mkv films** (The Crew, Real-Debrid…): the add-on reads the file's index and then only the small pieces containing the lines. A few megabytes are enough, without downloading the film and without any account. It picks the track in the language of the subtitles switched on in the player (then the audio's, then the film's) and skips "forced" tracks. The first time takes a while (one request per line: usually a minute or two for a whole film, and the bar in the top right shows the progress); after that they're saved and ready instantly.
3. **Real-Debrid** (HLS streaming): with your Real-Debrid token (taken automatically from ResolveURL, or entered in the settings).
4. **OpenSubtitles**, in the film's audio language (recognised from the IMDb code or the file name), and then the other subtitle services installed in Kodi (e.g. OpenSubtitles.com).

**Syncing with the audio.** Subtitles taken from outside the video (OpenSubtitles, downloaded, a file) are often made for another edition: they start a few seconds early or late, or drift during the film (25 instead of 24 frames per second). The add-on listens to two 90-second stretches of the film, finds where people speak and shifts the subtitles until the lines sit on the voices; if OpenSubtitles has several versions, it keeps the one that fits best. ffmpeg is needed. The first time takes a while (for a streamed film it has to read those two stretches); after that it's saved. Turn it off in **Trascrizione → Metti in fase con l'audio i sottotitoli scaricati** (*sync downloaded subtitles with the audio*).
5. **Audio transcription**, if enabled.

**Choosing by hand**: add-on menu → **Scegli i sottotitoli originali da tradurre…** (*choose the original subtitles to translate*). You get the list of everything found: first the subtitles **inside the video** (*dentro il video*, Real-Debrid ones included), then downloaded ones and OpenSubtitles, the transcription and at the bottom **Scegli un file dal dispositivo…** (*choose a file on the device*). The ones in use now are marked with ►. Pick one and the translation starts from it right away; the choice is remembered for that film. Lines already translated are reused, so switching original doesn't redo everything. The same list also appears in **Scegli originale e traduzione per questo video…** → *File di sottotitoli* and in the player's Subtitles menu.

**Setting "Testo originale da"** (*original text from*, in Trascrizione): *auto* (as above), *trascrizione* (always the audio) or *file* (never transcription).

---

## 6. Translation

### Services
Chosen in **Traduzione → Servizio**; each has its own key in the same section.

| Service | Cost | Notes |
|---|---|---|
| google | free, no key | fair, line by line |
| **gemini** ⭐ | free with key (aistudio.google.com/apikey) | excellent, follows the conversation |
| groq | free with key (console.groq.com/keys) | good and very fast; the same key is used for transcription |
| mistral | free with key (console.mistral.ai) | good, great for European languages |
| openrouter | free with key (":free" models) | variable quality |
| microsoft | free up to 2 million characters a month | accurate classic translator; needs the key and region of an Azure "Translator" F0 resource |
| deepl | free up to a monthly limit | very high |
| claude | paid | excellent |
| local | free | Ollama or LM Studio on your computer |

Lines are translated **in groups of 120** with their neighbours as context (a two-hour film ≈ 12 Gemini requests), starting from where you are. Translations that were copied, shifted or in the wrong language are detected and redone.

### Backup services
With **Se finiscono le richieste gratuite, continua con un altro servizio di cui hai la chiave** (*if free requests run out, continue with another service you have a key for*, on by default), when a service uses up its daily quota the add-on moves to the first other one you've entered a key for: **Gemini → Groq → Mistral → OpenRouter → Microsoft → DeepL**, then **Google**. The exhausted service is skipped until the next day (Gemini quotas reset at midnight Pacific Time).

### Translation memory
Every translated line is saved **immediately**, group by group:
- if you stop the film halfway, next time only the missing lines are translated;
- switching from the transcription to a subtitle file (or back), identical lines aren't translated again;
- each service has its own memory: try Google, go back to Gemini, and Gemini's lines are still there.

In **Scegli originale e traduzione** the entry *"Con Gemini: usa le frasi già tradotte…"* (*use the already translated lines*) tells you how many lines are saved; *"Rifai da capo"* (*redo from scratch*) requests them all again.

### Translation type (setting "Traduzione")
- **auto**: a human translation when the original is a subtitle file and the two versions are in sync, otherwise a new one;
- **nuova** (*new*): always with the chosen service (using the memory);
- **pronta** (*ready-made*): subtitles translated by people, if available;
- **chat**: the one imported from a chat ([section 9](#9-translating-with-a-chat-without-quotas)).

### Human translations
If the film's subtitles exist in your language (a `.it.srt` file next to the video, downloaded ones, OpenSubtitles), the add-on **synchronises** them with the original: it works out the delay and the different speed (25 or 23.976 frames per second) by itself, and re-synchronises if one edition has extra scenes. Under each original line it puts the matching translated one; lines with no match are translated by Google. If the two versions don't line up, they aren't used.

*Note*: subtitles made by people read naturally but are sometimes free or shortened; AI translations are more literal.

### Target language
**Generale → Traduci in**: 82 languages, or **kodi** (Kodi's language), or **altra** (*other*) and type the code or name in **Altra lingua** (e.g. `yue`, `Czech`).

---

## 7. Audio transcription (Whisper)

For films without subtitles, or when you want the exact text of what is said.

**Setup**: Groq key (free, console.groq.com/keys) in **Traduzione → Chiave Groq**, and ffmpeg installed ([section 2](#2-installing-and-updating)). Alternatively: **Trascrizione con → openai** (paid) or **local** (a Whisper server on your computer).

**How it works**:
- the audio is transcribed in 10-minute chunks (a two-hour film ≈ 12 Groq requests);
- the add-on transcribes **the audio track in the film's original language**, not the dub (often the first track in the file), and forces that language on Whisper for every chunk (or the one set in *Lingua parlata*). So Whisper doesn't switch language or write an English translation instead of transcribing;
- if the file has **only dubs** (e.g. only Russian audio for a German film) the add-on won't transcribe it on its own: it tells you, and if you start it by hand it asks whether to transcribe the dub anyway. Better to pick subtitles in the film's language;
- **word timings** make each subtitle start exactly when the voice starts;
- **speech left without subtitles** is listened to again on its own;
- lines invented during music are discarded;
- **more accurate transcription** (on by default): with Groq, whisper-large-v3 is used instead of the turbo version.

**How long it takes**: for a streamed film ffmpeg must read the whole file to extract its audio, so a whole film takes a long time (with a big file even half an hour). If the film has subtitles in its own language, using them is much faster.

**Saving**: the transcription is saved under the film's name (even if Real-Debrid changes the link) and **chunk by chunk**: stop the film halfway and next time it resumes where it was. Watching the film again uses nothing. If a transcription came out wrong: menu → **Rifai la trascrizione da capo**.

---

## 8. Saving and sharing subtitles

Add-on menu → **Salva i sottotitoli (.srt) per riusarli o condividerli…** (*save subtitles to reuse or share*). Saves the last film as three files:
- `Title.en.srt`: the original (including transcriptions);
- `Title.it.srt`: the translation only;
- `Title.doppi.it.srt`: original and translation together.

You can save them **next to the video** (with the video's name: Kodi shows them by itself and the add-on reuses them without redoing anything), in the folder from the settings, or in a folder chosen each time (USB or network too).

Under **Generale** you can choose the folder and turn on **Salva sempre una copia dei sottotitoli** (*always save a copy*).

---

## 9. Translating with a chat, without quotas

1. Add-on menu → **Esporta trascrizione (.txt)** (*export transcription*): writes one or more text files with the numbered lines and instructions (in parts of 250 lines).
2. On your computer open the file, copy everything and paste it into a chat (ChatGPT, Claude, Gemini…).
3. Save the chat's answer as a `.txt` file.
4. Add-on menu → **Importa traduzione (.txt)** (*import translation*): choose the file (several parts at once is fine). The translation is used immediately and stays saved for the film.

---

## 10. All settings

### Generale (*general*)
| Setting | Purpose |
|---|---|
| Crea i sottotitoli doppi da solo quando parte un video | Automatic mode. |
| Traduci in / Altra lingua | Target language ([section 6](#target-language)). |
| Disposizione | Layout: original on top, translation on top, translation only. |
| Cartella dove salvare / Salva sempre una copia | Saving folder / always save a copy ([section 8](#8-saving-and-sharing-subtitles)). |
| Mostra la barra di avanzamento | *Show the progress bar* in the top right while the add-on works. |
| Colore della traduzione | Translation colour in hex, e.g. `FFFF00` yellow, `00FFFF` cyan. |

### Traduzione (*translation*)
| Setting | Purpose |
|---|---|
| Traduzione | auto / nuova / pronta / chat ([section 6](#translation-type-setting-traduzione)). |
| Servizio | The translation service. |
| Token di Real-Debrid | Only for Real-Debrid HLS streaming; empty = ResolveURL's. Not needed to read .mkv files. |
| Se finiscono le richieste gratuite… | Backup services. |
| Keys and models | One box per service; Microsoft also needs the **region**. |

### Trascrizione (Whisper) (*transcription*)
| Setting | Purpose |
|---|---|
| Testo originale da | auto / trascrizione / file. |
| In automatico, se mancano i sottotitoli, trascrivi l'audio | Transcribe films without subtitles automatically. |
| Riascolta le parti con voce rimaste senza sottotitoli | Recover lines skipped by Whisper. |
| Trascrizione più precisa | whisper-large-v3 instead of the turbo version. |
| Trascrizione con | groq / openai / local. |
| Lingua parlata | auto, or the film's language if Whisper gets it wrong. |
| Percorso di ffmpeg | If the add-on can't find it by itself. |
| In automatico usa anche OpenSubtitles.com e gli altri servizi di Kodi | *Also use OpenSubtitles.com and Kodi's other services automatically*: off by default, because every file downloaded through them uses your account's download quota. |
| Metti in fase con l'audio i sottotitoli scaricati | *Sync downloaded subtitles with the audio*: shifts subtitles taken from outside the video until they match the voices ([section 5](#5-where-the-original-subtitles-come-from)). |

---

## 11. Troubleshooting

| What happens | What to do |
|---|---|
| "Non trovo sottotitoli originali" (*can't find original subtitles*) | Menu → **Scegli i sottotitoli originali da tradurre…** and pick from the list or a file on the device; or turn on transcription. **Controlla i sottotitoli dentro il video** shows what's in the film. |
| It uses OpenSubtitles instead of the film's own subtitles | Menu → **Scegli i sottotitoli originali da tradurre…** → the ones "dentro il video" (*inside the video*). If they're not in the list, menu → **Controlla i sottotitoli dentro il video**: if they're "PGS" or images, they aren't text and can't be read. |
| "Letti N sottotitoli su M" (*read N subtitles out of M*) | The streaming server (e.g. Real-Debrid) interrupted reading the subtitles inside the video. Wait a minute and run **Crea i sottotitoli doppi** again: it reads them again and completes them; lines already translated aren't translated again. |
| Subtitles out of sync | Check that **Metti in fase con l'audio i sottotitoli scaricati** is on (ffmpeg needed). If that's not enough, menu → **Scegli i sottotitoli originali da tradurre…** and try another version, or the ones inside the video. For a few tenths of a second there's also Kodi's own subtitle offset (during the film, in the player's subtitle settings: subtitle delay). |
| "Daily quota" notice from OpenSubtitles.com, even though you download nothing | Up to version 1.10.8 this add-on used it up: to look for a ready-made translation it downloaded files through Kodi's OpenSubtitles.com add-on, and each file counts against your account's quota. Since 1.10.9 it no longer does so automatically (setting **In automatico usa anche OpenSubtitles.com…**, off); you can still use it from the manual-choice list. The original subtitles still come from Stremio's OpenSubtitles, which has no quota. |
| "Hai finito i minuti di trascrizione" (*transcription minutes used up*) | Groq's free Whisper quota is used up (hourly or daily): the message says when it frees up. The part already transcribed is saved and continues from there next time. |
| Kodi closes by itself while the add-on is working | Update to the latest version: up to 1.10.9 the progress bar was updated many times a second and from several places at once, and on some computers (Intel graphics drivers) this makes Kodi close, especially when the window is resized or minimised. Now it's updated at most once a second. If it still happens, turn off **Generale → Mostra la barra di avanzamento** (*show the progress bar*) and update the graphics drivers. |
| Transcription in the wrong language | Set **Lingua parlata**, then menu → **Rifai la trascrizione da capo**. |
| "Limite di richieste" or Google used instead of Gemini | Daily quota used up: add keys for other free services (backup) or wait for the reset. |
| ffmpeg not found | Install it and, if needed, set its path in the settings. |

**Kodi's log**: for any problem, the `kodi.log` file contains lines starting with `[Sottotitoli Doppi]` describing what the add-on did and why. On Windows it's in `%APPDATA%\Kodi\kodi.log`, or upload it with the *Kodi Logfile Uploader* add-on.

---

## 12. Limitations

- Kodi shows one subtitle at a time, so the add-on creates a file that already contains both lines. Words can't be hovered as in the browser extension.
- **Image** subtitles (PGS, VobSub, typical of Blu-ray "Remux" files) aren't text: for those films use OpenSubtitles or transcription.
- A streamed .mkv can be read if its index includes the subtitles (almost always); otherwise the whole file would have to be downloaded.
- On devices without ffmpeg (Android boxes, Fire TV) audio can't be transcribed and subtitles inside local files can't be read.

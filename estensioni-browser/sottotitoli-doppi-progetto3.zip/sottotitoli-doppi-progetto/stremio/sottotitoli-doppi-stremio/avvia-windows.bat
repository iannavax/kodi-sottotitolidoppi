@echo off
title Sottotitoli Doppi per Stremio
cd /d "%~dp0"
where node >nul 2>nul || (echo Serve Node.js: scaricalo da https://nodejs.org ^(versione LTS^), poi riapri questo file. & pause & exit /b)
start "" http://127.0.0.1:7000/configure
node server.js
pause

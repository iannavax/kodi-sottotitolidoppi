## Correggere le singole frasi (5.4)

Quando una frase è trascritta o tradotta male, puoi segnalarla e far rifare solo quella.

**Sul video:** passa il mouse sui sottotitoli e clicca la bandierina **⚑** che compare a destra. Si apre una scheda con:
- **↻ Ritraduci:** chiede di nuovo la traduzione di quella frase, con le frasi vicine come contesto. Passa davanti alle altre traduzioni in corso, quindi arriva subito. Se il servizio scelto non dà una traduzione valida, la chiede a Google.
- **🎙 Ritrascrivi** (solo per le frasi trascritte dall'audio, non per i sottotitoli di YouTube): fa riascoltare la frase a Whisper con il modello più preciso (`whisper-large-v3` invece della versione turbo). Se l'audio di quella frase è ancora in memoria (gli ultimi minuti), è immediato. Altrimenti il video torna all'inizio della frase e la riascolta, e la nuova versione compare dopo pochi secondi. La traduzione della nuova frase viene rifatta da sola.
- **✎ Correggi a mano:** scrivi tu l'originale e/o la traduzione giusta. Se correggi solo l'originale, la traduzione viene rifatta da sola.
- **✕ Togli questa frase:** per le frasi inventate, per esempio durante la musica.

**Nella pagina "Trascrizione e traduzione"**, scheda **Frase per frase (e correzioni)**: ogni riga ha gli stessi pulsanti (↻ 🎙 ✎ ✕). Funzionano anche per i file trascritti direttamente dalla pagina, senza video aperto; lì però si può ritradurre, correggere e togliere, non ritrascrivere. Le frasi corrette hanno il segno ✎.

Le correzioni restano salvate con il video, valgono anche nell'esportazione (.txt, .srt) e non vengono sovrascritte nemmeno da "Rifai la traduzione".

Inoltre: la trascrizione dal vivo teneva in memoria l'audio di tutte le frasi, quindi nelle sessioni lunghe il consumo di memoria cresceva senza limite. Ora tiene solo quello degli ultimi minuti.


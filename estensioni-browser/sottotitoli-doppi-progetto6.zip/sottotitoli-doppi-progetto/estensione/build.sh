#!/bin/bash
# Build dell'estensione: crea build/chrome e build/firefox, i LEGGIMI e i pacchetti. Uso: ./build.sh 5.5
set -e; cd "$(dirname "$0")"; V=${1:-5.5}
FILES="han-data.json config.js subs.js media.js tts.js whole.js inject.js live.js ahead.js roman.js words.js ipa.js etym.js learn.js fix.js content.js background.js popup.js popup.html vocab.html vocab.js transcript.html transcript.js helper.html helper.js overlay.css voices-ui.js freq.html freq.js jlpt.html jlpt.js kanji.html kanji.js engines-ui.js"
rm -rf build && for b in chrome firefox; do mkdir -p build/$b/helper build/$b/icons
  for f in $FILES; do cp src/$f build/$b/; done
  cp src/helper/sd_host.py src/helper/install-windows.ps1 src/helper/install-unix.sh build/$b/helper/
  cp src/icons/icon-16.png src/icons/icon-32.png src/icons/icon-48.png src/icons/icon-96.png src/icons/icon-128.png build/$b/icons/
  cp manifest.$b.json build/$b/manifest.json
  { echo "*Versione $V*"; echo; cat GUIDA.md; } > build/$b/LEGGIMI.md
  { echo "*Version $V*"; echo; cat GUIDE.en.md; } > build/$b/GUIDE.en.md
  # changelog for the project only (not in the package)
  { echo "# Sottotitoli Doppi — novità delle versioni"; echo; cat novita521.md novita520.md novita519.md novita518.md novita517.md novita516.md novita515.md novita514.md novita513.md novita512.md novita511.md novita510.md novita59.md novita58.md novita57.md novita56.md novita55.md novita54.md novita53.md novita523.md novita522.md novita52.md novita51.md; } > NOVITA.md
done
for f in build/chrome/*.js; do node --check $f; done
(cd build/chrome && cat config.js subs.js media.js tts.js whole.js live.js ahead.js roman.js words.js ipa.js etym.js learn.js fix.js content.js > /tmp/all.js) && node --check /tmp/all.js
rm -f *.zip *.xpi; (cd build/chrome && zip -rq ../../sottotitoli-doppi-chrome-v$V.zip .); (cd build/firefox && zip -rq ../../sottotitoli-doppi-firefox-v$V.xpi .)
echo "fatto: sottotitoli-doppi-chrome-v$V.zip e sottotitoli-doppi-firefox-v$V.xpi"

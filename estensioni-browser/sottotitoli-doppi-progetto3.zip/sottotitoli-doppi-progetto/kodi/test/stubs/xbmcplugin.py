ITEMS = []
ENDED = []
def addDirectoryItem(handle, url, listitem, isFolder=False): ITEMS.append((url, listitem)); return True
def endOfDirectory(handle, succeeded=True): ENDED.append(handle)

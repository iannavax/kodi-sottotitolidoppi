# 1.6.3: 🔎 «Modi di dire con questa parola» in generale (dizionario + modello), parole cliccabili, errore momentaneo ripetuto
import asyncio, sys, os
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false, hoverPause:true, learnNgram:false, ankiImage:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("market")).click(); await pg.wait_for_timeout(2500)
        await pg.locator(".dualsub-card .dualsub-explainbtn").click()
        await pg.wait_for_selector(".dualsub-card .dsx-iditem", timeout=40000)
        print("1. elenco:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-iditem')].length"), "| pulsanti 🖼:", await pg.locator(".dualsub-card .dsx-idimgbtn").count())
        await pg.locator(".dualsub-card .dsx-idimgbtn").first.click(); await pg.wait_for_timeout(2500)
        print("2. immagini nel modo di dire:", await pg.locator(".dualsub-card .dsx-iditem .dsx-img").count(), "| miniature:", await pg.locator(".dualsub-card .dsx-iditem .dsx-imgthumb").count())
        await pg.locator(".dualsub-card .dsx-iditem .dsx-idsave").first.click(); await pg.wait_for_timeout(2500)
        voc = await sw.evaluate("chrome.storage.local.get('vocab').then(r => Object.values(r.vocab||{}).map(v => [v.word, v.image]))")
        print("3. salvato con immagine:", voc)
        ok = any(w == "went to the market" and im for w, im in voc)
        await pg.keyboard.press("Escape"); await pg.mouse.click(5, 5); await pg.wait_for_timeout(500)
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("went")).click(); await pg.wait_for_timeout(3500)
        print("4. scheda del modo di dire:", await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-card-word')||{}).textContent"), "| selettore immagine:", await pg.locator(".dualsub-card .dsx-img").count())
        ok = ok and await pg.locator(".dualsub-card .dsx-img").count() >= 1
        print("errori:", errs if ok else errs + ["il modo di dire non ha l'immagine"], log["errors"])
        await ctx.close()
asyncio.run(main())

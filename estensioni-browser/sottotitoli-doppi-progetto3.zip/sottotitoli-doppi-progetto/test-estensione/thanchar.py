# 5.19: kanji uno per uno nella scheda della parola (learn.js hanBox, background hanChar, words.js scheda del carattere)
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
T = "(s=>(document.querySelector(s)||{}).textContent||'')"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=jaKanji"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/勉強/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        await pg.locator(".dualsub-orig .dualsub-word", has_text="勉強").first.click()
        await pg.wait_for_selector(".dualsub-card .dsx-hanrow", timeout=8000)
        chips = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-hanchip')].map(b=>b.textContent)")
        print("1. riga dei kanji:", await pg.evaluate(f"{T}('.dualsub-card .dsx-hanrow')"), "| pulsanti:", chips)
        await pg.locator(".dualsub-card .dsx-hanchip", has_text="勉").click()
        await pg.wait_for_function("/tratti/.test((document.querySelector('.dualsub-card .dsx-hanpanel')||{}).textContent||'')", timeout=8000)
        print("2. pannello 勉:", await pg.evaluate(f"{T}('.dualsub-card .dsx-hanpanel')"))
        print("4b.richieste:", log.get("kanjiapi"), log.get("hanchar"))
        await pg.locator(".dualsub-card .dsx-hanpanel .dsx-btn", has_text="lo conosco?").click(); await pg.wait_for_timeout(400)
        print("3. conosciuto:", await sw.evaluate("chrome.storage.local.get('knownWords').then(r=>JSON.stringify(r.knownWords||{}))"),
              "| pulsante:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-hanchip')].map(b=>b.textContent)"))
        await pg.locator(".dualsub-card .dsx-btn", has_text="scheda del carattere").click()
        await pg.wait_for_function("(document.querySelector('.dualsub-card .dualsub-card-word')||{}).textContent==='勉'", timeout=8000)
        await pg.wait_for_function("/tratti/.test((document.querySelector('.dualsub-card .dsx-hanpanel')||{}).textContent||'')", timeout=8000)
        print("4. scheda del carattere:", await pg.evaluate(f"{T}('.dualsub-card .dualsub-card-word')"), "| significato:", await pg.evaluate(f"{T}('.dualsub-card .dualsub-card-meaning')"),
              "| riga pulsanti:", await pg.evaluate("!!document.querySelector('.dualsub-card .dsx-hanrow')"), "| pannello:", (await pg.evaluate(f"{T}('.dualsub-card .dsx-hanpanel')"))[:80])
        print("4b.torna:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-card-link')].map(b=>b.textContent)"),
              "| copia:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-card-replay')].map(b=>b.textContent).slice(0,1)"))
        await pg.locator(".dualsub-card .dualsub-star").click(); await pg.wait_for_timeout(500)
        print("5. ☆ vocabolario:", await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab||{}).map(v=>v.word).join(','))"))
        await pg.locator(".dualsub-card .dualsub-card-link", has_text="Torna alla parola").click()
        await pg.wait_for_function("(document.querySelector('.dualsub-card .dualsub-card-word')||{}).textContent==='勉強'", timeout=8000)
        print("6. tornato a:", await pg.evaluate(f"{T}('.dualsub-card .dualsub-card-word')"), "| aperta:", await pg.evaluate("!!document.querySelector('.dualsub-card .dsx-hanrow')"))
        print("7. richieste ai modelli:", log.get("gem", 0) if isinstance(log.get("gem"), int) else len(log.get("gem", [])), len(log.get("define", [])))
        await sw.evaluate("chrome.storage.sync.set({learnHan:false})"); await pg.wait_for_timeout(500)
        await pg.keyboard.press("Escape"); await pg.wait_for_timeout(200)
        await pg.locator(".dualsub-orig .dualsub-word", has_text="勉強").first.click(); await pg.wait_for_timeout(2500)
        print("8. spento:", await pg.evaluate("!!document.querySelector('.dualsub-card .dsx-hanrow')"), "| scheda:", await pg.evaluate("!!document.querySelector('.dualsub-card')"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

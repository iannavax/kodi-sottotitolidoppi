#!/bin/bash
# uso: cmp.sh prova.py [VAR=val ...]  → esegue con la 5.8.4 e la nuova e mostra le differenze
T=$1; shift
cd /home/claude/e2e
f(){ env "$@" timeout 280 python3 $T $B 2>&1 | grep -v "^  \|Traceback\|TargetClosed\|^Consider\|^before\|^During\|^$\|_impl\|^playwright" ; }
B=/home/claude/old584/chrome f "$@" > /tmp/old_$T.txt
B=/home/claude/sottotitoli-doppi-progetto/estensione/build/chrome f "$@" > /tmp/new_$T.txt
echo "== $T: differenze (< vecchia, > nuova)"; diff /tmp/old_$T.txt /tmp/new_$T.txt | head -30; echo "== nuova:"; tail -6 /tmp/new_$T.txt

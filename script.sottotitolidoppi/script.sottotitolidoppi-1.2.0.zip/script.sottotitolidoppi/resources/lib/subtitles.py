# -*- coding: utf-8 -*-
# Sottotitoli Doppi - voce nel menu dei sottotitoli del lettore.
# Mentre guardi un film: Sottotitoli → Scarica → "Sottotitoli Doppi". L'elenco propone i sottotitoli
# originali che ci sono (file scaricati, file accanto al video, tracce dentro il video); scegliendone uno
# arriva subito la versione doppia tradotta con Google, e se nelle impostazioni hai scelto Gemini (o un altro
# servizio) la traduzione migliore la sostituisce da sola appena è pronta.
import base64
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

from . import core
from . import runner

LANG_NAME = {"en": "English", "it": "Italian", "es": "Spanish", "fr": "French", "de": "German", "pt": "Portuguese",
             "nl": "Dutch", "pl": "Polish", "ro": "Romanian", "ru": "Russian", "uk": "Ukrainian", "tr": "Turkish",
             "ar": "Arabic", "ja": "Japanese", "ko": "Korean", "zh": "Chinese", "el": "Greek", "hu": "Hungarian",
             "cs": "Czech", "sk": "Slovak", "sv": "Swedish", "da": "Danish", "no": "Norwegian", "fi": "Finnish",
             "is": "Icelandic", "he": "Hebrew", "hi": "Hindi", "id": "Indonesian", "th": "Thai", "vi": "Vietnamese",
             "bg": "Bulgarian", "hr": "Croatian", "sr": "Serbian", "sl": "Slovenian", "fa": "Persian", "ms": "Malay",
             "ca": "Catalan", "et": "Estonian", "lv": "Latvian", "lt": "Lithuanian"}
IT_NAME = {"en": "inglese", "it": "italiano", "es": "spagnolo", "fr": "francese", "de": "tedesco", "pt": "portoghese",
           "nl": "olandese", "pl": "polacco", "ro": "rumeno", "ru": "russo", "uk": "ucraino", "tr": "turco", "ar": "arabo",
           "ja": "giapponese", "ko": "coreano", "zh": "cinese", "el": "greco", "hu": "ungherese", "cs": "ceco",
           "sk": "slovacco", "sv": "svedese", "da": "danese", "no": "norvegese", "fi": "finlandese", "is": "islandese",
           "he": "ebraico", "hi": "hindi", "id": "indonesiano", "th": "thailandese", "vi": "vietnamita", "bg": "bulgaro",
           "hr": "croato", "sr": "serbo", "sl": "sloveno", "fa": "persiano", "ms": "malese", "ca": "catalano",
           "et": "estone", "lv": "lettone", "lt": "lituano"}


def _enc(o):
    return base64.urlsafe_b64encode(json.dumps(o).encode("utf-8")).decode("ascii")


def _dec(s):
    return json.loads(base64.urlsafe_b64decode(s.encode("ascii")).decode("utf-8"))


def options(player):
    """Sottotitoli originali disponibili per il video in corso, il più probabile per primo"""
    video = player.getPlayingFile()
    s = runner.settings()
    target = s["target"]
    since = runner.playback_since(player, video)
    prefer = runner.current_sub_lang(player)
    cands = runner.candidates(video)
    best = runner.find_source(player, video, target)
    seen, out = set(), []
    # prima il file che verrebbe scelto da solo, poi gli altri utilizzabili (stesse regole: niente film di prima)
    ordered = ([c for c in cands if c[0] == best] + [c for c in cands if c[0] != best]) if best else cands
    for c in ordered:
        path = c[0]
        if path in seen or not core.pick_subtitle([c], video, target, since=since):
            continue
        seen.add(path)
        lang = core.lang_from_filename(path)
        out.append({"k": "file", "p": path, "l": lang, "name": os.path.basename(path)})
        if len(out) >= 6:
            break
    for idx, lang, codec, _ in runner.embedded_streams(video, s):
        if lang != target:
            out.append({"k": "stream", "i": idx, "l": lang, "name": "traccia del video n. %d (%s)" % (idx, codec)})
    if prefer:
        out.sort(key=lambda o: 0 if o["l"] == prefer else 1)
    return out


def search(handle, player):
    s = runner.settings()
    tname = IT_NAME.get(s["target"], s["target"])
    opts = options(player) if player.isPlayingVideo() else []
    for o in opts:
        src = IT_NAME.get(o["l"], "lingua originale")
        li = xbmcgui.ListItem(label=LANG_NAME.get(s["target"], "Italian"),
                              label2="Doppi: %s → %s · %s" % (src, tname, o["name"]))
        li.setArt({"icon": "5", "thumb": s["target"]})
        li.setProperty("sync", "false")
        li.setProperty("hearing_imp", "false")
        xbmcplugin.addDirectoryItem(handle=handle, url="plugin://script.sottotitolidoppi/?action=download&o=" + _enc(o),
                                    listitem=li, isFolder=False)
    if not opts:
        runner.notify("Sottotitoli Doppi: prima scarica o scegli i sottotitoli originali del film, poi torna qui.", 8000)


def download(handle, player, o):
    """Prepara il file doppio. Con Google è completo in pochi secondi; con un altro servizio
    rispondo subito con Google e lascio lavorare in sottofondo il servizio scelto."""
    s = runner.settings()
    video = player.getPlayingFile()
    target = s["target"]
    path = o["p"] if o["k"] == "file" else runner.extract_stream(video, s, o["i"])
    cues = core.parse_subs(runner.read_text(path))
    if not cues:
        runner.notify("In quei sottotitoli non ho trovato frasi da tradurre.")
        return
    src_lang = core.lang_from_filename(path) or o.get("l") or core.guess_lang_cues(cues)
    src_id = path + "|" + str(len(cues))
    os.makedirs(runner.CACHE, exist_ok=True)
    engine = s["engine"]
    model = s.get(engine + "_model", "")
    best = os.path.join(runner.CACHE, core.cache_key(video, src_id, target, engine, model) + ".json")
    quick = os.path.join(runner.CACHE, core.cache_key(video, src_id, target, "google", "") + ".json")
    upgrade = False
    if os.path.isfile(best):
        trans = json.load(open(best, encoding="utf-8"))["trans"]
    elif os.path.isfile(quick):
        trans = json.load(open(quick, encoding="utf-8"))["trans"]
        upgrade = engine != "google"
    else:
        trans = core.google_translate_fast([c["t"] for c in cues], target, src_lang)
        json.dump({"trans": trans}, open(quick, "w", encoding="utf-8"), ensure_ascii=False)
        upgrade = engine != "google"
    out = os.path.join(runner.CACHE, "%s.doppi.%s.srt" % (core.cache_key(video, src_id, target, "menu"), target))
    open(out, "w", encoding="utf-8").write(core.make_dual_srt(cues, trans, s["layout"], s["trans_color"] or "FFFF00"))
    li = xbmcgui.ListItem(label=out)
    xbmcplugin.addDirectoryItem(handle=handle, url=out, listitem=li, isFolder=False)
    if upgrade:
        # la traduzione con il servizio scelto (Gemini…) continua da sola e sostituisce questa quando è pronta
        xbmc.executebuiltin("RunScript(script.sottotitolidoppi,upgrade,%s)" % _enc({"p": path}))
        runner.notify("Traduzione rapida con Google. Quella con %s arriva da sola tra poco." % engine.capitalize(), 6000)


def main(argv):
    handle = int(argv[1])
    q = dict(urllib.parse.parse_qsl(argv[2].lstrip("?")))
    player = xbmc.Player()
    try:
        if q.get("action") in ("search", "manualsearch"):
            search(handle, player)
        elif q.get("action") == "download" and q.get("o"):
            download(handle, player, _dec(q["o"]))
    except Exception as e:
        runner.log("menu dei sottotitoli: %r" % e)
        runner.notify("Errore: %s" % e, 8000)
    xbmcplugin.endOfDirectory(handle)

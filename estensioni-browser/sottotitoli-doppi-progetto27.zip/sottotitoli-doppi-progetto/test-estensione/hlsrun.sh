#!/bin/sh
# riavvia la diretta HLS finta (la "diretta" ricomincia da capo)
[ -f /tmp/hlsserver.pid ] && kill $(cat /tmp/hlsserver.pid) 2>/dev/null
for p in $(pgrep -f "fake/hls_server.py"); do kill $p; done
sleep 1
cd /home/claude/e2e && python3 fake/hls_server.py 8799 > /tmp/hlsserver.out 2>&1 &
echo $! > /tmp/hlsserver.pid
sleep 2

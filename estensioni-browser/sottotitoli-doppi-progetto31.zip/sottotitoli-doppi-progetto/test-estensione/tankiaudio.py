# 1.6.2/1.6.3: carte di Anki con la pronuncia (madrelingua o sintetica) nel punto giusto; «Rimanda ad Anki» aggiorna invece di duplicare
import asyncio, sys, re
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false, learnNgram:false, ankiAuto:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ankiTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        W = lambda t: words.nth(texts.index(t))
        fr = []
        for w in ["bread", "market"]:
            await W(w).click(); await pg.wait_for_timeout(2500)
            await pg.locator(".dualsub-card .dualsub-star").click()
            for _ in range(30):
                if "Anki" in (await pg.evaluate("(document.querySelector('.dualsub-anki-note')||{}).textContent||''")): break
                await pg.wait_for_timeout(300)
            note = list(log["anki_notes"].values())[-1]
            fr.append(note["Fronte"])
            print(w, "→", note["Fronte"], "|", await pg.evaluate("(document.querySelector('.dualsub-anki-note')||{}).textContent"))
            await pg.keyboard.press("Escape"); await pg.wait_for_timeout(300)
        ok1 = bool(re.search(r"\[sound:sd-bread-rec-\d+\.mp3\]", fr[0])) and bool(re.search(r"\[sound:sd-market-tts-\d+\.mp3\]", fr[1])) and len(log.get("anki_media", [])) >= 2 and "<br><br><i>" in fr[0]
        # spento: niente audio
        await sw.evaluate("chrome.storage.sync.set({ankiAudio:false})"); await pg.wait_for_timeout(300)
        await W("fresh").click() if "fresh" in texts else await W(texts[0]).click()
        await pg.wait_for_timeout(1500); await pg.locator(".dualsub-card .dualsub-star").click(); await pg.wait_for_timeout(2000)
        note = list(log["anki_notes"].values())[-1]
        ok2 = "[sound:" not in note["Fronte"]
        print("spento:", ok2, note["Fronte"][:40])
        await sw.evaluate("chrome.storage.sync.set({ankiAudio:true})")
        # vocabolario: «Manda ad Anki» non duplica le carte che ci sono già; «Rimanda» le aggiorna
        vp = await ctx.new_page(); vp.on("pageerror", lambda e: errs.append("vocab: " + str(e)))
        await sw.evaluate("chrome.storage.local.get('vocab').then(r=>{for(const e of Object.values(r.vocab)) delete e.anki; return chrome.storage.local.set({vocab:r.vocab})})")
        await vp.goto(f"chrome-extension://{eid}/vocab.html"); await vp.wait_for_timeout(800)
        await vp.select_option("#filter", "all"); await vp.wait_for_timeout(300)
        n0 = len(log["anki_notes"])
        await vp.click("#send"); await vp.wait_for_timeout(5000)
        m1 = await vp.inner_text("#ankiMsg")
        ok3 = len(log["anki_notes"]) == n0 and "c'erano già" in m1
        print("manda (già presenti):", ok3, "|", m1)
        await vp.locator(".entry", has=vp.locator(".word", has_text=re.compile("^bread$"))).locator("button", has_text="Rimanda ad Anki").click(); await vp.wait_for_timeout(5000)
        m2 = await vp.inner_text("#ankiMsg")
        up = log.get("anki_updates", [])
        bread = [n for n in log["anki_notes"].values() if "<b>bread</b>" in n["Fronte"]]
        ok4 = len(up) == 1 and len(bread) == 1 and bread[0]["Fronte"].count("[sound:") == 1 and "aggiornata" in m2
        print("rimanda (aggiorna):", ok4, "|", m2, "|", bread[0]["Fronte"][:80])
        print("OK" if ok1 and ok2 and ok3 and ok4 else "NO", ok1, ok2, ok3, ok4)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

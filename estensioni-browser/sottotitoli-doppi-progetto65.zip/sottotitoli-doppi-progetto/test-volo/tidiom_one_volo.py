# 1.6.7: «Spiega con…» chiede nella stessa richiesta anche i modi di dire della frase: nessuna richiesta idiomsFind a parte
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
HL = "CSS.highlights.has('pav-idiom') ? [...CSS.highlights.get('pav-idiom')].map(r=>r.toString()) : []"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "walked", 400)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(200)
        await pg.get_by_role("button", name="Spiega con Groq").click(); await pg.wait_for_timeout(4500)
        print("1. richieste spiegazione:", len(tvolo.log.get("define_idioms", [])), "con modi di dire:", tvolo.log.get("define_idioms"), "| idiomsFind a parte:", len(tvolo.log.get("idiomsFind", [])))
        print(tvolo.log.get("define_user")); print("2. sottolineato:", await pg.evaluate(HL))
        ok = tvolo.log.get("define_idioms") == [True] and not tvolo.log.get("idiomsFind") and "walked home" in await pg.evaluate(HL + ".join('|')")
        print("errori:", errs if ok else errs + ["una sola richiesta non va"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

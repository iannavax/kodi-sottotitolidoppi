# 1.4.3: l'avviso ⏱ sopra i sottotitoli è largo quanto il testo (non quanto la riga corta dei sottotitoli)
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
SHOT = sys.argv[2] if len(sys.argv) > 2 else "/tmp/ttoast.png"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        # riga corta, come «Hi.» in una diretta
        await pg.evaluate("document.querySelector('.dualsub-orig').textContent='Hi.'; document.querySelector('.dualsub-trans') && (document.querySelector('.dualsub-trans').textContent='Ciao.')")
        await pg.evaluate("""(() => { const o = document.querySelector('.dualsub-overlay'); const t = document.createElement('div'); t.className = 'dualsub-toast';
          t.textContent = '⏱ Diretta sincronizzata: il video resta fermo ancora 12 s, così poi resta indietro e i sottotitoli arrivano in tempo.'; o.append(t); })()""")
        await pg.wait_for_timeout(300)
        r = await pg.evaluate("(() => { const t = document.querySelector('.dualsub-toast').getBoundingClientRect(); const o = document.querySelector('.dualsub-overlay').getBoundingClientRect(); return {toast: Math.round(t.width), alto: Math.round(t.height), riga: Math.round(o.width)}; })()")
        print("1. larghezze:", r)
        await pg.screenshot(path=SHOT)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# 1.6.2: pagina dei kanji: scheda accanto (pannello laterale), ✓/☆ veloci sulle caselle, salva nel vocabolario, ✨ spiega con l'LLM, filtro
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it'})")
        kp = await ctx.new_page(); errs = []
        kp.on("pageerror", lambda e: errs.append(str(e)))
        await kp.set_viewport_size({"width": 1300, "height": 800})
        await kp.goto(f"chrome-extension://{eid}/kanji.html?sys=jlpt&level=5&lang=ja&target=it")
        await kp.wait_for_selector(".grid .ch", timeout=10000); await kp.wait_for_timeout(500)
        n = await kp.evaluate("document.querySelectorAll('.grid .ch').length")
        print("1. caselle:", n)
        # scorro e clicco una casella in fondo: la scheda deve essere visibile senza risalire
        last = kp.locator(".grid .ch").nth(n - 3)
        await last.scroll_into_view_if_needed(); ch = (await last.locator("b").text_content()).strip()
        await last.click(); await kp.wait_for_timeout(600)
        vis = await kp.evaluate("(()=>{const r=document.querySelector('#detail').getBoundingClientRect(); return r.top < innerHeight && r.bottom > 0 && r.height > 50})()")
        print("2. scheda di", ch, "visibile accanto:", vis, "|", (await kp.inner_text("#detail")).replace("\n", " | ")[:120])
        await kp.locator("#detail button", has_text="salva nel vocabolario").click(); await kp.wait_for_timeout(1500)
        v = await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab||{}).map(e=>e.word||e.w||''))")
        print("3. salvato dalla scheda:", v, "| pulsante:", await kp.locator("#detail button", has_text="salvato").count())
        # ✓ veloce su un'altra casella
        t2 = kp.locator(".grid .ch").nth(1); c2 = (await t2.locator("b").text_content()).strip()
        await t2.hover(); await t2.locator(".qa button").first.click(); await kp.wait_for_timeout(600)
        kw = await sw.evaluate("chrome.storage.local.get('knownWords').then(r=>(r.knownWords||{}).ja||'')")
        print("4. ✓ veloce su", c2, ":", c2 in kw.split("\n"))
        # filtro
        await kp.select_option("#show", "saved"); await kp.wait_for_timeout(400)
        print("5. filtro salvati:", await kp.evaluate("[...document.querySelectorAll('.grid .ch b')].map(b=>b.textContent)"))
        await kp.select_option("#show", "all"); await kp.wait_for_timeout(300)
        # ✨ spiega
        await kp.locator(".grid .ch", has_text=ch).first.click(); await kp.wait_for_timeout(300)
        await kp.locator("#detail button", has_text="Spiega").click()
        for _ in range(40):
            if "SIGN[" in (await kp.inner_text("#detail")): break
            await kp.wait_for_timeout(500)
        t = await kp.inner_text("#detail")
        print("6. spiegazione:", ("SIGN[" + ch + "]") in t, "| richieste:", log.get("hanexplain"))
        await kp.screenshot(path="/home/claude/e2e/kanjipage2.png")
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

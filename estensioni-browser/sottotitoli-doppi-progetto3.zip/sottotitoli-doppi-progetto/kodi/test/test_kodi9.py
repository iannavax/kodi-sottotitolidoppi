# Prove della 1.10.5: la barra di avanzamento compare subito e mostra la lettura dei sottotitoli dentro il video
import sys, os, json, time, shutil, threading, http.server, socketserver, re, urllib.parse
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
FILM = "/tmp/mkvt/film.mkv"
STATS = {"req": 0, "bytes": 0}
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        if not self.path.startswith("/d/XYZ/"):
            self.send_response(404); self.end_headers(); return
        size = os.path.getsize(FILM)
        m = re.match(r"bytes=(\d+)-(\d*)", self.headers.get("Range", ""))
        a = int(m.group(1)) if m else 0
        b = min(int(m.group(2)) if m and m.group(2) else size - 1, size - 1)
        with open(FILM, "rb") as f:
            f.seek(a); data = f.read(b - a + 1)
        STATS["req"] += 1; STATS["bytes"] += len(data)
        self.send_response(206 if m else 200)
        self.send_header("Content-Length", str(len(data))); self.send_header("Content-Range", "bytes %d-%d/%d" % (a, b, size))
        self.end_headers(); self.wfile.write(data)
srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), H); srv.daemon_threads = True
threading.Thread(target=srv.serve_forever, daemon=True).start()
URL = "http://127.0.0.1:%d/d/XYZ/Festen.1998.Danish.1080p.mkv" % srv.server_address[1]
from resources.lib import core
tr = lambda x: " ".join(w[::-1] for w in x.split())
real_http = core.http
def fake_http(url, data=None, headers=None, timeout=90):
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + tr(l) + "]" for l in q.split("\n")), q]], None, "da"]).encode(), {}
    if "opensubtitles" in url or "cinemeta" in url:
        return 200, b'{"subtitles": [{"id": "1", "url": "https://dl.os.example/1.srt", "lang": "dan"}], "metas": []}', {}
    return 404, b"", {}
core.http = fake_http
from resources.lib import runner, subtitles
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra",
                           "trans_color": "FFFF00", "auto": "true", "source_mode": "auto (file)", "trans_mode": "nuova (x)"})
xbmc.Player.playing = True; xbmc.Player.playing_file = URL; xbmc.Player.subs.clear(); xbmc.Player.sub_lang = "dan"
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": URL, "at": time.time() - 20})
P = xbmc.Player()
xbmcgui.BARS.clear()
runner.save_choice(URL, source="file", pick=runner.mkv_options(URL)[0])
runner.run(P, interactive=True)
ev = [b for b in xbmcgui.BARS]
first = ev[0] if ev else None
reads = [b[3] for b in ev if b[0] == "update" and "Leggo i sottotitoli dentro il video:" in (b[3] if len(b) > 3 else "")]
print("1. prima cosa:", first)
print("   lettura:", reads[:2], "…", reads[-1:] if reads else None, "| aggiornamenti:", len(reads))
print("   chiusa alla fine:", ev[-1] if ev else None, "| una sola barra:", sum(1 for b in ev if b[0] == "create"))
ok1 = first and first[0] == "create" and "Cerco" in first[2] and reads and reads[-1].endswith("40 su 40") and ev[-1] == ["close"]
ok1 = ok1 and sum(1 for b in ev if b[0] == "create") == 1 and xbmcgui.PROPS.get(runner.BUSY_PROP) == ""
# 2. un secondo avvio mentre il primo lavora: avviso, non riparte
xbmcgui.PROPS[runner.BUSY_PROP] = str(time.time() - 5)
xbmcgui.NOTES.clear(); xbmcgui.BARS.clear()
runner.run(P, interactive=True)
print("2. secondo avvio:", xbmcgui.NOTES[-1:], "| barre:", len(xbmcgui.BARS))
ok2 = xbmcgui.NOTES and "già preparando" in xbmcgui.NOTES[-1] and not xbmcgui.BARS
# 3. segno vecchio (Kodi chiuso a metà): non blocca
xbmcgui.PROPS[runner.BUSY_PROP] = str(time.time() - 900)
xbmcgui.BARS.clear(); xbmc.Player.subs.clear()
runner.run(P, interactive=True)
ok3 = bool(xbmc.Player.subs)
print("3. segno vecchio ignorato:", ok3)
# 4. dal menu del lettore (lettura senza run): barra propria
for f in os.listdir(runner.CACHE):
    if f.startswith("mkv2-"): os.remove(os.path.join(runner.CACHE, f))
xbmcgui.BARS.clear()
runner.fetch_mkv(runner.mkv_options(URL)[0], URL)
ev = xbmcgui.BARS
print("4. menu del lettore:", ev[0], "…", ev[-2], ev[-1])
ok4 = ev[0][0] == "create" and "40 su 40" in ev[-2][3] and ev[-1] == ["close"]
print("ESITO:", bool(ok1 and ok2 and ok3 and ok4))
srv.shutdown()

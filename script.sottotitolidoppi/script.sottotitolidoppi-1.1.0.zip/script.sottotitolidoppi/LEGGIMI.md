# Sottotitoli Doppi per Kodi 1.1

## Novità della 1.1
- **Trascrivi l'audio anche se ci sono i sottotitoli.** I sottotitoli scaricati a volte non corrispondono a quello che si sente (versioni diverse del film, frasi riassunte). Ora puoi far trascrivere l'audio in due modi:
  - dal menu dell'add-on: **"Trascrivi l'audio con Whisper (anche se ci sono i sottotitoli)"**, solo per il video che stai guardando;
  - nelle impostazioni, **Trascrizione → "Trascrivi sempre l'audio, anche se ci sono i sottotitoli"**, per tutti i video. Attenzione: ogni film consuma quota di Groq (un film di 2 ore è circa la quota di un'ora).
- **Scelta del servizio di trascrizione**: Groq (gratis con chiave), **OpenAI** (a pagamento, con la sua chiave) oppure un server Whisper sul computer.
- **Repository**: l'add-on si può installare su qualsiasi Kodi (TV box, Fire TV, altri computer) da un indirizzo internet, e si aggiorna da solo. Vedi "Installazione".

Crea un file di sottotitoli **doppio**: in ogni riga c'è l'originale e, sotto, la traduzione in giallo. Kodi lo carica come un normale sottotitolo, quindi funziona con qualsiasi lettore, telecomando e skin.

Richiede Kodi 19 (Matrix) o più recente.

## Installazione dal repository (consigliata, si aggiorna da sola)
Va fatta una volta su ogni dispositivo con Kodi:
1. Kodi → **Impostazioni → Sistema → Add-on**: attiva **Sorgenti sconosciute** (conferma l'avviso).
2. **Impostazioni → File manager → Aggiungi sorgente → <Nessuno>** e scrivi esattamente: `https://iannavax.github.io/kodi-sottotitolidoppi/`. Come nome scrivi `sottotitolidoppi`, poi OK.
3. **Impostazioni → Add-on → Installa da un file zip** → `sottotitolidoppi` → `repository.sottotitolidoppi-1.0.0.zip`.
4. **Installa da repository → Sottotitoli Doppi (repository) → Add-on programmi → Sottotitoli Doppi → Installa**.
5. Apri le impostazioni dell'add-on e scegli lingua e servizio (punto 3 qui sotto).

Gli aggiornamenti arrivano da soli: Kodi controlla il repository e installa le versioni nuove (le impostazioni restano).

## Installazione da file zip (senza internet)
1. Kodi → **Impostazioni → Sistema → Add-on**: attiva **Sorgenti sconosciute**.
2. **Impostazioni → Add-on → Installa da un file zip** e scegli `script.sottotitolidoppi-1.1.0.zip` (installandolo sopra la versione vecchia, le impostazioni restano).
3. Apri le impostazioni dell'add-on (Add-on → Programmi → Sottotitoli Doppi → tasto menu/clic destro → Impostazioni) e scegli la lingua in cui tradurre e il servizio.

## Da dove prende l'originale
In quest'ordine:
1. **Un file di sottotitoli accanto al video**, con lo stesso nome (`Film.en.srt`, `Film.eng.srt`…), anche nelle sottocartelle `Subs`. Vengono esclusi quelli già nella tua lingua.
2. **Sottotitoli scaricati da poco con gli add-on di Kodi** (OpenSubtitles e simili), dalla cartella temporanea di Kodi.
3. **Un file scelto da te**: apri l'add-on mentre il video è in riproduzione e scegli "Scegli un file di sottotitoli…".
4. **La trascrizione dell'audio con Whisper**, se attivata nelle impostazioni (vedi sotto).

Se scegli "Trascrivi sempre l'audio" (o la voce del menu), i sottotitoli dei punti 1 e 2 vengono ignorati e si usa sempre l'audio.

Formati letti: .srt, .vtt, .ass, .ssa.

## Uso
- **In automatico** (predefinito): quando parte un video, dopo pochi secondi l'add-on cerca i sottotitoli e prepara quelli doppi. Parte dal punto in cui stai guardando, quindi li vedi presto, e alla fine li completa.
- **A mano**: apri l'add-on dagli add-on **Programmi** mentre il video è in riproduzione. Puoi anche assegnarlo a un tasto del telecomando con un add-on come "Keymap Editor".
- Ogni video tradotto viene salvato: rivederlo è immediato e non consuma richieste.

## Traduzione
Nelle impostazioni, sezione **Traduzione**:
- **google**: gratis e senza chiave. Traduce riga per riga.
- **gemini** (consigliato): gratis con una chiave da aistudio.google.com/apikey. Traduce con il contesto e resta coerente tra una riga e l'altra.
- **groq**, **openrouter**, **deepl**, **claude**, **local** (Ollama o LM Studio sul computer): come nell'estensione.

Le frasi vengono tradotte a blocchi, con le frasi vicine come contesto. Le traduzioni ricopiate, spostate sotto la riga sbagliata o nella lingua sbagliata vengono riconosciute e rifatte, o tradotte da Google. Se finisce la quota giornaliera di Gemini, l'add-on continua con Google.

## Trascrizione dell'audio
Nelle impostazioni, sezione **Trascrizione (Whisper)**:
- **"Se mancano i sottotitoli, trascrivi l'audio"**: trascrive solo i video senza sottotitoli;
- **"Trascrivi sempre l'audio"**: trascrive tutti i video, anche quelli con i sottotitoli (più fedele a quello che si sente, ma consuma quota);
- **"Trascrizione con"**: **groq** (gratis, chiave su console.groq.com/keys, la stessa della sezione Traduzione), **openai** (a pagamento, chiave e prezzi su platform.openai.com; usa il modello whisper-1), **local** (un server Whisper compatibile sul computer).

Dal menu dell'add-on, "Trascrivi l'audio con Whisper" lo fa per il video in riproduzione anche se le opzioni sono spente. La trascrizione viene salvata: rivedendo il film non si consumano altre richieste. Serve **ffmpeg**, perché Kodi non lascia agli add-on leggere l'audio:
- **Windows**: installalo (per esempio da gyan.dev o con `winget install ffmpeg`) e, se l'add-on non lo trova da solo, indica il percorso di `ffmpeg.exe` nelle impostazioni.
- **Mac**: `brew install ffmpeg`. **Linux**: dal gestore dei pacchetti.
- **Box Android e Fire TV**: di solito ffmpeg non c'è, quindi lì usa i sottotitoli già esistenti.

L'audio viene trascritto in pezzi da 10 minuti; ogni pezzo riconosce la sua lingua. Le frasi inventate da Whisper durante la musica vengono scartate. Un film di due ore richiede circa 12 richieste a Groq.

## Limiti
- Kodi mostra un solo sottotitolo alla volta: per questo l'add-on crea un file che contiene già entrambe le righe. Non si possono cliccare le parole come nell'estensione.
- I sottotitoli incorporati nel file video (per esempio dentro un .mkv) non sono leggibili dagli add-on: servono file di sottotitoli separati, oppure la trascrizione.
- L'add-on è stato provato con simulazioni di Kodi e dei servizi di traduzione, non su un Kodi vero: se qualcosa non va, il registro di Kodi (`kodi.log`) contiene le righe che iniziano con `[Sottotitoli Doppi]`.

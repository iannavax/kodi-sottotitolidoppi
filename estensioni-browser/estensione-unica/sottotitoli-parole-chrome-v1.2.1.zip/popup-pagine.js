let compLang = "";   // lingua della pagina (dal calcolo delle parole conosciute)
const $ = (id) => document.getElementById(id);
let S = {}, keys = {}, site = "";

async function init() {
  S = await PAV_SYNC.get(PAV_DEFAULTS);
  keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
  const sel = $("targetLang");
  for (const c of PAV_TARGETS) sel.append(new Option(pavLangName(c, c === "zh-Hans" ? "zh" : c) + (c !== "it" ? " · " + pavLangName(c) : ""), c));
  if (S.mode === "off") { S.hover = false; S.mode = "hover"; set({ hover: false, mode: "hover" }); }   // prime prove: "niente" = scheda spenta
  for (const id of ["targetLang", "mode", "ttsVoice"]) $(id).value = S[id];
  $("delay").value = String(S.delay);
  const langs = pavSourceLangs();
  $("sourceLang").append(new Option("riconosciuta da sola", ""));
  $("siteLang").append(new Option("come sopra", ""));
  for (const l of langs) { $("sourceLang").append(new Option(l.label, l.code)); $("siteLang").append(new Option(l.label, l.code)); }
  $("sourceLang").value = S.sourceLang || "";
  for (const id of ["on", "hover", "selection", "sentence", "ipa", "etym", "autoSpeak", "ankiAuto"]) $(id).checked = S[id] !== false && !!S[id];
  for (const id of LEARN_KEYS) $(id).checked = id === "ankiImage" || id === "learnKnownPage" || id === "roman" ? S[id] === true : S[id] !== false;
  modeRows();
  $("ankiDeck").value = S.ankiDeck;
  $("ankiPerLang").checked = S.ankiPerLang !== false;
  $("ankiLangDeck").value = S.ankiLangDeck || "Lingue::{lingua}";
  ankiRows();
  try {
    const [tab] = await DS_EXT.tabs.query({ active: true, currentWindow: true });
    site = tab && tab.url && /^https?:/.test(tab.url) ? new URL(tab.url).hostname : "";
  } catch {}
  if (site) {
    $("siteLabel").textContent = "Attiva su " + site; $("siteOn").checked = !(S.disabledSites || []).includes(site);
    $("siteLangLabel").textContent = "Lingua del testo su " + site; $("siteLang").value = (S.siteLang || {})[site] || "";
  } else { $("siteOn").closest(".row").hidden = true; $("siteLangRow").hidden = true; }
  voices();
  comp();
}

// quante parole della pagina conosci (chiesto alla pagina aperta)
const LEARN_KEYS = ["learnFreq", "learnKnown", "learnKnownPage", "savedPage", "idiomAuto", "idiomPage", "roman", "learnExamples", "learnAudio", "learnTable", "learnGender", "learnSpell", "learnLlmExtra", "learnJisho", "learnHan", "gdAlt", "gdDefs", "gdSyn", "gdSpell", "ankiImage"];
async function comp() {
  const el = $("compInfo");
  el.hidden = true;
  if (S.learnKnown === false) return;
  try {
    const [tab] = await DS_EXT.tabs.query({ active: true, currentWindow: true });
    if (!tab || !/^https?:/.test(tab.url || "")) return;
    const r = await DS_EXT.tabs.sendMessage(tab.id, { type: "pavComp" });
    if (r && r.lang && r.lang !== "?") compLang = r.lang;
    if (!r || r.error || !r.total) return;
    el.hidden = false;
    el.textContent = r.mine ? `Conosci il ${r.pct}% delle parole di questa pagina (${r.uniqueKnown} parole diverse su ${r.unique}).`
      : "Segna le parole che conosci («la conosco?» nella scheda): qui vedrai quante parole della pagina conosci.";
  } catch {}
}

function voices() {
  const fill = () => {
    const sel = $("ttsVoice"), cur = S.ttsVoice;
    while (sel.options.length > 2) sel.remove(2);
    for (const v of speechSynthesis.getVoices()) sel.append(new Option(`${v.name} (${v.lang})`, v.voiceURI));
    sel.value = cur;
  };
  if (window.speechSynthesis) { fill(); speechSynthesis.addEventListener("voiceschanged", fill); }
}

const set = (o) => PAV_SYNC.set(o);
for (const id of LEARN_KEYS) $(id).addEventListener("change", (e) => { S[id] = e.target.checked; set({ [id]: e.target.checked }); if (id === "learnKnown") comp(); });
for (const id of ["on", "hover", "selection", "sentence", "ipa", "etym", "autoSpeak", "ankiAuto"]) $(id).addEventListener("change", (e) => { S[id] = e.target.checked; set({ [id]: e.target.checked }); modeRows(); });
// con la scheda spenta non servono "come" e "attesa"
function modeRows() { $("modeRow").hidden = !$("hover").checked; $("delay").closest(".row").hidden = !$("hover").checked; }
// cambiato con la tastiera mentre il popup è aperto
PAV_ONCHANGED.addListener((ch, area) => {
  if (area !== "sync") return;
  for (const id of ["on", "hover", "selection"]) if (ch[id]) $(id).checked = ch[id].newValue !== false;
  modeRows();
});
for (const id of ["targetLang", "mode", "ttsVoice"]) $(id).addEventListener("change", (e) => set({ [id]: e.target.value }));
// servizio di traduzione: stessa sezione di Sottotitoli Doppi (engines-ui.js)
DS_ENGINES_UI.mount($("enginesBox"), {
  store: typeof PAV_SYNC !== "undefined" ? PAV_SYNC : undefined,   // estensione unica: impostazioni di Parole al Volo a parte
  label: "Servizio",
  purpose: (id, E) => E.kind === "google" ? "Tutto con Google: gratis e senza limiti. Per la spiegazione nel contesto («Spiega con…») e «Traduci meglio» scegli Gemini, Groq o un altro modello."
    : E.kind === "openai" || E.kind === "claude" ? `Traduzioni veloci con Google (gratis); con ${E.label.split(" (")[0].split(",")[0]}: «Spiega con…» nella scheda (significato nel contesto, pronuncia se manca, frase tradotta meglio) e «Traduci meglio» nel testo selezionato, una richiesta ogni volta che premi.`
    : `La frase e il testo selezionato li traduce ${E.label.split(" (")[0].split(",")[0]}; il significato della parola resta quello del dizionario di Google.`
});
$("sourceLang").addEventListener("change", (e) => set({ sourceLang: e.target.value }));
$("siteLang").addEventListener("change", async (e) => {
  const s = await PAV_SYNC.get({ siteLang: {} });
  const m = { ...(s.siteLang || {}) };
  if (e.target.value) m[site] = e.target.value; else delete m[site];
  set({ siteLang: m });
});
$("delay").addEventListener("change", (e) => set({ delay: Number(e.target.value) }));
function ankiRows() { const on = $("ankiPerLang").checked; $("ankiLangDeckRow").hidden = !on; $("ankiDeckRow").hidden = on; }
$("ankiPerLang").addEventListener("change", (e) => { S.ankiPerLang = e.target.checked; set({ ankiPerLang: e.target.checked }); ankiRows(); });
$("ankiLangDeck").addEventListener("change", (e) => set({ ankiLangDeck: e.target.value.trim() || "Lingue::{lingua}" }));
$("ankiDeck").addEventListener("change", (e) => set({ ankiDeck: e.target.value.trim() || "Parole al Volo" }));
$("siteOn").addEventListener("change", async (e) => {
  const s = await PAV_SYNC.get({ disabledSites: [] });
  const list = (s.disabledSites || []).filter((h) => h !== site);
  if (!e.target.checked) list.push(site);
  set({ disabledSites: list });
});
document.querySelectorAll("[data-show]").forEach((b) => b.addEventListener("click", (e) => {
  e.preventDefault();
  const inp = $(b.dataset.show);
  inp.type = inp.type === "password" ? "text" : "password";
  b.textContent = inp.type === "password" ? "Mostra" : "Nascondi";
}));
// elenco delle parole più usate (con le parole che conosci) nella lingua della pagina, o in quella con più parole conosciute
$("freqBtn").addEventListener("click", async () => {
  let lang = compLang;
  if (!lang) {
    const kw = (await DS_EXT.storage.local.get({ knownWords: {} })).knownWords || {};
    lang = Object.keys(kw).sort((a, b) => String(kw[b]).split("\n").length - String(kw[a]).split("\n").length)[0] || "en";
  }
  DS_EXT.tabs.create({ url: DS_EXT.runtime.getURL("freq.html") + "?lang=" + encodeURIComponent(String(lang).split("-")[0]) + "&target=" + encodeURIComponent(S.targetLang || "it") });
  window.close();
});
$("vocab").addEventListener("click", () => { DS_EXT.tabs.create({ url: DS_EXT.runtime.getURL("vocab.html") }); window.close(); });
$("ankiTest").addEventListener("click", async () => {
  const st = $("ankiStatus");
  st.className = "small"; st.textContent = "Collego… (se Anki chiede il permesso, premi Yes)";
  const r = await DS_EXT.runtime.sendMessage({ type: "pavAnkiCheck", model: S.ankiModel }).catch((e) => ({ error: String(e.message || e) }));
  if (r && !r.error) { st.className = "small ok"; st.textContent = `Collegato ad Anki (AnkiConnect ${r.version}). Tipo di nota: ${r.model}. Per esempio le parole inglesi vanno nel mazzo «${r.example}».`; }
  else { st.className = "small err"; st.textContent = (r && r.error) || "Nessuna risposta."; }
});
init();

// da dove prendere le immagini per le carte di Anki
(() => {
  const sel = document.getElementById("ankiImageSource");
  if (!sel) return;
  PAV_SYNC.get({ ankiImageSource: "auto" }).then((r) => { sel.value = r.ankiImageSource || "auto"; }).catch(() => {});
  sel.addEventListener("change", () => PAV_SYNC.set({ ankiImageSource: sel.value }));
})();

// ---------- PDF: il lettore del browser non lascia entrare le estensioni, quindi si aprono nel lettore di Parole al Volo ----------
const pavIsPdfUrl = (u) => { try { const x = new URL(u); return /^(https?|file):$/.test(x.protocol) && /\.pdf$/i.test(x.pathname); } catch { return false; } };
(async () => {
  const [tab] = await DS_EXT.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url && pavIsPdfUrl(tab.url)) {
    $("pdfThis").hidden = false;
    $("pdfThis").addEventListener("click", () => { DS_EXT.tabs.update(tab.id, { url: DS_EXT.runtime.getURL("pdf.html") + "?file=" + encodeURIComponent(tab.url) }); window.close(); });
  }
})().catch(() => {});
$("pdfOpen").addEventListener("click", () => { DS_EXT.tabs.create({ url: DS_EXT.runtime.getURL("pdf.html") }); window.close(); });
PAV_SYNC.get({ pdfAuto: false }).then((r) => { $("pdfAuto").checked = !!r.pdfAuto; }).catch(() => {});
$("pdfAuto").addEventListener("change", (e) => PAV_SYNC.set({ pdfAuto: e.target.checked }));

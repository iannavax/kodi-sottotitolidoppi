# Senza sottotitoli di YouTube: Whisper "traduce" in inglese dal 2° pezzo → la lingua resta russa; trascrizione salvata in inglese → rifatta
import asyncio, os, sys, json
os.environ["RU_TRANSLATE"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', hoverPause:false, cleanTranscript:false, sttLang:'', transcribeMode:'live'})
          .then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsRu"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(40000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(4000)
        for r in log.get("ru_req", []): print("  ", r)
        saved = await sw.evaluate("chrome.storage.local.get('live:noCapsRu').then(r=>r['live:noCapsRu'])")
        print("1. salvato:", saved and saved.get("lang"), [c["t"] for c in (saved or {}).get("cues", [])])
        # trascrizione vecchia in inglese di un video con sottotitoli automatici russi: viene buttata e rifatta
        await sw.evaluate("chrome.storage.local.set({'live:ruOld': {lang:'en', cues:[{s:100,e:2500,t:'this is the english translation'},{s:3000,e:5000,t:'another english line here'}], covered:[[0,6000]]}})")
        log["ru_req"] = []
        await pg.goto("https://www.youtube.com/watch?v=ruOld"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/Привет/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        tid = await sw.evaluate("chrome.tabs.query({}).then(t=>t.find(x=>(x.url||'').includes('ruOld')).id)")
        await sw.evaluate(f"chrome.tabs.sendMessage({tid}, {{type:'live', action:'start'}})")
        await pg.evaluate("const v=document.querySelector('video'); v.currentTime=0"); await pg.wait_for_timeout(9000)
        print("2. stato:", await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)"))
        print("   riga:", await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent"), "| richieste:", log.get("ru_req"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

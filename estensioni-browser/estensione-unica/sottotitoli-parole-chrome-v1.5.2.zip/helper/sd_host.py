#!/usr/bin/env python3
# Sottotitoli Doppi - programma di appoggio per yt-dlp.
# Il browser lo avvia da solo (messaggistica nativa) quando l'estensione chiede
# di trascrivere un video intero: scarica solo l'audio con yt-dlp e lo passa
# all'estensione a pezzi. Non tiene niente: il file scaricato viene cancellato subito.
import base64, json, os, re, shutil, struct, subprocess, sys, tempfile, threading, time

VERSION = "1.8"
HERE = os.path.dirname(os.path.abspath(__file__))
WIN = sys.platform.startswith("win")
CHUNK = 600 * 1024          # il browser accetta messaggi fino a 1 MB: 600 KB diventano ~800 KB in base64
UPDATE_EVERY = 3 * 86400    # yt-dlp si aggiorna da solo al massimo ogni 3 giorni

if WIN:
    import msvcrt
    msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
    msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)
NO_WINDOW = 0x08000000 if WIN else 0


# ---------- Messaggi con il browser ----------
def read_msg():
    raw = sys.stdin.buffer.read(4)
    if len(raw) < 4:
        return None
    n = struct.unpack("<I", raw)[0]
    return json.loads(sys.stdin.buffer.read(n).decode("utf-8"))


SEND_LOCK = threading.Lock()


def send(obj):
    data = json.dumps(obj).encode("utf-8")
    with SEND_LOCK:   # la diretta manda l'audio da un altro filo: un messaggio alla volta
        sys.stdout.buffer.write(struct.pack("<I", len(data)))
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()


# ---------- Strumenti ----------
def find_tool(names):
    for n in names:
        p = os.path.join(HERE, n)
        if os.path.isfile(p):
            return p
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return None


def ytdlp_path():
    return os.environ.get("SD_YTDLP") or find_tool(
        ["yt-dlp.exe"] if WIN else ["yt-dlp_macos", "yt-dlp"])


def deno_path():
    return os.environ.get("SD_DENO") or find_tool(["deno.exe"] if WIN else ["deno"]) or \
        (os.path.expanduser("~/.deno/bin/deno") if os.path.isfile(os.path.expanduser("~/.deno/bin/deno")) else None)


def ffmpeg_path():
    return os.environ.get("SD_FFMPEG") or find_tool(["ffmpeg.exe"] if WIN else ["ffmpeg"])


# 1.8: i programmi avviati da qui non ricevono lo stdin del programma di appoggio (è il canale con il browser):
# prima lo ereditavano, e yt-dlp (o Deno, che yt-dlp avvia) poteva bloccarsi o leggerci dentro
def run(cmd, **kw):
    kw.setdefault("stdin", subprocess.DEVNULL)
    return subprocess.run(cmd, capture_output=True, text=True, creationflags=NO_WINDOW, **kw)


def ytdlp_version(y):
    try:
        return run([y, "--version"], timeout=30).stdout.strip()
    except Exception:
        return ""


def maybe_update(y):
    stamp = os.path.join(HERE, ".last-update")
    try:
        if time.time() - os.path.getmtime(stamp) < UPDATE_EVERY:
            return
    except OSError:
        pass
    try:
        open(stamp, "w").close()
        send({"type": "status", "text": "Aggiorno yt-dlp…"})
        run([y, "-U"], timeout=120)
    except Exception:
        pass


def firefox_profile_exists():
    if WIN:
        base = os.path.join(os.environ.get("APPDATA", ""), "Mozilla", "Firefox", "Profiles")
    elif sys.platform == "darwin":
        base = os.path.expanduser("~/Library/Application Support/Firefox/Profiles")
    else:
        base = os.path.expanduser("~/.mozilla/firefox")
    return os.path.isdir(base)


# ---------- Download dell'audio ----------
# Prima l'audio più leggero adatto al parlato (opus), così il file resta piccolo;
# se il sito non separa l'audio, il video più piccolo disponibile.
FORMAT = "ba[acodec^=opus][abr<=90]/ba[acodec^=opus]/ba[ext=m4a]/ba/wv*+wa/w"


def download(url, cookies=False):
    y = ytdlp_path()
    tmp = tempfile.mkdtemp(prefix="sd-")
    cmd = [y, "--no-playlist", "--no-part", "--no-mtime", "--newline", "--no-simulate",
           "-f", FORMAT, "--max-filesize", "600M",
           "-o", os.path.join(tmp, "audio.%(ext)s"),
           "--progress-template", "download:SDPROG %(progress._percent_str)s",
           "--print", "before_dl:SDMETA %(duration)s|%(ext)s|%(title)s",
           "--print", "after_move:SDFILE %(filepath)s"]
    d = deno_path()
    if d:
        cmd += ["--js-runtimes", "deno:" + d]
    if cookies:
        cmd += ["--cookies-from-browser", "firefox"]
    cmd.append(url)

    p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                         encoding="utf-8", errors="replace", creationflags=NO_WINDOW,
                         env=dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1"))
    meta, filepath, last_pct = {}, None, -1
    for line in p.stdout:
        line = line.strip()
        if line.startswith("SDPROG"):
            m = re.search(r"([\d.]+)%", line)
            if m:
                pct = int(float(m.group(1)))
                if pct != last_pct:
                    last_pct = pct
                    send({"type": "progress", "pct": pct})
        elif line.startswith("SDMETA"):
            dur, ext, title = (line[7:].split("|", 2) + ["", "", ""])[:3]
            try:
                meta["duration"] = float(dur)
            except ValueError:
                meta["duration"] = 0
            meta["ext"], meta["title"] = ext, title
            send({"type": "status", "text": "Scarico l'audio…"})
        elif line.startswith("SDFILE"):
            filepath = line[7:].strip()
    err = p.stderr.read()
    p.wait()
    if not filepath or not os.path.isfile(filepath):
        # yt-dlp a volte non stampa il percorso: lo cerco nella cartella temporanea
        files = [os.path.join(tmp, f) for f in os.listdir(tmp)]
        filepath = files[0] if files else None
    return p.returncode, filepath, meta, err, tmp


def friendly_error(err):
    e = err or ""
    if re.search(r"Sign in to confirm|not a bot", e, re.I):
        return "bot", "YouTube chiede di confermare che non sei un robot: apri il video da Firefox con l'account YouTube, oppure riprova più tardi."
    if re.search(r"Private video|members-only|This video is private", e, re.I):
        return "private", "Il video è privato o riservato agli abbonati del canale."
    if re.search(r"HTTP Error 403|403: Forbidden|Forbidden", e, re.I):
        return "forbidden", "YouTube rifiuta di far leggere la diretta (errore 403). Di solito si risolve aggiornando yt-dlp (lo fa da solo una volta al giorno) o riprovando più tardi."
    if re.search(r"Unsupported URL", e, re.I):
        return "unsupported", "yt-dlp non sa scaricare da questo sito."
    if re.search(r"max-filesize|larger than max", e, re.I):
        return "toobig", "Il file è troppo grande (oltre 600 MB)."
    if re.search(r"JavaScript runtime|jsc|challenge", e, re.I):
        return "js", "yt-dlp non riesce a risolvere i controlli di YouTube: serve Deno aggiornato (rilancia l'installatore)."
    lines = [l for l in e.strip().splitlines() if "ERROR" in l] or e.strip().splitlines()[-1:]
    return "failed", (lines[-1] if lines else "yt-dlp non è riuscito a scaricare l'audio.")[:300]


def cmd_audio(msg):
    y = ytdlp_path()
    if not y:
        send({"type": "error", "code": "noytdlp", "message": "yt-dlp non è installato: rilancia l'installatore."})
        return
    maybe_update(y)
    send({"type": "status", "text": "Cerco l'audio del video…"})
    code, path, meta, err, tmp = download(msg["url"])
    if (not path) and re.search(r"Sign in to confirm|not a bot", err or "", re.I) and firefox_profile_exists():
        send({"type": "status", "text": "YouTube chiede una conferma: riprovo con i cookie di Firefox…"})
        shutil.rmtree(tmp, ignore_errors=True)
        code, path, meta, err, tmp = download(msg["url"], cookies=True)
    try:
        if not path:
            c, m = friendly_error(err)
            send({"type": "error", "code": c, "message": m})
            return
        size = os.path.getsize(path)
        ext = os.path.splitext(path)[1].lstrip(".") or meta.get("ext", "")
        send({"type": "meta", "size": size, "ext": ext, "title": meta.get("title", ""),
              "duration": meta.get("duration", 0)})
        with open(path, "rb") as f:
            seq = 0
            while True:
                block = f.read(CHUNK)
                if not block:
                    break
                send({"type": "chunk", "seq": seq, "data": base64.b64encode(block).decode("ascii")})
                seq += 1
        send({"type": "done", "chunks": seq})
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------- Diretta in anticipo ----------
# yt-dlp legge la diretta dal punto più recente e ffmpeg la trasforma in audio semplice (16 kHz, mono): l'estensione
# riceve un secondo alla volta, lo trascrive e mostra i sottotitoli quando il video (tenuto qualche secondo indietro)
# arriva lì. Niente viene salvato su disco. Si ferma quando l'estensione chiude il collegamento o manda "stop".
LIVE_FORMAT = "ba/91/92/93/w"
LIVE = {"stop": None, "procs": []}


def live_stop():
    if LIVE["stop"]:
        LIVE["stop"].set()
    for p in LIVE["procs"]:
        try:
            p.kill()
        except Exception:
            pass
    LIVE["procs"] = []


def _tail(fh, n=3):
    """Ultime righe scritte da un programma (stderr in un file temporaneo condiviso con il programma stesso)."""
    try:
        fh.seek(0)
        lines = [l.strip() for l in fh.read().decode("utf-8", "replace").splitlines() if l.strip()]
        return " | ".join(lines[-n:])[:300]
    except Exception:
        return ""
    finally:
        try:
            fh.seek(0, 2)   # il file è condiviso con il programma: rimetto la posizione in fondo
        except Exception:
            pass


def _kill(procs):
    for p in procs:
        _kill_tree(p)


def _kill_tree(p):
    """Chiude il programma e quelli che ha avviato (yt-dlp avvia Deno): su Windows chiudere solo yt-dlp lasciava Deno
    vivo con le uscite aperte, e chi aspettava la risposta restava bloccato per sempre (1.8)."""
    try:
        if p.poll() is not None:
            return
        if WIN:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, creationflags=NO_WINDOW, timeout=10)
        p.kill()
    except Exception:
        pass


def _pump(ff, procs, errf, stop, label, pos0, say_at, give_up):
    """Legge l'audio (16 kHz mono s16le) da ff.stdout e lo manda all'estensione, un secondo alla volta.
    Se per give_up secondi non arriva niente ferma i programmi; a say_at secondi dice cosa sta succedendo
    (con le ultime righe dei messaggi). Restituisce (pezzi mandati, posizione)."""
    started = time.time()
    st = {"sent": 0}

    def watchdog():
        said = False
        while not stop.is_set() and st["sent"] == 0 and not st.get("done"):
            time.sleep(2)
            if st["sent"] or stop.is_set() or st.get("done"):
                return   # (1.7: anche quando questa strada è finita: prima il suo messaggio arrivava durante la strada dopo)
            waited = time.time() - started
            if waited > say_at and not said:
                said = True
                last = _tail(errf)
                send({"type": "status", "text": f"Diretta: {label} non manda ancora l'audio ({int(waited)} s)" + (": " + last if last else ", nessun messaggio") + "."})
            if waited > give_up:
                _kill(procs)
                return
    threading.Thread(target=watchdog, daemon=True).start()
    pos = pos0
    while not stop.is_set():
        block = ff.stdout.read(32000)          # un secondo di audio
        if not block:
            break
        if st["sent"] == 0:
            send({"type": "status", "text": "Diretta: leggo l'audio in anticipo" + (" (" + label + ")" if label != "yt-dlp" else "") + "."})
        send({"type": "pcm", "pos": pos, "rate": 16000, "data": base64.b64encode(block).decode("ascii")})
        pos += len(block) // 2
        st["sent"] += 1
    st["done"] = True
    _kill(procs)
    return st["sent"], pos


def _ytdlp_base(cookies):
    cmd = [ytdlp_path(), "--no-playlist"]
    d = deno_path()
    if d:
        cmd += ["--js-runtimes", "deno:" + d]
    if cookies:
        cmd += ["--cookies-from-browser", "firefox"]
    return cmd


FF_PCM = ["-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "pipe:1"]


def _hls_variant(hls):
    """Dalla playlist principale HLS di YouTube la variante più leggera (basta l'audio): meno dati da scaricare."""
    try:
        import urllib.request
        with urllib.request.urlopen(urllib.request.Request(hls, headers={"User-Agent": "Mozilla/5.0"}), timeout=15) as r:
            text = r.read().decode("utf-8", "replace")
    except Exception as e:
        return "", f"playlist HLS non leggibile: {e}"
    if "#EXT-X-STREAM-INF" not in text:
        return hls, ""
    best, bw, lines = "", None, text.splitlines()
    for i, l in enumerate(lines):
        if l.startswith("#EXT-X-STREAM-INF"):
            m = re.search(r"BANDWIDTH=(\d+)", l)
            nxt = next((x.strip() for x in lines[i + 1:] if x.strip() and not x.startswith("#")), "")
            if nxt and (bw is None or (m and int(m.group(1)) < bw)):
                best, bw = nxt, int(m.group(1)) if m else bw
    if best and not best.startswith("http"):
        from urllib.parse import urljoin
        best = urljoin(hls, best)
    return best or hls, ""


def _ffmpeg_live(src, stop, label, say_at, give_up):
    f = ffmpeg_path()
    err_f = tempfile.TemporaryFile()
    ff = subprocess.Popen([f, "-hide_banner", "-loglevel", "warning"] + (["-re"] if src.startswith("file:") else []) + ["-i", src] + FF_PCM, stdin=subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=err_f, creationflags=NO_WINDOW)
    LIVE["procs"] = [ff]
    sent, pos = _pump(ff, [ff], err_f, stop, label, 0, say_at, give_up)
    return sent, label + ": " + (_tail(err_f, 3) or "nessun messaggio")


HLS_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36"


def _http_get(url, timeout=15):
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": HLS_UA, "Origin": "https://www.youtube.com",
                                               "Referer": "https://www.youtube.com/"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(), r.headers.get("Content-Type", "")


def _hls_feed(src, out, stop, note):
    """Legge la playlist HLS della diretta e i suoi pezzi con Python e li passa a ffmpeg (stdin).
    1.5 dava l'indirizzo direttamente a ffmpeg, ma le versioni nuove di ffmpeg rifiutano le playlist di YouTube
    (registro di un utente: «Invalid data found when processing input»): così ffmpeg vede solo l'audio/video."""
    from urllib.parse import urljoin
    last, fails, init_done = None, 0, False
    got, refused = 0, 0   # pezzi arrivati / rifiutati (403) prima del primo arrivato
    try:
        while not stop.is_set():
            try:
                body, ctype = _http_get(src)
                fails = 0
            except Exception as e:
                fails += 1
                note(f"playlist: {e}")
                if fails >= 4:
                    return
                time.sleep(2)
                continue
            text = body.decode("utf-8", "replace")
            if not text.lstrip().startswith("#EXTM3U"):
                note(f"la playlist non è HLS ({ctype or 'tipo sconosciuto'}): {text[:80]!r}")
                return
            seq, target, segs, init, ended = 0, 4.0, [], None, False
            for l in text.splitlines():
                l = l.strip()
                if l.startswith("#EXT-X-MEDIA-SEQUENCE:"):
                    seq = int(re.sub(r"\D", "", l.split(":", 1)[1]) or 0)
                elif l.startswith("#EXT-X-TARGETDURATION:"):
                    try:
                        target = float(l.split(":", 1)[1])
                    except ValueError:
                        pass
                elif l.startswith("#EXT-X-MAP:"):
                    m = re.search(r'URI="([^"]+)"', l)
                    init = m and m.group(1)
                elif l.startswith("#EXT-X-ENDLIST"):
                    ended = True
                elif l and not l.startswith("#"):
                    segs.append((seq + len(segs), l))
            if not segs:
                note("la playlist non ha pezzi")
                return
            if last is None:
                last = segs[max(0, len(segs) - 3)][0] - 1   # come ffmpeg: si parte 3 pezzi prima della fine
            if init and not init_done:
                out.write(_http_get(urljoin(src, init))[0])
                init_done = True
            for n, uri in segs:
                if stop.is_set():
                    return
                if n <= last:
                    continue
                try:
                    data = _http_get(urljoin(src, uri), 30)[0]
                except Exception as e:
                    note(f"pezzo {n}: {e}")
                    last = n
                    # 1.7: YouTube rifiuta i pezzi (403: all'indirizzo del lettore web manca il «gettone» che il lettore
                    # aggiunge da sé). Inutile aspettare: mi fermo subito e si passa alla strada successiva
                    if not got and "403" in str(e):
                        refused += 1
                        if refused >= 3:
                            note("YouTube rifiuta i pezzi di questo indirizzo (403)")
                            return
                    continue
                got += 1
                out.write(data)
                out.flush()
                last = n
            if ended:
                return
            stop.wait(max(1.0, min(target / 2, 5.0)))
    except (BrokenPipeError, OSError, ValueError):
        pass   # ffmpeg chiuso
    finally:
        try:
            out.close()
        except Exception:
            pass


def _hls_live(src, stop, label, say_at, give_up):
    """Piano 0: Python scarica la diretta HLS, ffmpeg tira fuori solo l'audio."""
    f = ffmpeg_path()
    err_f = tempfile.TemporaryFile()
    ff = subprocess.Popen([f, "-hide_banner", "-loglevel", "warning", "-i", "pipe:0"] + FF_PCM,
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err_f, creationflags=NO_WINDOW)
    LIVE["procs"] = [ff]
    notes = []

    def note(t):
        notes.append(t)
        try:
            os.write(err_f.fileno(), (t + "\n").encode("utf-8", "replace"))
        except Exception:
            pass
    threading.Thread(target=_hls_feed, args=(src, ff.stdin, stop, note), daemon=True).start()
    sent, pos = _pump(ff, [ff], err_f, stop, label, 0, say_at, give_up)
    return sent, label + ": " + (_tail(err_f, 3) or "nessun messaggio")


# 1.8: l'indirizzo della diretta dato da «yt-dlp -g» (lento la prima volta: 10-30 s) resta ricordato per qualche ora,
# così riaprendo la stessa diretta, o riaccendendo ⏱, l'audio parte subito
LIVE_URLS = os.path.join(HERE, "live-urls.json")
G_TIMEOUT = float(os.environ.get("SD_G_TIMEOUT") or 60)   # (più corto nelle prove)


def _live_url_cached(url):
    try:
        d = json.load(open(LIVE_URLS, encoding="utf-8"))
        x = d.get(url)
        if x and time.time() - x[1] < 4 * 3600:
            return x[0]
    except Exception:
        pass
    return ""


def _live_url_save(url, hls):
    try:
        d = json.load(open(LIVE_URLS, encoding="utf-8")) if os.path.exists(LIVE_URLS) else {}
    except Exception:
        d = {}
    d = {k: v for k, v in d.items() if time.time() - v[1] < 4 * 3600}
    if hls:
        d[url] = [hls, time.time()]
    else:
        d.pop(url, None)
    try:
        json.dump(d, open(LIVE_URLS, "w", encoding="utf-8"))
    except Exception:
        pass


def _ytdlp_g(url, cookies, box):
    """yt-dlp -g in un filo a parte (parte subito, insieme al piano 0): mette in box l'indirizzo o l'errore, e in
    box["last"] l'ultima riga scritta da yt-dlp (-v: si vede nel registro dove si ferma). Al massimo 60 s, poi lo chiudo
    con tutto quello che ha avviato (1.7 usava subprocess.run(timeout=45): su Windows restava bloccato per sempre)."""
    lines = []
    try:
        p = subprocess.Popen(_ytdlp_base(cookies) + ["-v", "-g", "-f", "ba/91/92/93/94/95/96/b", url], stdin=subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace",
                             creationflags=NO_WINDOW, env=dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1"))
        out = []
        def read_err():
            for l in p.stderr:
                l = l.strip()
                if l:
                    lines.append(l)
                    box["last"] = l[:200]
        def read_out():
            for l in p.stdout:
                out.append(l.strip())
        te = threading.Thread(target=read_err, daemon=True); te.start()
        to = threading.Thread(target=read_out, daemon=True); to.start()
        try:
            p.wait(timeout=G_TIMEOUT)
        except subprocess.TimeoutExpired:
            _kill_tree(p)
            box["err"] = f"yt-dlp -g: nessuna risposta in {int(G_TIMEOUT)} s (ultima riga: " + (box.get("last") or "nessuna") + ")"
        to.join(2); te.join(2)
        box["hls"] = next((l for l in out if re.match(r"(https?|file):", l)), "")
        if not box["hls"] and not box.get("err"):
            errs = [l for l in lines if "ERROR" in l] or lines[-1:]
            box["err"] = "yt-dlp -g: " + ((errs[-1] if errs else "nessun indirizzo")[:200])
    except Exception as e:
        box["err"] = f"yt-dlp -g: {e}"
    box["done"].set()


def live_run(url, cookies, stop, hls=""):
    """Ordine (1.7): piano 0 (indirizzo HLS del lettore, si ferma subito se YouTube rifiuta i pezzi con 403), piano B
    (indirizzo dato da yt-dlp -g, letto da Python), piano A (yt-dlp scarica e passa a ffmpeg). Storia: piano A da solo: Prima yt-dlp girava con --quiet --no-warnings e,
    quando YouTube rifiutava i pezzi, restava muto senza dire niente (registro di un utente: 4 minuti senza audio).
    1.6: la causa vera era ffmpeg: le versioni nuove rifiutano i pezzi di YouTube (indirizzi senza «.ts»: «not in
    allowed_segment_extensions» → «Invalid data found»), e yt-dlp per le dirette usa proprio ffmpeg. Ora nei piani 0 e B
    la playlist e i pezzi li scarica Python (_hls_feed) e ffmpeg tira fuori solo l'audio."""
    f = ffmpeg_path()
    msgs = []
    # yt-dlp -g parte subito, insieme al piano 0 (se l'indirizzo non è già ricordato): prima partiva solo dopo
    gbox = {}
    if not _live_url_cached(url) or cookies:
        gbox["done"] = threading.Event()
        threading.Thread(target=_ytdlp_g, args=(url, cookies, gbox), daemon=True).start()
    # --- piano 0: l'indirizzo HLS che il lettore di YouTube ha già (dall'estensione), letto da ffmpeg senza yt-dlp
    if hls and not cookies:
        send({"type": "status", "text": "Diretta: leggo l'audio con ffmpeg dall'indirizzo del lettore di YouTube…"})
        src, why = (hls, "") if hls.startswith("file:") else _hls_variant(hls)
        if src:
            live = _ffmpeg_live if src.startswith("file:") else _hls_live   # file: solo nelle prove
            sent, m = live(src, stop, "indirizzo del lettore", 10, 25)
            if sent or stop.is_set():
                return sent, m
            msgs.append(m)
        else:
            msgs.append(why)
        send({"type": "status", "text": "Diretta: l'indirizzo del lettore non dà audio, provo con yt-dlp…"})
    # --- piano B: l'indirizzo della diretta dato da yt-dlp (ricordato, o cercato in un filo partito all'inizio)
    for attempt in (1, 2):
        hls_b = _live_url_cached(url) if attempt == 1 and not cookies else ""
        if not hls_b:
            if not gbox:
                gbox.update({"done": threading.Event()}); threading.Thread(target=_ytdlp_g, args=(url, cookies, gbox), daemon=True).start()
            t0, said = time.time(), 0
            while not gbox["done"].wait(1):
                if stop.is_set():
                    return 0, ""
                n = int(time.time() - t0)
                if n >= said + 10:
                    said = n
                    send({"type": "status", "text": f"Diretta: yt-dlp sta ancora cercando l'indirizzo della diretta ({n} s; la prima volta può volerci mezzo minuto)…" + (" Ultima riga: " + gbox["last"] if gbox.get("last") else "")})
            hls_b = gbox.get("hls", "")
            if not hls_b:
                msgs.append(gbox.get("err", "yt-dlp -g: nessun indirizzo"))
                # yt-dlp vecchio è la causa più comune: lo aggiorno (al massimo ogni 3 giorni) e riprovo una volta
                if attempt == 1 and not cookies:
                    maybe_update(ytdlp_path())
                    gbox.clear()
                    continue
                break
            _live_url_save(url, hls_b)
        if stop.is_set():
            return 0, ""
        send({"type": "status", "text": "Diretta: leggo l'audio dall'indirizzo dato da yt-dlp…"})
        sent, m = _ffmpeg_live(hls_b, stop, "indirizzo di yt-dlp", 12, 30) if hls_b.startswith("file:") else _hls_live(_hls_variant(hls_b)[0] or hls_b, stop, "indirizzo di yt-dlp", 12, 30)
        if sent or stop.is_set():
            return sent, m
        msgs.append(m)
        _live_url_save(url, "")   # indirizzo scaduto o rifiutato: lo dimentico e (al primo giro) ne chiedo uno nuovo
        gbox.clear()
        if attempt == 2:
            break
    # --- piano A (ultimo): yt-dlp scarica la diretta e la passa a ffmpeg (con i ffmpeg nuovi di solito resta muto)
    send({"type": "status", "text": "Diretta: provo a far scaricare la diretta a yt-dlp…"})
    err_y = tempfile.TemporaryFile()
    # -v: ogni passo di yt-dlp nei messaggi (con le dirette che si bloccano senza dire niente si vede dove si ferma)
    cmd = _ytdlp_base(cookies) + ["-v", "--no-part", "--no-progress", "-f", LIVE_FORMAT, "-o", "-", "--ffmpeg-location", f, url]
    yt = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=err_y, creationflags=NO_WINDOW)
    ff = subprocess.Popen([f, "-hide_banner", "-loglevel", "error", "-i", "pipe:0"] + FF_PCM, stdin=yt.stdout,
                          stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
    yt.stdout.close()
    LIVE["procs"] = [yt, ff]
    sent, pos = _pump(ff, [yt, ff], err_y, stop, "yt-dlp", 0, 12, 25)
    msgs.append(_tail(err_y, 4))
    return sent, " | ".join(x for x in msgs if x)


def cmd_live(msg):
    y, f = ytdlp_path(), ffmpeg_path()
    if not y:
        send({"type": "error", "code": "noytdlp", "message": "yt-dlp non è installato: rilancia l'installatore."})
        return
    if not f:
        send({"type": "error", "code": "noffmpeg", "message": "manca ffmpeg (serve per le dirette sincronizzate): rilancia l'installatore."})
        return
    stop = threading.Event()
    LIVE["stop"] = stop

    def work():
        try:
            sent, err = live_run(msg["url"], False, stop, msg.get("hls", ""))
            if not sent and not stop.is_set() and re.search(r"Sign in to confirm|not a bot", err, re.I) and firefox_profile_exists():
                send({"type": "status", "text": "YouTube chiede una conferma: riprovo con i cookie di Firefox…"})
                sent, err = live_run(msg["url"], True, stop)
            if stop.is_set():
                return
            if not sent:
                c, m = friendly_error(err)
                send({"type": "error", "code": c, "message": m})
            else:
                send({"type": "done"})
        except Exception as e:
            send({"type": "error", "code": "crash", "message": f"errore nella lettura della diretta: {e}"})
    threading.Thread(target=work, daemon=True).start()


def main():
    while True:
        msg = read_msg()
        if msg is None:
            live_stop()   # l'estensione ha chiuso il collegamento: fermo yt-dlp e ffmpeg
            return
        try:
            if msg.get("cmd") == "ping":
                y = ytdlp_path()
                send({"type": "pong", "version": VERSION, "ytdlp": ytdlp_version(y) if y else "",
                      "deno": bool(deno_path()), "ffmpeg": bool(ffmpeg_path()), "platform": sys.platform})
            elif msg.get("cmd") == "audio":
                cmd_audio(msg)
            elif msg.get("cmd") == "live":
                live_stop()
                cmd_live(msg)
            elif msg.get("cmd") == "stop":
                live_stop()
            else:
                send({"type": "error", "code": "unknown", "message": "comando sconosciuto"})
        except Exception as e:
            send({"type": "error", "code": "crash", "message": f"errore del programma di appoggio: {e}"})


if __name__ == "__main__":
    main()

# Parole al Volo con molte lingue e alfabeti: parola trovata sotto il mouse, IPA chiesta in automatico,
# pulsante "Mostra la pronuncia IPA" che funziona anche quando il modello salta la parola o cambia le chiavi
import asyncio, os, sys, json, re, urllib.parse
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
L = [  # (id, lang, testo, parola)
  ("zh", "zh", "我喜欢学习中文。", "学习"), ("ja", "ja", "日本語を勉強しています。", "勉強"), ("ko", "ko", "저는 한국어를 공부해요.", "공부해요"),
  ("ar", "ar", "أنا أحب القراءة كثيرا.", "القراءة"), ("he", "he", "אני אוהב ללמוד עברית.", "ללמוד"), ("el", "el", "Μου αρέσει πολύ το διάβασμα.", "διάβασμα"),
  ("th", "th", "ฉันชอบเรียนภาษาไทยมาก", "เรียน"), ("hi", "hi", "मुझे किताबें पढ़ना पसंद है।", "किताबें"), ("ru", "ru", "Я люблю читать книги.", "читать"),
  ("uk", "uk", "Я дуже люблю читати.", "читати"), ("cs", "cs", "Příliš žluťoučký kůň úpěl ďábelské ódy.", "žluťoučký"), ("da", "da", "Jeg spiser rødgrød med fløde.", "rødgrød"),
  ("de", "de", "Wir gehen über die Straße.", "Straße"), ("vi", "vi", "Tiếng Việt rất hay và đẹp.", "Việt"), ("tr", "tr", "Bu kitap çok güzel ığdır.", "güzel"),
]
SCRIPT = {"zh": "[一-鿿]", "ja": "[぀-ヿ]", "ko": "[가-힯]", "ar": "[؀-ۿ]", "he": "[֐-׿]", "el": "[Ͱ-Ͽ]",
          "th": "[฀-๿]", "hi": "[ऀ-ॿ]", "ru": "[а-яё]", "uk": "[іїєґ]|люблю|читати"}
TARGET = {w for _, _, _, w in L}
calls = {}
def lang_of(t):
    for _, l, txt, w in L:
        if t and (t in txt or txt in t): return l
    return "en"
orig_handle = tvolo.handle
async def handle(route, request):
    url = request.url
    if url.startswith("https://example.test/"):
        body = "<!doctype html><html lang='en'><head><meta charset='utf-8'></head><body style='margin:40px;font:20px/2 sans-serif'>" + \
            "".join(f"<p id='{i}' lang='{l}' dir='{'rtl' if l in ('ar','he') else 'ltr'}'>{t}</p>" for i, l, t, _ in L) + "</body></html>"
        return await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=body)
    if url.startswith("https://translate.googleapis.com/translate_a/single"):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query); text = q.get("q", [""])[0]
        l = lang_of(text)
        parts = [["IT[" + text + "]", text]]
        if "rm" in q.get("dt", []) and l not in ("cs", "da", "de", "vi", "tr"): parts.append([None, None, None, "latin(" + text + ")"])
        return await route.fulfill(status=200, content_type="application/json", body=json.dumps([parts, [["nome", ["x"]]] if "bd" in q.get("dt", []) else None, l]))
    if url.startswith("https://api.groq.com/openai/v1/chat"):
        p = json.loads(request.post_data or "{}"); words = json.loads(p["messages"][1]["content"])["words"]
        l = lang_of(" ".join(words)) if words else "en"
        key = next((w for w in words if w in TARGET), None) or (words[0] if words else "")
        n = calls[key] = calls.get(key, 0) + 1
        if n == 1:   # la prima volta il modello salta la parola puntata
            ans = {w: "ipa-" + w for w in words if w not in TARGET}
        else:        # poi la dà, ma con chiavi diverse (traslitterate), nello stesso ordine
            ans = {"k" + str(i): "ipa-" + w for i, w in enumerate(words)}
        content = json.dumps({"ipa": ans}, ensure_ascii=False)
        return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": content}}]}))
    return await orig_handle(route, request)

async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', engine:'groq'}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/lingue.html"); await pg.wait_for_timeout(800)
        ok_all = True
        for pid, l, txt, w in L:
            await pg.evaluate("(id) => document.getElementById(id).scrollIntoView({block: 'center'})", pid); await pg.wait_for_timeout(300)
            await tvolo.hover(pg, pid, w, 3500)
            word = await pg.evaluate("(document.querySelector('.pav-word')||{}).textContent")
            auto = await pg.evaluate("(document.querySelector('.pav-card .pav-ipa')||{}).textContent")
            tr = await pg.evaluate("(document.querySelector('.pav-translit')||{}).textContent")
            btn = pg.locator(".pav-card").get_by_text("Mostra la pronuncia IPA")
            after = None
            if await btn.count():
                box = await pg.locator(".pav-card").bounding_box()
                await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
                await btn.click(); await pg.wait_for_timeout(3500)
                after = await pg.evaluate("(document.querySelector('.pav-card .pav-ipa')||{}).textContent")
            word2 = await pg.evaluate("(document.querySelector('.pav-word')||{}).textContent")
            good = word == w and word2 == w and after == "/ipa-" + w + "/"
            ok_all &= good
            print(f"{l}: parola {word!r} | automatica {auto!r} | pulsante → {after!r} | trascrizione {tr!r} | {'OK' if good else 'NO'}")
            await pg.keyboard.press("Escape"); await pg.mouse.click(5, 5)
        print("errori:", errs, tvolo.log["errors"], "| ESITO:", ok_all)
        await ctx.close()
asyncio.run(main())

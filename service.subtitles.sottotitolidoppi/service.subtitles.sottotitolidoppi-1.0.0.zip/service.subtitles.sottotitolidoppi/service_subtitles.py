# -*- coding: utf-8 -*-
# Sottotitoli Doppi - servizio per il menu dei sottotitoli del lettore (Sottotitoli → Scarica → Sottotitoli Doppi).
# Il lavoro lo fa l'add-on principale script.sottotitolidoppi (stesse impostazioni, stessa cache).
import sys

import xbmcaddon
import xbmcvfs

sys.path.insert(0, xbmcvfs.translatePath(xbmcaddon.Addon("script.sottotitolidoppi").getAddonInfo("path")))

from resources.lib import subtitles  # noqa: E402  (dall'add-on principale)

subtitles.main(sys.argv)

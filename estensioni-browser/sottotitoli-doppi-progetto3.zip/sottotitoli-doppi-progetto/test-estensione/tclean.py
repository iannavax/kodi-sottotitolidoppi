import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', transcribeMode:'live'})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsClean"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(34000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(9000)
        dbg = json.loads(await pg.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))
        for c in dbg: print(f"  {c['start']/1000:5.1f}s {'(TOLTA) ' if c['removed'] else ''}{c['text'][:50]:50} | {(c['trans'] or '')[:42]}")
        # la frase tolta non deve comparire sul video
        t3 = [c for c in dbg if c["removed"]]
        if t3:
            await pg.evaluate(f"document.querySelector('video').currentTime={t3[0]['start']/1000 + 1}"); await pg.wait_for_timeout(600)
            print("  sul video nel punto della frase tolta:", repr(await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent")))
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

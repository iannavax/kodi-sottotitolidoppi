# -*- coding: utf-8 -*-
# Sottotitoli Doppi per Kodi - collegamento con Kodi (lettore, file, finestre, impostazioni)
import base64
import json
import re
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import core

# sempre questo add-on, anche quando il codice è usato dall'add-on del menu dei sottotitoli
ADDON_ID = "script.sottotitolidoppi"
ADDON = xbmcaddon.Addon(ADDON_ID)
NAME = ADDON.getAddonInfo("name")
ICON = ADDON.getAddonInfo("icon")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CACHE = os.path.join(PROFILE, "cache")
core.BLOCKED_PATH = os.path.join(PROFILE, "servizi-esauriti-oggi.json")
_busy = threading.Lock()


def log(msg):
    xbmc.log("[%s] %s" % (NAME, msg), xbmc.LOGINFO)


def notify(msg, ms=5000):
    xbmcgui.Dialog().notification(NAME, msg, ICON, ms)


def settings():
    a = xbmcaddon.Addon(ADDON_ID)
    keys = ["target", "engine", "layout", "trans_color", "auto", "auto_mode", "auto_skip_lang", "auto_min", "transcribe", "transcribe_always", "stt", "stt_url",
            "stt_model", "stt_lang", "groq_key", "openai_key", "ffmpeg", "human", "stt_gaps", "target_custom", "save_folder", "save_auto",
            "source_mode", "trans_mode", "stt_precise", "rd_token", "sync_audio", "use_services"]
    keys += ["microsoft_region", "fallback", "subdl_key", "stt_workers"]
    for e in ("gemini", "groq", "mistral", "openrouter", "deepl", "microsoft", "claude", "local"):
        keys += [e + "_key", e + "_model", e + "_url"]
    s = {k: a.getSetting(k) for k in keys}
    s["target"] = target_lang(s["target"], s.get("target_custom", ""))
    s["engine"] = (s["engine"] or "google").split(" ")[0]
    s["stt_lang"] = (s["stt_lang"] or "").split(" ")[0] if s["stt_lang"] not in ("", "auto") else ""
    # quando parte un video: chiedi (predefinito) / sempre / mai. La vecchia "auto" spenta vale "mai".
    am = (s.get("auto_mode") or "").split(" ")[0]
    if am not in ("chiedi", "sempre", "mai"):
        am = "mai" if s["auto"] == "false" else "chiedi"
    s["auto_mode"] = am
    s["auto"] = am != "mai"
    s["auto_skip_lang"] = s.get("auto_skip_lang") != "false"   # predefinito: sì
    try:
        s["auto_min"] = max(0, int(float(s.get("auto_min") or 15)))
    except ValueError:
        s["auto_min"] = 15
    s["transcribe"] = s["transcribe"] == "true"
    s["transcribe_always"] = s["transcribe_always"] == "true"
    s["human"] = s["human"] != "false"       # predefinito: sì (impostazione della 1.5, sostituita da trans_mode)
    # da dove prendere l'originale: auto (file, se manca trascrizione se attiva) / trascrizione / file
    sm = (s.get("source_mode") or "").split(" ")[0]
    s["source_mode"] = sm if sm in ("auto", "trascrizione", "file") else ("trascrizione" if s["transcribe_always"] else "auto")
    # traduzione: auto (già pronta solo se l'originale è un file di sottotitoli) / nuova / pronta
    tm = (s.get("trans_mode") or "").split(" ")[0]
    s["trans_mode"] = tm if tm in ("auto", "nuova", "pronta", "chat") else ("auto" if s["human"] else "nuova")
    s["stt_precise"] = s.get("stt_precise") != "false"   # predefinito: sì
    s["save_auto"] = s["save_auto"] == "true"
    s["fallback"] = s.get("fallback") != "false"     # predefinito: sì
    s["stt_gaps"] = s.get("stt_gaps") != "false"     # predefinito: sì
    s["sync_audio"] = s.get("sync_audio") != "false"   # predefinito: sì
    s["use_services"] = s.get("use_services") == "true"  # predefinito: no (consuma la quota di download dell'account)
    s["stt"] = (s["stt"] or "groq").split(" ")[0]
    s["layout"] = {"Originale sopra": "orig_top", "Traduzione sopra": "trans_top", "Solo traduzione": "trans_only"}.get(
        s["layout"], s["layout"] or "orig_top")
    s["groq_key"] = s["groq_key"] or s.get("groq_key", "")
    return s


def target_lang(choice, custom=""):
    """Lingua di arrivo dalle impostazioni: una della lista, quella di Kodi, oppure una scritta a mano"""
    code = (choice or "it").split(" ")[0]
    if code == "kodi":
        try:
            code = core.lang_code(xbmc.getLanguage(xbmc.ISO_639_1)) or core.lang_code(xbmc.getLanguage(xbmc.ENGLISH_NAME))
        except Exception:
            code = ""
    elif code == "altra":
        code = core.lang_code(custom)
        if not code and custom.strip():
            try:   # nomi di lingua che conosce Kodi (anche nella lingua di Kodi)
                code = core.lang_code(xbmc.convertLanguage(custom.strip(), xbmc.ISO_639_1))
            except Exception:
                code = ""
        if not code:
            log("lingua di arrivo scritta a mano non riconosciuta: %r, uso l'italiano" % custom)
    return code or "it"


# ---------------------------------------------------------------------- file
def read_text(path):
    f = xbmcvfs.File(path)
    try:
        data = f.readBytes()
    finally:
        f.close()
    data = bytes(data)
    for enc in ("utf-8-sig", "utf-16", "cp1252", "latin-1"):
        try:
            text = data.decode(enc)
            if enc == "utf-16" and "-->" not in text and "Dialogue" not in text:
                continue
            return text
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "replace")


VIDEO_EXT = (".mkv", ".mp4", ".avi", ".mov", ".m4v", ".wmv", ".ts", ".m2ts", ".webm", ".mpg", ".mpeg", ".flv")


def list_subs(folder, max_age_h=None, strict=False):
    """strict: file da accettare solo se scaricati adesso o con il nome del video (vedi core.pick_subtitle)"""
    out = []
    try:
        _, files = xbmcvfs.listdir(folder)
    except Exception:
        return out
    now = time.time()
    for f in files:
        if not f.lower().endswith(core.SUB_EXT):
            continue
        p = folder.rstrip("/\\") + ("\\" if "\\" in folder and "://" not in folder else "/") + f
        try:
            mtime = xbmcvfs.Stat(p).st_mtime()
        except Exception:
            mtime = 0
        if max_age_h and mtime and now - mtime > max_age_h * 3600:
            continue
        out.append((p, mtime, strict))
    return out


def _many_videos(folder):
    try:
        _, files = xbmcvfs.listdir(folder)
    except Exception:
        return False
    return sum(1 for f in files if f.lower().endswith(VIDEO_EXT)) > 1


def candidates(video):
    found = []
    if video and not video.startswith(("http://", "https://", "plugin://", "pvr://")):
        folder = os.path.dirname(video) if "://" not in video else video.rsplit("/", 1)[0]
        # in una cartella con più film, un sottotitolo con un altro nome può essere di un altro film
        shared = _many_videos(folder)
        found += list_subs(folder, strict=shared)
        found += list_subs(folder.rstrip("/\\") + "/Subs", strict=shared) + list_subs(folder.rstrip("/\\") + "/subs", strict=shared)
    # sottotitoli scaricati con gli add-on di Kodi (OpenSubtitles & co.) o lasciati dagli add-on video
    # nelle loro cartelle: solo quelli di questo film (scritti dopo l'inizio della visione)
    for t in ("special://temp/", "special://temp/subtitles/"):
        found += list_subs(t, max_age_h=12, strict=True)
    found += scan_recent(["special://temp/", "special://profile/addon_data/"], max_depth=4)
    seen, out = set(), []
    for c in found:
        if c[0] not in seen:
            seen.add(c[0]); out.append(c)
    return out


def scan_recent(roots, max_depth=4, max_age_s=6 * 3600, limit=4000):
    """Sottotitoli scritti di recente nelle cartelle di Kodi e degli add-on (anche in sottocartelle).
    Gli add-on video spesso salvano lì i sottotitoli del film che passano al lettore."""
    out, now, visited = [], time.time(), [0]

    def walk(folder, depth):
        if depth > max_depth or visited[0] > limit:
            return
        try:
            dirs, files = xbmcvfs.listdir(folder)
        except Exception:
            return
        for f in files:
            visited[0] += 1
            if not f.lower().endswith(core.SUB_EXT) or ".doppi." in f.lower():
                continue
            p = folder.rstrip("/") + "/" + f
            try:
                m = xbmcvfs.Stat(p).st_mtime()
            except Exception:
                continue
            if now - m <= max_age_s:
                out.append((p, m, True))
        for d in dirs:
            if d.lower() in ("packages", "thumbnails", "cache", "temp") and depth == 0 and "addon_data" not in folder:
                continue
            if d == "script.sottotitolidoppi":      # la mia cache: file doppi e tracce già estratte
                continue
            walk(folder.rstrip("/") + "/" + d + "/", depth + 1)
    for r in roots:
        walk(r, 0)
    return out


def item_subtitles(player):
    """Sottotitoli che l'add-on video ha passato al lettore insieme al film (setSubtitles):
    li leggo dalle proprietà dell'elemento in riproduzione; se sono indirizzi internet li scarico."""
    out = []
    try:
        item = player.getPlayingItem()
    except Exception:
        return out
    for i in range(1, 21):
        try:
            p = item.getProperty("subtitle:%d" % i)
        except Exception:
            p = ""
        if not p:
            break
        if p.startswith(("http://", "https://")):
            try:
                os.makedirs(CACHE, exist_ok=True)
                name = p.split("?")[0].rsplit("/", 1)[-1] or "sub.srt"
                ext = os.path.splitext(name)[1].lower()
                # tengo il nome originale (spesso contiene la lingua, per esempio film.nor.srt)
                base = re.sub(r"[^\w.-]", "_", os.path.splitext(name)[0])[:60]
                local = os.path.join(CACHE, "addon-%s-%s%s" % (core.cache_key(p)[:8], base, ext if ext in core.SUB_EXT else ".srt"))
                if not os.path.isfile(local):
                    st, body, h = core.http(p, timeout=30)
                    if st != 200 or not body:
                        continue
                    open(local, "wb").write(body)
                out.append((local, time.time(), False))
            except Exception as e:
                log("sottotitolo dell'add-on video non scaricato: %r" % e)
        else:
            out.append((p, time.time(), False))
    return out


# ---------------------------------------------------------------------- video in corso
START_PROP = "sottotitolidoppi.start"
BUSY_PROP = "sottotitolidoppi.busy"
CANCEL_PROP = "sottotitolidoppi.cancel"


class Bar(object):
    """Barra di avanzamento in alto a destra. Segna anche (proprietà della finestra di Kodi, vista da tutte le istanze
    dell'add-on) che sto lavorando, così un secondo avvio non ricomincia da capo.
    Le chiamate all'interfaccia di Kodi sono poche (al massimo una al secondo) e solo dal thread che ha creato la barra:
    aggiornamenti fitti da più thread insieme possono far bloccare Kodi (per esempio mentre la finestra si ridimensiona)."""
    def __init__(self, msg="Preparo i sottotitoli…", pct=0, auto=False):
        self.started, self.auto = time.time(), auto
        self.owner = threading.current_thread()
        self.pct, self.msg, self.shown_at, self.beat_at = pct, msg, 0.0, 0.0
        self.show = settings_bool("progress_bar", True)
        self.d = None
        if self.show:
            self.d = xbmcgui.DialogProgressBG()
            self.d.create(NAME, msg)
        self.beat(force=True)

    def beat(self, force=False):
        now = time.time()
        if not force and now - self.beat_at < 3:
            return
        self.beat_at = now
        try:
            w = xbmcgui.Window(10000)
            # una scelta fatta a mano dopo che ho cominciato: smetto e lascio il posto a quella
            if float(w.getProperty(CANCEL_PROP) or 0) > self.started:
                raise core.Cancelled("interrotto per una scelta fatta a mano")
            w.setProperty(BUSY_PROP, "%s|%s" % (now, "auto" if self.auto else "mano"))
        except core.Cancelled:
            raise
        except Exception:
            pass

    def update(self, pct=None, heading=None, msg=None, force=False):
        if pct is not None:
            self.pct = pct
        if msg:
            self.msg = msg
        if threading.current_thread() is not self.owner:
            return                      # da un altro thread: lo mostro al prossimo aggiornamento del mio
        self.beat()
        now = time.time()
        if self.d and (force or now - self.shown_at >= 1.0):
            self.shown_at = now
            self.d.update(int(self.pct), heading or NAME, self.msg or "")

    def close(self):
        try:
            if self.d:
                self.d.close()
        finally:
            try:
                xbmcgui.Window(10000).setProperty(BUSY_PROP, "")
            except Exception:
                pass


def settings_bool(key, default):
    try:
        v = xbmcaddon.Addon(ADDON_ID).getSetting(key)
    except Exception:
        return default
    return default if v == "" else v == "true"


def busy_elsewhere():
    """Un'altra istanza dell'add-on sta già preparando i sottotitoli (aggiornata da meno di 5 minuti)"""
    return bool(busy_info())


def busy_info():
    """"auto" o "mano" se un'altra istanza sta preparando i sottotitoli (aggiornata da meno di 5 minuti), altrimenti "" """
    try:
        t, _, who = (xbmcgui.Window(10000).getProperty(BUSY_PROP) or "").partition("|")
        t = float(t or 0)
    except Exception:
        return ""
    return (who or "mano") if 0 < time.time() - t < 300 else ""


def cancel_auto(wait=25):
    """Fermo il lavoro automatico in corso (per esempio la lettura di una traccia scelta da solo) e aspetto che lasci il posto"""
    xbmcgui.Window(10000).setProperty(CANCEL_PROP, str(time.time()))
    end = time.time() + wait
    while time.time() < end and busy_info():
        xbmc.sleep(300)
    return not busy_info()


def mark_start(player):
    """Chiamata dal servizio all'avvio di ogni video: ricordo quando è cominciato e quale file è"""
    try:
        xbmcgui.Window(10000).setProperty(START_PROP, json.dumps({"file": player.getPlayingFile(), "at": time.time()}))
    except Exception:
        pass


def playback_since(player, video):
    """Da quando stai guardando questo video (meno 2 minuti di margine per i sottotitoli scaricati all'avvio)"""
    at = 0
    try:
        p = json.loads(xbmcgui.Window(10000).getProperty(START_PROP) or "{}")
        if p.get("file") == video:
            at = p.get("at", 0)
    except Exception:
        pass
    if not at:
        try:
            at = time.time() - player.getTime()
        except Exception:
            at = time.time()
    return at - 120


def current_sub_lang(player):
    """Lingua dei sottotitoli scelti nel lettore (per preferire il file in quella lingua)"""
    try:
        return core.FILE_TAGS.get((player.getSubtitles() or "").lower().split("-")[0], "")
    except Exception:
        return ""


def looks_dual(path):
    """Un file doppio fatto da me (magari copiato da Kodi con un altro nome): non va usato come originale"""
    try:
        head = read_text(path)[:4000]
    except Exception:
        return False
    return head.count('<font color="#') >= 3


def _info(label):
    try:
        return xbmc.getInfoLabel(label) or ""
    except Exception:
        return ""


def film_info(video):
    """Codice IMDb, stagione e puntata del video in corso (dalle informazioni che l'add-on video passa a Kodi,
    altrimenti dal titolo o dal nome del file, per esempio The.Burbs.1989.2160p…mkv)"""
    imdb = _info("VideoPlayer.IMDBNumber")
    season, episode = _info("VideoPlayer.Season"), _info("VideoPlayer.Episode")
    if not imdb.startswith("tt"):
        title = _info("VideoPlayer.OriginalTitle") or _info("VideoPlayer.Title")
        year = _info("VideoPlayer.Year")
        name = os.path.basename(video.split("?")[0])
        m = re.match(r"(.+?)[ ._(\[-]+((?:19|20)\d\d)\b", name)
        if (not title or title == name) and m:
            title, year = m.group(1).replace(".", " ").replace("_", " ").strip(), m.group(2)
        mse = re.search(r"[Ss](\d{1,2})[Ee](\d{1,3})", name)
        if mse and not (season and episode):
            season, episode = mse.group(1), mse.group(2)
        try:
            imdb = core.find_imdb(title, year, "series" if season and episode else "movie")
        except Exception as e:
            log("ricerca del film non riuscita: %r" % e)
            imdb = ""
    return imdb, season, episode


def spoken_langs(player, target):
    """Lingue in cui cercare l'originale: la lingua originale del film, poi quella dell'audio e dei sottotitoli scelti,
    infine l'inglese"""
    out = []
    try:
        orig = original_lang(player.getPlayingFile())
    except Exception:
        orig = ""
    audio = core.FILE_TAGS.get((_info("VideoPlayer.AudioLanguage") or "").lower().split("-")[0], "")
    if (orig or audio) and (orig or audio) == target:
        return []                      # il film è già nella tua lingua
    for l in (orig, audio, current_sub_lang(player), "en"):
        if l and l != target and l not in out:
            out.append(l)
    return out


def subdl_options(video, langs, per_lang=3, imdb=None, season=None, episode=None):
    """Sottotitoli da SubDL (subdl.com) se nelle impostazioni c'è la chiave gratuita"""
    key = settings().get("subdl_key", "")
    if not key or not langs:
        return []
    try:
        if imdb is None:
            imdb, season, episode = film_info(video)
        title = _info("VideoPlayer.OriginalTitle") or _info("VideoPlayer.TVShowTitle") or _info("VideoPlayer.Title")
        found = core.subdl_search(key, langs, imdb, title, _info("VideoPlayer.Year"), season or 0, episode or 0)
    except Exception as e:
        log("SubDL: %r" % e)
        return []
    out, count = [], {}
    for f in found:
        l = f["lang"] if f["lang"] in langs else ""
        if not l:
            continue
        count[l] = count.get(l, 0) + 1
        if count[l] <= per_lang:
            out.append({"k": "subdl", "u": f["url"], "l": l, "n": count[l], "src": "SubDL", "rel": f["release"][:60],
                        "se": season or 0, "ep": episode or 0})
    log("SubDL: %s → %d sottotitoli nelle lingue %s" % (imdb or "titolo", len(out), langs))
    return out


def online_options(player, video, target, per_lang=3, services=True):
    """Sottotitoli originali per il film in corso (quando non ci sono file da leggere): prima OpenSubtitles
    (lo stesso usato dall'add-on Stremio), poi gli altri servizi di sottotitoli installati in Kodi"""
    langs = spoken_langs(player, target)
    if not langs:
        return []
    found, info, imdb = [], {}, ""
    try:
        imdb, season, episode = film_info(video)
        found = core.online_subtitles(imdb, langs, season, episode, os.path.basename(video.split("?")[0]), info=info)
    except Exception as e:
        log("OpenSubtitles non risponde: %r" % e)
    out, count = [], {}
    for url, lang in found:
        count[lang] = count.get(lang, 0) + 1
        if count[lang] <= per_lang:
            out.append({"k": "online", "u": url, "l": lang, "n": count[lang], "src": "OpenSubtitles"})
    log("OpenSubtitles: %s → %d sottotitoli nelle lingue %s (dettagli: %s)" % (imdb or "film non riconosciuto", len(out), langs, info))
    # SubDL (con la chiave gratuita): altre versioni, spesso anche quando OpenSubtitles non ha niente
    try:
        _, season, episode = film_info(video) if not imdb else (imdb, season, episode)
    except Exception:
        season = episode = 0
    out += subdl_options(video, langs, per_lang, imdb or "", season, episode)
    if not out and services:
        out = service_options(langs, per_lang)
    return out


def _rpc(method, params):
    req = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception as e:
        return {"error": repr(e)}


def _lang_name(code):
    """Nome inglese della lingua, come lo vogliono i servizi di sottotitoli di Kodi ("English")"""
    try:
        name = xbmc.convertLanguage(code, xbmc.ENGLISH_NAME)
        if name:
            return name
    except Exception:
        pass
    return {"zh": "Chinese"}.get(code) or core.LANG_EN.get(code, code)


SERVICES_DOWN = os.path.join(PROFILE, "servizi-sottotitoli-esauriti.json")


def service_down(aid, mark=False):
    """Servizi di sottotitoli che oggi non danno più file (per esempio OpenSubtitles.com con la quota di download
    del giorno finita): non li richiamo fino a domani, così non mostrano di continuo il loro avviso di quota."""
    today = time.strftime("%Y-%m-%d")
    try:
        d = json.load(open(SERVICES_DOWN, encoding="utf-8"))
    except Exception:
        d = {}
    if mark:
        d[aid] = today
        try:
            json.dump(d, open(SERVICES_DOWN, "w", encoding="utf-8"))
        except Exception:
            pass
        log("servizio %s: niente file (quota del giorno finita?), non lo uso fino a domani" % aid)
    return d.get(aid) == today


def subtitle_services():
    """Altri servizi di sottotitoli installati e attivi (per esempio OpenSubtitles.com di Kodi)"""
    r = _rpc("Addons.GetAddons", {"type": "xbmc.subtitle.module", "enabled": True, "properties": ["name"]})
    adds = ((r.get("result") or {}).get("addons")) or []
    ids = [a.get("addonid") for a in adds if a.get("addonid") and "sottotitolidoppi" not in a.get("addonid")
           and not service_down(a.get("addonid"))]
    ids.sort(key=lambda x: 0 if "opensubtitles" in x else 1)
    return [(i, next((a.get("name") for a in adds if a.get("addonid") == i), i)) for i in ids]


def service_options(langs, per_lang=3):
    """Chiedo i sottotitoli agli altri servizi installati, come farebbe il menu Sottotitoli → Scarica.
    Kodi esegue il servizio e mi restituisce l'elenco (Files.GetDirectory)."""
    names = ",".join(_lang_name(l) for l in langs)
    out = []
    for aid, aname in subtitle_services()[:3]:
        url = "plugin://%s/?action=search&languages=%s&preferredlanguage=%s" % (
            aid, urllib_quote(names), urllib_quote(_lang_name(langs[0])))
        r = _rpc("Files.GetDirectory", {"directory": url, "media": "files", "properties": ["title"]})
        files = ((r.get("result") or {}).get("files")) or []
        count = {}
        for f in files:
            label = (f.get("label") or "").strip()
            lang = next((l for l in langs if _lang_name(l).lower() == label.lower() or l == label.lower()[:2]), "")
            if not lang or not f.get("file"):
                continue
            count[lang] = count.get(lang, 0) + 1
            if count[lang] <= per_lang:
                out.append({"k": "service", "u": f["file"], "l": lang, "n": count[lang], "src": aname})
        log("servizio %s: %d risultati, %d utili%s" % (aid, len(files), len(out), (" (errore: %s)" % r.get("error")) if r.get("error") else ""))
        if out:
            break
    return out


def urllib_quote(text):
    import urllib.parse
    return urllib.parse.quote(text, safe="")


def fetch_online(o):
    """Scarica (una volta sola) un sottotitolo trovato in rete nella cache"""
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, "%s-%s.%s.srt" % ({"online": "opensubtitles", "rd": "realdebrid", "subdl": "subdl"}.get(o["k"], "servizio"), core.cache_key(o["u"]), o["l"] or "orig"))
    if os.path.isfile(path):
        return path
    if o["k"] == "subdl":
        body, ext = core.subdl_download(o["u"], o.get("se") or 0, o.get("ep") or 0)
        if ext != ".srt":
            path = path[:-4] + ext
        open(path, "wb").write(body)
        return path
    if o["k"] == "rd":
        cues = core.rd_download_vtt(o["u"])
        if not cues:
            raise Exception("Real-Debrid non ha dato frasi per quella traccia")
        path = os.path.join(CACHE, "realdebrid-%s.%s.srt" % (core.cache_key(o["u"]), o["l"] or "orig"))
        open(path, "w", encoding="utf-8").write(core.cues_to_srt(cues))
        return path
    if o["k"] == "service":
        # il servizio scarica il file e lo restituisce come elemento dell'elenco
        r = _rpc("Files.GetDirectory", {"directory": o["u"], "media": "files"})
        files = [f.get("file", "") for f in (((r.get("result") or {}).get("files")) or [])]
        local = next((f for f in files if os.path.splitext(f.split("?")[0])[1].lower() in (".srt", ".vtt", ".ass", ".ssa", ".sub")), "") \
            or next((f for f in files if f), "")
        if not local:
            m = re.match(r"plugin://([^/]+)", o["u"])
            if m and not r.get("error"):
                service_down(m.group(1), mark=True)
            raise Exception("il servizio %s non ha dato il file (%s)" % (o.get("src", ""), r.get("error") or "elenco vuoto"))
        if local.startswith("http"):
            st, body, h = core.http(local, timeout=30)
        else:
            f = xbmcvfs.File(local)
            try:
                body = f.readBytes()
            finally:
                f.close()
            body = bytes(body)
        if b"-->" not in body and b"Dialogue:" not in body:
            raise Exception("il file del servizio %s non sembra un sottotitolo" % o.get("src", ""))
        ext = os.path.splitext(local.split("?")[0])[1].lower()
        if ext in (".ass", ".ssa", ".vtt"):
            path = path[:-4] + ext
        open(path, "wb").write(body)
        return path
    st, body, h = core.http(o["u"], timeout=30)
    if st != 200 or b"-->" not in body:
        raise Exception("OpenSubtitles non ha dato il file (risposta %s)" % st)
    open(path, "wb").write(body)
    return path


# ---------------------------------------------------------------------- identità del video e scelte per video
def video_key(video):
    """Nome stabile del video per la cache. Gli indirizzi in streaming (Real-Debrid…) cambiano a ogni visione
    (/d/<codice nuovo>/Film.mkv): uso il nome del file e il codice IMDb, così trascrizione e traduzioni salvate
    si ritrovano anche la volta dopo."""
    if re.match(r"^https?://", video or ""):
        import urllib.parse
        name = urllib.parse.unquote(os.path.basename(video.split("?")[0])) or video
        imdb = _info("VideoPlayer.IMDBNumber")
        return "web:" + (imdb + ":" if imdb and imdb.startswith("tt") else "") + name
    return video


CHOICES = os.path.join(PROFILE, "scelte-per-video.json")


def load_choice(video):
    try:
        return json.load(open(CHOICES, encoding="utf-8")).get(video_key(video), {})
    except Exception:
        return {}


# ---------- Quando parte un video: farli o no (senza consumare niente se non servono) ----------
SERIES = os.path.join(PROFILE, "scelte-per-serie.json")


def _load_json(path):
    try:
        return json.load(open(path, encoding="utf-8"))
    except Exception:
        return {}


def series_choice(show, value=None):
    """Scelta ricordata per una serie ("si" = sempre, "no" = mai); con value la salva ("" la toglie)"""
    allc = _load_json(SERIES)
    if value is None:
        return allc.get(show, "")
    if value:
        allc[show] = value
    else:
        allc.pop(show, None)
    os.makedirs(PROFILE, exist_ok=True)
    json.dump(allc, open(SERIES, "w", encoding="utf-8"), ensure_ascii=False)
    return value


def auto_decision(player, video, s, ask=True):
    """Decide all'avvio di un video se preparare i sottotitoli doppi. Prima i controlli che non costano niente
    (impostazione, durata, scelte già fatte per il video o la serie, lingua dell'audio), poi la lingua del film
    dal catalogo (una richiesta, ricordata), e solo alla fine, se serve, la domanda. Restituisce (sì/no, motivo)."""
    mode = s["auto_mode"]
    if mode == "mai":
        return False, "impostazione: mai in automatico"
    if video.startswith(("pvr://", "rtmp://")) or "/live" in video.lower() and video.lower().endswith(".m3u8"):
        return False, "TV in diretta"
    try:
        total = player.getTotalTime()
    except Exception:
        total = 0
    if total and s["auto_min"] and total < s["auto_min"] * 60:
        return False, "video breve (%d s)" % total
    chosen = load_choice(video)
    if chosen.get("auto") == "no":
        return False, "hai detto di no per questo video"
    show = _info("VideoPlayer.TVShowTitle")
    sc = series_choice(show) if show else ""
    if sc == "no":
        return False, "hai detto mai per la serie %s" % show
    target = s["target"]
    if s["auto_skip_lang"]:
        audio = audio_hint()
        if audio and audio == target:
            return False, "l'audio è già in %s" % target
        orig = original_lang(video)
        if orig and orig == target:
            return False, "il film è già in %s" % target
    if chosen.get("auto") == "si" or sc == "si" or mode == "sempre":
        return True, "sì (%s)" % ("già fatto per questo video" if chosen.get("auto") == "si" else "serie" if sc == "si" else "sempre")
    if not ask:
        return False, "da chiedere"
    # domanda: 20 secondi per rispondere, poi vale "no" (niente richieste consumate per sbaglio)
    title = _info("VideoPlayer.Title") or os.path.basename(video.split("?")[0])
    opts = ["Sì, crea i sottotitoli doppi", "No, non per questo video"]
    if show:
        opts += ["Sempre per la serie %s" % show, "Mai per la serie %s" % show]
    opts += ["Non chiedere più (solo dal menu dell'add-on)"]
    try:
        i = xbmcgui.Dialog().select("%s: %s" % (NAME, title[:60]), opts, autoclose=20000)
    except TypeError:
        i = xbmcgui.Dialog().select("%s: %s" % (NAME, title[:60]), opts)
    pick = opts[i] if 0 <= i < len(opts) else ""
    if pick.startswith("Sì"):
        save_choice(video, auto="si")
        return True, "hai detto sì"
    if pick.startswith("No,"):
        save_choice(video, auto="no")
        return False, "hai detto no"
    if pick.startswith("Sempre per la serie"):
        series_choice(show, "si")
        return True, "sempre per la serie"
    if pick.startswith("Mai per la serie"):
        series_choice(show, "no")
        return False, "mai per la serie"
    if pick.startswith("Non chiedere"):
        try:
            ADDON.setSetting("auto_mode", "mai (solo dal menu dell'add-on)")
        except Exception:
            pass
        notify("Va bene: li crei dal menu dell'add-on (Programmi → Sottotitoli Doppi) quando vuoi.", 6000)
        return False, "non chiedere più"
    return False, "nessuna risposta"


def auto_menu(player):
    """Menu: cambia la scelta dell'avvio automatico per il video in corso e per la sua serie"""
    s = settings()
    mode_txt = {"chiedi": "chiedi", "sempre": "sempre", "mai": "mai (solo dal menu)"}[s["auto_mode"]]
    video = player.getPlayingFile() if player.isPlayingVideo() else ""
    show = _info("VideoPlayer.TVShowTitle") if video else ""
    cur_v = load_choice(video).get("auto", "") if video else ""
    cur_s = series_choice(show) if show else ""
    word = {"si": "sì", "no": "no", "": "come l'impostazione"}
    opts, acts = [], []
    opts.append("Impostazione generale: %s (cambia…)" % mode_txt); acts.append("mode")
    if video:
        opts.append("Questo video: %s → sempre sì" % word[cur_v]); acts.append(("v", "si"))
        opts.append("Questo video: %s → mai" % word[cur_v]); acts.append(("v", "no"))
        if cur_v:
            opts.append("Questo video: torna a come l'impostazione"); acts.append(("v", ""))
    if show:
        opts.append("Serie %s: %s → sempre sì" % (show, word[cur_s])); acts.append(("s", "si"))
        opts.append("Serie %s: %s → mai" % (show, word[cur_s])); acts.append(("s", "no"))
        if cur_s:
            opts.append("Serie %s: torna a come l'impostazione" % show); acts.append(("s", ""))
    i = xbmcgui.Dialog().select("Quando creare i sottotitoli doppi da soli", opts)
    if i < 0:
        return
    a = acts[i]
    if a == "mode":
        modes = ["chiedi (una domanda all'avvio: sì, no, sempre o mai per la serie)", "sempre (crea i sottotitoli doppi da solo)",
                 "mai (solo dal menu dell'add-on)"]
        j = xbmcgui.Dialog().select("Quando parte un video", modes)
        if j >= 0:
            ADDON.setSetting("auto_mode", modes[j])
            notify("Impostato: " + modes[j].split(" (")[0])
    elif a[0] == "v":
        allc = _load_json(CHOICES)
        c = allc.get(video_key(video), {})
        if a[1]:
            c["auto"] = a[1]
        else:
            c.pop("auto", None)
        allc[video_key(video)] = c
        os.makedirs(PROFILE, exist_ok=True)
        json.dump(allc, open(CHOICES, "w", encoding="utf-8"), ensure_ascii=False)
        notify("Fatto per questo video.")
    else:
        series_choice(show, a[1])
        notify("Fatto per la serie %s." % show)


def auto_start(player):
    """Chiamata dal servizio qualche secondo dopo l'avvio di un video"""
    try:
        if not player.isPlayingVideo():
            return
        video = player.getPlayingFile()
        s = settings()
        ok, why = auto_decision(player, video, s)
        log("avvio automatico per %s: %s" % (video_key(video), why))
        if ok and player.isPlayingVideo() and player.getPlayingFile() == video:
            run(player)
    except Exception as e:
        log("avvio automatico: %r" % e)


def save_choice(video, source=None, trans=None, pick=None, auto=None):
    try:
        allc = json.load(open(CHOICES, encoding="utf-8"))
    except Exception:
        allc = {}
    c = allc.get(video_key(video), {})
    if source:
        c["source"] = source
    if trans:
        c["trans"] = trans
    if pick is not None:
        c["pick"] = pick
    if auto:
        c["auto"] = auto
    allc[video_key(video)] = c
    if len(allc) > 500:
        for k in list(allc)[:len(allc) - 500]:
            del allc[k]
    os.makedirs(PROFILE, exist_ok=True)
    json.dump(allc, open(CHOICES, "w", encoding="utf-8"), ensure_ascii=False)


def stt_settings(s):
    """Impostazioni della trascrizione: con "più precisa" Groq usa whisper-large-v3 invece della versione turbo"""
    s = dict(s)
    if s.get("stt", "groq") == "groq" and s.get("stt_precise", True) and s.get("stt_model", "") in ("", "whisper-large-v3-turbo"):
        s["stt_model"] = "whisper-large-v3"
    return s


def transcript_paths(video, s):
    s2 = stt_settings(s)
    key = core.cache_key("trascrizione", video_key(video), s2.get("stt_lang", ""), s2["stt"], s2.get("stt_model", ""))
    return os.path.join(CACHE, key + ".json"), os.path.join(CACHE, key + ".parziale.json")


def has_transcript(video, s):
    return os.path.isfile(transcript_paths(video, s)[0])


def forget_transcript(video, s):
    for p in transcript_paths(video, s):
        if os.path.isfile(p):
            os.remove(p)


def audio_hint():
    """Lingua della traccia audio, se Kodi la conosce ("dan" → "da")"""
    a = (_info("VideoPlayer.AudioLanguage") or "").lower().split("-")[0]
    return "" if a in ("", "und", "unk", "mul", "zxx") else core.lang_code(a)


def film_hint(video):
    """Lingua originale del film dal catalogo (quando Kodi non conosce la lingua della traccia audio)"""
    if audio_hint():
        return ""
    try:
        imdb, season, episode = film_info(video)
        return core.film_language(imdb, "series" if season and episode else "movie")
    except Exception:
        return ""


_ORIG = {}
_ALLOW_DUB = set()     # video per cui hai detto di trascrivere comunque il doppiaggio


def original_lang(video):
    """Lingua ORIGINALE del film: quella da imparare. Dal catalogo (lingua dichiarata, altrimenti paese di produzione);
    solo se il film non si riconosce, la lingua dell'audio secondo Kodi (che può essere un doppiaggio)."""
    vk = video_key(video)
    if vk not in _ORIG:
        lang = ""
        try:
            imdb, season, episode = film_info(video)
            lang = core.film_language(imdb, "series" if season and episode else "movie")
        except Exception:
            lang = ""
        _ORIG[vk] = lang
    return _ORIG[vk] or audio_hint()


def get_transcript(player, video, s, progress):
    """Trascrizione salvata, o fatta adesso (riprende dai pezzi già fatti se era stata interrotta)"""
    tpath, ppath = transcript_paths(video, s)
    hint = "" if s.get("stt_lang") else original_lang(video)
    if os.path.isfile(tpath):
        d = json.load(open(tpath, encoding="utf-8"))
        # trascrizione salvata da una versione precedente in una lingua diversa da quella del film (per esempio
        # Whisper che aveva scritto in inglese un film danese): la rifaccio una volta, nella lingua giusta
        if "hint" not in d and hint and d.get("lang") and d["lang"] != hint:
            log("trascrizione salvata in %s ma il film è in %s: la rifaccio" % (d["lang"], hint))
            notify("La trascrizione salvata era in una lingua sbagliata (%s): la rifaccio in %s." % (
                core.LANG_IT.get(d["lang"], d["lang"]), core.LANG_IT.get(hint, hint)), 8000)
            os.replace(tpath, tpath + ".lingua-sbagliata")
            if os.path.isfile(ppath):
                os.remove(ppath)
        else:
            return d["cues"], d["lang"]
    done = {}
    if os.path.isfile(ppath):
        try:
            done = json.load(open(ppath, encoding="utf-8")).get("pieces", {})
        except Exception:
            done = {}
        if hint and any(p.get("lang") and p["lang"] != hint for p in done.values()):
            done = {}   # pezzi fatti in un'altra lingua: si rifanno

    def on_piece(n, piece, lang):
        done[str(n)] = {"cues": piece, "lang": lang}
        json.dump({"pieces": done}, open(ppath, "w", encoding="utf-8"), ensure_ascii=False)

    work = os.path.join(CACHE, "audio-" + os.path.basename(tpath)[:16])
    os.makedirs(work, exist_ok=True)
    try:
        try:
            dur = float(player.getTotalTime() or 0)
        except Exception:
            dur = 0
        # la barra va avanti a ogni pezzo pronto (prima restava ferma al 48% mentre si leggeva tutto l'audio del film)
        def tick(n, tot):
            if n < 0:
                progress.update(49, NAME, "Leggo l'audio del film (in streaming può volerci qualche minuto)…")
            else:
                progress.update(int(50 + 38 * n / max(1, tot)), NAME, "Trascrivo l'audio: %d pezzi da 10 minuti su %d pronti" % (n, tot))
        cues, lang, complete = core.transcribe(
            video, stt_settings(s), work, on_progress=tick,
            should_stop=lambda: not player.isPlayingVideo(), hint=hint, done=done, on_piece=on_piece,
            audio_lang=original_lang(video), allow_dub=video_key(video) in _ALLOW_DUB,
            duration=dur if dur >= 60 else 0, workers=int(s.get("stt_workers", 3) or 3))
    finally:
        for f in os.listdir(work):
            os.remove(os.path.join(work, f))
        os.rmdir(work)
    if complete:
        json.dump({"cues": cues, "lang": lang, "hint": hint}, open(tpath, "w", encoding="utf-8"), ensure_ascii=False)
        if os.path.isfile(ppath):
            os.remove(ppath)
    log("trascrizione: %d frasi, lingua %s%s" % (len(cues), lang or "?", "" if complete else " (interrotta: riprende la prossima volta)"))
    return cues, lang


def transcript_only_srt(video, s):
    """La trascrizione da sola (solo la lingua originale, senza traduzione), in un file .srt"""
    tp = transcript_paths(video, s)[0]
    if not os.path.isfile(tp):
        return None
    d = json.load(open(tp, encoding="utf-8"))
    cues = d.get("cues") or []
    if not cues:
        return None
    os.makedirs(CACHE, exist_ok=True)
    out = os.path.join(CACHE, "%s.trascrizione.%s.srt" % (core.cache_key(video_key(video), "solo-originale"), d.get("lang") or "orig"))
    open(out, "w", encoding="utf-8").write(core.make_dual_srt(cues, [""] * len(cues), "orig_top"))
    return out


def show_transcript_only(player):
    """Menu → «Mostra solo la trascrizione (lingua originale)»: se c'è già si vede subito, altrimenti la faccio"""
    if not player.isPlayingVideo():
        notify("Avvia prima un video")
        return
    video = player.getPlayingFile()
    s = settings()
    out = transcript_only_srt(video, s)
    if out:
        player.setSubtitles(out)
        notify("Solo la trascrizione, nella lingua originale.", 5000)
        return
    if xbmcgui.Dialog().yesno(NAME, "Questo video non è ancora trascritto. Trascrivo adesso l'audio? Alla fine vedrai solo "
                                    "l'originale (la traduzione la puoi chiedere dopo, senza rifare la trascrizione)."):
        run(player, source_mode="trascrizione", interactive=True, orig_only=True)


def choose_menu(player):
    """Per questo video: da dove prendere l'originale e quale traduzione usare. La scelta viene ricordata
    per il video; trascrizione e traduzioni restano salvate, quindi cambiare scelta non rifà il lavoro."""
    if not player.isPlayingVideo():
        notify("Avvia prima un video")
        return
    video = player.getPlayingFile()
    s = settings()
    cur = load_choice(video)
    done = has_transcript(video, s)
    tpart = os.path.isfile(transcript_paths(video, s)[1])
    src_opts = [("auto", "Automatico: file di sottotitoli se c'è, altrimenti trascrizione"),
                ("trascrizione", "Trascrizione dell'audio (Whisper)" + (" — già fatta, subito pronta" if done else
                                                                        " — a metà, riprende da dove era" if tpart else " — da fare")),
                ("file", "File di sottotitoli (accanto al video, scaricati, OpenSubtitles)")]
    now_s = cur.get("source") or s["source_mode"]
    k = xbmcgui.Dialog().select("Originale (adesso: %s)" % dict(src_opts)[now_s].split(":")[0].split(" (")[0],
                                [label for _, label in src_opts])
    if k < 0:
        return
    eng = engine_name(s)
    saved = ""
    try:
        last = json.load(open(LAST, encoding="utf-8"))
        if last.get("vkey") == video_key(video):
            mine, anyv = memory_stats(video, s["target"], s, last["cues"])
            saved = " — salvate %d frasi su %d" % (mine, len(last["cues"]))
    except Exception:
        pass
    tr_opts = [("auto", "Automatica: già pronta se l'originale è un file e va in fase, altrimenti nuova"),
               ("nuova", "Con %s: usa le frasi già tradotte e traduce solo quelle che mancano%s" % (eng, saved)),
               ("rifai", "Rifai da capo con %s: ignora le traduzioni salvate (consuma richieste)" % eng),
               ("pronta", "Già pronta: sottotitoli tradotti da persone, messi in fase con l'originale"),
               ("chat", "Da una chat: quella importata con \"Importa traduzione\"")]
    now_t = cur.get("trans") or s["trans_mode"]
    j = xbmcgui.Dialog().select("Traduzione (adesso: %s)" % dict(tr_opts).get(now_t, now_t).split(":")[0].split(" (")[0],
                                [label for _, label in tr_opts])
    if j < 0:
        return
    pick = None
    if src_opts[k][0] == "file":
        pick = choose_original(player, cur, with_transcript=False)
        if not pick:
            return
    tm = tr_opts[j][0]
    save_choice(video, source=src_opts[k][0], trans="nuova" if tm == "rifai" else tm, pick=pick)
    run(player, interactive=True, source_mode=src_opts[k][0], trans_mode="nuova" if tm == "rifai" else tm, retranslate=tm == "rifai")


def _same_pick(a, b):
    return bool(a and b) and all(a.get(x) == b.get(x) for x in ("k", "p", "i", "u", "n", "l"))


def choose_original(player, cur=None, with_transcript=True):
    """Elenco dei sottotitoli originali di questo video (dentro il video, scaricati, accanto al video, OpenSubtitles,
    trascrizione) + un file scelto a mano. Restituisce la scelta (dizionario) o None."""
    from . import subtitles
    cur = cur if cur is not None else load_choice(player.getPlayingFile())
    notify("Cerco i sottotitoli originali…", 3000)
    opts = subtitles.options(player, with_transcript=with_transcript)
    last = cur.get("pick")
    if last and not any(_same_pick(last, o) for o in opts) and last.get("k") == "file" and os.path.isfile(last.get("p", "")):
        opts.insert(0, last)
    labels = []
    orig = original_lang(player.getPlayingFile())
    for o in opts:
        mark = "► " if _same_pick(last, o) else ""
        lang = core.LANG_IT.get(o.get("l", ""), "")
        if lang and orig and o.get("l") == orig:
            lang += " (lingua del film)"
        if not lang and o["k"] not in ("trans", "dotrans"):
            lang = "lingua ?"
        labels.append("%s%s%s" % (mark, lang + " · " if lang else "", o.get("name", "")))
    labels.append("Scegli un file dal dispositivo (.srt, .vtt, .ass)…")
    f = xbmcgui.Dialog().select("Quali sottotitoli originali tradurre?", labels)
    if f < 0:
        return None
    if f == len(opts):
        path = xbmcgui.Dialog().browse(1, "Scegli i sottotitoli nella lingua originale", "files", ".srt|.vtt|.ass|.ssa")
        if not path:
            return None
        return {"k": "file", "p": path, "l": core.lang_from_filename(path), "name": os.path.basename(path)}
    return opts[f]


def pick_menu(player):
    """Voce del menu: scegli i sottotitoli originali e parte subito la traduzione da quelli"""
    if not player.isPlayingVideo():
        notify("Avvia prima un video")
        return
    video = player.getPlayingFile()
    o = choose_original(player)
    if not o:
        return
    if o["k"] in ("trans", "dotrans"):
        save_choice(video, source="trascrizione")
        run(player, source_mode="trascrizione", interactive=True)
    else:
        # ricordata per questo video: anche le volte dopo, in automatico, si parte da questi
        save_choice(video, source="file", pick=o)
        run(player, source_mode="file", interactive=True)


# ---------------------------------------------------------------------- sottotitoli dentro il .mkv in streaming
_MKV = {}


def is_remote_mkv(video):
    return bool(re.match(r"^https?://", video or "")) and video.split("?")[0].lower().endswith((".mkv", ".mk3d", ".webm"))


def mkv_options(video):
    """Tracce di sottotitoli dentro il file .mkv in streaming (Real-Debrid, The Crew…), lette senza scaricare il film"""
    if not is_remote_mkv(video):
        return []
    vk = video_key(video)
    if vk not in _MKV:
        try:
            tracks, _ = core.mkv_tracks(video)
            _MKV[vk] = tracks
            log("mkv in streaming: tracce di sottotitoli %s" % [(t["num"], t["lang"], t["codec"], t["name"]) for t in tracks])
        except Exception as e:
            log("mkv in streaming: sottotitoli non leggibili (%r)" % e)
            _MKV[vk] = []
    out = []
    for t in _MKV[vk]:
        what = core.LANG_IT.get(t["lang"], t["lang"] or "lingua ?")
        extra = ", solo le parti in altre lingue" if t.get("forced") else ""
        out.append({"k": "mkv", "u": video, "i": t["num"], "l": t["lang"], "forced": bool(t.get("forced")),
                    "name": "dentro il video: %s%s%s" % (what, (" (%s)" % t["name"]) if t.get("name") else "", extra)})
    return out


def check_menu(player):
    """Controlla i sottotitoli dentro il video: cosa trova l'add-on nel file che stai guardando (e perché no)"""
    if not player.isPlayingVideo():
        notify("Avvia prima un video")
        return
    video = player.getPlayingFile()
    s = settings()
    lines = ["Video: %s" % os.path.basename(video.split("?")[0]), ""]
    if is_remote_mkv(video):
        _MKV.pop(video_key(video), None)
        try:
            tracks, m = core.mkv_tracks(video)
            lines.append("File .mkv in streaming: %d tracce di sottotitoli di testo." % len(tracks))
            for t in tracks:
                try:
                    n = len(m.cue_points(t["num"]))
                    ok = "%d frasi nell'indice: si possono leggere" % n if n else "non sono nell'indice del file: non si possono leggere senza scaricare tutto il film"
                except Exception as e:
                    ok = "indice non leggibile (%s)" % e
                lines.append("  - traccia %d: %s %s%s → %s" % (t["num"], core.LANG_IT.get(t["lang"], t["lang"]), t["codec"],
                                                             " (solo parti in altre lingue)" if t.get("forced") else "", ok))
            if not tracks:
                lines.append("  (i sottotitoli che vedi potrebbero essere immagini, PGS/VobSub: non si possono leggere come testo)")
        except Exception as e:
            lines.append("File .mkv in streaming: non riesco a leggerlo (%s)" % e)
    elif re.match(r"^https?://", video):
        lines.append("Video in streaming non .mkv: i sottotitoli dentro il file non si possono leggere.")
    else:
        lines.append("File sul dispositivo: tracce lette con ffmpeg: %s" % (embedded_streams(video, s) or "nessuna (o ffmpeg mancante)"))
    if core.is_rd_link(video):
        lines += ["", "Real-Debrid: token %s." % ("trovato" if rd_token(s) else "non trovato (impostazioni dell'add-on)")]
    lines += ["", "Sottotitoli scelti nel lettore: %s" % (current_sub_lang(player) or "nessuno"),
              "Lingua dell'audio secondo Kodi: %s" % (audio_hint() or "sconosciuta")]
    log("controllo: " + " | ".join(lines))
    xbmcgui.Dialog().textviewer("Sottotitoli dentro il video", "\n".join(lines))


def fetch_mkv(o, video=None, progress=None):
    """Legge la traccia (una volta sola: poi resta in cache con il nome del film).
    Va in cache solo se è completa: se il server interrompe la lettura e mancano frasi, la volta dopo si rilegge."""
    vk = video_key(video or o["u"])
    base = os.path.join(CACHE, "mkv2-%s-%d" % (core.cache_key(vk), o["i"]))
    path = base + ".%s.srt" % (o.get("l") or "orig")
    if os.path.isfile(path):
        return path
    url = video if video and is_remote_mkv(video) else o["u"]
    own = progress is None
    bar = Bar("Leggo i sottotitoli dentro il video…") if own else progress
    if not own:
        bar.update(2, NAME, "Leggo i sottotitoli dentro il video…")

    def step(done, total):
        bar.update(int((95 if own else 45) * done / max(1, total)), NAME,
                   "Leggo i sottotitoli dentro il video: %d su %d" % (done, total), force=done >= total)
    pieces = base + ".pezzi.json"      # frasi lette in un tentativo interrotto: non si rileggono
    try:
        known = json.load(open(pieces, encoding="utf-8"))
    except Exception:
        known = None
    try:
        info = {}
        cues = core.mkv_read(url, o["i"], log, info, step, known)
    finally:
        if own:
            bar.close()
    if not cues:
        raise Exception("nessuna frase in quella traccia")
    os.makedirs(CACHE, exist_ok=True)
    total, missing = info.get("totale", len(cues)), info.get("mancanti", 0)
    if missing:
        try:
            json.dump(info.get("lette") or {}, open(pieces, "w", encoding="utf-8"), ensure_ascii=False)
        except Exception as e:
            log("pezzi letti non salvati: %r" % e)
    elif os.path.isfile(pieces):
        os.remove(pieces)
    if missing > max(2, total // 200):
        # incompleta: la uso adesso, ma non la tengo come definitiva
        path = base + ".parziale.%s.srt" % (o.get("l") or "orig")
        notify("Letti %d sottotitoli su %d: il server ha interrotto la lettura. Rifai \"Crea i sottotitoli doppi\" "
               "tra poco: legge solo quelli che mancano (e le frasi già tradotte non si ritraducono)." % (total - missing, total), 10000)
    open(path, "w", encoding="utf-8").write(core.cues_to_srt(cues))
    log("mkv in streaming: %d frasi lette dalla traccia %d (%d nell'indice, %d non lette)" % (len(cues), o["i"], total, missing))
    return path


def pick_language_option(opts, player, video, target):
    """Tra più tracce: quella nella lingua ORIGINALE del film (non le "forzate"). Se la lingua del film è nota e non c'è
    una traccia in quella lingua: nessuna (in automatico non si traducono sottotitoli di un doppiaggio)."""
    opts = [o for o in opts if o.get("l") != target]
    full = [o for o in opts if not o.get("forced")] or opts
    orig = original_lang(video)
    if orig and orig != target:
        return next((o for o in full if o.get("l") == orig), None)
    want = [audio_hint(), current_sub_lang(player)]
    return next((o for w in want if w for o in full if o.get("l") == w), None) or (full[0] if full else None)


# ---------------------------------------------------------------------- Real-Debrid
def rd_token(s):
    """Token di Real-Debrid: quello delle impostazioni, altrimenti quello che usa già ResolveURL (The Crew e simili)"""
    if s.get("rd_token"):
        return s["rd_token"].strip()
    for aid, key in (("script.module.resolveurl", "RealDebridResolver_token"), ("script.module.urlresolver", "RealDebridResolver_token")):
        try:
            t = xbmcaddon.Addon(aid).getSetting(key)
            if t:
                return t.strip()
        except Exception:
            pass
    return ""


def rd_options(video, s):
    """Tracce di sottotitoli dentro il file di Real-Debrid che stai guardando, prese dallo streaming HLS di Real-Debrid"""
    if not core.is_rd_link(video):
        return []
    token = rd_token(s)
    if not token:
        log("Real-Debrid: manca il token (impostazioni dell'add-on, o ResolveURL)")
        return []
    try:
        rid = core.rd_find_id(video, token)
        if not rid:
            log("Real-Debrid: file non trovato tra i download")
            return []
        subs = core.rd_hls_subtitles(rid, token)
        if not subs:
            try:
                tracks = core.rd_sub_tracks(rid, token)
            except Exception as e:
                tracks = "errore %r" % e
            log("Real-Debrid: nessun sottotitolo nello streaming HLS (tracce nel file secondo Real-Debrid: %s)" % (tracks,))
        out = []
        for n, (lang, name, url) in enumerate(subs, 1):
            out.append({"k": "rd", "u": url, "l": lang, "n": n, "src": "Real-Debrid",
                        "name": "dentro il video (Real-Debrid): %s" % (name or core.LANG_IT.get(lang, lang) or "traccia %d" % n)})
        log("Real-Debrid: %d tracce di sottotitoli %s" % (len(out), [o["l"] for o in out]))
        return out
    except core.Fatal as e:
        notify(str(e), 7000)
    except Exception as e:
        log("Real-Debrid: %r" % e)
    return []


def file_source(player, video, target, s, progress=None):
    """Sottotitoli originali da un file: accanto al video, scaricati, dentro il video, oppure da OpenSubtitles.
    Per un .mkv in streaming prima le tracce dentro il video: sono proprio quelle del file che stai guardando."""
    source = None
    tried_mkv = is_remote_mkv(video)
    if tried_mkv:
        pick = pick_language_option(mkv_options(video), player, video, target)
        if pick:
            try:
                source = fetch_mkv(pick, video, progress)
                notify("Sottotitoli originali presi dal video (%s)" % (pick["l"] or "?").upper(), 5000)
            except Exception as e:
                log("mkv in streaming, traccia non letta: %r" % e)
    if not source:
        source = find_source(player, video, target)
    if not source:
        streams = embedded_streams(video, s)
        if streams:
            want = original_lang(video) or current_sub_lang(player)
            pick = next((x for x in streams if want and x[1] == want), None) or \
                next((x for x in streams if x[1] != target), None)
            if pick:
                try:
                    source = extract_stream(video, s, pick[0])
                except Exception as e:
                    log("traccia incorporata non letta: %r" % e)
    if not source and not tried_mkv:
        # sottotitoli dentro il .mkv in streaming: sono quelli del file che stai guardando (i più esatti)
        pick = pick_language_option(mkv_options(video), player, video, target)
        if pick:
            try:
                source = fetch_mkv(pick, video, progress)
                notify("Sottotitoli originali presi dal video (%s)" % (pick["l"] or "?").upper(), 5000)
            except Exception as e:
                log("mkv in streaming, traccia non letta: %r" % e)
    if not source:
        # sottotitoli dentro il file in streaming di Real-Debrid: di solito i più esatti per quel file
        rd = [o for o in rd_options(video, s) if o["l"] != target]
        orig = original_lang(video)
        if orig and orig != target:
            rd = [o for o in rd if o["l"] == orig]          # solo nella lingua del film
        if rd:
            want = [original_lang(video), audio_hint(), current_sub_lang(player)]
            pick = next((o for w in want if w for o in rd if o["l"] == w), None) or rd[0]
            try:
                source = fetch_online(pick)
                notify("Sottotitoli originali presi dal video (Real-Debrid, %s)" % (pick["l"] or "?").upper(), 5000)
            except Exception as e:
                log("Real-Debrid, sottotitoli non scaricati: %r" % e)
    if not source:
        online = online_options(player, video, target, per_lang=1, services=s.get("use_services", False))
        if online:
            try:
                source = fetch_online(online[0])
                notify("Sottotitoli originali presi da %s (%s). Se non vanno a tempo, scegline un'altra versione dal menu "
                       "dell'add-on: Scegli i sottotitoli originali da tradurre." % (online[0].get("src", "OpenSubtitles"), online[0]["l"].upper()), 7000)
            except Exception as e:
                log("OpenSubtitles: %r" % e)
    return source


# ---------------------------------------------------------------------- memoria delle traduzioni
# Ogni frase tradotta viene salvata subito (gruppo per gruppo) nella memoria del film: frase originale → traduzione,
# per servizio. Così:
#  - se il film si ferma a metà, la volta dopo si traducono solo le frasi che mancano;
#  - passando dalla trascrizione a un file di sottotitoli (o viceversa) le frasi uguali non si traducono di nuovo;
#  - cambiando servizio e tornando indietro, la traduzione di prima è ancora lì.
def memory_path(video, target):
    return os.path.join(CACHE, "memoria-%s.json" % core.cache_key(video_key(video), target))


def load_memory(video, target):
    try:
        return json.load(open(memory_path(video, target), encoding="utf-8"))
    except Exception:
        return {}


def save_memory(video, target, mem):
    try:
        tmp = memory_path(video, target) + ".tmp"
        json.dump(mem, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
        os.replace(tmp, memory_path(video, target))
    except Exception as e:
        log("memoria delle traduzioni non salvata: %r" % e)


def _mkey(text):
    return " ".join(text.split()).lower()


ENGINE_NAMES = {"google": "Google", "gemini": "Gemini", "groq": "Groq", "mistral": "Mistral", "openrouter": "OpenRouter",
                "deepl": "DeepL", "microsoft": "Microsoft", "claude": "Claude", "local": "il modello sul computer"}


def engine_name(s):
    """Il servizio che tradurrà davvero: quello scelto se è pronto (chiave, quota di oggi), altrimenti il primo di
    riserva disponibile (prima si scriveva sempre «Gemini» anche quando Gemini non c'era)"""
    try:
        e = core.engine_chain(s)[0]
    except Exception:
        e = s.get("engine", "google")
    return ENGINE_NAMES.get(e, e.capitalize())


def engine_tag(s):
    return s["engine"] + "|" + (s.get(s["engine"] + "_model", "") or "")


def memory_stats(video, target, s, cues):
    """Quante frasi di questi sottotitoli hanno già una traduzione salvata (con il servizio scelto, con qualsiasi servizio)"""
    mem = load_memory(video, target)
    tag = engine_tag(s)
    mine = sum(1 for c in cues if tag in mem.get(_mkey(c["t"]), {}))
    anyv = sum(1 for c in cues if mem.get(_mkey(c["t"])))
    return mine, anyv


def translate_with_memory(player, video, cues, s, target, src_lang, jpath, progress, write, out, upgrade=False, redo=False, legacy=None):
    """Traduce solo le frasi che non hanno già una traduzione salvata con questo servizio; salva man mano"""
    mem = load_memory(video, target)
    tag = engine_tag(s)
    # vecchie traduzioni complete (versioni precedenti dell'add-on): entrano nella memoria
    for jp in [p for p in (jpath, legacy) if p and os.path.isfile(p)] if not redo else []:
        try:
            old = json.load(open(jp, encoding="utf-8"))["trans"]
            if len(old) == len(cues):
                for c, t in zip(cues, old):
                    if t:
                        mem.setdefault(_mkey(c["t"]), {}).setdefault(tag, t)
        except Exception:
            pass
    trans = [None if redo else mem.get(_mkey(c["t"]), {}).get(tag) for c in cues]
    # traduzioni salvate che sono l'originale ricopiato (frasi brevi: "Ja." → "Ja."): si rifanno,
    # a meno che sia già stato controllato che restano uguali (nomi, "Okay"…)
    for i, c in enumerate(cues):
        if trans[i] and core.is_copy(c["t"], trans[i]) and not mem.get(_mkey(c["t"]), {}).get("uguale"):
            trans[i] = None
    todo = [i for i, t in enumerate(trans) if not t]
    if len(todo) < len(cues):
        log("memoria delle traduzioni: %d frasi già tradotte con %s, ne traduco %d" % (len(cues) - len(todo), s["engine"], len(todo)))
    if todo:
        sub = [cues[i] for i in todo]
        state = {"shown": False, "saved": 0}

        def on_batch(partial):
            for k, t in enumerate(partial):
                if t:
                    trans[todo[k]] = t
                    mem.setdefault(_mkey(sub[k]["t"]), {})[tag] = t
            save_memory(video, target, mem)          # salvo subito: se il film si ferma, non si perde niente
            # appena è pronto il pezzo che stai guardando, carico già i sottotitoli
            if not state["shown"] and not upgrade:
                state["shown"] = True
                write([t or "" for t in trans])
                player.setSubtitles(out)
                player.showSubtitles(True)

        start_ms = int(player.getTime() * 1000) if player.isPlayingVideo() else 0
        done_before = len(cues) - len(todo)
        got = core.translate_all(
            sub, s, target, src_lang, start_ms,
            on_progress=lambda d, tot: progress.update(int(50 + 50 * (d + done_before) / max(1, len(cues))), NAME,
                                                       "Traduco: %d di %d frasi" % (d + done_before, len(cues))),
            on_batch=on_batch, should_stop=lambda: not player.isPlayingVideo())
        for k, t in enumerate(got):
            if t:
                trans[todo[k]] = t
                mem.setdefault(_mkey(sub[k]["t"]), {})[tag] = t
                if core.is_copy(sub[k]["t"], t):
                    mem[_mkey(sub[k]["t"])]["uguale"] = 1     # controllata: resta uguale anche nella traduzione
        save_memory(video, target, mem)
    trans = fill_missing(cues, [t or "" for t in trans], target, src_lang)
    if player.isPlayingVideo() and all(trans):
        json.dump({"trans": trans}, open(jpath, "w", encoding="utf-8"), ensure_ascii=False)
    return trans


def fill_missing(cues, trans, target, src_lang):
    """La traduzione c'è sempre: le frasi rimaste senza le traduce Google"""
    trans = list(trans) + [""] * (len(cues) - len(trans))
    missing = [i for i, t in enumerate(trans) if not (t or "").strip()]
    if missing:
        try:
            got = core.google_translate_fast([cues[i]["t"] for i in missing], target, src_lang)
            for i, t in zip(missing, got):
                trans[i] = t or ""
        except Exception as e:
            log("Google per le frasi senza traduzione: %r" % e)
        # quelle ancora vuote, una per una (a volte Google salta una riga in un gruppo)
        for i in [i for i in missing if not (trans[i] or "").strip()][:200]:
            try:
                trans[i] = core.google_translate([cues[i]["t"]], target, src_lang)[0] or ""
            except Exception:
                pass
    return trans


# ---------------------------------------------------------------------- salvare i sottotitoli
LAST = os.path.join(PROFILE, "ultimi-sottotitoli.json")


def remember_result(video, cues, trans, src_lang, target, src_id=""):
    """Tengo da parte l'ultimo risultato (trascrizione o sottotitoli originali, traduzione) per poterlo salvare"""
    try:
        title = _info("VideoPlayer.Title") or os.path.basename(video.split("?")[0])
        json.dump({"video": video, "title": title, "cues": cues, "trans": trans, "src": src_lang or "", "target": target,
                   "src_id": src_id, "vkey": video_key(video)},
                  open(LAST, "w", encoding="utf-8"), ensure_ascii=False)
    except Exception as e:
        log("non riesco a tenere da parte i sottotitoli: %r" % e)


def safe_name(title):
    name = os.path.splitext(title)[0] if re.search(r"\.(mkv|mp4|avi|mov|m4v|ts|webm)$", title, re.I) else title
    name = re.sub(r'[\\/:*?"<>|]+', " ", name)
    return re.sub(r"\s+", " ", name).strip()[:100] or "sottotitoli"


def _write(path, text):
    f = xbmcvfs.File(path, "w")
    try:
        ok = f.write(text.encode("utf-8"))
    finally:
        f.close()
    if ok is False:
        raise Exception("non riesco a scrivere " + path)


def video_folder(video):
    """Cartella del video, se è un file sul dispositivo o in rete locale (non un indirizzo internet)"""
    if not video or re.match(r"^(https?|plugin|pvr|rtmp|rtsp)://", video):
        return ""
    return os.path.dirname(video) if "://" not in video else video.rsplit("/", 1)[0]


def save_files(folder, last=None):
    """Scrive tre file: originale (o trascrizione) "Titolo.en.srt", traduzione "Titolo.it.srt",
    doppio "Titolo.doppi.it.srt". Con questi nomi Kodi li riconosce, e l'add-on la prossima volta
    li usa al posto di rifare la trascrizione o la traduzione (se sono accanto al video)."""
    if last is None:
        last = json.load(open(LAST, encoding="utf-8"))
    s = settings()
    cues, trans, target = last["cues"], last["trans"], last["target"]
    base = safe_name(last.get("title") or os.path.basename(last["video"].split("?")[0]))
    if video_folder(last["video"]) and folder.rstrip("/\\") == video_folder(last["video"]).rstrip("/\\"):
        base = os.path.splitext(os.path.basename(last["video"].split("?")[0]))[0]   # stesso nome del video
    sep = "" if folder.endswith(("/", "\\")) else ("\\" if "\\" in folder and "://" not in folder else "/")
    src = last.get("src") or "orig"
    orig = "\n".join("%d\n%s --> %s\n%s\n" % (n, core.ms_srt(c["s"]), core.ms_srt(c["e"]), c["t"]) for n, c in enumerate(cues, 1))
    only = "\n".join("%d\n%s --> %s\n%s\n" % (n, core.ms_srt(c["s"]), core.ms_srt(c["e"]), t or "") for n, (c, t) in enumerate(zip(cues, trans), 1))
    files = [(folder + sep + "%s.%s.srt" % (base, src), orig),
             (folder + sep + "%s.%s.srt" % (base, target), only),
             (folder + sep + "%s.doppi.%s.srt" % (base, target), core.make_dual_srt(cues, trans, s["layout"], s["trans_color"] or "FFFF00"))]
    for path, text in files:
        _write(path, text)
    log("sottotitoli salvati: %s" % [p for p, _ in files])
    return [p for p, _ in files]


# ---------------------------------------------------------------------- traduzione fatta con una chat
CHAT_PART = 250


def chat_path(vkey, src_id, target):
    return os.path.join(CACHE, core.cache_key(vkey, src_id, target, "chat") + ".json")


def _ask_folder(last, title):
    s = settings()
    choices, folders = [], []
    vf = video_folder(last["video"])
    if vf:
        choices.append("Accanto al video"); folders.append(vf)
    if s.get("save_folder"):
        choices.append("Nella cartella delle impostazioni: " + s["save_folder"]); folders.append(s["save_folder"])
    choices.append("Scegli una cartella…"); folders.append(None)
    k = xbmcgui.Dialog().select(title, choices)
    if k < 0:
        return ""
    return folders[k] or xbmcgui.Dialog().browse(3, title, "files")


def export_menu(player):
    """Esporta trascrizione: file di testo con le frasi numerate e le istruzioni, da incollare in una chat
    (ChatGPT, Claude, Gemini…) per tradurle senza usare le richieste gratuite dei servizi"""
    if not os.path.isfile(LAST):
        notify("Non ho ancora frasi da esportare: crea prima i sottotitoli doppi di un video.", 7000)
        return
    last = json.load(open(LAST, encoding="utf-8"))
    folder = _ask_folder(last, "Dove salvo la trascrizione da tradurre?")
    if not folder:
        return
    cues, target = last["cues"], last["target"]
    tname = core.LANG_IT.get(target, target)
    sname = core.LANG_IT.get(last.get("src", ""), "")
    base = safe_name(last.get("title") or os.path.basename(last["video"].split("?")[0]))
    sep = "" if folder.endswith(("/", "\\")) else ("\\" if "\\" in folder and "://" not in folder else "/")
    parts = max(1, (len(cues) + CHAT_PART - 1) // CHAT_PART)
    paths = []
    for p in range(parts):
        a, b = p * CHAT_PART, min(len(cues), (p + 1) * CHAT_PART)
        head = ("Traduci in %s le frasi numerate qui sotto%s. Sono i sottotitoli di un video, in ordine: tieni conto del discorso "
                "e traduci in modo naturale ma fedele. Rispondi solo con le traduzioni, una per riga, ognuna con lo stesso numero "
                "davanti (per esempio \"%d. ...\"), senza unire, dividere o saltare frasi e senza commenti.%s\n\n") % (
            tname, (" (lingua originale: %s)" % sname) if sname else "", a + 1, (" (Parte %d di %d.)" % (p + 1, parts)) if parts > 1 else "")
        body = "\n".join("%d. %s" % (a + k + 1, " ".join(c["t"].split())) for k, c in enumerate(cues[a:b]))
        path = folder + sep + "%s.da-tradurre%s.txt" % (base, (".parte%d" % (p + 1)) if parts > 1 else "")
        _write(path, head + body + "\n")
        paths.append(path)
    notify("Trascrizione esportata in %d file: aprili sul computer, incolla il testo in una chat e salva la risposta in un file .txt" % len(paths), 9000)
    log("trascrizione esportata: %s" % paths)


def parse_chat(text):
    """Righe "12. testo", "12) testo", "12: testo" (anche con ** del grassetto delle chat) → {numero: testo}"""
    out = {}
    for line in text.replace("\r", "").split("\n"):
        m = re.match(r"^\s*(\d{1,5})\s*[.):\-–]\s*(.+?)\s*$", line.replace("**", ""))
        if m and m.group(2):
            out[int(m.group(1))] = m.group(2)
    return out


def import_menu(player):
    """Importa traduzione: uno o più file .txt con la risposta della chat (righe numerate)"""
    if not os.path.isfile(LAST):
        notify("Crea prima i sottotitoli doppi del video, poi importa la traduzione.", 7000)
        return
    last = json.load(open(LAST, encoding="utf-8"))
    sel = xbmcgui.Dialog().browse(1, "Scegli il file con la traduzione (.txt)", "files", ".txt", False, False, "", True)
    files = [x for x in (sel if isinstance(sel, (list, tuple)) else [sel]) if x]
    if not files:
        return
    got = {}
    for f in files:
        got.update(parse_chat(read_text(f)))
    cues = last["cues"]
    use = {n: t for n, t in got.items() if 1 <= n <= len(cues)}
    if not use:
        notify("In quel file non trovo righe numerate: salva la risposta della chat così com'è.", 8000)
        return
    trans = list(last.get("trans") or [""] * len(cues))
    for n, t in use.items():
        trans[n - 1] = t
    path = chat_path(last.get("vkey") or video_key(last["video"]), last.get("src_id", ""), last["target"])
    old = json.load(open(path, encoding="utf-8")).get("trans") if os.path.isfile(path) else None
    if old and len(old) == len(cues):
        for i, t in enumerate(old):          # parti importate prima restano
            if t and (i + 1) not in use:
                trans[i] = t
    json.dump({"trans": trans, "n": len(use)}, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    save_choice(last["video"], trans="chat")
    last["trans"] = trans
    json.dump(last, open(LAST, "w", encoding="utf-8"), ensure_ascii=False)
    missing = len(cues) - sum(1 for t in trans if t)
    notify("Traduzione importata: %d frasi%s." % (len(use), (", ne mancano %d (importa le altre parti)" % missing) if missing else ""), 8000)
    if player.isPlayingVideo() and video_key(player.getPlayingFile()) == (last.get("vkey") or video_key(last["video"])):
        run(player, interactive=True, trans_mode="chat")


def save_menu(player):
    """Voce del menu: salva i sottotitoli dell'ultimo video (da riusare o da condividere)"""
    if not os.path.isfile(LAST):
        notify("Non ho ancora sottotitoli da salvare: crea prima i sottotitoli doppi di un video.", 7000)
        return
    last = json.load(open(LAST, encoding="utf-8"))
    s = settings()
    choices, folders = [], []
    vf = video_folder(last["video"])
    if vf:
        choices.append("Accanto al video (Kodi e l'add-on li ritrovano da soli)"); folders.append(vf)
    if s.get("save_folder"):
        choices.append("Nella cartella delle impostazioni: " + s["save_folder"]); folders.append(s["save_folder"])
    choices.append("Scegli una cartella…"); folders.append(None)
    k = xbmcgui.Dialog().select("Salva i sottotitoli di: " + last.get("title", ""), choices)
    if k < 0:
        return
    folder = folders[k] or xbmcgui.Dialog().browse(3, "Dove salvo i sottotitoli?", "files")
    if not folder:
        return
    try:
        paths = save_files(folder, last)
        notify("Salvati %d file in %s (originale, traduzione e doppio)" % (len(paths), folder), 8000)
    except Exception as e:
        log("salvataggio: %r" % e)
        notify("Non riesco a salvare in quella cartella: %s" % e, 8000)


# ---------------------------------------------------------------------- traduzione già fatta da persone
def target_options(player, video, target):
    """Sottotitoli già tradotti nella lingua di arrivo per questo film: prima i file sul dispositivo
    (accanto al video o appena scaricati), poi OpenSubtitles, poi gli altri servizi installati"""
    out = []
    since = playback_since(player, video)
    base = os.path.splitext(os.path.basename(video.split("?")[0]))[0].lower()
    for c in item_subtitles(player) + candidates(video):
        path, mtime = c[0], c[1]
        is_temp = len(c) > 2 and c[2]
        name = os.path.basename(path).lower()
        if ".doppi." in name or looks_dual(path) or core.lang_from_filename(path) != target:
            continue
        if is_temp and since and mtime < since and not (base and name.startswith(base)):
            continue                                       # scaricato per un altro film
        out.append({"k": "file", "p": path, "l": target, "src": "file " + os.path.basename(path)})
    if not out:
        try:
            imdb, season, episode = film_info(video)
            info = {}
            found = core.online_subtitles(imdb, [target], season, episode, os.path.basename(video.split("?")[0]), info=info)
            out += [{"k": "online", "u": u, "l": l, "n": i + 1, "src": "OpenSubtitles"} for i, (u, l) in enumerate(found[:3])]
            log("traduzione già pronta (%s) su OpenSubtitles: %d (dettagli: %s)" % (target, len(found), info))
        except Exception as e:
            log("OpenSubtitles (traduzione già pronta): %r" % e)
    if not out:
        out += subdl_options(video, [target], per_lang=2)
    if not out and settings().get("use_services"):
        # OpenSubtitles.com e simili: ogni file scaricato consuma la quota del TUO account, quindi solo se lo permetti
        out = service_options([target], per_lang=2)
    return out


def human_translation(player, video, cues, src_id, target, s, progress=None, src_lang="", force=False):
    """Traduzione presa dai sottotitoli già tradotti del film, messi in fase con l'originale.
    Restituisce (traduzioni, descrizione) oppure (None, motivo). Le frasi senza corrispondenza le traduce Google."""
    if not force and s.get("trans_mode") == "nuova":
        return None, "spenta nelle impostazioni"
    hkey = core.cache_key(video_key(video), src_id, target, "umana")
    hpath = os.path.join(CACHE, hkey + ".json")
    if os.path.isfile(hpath):
        d = json.load(open(hpath, encoding="utf-8"))
        if d.get("trans"):
            return d["trans"], d.get("from", "")
        if time.time() - d.get("at", 0) < 86400 and not force:
            return None, d.get("none", "nessuna traduzione già pronta (cercata da poco)")
    best = None
    for o in target_options(player, video, target)[:4]:
        m = re.match(r"plugin://([^/]+)", o.get("u", "")) if o.get("k") == "service" else None
        if m and service_down(m.group(1)):
            continue
        try:
            path = o["p"] if o["k"] == "file" else fetch_online(o)
            tcues = core.parse_subs(read_text(path))
        except Exception as e:
            log("traduzione già pronta non letta (%s): %r" % (o.get("src"), e))
            continue
        lang = core.guess_lang_cues(tcues)
        if not tcues or (lang and lang != target):
            log("traduzione già pronta scartata (%s): lingua %s" % (o.get("src"), lang or "?"))
            continue
        trans, info = core.merge_human(cues, tcues, target)
        log("traduzione già pronta da %s: %s" % (o.get("src"), info))
        if not best or (info["in_fase"], info["coperte"]) > (best[1]["in_fase"], best[1]["coperte"]):
            best = (trans, info, o)
        if info["in_fase"] >= 0.75 and info["coperte"] >= 0.85:
            break
    # se meno di 6 frasi su 10 vanno in fase è probabilmente un'altra edizione (montaggio diverso): non la uso
    if not best or best[1]["in_fase"] < 0.6:
        why = "nessuna traduzione già pronta in fase con l'originale"
        try:
            json.dump({"none": why, "at": time.time()}, open(hpath, "w", encoding="utf-8"))
        except Exception:
            pass
        return None, why
    trans, info, o = best
    missing = [i for i, t in enumerate(trans) if not t]
    if missing:
        if progress:
            progress.update(80, NAME, "Traduco con Google le %d frasi senza traduzione già pronta" % len(missing))
        try:
            filled = core.google_translate_fast([cues[i]["t"] for i in missing], target, src_lang)
            for i, t in zip(missing, filled):
                trans[i] = t or ""
        except Exception as e:
            log("Google per le frasi mancanti: %r" % e)
    desc = "%s (%d%% delle frasi%s)" % (o.get("src", ""), round(info["coperte"] * 100),
                                         ", il resto con Google" if missing else "")
    if player.isPlayingVideo():
        json.dump({"trans": trans, "from": desc}, open(hpath, "w", encoding="utf-8"), ensure_ascii=False)
    return trans, desc


def find_source(player, video, target):
    found = [c for c in item_subtitles(player) + candidates(video) if not (c[1] > time.time() - 6 * 3600 and looks_dual(c[0]))]
    src = core.pick_subtitle(found, video, target, since=playback_since(player, video), prefer_lang=current_sub_lang(player))
    if not src:
        log("nessun sottotitolo: video=%s lingua nel lettore=%s candidati=%s" % (
            video, current_sub_lang(player), [os.path.basename(c[0]) for c in found][:30]))
    return src


def embedded_streams(video, s):
    """Tracce di sottotitoli di testo dentro il file (solo file sul dispositivo, serve ffmpeg)"""
    if not video or ("://" in video and not video.startswith("special://")):
        return []
    ffmpeg = core.find_ffmpeg(s.get("ffmpeg", ""))
    if not ffmpeg:
        return []
    real = xbmcvfs.translatePath(video) if "://" in video else video
    return [x for x in core.list_sub_streams(ffmpeg, real) if x[3]]


def extract_stream(video, s, index):
    """Salva la traccia incorporata come .srt nella cache e ne restituisce il percorso"""
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, "traccia-%s-%d.srt" % (core.cache_key(video_key(video)), index))
    if not os.path.isfile(path):
        real = xbmcvfs.translatePath(video) if "://" in video else video
        text = core.extract_sub_stream(core.find_ffmpeg(s.get("ffmpeg", "")), real, index)
        open(path, "w", encoding="utf-8").write(text)
    return path


# ---------------------------------------------------------------------- messa in fase con l'audio
SYNC_WINDOWS = (0.22, 0.62)     # tratti del film ascoltati (frazioni della durata), 90 secondi l'uno


def _from_inside(path):
    """Sottotitoli letti dentro il video stesso: sono già in fase"""
    b = os.path.basename(path or "")
    return b.startswith(("mkv-", "mkv2-", "traccia-", "realdebrid-"))


def film_energy(player, video, s, progress=None):
    """Energia della voce in due tratti del film (salvata: si legge una volta sola per film)"""
    path = os.path.join(CACHE, "energia-%s.json" % core.cache_key(video_key(video)))
    try:
        return json.load(open(path, encoding="utf-8"))
    except Exception:
        pass
    ffmpeg = core.find_ffmpeg(s.get("ffmpeg", ""))
    if not ffmpeg:
        return None
    try:
        dur = float(player.getTotalTime() or 0)
    except Exception:
        dur = 0
    if dur < 600:
        return None
    media = video if "://" not in video or re.match(r"^https?://", video) else xbmcvfs.translatePath(video)
    wins = []
    for k, f in enumerate(SYNC_WINDOWS):
        if progress:
            progress.update(46, NAME, "Metto in fase i sottotitoli con l'audio del film (%d di %d)…" % (k + 1, len(SYNC_WINDOWS)))
        try:
            en = core.audio_energy(ffmpeg, media, dur * f, 90)
        except Exception as e:
            log("audio per la messa in fase non letto: %r" % e)
            en = []
        if len(en) >= 300:
            wins.append((round(dur * f, 2), en))
    if len(wins) < 2:
        log("messa in fase: audio del film non letto (%d tratti)" % len(wins))
        return None
    try:
        json.dump(wins, open(path, "w", encoding="utf-8"))
    except Exception:
        pass
    return wins


def sync_to_audio(player, video, cues, source, s, progress=None, alternatives=False):
    """Mette in fase con l'audio i sottotitoli presi fuori dal video (spostamento e velocità, per esempio 25 → 23,976
    fotogrammi al secondo). Se sono di OpenSubtitles scelti da me, prova anche le altre versioni e tiene quella che va
    meglio con l'audio. Restituisce (frasi, file)."""
    if not s.get("sync_audio", True) or not cues or _from_inside(source):
        return cues, source
    key = core.cache_key(video_key(video), *["%d|%d|%s" % (c["s"], c["e"], c["t"]) for c in cues[:400]])
    spath = os.path.join(CACHE, "fase-%s.json" % key)
    try:
        d = json.load(open(spath, encoding="utf-8"))
        if d.get("source") and d["source"] != source and os.path.isfile(d["source"]):
            source = d["source"]
            cues = core.parse_subs(read_text(source))
        return (core.apply_sync(cues, d["a"], d["b"]) if d.get("apply") else cues), source
    except Exception:
        pass
    wins = film_energy(player, video, s, progress)
    if not wins:
        return cues, source
    cands = [(source, cues)]
    if alternatives and os.path.basename(source).startswith("opensubtitles-"):
        lang = core.lang_from_filename(source)
        try:
            for o in online_options(player, video, s["target"], per_lang=4, services=False):
                if o["l"] == lang and len(cands) < 5:
                    p = fetch_online(o)
                    if p != source:
                        cands.append((p, core.parse_subs(read_text(p))))
        except Exception as e:
            log("messa in fase: altre versioni non lette: %r" % e)
    best = None
    for path, cs in cands:
        r = core.best_sync(cs, wins)
        if r:
            log("messa in fase %s: %s" % (os.path.basename(path), r))
        if r and (not best or r["score"] > best[2]["score"]):
            best = (path, cs, r)
    if not best:
        return cues, source
    path, cs, r = best
    # cambio solo se va chiaramente meglio: altrimenti i sottotitoli erano già in fase
    apply = r["score"] - r["base"] >= 0.08 and (abs(r["b"]) >= 0.25 or r["a"] != 1.0)
    try:
        json.dump(dict(r, apply=apply, source=path), open(spath, "w", encoding="utf-8"))
    except Exception:
        pass
    if path != source:
        notify("Ho scelto la versione dei sottotitoli che va meglio con l'audio del film.", 5000)
    if apply:
        what = "spostati di %+.1f s" % r["b"]
        if r["a"] != 1.0:
            what += " e con la velocità corretta"
        notify("Sottotitoli messi in fase con l'audio del film (%s)." % what, 6000)
        cs = core.apply_sync(cs, r["a"], r["b"])
    return cs, path


# ---------------------------------------------------------------------- lavoro principale
def run(player, manual_path=None, force_transcribe=False, interactive=False, upgrade=False, source_mode=None, trans_mode=None,
        retranslate=False, orig_only=False):
    """upgrade: chiamata dal menu dei sottotitoli del lettore dopo la versione veloce di Google:
    traduce con il servizio scelto e cambia i sottotitoli solo alla fine, senza versioni a metà.
    source_mode: "auto" / "trascrizione" / "file"; trans_mode: "auto" / "nuova" / "pronta"
    (se mancano: scelta fatta per questo video dal menu, altrimenti impostazioni)."""
    if not _busy.acquire(False):
        if interactive:
            notify("Sto già preparando i sottotitoli doppi…")
        return
    progress = None
    retry = False
    try:
        if not player.isPlayingVideo():
            if interactive:
                notify("Avvia prima un video")
            return
        video = player.getPlayingFile()
        who = busy_info()
        if who == "auto" and interactive:
            # stava lavorando da solo (per esempio con una traccia scelta in automatico): conta la tua scelta
            notify("Interrompo la preparazione automatica e parto con la tua scelta…", 5000)
            if not cancel_auto():
                notify("Sto ancora finendo un passaggio: riprova tra qualche secondo.", 6000)
                return
        elif who:
            if interactive:
                notify("Sto già preparando i sottotitoli doppi: guarda la barra in alto a destra.", 6000)
            return
        s = settings()
        target = s["target"]
        os.makedirs(CACHE, exist_ok=True)
        progress = Bar("Cerco i sottotitoli originali…", auto=not interactive)
        chosen = load_choice(video)
        smode = "file" if manual_path else ("trascrizione" if force_transcribe else None) or source_mode or \
            chosen.get("source") or s["source_mode"]
        tmode = trans_mode or chosen.get("trans") or s["trans_mode"]

        # --- da dove viene l'originale
        source = None
        if manual_path:
            source = manual_path
        elif smode == "file" and chosen.get("pick"):
            o = chosen["pick"]
            try:
                source = o["p"] if o["k"] == "file" else fetch_mkv(o, video, progress) if o["k"] == "mkv" else \
                    fetch_online(o) if o["k"] in ("online", "service", "rd", "subdl") else extract_stream(video, s, o["i"])
            except Exception as e:
                log("sottotitoli scelti non letti (%s): %r" % (o.get("name"), e))
                source = file_source(player, video, target, s, progress)
        elif smode in ("auto", "file"):
            source = file_source(player, video, target, s, progress)
        # in automatico: mai sottotitoli in una lingua diversa da quella originale del film (per esempio quelli
        # del doppiaggio russo con cui parte il file di un film tedesco)
        orig = original_lang(video)
        if source and not manual_path and not chosen.get("pick") and orig and orig != target:
            try:
                sl = core.lang_from_filename(source) or core.guess_lang_cues(core.parse_subs(read_text(source)))
            except Exception:
                sl = ""
            if sl and sl != orig:
                log("sottotitoli in %s scartati: il film è in %s" % (sl, orig))
                source = None
                if smode != "trascrizione" and not s["transcribe"]:
                    if interactive or s["auto"]:
                        notify("Non trovo sottotitoli in %s, la lingua del film (solo in %s): non li traduco. Scegli tu dal menu "
                               "dell'add-on (Scegli i sottotitoli originali da tradurre) o fai trascrivere l'audio originale." % (
                                   core.LANG_IT.get(orig, orig), core.LANG_IT.get(sl, sl)), 12000)
                    return
        use_whisper = smode == "trascrizione" or (smode == "auto" and not source and (s["transcribe"] or has_transcript(video, s)))
        if not source and not use_whisper:
            if interactive or s["auto"]:
                lang_txt = (" in %s (la lingua del film)" % core.LANG_IT.get(orig, orig)) if orig and orig != target else " originali"
                notify("Non trovo sottotitoli%s per questo video. Dal menu dell'add-on: \"Scegli i sottotitoli "
                       "originali da tradurre…\", oppure fai trascrivere l'audio originale." % lang_txt, 10000)
            return

        progress.update(48, NAME, "Preparo i sottotitoli…")

        if source and not use_whisper:
            cues = core.parse_subs(read_text(source))
            # sottotitoli presi fuori dal video (OpenSubtitles, scaricati, un file): li metto in fase con l'audio
            cues, source = sync_to_audio(player, video, cues, source, s, progress, alternatives=not manual_path and not chosen.get("pick"))
            src_lang = core.lang_from_filename(source) or core.guess_lang_cues(cues)
            src_id = os.path.basename(source) + "|" + str(len(cues))
            legacy = (src_id, os.path.getmtime(source) if os.path.isfile(source) else 0)
            src_id += "|" + core.cache_key(*[c["t"] for c in cues])[:10]   # contenuto: file diverso con lo stesso nome = altra traduzione
        else:
            fresh = not has_transcript(video, s)
            cues, src_lang = get_transcript(player, video, s, progress)
            # trascrizione appena finita: si vede subito l'originale da solo, poi arriva la versione doppia
            if cues and (fresh or orig_only) and has_transcript(video, s) and not upgrade:
                only = transcript_only_srt(video, s)
                if only:
                    player.setSubtitles(only)
                    if orig_only:
                        notify("Trascrizione in %s: solo l'originale, senza traduzione." % core.LANG_IT.get(src_lang, src_lang or "lingua originale"), 6000)
                        return
                    notify("Trascrizione pronta: intanto vedi l'originale, la traduzione arriva tra poco.", 6000)
            tp = transcript_paths(video, s)[0]
            legacy = ("trascrizione", os.path.getmtime(tp) if os.path.isfile(tp) else 0)
            src_id = "trascrizione|" + core.cache_key(*[c["t"] for c in cues])[:10]
        if not cues:
            notify("Nei sottotitoli non ho trovato frasi da tradurre.")
            return
        if src_lang and src_lang == target:
            notify("I sottotitoli sono già nella lingua in cui traduci.")
            return

        # --- traduzione (salvata: rivedendo il video o cambiando scelta è subito pronta)
        model = s.get(s["engine"] + "_model", "")
        key = core.cache_key(video_key(video), src_id, target, s["engine"], model)
        jpath = os.path.join(CACHE, key + ".json")
        out = os.path.join(CACHE, "%s.doppi.%s.srt" % (key, target))
        write = lambda trans: open(out, "w", encoding="utf-8").write(
            core.make_dual_srt(cues, trans, s["layout"], s["trans_color"] or "FFFF00"))

        trans, human = None, None
        cpath = chat_path(video_key(video), src_id, target)
        if tmode in ("auto", "chat") and os.path.isfile(cpath) and not retranslate:
            # traduzione importata da una chat (Importa traduzione): ha la precedenza, è stata scelta apposta
            trans = json.load(open(cpath, encoding="utf-8"))["trans"]
            human = "importata da una chat"
        # traduzione già fatta da persone: chiesta ("pronta"), oppure in automatico solo se l'originale è un file
        # di sottotitoli (la trascrizione divide le frasi in modo diverso e spesso non va in fase)
        want_human = trans is None and not retranslate and (tmode == "pronta" or (tmode == "auto" and not src_id.startswith("trascrizione")))
        if want_human and not (tmode == "auto" and os.path.isfile(jpath)):
            progress.update(50, NAME, "Cerco una traduzione già pronta…")
            trans, human = human_translation(player, video, cues, src_id, target, s, progress, src_lang, force=tmode == "pronta")
            if trans is None:
                log("traduzione già pronta: %s" % human)
                if tmode == "pronta":
                    notify("Non trovo una traduzione già pronta in fase con l'originale: faccio una traduzione nuova.", 6000)
                human = None
        if trans is None:
            # traduzione completa salvata dalle versioni precedenti (stessi sottotitoli, salvata dopo di loro)
            lj = os.path.join(CACHE, core.cache_key(video_key(video), legacy[0], target, s["engine"], model) + ".json")
            if not os.path.isfile(jpath) and os.path.isfile(lj) and os.path.getmtime(lj) >= legacy[1]:
                jpath_old = lj
            else:
                jpath_old = None
            trans = translate_with_memory(player, video, cues, s, target, src_lang, jpath, progress, write, out,
                                          upgrade=upgrade, redo=retranslate, legacy=jpath_old)
        else:
            trans = fill_missing(cues, trans, target, src_lang)
        write(trans)
        remember_result(video, cues, trans, src_lang, target, src_id)
        if load_choice(video).get("auto") != "si":
            save_choice(video, auto="si")
        if s["save_auto"] and (s.get("save_folder") or video_folder(video)):
            try:
                save_files(s.get("save_folder") or video_folder(video))
            except Exception as e:
                log("salvataggio automatico: %r" % e)
        if player.isPlayingVideo() and (not upgrade or player.getPlayingFile() == video):
            player.setSubtitles(out)
            player.showSubtitles(True)
            what = "trascrizione" if src_id.startswith("trascrizione") else "sottotitoli"
            if human == "importata da una chat":
                notify("Sottotitoli doppi pronti (%s + traduzione importata da una chat)" % what, 6000)
            elif human:
                notify("Sottotitoli doppi pronti (%s + traduzione già fatta: %s)" % (what, human), 6000)
            else:
                notify(("Traduzione migliorata con %s pronta" % engine_name(s)) if upgrade
                       else "Sottotitoli doppi pronti (%s, %d frasi)" % (what, len(cues)), 3000)
    except core.Cancelled:
        log("lavoro automatico interrotto: hai fatto una scelta a mano")
    except core.WrongAudio as e:
        # solo doppiaggi: non trascrivo a caso un'altra lingua (ci vorrebbe tanto e non serve a imparare quella del film)
        log("audio originale assente: %s" % e)
        if interactive and xbmcgui.Dialog().yesno(NAME, str(e) + "\n\nScegli piuttosto dei sottotitoli nella lingua del film "
                                                  "(menu → Scegli i sottotitoli originali da tradurre). Trascrivo comunque il doppiaggio?"):
            _ALLOW_DUB.add(video_key(player.getPlayingFile()))
            retry = True
        elif not interactive:
            notify(str(e), 12000)
    except core.QuotaError as e:
        # quota finita: lo dico chiaramente (un avviso di pochi secondi si perde)
        log("quota finita: %s" % e)
        if interactive:
            xbmcgui.Dialog().ok(NAME, str(e))
        else:
            notify(str(e), 15000)
    except core.Fatal as e:
        notify(str(e), 8000)
    except Exception as e:
        log("errore: %r" % e)
        notify("Errore: %s" % e, 8000)
    finally:
        if progress:
            progress.close()
        _busy.release()
    if retry:
        return run(player, manual_path, force_transcribe, interactive, upgrade, source_mode, trans_mode, retranslate)

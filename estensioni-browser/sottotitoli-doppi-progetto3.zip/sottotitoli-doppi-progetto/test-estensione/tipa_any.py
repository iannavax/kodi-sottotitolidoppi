import asyncio
from playwright.async_api import async_playwright
SRC = open("/home/claude/sottotitoli-doppi-progetto/estensione/src/etym.js").read()
H2 = lambda t: f'<div class="mw-heading mw-heading2"><h2 id="x">{t}</h2></div>'
H3 = lambda t: f'<div class="mw-heading mw-heading3"><h3>{t}</h3></div>'
P = lambda b: '<div class="mw-parser-output">' + b + '</div>'
cases = [
 ("ru", "ru", P(H2("Русский") + H3("Морфологические и синтаксические свойства") + "<table><tr><td>ко́шку</td></tr></table>" + H3("Произношение") + '<ul><li>МФА: [ˈkoʂkʊ]</li></ul>' + H2("Белорусский") + "<p>[bel]</p>")),
 ("ru", "ru", P(H2("Русский") + H3("Произношение") + '<p><span class="IPA">[ˈkoʂkʊ]</span></p>')),
 ("cs", "cs", P(H2("čeština") + H3("výslovnost") + '<ul><li>IPA: <span class="IPA">[ˈxlɛba]</span></li></ul>')),
 ("de", "de", P(H2("Brot (Deutsch)") + '<p><b>Aussprache:</b></p><dl><dd><a>IPA</a>: [<span class="ipa">bʁoːt</span>]</dd></dl>')),
 ("fr", "fr", P(H2("Français") + '<p><b>pain</b> <a><span class="API" title="Prononciation API">\\pɛ̃\\</span></a> masculin</p>')),
 ("cs", "it", P(H2("Ceco") + '<p><b>chleba</b></p><p>Pronuncia: IPA: /ˈxlɛba/</p>')),
 ("cs", "fr", P(H2("Français") + '<p><span class="API">\\pɛ̃\\</span></p>' + H2("Tchèque") + '<p><span class="API">\\ˈxlɛba\\</span></p>')),
 ("cs", "de", P(H2("Brot (Deutsch)") + '<dl><dd>IPA: [<span class="ipa">bʁoːt</span>]</dd></dl>')),
 ("pl", "pl", P(H2("chleb (język polski)") + '<dl><dd>IPA: <span class="ipa">[xlɛp]</span></dd></dl>')),
 ("ja", "ja", P(H2("日本語") + '<p>発音: べんきょう</p>')),
]
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(channel="chromium", headless=True); pg = await b.new_page()
        await pg.set_content("<html><body></body></html>")
        await pg.evaluate("window.DS_EXT={storage:{local:{get:()=>Promise.resolve({}),set:()=>Promise.resolve()}},runtime:{sendMessage:()=>Promise.resolve({})}}")
        await pg.add_script_tag(content=SRC + "\nwindow.E=DS_ETYM;")
        for lang, ed, html in cases:
            print(lang, ed, "→", repr(await pg.evaluate("([h,l,e])=>E.extractIpaAny(h,l,e)", [html, lang, ed])))
        await b.close()
asyncio.run(main())

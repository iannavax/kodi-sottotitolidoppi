// Le due schede in cima al popup dell'estensione unica
(() => {
  const here = /popup-pagine/.test(location.pathname) ? "pagine" : "video";
  const bar = document.createElement("div");
  bar.className = "unica-tabs";
  bar.setAttribute("style", "display:flex;gap:6px;padding:8px 10px 6px;background:#10151d;border-bottom:1px solid #2c3646;position:sticky;top:0;z-index:50");
  for (const [id, label, title] of [["video", "🎬 Video", "Sottotitoli doppi, trascrizione e scheda delle parole nei video"], ["pagine", "📄 Pagine", "Parole al Volo: scheda delle parole e traduzione sulle pagine web"]]) {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = label;
    b.title = title;
    const on = id === here;
    b.setAttribute("style", "flex:1;cursor:pointer;font:600 13px system-ui,sans-serif;padding:6px 8px;border-radius:8px;border:1px solid " +
      (on ? "#f5c84b;background:#3b3520;color:#ffe39a" : "#3a4557;background:#1d2430;color:#c9d2de"));
    b.addEventListener("click", () => {
      try { localStorage.setItem("unicaTab", id); } catch {}
      if (!on) location.replace(id === "pagine" ? "popup-pagine.html" : "popup-video.html");
    });
    bar.append(b);
  }
  document.body.prepend(bar);
  try { localStorage.setItem("unicaTab", here); } catch {}
})();

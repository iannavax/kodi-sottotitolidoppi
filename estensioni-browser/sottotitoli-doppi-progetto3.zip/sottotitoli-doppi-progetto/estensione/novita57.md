## Novità della 5.8: meno richieste, servizi di riserva, traduzione con una chat, trascrizione che resta nella lingua giusta
**Meno richieste a Gemini (la quota dura molto di più).**
- La traduzione si chiede a gruppi di **120 frasi** invece di 40: un film di 2 ore costa circa 12 richieste invece di 38.
- Il collegamento parola tradotta ↔ originale e i modi di dire si chiedono **per 8 frasi alla volta**: passando sulle frasi seguenti sono già pronti, senza nuove richieste.
- Le **spiegazioni delle parole restano salvate** anche chiudendo il browser (le ultime 1500): la stessa parola nella stessa frase non si richiede più.

**Servizi di riserva.** Quando un servizio finisce le richieste gratuite di oggi, l'estensione continua da sola con il primo altro servizio di cui hai inserito la chiave, in quest'ordine: Gemini, Groq, Mistral, OpenRouter, Microsoft Translator, DeepL; alla fine Google Traduttore. Il servizio esaurito viene saltato fino al giorno dopo (anche negli altri video), così non si sprecano richieste. Nel popup, sotto la scelta del servizio, c'è l'elenco dei servizi di riserva pronti e di quelli finiti per oggi. Si può spegnere con la casella "Se finiscono le richieste gratuite, continua con un altro servizio".

**Servizi nuovi.**
- **Mistral** (gratis con chiave, console.mistral.ai): buona qualità nelle lingue europee.
- **Microsoft Translator** (gratis con chiave, 2 milioni di caratteri al mese, circa 40 film): traduttore classico, più preciso di Google, senza limiti al minuto. Serve un account Azure: crea una risorsa "Translator" con il piano gratuito F0, poi incolla nel popup la chiave e l'area (per esempio westeurope).

**Traduzione con una chat, senza quote.** Nella pagina "Trascrizione e traduzione":
- **Copia trascrizione** copia le frasi numerate con le istruzioni (a parti di 250 frasi se il video è lungo: il pulsante dice quale parte copierà).
- Incollale in una chat (ChatGPT, Claude, Gemini…), copia la risposta e premi **Incolla traduzione**: l'estensione legge le righe numerate, controlla che sia davvero una traduzione e la usa sul video. Resta salvata con il video, come le correzioni.

**La trascrizione non diventa più inglese.** Whisper, quando non gli si dice la lingua, a volte scrive in inglese quello che sente in un'altra lingua (cioè traduce invece di trascrivere). Ora:
- nei primi pezzi la lingua si decide "a voti" (contano solo i pezzi con abbastanza parlato); con 3 voti si fissa e da lì viene **imposta a Whisper** per tutto il video;
- i primi pezzi venuti in un'altra lingua vengono rifatti nella lingua giusta;
- se un pezzo esce comunque in inglese in un video non inglese, viene rifatto;
- un vero cambio di lingua (per esempio un video che passa dall'inglese all'italiano) viene ancora seguito, ma solo se Whisper è chiaramente più sicuro della lingua nuova per due pezzi di fila (e mai verso l'inglese, che è proprio l'errore da evitare). Se serve, la lingua si può sempre imporre nel popup con "Lingua parlata".

## Novità della 5.7.5
- **Reverso c'è sempre.** Nella 5.7.4 il collegamento a Reverso compariva solo per le lingue che Reverso apre già pronte da un indirizzo (inglese, italiano, spagnolo, francese, tedesco, russo, ecc.), quindi con il ceco non c'era. Ora c'è sempre: con queste lingue si apre già con la parola o la frase; con le altre, come il ceco, si apre Reverso e il testo viene copiato da solo: basta incollarlo (Ctrl+V) nella casella e scegliere le lingue.

## Novità della 5.7.4: copiare il testo e consultare i servizi di traduzione
- **Sul video**, accanto al pulsante ⚑ c'è il pulsante **⧉** (compare passando il mouse sui sottotitoli). Apre una scheda con la frase: il video si ferma, e il testo si può selezionare con il mouse. Ci sono i pulsanti **Copia originale**, **Copia traduzione** e **Copia tutte e due**; se selezioni solo una parte, copiano quella parte.
- **Apri in: Google Traduttore · DeepL · Reverso**: la frase (o la parte selezionata) si apre in un'altra scheda, già con le due lingue giuste. Reverso mostra la parola o l'espressione dentro tante frasi vere, utile per capire come si usa.
- **Nella scheda di una parola** (o di un'espressione) ci sono anche **Copia la parola** e **Copia la frase**, più i collegamenti a Google Traduttore, DeepL, Reverso, **WordReference** (tra inglese e italiano, spagnolo, francese, tedesco, portoghese) e **Wiktionary** (che spiega quasi ogni parola di quasi ogni lingua, anche il ceco).
- **Trascinando sulla traduzione** (confronto con l'originale), nell'etichetta ci sono anche **Copia** e i collegamenti.
- **Pagina "Trascrizione e traduzione" sistemata per copiare:**
  - prima la pagina si ridisegnava da sola ogni 3 secondi, anche mentre selezionavi: la selezione si perdeva o si allargava a tutta la pagina. Ora si ridisegna solo quando arriva testo nuovo, e mai mentre selezioni;
  - nella vista "Frase per frase" la selezione prende solo il testo: l'ora e i pulsanti non entrano più;
  - il "Testo unico" è diviso in paragrafi veri, più facili da selezionare;
  - selezionando una parte compare una barra con **Copia** e i collegamenti ai servizi di traduzione (se selezioni nella traduzione, il verso è al contrario);
  - ogni frase ha il pulsante **⧉** per copiarla con la sua traduzione.

## Novità della 5.7.3: parola giusta e particelle segnalate
- **Ogni parola tradotta rimanda alla parola che traduce davvero, non a quella vicina.** Prima, se il modello non collegava bene una parola (per esempio "angoli"), l'estensione prendeva la parte della parola accanto, e così si illuminava la parola dopo ("narozi" no, la seguente sì). Ora in quel caso cerca la traduzione vera: traduce con Google parola per parola la frase originale (una sola richiesta per frase, gratis) e collega "angoli" alla parola dell'originale che significa "angolo". Lo stesso vale per chi traduce con Google.
- Al modello (Gemini, Groq, Claude) si chiedono coppie più piccole possibile: una parola con la sua corrispondente quando la traduzione è letterale.
- **Particelle della traduzione segnalate.** Articoli, preposizioni e ausiliari che l'originale non ha (per esempio "i" in "i gatti" per l'inglese "cats", o "gli" per il ceco, che non ha articoli) non sono la traduzione di una parola:
  - passando il mouse compare l'etichetta **particella** e la spiegazione: «i» non traduce una parola dell'originale: la aggiunge la grammatica della traduzione in «i gatti», che traduce **cats**. Nell'originale la parte collegata è contornata a tratteggio, e si illumina anche il resto del gruppo nella traduzione;
  - dopo che il modello ha allineato la frase, le particelle restano **sottolineate a puntini** nella traduzione, così si riconoscono a colpo d'occhio;
  - passando sull'originale, si illumina la sua traduzione e, più tenui, le particelle che la accompagnano.
- Se una parola non ha una traduzione diretta (traduzione libera, o particella riconosciuta solo con Google), l'etichetta lo dice chiaramente e indica la zona della frase, con la scritta "circa", invece di fingere una corrispondenza precisa.

## Novità della 5.7.2: ogni parola della traduzione rimanda sempre all'originale
- **Non compare più "Nessuna parola corrispondente nell'originale".** Passando il mouse su una parola della traduzione si illumina sempre la parte dell'originale da cui viene.
- **Parole che la traduzione aggiunge** (articoli, preposizioni, verbi ausiliari: per esempio "del" in "una fetta del pane"): l'etichetta mostra la parte dell'originale a cui sono legate e spiega che nell'originale non hanno una parola propria. Così si capisce anche come cambia la grammatica tra le due lingue.
- Al modello (Gemini, Groq, Claude) si chiede di collegare ogni parola a una parte dell'originale, senza lasciarne nessuna vuota.
- Funziona meglio con apostrofi diversi ("l’acqua" e "l'acqua"), parole con il trattino e lingue scritte senza spazi (cinese, giapponese, thailandese).
- Se il modello non risponde (quota finita, errore), l'etichetta non resta più ferma su "Cerco…": passa a Google. Se anche Google non trova la parola, la cerca insieme alle parole vicine e, come ultima risorsa, indica la zona della frase con la scritta "posizione stimata".
- Cliccando una parola della traduzione si apre la scheda della parola principale della parte corrispondente (per esempio "bread" e non "the").
- Lo stesso vale per il confronto trascinando sulla traduzione: con Google la parte si cerca solo nella zona giusta della frase (prima parole comuni come "the" potevano illuminare quasi tutta la riga).
- I modi di dire vengono riconosciuti anche quando il modello scrive l'apostrofo in modo diverso.

## Novità della 5.7.1
- **"↻ Ritraduci" aggiorna subito anche i sottotitoli sul video.** Prima la nuova traduzione compariva solo nella scheda, e sul video restava quella vecchia finché non chiudevi la scheda. Ora cambia subito anche sotto l'originale. Lo stesso vale per "Ritrascrivi" e "Correggi a mano".

## Novità della 5.7: pulsante DS nel lettore e confronto delle frasi

### Pulsante DS per accendere e spegnere i sottotitoli doppi
- **Su YouTube** c'è un pulsante **DS** nella barra dei comandi del video, accanto al pulsante dei sottotitoli. **Sugli altri siti** è un piccolo pulsante "DS" in alto a destra del video: è semitrasparente e diventa pieno quando ci passi sopra.
- **Acceso** (bordo giallo): si vedono i sottotitoli doppi. **Spento**: spariscono, e la trascrizione dell'audio si ferma, così non consuma la quota di Groq e Gemini. Sono spenti finché non lo riaccendi, anche negli altri video, come il pulsante dei sottotitoli di YouTube.
- Se i sottotitoli doppi sono spariti per qualsiasi motivo (per esempio i sottotitoli di YouTube si sono spenti, o il testo si è perso), **premendo DS tornano**: l'estensione riaccende i sottotitoli di YouTube e, se serve, li richiede di nuovo. Nei video senza sottotitoli fa ripartire la trascrizione.
- La casella "Sottotitoli doppi attivi" del popup (sezione Altro) fa la stessa cosa.

### Confronto di una parte della traduzione con l'originale
- **Tieni premuto sulla prima parola della traduzione e trascina fino all'ultima**: le parole scelte si colorano di azzurro, e nella riga originale si illumina la parte corrispondente. Sopra compare un'etichetta con quel pezzo di originale e il pulsante **Spiega**, che apre la scheda con il suo significato nel contesto.
- Con Gemini, Groq o Claude la corrispondenza è precisa. Con Google è approssimata (nell'etichetta c'è scritto "circa").
- Il confronto resta visibile anche spostando il mouse. Si chiude con **Esc** o cliccando altrove nei sottotitoli.
- Trascinando sui sottotitoli il browser non seleziona più il testo, e i sottotitoli non spariscono.


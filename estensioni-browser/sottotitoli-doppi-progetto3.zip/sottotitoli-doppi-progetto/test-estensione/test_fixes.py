import asyncio, json, sys, os
from bharness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', autoTranscribe:true})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}}))""")
        errs = []
        async def lines(pg):
            return await pg.evaluate("({o:(document.querySelector('.dualsub-orig')||{}).textContent||'', t:(document.querySelector('.dualsub-trans')||{}).textContent||''})")

        # A. pausa a metà frase (la frase 2 va da 3,2 a 7,0 s): il pezzo non deve essere tagliato a 5 s
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        os.environ["LANG_FLIP"] = "1"   # B. il 2° pezzo arriva "in italiano"
        await pg.goto("https://www.youtube.com/watch?v=noCapsA"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("document.querySelector('video').currentTime > 5.0", timeout=10000)
        await pg.evaluate("document.querySelector('video').pause()")
        await pg.wait_for_timeout(4000)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("document.querySelector('video').currentTime > 40", timeout=60000)
        await pg.wait_for_timeout(5000)
        bounds, t = [], 0
        for d in log["groq"]: t += d; bounds.append(round(t, 1))
        print("A. pezzi (s):", log["groq"], "\n   fine dei pezzi nel video (s):", bounds[:6], "(pause dell'audio: 2.6-3.2, 7.0-7.6, 9.5-10.1, 15.3-15.9, 19.0-19.6)")
        print("B. lingua forzata nelle richieste:", log["groq_lang"])
        dbg = json.loads(await pg.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))
        print("   frasi 'italiane' rimaste:", [c["text"] for c in dbg if "italiana" in c["text"]], "| frasi totali:", len(dbg))
        await pg.evaluate("const v=document.querySelector('video'); v.currentTime=8; v.pause()"); await pg.wait_for_timeout(700)
        print("   a 8 s:", await lines(pg))

        # C. il modello ricopia l'originale invece di tradurre
        os.environ["LANG_FLIP"] = ""; os.environ["GEM_MODE"] = "echo"
        pg2 = await ctx.new_page(); pg2.on("pageerror", lambda e: errs.append(str(e)))
        await pg2.goto("https://www.youtube.com/watch?v=noCapsC"); await pg2.wait_for_timeout(1200)
        await pg2.evaluate("document.querySelector('video').play()")
        await pg2.wait_for_timeout(22000)
        await pg2.evaluate("const v=document.querySelector('video'); v.currentTime=4; v.pause()"); await pg2.wait_for_timeout(700)
        saved = await sw.evaluate("chrome.storage.local.get(null).then(a=>Object.keys(a).filter(k=>k.startsWith('livetr:noCapsC')).map(k=>Object.keys(a[k]).length))")
        print("C. Gemini ricopia: sul video", await lines(pg2), "| traduzioni salvate:", saved)

        # D. numeri davanti alle traduzioni
        os.environ["GEM_MODE"] = "numbered"
        pg3 = await ctx.new_page()
        await pg3.goto("https://www.youtube.com/watch?v=noCapsD"); await pg3.wait_for_timeout(1200)
        await pg3.evaluate("document.querySelector('video').play()")
        await pg3.wait_for_timeout(22000)
        await pg3.evaluate("const v=document.querySelector('video'); v.currentTime=4; v.pause()"); await pg3.wait_for_timeout(700)
        print("D. modello che numera:", await lines(pg3))

        # E. risposta illeggibile sui sottotitoli di YouTube: la traduzione deve andare avanti lo stesso
        os.environ["GEM_MODE"] = "bad"
        pg4 = await ctx.new_page()
        await pg4.goto("https://www.youtube.com/watch?v=longE"); await pg4.evaluate("document.querySelector('video').play()")
        st = ""
        for _ in range(80):
            await pg4.wait_for_timeout(1000)
            st = await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status.text)")
            if "completata" in st or "Errore" in st: break
        print("E. risposta illeggibile:", st)
        print("   sul video:", await lines(pg4))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

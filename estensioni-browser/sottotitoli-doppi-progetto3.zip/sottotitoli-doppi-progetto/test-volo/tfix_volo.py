# Parole al Volo 1.5: ⚑ traduzione sbagliata (rifai con Google / con il modello / correggi a mano, salvata) e ⚙ voce
import asyncio, os, sys, json
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
async def handle(route, request):
    if ".wiktionary.org/" in request.url or "tts.speech.microsoft.com" in request.url: return await charness.handle(route, request)
    return await tvolo.handle(route, request)
T = lambda pg: pg.evaluate("(document.querySelector('.pav-card')||{}).innerText||''")
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'gemini', learnExamples:false, learnSpell:false, learnFreq:false, etym:false}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        async def openb():
            await tvolo.hover(pg, "en", "bread", 2000)
            box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await openb()
        await pg.locator(".pav-card .pav-linkbtn", has_text="Traduzione sbagliata").click(); await pg.wait_for_timeout(300)
        print("1. opzioni:", await pg.evaluate("[...document.querySelectorAll('.pav-card .pav-fixbox > .pav-btn')].map(b=>b.textContent)"))
        n = len(tvolo.log["google"])
        await pg.locator(".pav-card .pav-fixbox .pav-btn", has_text="Rifai con Google").click(); await pg.wait_for_timeout(1500)
        print("2. rifatta con Google: richieste nuove", len(tvolo.log["google"]) - n)
        await pg.locator(".pav-card .pav-linkbtn", has_text="Traduzione sbagliata").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card .pav-fixbox .pav-btn", has_text="Correggi a mano").click(); await pg.wait_for_timeout(300)
        inp = pg.locator(".pav-card textarea.pav-fixinput")
        await inp.nth(0).fill("pane (corretto)"); await inp.nth(1).fill("Siamo andati al mercato (corretta).")
        await pg.locator(".pav-card .pav-fixform .pav-btn", has_text="Salva").click(); await pg.wait_for_timeout(500)
        t = await T(pg)
        print("3. dopo la correzione:", [l for l in t.split("\n") if "corrett" in l])
        await pg.keyboard.press("Escape"); await pg.reload(); await pg.wait_for_timeout(1000)
        await openb()
        t = await T(pg)
        print("4. dopo ricarica:", [l for l in t.split("\n") if "corrett" in l or "corretta da te" in l])
        await pg.locator(".pav-card .pav-star").click(); await pg.wait_for_timeout(600)
        print("   vocabolario:", await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab).map(e=>e.meaning))"))
        await pg.locator(".pav-card .pav-linkbtn", has_text="Traduzione sbagliata").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card .pav-fixbox .pav-btn", has_text="Togli la correzione").click(); await pg.wait_for_timeout(1500)
        print("5. tolta:", [l for l in (await T(pg)).split("\n") if "corrett" in l], "| salvate:", await sw.evaluate("chrome.storage.local.get('pavFix')"))
        n = len([x for x in tvolo.log["gem"] if x[0] in ("define", "translate")])
        await pg.locator(".pav-card .pav-linkbtn", has_text="Traduzione sbagliata").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card .pav-fixbox .pav-btn", has_text="Rifai con Gemini").click(); await pg.wait_for_timeout(5000)
        print("6. rifatta con Gemini: richieste", [x[0] for x in tvolo.log["gem"]][n:], "| frase:", [l for l in (await T(pg)).split("\n") if "FRASE-GEM[" in l][:1])
        await pg.keyboard.press("Escape")
        # testo selezionato
        b = await tvolo.word_box(pg, "long", "weather"); e = await tvolo.word_box(pg, "long", "fire")
        await pg.mouse.move(b["l"] + 1, b["y"]); await pg.mouse.down(); await pg.mouse.move(e["r"] - 1, e["y"], steps=6); await pg.mouse.up(); await pg.wait_for_timeout(1500)
        await pg.locator(".pav-card .pav-linkbtn", has_text="Traduzione sbagliata").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card .pav-fixbox .pav-btn", has_text="Correggi a mano").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card textarea.pav-fixinput").fill("Faceva freddo (corretta).")
        await pg.locator(".pav-card .pav-fixform .pav-btn", has_text="Salva").click(); await pg.wait_for_timeout(400)
        print("7. testo corretto:", await pg.evaluate("(document.querySelector('.pav-card .pav-trans')||{}).textContent"))
        await pg.keyboard.press("Escape")
        # ⚙ voce
        await openb()
        await pg.locator(".pav-card .pav-tools .pav-btn", has_text="⚙").click(); await pg.wait_for_timeout(800)
        print("8. menu voci:", await pg.evaluate("[...document.querySelectorAll('.pav-card .ds-voicemenu-item')].map(b=>b.textContent)"))
        await pg.locator(".pav-card .ds-voicemenu-item", has_text="Google").click(); await pg.wait_for_timeout(800)
        print("   salvata:", await sw.evaluate("chrome.storage.sync.get('ttsVoices')"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

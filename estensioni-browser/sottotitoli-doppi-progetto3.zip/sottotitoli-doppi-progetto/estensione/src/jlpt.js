// Pagina "Parole del JLPT": le parole di un livello (N5…N1) dal dizionario Jisho, a pagine di 20, con le parole che
// conosci (le stesse di tutto il resto). Indirizzo: jlpt.html?level=N5&word=勉強
const $ = (id) => document.getElementById(id);
const P = new URLSearchParams(location.search);
const level = (DS_JLPT.includes(String(P.get("level") || "").toUpperCase()) ? String(P.get("level")).toUpperCase() : "N5");
const word = String(P.get("word") || "").trim();
const target = P.get("target") || "it";
let items = [], page = 0, more = true, busy = false, known = new Set();
const nf = (n) => n.toLocaleString("it-IT");

function tabs() {
  const t = $("tabs");
  for (const l of DS_JLPT) {
    const a = document.createElement("a");
    a.textContent = "JLPT " + l;
    a.href = "?level=" + l + "&target=" + encodeURIComponent(target);
    if (l === level) a.className = "on";
    t.append(a);
  }
  $("freqLink").href = "freq.html?lang=ja&target=" + encodeURIComponent(target) + (word ? "&word=" + encodeURIComponent(word) : "");
}
async function loadKnown() {
  const r = await DS_EXT.storage.local.get({ knownWords: {} });
  known = new Set(String((r.knownWords || {}).ja || "").split("\n").filter(Boolean));
}
async function setKnown(w, on) {
  const r = await DS_EXT.storage.local.get({ knownWords: {} });
  const kw = { ...(r.knownWords || {}) };
  const set = new Set(String(kw.ja || "").split("\n").filter(Boolean));
  if (on) set.add(w); else set.delete(w);
  kw.ja = [...set].join("\n");
  known = set;
  await DS_EXT.storage.local.set({ knownWords: kw });
}
const isKnown = (it) => known.has(it.word.toLowerCase()) || (it.reading && known.has(it.reading));
async function loadPage() {
  if (busy || !more) return false;
  busy = true;
  $("status").textContent = "Scarico da Jisho…";
  let r;
  try { r = await DS_EXT.runtime.sendMessage({ type: "jlptList", level, page: page + 1 }); } catch (e) { r = { error: String(e.message || e) }; }
  busy = false;
  if (!r || r.error) { $("status").textContent = "Jisho non risponde" + (r && r.error ? ": " + r.error : "") + ". Riprova tra poco."; return false; }
  page++;
  for (const it of r.items) if (!items.some((x) => x.word === it.word && x.reading === it.reading)) items.push(it);
  more = r.more;
  $("status").textContent = more ? `${nf(items.length)} parole caricate finora.` : `Tutte le ${nf(items.length)} parole del livello ${level}.`;
  $("more").hidden = $("all").hidden = !more;
  return true;
}
function stats() {
  const s = $("stats");
  s.textContent = "";
  const k = items.filter(isKnown).length;
  const d = document.createElement("span");
  d.className = "stat";
  d.textContent = `JLPT ${level}: ne conosci ${nf(k)} su ${nf(items.length)}${more ? " caricate" : ""}` + (items.length ? ` (${Math.round((k * 100) / items.length)}%)` : "");
  s.append(d);
}
function render() {
  const q = $("q").value.trim().toLowerCase();
  const tb = $("list");
  tb.textContent = "";
  items.forEach((it, i) => {
    if (q && !(it.word.toLowerCase().includes(q) || it.reading.includes(q) || it.meanings.join(", ").toLowerCase().includes(q))) return;
    const tr = document.createElement("tr");
    if (word && (it.word === word || it.reading === word)) { tr.className = "me"; tr.id = "me"; }
    if (isKnown(it)) tr.classList.add("known");
    const n = document.createElement("td"); n.className = "n"; n.textContent = nf(i + 1);
    const w = document.createElement("td"); w.className = "w"; w.textContent = it.word;
    if (it.common) { const c = document.createElement("span"); c.className = "tag"; c.textContent = "comune"; w.append(c); }
    const a = document.createElement("a"); a.className = "tr"; a.textContent = "↗"; a.title = "Traduzione su Google";
    a.href = `https://translate.google.com/?sl=ja&tl=${encodeURIComponent(target)}&text=${encodeURIComponent(it.word)}&op=translate`;
    a.target = "_blank"; a.rel = "noopener noreferrer";
    w.append(a);
    const r = document.createElement("td"); r.className = "r"; r.textContent = it.reading !== it.word ? it.reading : "";
    const m = document.createElement("td"); m.className = "m"; m.textContent = it.meanings.join(", ");
    const k = document.createElement("td"); k.className = "k";
    const b = document.createElement("button"); b.className = "kbtn"; b.type = "button";
    b.textContent = isKnown(it) ? "✓ la conosco" : "la conosco?";
    b.addEventListener("click", async () => {
      const on = !isKnown(it);
      await setKnown(it.word.toLowerCase(), on);
      if (!on && it.reading) await setKnown(it.reading, false);
      stats(); render();
    });
    k.append(b);
    tr.append(n, w, r, m, k);
    tb.append(tr);
  });
}
(async () => {
  document.title = "Parole JLPT " + level;
  $("title").textContent = "Parole del JLPT " + level;
  tabs();
  await loadKnown();
  for (let i = 0; i < 3; i++) if (!(await loadPage())) break;
  // la parola da cui sei arrivato: cerco nelle pagine successive (al massimo 40)
  if (word) {
    const has = () => items.some((x) => x.word === word || x.reading === word);
    for (let i = 0; i < 40 && !has() && more; i++) { if (!(await loadPage())) break; if (i % 3 === 2) { stats(); render(); } }
    const w = $("where");
    w.hidden = false;
    w.textContent = "";
    const b = document.createElement("b"); b.textContent = word;
    const pos = items.findIndex((x) => x.word === word || x.reading === word) + 1;
    w.append("«", b, "» ", pos ? `è nel livello JLPT ${level} (n. ${nf(pos)} nell'elenco di Jisho).` : `non l'ho trovata tra le prime ${nf(items.length)} parole del livello ${level}.`);
  }
  stats(); render();
  const me = $("me"); if (me) me.scrollIntoView({ block: "center" });
  $("more").addEventListener("click", async () => { for (let i = 0; i < 5; i++) if (!(await loadPage())) break; stats(); render(); });
  $("all").addEventListener("click", async () => { while (more) { if (!(await loadPage())) break; if (page % 5 === 0) { stats(); render(); } } stats(); render(); });
  $("q").addEventListener("input", render);
  DS_EXT.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.knownWords) { known = new Set(String((ch.knownWords.newValue || {}).ja || "").split("\n").filter(Boolean)); stats(); render(); } });
})();

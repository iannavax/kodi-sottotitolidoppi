// Voci Piper (https://github.com/rhasspy/piper) dentro l'estensione: le voci si scaricano una volta da HuggingFace
// (rhasspy/piper-voices) e restano nella Cache del browser; la sintesi gira qui, sul computer, senza chiavi né server.
// Messaggi (target "piper-host"): ping, voices, status, download, remove, speak. Risposta: { ... } oppure { error }.
(() => {
  const X = typeof browser !== "undefined" ? browser : chrome;
  let HF = "https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/";   // il sottofondo può mandare un'altra copia dell'archivio (storage.local «piperBase»: rete aziendale, prove)
  const CACHE = "piper-voices-v1";
  const MAX_MODELS = 1;   // sessioni ONNX tenute in memoria (ognuna 20-110 MB)
  const IDLE_MS = 3 * 60e3;   // dopo qualche minuto senza parlare libero la memoria (modello e dati di espeak-ng)

  // elenco di riserva (se voices.json non si scarica): le voci note del repository, solo i nomi
  const FALLBACK = ("ar_JO-kareem-low ar_JO-kareem-medium ca_ES-upc_ona-medium ca_ES-upc_pau-x_low cs_CZ-jirka-low cs_CZ-jirka-medium da_DK-talesyntese-medium " +
    "de_DE-eva_k-x_low de_DE-karlsson-low de_DE-kerstin-low de_DE-mls-medium de_DE-pavoque-low de_DE-ramona-low de_DE-thorsten-high de_DE-thorsten-low de_DE-thorsten-medium " +
    "el_GR-rapunzelina-low en_GB-alan-low en_GB-alan-medium en_GB-alba-medium en_GB-aru-medium en_GB-cori-high en_GB-cori-medium en_GB-jenny_dioco-medium " +
    "en_GB-northern_english_male-medium en_GB-semaine-medium en_GB-southern_english_female-low en_GB-vctk-medium en_US-amy-low en_US-amy-medium en_US-arctic-medium " +
    "en_US-danny-low en_US-hfc_female-medium en_US-hfc_male-medium en_US-joe-medium en_US-kathleen-low en_US-kristin-medium en_US-kusal-medium en_US-l2arctic-medium " +
    "en_US-lessac-high en_US-lessac-low en_US-lessac-medium en_US-libritts-high en_US-libritts_r-medium en_US-ljspeech-high en_US-ljspeech-medium en_US-ryan-high " +
    "en_US-ryan-low en_US-ryan-medium es_ES-carlfm-x_low es_ES-davefx-medium es_ES-mls_10246-low es_ES-mls_9972-low es_ES-sharvard-medium es_MX-ald-medium es_MX-claude-high " +
    "fa_IR-amir-medium fa_IR-gyro-medium fi_FI-harri-low fi_FI-harri-medium fr_FR-gilles-low fr_FR-mls-medium fr_FR-mls_1840-low fr_FR-siwis-low fr_FR-siwis-medium " +
    "fr_FR-tom-medium fr_FR-upmc-medium hu_HU-anna-medium hu_HU-berta-medium hu_HU-imre-medium is_IS-bui-medium is_IS-salka-medium is_IS-steinn-medium is_IS-ugla-medium " +
    "it_IT-riccardo-x_low ka_GE-natia-medium kk_KZ-iseke-x_low kk_KZ-issai-high kk_KZ-raya-x_low lb_LU-marylux-medium ne_NP-google-medium ne_NP-google-x_low " +
    "nl_BE-nathalie-medium nl_BE-nathalie-x_low nl_BE-rdh-medium nl_BE-rdh-x_low nl_NL-mls-medium nl_NL-mls_5809-low nl_NL-mls_7432-low no_NO-talesyntese-medium " +
    "pl_PL-darkman-medium pl_PL-gosia-medium pl_PL-mc_speech-medium pl_PL-mls_6892-low pt_BR-edresson-low pt_BR-faber-medium pt_PT-tugão-medium ro_RO-mihai-medium " +
    "ru_RU-denis-medium ru_RU-dmitri-medium ru_RU-irina-medium ru_RU-ruslan-medium sk_SK-lili-medium sl_SI-artur-medium sr_RS-serbski_institut-medium sv_SE-nst-medium " +
    "sw_CD-lanfrica-medium tr_TR-dfki-medium tr_TR-fahrettin-medium tr_TR-fettah-medium uk_UA-lada-x_low uk_UA-ukrainian_tts-medium vi_VN-25hours_single-low " +
    "vi_VN-vais1000-medium vi_VN-vivos-x_low zh_CN-huayan-medium zh_CN-huayan-x_low").split(" ");

  const parseKey = (key) => {
    const m = /^([a-z]{2,3})_([A-Za-z]+)-(.+)-(x_low|low|medium|high)$/.exec(key);
    return m ? { key, family: m[1], region: m[2], name: m[3], quality: m[4], code: m[1] + "_" + m[2] } : null;
  };
  const pathOf = (key) => { const p = parseKey(key); return p ? `${p.family}/${p.code}/${p.name}/${p.quality}/${key}` : ""; };
  const urlOf = (key, ext) => HF + pathOf(key).split("/").map(encodeURIComponent).join("/") + ext;

  // ---------- elenco delle voci ----------
  let catalog = null;
  async function loadCatalog() {
    if (catalog) return catalog;
    const cache = await caches.open(CACHE);
    const url = HF + "voices.json";
    let json = null;
    const hit = await cache.match(url);
    const age = hit ? Date.now() - Number(hit.headers.get("x-saved") || 0) : Infinity;
    if (hit && age < 7 * 864e5) { try { json = await hit.clone().json(); } catch {} }
    if (!json) {
      try {
        const r = await fetch(url);
        if (r.ok) {
          const text = await r.text();
          json = JSON.parse(text);
          await cache.put(url, new Response(text, { headers: { "x-saved": String(Date.now()), "content-type": "application/json" } }));
        }
      } catch {}
      if (!json && hit) { try { json = await hit.json(); } catch {} }
    }
    const list = [];
    if (json && typeof json === "object") {
      for (const [key, v] of Object.entries(json)) {
        const p = parseKey(key);
        if (!p) continue;
        let size = 0;
        for (const [f, info] of Object.entries((v && v.files) || {})) if (f.endsWith(".onnx") || f.endsWith(".onnx.json")) size += Number(info && info.size_bytes) || 0;
        list.push({ ...p, size, speakers: Number(v && v.num_speakers) || 1 });
      }
    }
    if (!list.length) for (const key of FALLBACK) { const p = parseKey(key); if (p) list.push({ ...p, size: 0, speakers: 1 }); }
    catalog = list;
    return list;
  }
  // un file della voce nella Cache, comunque sia stato messo (scaricato o importato a mano, da qualsiasi indirizzo)
  async function findFile(cache, key, ext) {
    const tail = "/" + encodeURIComponent(key) + ext;
    for (const r of await cache.keys()) if (r.url.endsWith(tail)) return cache.match(r);
    return null;
  }
  async function downloaded() {
    const cache = await caches.open(CACHE);
    const out = new Set();
    for (const r of await cache.keys()) {
      const m = /\/([^/]+)\.onnx$/.exec(r.url);
      if (m) out.add(decodeURIComponent(m[1]));
    }
    return out;
  }

  // ---------- scaricamento ----------
  const progress = (key, loaded, total) => { try { X.runtime.sendMessage({ type: "piperProgress", key, loaded, total }).catch?.(() => {}); } catch {} };
  const downloading = new Map();
  function download(key) {
    if (!parseKey(key)) return Promise.reject(new Error("voce sconosciuta"));
    if (downloading.has(key)) return downloading.get(key);
    const p = (async () => {
      const cache = await caches.open(CACHE);
      const onnx = urlOf(key, ".onnx"), cfg = urlOf(key, ".onnx.json");
      if (await findFile(cache, key, ".onnx") && await findFile(cache, key, ".onnx.json")) return;
      const rc = await fetch(cfg);
      if (!rc.ok) throw new Error("HuggingFace ha risposto " + rc.status + " per la voce " + key);
      const cfgText = await rc.text();
      const r = await fetch(onnx);
      if (!r.ok) throw new Error("HuggingFace ha risposto " + r.status + " per la voce " + key);
      const total = Number(r.headers.get("content-length")) || 0;
      const reader = r.body.getReader();
      const parts = []; let loaded = 0, last = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        parts.push(value); loaded += value.length;
        if (Date.now() - last > 250) { last = Date.now(); progress(key, loaded, total); }
      }
      progress(key, loaded, loaded);
      // prima il modello, poi la configurazione: una voce è «scaricata» solo se ci sono tutti e due
      await cache.put(onnx, new Response(new Blob(parts), { headers: { "content-type": "application/octet-stream" } }));
      await cache.put(cfg, new Response(cfgText, { headers: { "content-type": "application/json" } }));
    })().finally(() => downloading.delete(key));
    downloading.set(key, p);
    return p;
  }
  async function remove(key) {
    const cache = await caches.open(CACHE);
    const tails = ["/" + encodeURIComponent(key) + ".onnx", "/" + encodeURIComponent(key) + ".onnx.json"];
    for (const r of await cache.keys()) if (tails.some((t) => r.url.endsWith(t))) await cache.delete(r);
    models.delete(key);
  }

  // ---------- sintesi ----------
  ort.env.wasm.wasmPaths = X.runtime.getURL("piper/");
  ort.env.wasm.numThreads = 1;   // più thread chiedono l'isolamento cross-origin: una voce Piper è veloce anche così
  ort.env.wasm.proxy = false;
  const models = new Map();   // key → { session, cfg }
  async function model(key) {
    if (models.has(key)) { const m = models.get(key); models.delete(key); models.set(key, m); return m; }
    await download(key);
    const cache = await caches.open(CACHE);
    const cfg = await (await findFile(cache, key, ".onnx.json")).json();
    const buf = await (await findFile(cache, key, ".onnx")).arrayBuffer();
    const session = await ort.InferenceSession.create(buf, { executionProviders: ["wasm"] });
    const m = { session, cfg };
    models.set(key, m);
    while (models.size > MAX_MODELS) models.delete(models.keys().next().value);
    return m;
  }
  // il convertitore testo → suoni (espeak-ng): lo creo una volta, poi riuso la stessa istanza
  let phon = null, phonLines = [], phonErr = [];
  async function phonemizer() {
    if (!phon) phon = await createPiperPhonemize({
      print: (l) => phonLines.push(l), printErr: (l) => phonErr.push(l),
      locateFile: (f) => X.runtime.getURL("piper/" + f)
    });
    return phon;
  }
  async function phonemeIds(text, voice) {
    const m = await phonemizer();
    phonLines = []; phonErr = [];
    try { m.callMain(["-l", voice, "--input", JSON.stringify([{ text }]), "--espeak_data", "/espeak-ng-data"]); }
    catch (e) { phon = null; throw new Error("conversione in suoni non riuscita: " + (e && e.message || e)); }
    const out = [];
    for (const l of phonLines) { try { const j = JSON.parse(l); if (j.phoneme_ids && j.phoneme_ids.length) out.push(j.phoneme_ids); } catch {} }
    if (!out.length) throw new Error("nessun suono per questo testo" + (phonErr.length ? " (" + phonErr[0] + ")" : ""));
    return out;
  }
  function wav(chunks, rate) {
    let n = 0; for (const c of chunks) n += c.length;
    const dv = new DataView(new ArrayBuffer(44 + n * 2));
    const w = (o, s) => { for (let i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); };
    w(0, "RIFF"); dv.setUint32(4, 36 + n * 2, true); w(8, "WAVE"); w(12, "fmt "); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true);
    dv.setUint16(22, 1, true); dv.setUint32(24, rate, true); dv.setUint32(28, rate * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true);
    w(36, "data"); dv.setUint32(40, n * 2, true);
    let o = 44;
    for (const c of chunks) for (let i = 0; i < c.length; i++, o += 2) { const s = Math.max(-1, Math.min(1, c[i])); dv.setInt16(o, s < 0 ? s * 32768 : s * 32767, true); }
    return new Uint8Array(dv.buffer);
  }
  const b64 = (bytes) => { let s = ""; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); };
  let idleTimer = 0;
  const idleReset = () => { clearTimeout(idleTimer); idleTimer = setTimeout(() => { if (!downloading.size) { models.clear(); phon = null; } }, IDLE_MS); };
  let queue = Promise.resolve();   // una sintesi alla volta: onnxruntime non accetta due run() insieme sulla stessa sessione
  function speak(key, text, rate, speaker) {
    const job = queue.then(async () => {
      const t0 = Date.now();
      idleReset();
      const { session, cfg } = await model(key);
      const idsList = await phonemeIds(String(text || "").slice(0, 1500), (cfg.espeak && cfg.espeak.voice) || key.split("_")[0]);
      const inf = cfg.inference || {};
      // velocità: 0,9 è il valore normale dell'estensione (rate più basso = voce più lenta = length_scale più grande)
      const scale = (inf.length_scale || 1) * (0.9 / (rate || 0.9));
      const chunks = [];
      for (const ids of idsList) {
        const feeds = {
          input: new ort.Tensor("int64", BigInt64Array.from(ids, (x) => BigInt(x)), [1, ids.length]),
          input_lengths: new ort.Tensor("int64", BigInt64Array.from([BigInt(ids.length)]), [1]),
          scales: new ort.Tensor("float32", Float32Array.from([inf.noise_scale ?? 0.667, scale, inf.noise_w ?? 0.8]), [3])
        };
        if (session.inputNames.includes("sid")) feeds.sid = new ort.Tensor("int64", BigInt64Array.from([BigInt(speaker || 0)]), [1]);
        const out = await session.run(feeds);
        chunks.push(out[session.outputNames[0]].data);
      }
      return { audio: b64(wav(chunks, (cfg.audio && cfg.audio.sample_rate) || 22050)), ms: Date.now() - t0 };
    });
    queue = job.catch(() => {});
    return job;
  }

  async function handle(msg) {
    if (msg.base) HF = String(msg.base).replace(/\/*$/, "/");
    switch (msg.op) {
      case "ping": return { ok: true };
      case "voices": {
        const [list, have] = await Promise.all([loadCatalog(), downloaded()]);
        return { voices: list.map((v) => ({ ...v, have: have.has(v.key) })) };
      }
      case "download": await download(msg.key); return { ok: true };
      case "remove": await remove(msg.key); return { ok: true };
      case "speak": return await speak(msg.key, msg.text, msg.rate, msg.speaker);
      default: return { error: "operazione sconosciuta" };
    }
  }
  X.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.target !== "piper-host") return false;
    handle(msg).then(sendResponse, (e) => sendResponse({ error: String((e && e.message) || e) }));
    return true;
  });
})();

const C = DS_CONFIG;
const $ = (id) => document.getElementById(id);
const tabId = Number(new URLSearchParams(location.search).get("tab")) || null;

let data = { title: "", source: "", lang: "", cues: [], full: false, duration: 0, mediaId: null, src: "" };
let settings = null;
let fromTab = false;     // i dati arrivano dalla scheda del video (che li aggiorna da sola)
let busy = false;
let pollTimer = 0;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function hash(str) {
  let h1 = 5381, h2 = 52711;
  for (let i = 0; i < str.length; i++) { const c = str.charCodeAt(i); h1 = (h1 * 33) ^ c; h2 = (h2 * 33) ^ c; }
  return (h1 >>> 0).toString(36) + (h2 >>> 0).toString(36);
}
const norm = (t) => String(t || "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
const isEcho = (o, t) => {
  const words = (x) => String(x || "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  const a = words(o), b = words(t);
  if (a.length < 3 || !b.length) return false;
  if (a.join(" ") === b.join(" ")) return true;
  const set = new Set(a);
  const ratio = b.length / a.length;
  return ratio > 0.7 && ratio < 1.45 && b.filter((x) => set.has(x)).length / Math.max(a.length, b.length) >= 0.8;
};
const status = (t, cls = "") => { $("status").textContent = t; $("status").className = "note " + cls; };

async function loadSettings() {
  const s = await DS_EXT.storage.sync.get(C.SYNC_DEFAULTS);
  const l = await DS_EXT.storage.local.get({ keys: {} });
  settings = { ...s, models: { ...(s.models || {}) }, keys: l.keys || {} };
}

// ---------- Dati dalla scheda del video ----------
let frameTarget = null;   // la parte della pagina (video) che ha la trascrizione
function askTab(msg) {
  return new Promise((res) => {
    if (!tabId) return res(null);
    const m = msg.type === "getTranscript" || !frameTarget ? msg : { ...msg, target: frameTarget };
    chrome.tabs.sendMessage(tabId, m, (r) => {
      if (chrome.runtime.lastError) return res(null);
      if (r && r.frame && msg.type === "getTranscript" && (r.cues || []).length) frameTarget = r.frame;
      res(r || null);
    });
  });
}

async function refreshFromTab() {
  if (editing) return true;
  const r = await askTab({ type: "getTranscript" });
  if (!r || !r.ok) return false;
  // se nel frattempo risponde un video senza testo, tengo quello che avevo
  if (fromTab && !(r.cues || []).length && (data.cues || []).length && r.frame !== frameTarget) return true;
  fromTab = true;
  data = r;
  render();
  return true;
}

// ---------- Visualizzazione ----------
function fmt(ms, srt = false) {
  ms = Math.max(0, Math.round(ms || 0));
  const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000), s = Math.floor((ms % 60000) / 1000);
  const pad = (n, l = 2) => String(n).padStart(l, "0");
  if (srt) return `${pad(h)}:${pad(m)}:${pad(s)},${pad(ms % 1000, 3)}`;
  return (h ? h + ":" + pad(m) : m) + ":" + pad(s);
}

// Paragrafi: vado a capo nelle pause lunghe o dopo qualche frase
function paragraphs(cues, field) {
  const out = [];
  let cur = [];
  cues.forEach((c, i) => {
    const t = (c[field] || "").trim();
    if (t) cur.push(t);
    const next = cues[i + 1];
    const gap = next ? next.start - c.end : Infinity;
    if (cur.length && (gap > 2500 || cur.length >= 6 || !next)) { out.push(cur.join(" ")); cur = []; }
  });
  return out;
}

function plainText(mode) {
  const cues = data.cues || [];
  if (mode === "orig") return paragraphs(cues, "text").join("\n\n");
  if (mode === "trans") return paragraphs(cues, "trans").join("\n\n");
  // originale e traduzione, paragrafo per paragrafo
  const out = [];
  let group = [];
  cues.forEach((c, i) => {
    group.push(c);
    const next = cues[i + 1];
    const gap = next ? next.start - c.end : Infinity;
    if (gap > 2500 || group.length >= 6 || !next) {
      out.push(group.map((x) => x.text).join(" "));
      const tr = group.map((x) => x.trans || "").join(" ").trim();
      if (tr) out.push("→ " + tr);
      out.push("");
      group = [];
    }
  });
  return out.join("\n").trim();
}

// La pagina si aggiorna da sola ogni 3 secondi: ridisegnarla mentre selezioni il testo faceva perdere la selezione
// (o la allargava a tutta la pagina). Ora ridisegno solo se qualcosa è cambiato, e mai mentre selezioni.
let lastSig = "", renderPending = false, mouseDownInText = false;
function selectingText() {
  if (mouseDownInText) return true;
  const sel = window.getSelection();
  if (!sel || sel.isCollapsed) return false;
  const views = [$("textView"), $("timeView")];
  return views.some((v) => v.contains(sel.anchorNode) || v.contains(sel.focusNode));
}
function render(force) {
  const sig = hash(JSON.stringify([data, $("mode").value, fromTab, editing]));
  if (!force && sig === lastSig) return;
  if (!force && selectingText()) { renderPending = true; return; }
  renderPending = false;
  lastSig = sig;
  renderNow();
}
document.addEventListener("mousedown", (e) => {
  mouseDownInText = !!(e.target.closest && e.target.closest("#textView, #timeView")) && !e.target.closest("button, textarea");
  if (!(e.target.closest && e.target.closest("#selbar"))) hideSelBar();
});
document.addEventListener("mouseup", () => {
  mouseDownInText = false;
  setTimeout(showSelBar, 0);
});
document.addEventListener("selectionchange", () => {
  const sel = window.getSelection();
  if (renderPending && !mouseDownInText && (!sel || sel.isCollapsed)) render();
  if (!sel || sel.isCollapsed) hideSelBar();
});

// ---------- Barra sopra il testo selezionato: copia e servizi di traduzione ----------
function hideSelBar() { const b = $("selbar"); if (b) b.hidden = true; }
function showSelBar() {
  const sel = window.getSelection();
  const bar = $("selbar");
  if (!bar || !sel || sel.isCollapsed) return hideSelBar();
  const views = [$("textView"), $("timeView")];
  if (!views.some((v) => v.contains(sel.anchorNode) && v.contains(sel.focusNode))) return hideSelBar();
  const text = sel.toString().replace(/\s+/g, " ").trim();
  if (!text) return hideSelBar();
  // selezione nella traduzione → si consulta dalla lingua di arrivo a quella dell'originale
  const node = sel.anchorNode && (sel.anchorNode.nodeType === 1 ? sel.anchorNode : sel.anchorNode.parentElement);
  const inTrans = !!(node && node.closest(".tr"));
  const src = (data.lang || "").split("-")[0];
  const from = inTrans ? settings.targetLang : src, to = inTrans ? (src || "en") : settings.targetLang;
  bar.textContent = "";
  const copy = Object.assign(document.createElement("button"), { type: "button", textContent: "Copia" });
  copy.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(text); copy.textContent = "Copiato ✓"; }
    catch { document.execCommand("copy"); copy.textContent = "Copiato ✓"; }
  });
  bar.append(copy);
  const words = text.split(/\s+/).length;
  for (const l of dsServiceLinks(text, from, to, words <= 3)) {
    const a = Object.assign(document.createElement("a"), { href: l.url, target: "_blank", rel: "noopener noreferrer", textContent: l.label });
    a.title = l.title || "Si apre in un'altra scheda";
    if (l.copy) a.addEventListener("click", () => { navigator.clipboard.writeText(text).catch(() => {}); });
    bar.append(a);
  }
  bar.hidden = false;
  const r = sel.getRangeAt(0).getBoundingClientRect();
  const w = bar.offsetWidth, h = bar.offsetHeight;
  bar.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.left + r.width / 2 - w / 2)) + "px";
  bar.style.top = (r.top - h - 8 > 8 ? r.top - h - 8 : r.bottom + 8) + "px";
}
window.addEventListener("scroll", hideSelBar, { passive: true });

function renderNow() {
  const cues = data.cues || [];
  if (typeof chatLabel === "function" && $("copyForChat")) chatLabel();
  $("title").textContent = data.title || (fromTab ? "Trascrizione e traduzione" : "Trascrivi un file audio o video");
  const src = { whisper: "trascrizione dell'audio (Whisper)", youtube: "sottotitoli di YouTube", track: "sottotitoli del video", file: "sottotitoli caricati da file", filetr: "trascrizione di un file intero (Whisper)" }[data.source] || "";
  const translated = cues.filter((c) => c.trans).length;
  $("subtitle").textContent = cues.length
    ? `${cues.length} frasi${src ? " · " + src : ""}${data.lang ? " · lingua: " + data.lang : ""} · tradotte: ${translated}/${cues.length}`
    : "";

  // Copertura: la trascrizione dal vivo copre solo le parti già guardate
  const cov = $("coverage");
  if (data.live) {
    cov.textContent = "È una diretta: il testo cresce mentre la guardi. Puoi copiarlo o scaricarlo quando vuoi.";
  } else if (data.source === "whisper" && !data.full && data.duration > 0 && cues.length) {
    const covered = cues.reduce((a, c) => a + (c.end - c.start), 0);
    const pct = Math.min(100, Math.round((covered / data.duration) * 100));
    cov.textContent = `La trascrizione copre le parti del video già riprodotte (circa il ${pct}% del parlato possibile). ` +
      `Per averla completa guarda il resto, oppure usa "Trascrivere un file intero" qui sotto.`;
  } else cov.textContent = "";

  const mode = $("mode").value;
  const tv = $("textView");
  tv.textContent = "";
  if (!cues.length) {
    tv.append(Object.assign(document.createElement("div"), { className: "empty",
      textContent: tabId ? "Ancora nessun testo per questo video. Premi CC (o avvia la trascrizione dal popup) e guarda il video: il testo comparirà qui." : "Scegli un file audio o video qui sotto per trascriverlo." }));
  } else if (mode === "both") {
    for (const line of plainText("both").split("\n")) {
      if (!line.trim()) continue;
      const d = document.createElement("p");
      if (line.startsWith("→ ")) { d.className = "tr"; d.textContent = line.slice(2); } else { d.className = "orig"; d.textContent = line; }
      tv.append(d);
    }
  } else {
    for (const par of plainText(mode).split("\n\n")) {
      if (par.trim()) tv.append(Object.assign(document.createElement("p"), { className: mode === "trans" ? "tr" : "orig", textContent: par }));
    }
  }

  const tl = $("timeView");
  if (editing) return;   // mentre correggi una frase non ridisegno la lista
  tl.textContent = "";
  const canRetranscribe = fromTab && data.source === "whisper";
  cues.forEach((c, i) => {
    const row = document.createElement("div");
    row.className = "line" + (c.fixed ? " fixed" : "");
    const tools = Object.assign(document.createElement("div"), { className: "tools" });
    const btn = (label, title, fn) => {
      const b = Object.assign(document.createElement("button"), { type: "button", className: "mini", textContent: label, title });
      b.addEventListener("click", fn);
      tools.append(b);
    };
    btn("⧉", "Copia questa frase (originale e traduzione)", async (ev) => {
      const b = ev.currentTarget;
      try { await navigator.clipboard.writeText(c.text + (c.trans ? "\n" + c.trans : "")); b.textContent = "✓"; setTimeout(() => { b.textContent = "⧉"; }, 1200); } catch {}
    });
    btn("↻", "Ritraduci questa frase", () => fixCue(i, "retranslate"));
    if (canRetranscribe) btn("🎙", "Ritrascrivi questa frase (Whisper, modello più preciso)", () => fixCue(i, "retranscribe"));
    btn("✎", "Correggi a mano", () => editRow(row, i));
    btn("✕", "Togli questa frase (per esempio se è inventata)", () => fixCue(i, "remove"));
    row.append(Object.assign(document.createElement("div"), { className: "time", textContent: fmt(c.start) }),
      Object.assign(document.createElement("div"), { className: "orig", textContent: c.text }),
      Object.assign(document.createElement("div"), { className: "tr", textContent: c.trans || "" }), tools);
    tl.append(row);
  });

  const hasMedia = fromTab && data.mediaId;
  $("fixCard").hidden = !hasMedia;
  $("fromTab").hidden = !(hasMedia && !data.live && /^https?:/.test(data.src || ""));
  $("fileNote").textContent = hasMedia
    ? "Il file che scegli viene collegato al video aperto nella scheda: sottotitoli e traduzione compariranno anche lì."
    : "";
}

// ---------- Correzione delle singole frasi ----------
let editing = false;

async function fixCue(i, action, text, trans) {
  const c = data.cues[i];
  if (!c) return;
  status({ retranslate: "Ritraduco la frase…", retranscribe: "Ritrascrivo la frase…", remove: "Tolgo la frase…", edit: "Salvo…" }[action]);
  let r;
  if (fromTab && data.mediaId) {
    r = await askTab({ type: "fixCue", action, start: c.start, text, trans });
    if (!r) r = { ok: false, error: "la scheda del video non risponde" };
  } else {
    r = await fixHere(i, action, text, trans);
  }
  status(r.ok ? (r.note || "Fatto ✓") : "Non ci sono riuscito: " + r.error, r.ok ? "okmsg" : "warn");
  if (fromTab) await refreshFromTab(); else render();
}

// File trascritto qui (senza scheda): le correzioni le faccio io e le salvo
async function fixHere(i, action, text, trans) {
  const c = data.cues[i];
  if (action === "remove") data.cues.splice(i, 1);
  else if (action === "edit") {
    const changed = text != null && text.trim() && text.trim() !== c.text;
    if (changed) c.text = text.trim();
    if (trans != null && trans.trim()) c.trans = trans.trim();
    else if (changed) return fixHere(i, "retranslate");
  } else if (action === "retranslate") {
    const id = C.ENGINES[settings.engine] && C.ENGINES[settings.engine].kind !== "youtube" ? settings.engine : "google";
    const ask = async (engine) => {
      const E = C.ENGINES[engine];
      const r = await DS_EXT.runtime.sendMessage({
        type: "translate", engine, target: settings.targetLang, source: data.lang, texts: [c.text], priority: true,
        before: data.cues.slice(Math.max(0, i - 4), i).map((x) => x.text), after: data.cues.slice(i + 1, i + 3).map((x) => x.text),
        key: settings.keys[engine] || "", model: settings.models[engine] || E.defaultModel || "", localUrl: settings.localUrl
      }).catch((e) => ({ error: String(e.message || e) }));
      const t = r && !r.error ? r.translations[0] || "" : "";
      if (!t || isEcho(c.text, t)) return "";
      if (engine !== "google" && dsUncheckedCopy(c.text, t, settings.targetLang)) return "";   // ricopiata: la chiedo a Google
      if (dsIsCopy(c.text, t)) dsMarkCopyOk(c.text, settings.targetLang);
      return t;
    };
    const t = (await ask(id)) || (id !== "google" ? await ask("google") : "");
    if (!t) return { ok: false, error: "nessuna traduzione valida" };
    c.trans = t;
  } else return { ok: false, error: "qui si può solo ritradurre, correggere o togliere" };
  if (data.mediaId) await saveResult(data.mediaId);
  return { ok: true };
}

function editRow(row, i) {
  const c = data.cues[i];
  editing = true;
  row.textContent = "";
  const t1 = Object.assign(document.createElement("textarea"), { value: c.text, className: "edit" });
  const t2 = Object.assign(document.createElement("textarea"), { value: c.trans || "", className: "edit", placeholder: "Traduzione (se la lasci vuota e cambi l'originale, la rifaccio io)" });
  const save = Object.assign(document.createElement("button"), { type: "button", textContent: "Salva" });
  const cancel = Object.assign(document.createElement("button"), { type: "button", className: "ghost", textContent: "Annulla" });
  save.addEventListener("click", async () => { editing = false; await fixCue(i, "edit", t1.value, t2.value); });
  cancel.addEventListener("click", () => { editing = false; render(true); });
  const box = Object.assign(document.createElement("div"), { className: "editbox" });
  box.append(t1, t2, Object.assign(document.createElement("div"), { className: "row" }));
  box.lastChild.append(save, cancel);
  row.append(Object.assign(document.createElement("div"), { className: "time", textContent: fmt(c.start) }), box);
  t1.focus();
}

// ---------- Esportazione ----------
function safeName() {
  return (data.title || "trascrizione").replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 80) || "trascrizione";
}
function download(name, text) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(["\uFEFF" + text], { type: "text/plain;charset=utf-8" }));
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
function srt(field) {
  return (data.cues || []).map((c, i) => {
    const body = field === "both" ? [c.text, c.trans].filter(Boolean).join("\n") : (c[field] || "");
    return `${i + 1}\n${fmt(c.start, true)} --> ${fmt(Math.max(c.end, c.start + 500), true)}\n${body}\n`;
  }).join("\n");
}
$("dlTxt").addEventListener("click", () => download(`${safeName()}.txt`, plainText($("mode").value)));
$("dlSrtOrig").addEventListener("click", () => download(`${safeName()}.srt`, srt("text")));
$("dlSrtTrans").addEventListener("click", () => download(`${safeName()}.${settings.targetLang}.srt`, srt("trans")));
$("dlSrtBoth").addEventListener("click", () => download(`${safeName()}.doppi.srt`, srt("both")));
$("copy").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(plainText($("mode").value)); status("Testo copiato.", "okmsg"); }
  catch { const r = document.createRange(); r.selectNodeContents($("textView")); getSelection().removeAllRanges(); getSelection().addRange(r); status("Testo selezionato: premi Ctrl+C per copiarlo."); }
});
$("mode").addEventListener("change", () => render(true));
for (const [btn, view] of [["tabText", "textView"], ["tabTime", "timeView"]]) {
  $(btn).addEventListener("click", () => {
    for (const [b, v] of [["tabText", "textView"], ["tabTime", "timeView"]]) {
      $(b).setAttribute("aria-selected", String(b === btn));
      $(v).hidden = v !== view;
    }
  });
}

// ---------- Rifare / caricare sottotitoli ----------
$("redoTrans").addEventListener("click", async () => {
  await askTab({ type: "redo", what: "translation" });
  status("Traduzione cancellata: viene rifatta adesso.");
  setTimeout(refreshFromTab, 800);
});
$("redoTranscript").addEventListener("click", async () => {
  if (!confirm("Cancellare la trascrizione salvata di questo video?")) return;
  await askTab({ type: "redo", what: "transcription" });
  status("Trascrizione cancellata: verrà rifatta mentre guardi il video.");
  setTimeout(refreshFromTab, 800);
});
$("pickSubs").addEventListener("change", async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const r = await askTab({ type: "loadSubs", text: await f.text(), name: f.name });
  status(r && r.ok ? `Sottotitoli caricati: ${r.count} frasi. Adesso vengono tradotti.` : "Errore: " + ((r && r.error) || "la scheda del video non risponde"), r && r.ok ? "okmsg" : "warn");
  e.target.value = "";
  setTimeout(refreshFromTab, 1500);
});

// ---------- Trascrizione di un file intero ----------
function progress(v, text) {
  $("progress").hidden = v == null;
  if (v != null) $("progress").value = v;
  if (text) status(text);
}

async function transcribeBlob(blob, filename) {
  return DS_WHOLE.transcribe(blob, filename, {
    settings,
    onProgress: (pct, text) => progress(pct == null ? $("progress").value : pct, text)
  });
}

function mapLang(l) {
  const x = String(l || "").toLowerCase();
  return C.WHISPER_LANGS[x] || (x.length <= 3 ? x : "");
}

// Traduzione fatta qui (per i file non collegati a una scheda)
async function translateHere() {
  const e0 = settings.engine;
  let id = C.ENGINES[e0] && C.ENGINES[e0].kind !== "youtube" ? e0 : "google";
  let E = C.ENGINES[id];
  const key = () => settings.keys[id] || "";
  const model = () => settings.models[id] || E.defaultModel || "";
  if ((E.needsKey && !key()) || (E.kind === "openai" && !model())) { id = "google"; E = C.ENGINES.google; }
  const cues = data.cues;
  await dsCopyOkReady;
  // da tradurre: quelle senza traduzione e quelle "tradotte" ricopiando l'originale (frasi brevi: "Ja." → "Ja.")
  const todo = cues.map((c, i) => (c.trans && !dsUncheckedCopy(c.text, c.trans, settings.targetLang) ? -1 : i)).filter((i) => i >= 0);
  const queue = [];
  for (let i = 0; i < todo.length; i += E.chunk.count) queue.push(todo.slice(i, i + E.chunk.count));
  let done = cues.length - todo.length;
  while (queue.length) {
    const ch = queue.shift();
    progress(90 + Math.round((10 * done) / cues.length), `Traduco (${E.label.split(" (")[0]}): ${done}/${cues.length} frasi…`);
    const msg = {
      type: "translate", engine: id, target: settings.targetLang, source: data.lang,
      texts: ch.map((i) => cues[i].text),
      before: cues.slice(Math.max(0, ch[0] - 4), ch[0]).map((c) => c.text),
      after: cues.slice(ch[ch.length - 1] + 1, ch[ch.length - 1] + 3).map((c) => c.text),
      key: key(), model: model(), localUrl: settings.localUrl
    };
    let r;
    try { r = await DS_EXT.runtime.sendMessage(msg); } catch (err) { r = { error: String(err.message || err) }; }
    if (r && r.rateLimited && !r.daily) { queue.unshift(ch); await sleep(Math.max(r.retryAfter || 0, 10) * 1000); continue; }
    if (r && !r.fatal && !r.daily && ((r.error && ch.length > 3) || (r.misaligned && ch.length > 1))) {
      const mid = Math.ceil(ch.length / 2); queue.unshift(ch.slice(0, mid), ch.slice(mid)); continue;
    }
    if (!r || r.error) {
      if (id !== "google") { id = "google"; E = C.ENGINES.google; queue.unshift(ch); continue; }
      status("Errore di traduzione: " + ((r && r.error) || "nessuna risposta"), "warn");
      return;
    }
    const copied = [];
    ch.forEach((i, k) => {
      const t = r.translations[k] || "";
      cues[i].trans = isEcho(cues[i].text, t) ? "" : t;
      if (cues[i].trans && dsIsCopy(cues[i].text, t)) {
        if (id === "google") dsMarkCopyOk(cues[i].text, settings.targetLang);
        else if (!dsCopyOk(cues[i].text, settings.targetLang)) copied.push(i);
      }
    });
    // frasi brevi ricopiate dal modello: seconda opinione di Google (se la lascia uguale anche lui è un nome)
    if (copied.length) {
      const g = await DS_EXT.runtime.sendMessage({ type: "translate", engine: "google", target: settings.targetLang, source: data.lang,
        texts: copied.map((i) => cues[i].text) }).catch(() => null);
      copied.forEach((i, k) => {
        const t = g && !g.error ? (g.translations || [])[k] || "" : "";
        if (!t || isEcho(cues[i].text, t)) return;
        if (dsIsCopy(cues[i].text, t)) dsMarkCopyOk(cues[i].text, settings.targetLang);
        cues[i].trans = t;
      });
    }
    done += ch.length;
    render();
  }
}

async function saveResult(mediaId) {
  const v = mediaId;
  const cues = data.cues.map((c) => ({ s: Math.round(c.start), e: Math.round(c.end), t: c.text }));
  const last = data.cues[data.cues.length - 1];
  const entry = { [`live:${v}`]: { cues, covered: last ? [[0, last.end + 1000]] : [], lang: data.lang, full: true, title: data.title } };
  const trans = {};
  for (const c of data.cues) if (c.trans) trans[Math.round(c.start)] = c.trans;
  if (Object.keys(trans).length) {
    const e = C.ENGINES[settings.engine] && C.ENGINES[settings.engine].kind !== "youtube" ? settings.engine : "google";
    const model = settings.models[e] || (C.ENGINES[e].defaultModel || "");
    entry[`livetr:${v}|${settings.targetLang}|${e}|${model}`] = trans;
  }
  const { cacheIndex = [] } = await DS_EXT.storage.local.get({ cacheIndex: [] });
  const idx = cacheIndex.filter((k) => !(k in entry)).concat(Object.keys(entry));
  const drop = idx.length > 80 ? idx.splice(0, idx.length - 80) : [];
  if (drop.length) await DS_EXT.storage.local.remove(drop);
  await DS_EXT.storage.local.set({ ...entry, cacheIndex: idx });
}

async function runFile(blob, filename) {
  if (busy) return;
  await loadSettings();
  if (settings.stt === "groq" && !settings.keys.groq) {
    status("Per trascrivere serve la chiave Groq: inseriscila nel popup, nella sezione dei video senza sottotitoli.", "warn");
    return;
  }
  busy = true;
  clearInterval(pollTimer);
  const linked = fromTab && data.mediaId;
  const mediaId = linked ? data.mediaId : "f" + hash(`${filename}|${blob.size}`);
  try {
    // Già trascritto in passato? Allora non rifaccio le richieste
    const saved = (await DS_EXT.storage.local.get(`live:${mediaId}`))[`live:${mediaId}`];
    let result;
    if (saved && saved.full && saved.cues && saved.cues.length && !linked) {
      result = { cues: saved.cues.map((c) => ({ start: c.s, end: c.e, text: c.t, trans: "" })), lang: saved.lang };
      status("Questo file era già stato trascritto: uso il testo salvato.");
    } else {
      result = await transcribeBlob(blob, filename);
    }
    if (!result.cues.length) throw new Error("nel file non ho trovato parlato da trascrivere");
    data = { ...data, title: linked ? data.title : filename, source: linked ? "whisper" : "filetr", lang: result.lang, cues: result.cues, full: true, mediaId };
    render();
    if (linked) {
      const r = await askTab({ type: "setTranscript", mediaId, cues: result.cues, lang: result.lang });
      progress(null);
      status(r && r.ok ? `Trascrizione completa: ${result.cues.length} frasi. La traduzione la fa la scheda del video e compare qui man mano.` : "Trascrizione completa, ma la scheda del video non risponde: ricaricala.", r && r.ok ? "okmsg" : "warn");
      pollTimer = setInterval(refreshFromTab, 3000);
    } else {
      const tr = await DS_EXT.storage.local.get(null);
      const tkey = Object.keys(tr).find((k) => k.startsWith(`livetr:${mediaId}|${settings.targetLang}|`));
      if (tkey) for (const c of data.cues) c.trans = tr[tkey][Math.round(c.start)] || "";
      await translateHere();
      await saveResult(mediaId);
      progress(null);
      status(`Fatto: ${data.cues.length} frasi trascritte e tradotte.`, "okmsg");
      render();
    }
  } catch (e) {
    progress(null);
    status("Errore: " + (e.message || e), "warn");
  } finally {
    busy = false;
  }
}

$("pickFile").addEventListener("change", (e) => {
  const f = e.target.files[0];
  if (f) runFile(f, f.name);
  e.target.value = "";
});
$("fromTab").addEventListener("click", async () => {
  const url = data.src;
  status("Scarico il file…");
  progress(2);
  try {
    const r = await fetch(url);
    if (!r.ok) throw new Error("il sito ha risposto " + r.status);
    const blob = await r.blob();
    const name = decodeURIComponent(url.split("?")[0].split("/").pop() || "video") || "video";
    await runFile(blob, name);
  } catch (e) {
    progress(null);
    status("Non riesco a scaricare il file da questo sito (" + (e.message || e) + "). Se l'hai sul computer, sceglilo con il pulsante qui accanto.", "warn");
  }
});

// ---------- Avvio ----------
(async () => {
  await loadSettings();
  const ok = await refreshFromTab();
  if (!ok) {
    fromTab = false;
    $("title").textContent = "Trascrivi un file audio o video";
    render();
  } else {
    pollTimer = setInterval(() => { if (!busy) refreshFromTab(); }, 3000);
  }
})();


// ---------- Traduzione fatta con una chat: Copia trascrizione → Incolla traduzione ----------
// Le frasi si copiano numerate, a parti di 250 (le chat accettano testi lunghi, ma rispondono meglio a pezzi).
const CHAT_PART = 250;
let chatPart = 0;
function langName(code) {
  try { return new Intl.DisplayNames([dsUiLocale()], { type: "language" }).of(code) || code; } catch { return code; }
}
function chatParts() {
  const n = (data.cues || []).length;
  return Math.max(1, Math.ceil(n / CHAT_PART));
}
function chatLabel() {
  const parts = chatParts();
  $("copyForChat").textContent = parts > 1 ? `Copia trascrizione (parte ${chatPart + 1} di ${parts})` : "Copia trascrizione";
}
$("copyForChat").addEventListener("click", async () => {
  const cues = data.cues || [];
  if (!cues.length) { status("Non c'è ancora testo da copiare.", "warn"); return; }
  const parts = chatParts();
  if (chatPart >= parts) chatPart = 0;
  const from = chatPart * CHAT_PART, to = Math.min(cues.length, from + CHAT_PART);
  const target = langName(settings.targetLang);
  const src = data.lang ? ` (lingua originale: ${langName(data.lang.split("-")[0])})` : "";
  const text =
    `Traduci in ${target} le frasi numerate qui sotto${src}. Sono i sottotitoli di un video, in ordine: tieni conto del discorso ` +
    `e traduci in modo naturale ma fedele. Rispondi solo con le traduzioni, una per riga, ognuna con lo stesso numero davanti ` +
    `(per esempio "${from + 1}. ..."), senza unire, dividere o saltare frasi e senza commenti.` +
    (parts > 1 ? ` (Parte ${chatPart + 1} di ${parts}.)` : "") + "\n\n" +
    cues.slice(from, to).map((c, k) => `${from + k + 1}. ${c.text.replace(/\s+/g, " ").trim()}`).join("\n");
  try {
    await navigator.clipboard.writeText(text);
    status(`Copiate le frasi ${from + 1}-${to}${parts > 1 ? ` (parte ${chatPart + 1} di ${parts})` : ""}: incollale nella chat.`, "okmsg");
  } catch {
    status("Non riesco a copiare negli appunti.", "warn");
    return;
  }
  chatPart = (chatPart + 1) % parts;
  chatLabel();
});
$("pasteFromChat").addEventListener("click", () => {
  $("pasteBox").hidden = false;
  $("pasteMsg").textContent = "";
  $("pasteText").focus();
});
$("pasteCancel").addEventListener("click", () => { $("pasteBox").hidden = true; $("pasteText").value = ""; });

// Righe "12. testo", "12) testo", "12: testo", "12 - testo" (anche con ** del grassetto delle chat)
function parseChat(text) {
  const out = new Map();
  for (const line of String(text || "").split(/\r?\n/)) {
    const m = line.replace(/\*\*/g, "").match(/^\s*(\d{1,5})\s*[.):\-–]\s*(.+?)\s*$/);
    if (m && m[2]) out.set(Number(m[1]), m[2]);
  }
  return out;
}
$("pasteApply").addEventListener("click", async () => {
  const cues = data.cues || [];
  const got = parseChat($("pasteText").value);
  const items = [];
  for (const [n, t] of got) if (n >= 1 && n <= cues.length) items.push({ i: n - 1, start: cues[n - 1].start, trans: t });
  if (!items.length) { $("pasteMsg").textContent = "Non trovo righe numerate: incolla la risposta della chat così com'è."; return; }
  const echo = items.filter((it) => isEcho(cues[it.i].text, it.trans)).length;
  if (echo > items.length / 2) { $("pasteMsg").textContent = "Sembra il testo originale, non la traduzione: controlla di aver copiato la risposta della chat."; return; }
  if (fromTab) {
    const r = await askTab({ type: "manualTrans", items: items.map(({ start, trans }) => ({ start, trans })) });
    if (!r || !r.ok) { $("pasteMsg").textContent = "Non riesco a mandarla alla scheda del video: " + ((r && r.error) || "nessuna risposta"); return; }
    await refreshFromTab();
  } else {
    items.forEach((it) => { cues[it.i].trans = it.trans; });
    render(true);
  }
  const nums = items.map((x) => x.i + 1);
  const lo = Math.min(...nums), hi = Math.max(...nums);
  const holes = hi - lo + 1 - nums.length;
  $("pasteMsg").textContent = `Usate ${items.length} traduzioni (frasi ${lo}-${hi})` + (holes ? `; mancano ${holes} frasi in mezzo, restano quelle di prima.` : ".") +
    (hi < cues.length ? " Se le frasi sono a parti, copia la parte successiva." : "");
  $("pasteText").value = "";
});

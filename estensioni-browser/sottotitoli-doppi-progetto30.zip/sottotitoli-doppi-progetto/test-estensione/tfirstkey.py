# 1.6.2: la prima chiave incollata in 🔑 Servizi, con i sottotitoli ancora su Google: i sottotitoli passano a quel servizio
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1500)
        await pp.evaluate("document.querySelectorAll('details').forEach(d=>d.open=true)")
        print("0.", await sw.evaluate("chrome.storage.sync.get('engine').then(r=>r.engine)"))
        await pp.fill("#key-gemini", "AIza-test"); await pp.press("#key-gemini", "Enter"); await pp.locator("#key-gemini").blur(); await pp.wait_for_timeout(1200)
        e1 = await sw.evaluate("chrome.storage.sync.get('engine').then(r=>r.engine)")
        v1 = await pp.evaluate("document.querySelector('.ds-task-video').value")
        await pp.fill("#groqKey", "gsk"); await pp.locator("#groqKey").blur(); await pp.wait_for_timeout(800)
        e2 = await sw.evaluate("chrome.storage.sync.get('engine').then(r=>r.engine)")
        print("1. dopo Gemini:", e1, v1, "| dopo Groq:", e2)
        ok = e1 == "gemini" and v1 == "gemini" and e2 == "gemini"
        print("errori:", errs if ok else errs + ["prima chiave non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

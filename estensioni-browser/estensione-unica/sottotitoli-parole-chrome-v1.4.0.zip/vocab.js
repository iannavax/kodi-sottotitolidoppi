// Il mio vocabolario — pagina comune a Sottotitoli Doppi e Parole al Volo (stesso file nelle due estensioni).
// Usa: DS_EXT, dsAnki* (config.js), DS_TTS (tts.js), DS_ETYM (etym.js), DS_LEARN (learn.js);
// in Parole al Volo anche PAV_* (volo-config.js, aggiunto dal build).
const $ = (id) => document.getElementById(id);
const PAV = typeof PAV_DEFAULTS !== "undefined";
let vocab = {};
let view = {};
let target = "it";
const pickers = new Map();   // voce → immagine che stai scegliendo (lo stato del selettore)
const VIEW = [
  ["ipa", "Pronuncia IPA", true], ["translit", "Trascrizione", true], ["meaning", "Significato", true], ["expl", "Spiegazione", true],
  ["sentence", "Frase", true], ["sentTrans", "Traduzione della frase", true], ["etym", "Etimologia", false], ["gender", "Genere", true],
  ["freq", "Frequenza", false], ["image", "Immagine", true], ["source", "Da dove viene", true], ["audio", "Pulsanti di ascolto", true],
  ["examples", "Esempi veri (Tatoeba, quando li apri)", false]
];
const show = (k) => view[k] !== false && (view[k] === true || (VIEW.find((v) => v[0] === k) || [])[2]);

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}
const langName = (l) => { try { return new Intl.DisplayNames(["it"], { type: "language" }).of(String(l).split("-")[0]) || l; } catch { return l; } };
const baseLang = (l) => String(l || "").split("-")[0].toLowerCase();

function fmtTime(s) {
  s = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(sec).padStart(2, "0");
}
function videoLink(e) {
  return e.videoId ? `https://www.youtube.com/watch?v=${encodeURIComponent(e.videoId)}&t=${Math.max(0, (e.time || 0) - 2)}s` : "";
}
function sentenceNode(e) {
  const p = el("span");
  const text = e.sentence || "";
  const i = text.toLowerCase().indexOf((e.word || "").toLowerCase());
  if (!e.word || i < 0) { p.textContent = text; return p; }
  p.append(text.slice(0, i), el("mark", null, text.slice(i, i + e.word.length)), text.slice(i + e.word.length));
  return p;
}
const save = () => DS_EXT.storage.local.set({ vocab });

// "Segna come imparata" la aggiunge anche alle parole che conosci (percentuale e colore)
function markKnown(e, on) {
  const lang = baseLang(e.lang) || "?";
  DS_EXT.storage.local.get({ knownWords: {} }).then((r) => {
    const kw = { ...(r.knownWords || {}) };
    const set = new Set(String(kw[lang] || "").split("\n").filter(Boolean));
    const w = String(e.word || "").toLowerCase().trim();
    if (!w) return;
    if (on) set.add(w); else set.delete(w);
    kw[lang] = [...set].join("\n");
    return DS_EXT.storage.local.set({ knownWords: kw });
  }).catch(() => {});
}

function filtered() {
  const q = $("search").value.trim().toLowerCase();
  const f = $("filter").value, lf = $("langFilter").value, so = $("sort").value;
  const list = Object.values(vocab).filter((e) =>
    (f === "all" || (f === "known" ? e.status === "known" : e.status !== "known")) &&
    (!lf || baseLang(e.lang) === lf) &&
    (!q || [e.word, e.lemma, e.meaning, e.sentence, e.sentenceTrans, e.explanation].some((x) => (x || "").toLowerCase().includes(q))));
  if (so === "az") list.sort((a, b) => String(a.word).localeCompare(String(b.word)));
  else if (so === "old") list.sort((a, b) => (a.added || 0) - (b.added || 0));
  else list.sort((a, b) => (b.added || 0) - (a.added || 0));
  return list;
}

// ---------- Ascolto: registrazione vera (Wiktionary) se c'è, sennò voce sintetica ----------
const recCache = new Map();
async function recordingFor(e) {
  const k = baseLang(e.lang) + "|" + String(e.word).toLowerCase();
  if (recCache.has(k)) return recCache.get(k);
  let rec = null;
  try {
    const w = await DS_ETYM.get(e.word, e.lang, target, e.lemma);
    rec = DS_LEARN.recordingOf({ wikt: w }, e.word, {});
    if (!rec) { const o = await DS_ETYM.audioOther(e.word, e.lang, target); if (o.audio && o.audio.length) rec = o.audio; }
  } catch {}
  recCache.set(k, rec);
  return rec;
}
async function speak(text, lang, rate) {
  try { const r = await DS_TTS.speak(text, lang, { rate }); await r.done; } catch {}
}

function render() {
  const all = Object.values(vocab);
  const learning = all.filter((e) => e.status !== "known").length;
  $("count").textContent = all.length
    ? `${all.length} ${all.length === 1 ? "voce salvata" : "voci salvate"}, ${learning} da imparare, ${all.filter((e) => e.anki).length} già in Anki.` : "";
  // lingue presenti
  const lf = $("langFilter"), cur = lf.value;
  const langs = [...new Set(all.map((e) => baseLang(e.lang)).filter(Boolean))].sort();
  lf.textContent = "";
  lf.append(new Option("Tutte le lingue", ""));
  for (const l of langs) lf.append(new Option(langName(l) + " (" + all.filter((e) => baseLang(e.lang) === l).length + ")", l));
  lf.value = langs.includes(cur) ? cur : "";

  const shown = filtered();
  const list = $("list");
  list.textContent = "";
  if (!all.length) {
    list.append(el("p", "empty", PAV
      ? "Ancora niente. Passa il mouse su una parola di una pagina (o seleziona un pezzo di testo) e premi la stella ☆ per salvarla qui."
      : "Ancora nessuna parola. Mentre guardi un video, passa il mouse su una parola nei sottotitoli e premi la stella ☆ per salvarla qui."));
    return;
  }
  if (!shown.length) { list.append(el("p", "empty", "Niente corrisponde a questa ricerca.")); return; }
  for (const e of shown) list.append(entryNode(e));
}

function entryNode(e) {
  const row = el("article", "entry" + (e.status === "known" ? " known" : "") + (e.kind === "text" ? " text" : ""));
  if (show("image") && e.image) { const im = el("img", "pic"); im.src = e.image; im.alt = ""; im.loading = "lazy"; row.append(im); }
  const top = el("div", "top");
  top.append(el("span", "word", e.word));
  if (show("audio") && e.kind !== "text") {
    const tts = el("button", "icon", "🔈"); tts.title = "Ascolta (voce sintetica)";
    tts.addEventListener("click", () => speak(e.word, e.lang));
    const rec = el("button", "icon", "🔊"); rec.title = "Registrazione di una persona (Wiktionary): la cerco quando la premi";
    rec.addEventListener("click", async () => {
      rec.textContent = "…";
      const r = await recordingFor(e);
      if (r) { const ok = await DS_LEARN.playUrl(r, null); rec.textContent = ok ? "🔊" : "✕"; if (!ok) rec.title = "Registrazione non riproducibile"; }
      else { rec.textContent = "—"; rec.title = "Su Wiktionary non c'è una registrazione di questa parola"; rec.disabled = true; }
    });
    top.append(tts, rec);
  } else if (show("audio")) {
    const tts = el("button", "icon", "🔈"); tts.title = "Leggi il testo (voce sintetica)";
    tts.addEventListener("click", () => speak(String(e.word).slice(0, 1500), e.lang));
    top.append(tts);
  }
  if (e.lemma && e.lemma.toLowerCase() !== String(e.word).toLowerCase()) top.append(el("span", "lemma", "→ " + e.lemma));
  if (e.pos) top.append(el("span", "pos", e.pos));
  if (show("ipa") && e.ipa) top.append(el("span", "ipa", "/" + e.ipa + "/"));
  if (show("translit") && e.translit) top.append(el("span", "tr", e.translit));
  if (show("gender") && e.gender) top.append(el("span", "badge", e.gender));
  if (show("freq") && e.freq) top.append(el("span", "badge", typeof DS_FREQ !== "undefined" ? DS_FREQ.label(e.freq) : "n. " + e.freq));
  if (e.lang) top.append(el("span", "lang", langName(e.lang)));
  row.append(top);
  if (show("meaning") && e.meaning) row.append(el("div", "meaning", e.meaning));
  if (show("expl") && e.explanation) row.append(el("div", "expl", e.explanation));
  if (show("etym") && e.etym) row.append(el("div", "etym", "Etimologia: " + e.etym));
  if (show("sentence") && e.sentence && e.kind !== "text") {
    const s = el("div", "sentence");
    if (show("audio")) {
      const b = el("button", "icon", "🔈"); b.title = "Ascolta la frase (voce sintetica)";
      b.addEventListener("click", () => speak(e.sentence, e.lang));
      const sl = el("button", "icon", "🐢"); sl.title = "Ascolta la frase lentamente";
      sl.addEventListener("click", () => speak(e.sentence, e.lang, 0.6));
      s.append(b, sl);
    }
    s.append(sentenceNode(e));
    row.append(s);
  }
  if (show("sentTrans") && e.sentenceTrans) row.append(el("div", "trans", e.sentenceTrans));
  if (show("examples") && e.kind !== "text") {
    const exBox = el("div", "ex");
    const b = el("button", "ghost", "Esempi veri (Tatoeba)");
    b.addEventListener("click", async () => {
      b.textContent = "…";
      let r;
      try { r = await DS_EXT.runtime.sendMessage({ type: "tatoeba", word: e.word, lang: e.lang, target }); } catch (err) { r = { error: String(err.message || err) }; }
      exBox.textContent = "";
      if (!r || r.error || !r.items || !r.items.length) { exBox.append(el("div", "note", r && r.error ? "Tatoeba non risponde" : "Nessun esempio su Tatoeba")); return; }
      for (const it of r.items) {
        const d = el("div");
        const p = el("button", "icon", it.audio ? "🔊" : "🔈");
        p.addEventListener("click", () => it.audio ? DS_LEARN.playUrl([it.audio, ...(it.audioAlt || [])], null) : speak(it.text, e.lang));
        d.append(p, document.createTextNode(" " + it.text));
        exBox.append(d);
        if (it.trans) exBox.append(el("div", "t", it.trans));
      }
    });
    exBox.append(b);
    row.append(exBox);
  }

  const actions = el("div", "actions");
  if (show("source")) {
    const link = videoLink(e);
    if (link) {
      const a = el("a", null, `Riguarda nel video (${fmtTime(e.time)})${e.title ? " · " + e.title : ""}`);
      a.href = link; a.target = "_blank"; a.rel = "noopener";
      actions.append(a);
    } else if (e.url) {
      const a = el("a", null, "Pagina: " + (e.title || e.url).slice(0, 70));
      a.href = e.url; a.target = "_blank"; a.rel = "noopener";
      actions.append(a);
    }
  }
  if (e.anki) actions.append(el("span", "badge", "in Anki"));
  const known = el("button", "ghost", e.status === "known" ? "Rimetti da imparare" : "Segna come imparata");
  known.addEventListener("click", () => {
    vocab[e.id].status = e.status === "known" ? "learning" : "known";
    save();
    if (e.kind !== "text") markKnown(e, vocab[e.id].status === "known");
  });
  const anki = el("button", "ghost", e.anki ? "Rimanda ad Anki" : "Manda ad Anki");
  anki.addEventListener("click", () => sendAnki([e], anki));
  const edit = el("button", "ghost", "✎ Modifica");
  edit.addEventListener("click", () => {
    if (row.querySelector(".edit")) { row.querySelector(".edit").remove(); return; }
    const f = el("div", "edit");
    const m = el("textarea"); m.rows = 2; m.value = e.meaning || ""; m.setAttribute("aria-label", "Significato");
    const t = el("textarea"); t.rows = 2; t.value = e.sentenceTrans || ""; t.setAttribute("aria-label", "Traduzione della frase");
    const ok = el("button", null, "Salva");
    ok.addEventListener("click", () => { vocab[e.id].meaning = m.value.trim(); vocab[e.id].sentenceTrans = t.value.trim(); save(); });
    f.append(el("span", "note", "Significato"), m, el("span", "note", "Traduzione della frase"), t, ok);
    row.append(f);
  });
  // immagine per la carta di Anki: cambiala (Wikipedia, Commons, Openverse, un indirizzo tuo) o toglila
  if (e.kind !== "text" && typeof DS_LEARN !== "undefined" && DS_LEARN.imagePicker) {
    const pic = el("button", "ghost", pickers.has(e.id) ? "🖼 chiudi" : e.image ? "🖼 Cambia immagine" : "🖼 Immagine");
    pic.title = "Scegli l'immagine per la carta di Anki";
    pic.addEventListener("click", () => {
      if (pickers.has(e.id)) pickers.delete(e.id);
      else pickers.set(e.id, { list: e.image ? [{ url: e.image, thumb: e.image, source: "salvata" }] : [], i: 0, open: true, none: e.image === "" });
      render();
    });
    actions.append(pic);
    const im = pickers.get(e.id);
    if (im) {
      const redraw = () => { if (pickers.get(e.id) === im) render(); };
      const box = DS_LEARN.imagePicker(im, { word: e.lemma || e.word, lang: e.lang, rerender: redraw, autoload: true, onPick: (url) => {
        if (!vocab[e.id]) return;
        vocab[e.id].image = url;
        save();
      } });
      row.append(box);
      if (e.anki) row.append(el("span", "note", "Questa parola è già in Anki: la nuova immagine vale per «Rimanda ad Anki» e per il file esportato (in Anki la carta di prima resta com'è)."));
    }
  }
  const del = el("button", "ghost danger", "Elimina");
  del.addEventListener("click", () => { delete vocab[e.id]; save(); });
  actions.append(known, anki, edit, del);
  row.append(actions);
  return row;
}

// ---------- Anki ----------
async function sendAnki(entries, btn) {
  const msg = $("ankiMsg");
  msg.className = "";
  msg.textContent = `Mando ${entries.length} ${entries.length === 1 ? "carta" : "carte"} ad Anki… (se Anki chiede il permesso, premi Yes)`;
  if (btn) btn.disabled = true;
  let r;
  try {
    r = await DS_EXT.runtime.sendMessage(PAV ? { type: "pavAnki", entries } : { type: "ankiAdd", entries });
  } catch (e) { r = { error: String(e.message || e) }; }
  if (btn) btn.disabled = false;
  if (!r || r.error) { msg.className = "err"; msg.textContent = "Anki: " + ((r && r.error) || "nessuna risposta"); return; }
  const l = await DS_EXT.storage.local.get({ vocab: {} });
  entries.forEach((e, i) => { if (r.ids[i] != null && l.vocab[e.id]) l.vocab[e.id].anki = 1; });
  await DS_EXT.storage.local.set({ vocab: l.vocab });
  msg.textContent = `Fatto: ${entries.length - r.dup} carte aggiunte (${r.deck})` + (r.dup ? `, ${r.dup} c'erano già.` : ".");
}
$("send").addEventListener("click", () => {
  const entries = filtered().filter((e) => !e.anki);
  if (!entries.length) { $("ankiMsg").textContent = "Tutte le voci mostrate sono già in Anki."; return; }
  sendAnki(entries, $("send"));
});

// file per Anki (tabulazioni), con il mazzo di ogni carta
$("export").addEventListener("click", async () => {
  const entries = filtered();
  if (!entries.length) { alert("Non c'è niente da esportare con questo filtro."); return; }
  const s = await DS_EXT.storage.sync.get({ ankiDeck: PAV ? PAV_DEFAULTS.ankiDeck : "Sottotitoli Doppi", ankiPerLang: true, ankiLangDeck: "Lingue::{lingua}" });
  const opts = { deck: s.ankiDeck, perLang: s.ankiPerLang !== false, tpl: s.ankiLangDeck };
  let text;
  if (PAV) text = pavAnkiFile(entries, opts);
  else {
    const lines = ["#separator:tab", "#html:true", "#tags column:3", "#deck column:4"];
    for (const e of entries) {
      const f = dsAnkiFields(e);
      const front = f.front + (e.image && /^https:\/\//.test(e.image) ? `<br><img src="${dsAnkiEsc(e.image)}">` : "");
      lines.push([front, f.back, f.tags.join(" "), dsAnkiDeckFor(e.lang, opts)].join("\t"));
    }
    text = lines.join("\n") + "\n";
  }
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${PAV ? "parole-al-volo" : "vocabolario"}-anki-${new Date().toISOString().slice(0, 10)}.txt`;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
});

// ascolta l'elenco: parola (registrazione se c'è) e poi il significato con la voce della tua lingua
let playing = false;
$("playAll").addEventListener("click", async () => {
  if (playing) { playing = false; $("playAll").textContent = "▶ Ascolta l'elenco"; return; }
  playing = true; $("playAll").textContent = "■ Ferma";
  for (const e of filtered().filter((x) => x.kind !== "text")) {
    if (!playing) break;
    await speak(e.word, e.lang);
    await new Promise((r) => setTimeout(r, 500));
    if (!playing) break;
    if (e.meaning) await speak(e.meaning, target);
    await new Promise((r) => setTimeout(r, 900));
  }
  playing = false; $("playAll").textContent = "▶ Ascolta l'elenco";
});

// ---------- Cosa mostrare (resta salvato) ----------
function renderOpts() {
  const box = $("opts");
  box.textContent = "";
  for (const [k, label] of VIEW) {
    const l = el("label");
    const c = el("input"); c.type = "checkbox"; c.checked = show(k);
    c.addEventListener("change", () => { view[k] = c.checked; DS_EXT.storage.local.set({ vocabView: view }).catch(() => {}); render(); });
    l.append(c, document.createTextNode(label));
    box.append(l);
  }
}

$("search").addEventListener("input", render);
$("filter").addEventListener("change", render);
$("langFilter").addEventListener("change", render);
$("sort").addEventListener("change", render);
DS_EXT.storage.onChanged.addListener((ch, area) => {
  if (area === "local" && ch.vocab) { vocab = ch.vocab.newValue || {}; render(); }
});
(async () => {
  const l = await DS_EXT.storage.local.get({ vocab: {}, vocabView: {} });
  const s = await DS_EXT.storage.sync.get({ targetLang: "it" });
  vocab = l.vocab || {}; view = l.vocabView || {}; target = s.targetLang || "it";
  if (PAV) document.title = "Parole al Volo — vocabolario";
  renderOpts();
  render();
})();

// ---------- Scambio con l'altra estensione (Sottotitoli Doppi ↔ Parole al Volo) ----------
$("swapExp").addEventListener("click", async () => {
  const msg = $("ankiMsg"); msg.className = "";
  try { const r = await dsExportData({ vocab: true, known: true }); msg.textContent = `Salvato «${r.name}»: ${r.vocab} voci e ${r.known} parole che conosci. Nell'altra estensione: Il mio vocabolario → ⇄ Importa…`; }
  catch (e) { msg.className = "err"; msg.textContent = "Non riesco: " + (e.message || e); }
});
$("swapImp").addEventListener("click", () => $("swapFile").click());
$("swapFile").addEventListener("change", async () => {
  const f = $("swapFile").files[0];
  $("swapFile").value = "";
  if (!f) return;
  const msg = $("ankiMsg"); msg.className = "";
  try { msg.textContent = dsImportReport(await dsImportData(await f.text(), "")); }
  catch (e) { msg.className = "err"; msg.textContent = "Non riesco a importare: " + (e.message || e); }
});
$("freqPage").addEventListener("click", async () => {
  // la lingua con più parole nel vocabolario
  const n = {};
  for (const e of Object.values(vocab)) { const l = String(e.lang || "").split("-")[0]; if (l) n[l] = (n[l] || 0) + 1; }
  const lang = $("langFilter").value || Object.keys(n).sort((a, b) => n[b] - n[a])[0] || "en";
  DS_EXT.tabs.create({ url: DS_EXT.runtime.getURL("freq.html") + "?lang=" + encodeURIComponent(lang) + "&target=" + encodeURIComponent(target) });
});

$("swapSync").textContent = "⇄ Sincronizza con le altre estensioni";
$("swapSync").title = "Passa vocabolario e parole conosciute da qui a " + dsSiblingNames().join(", ") + " (quelle installate) e viceversa: si uniscono, non si cancella niente. Passano anche le chiavi dei servizi e le impostazioni non ancora scelte";
$("swapSync").addEventListener("click", async () => {
  const msg = $("ankiMsg"); msg.className = "";
  msg.textContent = "Sincronizzo con le altre estensioni…";
  try { msg.textContent = dsSyncReport(await dsSyncWithSibling({ known: true, vocab: true })); }
  catch (e) { msg.className = "err"; msg.textContent = "Non riesco: " + (e.message || e); }
});

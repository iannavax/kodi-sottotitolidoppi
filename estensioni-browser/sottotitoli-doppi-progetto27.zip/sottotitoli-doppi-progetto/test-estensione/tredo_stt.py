# 1.4.12: «Rifai la trascrizione» esplicito, nel popup e nella scheda ⚑ sul video. Con «Rifalla con il modello più
# preciso» tutti i pezzi nuovi vanno a Whisper con whisper-large-v3 (non turbo).
import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
SHOWN = "(document.querySelector('.dualsub-overlay:not([hidden]) .dualsub-orig')||{}).textContent||''"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, stt:'groq', sttModel:'whisper-large-v3-turbo'}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsRedo"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        for _ in range(100):
            if await pg.evaluate(SHOWN): break
            await pg.wait_for_timeout(200)
        await pg.wait_for_timeout(4000)
        n1 = len(log["groq"])
        print("1. trascrizione partita: pezzi a Whisper", n1, "| modelli:", sorted(set(log.get("groq_model", []))))
        # popup: i pulsanti compaiono quando c'è una trascrizione
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(600)
        st = await sw.evaluate("chrome.tabs.query({url:'https://www.youtube.com/*'}).then(t=>new Promise(r=>chrome.tabs.sendMessage(t[0].id,{type:'liveState'},r)))")
        await pp.evaluate("s=>updateLive(s)", st); await pp.wait_for_timeout(200)
        vis = await pp.evaluate("[!document.getElementById('redoBox').hidden, !document.getElementById('redoSttBetter').hidden]")
        print("2. popup: frasi", st.get("cues"), "| «Rifai la trascrizione» visibile:", vis[0], "| «più preciso»:", vis[1])
        await pp.evaluate("updateLive({onVideo:true, running:false, cues:0})"); await pp.wait_for_timeout(100)
        hidden_empty = await pp.evaluate("document.getElementById('redoBox').hidden")
        print("   senza trascrizione nascosto:", hidden_empty)
        await pp.close()
        # scheda ⚑ sul video
        await pg.evaluate("document.querySelector('video').pause()")
        await pg.evaluate("document.querySelector('.dualsub-fixbtn').click()"); await pg.wait_for_timeout(500)
        btns = await pg.evaluate("[...document.querySelectorAll('.dualsub-fixcard button')].map(b=>b.textContent)")
        print("3. scheda ⚑:", [b for b in btns if "trascri" in b.lower() or "preciso" in b])
        before = len(log["groq"])
        await pg.evaluate("[...document.querySelectorAll('.dualsub-fixcard button')].find(b=>/più preciso/.test(b.textContent)).click()")
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_timeout(9000)
        newm = log.get("groq_model", [])[before:]
        print("4. dopo «Rifalla con il modello più preciso»: pezzi nuovi", len(newm), "| modelli:", sorted(set(newm)))
        print("   stato:", (await pg.evaluate("(document.querySelector('.dualsub-status')||{}).textContent||''"))[:100])
        ok = vis == [True, True] and hidden_empty and newm and set(newm) == {"whisper-large-v3"}
        print("errori:", errs if ok else errs + ["rifai trascrizione non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

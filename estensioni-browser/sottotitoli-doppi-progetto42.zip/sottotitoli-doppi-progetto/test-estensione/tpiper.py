# 1.7.0: voci Piper gratuite (sul computer) e del server Speaches nel menù «🔈 Voce» — modello finto, rete simulata
import asyncio, os, sys, json
os.environ["PIPER_SPEACHES"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from charness import *
import http.server, threading, shutil
FIX = "/tmp/piperfix"; shutil.rmtree(FIX, ignore_errors=True)
for k, n, q, fam, cod in (("it_IT-riccardo-x_low", "riccardo", "x_low", "it", "it_IT"), ("en_US-amy-low", "amy", "low", "en", "en_US")):
    d = f"{FIX}/{fam}/{cod}/{n}/{q}"; os.makedirs(d)
    shutil.copy("/home/claude/e2e/fixtures/fake-piper.onnx", f"{d}/{k}.onnx")
    json.dump({"audio": {"sample_rate": 22050}, "espeak": {"voice": "it" if fam == "it" else "en-us"}, "inference": {"noise_scale": 0.667, "length_scale": 1, "noise_w": 0.8}, "num_speakers": 1}, open(f"{d}/{k}.onnx.json", "w"))
json.dump({"it_IT-riccardo-x_low": {"key": "it_IT-riccardo-x_low", "num_speakers": 1, "files": {"it/it_IT/riccardo/x_low/it_IT-riccardo-x_low.onnx": {"size_bytes": 311}}}, "it_IT-paola-medium": {"key": "it_IT-paola-medium", "files": {}}, "en_US-amy-low": {"key": "en_US-amy-low", "files": {"en/en_US/amy/low/en_US-amy-low.onnx": {"size_bytes": 311}}}}, open(f"{FIX}/voices.json", "w"))
os.makedirs(f"{FIX}/api", exist_ok=True)
json.dump([{"id": "speaches-ai/piper-it_IT-riccardo-x_low", "downloads": 5400}, {"id": "speaches-ai/piper-it_IT-paola-medium", "downloads": 123000}, {"id": "speaches-ai/piper-en_US-amy-low", "downloads": 900}], open(f"{FIX}/api/models", "w"))
hits = []
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=FIX, **k)
    def log_message(self, f, *a): hits.append(self.path)
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 8791), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({piperBase:'http://127.0.0.1:8791/', piperPopUrl:'http://127.0.0.1:8791/api/models'})")
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'en', ttsLang:'it', ipa:false})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append("popup: " + str(e)))
        pp.on("console", lambda m: errs.append("console: " + m.text) if m.type == "error" else None)
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1500)
        await pp.evaluate("document.getElementById('dTts').open=true"); await pp.wait_for_timeout(2500)
        opts = await pp.evaluate("[...document.querySelectorAll('#ttsPiper option')].map(o=>o.value+' | '+o.textContent)")
        print("1. voci Piper per l'italiano:", opts, "| server:", hits)
        await pp.select_option("#ttsVoice", "piper:it_IT-riccardo-x_low"); await pp.wait_for_timeout(500)
        print("2. riquadro:", await pp.inner_text("#piperInfo"), "| scarica visibile:", await pp.is_visible("#piperGet"))
        await pp.click("#piperGet"); await pp.wait_for_timeout(3000)
        print("3. dopo il download:", await pp.inner_text("#piperInfo"), "| elimina visibile:", await pp.is_visible("#piperDel"), "| server:", hits)
        await pp.click("#ttsTest"); await pp.wait_for_timeout(8000)
        print("4. prova:", await pp.inner_text("#ttsInfo"))
        # importo una voce già presente sul computer (file .onnx + .onnx.json con il nome originale)
        d = "/tmp/piperimp"; shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
        shutil.copy("/home/claude/e2e/fixtures/fake-piper.onnx", f"{d}/it_IT-paola-medium.onnx")
        json.dump({"audio": {"sample_rate": 22050}, "espeak": {"voice": "it"}, "inference": {"noise_scale": 0.667, "length_scale": 1, "noise_w": 0.8}}, open(f"{d}/it_IT-paola-medium.onnx.json", "w"))
        n0 = len(hits)
        await pp.set_input_files("#piperFiles", [f"{d}/it_IT-paola-medium.onnx", f"{d}/it_IT-paola-medium.onnx.json"]); await pp.wait_for_timeout(2500)
        print("4b. import:", await pp.inner_text("#piperImportInfo"), "|", await pp.evaluate("[...document.querySelectorAll('#ttsPiper option')].map(o=>o.textContent)"))
        await pp.select_option("#ttsVoice", "piper:it_IT-paola-medium"); await pp.click("#ttsTest"); await pp.wait_for_timeout(5000)
        print("   prova con la voce importata:", await pp.inner_text("#ttsInfo"), "| scaricamenti nuovi:", [h for h in hits[n0:] if h.endswith(".onnx")])
        # aggiorna l'elenco a mano + voce albanese «edon» (aggiunta a mano all'elenco) + collegamenti al sito
        await pp.click("#piperRefresh"); await pp.wait_for_timeout(2500)
        print("4c. aggiorna:", await pp.inner_text("#piperImportInfo"), "| link:", await pp.evaluate("[...document.querySelectorAll('#piperRefresh ~ a, #piperRefreshInfo a')].map(a=>a.href)"))
        await sw.evaluate("chrome.storage.sync.set({ttsLang:'sq'})"); await pp.reload(); await pp.wait_for_timeout(1500)
        await pp.evaluate("document.getElementById('dTts').open=true"); await pp.wait_for_timeout(2500)
        print("4d. albanese:", await pp.evaluate("[...document.querySelectorAll('#ttsPiper option')].map(o=>o.value+' | '+o.textContent)"))
        await sw.evaluate("chrome.storage.sync.set({ttsLang:'it'})"); await pp.reload(); await pp.wait_for_timeout(1500)
        await pp.evaluate("document.getElementById('dTts').open=true"); await pp.wait_for_timeout(2000)
        # Speaches
        await pp.check("#ttsSpeaches"); await pp.wait_for_timeout(2500)
        sp = await pp.evaluate("[...document.querySelectorAll('#ttsSpeachesG option')].map(o=>o.value+' | '+o.textContent)")
        print("5. Speaches:", sp)
        await pp.select_option("#ttsVoice", "speaches:it_IT-riccardo-x_low"); await pp.wait_for_timeout(500)
        print("   riquadro:", await pp.inner_text("#piperInfo"), "| installa visibile:", await pp.is_visible("#piperGet"))
        await pp.click("#piperGet"); await pp.wait_for_timeout(1500)
        log["speaches_installed"] = ["speaches-ai/piper-it_IT-riccardo-x_low"]
        await pp.click("#ttsTest"); await pp.wait_for_timeout(2500)
        print("6. prova Speaches:", await pp.inner_text("#ttsInfo"), "| installato:", log.get("speaches_install"), "| tts:", log.get("speaches_tts"))
        # nella scheda della parola (YouTube): ⚙ → voce Piper per l'inglese, poi 🔊
        await sw.evaluate("chrome.storage.sync.set({ttsVoice:'', ttsSpeaches:false, ttsLang:''})")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append("pagina: " + str(e)))
        await pg.goto("https://www.youtube.com/watch?v=voiceTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("market")).click(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-card .dualsub-voicegear").click(); await pg.wait_for_timeout(2500)
        items = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .ds-voicemenu-item')].map(b=>b.textContent)")
        print("7. menu ⚙ della scheda:", items)
        await pg.locator(".dualsub-card .ds-voicemenu-item", has_text="Piper: Amy").click(); await pg.wait_for_timeout(500)
        print("   salvata:", await sw.evaluate("chrome.storage.sync.get('ttsVoices')"))
        await pg.locator(".dualsub-card .dualsub-speak:not(.dualsub-rec)").click(); await pg.wait_for_timeout(6000)
        print("8. 🔊:", await pg.evaluate("document.querySelector('.dualsub-card .dualsub-speak:not(.dualsub-rec)').title"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

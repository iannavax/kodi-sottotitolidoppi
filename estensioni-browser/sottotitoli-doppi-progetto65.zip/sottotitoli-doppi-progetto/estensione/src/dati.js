// Pagina «Dati salvati» (1.10.0): quanto occupa la memoria «local», guardare, salvare su file, svuotare, pulizia per età.
(() => {
  const $ = (id) => document.getElementById(id);
  const R = DS_LOCAL_RAW || { get: (k) => DS_EXT.storage.local.get(k), set: (o) => DS_EXT.storage.local.set(o), remove: (k) => DS_EXT.storage.local.remove(k), getKeys: null };
  const fmt = (n) => n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(0) + " KB" : (n / 1048576).toFixed(1) + " MB";
  const day = (t) => t ? new Date(t).toLocaleDateString() : "—";
  const say = (t, err) => { $("msg").textContent = t || ""; $("msg").className = err ? "err" : ""; };
  const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error("la memoria non risponde")), ms))]);
  let sizes = {}, stamps = {}, busy = false;

  async function load() {
    say(""); $("tot").textContent = "Calcolo la dimensione…";
    sizes = {};
    let keys;
    try { keys = await withTimeout(dsDataKeys(), 120000); }
    catch (e) { $("tot").textContent = "Non riesco a leggere l'elenco dei dati: " + e.message + ". Vedi in fondo alla pagina."; $("nuke").open = true; return; }
    try { stamps = (await withTimeout(R.get({ dsStamps: {} }), 30000)).dsStamps || {}; } catch { stamps = {}; }
    for (let i = 0; i < keys.length; i += 20) {
      const part = keys.slice(i, i + 20);
      try {
        const r = await withTimeout(R.get(part), 60000);
        for (const k of part) sizes[k] = k in r ? (JSON.stringify(r[k]) || "").length + k.length : 0;
      } catch { for (const k of part) sizes[k] = 0; }
      $("tot").textContent = `Calcolo la dimensione… ${Math.min(i + 20, keys.length)} di ${keys.length}`;
    }
    render();
  }

  function groups() {
    const g = DS_DATA_CATS.map((c) => ({ c, keys: [], size: 0 }));
    for (const k of Object.keys(sizes)) { const c = dsDataCat(k); const e = g.find((x) => x.c === c); e.keys.push(k); e.size += sizes[k]; }
    for (const e of g) e.keys.sort((a, b) => sizes[b] - sizes[a]);
    return g;
  }

  function render() {
    const g = groups(), total = g.reduce((a, e) => a + e.size, 0);
    $("tot").textContent = `In tutto: ${fmt(total)} (${Object.keys(sizes).length} voci). I numeri sono una stima del testo salvato; la cartella su disco può essere un po' più grande.`;
    const box = $("cats"); box.textContent = "";
    for (const e of g) {
      const d = document.createElement("details"); d.className = "box cat"; d.dataset.cat = e.c.id;
      const sm = document.createElement("summary");
      sm.innerHTML = `<span class="nm"></span><span class="note">${e.keys.length} voci</span><span class="sz">${fmt(e.size)}</span>`;
      sm.querySelector(".nm").textContent = e.c.name;
      d.append(sm);
      const bar = document.createElement("div"); bar.className = "bar"; bar.innerHTML = `<i style="width:${total ? Math.max(1, Math.round(e.size / total * 100)) : 0}%"></i>`; d.append(bar);
      const acts = document.createElement("div"); acts.className = "acts";
      const bs = mk("💾 Salva in un file", () => exportKeys(e.keys, e.c.id));
      acts.append(bs);
      if (!e.c.keep) acts.append(mk("🗑 Svuota questo gruppo…", () => clearKeys(e.keys, e.c.name), "danger"));
      d.append(acts);
      let shown = 0;
      const list = document.createElement("div");
      const more = mk("Mostra altre voci", () => page(), "");
      const page = () => {
        for (const k of e.keys.slice(shown, shown + 100)) list.append(row(k, e.c));
        shown += 100; more.hidden = shown >= e.keys.length;
      };
      d.append(list, more);
      d.addEventListener("toggle", () => { if (d.open && !shown) page(); });
      box.append(d);
    }
  }

  function mk(label, fn, cls = "ghost") {
    const b = document.createElement("button"); b.type = "button"; b.className = cls === "danger" ? "ghost danger" : cls || "ghost"; b.textContent = label;
    b.addEventListener("click", fn); return b;
  }

  function row(k, c) {
    const r = document.createElement("div"); r.className = "row";
    r.innerHTML = `<span class="k"></span><span class="s">${fmt(sizes[k])}</span><span class="d">${c.keep ? "" : day(stamps[k])}</span>`;
    r.querySelector(".k").textContent = k;
    let pre = null;
    r.append(mk("👁 Guarda", async () => {
      if (pre) { pre.remove(); pre = null; return; }
      pre = document.createElement("pre"); pre.textContent = "Carico…"; r.append(pre);
      try { const v = (await withTimeout(R.get(k), 60000))[k]; const t = JSON.stringify(v, null, 1) || ""; pre.textContent = t.slice(0, 6000) + (t.length > 6000 ? `\n… (altri ${t.length - 6000} caratteri: salva in un file per averli tutti)` : ""); }
      catch (e) { pre.textContent = "Errore: " + e.message; }
    }));
    r.append(mk("💾", () => exportKeys([k], k.replace(/[^\w.-]+/g, "_").slice(0, 40))));
    if (!c.keep) r.append(mk("🗑", async () => { if (busy) return; await R.remove(k); delete sizes[k]; render(); say("Voce cancellata."); }, "danger"));
    return r;
  }

  async function exportKeys(keys, name) {
    if (busy) return; busy = true; say("Preparo il file… (può volerci un po')");
    try {
      const parts = ["{\n"]; let n = 0;
      for (let i = 0; i < keys.length; i += 20) {
        const part = keys.slice(i, i + 20), r = await withTimeout(R.get(part), 120000);
        for (const k of part) if (k in r) parts.push((n++ ? ",\n" : "") + JSON.stringify(k) + ": " + JSON.stringify(r[k]));
        say(`Preparo il file… ${Math.min(i + 20, keys.length)} di ${keys.length}`);
      }
      parts.push("\n}\n");
      const blob = new Blob(parts, { type: "application/json" });
      const fname = `sottotitoli-dati-${name}-${new Date().toISOString().slice(0, 10)}.json`;
      if (window.showSaveFilePicker) {   // Chrome/Edge: scegli tu dove (anche un'altra unità)
        try { const h = await window.showSaveFilePicker({ suggestedName: fname, types: [{ description: "JSON", accept: { "application/json": [".json"] } }] }); const w = await h.createWritable(); await w.write(blob); await w.close(); say(`Salvato: ${fmt(blob.size)}.`); return; }
        catch (e) { if (e && e.name === "AbortError") { say("Salvataggio annullato."); return; } }
      }
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = fname; document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60000);
      say(`File pronto (${fmt(blob.size)}): lo trovi nella cartella dei download. In Firefox puoi scegliere dove salvare in Impostazioni → Download → «Chiedi dove salvare i file».`);
    } catch (e) { say("Non sono riuscito a salvare: " + e.message, true); }
    finally { busy = false; }
  }

  async function clearKeys(keys, name) {
    if (busy || !keys.length) return;
    if (!confirm(`Cancello «${name}» (${keys.length} voci)? Se servono, l'estensione le rifà (con nuove richieste ai servizi).`)) return;
    busy = true;
    try {
      for (let i = 0; i < keys.length; i += 40) { await withTimeout(R.remove(keys.slice(i, i + 40)), 60000); say(`Cancello… ${Math.min(i + 40, keys.length)} di ${keys.length}`); }
      say("Fatto."); busy = false; await load();
    } catch (e) { say("Non sono riuscito a cancellare tutto: " + e.message, true); }
    finally { busy = false; }
  }

  // ----- pulizia per età -----
  const auto = { days: 0, cats: DS_DATA_CATS.filter((c) => c.auto).map((c) => c.id) };
  function saveAuto() { try { DS_EXT.storage.sync.set({ dsAutoClean: { days: auto.days, cats: auto.cats } }); } catch {} }
  for (const c of DS_DATA_CATS.filter((x) => !x.keep)) {
    const l = document.createElement("label"), i = document.createElement("input"); i.type = "checkbox"; i.dataset.cat = c.id;
    l.append(i, document.createTextNode(c.name)); $("autoCats").append(l);
    i.addEventListener("change", () => { auto.cats = [...$("autoCats").querySelectorAll("input:checked")].map((x) => x.dataset.cat); saveAuto(); });
  }
  // ----- cosa salvare -----
  const SAVE_HINT = { trans: "se spento, la trascrizione si rifà (con nuove richieste) a ogni apertura del video", cache: "se spento, le traduzioni si rifanno a ogni apertura del video", dict: "se spento, dizionari, frequenze e traduzioni dell'interfaccia si riscaricano ogni volta", expl: "se spento, le spiegazioni e le etimologie non restano salvate" };
  for (const c of DS_DATA_CATS.filter((x) => !x.keep)) {
    const l = document.createElement("label"), i = document.createElement("input"); i.type = "checkbox"; i.dataset.cat = c.id; i.checked = true;
    l.title = SAVE_HINT[c.id] || ""; l.append(i, document.createTextNode(c.name)); $("saveCats").append(l);
    i.addEventListener("change", () => { const offs = [...$("saveCats").querySelectorAll("input:not(:checked)")].map((x) => x.dataset.cat); try { DS_EXT.storage.sync.set({ dsCacheOff: offs }); } catch {} say(i.checked ? "Questo gruppo si salva di nuovo." : "Da ora questo gruppo non si salva più. " + (SAVE_HINT[c.id] || ""), false); });
  }
  DS_EXT.storage.sync.get({ dsCacheOff: [] }).then((r) => { $("saveCats").querySelectorAll("input").forEach((i) => { i.checked = !(r.dsCacheOff || []).includes(i.dataset.cat); }); }).catch(() => {});
  DS_EXT.storage.sync.get({ dsAutoClean: null }).then((r) => {
    if (r.dsAutoClean) { auto.days = r.dsAutoClean.days || 0; auto.cats = r.dsAutoClean.cats || auto.cats; }
    $("days").value = String(auto.days);
    $("autoCats").querySelectorAll("input").forEach((i) => { i.checked = auto.cats.includes(i.dataset.cat); });
  }).catch(() => {});
  $("days").addEventListener("change", () => { auto.days = +$("days").value; saveAuto(); say(auto.days ? "Impostato: la pulizia parte da sola ogni volta che apri il browser." : "Pulizia automatica spenta."); });
  $("cleanNow").addEventListener("click", async () => {
    if (busy) return;
    if (!auto.days) { say("Scegli prima dopo quanto tempo cancellare.", true); return; }
    busy = true; say("Pulisco…");
    try { const n = await dsDataClean(auto.days, auto.cats); busy = false; say(`Cancellate ${n} voci più vecchie di ${auto.days} giorni.`); await load(); }
    catch (e) { say("Errore: " + e.message, true); }
    finally { busy = false; }
  });
  $("wipeAll").addEventListener("click", async () => {
    if (!confirm("Azzero TUTTA la memoria locale dell'estensione? Si perdono vocabolario, parole note, spiegazioni, trascrizioni e traduzioni salvate (le chiavi e le impostazioni restano). Non si può annullare.")) return;
    if (!confirm("Sei proprio sicuro? Hai già salvato un file con «Salva tutto in un file»?")) return;
    say("Azzero… (con tanti dati può volerci qualche minuto: non chiudere la pagina)");
    const t0 = Date.now(), tick = setInterval(() => say(`Azzero… ${Math.round((Date.now() - t0) / 1000)} secondi. Se resta fermo oltre 2 minuti, usa il metodo della cartella qui sopra.`), 5000);
    try {
      await DS_EXT.storage.local.clear();
      // (i segni degli aggiornamenti già fatti restano: senza, al prossimo aggiornamento si rifarebbero e cambierebbero le tue impostazioni)
      await DS_EXT.storage.local.set({ migrated: { flashLite: true, consumo16: true } }).catch(() => {});
      clearInterval(tick); say("Memoria azzerata."); await load();
    } catch (e) { clearInterval(tick); say("Errore: " + e.message, true); }
  });
  // «Salva tutto» anche quando l'elenco non si carica: usa l'elenco dei nomi
  const saveAll = mk("💾 Salva tutto in un file", async () => { const ks = await withTimeout(dsDataKeys(), 120000); exportKeys(ks, "tutto"); });
  $("nuke").querySelector(".acts").prepend(saveAll);
  if (/\bFirefox\//.test(navigator.userAgent)) $("ffHint").hidden = false;   // (le istruzioni per la cartella valgono per Firefox)
  load();
})();

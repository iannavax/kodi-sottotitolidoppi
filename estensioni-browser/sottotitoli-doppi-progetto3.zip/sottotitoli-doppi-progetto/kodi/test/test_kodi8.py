# Prove della 1.10.4/1.10.6: server che interrompe le connessioni (come Real-Debrid con troppe richieste): nessuna frase deve sparire
import sys, os, json, time, shutil, threading, http.server, socketserver, re, urllib.parse
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
FILM = "/tmp/mkvt/film.mkv"
STATS = {"req": 0, "bytes": 0}
import random
random.seed(7)
FLAKY = {"p": 0.35, "dead": set()}
ACTIVE = {"n": 0, "max": 0, "conns": 0}
LOCK = threading.Lock()
class H(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def setup(self):
        super().setup()
        with LOCK:
            ACTIVE["n"] += 1; ACTIVE["conns"] += 1; ACTIVE["max"] = max(ACTIVE["max"], ACTIVE["n"]); self.too_many = ACTIVE["n"] > 3
    def finish(self):
        with LOCK: ACTIVE["n"] -= 1
        try: super().finish()
        except Exception: pass
    def do_GET(self):
        m0 = re.match(r"bytes=(\d+)-", self.headers.get("Range", ""))
        off = int(m0.group(1)) if m0 else 0
        if self.too_many or (off > 70000 and random.random() < FLAKY["p"]) or any(a <= off < b for a, b in FLAKY["dead"]):
            self.close_connection = True; self.connection.close(); return
        if not self.path.startswith("/d/XYZ/"):
            self.send_response(404); self.end_headers(); return
        size = os.path.getsize(FILM)
        m = re.match(r"bytes=(\d+)-(\d*)", self.headers.get("Range", ""))
        a = int(m.group(1)) if m else 0
        b = min(int(m.group(2)) if m and m.group(2) else size - 1, size - 1)
        with open(FILM, "rb") as f:
            f.seek(a); data = f.read(b - a + 1)
        STATS["req"] += 1; STATS["bytes"] += len(data)
        self.send_response(206 if m else 200)
        self.send_header("Content-Length", str(len(data))); self.send_header("Content-Range", "bytes %d-%d/%d" % (a, b, size))
        self.end_headers(); self.wfile.write(data)
srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), H); srv.daemon_threads = True
threading.Thread(target=srv.serve_forever, daemon=True).start()
URL = "http://127.0.0.1:%d/d/XYZ/Festen.1998.Danish.1080p.mkv" % srv.server_address[1]
from resources.lib import core
tr = lambda x: " ".join(w[::-1] for w in x.split())
real_http = core.http
def fake_http(url, data=None, headers=None, timeout=90):
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + tr(l) + "]" for l in q.split("\n")), q]], None, "da"]).encode(), {}
    if "opensubtitles" in url or "cinemeta" in url:
        return 200, b'{"subtitles": [{"id": "1", "url": "https://dl.os.example/1.srt", "lang": "dan"}], "metas": []}', {}
    return 404, b"", {}
core.http = fake_http
from resources.lib import runner, subtitles
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra",
                           "trans_color": "FFFF00", "auto": "true", "source_mode": "auto (file)", "trans_mode": "nuova (x)"})
xbmc.Player.playing = True; xbmc.Player.playing_file = URL; xbmc.Player.subs.clear(); xbmc.Player.sub_lang = "dan"
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": URL, "at": time.time() - 20})
from resources.lib import mkvsubs
xbmc.Player.playing = True; xbmc.Player.playing_file = URL; xbmc.Player.subs.clear(); xbmc.Player.sub_lang = "dan"
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": URL, "at": time.time() - 20})
# 1. 35% delle richieste interrotte: alla fine ci sono tutte le 40 frasi
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
n1 = len([b for b in t.strip().split("\n\n") if b.strip()])
cache = [f for f in os.listdir(runner.CACHE) if f.startswith("mkv2-")]
print("1. frasi:", n1, "| richieste:", STATS["req"], "| connessioni aperte:", ACTIVE["conns"], "| massimo insieme:", ACTIVE["max"], "| cache:", cache)
ok1 = n1 == 40 and len(cache) == 1 and ".parziale." not in cache[0]
# 2. una zona del file che non risponde mai: si usa quello che c'è, avviso, e niente cache definitiva
for f in cache: os.remove(os.path.join(runner.CACHE, f))
FLAKY["p"] = 0.0
size = os.path.getsize(FILM)
FLAKY["dead"] = {(int(size * 0.4), int(size * 0.6))}
xbmc.Player.subs.clear(); xbmcgui.NOTES.clear()
for f in os.listdir(runner.CACHE):
    if f.endswith(".json"): os.remove(os.path.join(runner.CACHE, f))
t0 = time.time()
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
n2 = len([b for b in t.strip().split("\n\n") if b.strip()])
cache = sorted(f for f in os.listdir(runner.CACHE) if f.startswith("mkv2-"))
warn = [n for n in xbmcgui.NOTES if "Letti" in n]
print("2. frasi:", n2, "| avviso:", warn[:1], "| cache:", cache, "| %.0f s" % (time.time() - t0))
ok2 = 0 < n2 < 40 and warn and all(".parziale." in f for f in cache if f.endswith(".srt")) and any(f.endswith(".pezzi.json") for f in cache)
# 3. il server torna a posto: la volta dopo rilegge e completa
FLAKY["dead"] = set()
xbmc.Player.subs.clear()
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
n3 = len([b for b in t.strip().split("\n\n") if b.strip()])
cache = sorted(f for f in os.listdir(runner.CACHE) if f.startswith("mkv2-"))
print("3. frasi:", n3, "| cache:", cache)
ok3 = n3 == 40 and any(".parziale." not in f for f in cache) and not any(f.endswith(".pezzi.json") for f in cache)
reread = [l for l in xbmc.LOG if "già lette l'altra volta" in l]
print("   rilette solo le mancanti:", reread[-1:])
ok3 = ok3 and reread and "ne leggo 8" in reread[-1]
print("ESITO:", bool(ok1 and ok2 and ok3))
srv.shutdown()

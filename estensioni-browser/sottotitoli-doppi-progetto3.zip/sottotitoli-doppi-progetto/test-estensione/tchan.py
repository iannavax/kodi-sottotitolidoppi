import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it'}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        for page in ["canaleA.html", "canaleB.html"]:
            n0 = len(log["groq"])
            pg = await ctx.new_page()
            await pg.goto(f"https://example.test/{page}"); await pg.wait_for_timeout(2500)
            fr = pg.frames[1]
            await fr.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(800)
            tid = await sw.evaluate(f"chrome.tabs.query({{}}).then(t=>t.find(x=>(x.url||'').includes('{page}')).id)")
            await sw.evaluate(f"chrome.tabs.sendMessage({tid}, {{type:'live', action:'start'}}).catch(e=>0)")
            await pg.wait_for_timeout(15000)
            st = await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)")
            keys = await sw.evaluate("chrome.storage.local.get(null).then(a=>Object.keys(a).filter(k=>k.startsWith('live:')))")
            print(f"{page}: Whisper {len(log['groq'])-n0} | stato: {st} | salvati: {keys}")
            await pg.wait_for_timeout(2500)
            await pg.close()
        await ctx.close()
asyncio.run(main())

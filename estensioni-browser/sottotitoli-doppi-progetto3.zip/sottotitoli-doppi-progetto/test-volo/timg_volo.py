# 1.10: immagine per Anki in Parole al Volo (scheda ‹ ›, invio come file) e parole del vocabolario sottolineate in celeste
import asyncio, os, sys, json, re
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
OTHER = ("https://tatoeba.org/", "https://api.tatoeba.org/", "https://api.languagetool.org/", "https://raw.githubusercontent.com/", "https://en.wikipedia.org/", "https://api.openverse.org/",
         "https://commons.wikimedia.org/", "https://upload.wikimedia.org/", "https://audio.tatoeba.org/")
async def handle(route, request):
    if request.url.startswith(OTHER) or re.match(r"https://[a-z-]+\.wiktionary\.org/", request.url): return await charness.handle(route, request)
    return await tvolo.handle(route, request)
IMG = "(document.querySelector('.pav-card .dsx-img')||{}).innerText||'(nessuna)'"
SAVED = "CSS.highlights.has('pav-saved') ? [...CSS.highlights.get('pav-saved')].map(r=>r.toString()) : []"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, ankiImage:true, ankiAuto:true, learnExamples:false, learnSpell:false, learnFreq:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/pagina.html"); await pg.wait_for_timeout(2500)
        print("0. sottolineate prima:", await pg.evaluate(SAVED))
        await tvolo.hover(pg, "en", "bread", 3500)
        print("1. scheda:", (await pg.evaluate(IMG)).replace("\n", " | "))
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.locator(".pav-card .dsx-img .dsx-btn", has_text="›").click(); await pg.wait_for_timeout(300)
        print("2. dopo ›:", (await pg.evaluate(IMG)).replace("\n", " | "), await pg.evaluate("(document.querySelector('.pav-card .dsx-imgthumb')||{}).src"))
        await pg.locator(".pav-card .pav-star").click(); await pg.wait_for_timeout(3000)
        add = [x[1]["note"] for x in tvolo.log.get("anki", []) if x[0] == "addNote"]
        pic = add[-1].get("picture") if add else None
        print("3. carta Anki:", pic and [{k: (v[:20] if isinstance(v, str) else v) for k, v in x.items()} for x in pic])
        print("   vocabolario:", await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab).map(e=>[e.word,e.image]))"))
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(1500)
        print("4. sottolineate dopo ☆:", await pg.evaluate(SAVED))
        await sw.evaluate("chrome.storage.local.get('vocab').then(r=>{for(const k in r.vocab) r.vocab[k].status='known'; return chrome.storage.local.set({vocab:r.vocab})})"); await pg.wait_for_timeout(1200)
        print("5. dopo 'imparata':", await pg.evaluate(SAVED))
        print("errori:", errs, tvolo.log["errors"], charness.log.get("errors"))
        await ctx.close()
asyncio.run(main())

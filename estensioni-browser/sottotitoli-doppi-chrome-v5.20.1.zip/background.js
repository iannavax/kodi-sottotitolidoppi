// Chiamate ai servizi esterni: traduzione, significati delle parole, trascrizione.
// In Chrome/Edge gira come service worker, in Firefox come script di background
// (lì config.js è già caricato dal manifest).
if (typeof DS_CONFIG === "undefined" && typeof importScripts === "function") importScripts("config.js");
const C = DS_CONFIG;

// Messaggi dall'altra estensione (Sottotitoli Doppi ↔ Parole al Volo): parole conosciute e vocabolario
if (chrome.runtime.onMessageExternal) chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== "dsSync") return false;
  dsSyncReceive(msg, sender).then((r) => sendResponse(r), (e) => sendResponse({ error: String((e && e.message) || e) }));
  return true;
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  let run;
  if (msg.type === "translate") run = translate(msg);
  else if (msg.type === "define") run = define(msg);
  else if (msg.type === "listModels") run = listModels(msg);
  else if (msg.type === "transcribe") run = transcribe(msg);
  else if (msg.type === "tts") run = tts(msg);
  else if (msg.type === "ankiAdd") run = ankiAdd(msg);
  else if (msg.type === "openFreq") run = (async () => { await DS_EXT.tabs.create({ url: DS_EXT.runtime.getURL("freq.html") + "?lang=" + encodeURIComponent(msg.lang || "") + "&word=" + encodeURIComponent(msg.word || "") + "&target=" + encodeURIComponent(msg.target || "it") + (msg.level ? "&level=" + encodeURIComponent(msg.level) : "") }); return {}; })();
  else if (msg.type === "openJlpt") run = (async () => { await DS_EXT.tabs.create({ url: DS_EXT.runtime.getURL("jlpt.html") + "?level=" + encodeURIComponent(msg.level || "N5") + "&word=" + encodeURIComponent(msg.word || "") + "&target=" + encodeURIComponent(msg.target || "it") }); return {}; })();
  else if (msg.type === "jlptList") run = jlptList(msg);
  else if (msg.type === "ankiCheck") run = ankiCheck(msg);
  else if (msg.type === "azureTts") run = azureTts(msg);
  else if (msg.type === "azureVoices") run = azureVoices(msg);
  else if (msg.type === "helperPing") run = helperPing();
  else if (msg.type === "align") run = align(msg);
  else if (msg.type === "wordBack") run = wordBack(msg);
  else if (msg.type === "cleanText") run = cleanText(msg);
  else if (msg.type === "ipa") run = ipa(msg);
  else if (msg.type === "etymPage") run = etymPage(msg);
  else if (msg.type === "fetchB64") run = fetchB64(msg);
  else if (msg.type === "tatoeba") run = tatoeba(msg);
  else if (msg.type === "jisho") run = jisho(msg);
  else if (msg.type === "hanChar") run = hanChar(msg);
  else if (msg.type === "langtool") run = langtool(msg);
  else if (msg.type === "freqList") run = freqList(msg);
  else if (msg.type === "commonsImage") run = commonsImage(msg);
  else if (msg.type === "imageSearch") run = imageSearch(msg);
  else if (msg.type === "romanLine") run = romanLine(msg);
  else if (msg.type === "idiomsFind") run = idiomsFind(msg);
  else if (msg.type === "etymLlm") run = etymLlm(msg);
  else return false;
  run.then(
    (res) => sendResponse(res),
    (err) => sendResponse({
      error: String((err && err.message) || err),
      rateLimited: !!(err && err.rateLimited),
      daily: !!(err && err.daily),
      fatal: !!(err && err.fatal),
      hourly: !!(err && err.hourly),
      tooLarge: !!(err && (err.tooLarge || err.tpm)),
      retryAfter: (err && err.retryAfter) || 0
    })
  );
  return true;
});

// ---------- Errori ----------
async function httpError(r, service) {
  const text = await r.text().catch(() => "");
  let detail = "";
  try {
    const j = JSON.parse(text);
    detail = (j.error && (j.error.message || j.error)) || j.message || "";
    if (Array.isArray(j) && j[0] && j[0].error) detail = j[0].error.message;
  } catch {}
  const e = new Error(`${service} ha risposto ${r.status}${detail ? ": " + String(detail).slice(0, 200) : ""}`);
  if (r.status === 429 || r.status === 503 || r.status === 529) {
    e.rateLimited = true;
    const header = Number(r.headers.get("retry-after"));
    const m = text.match(/"retryDelay"\s*:\s*"(\d+)/);
    e.retryAfter = header > 0 ? header : m ? Number(m[1]) : 0;
    // "Please try again in 22m45.5s" (Groq): quanto manca davvero
    const ta = text.match(/try again in\s+(?:(\d+)h)?\s*(?:(\d+)m)?\s*(?:([\d.]+)s)?/i);
    if (ta && (ta[1] || ta[2] || ta[3])) e.retryAfter = Math.max(e.retryAfter, (+ta[1] || 0) * 3600 + (+ta[2] || 0) * 60 + (+ta[3] || 0));
    if (/per hour|ASPH/i.test(text)) e.hourly = true;
    if (r.status === 429 && /PerDay|per_day|per day|RequestsPerDay|daily/i.test(text)) {
      e.daily = true;
      const lim = text.match(/Limit:?\s*(\d+)/i);
      e.message = `${service}: hai esaurito le richieste gratuite di oggi per questo modello.` + (lim ? ` (Limit ${lim[1]})` : "");
    }
  }
  if (r.status === 413 || /request too large|tokens per minute \(TPM\)/i.test(text)) {
    e.tooLarge = r.status === 413 || /request too large/i.test(text);
    if (/tokens per minute|TPM/i.test(text)) { e.rateLimited = true; e.tpm = true; }
  }
  if (r.status === 402 || /insufficient|credit balance|out of credits|organization_restricted/i.test(text)) {
    e.message = `${service}: credito o quota dell'account finiti. Controlla il tuo account (per Groq: console.groq.com).`;
    e.fatal = true; e.rateLimited = false;
  }
  if (r.status === 401 || r.status === 403) { e.message = `${service}: chiave non valida o senza permessi (${r.status}).`; e.fatal = true; }
  if (r.status === 404 && /model/i.test(text)) { e.message = `${service}: il modello scelto non esiste più. Nel popup premi "Carica modelli" e scegline un altro.`; e.fatal = true; }
  if (r.status === 456) e.message = "DeepL: hai esaurito i caratteri gratuiti di questo mese.";
  return e;
}

function cleanModelText(content) {
  return String(content || "").replace(/<think>[\s\S]*?<\/think>/g, "").replace(/```(?:json)?/g, "");
}

// Legge la risposta di un modello anche se è "sporca": JSON con testo intorno, JSON troncato,
// oppure righe numerate. Toglie i numeri "1. 2. 3." che alcuni modelli aggiungono.
function parseList(content, texts) {
  const n = texts.length;
  const s = cleanModelText(content);
  let arr = null, srcArr = null;
  const o1 = s.indexOf("{"), o2 = s.lastIndexOf("}");
  if (o1 >= 0 && o2 > o1) {
    try {
      const obj = JSON.parse(s.slice(o1, o2 + 1));
      arr = obj.t || obj.translations || obj.segments || Object.values(obj).find(Array.isArray) || null;
      if (Array.isArray(obj.src)) srcArr = obj.src;
    } catch {}
  }
  if (!arr) {
    const a1 = s.indexOf("["), a2 = s.lastIndexOf("]");
    if (a1 >= 0 && a2 > a1) { try { arr = JSON.parse(s.slice(a1, a2 + 1)); } catch {} }
  }
  if (!arr) {
    // JSON troncato o malformato: recupero le stringhe una per una
    const k = s.search(/"(t|translations)"\s*:\s*\[/);
    if (k >= 0) {
      arr = [];
      const re = /"((?:[^"\\]|\\.)*)"/g;
      re.lastIndex = s.indexOf("[", k) + 1;
      let m;
      while ((m = re.exec(s))) { try { arr.push(JSON.parse('"' + m[1] + '"')); } catch { arr.push(m[1]); } }
    }
  }
  if (!arr || !arr.length) {
    const lines = s.split("\n").map((l) => l.match(/^\s*(\d{1,3})[.)]\s+(.*)$/)).filter(Boolean);
    if (lines.length) arr = lines.map((m) => m[2]);
  }
  if (!Array.isArray(arr) || !arr.length) throw new Error("risposta del modello non leggibile");
  arr = arr.map((x) => (typeof x === "string" ? x : x && typeof x === "object" ? String(Object.values(x)[0] || "") : String(x ?? "")));
  const translations = Array.from({ length: n }, (_, i) => {
    let t = (arr[i] || "").trim();
    if (!/^\s*\d/.test(texts[i] || "")) t = t.replace(/^\s*\d{1,3}[.)]\s+/, "");
    return t.replace(/^["“](.*)["”]$/, "$1");
  });
  // pezzi volutamente vuoti in entrambe le versioni = "non è parlato", non uno sfasamento
  const removed = new Set(srcArr ? translations.map((t, i) => (!t && srcArr[i] != null && !String(srcArr[i]).trim() ? i : -1)).filter((i) => i >= 0) : []);
  const out = { translations, misaligned: arr.length !== n || badAlignment(texts.filter((_, i) => !removed.has(i)), translations.filter((_, i) => !removed.has(i))) };
  if (srcArr) {
    out.sources = Array.from({ length: n }, (_, i) => (srcArr[i] == null ? null : String(srcArr[i]).trim()));
    if (srcArr.length !== n) out.misaligned = true;
  }
  return out;
}

// Il modello a volte sposta la traduzione di una frase sotto quella accanto:
// me ne accorgo da traduzioni vuote o di lunghezza molto diversa dall'originale
function badAlignment(texts, translations) {
  if (texts.length < 2) return false;
  let bad = 0;
  texts.forEach((src, i) => {
    const t = translations[i] || "";
    const words = String(src).trim().split(/\s+/).length;
    if (words < 3) return;
    if (!t.trim()) bad++;
    else if (t.length > src.length * 2.6 + 25 || t.length < src.length * 0.3) bad++;
  });
  return bad > 0;
}

function parseObject(content) {
  const s = cleanModelText(content);
  const o1 = s.indexOf("{"), o2 = s.lastIndexOf("}");
  if (o1 < 0 || o2 <= o1) throw new Error("risposta del modello non leggibile");
  return JSON.parse(s.slice(o1, o2 + 1));
}

// ---------- Ritmo delle richieste ----------
// Ogni servizio gratuito accetta solo un certo numero di richieste al minuto. Tutte le richieste
// (traduzioni, significati, da qualsiasi scheda) passano da qui e vengono distanziate.
// Se il servizio risponde "troppe richieste", l'intervallo si allunga e poi torna piano piano normale.
const nextSlot = new Map();
const currentInterval = new Map();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const lastStart = new Map();

async function waitTurn(id, E, priority) {
  const base = E.minIntervalMs || 0;
  const interval = currentInterval.get(id) || base;
  if (!interval && !nextSlot.has(id)) return;
  const now = Date.now();
  if (priority) {
    // richiesta fatta da te (correzione di una frase): passa davanti alla fila,
    // rispettando solo la distanza dall'ultima richiesta partita
    const at = Math.max(now, (lastStart.get(id) || 0) + interval);
    if (at > now) await sleep(at - now);
    lastStart.set(id, Date.now());
    return;
  }
  const at = Math.max(now, nextSlot.get(id) || 0);
  nextSlot.set(id, at + interval);
  if (at > now) await sleep(at - now);
  lastStart.set(id, Date.now());
}

function rateLimitHit(id, E, err) {
  const base = E.minIntervalMs || 2000;
  currentInterval.set(id, Math.min(20000, (currentInterval.get(id) || base) * 1.5));
  nextSlot.set(id, Date.now() + Math.max(err.retryAfter || 0, 5) * 1000);
}

function requestOk(id, E) {
  const iv = currentInterval.get(id);
  if (iv) currentInterval.set(id, Math.max(E.minIntervalMs || 0, iv * 0.9));
}

async function paced(id, E, fn, priority) {
  await waitTurn(id, E, priority);
  try {
    const out = await fn();
    requestOk(id, E);
    return out;
  } catch (e) {
    if (e && e.rateLimited && !e.daily) rateLimitHit(id, E, e);
    throw e;
  }
}

// ---------- Modelli linguistici (compatibili OpenAI e Claude) ----------
function openaiBase(E, msg) {
  return (E.local ? msg.localUrl || C.SYNC_DEFAULTS.localUrl : E.base).trim().replace(/\/+$/, "");
}

function localError(base) {
  return new Error(
    `Non riesco a collegarmi al modello locale su ${base}. Controlla che Ollama o LM Studio sia avviato ` +
    `e che accetti le richieste dalle estensioni (vedi LEGGIMI).`
  );
}

const llmReady = (E, msg) =>
  (E.kind === "openai" || E.kind === "claude") && (!E.needsKey || !!msg.key) && !!(msg.model || E.defaultModel);

async function llmText(E, msg, system, user) {
  if (E.kind === "claude") {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": msg.key.trim(),
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model: msg.model || E.defaultModel, max_tokens: 8000, system,
        messages: [{ role: "user", content: user }]
      })
    });
    if (!r.ok) throw await httpError(r, "Claude");
    const data = await r.json();
    return (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
  }

  const base = openaiBase(E, msg);
  const model = msg.model || E.defaultModel;
  if (!model) throw new Error("scegli un modello nel popup (pulsante \"Carica modelli\")");
  const headers = { "Content-Type": "application/json" };
  if (msg.key) headers.Authorization = "Bearer " + msg.key.trim();
  const body = {
    model, temperature: 0.2, max_tokens: msg.maxTokens || E.maxTokens || 8192,
    messages: [{ role: "system", content: system }, { role: "user", content: user }],
    ...(E.extra || {})
  };
  const send = (b) => fetch(base + "/chat/completions", { method: "POST", headers, body: JSON.stringify(b) });
  let r;
  try { r = await send(body); } catch (e) { if (E.local) throw localError(base); throw e; }
  if (r.status === 400 && E.extra) {
    // alcuni modelli non accettano i parametri extra: riprovo senza
    const plain = { ...body };
    for (const k of Object.keys(E.extra)) delete plain[k];
    r = await send(plain);
  }
  if ((r.status === 413 || r.status === 429) && body.max_tokens > 3000) {
    const peek = await r.clone().text().catch(() => "");
    if (r.status === 413 || /request too large/i.test(peek)) r = await send({ ...body, max_tokens: 3000 });
  }
  if (E.local && r.status === 403) {
    throw new Error("Il modello locale rifiuta la richiesta: devi permettere le estensioni del browser (OLLAMA_ORIGINS, vedi LEGGIMI).");
  }
  if (!r.ok) throw await httpError(r, E.local ? "Il modello locale" : E.label.split(",")[0]);
  const data = await r.json();
  const m = (data.choices && data.choices[0] && data.choices[0].message) || {};
  return Array.isArray(m.content) ? m.content.map((p) => p.text || "").join("") : m.content;
}

// ---------- Traduzione ----------
async function translate(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E) throw new Error("servizio sconosciuto");
  if (E.needsKey && !msg.key) throw new Error("manca la chiave: inseriscila nel popup dell'estensione");
  if (E.kind === "google") return { translations: await translateGoogle(msg) };
  if (E.kind === "deepl") return { translations: await paced(msg.engine, E, () => translateDeepL(msg)) };
  if (E.kind === "microsoft") return { translations: await paced(msg.engine, E, () => translateMicrosoft(msg)) };
  if (E.kind === "openai" || E.kind === "claude") {
    const text = await paced(msg.engine, E, () =>
      llmText(E, msg, C.prompt(msg.target, msg.texts.length, !!msg.clean), C.userMessage(msg.texts, msg.before, msg.after)), !!msg.priority);
    return parseList(text, msg.texts);
  }
  throw new Error("servizio non supportato qui");
}

// Solo correzione della trascrizione (si traduce poi con Google o DeepL)
async function cleanText(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve un modello per correggere la trascrizione");
  const text = await paced(msg.engine, E, () =>
    llmText(E, msg, C.promptCleanOnly(msg.texts.length), C.userMessage(msg.texts, msg.before, msg.after)));
  const obj = parseObject(text);
  const arr = Array.isArray(obj.src) ? obj.src : Object.values(obj).find(Array.isArray);
  if (!Array.isArray(arr)) throw new Error("risposta del modello non leggibile");
  return { sources: msg.texts.map((_, i) => (arr[i] == null ? null : String(arr[i]).trim())), misaligned: arr.length !== msg.texts.length };
}

const googleLang = (l) => (l === "zh-Hans" ? "zh-CN" : l);

async function googleRequest(text, tl, extra = "") {
  const url = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t" + extra +
    "&tl=" + encodeURIComponent(tl) + "&q=" + encodeURIComponent(text) +
    (extra.includes("&sl=") ? "" : "&sl=auto");
  const r = await fetch(url);
  if (!r.ok) throw await httpError(r, "Google Traduttore");
  return r.json();
}
const googleText = (data) => (data[0] || []).map((p) => (p && p[0]) || "").join("");

// Dizionario di Google, nella stessa richiesta della traduzione (gratis): definizioni nella lingua originale,
// sinonimi, esempi, "vedi anche", "forse cercavi", traduzioni con il loro peso e le traduzioni al contrario.
// Google a volte lascia vuote alcune parti: quello che manca semplicemente non c'è.
const GOOGLE_DICT_DT = "&dt=bd&dt=md&dt=ss&dt=ex&dt=rw&dt=qca";
function googleDict(data) {
  const A = (x) => (Array.isArray(x) ? x : []);
  const str = (x) => (typeof x === "string" ? x : "");
  const strip = (x) => str(x).replace(/<[^>]+>/g, "").replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, "&").trim();
  const out = { alt: [], defs: [], syn: [], examples: [], related: [], didYouMean: "" };
  try {
    for (const e of A(data[1]).slice(0, 4)) {
      const items = A(e[2]).slice(0, 6).map((x) => ({ word: str(x[0]), rev: A(x[1]).slice(0, 5).map(str).filter(Boolean), score: typeof x[3] === "number" ? x[3] : 0 })).filter((x) => x.word);
      if (items.length) out.alt.push({ pos: str(e[0]), items });
    }
    for (const e of A(data[12]).slice(0, 3)) {
      const items = A(e[1]).slice(0, 3).map((x) => ({ def: strip(x[0]), ex: strip(x[2]) })).filter((x) => x.def);
      if (items.length) out.defs.push({ pos: str(e[0]), items });
    }
    for (const e of A(data[11]).slice(0, 3)) {
      const words = [];
      for (const g of A(e[1])) for (const w of A(g[0])) if (typeof w === "string" && !words.includes(w)) words.push(w);
      if (words.length) out.syn.push({ pos: str(e[0]), words: words.slice(0, 10) });
    }
    out.examples = A(A(data[13])[0]).slice(0, 3).map((x) => strip(A(x)[0])).filter(Boolean);
    out.related = A(A(data[14])[0]).slice(0, 8).map(str).filter(Boolean);
    const q = A(data[7]);
    if (str(q[1])) out.didYouMean = strip(q[1]);
  } catch {}
  return out;
}

function googleSource(source, target) {
  const b = String(source || "").split("-")[0].toLowerCase();
  if (!b || b === String(target).split("-")[0].toLowerCase()) return "";
  return "&sl=" + encodeURIComponent(b === "zh" ? "zh-CN" : b === "jw" ? "jv" : b);
}

async function translateGoogle({ texts, target, source }) {
  const tl = googleLang(target);
  const sl = googleSource(source, target);
  const lines = googleText(await googleRequest(texts.join("\n"), tl, sl)).split("\n").map((s) => s.trim());
  if (lines.length === texts.length) return lines;
  const out = [];
  for (const t of texts) out.push(googleText(await googleRequest(t, tl, sl)).trim());
  return out;
}

async function translateDeepL({ texts, target, before = [], after = [], key }) {
  const host = key.trim().endsWith(":fx") ? "https://api-free.deepl.com" : "https://api.deepl.com";
  const map = { en: "EN-US", pt: "PT-BR", "zh-Hans": "ZH-HANS" };
  const body = { text: texts, target_lang: map[target] || target.toUpperCase() };
  const context = [...before, ...after].join("\n");
  if (context) body.context = context;
  const r = await fetch(host + "/v2/translate", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "DeepL-Auth-Key " + key.trim() },
    body: JSON.stringify(body)
  });
  if (!r.ok) throw await httpError(r, "DeepL");
  const data = await r.json();
  return texts.map((_, i) => ((data.translations || [])[i] || {}).text || "");
}

// Microsoft Translator (Azure, piano F0 gratuito): fino a 100 frasi per richiesta
async function translateMicrosoft({ texts, target, source, key, region }) {
  if (!region) region = (await DS_EXT.storage.sync.get({ msRegion: "" })).msRegion || "";
  const ms = (l) => ({ "zh-Hans": "zh-Hans", zh: "zh-Hans", he: "he", no: "nb", tl: "fil" }[l] || String(l || "").split("-")[0]);
  const from = source && ms(source) !== ms(target) ? "&from=" + encodeURIComponent(ms(source)) : "";
  const headers = { "Content-Type": "application/json", "Ocp-Apim-Subscription-Key": String(key || "").trim() };
  if (region && region.trim()) headers["Ocp-Apim-Subscription-Region"] = region.trim();
  const r = await fetch("https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=" + encodeURIComponent(ms(target)) + from, {
    method: "POST", headers, body: JSON.stringify(texts.map((t) => ({ Text: t })))
  });
  if (!r.ok) {
    const e = await httpError(r, "Microsoft Translator");
    if (r.status === 403 || /quota/i.test(e.message)) { e.daily = true; e.rateLimited = true; e.message = "Microsoft Translator: hai esaurito i caratteri gratuiti di questo mese."; }
    if (r.status === 401) e.message = "Microsoft Translator: chiave o area sbagliata (controlla anche l'area, per esempio westeurope).";
    throw e;
  }
  const data = await r.json();
  return texts.map((_, i) => (((data[i] || {}).translations || [])[0] || {}).text || "");
}

// ---------- Significato di una parola nel suo contesto ----------
// un campo di testo del modello: vuoto se è un "niente" scritto a parole (false, none, null, n/a, -, nessuno…)
function llmField(v) {
  if (v == null || v === false || v === true) return "";
  const t = String(Array.isArray(v) ? v.filter(Boolean).join(", ") : v).trim();
  return /^(false|true|none|null|nil|n\/?a|no|non|nessun[oa]?|niente|empty|vuoto|-+|—|\.+|undefined)\.?$/i.test(t) ? "" : t;
}

// Nome inglese di una lingua dalla sigla (per i prompt)
function langNameEn(code) {
  const b = String(code || "").split("-")[0];
  if (!b) return "";
  if (C.LANG_EN[code]) return C.LANG_EN[code];
  try { return new Intl.DisplayNames(["en"], { type: "language" }).of(b) || ""; } catch { return ""; }
}
// Alfabeto atteso per la lingua di arrivo; le parti in un altro alfabeto sono in un'altra lingua
const SCRIPT_OF = { ru: "Cyrillic", uk: "Cyrillic", bg: "Cyrillic", sr: "Cyrillic", mk: "Cyrillic", be: "Cyrillic", kk: "Cyrillic",
  ar: "Arabic", fa: "Arabic", ur: "Arabic", he: "Hebrew", el: "Greek", hi: "Devanagari", mr: "Devanagari", ne: "Devanagari",
  th: "Thai", ko: "Hangul", ja: "Han|Hiragana|Katakana", zh: "Han", ka: "Georgian", hy: "Armenian", bn: "Bengali", ta: "Tamil" };
function wrongScript(text, target) {
  // le parole citate (tra parentesi o virgolette) possono essere nella lingua originale: non le conto
  const t = String(text || "").replace(/\([^)]*\)|«[^»]*»|"[^"]*"|“[^”]*”|'[^']*'/g, " ");
  const letters = t.match(/\p{L}/gu) || [];
  if (letters.length < 3) return false;
  const want = SCRIPT_OF[String(target || "").split("-")[0].toLowerCase()] || "Latin";
  const re = new RegExp("[" + want.split("|").map((x) => "\\p{Script=" + x + "}").join("") + "]", "u");
  const ok = letters.filter((ch) => re.test(ch)).length;
  return ok / letters.length < 0.6;
}
// Quali campi della risposta del modello sono sbagliati
function defineProblems(o, msg) {
  const bad = [];
  const norm = (x) => String(x || "").toLowerCase().normalize("NFD").replace(/\p{M}/gu, "").replace(/[^\p{L}\p{N}]/gu, "");
  const m = String(o.meaning || "");
  // significato vuoto, o in un altro alfabeto (per esempio la parola russa ricopiata così com'è). Una parola uguale
  // nello stesso alfabeto può essere giusta (computer, weekend…): quella la lascio
  if (!m.trim() || wrongScript(m, msg.target)) bad.push("meaning");
  void norm;
  for (const f of ["explanation", "expression_meaning", "example_translation", "pos"]) if (o[f] && wrongScript(o[f], msg.target)) bad.push(f);
  return bad;
}

async function define(msg) {
  const E = C.ENGINES[msg.engine] || C.ENGINES.google;
  let llmError = "";
  if (llmReady(E, msg)) {
    try {
      const user = `${/\s/.test(String(msg.word).trim()) ? "Expression" : "Word"}: "${msg.word}"\nSentence: "${msg.sentence}"` +
        (msg.sentenceTrans ? `\nSentence translation: "${msg.sentenceTrans}"` : "");
      // una risposta breve: poche migliaia di token bastano (Groq conta max_tokens nel limite al minuto:
      // con 8192 la richiesta veniva rifiutata come "troppo grande" e la spiegazione non arrivava)
      const dm = { ...msg, maxTokens: msg.engine === "gemini" ? 4096 : 2500 };
      const system = C.definePrompt(msg.target, msg.lang, { etym: !!msg.etym, ipa: msg.ipa !== false, extra: !!msg.extra, sentence: !!msg.sentFix && /\s/.test(String(msg.sentence || "").trim()) });
      let text;
      try { text = await paced(msg.engine, E, () => llmText(E, dm, system, user), true); }
      catch (e) { if (!e.tooLarge) throw e; text = await paced(msg.engine, E, () => llmText(E, { ...dm, maxTokens: 1200 }, system, user), true); }
      let o;
      try { o = parseObject(text); }
      catch { o = parseObject(await paced(msg.engine, E, () => llmText(E, { ...dm, maxTokens: 3500 }, system, user), true)); }   // risposta tagliata: riprovo una volta
      // Controllo della risposta: a volte (soprattutto con i modelli piccoli) il "significato" è la parola stessa
      // non tradotta, o la spiegazione è in un'altra lingua (per esempio in arabo per una parola russa).
      // Riprovo una volta con istruzioni più rigide; se è ancora sbagliata, quelle parti le tolgo e il
      // significato lo prende Google.
      let bad = defineProblems(o, msg);
      if (bad.length) {
        const tName = C.LANG_EN[msg.target] || langNameEn(msg.target) || msg.target;
        const strict = system + ` IMPORTANT: "meaning", "explanation", "pos", "expression_meaning", "example_translation" MUST be written in ${tName} only` +
          ` (never in another language)${msg.lang ? `; the word is ${langNameEn(msg.lang) || msg.lang}: TRANSLATE it into ${tName}, do not copy it` : ""}.`;
        try {
          const o2 = parseObject(await paced(msg.engine, E, () => llmText(E, dm, strict, user), true));
          const bad2 = defineProblems(o2, msg);
          if (bad2.length < bad.length) { o = o2; bad = bad2; }
        } catch {}
      }
      let fixedByGoogle = false;
      if (bad.length) {
        for (const f of bad) o[f] = "";
        if (bad.includes("meaning")) {
          try {
            const g = await googleRequest(msg.word, googleLang(msg.target), googleSource(msg.lang, msg.target) || "&sl=auto");
            o.meaning = googleText(g); fixedByGoogle = true;
          } catch {}
        }
      }
      return {
        checkNote: bad.length ? "Una parte della risposta era sbagliata (lingua o parola non tradotta): " + (fixedByGoogle ? "il significato è di Google." : "tolta.") : "",
        source: E.label.split(" (")[0].split(",")[0],
        lemma: String(o.lemma || ""), pos: String(o.pos || ""), meaning: String(o.meaning || ""),
        explanation: String(o.explanation || ""), example: String(o.example || ""),
        exampleTrans: String(o.example_translation || ""), lang: String(o.lang || msg.lang || ""),
        expression: llmField(o.expression), expressionMeaning: llmField(o.expression_meaning),
        ipa: String(o.ipa || "").replace(/^[\s\/\[]+|[\s\/\]]+$/g, ""),
        etymology: llmField(o.etymology),
        // il modello a volte scrive "false", "none", "N/A"… invece di lasciare vuoto: compariva "⚠ false"
        falseFriend: llmField(o.false_friend), related: llmField(o.related),
        sentenceTrans: llmField(o.sentence_translation),
        spelling: o.spelling && typeof o.spelling === "object" ? { score: Number(o.spelling.score), correct: String(o.spelling.correct || ""), note: String(o.spelling.note || "") } : null
      };
    } catch (e) {
      // ripiego su Google qui sotto
      llmError = e && e.daily ? "richieste gratuite di oggi esaurite" : e && e.rateLimited ? "troppe richieste in questo momento" :
        "non ha risposto" + (e && e.message ? " — " + String(e.message).replace(/^[^:]*ha risposto\s*/, "").slice(0, 160) : "");
    }
  }
  const tl = googleLang(msg.target);
  const same = (d) => googleText(d).trim().toLowerCase() === String(msg.word).trim().toLowerCase();
  const sl = googleSource(msg.lang, msg.target);
  let data = await googleRequest(msg.word, tl, GOOGLE_DICT_DT + "&dt=rm&hl=" + encodeURIComponent(tl) + sl);
  if (same(data) && !(Array.isArray(data[1]) && data[1].length)) {
    // la lingua indicata forse è sbagliata: lascio decidere a Google
    const retry = await googleRequest(msg.word, tl, GOOGLE_DICT_DT + "&dt=rm&hl=" + encodeURIComponent(tl) + (sl ? "&sl=auto" : ""));
    if (!same(retry) || (Array.isArray(retry[1]) && retry[1].length)) data = retry;
  }
  const entries = Array.isArray(data[1]) ? data[1] : [];
  const untranslated = same(data) && !entries.length;
  return {
    source: "Google Traduttore" + (llmError ? ` (${E.label.split(" (")[0].split(",")[0]}: ${llmError})` : ""),
    fallback: !!llmError, llmDaily: llmError === "richieste gratuite di oggi esaurite",
    lemma: "", pos: entries[0] ? String(entries[0][0] || "") : "",
    meaning: untranslated ? "" : googleText(data),
    untranslated,
    explanation: entries.slice(0, 3).map((e) => `${e[0]}: ${(e[1] || []).slice(0, 5).join(", ")}`).join(" · "),
    example: "", exampleTrans: "",
    lang: msg.lang || (typeof data[2] === "string" ? data[2] : ""),
    gdict: googleDict(data),
    // trascrizione in caratteri latini (alfabeti diversi: кошка → koshka), gratis
    translit: (() => { let t = ""; for (const p of data[0] || []) if (p && p[0] == null && p[1] == null && typeof p[3] === "string") t += p[3];
      t = t.trim(); return t && t.toLowerCase() !== String(msg.word).toLowerCase() && /[^\p{Script=Latin}\p{Script=Common}\p{Script=Inherited}\s]/u.test(msg.word) ? t : ""; })()
  };
}

// ---------- Pronuncia IPA di più parole in una richiesta (le parole già note non vengono mai richieste) ----------
async function ipa(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve una chiave di Gemini o Groq");
  const words = (Array.isArray(msg.words) ? msg.words : []).map(String).filter(Boolean).slice(0, 400);
  if (!words.length) return { ipa: {} };
  // a pezzi: Gemini ha molti token al minuto, Groq pochi (12000 al minuto per llama-3.3-70b, compresa la risposta
  // massima prenotata): con 300 parole e max_tokens 8192 la richiesta era "troppo grande" e non passava mai
  const size = msg.engine === "gemini" ? 200 : 80;
  const out = {};
  const queue = [];
  for (let i = 0; i < words.length; i += size) queue.push(words.slice(i, i + size));
  while (queue.length) {
    const part = queue.shift();
    try {
      Object.assign(out, await ipaPart(E, msg, part));
    } catch (e) {
      // troppo grande per il limite al minuto: divido a metà e riprovo (non oltre 10 parole)
      if (e && (e.tooLarge || e.tpm) && part.length > 10) { const h = Math.ceil(part.length / 2); queue.unshift(part.slice(0, h), part.slice(h)); continue; }
      if (Object.keys(out).length) break;   // quello che è arrivato lo tengo
      throw e;
    }
  }
  return { ipa: out };
}

async function ipaPart(E, msg, words) {
  const lang = String(msg.lang || "").split("-")[0];
  // per cinese, giapponese e coreano la lettura dipende dalla frase (kanji con più letture): la mando sempre
  const withSentence = !lang || /^(ja|zh|ko)$/.test(lang);
  const user = JSON.stringify(withSentence && msg.sentence ? { sentence: String(msg.sentence).slice(0, 400), words } : { words });
  // risposta massima su misura (circa 14 token per parola): prenota meno token al minuto
  const m = { ...msg, maxTokens: Math.min(E.maxTokens || 8192, 300 + words.length * 16) };
  const obj = parseObject(await paced(msg.engine, E, () => llmText(E, m, C.ipaPrompt(lang), user), !!msg.priority));
  let src = obj && obj.ipa != null ? obj.ipa : obj || {};
  const clean = (v) => String(v || "").trim().replace(/^[\/\[]+|[\/\]]+$/g, "").trim();
  const out = {};
  // anche in forma di elenco: ["ipa", …] oppure [{"word": …, "ipa": …}, …]
  if (Array.isArray(src)) {
    if (src.every((x) => typeof x === "string")) { if (src.length === words.length) words.forEach((w, i) => { if (src[i]) out[w] = clean(src[i]); }); return out; }
    const o = {};
    for (const x of src) if (x && typeof x === "object") o[String(x.word || x.w || x.text || "")] = x.ipa || x.pronunciation || x.p || "";
    src = o;
  }
  const norm = (k) => String(k || "").normalize("NFKC").toLowerCase().trim();
  const low = new Map(Object.keys(src).map((k) => [norm(k), src[k]]));
  for (const w of words) {
    const v = src[w] != null ? src[w] : low.get(norm(w));
    if (typeof v === "string" && clean(v)) out[w] = clean(v);
  }
  // il modello ha cambiato le chiavi (per esempio le ha scritte in kana o in caratteri latini) ma ha risposto a tutte,
  // nello stesso ordine: le abbino per posizione
  const vals = Object.values(src).filter((v) => typeof v === "string");
  if (Object.keys(out).length < words.length * 0.6 && vals.length === words.length) words.forEach((w, i) => { if (!out[w] && clean(vals[i])) out[w] = clean(vals[i]); });
  return out;
}

// ---------- Etimologia ----------
// La pagina della parola su Wiktionary (gratis, senza chiave): la leggo qui e la pagina estrae la sezione giusta
async function etymPage(msg) {
  const title = String(msg.word || "").trim();
  if (!title) return { html: "" };
  // site: l'edizione di Wiktionary (en di solito; anche quella nella lingua della parola, per la pronuncia)
  const site = /^[a-z]{2,3}(-[a-z]{2,8})*$|^simple$/.test(String(msg.site || "")) ? msg.site : "en";
  const url = `https://${site}.wiktionary.org/w/api.php?action=parse&format=json&formatversion=2&prop=text&redirects=1&origin=*&page=` + encodeURIComponent(title);
  const r = await fetch(url, { headers: { "Api-User-Agent": "SottotitoliDoppi/5.9 (estensione per imparare le lingue)" } });
  if (!r.ok) throw new Error("Wiktionary" + (site !== "en" ? " (" + site + ")" : "") + " ha risposto " + r.status);
  const j = await r.json();
  if (j.error) return { html: "", missing: true };
  return { html: (j.parse && j.parse.text) || "", title: (j.parse && j.parse.title) || title };
}

// Le parole di un livello JLPT (Jisho, gratis): 20 per pagina, salvate per non richiederle
const jlptCache = new Map();
async function jlptList(msg) {
  const level = String(msg.level || "N5").toLowerCase().replace(/[^n1-5]/g, "");
  const page = Math.max(1, Math.min(200, parseInt(msg.page, 10) || 1));
  const k = level + "|" + page;
  if (jlptCache.has(k)) return jlptCache.get(k);
  const r = await fetch("https://jisho.org/api/v1/search/words?keyword=" + encodeURIComponent("#jlpt-" + level) + "&page=" + page);
  if (!r.ok) throw new Error("Jisho ha risposto " + r.status);
  const j = await r.json();
  const items = (j.data || []).map((d) => ({
    word: String((d.japanese && d.japanese[0] && (d.japanese[0].word || d.japanese[0].reading)) || d.slug || ""),
    reading: String((d.japanese && d.japanese[0] && d.japanese[0].reading) || ""),
    common: !!d.is_common,
    meanings: ((d.senses && d.senses[0] && d.senses[0].english_definitions) || []).slice(0, 4).map(String),
    pos: ((d.senses && d.senses[0] && d.senses[0].parts_of_speech) || []).slice(0, 2).map(String)
  })).filter((x) => x.word);
  const out = { items, more: items.length >= 20 };
  jlptCache.set(k, out);
  while (jlptCache.size > 300) jlptCache.delete(jlptCache.keys().next().value);
  return out;
}

// Dizionario giapponese Jisho (gratis): lettura in kana, livello JLPT, parola comune, significati in inglese
async function jisho(msg) {
  const w = String(msg.word || "").trim();
  if (!w) return { items: [] };
  const r = await fetch("https://jisho.org/api/v1/search/words?keyword=" + encodeURIComponent(w));
  if (!r.ok) throw new Error("Jisho ha risposto " + r.status);
  const j = await r.json();
  const items = (j.data || []).slice(0, 5).map((d) => ({
    word: String((d.japanese && d.japanese[0] && (d.japanese[0].word || d.japanese[0].reading)) || d.slug || ""),
    reading: String((d.japanese && d.japanese[0] && d.japanese[0].reading) || ""),
    common: !!d.is_common, jlpt: (d.jlpt || []).map((x) => String(x).replace(/^jlpt-/i, "").toUpperCase()).sort().reverse(),
    meanings: ((d.senses && d.senses[0] && d.senses[0].english_definitions) || []).slice(0, 4).map(String),
    pos: ((d.senses && d.senses[0] && d.senses[0].parts_of_speech) || []).slice(0, 2).map(String)
  }));
  // prima la voce scritta esattamente così (o con quella lettura)
  items.sort((a, b) => ((b.word === w || b.reading === w) - (a.word === w || a.reading === w)));
  return { items };
}

// Un kanji o un carattere cinese da solo (gratis, senza chiavi): per imparare i caratteri uno per uno.
// I dati sono dentro l'estensione (han-data.json, uguali per giapponese, cinese, coreano e vietnamita: Unihan di
// Unicode, parti di BabelStone, KANJIDIC, HSK 3.0, lista ufficiale cinese dei caratteri comuni; si rifà con
// tools/crea_han_data.py). Google (gratis) dà il significato del carattere da solo nella tua lingua e traduce le
// definizioni inglesi. Risposta: { ch, found, def, defTr, jm, jmTr, py, yue, on, kun, ko, vi, strokes, radical, parts,
// jlpt, grade, freq, hsk, tg, koe, joyo, sv, tv, meaning, alt, reading, sources }
let hanData = null;
async function hanDataLoad() {
  if (!hanData) hanData = fetch(DS_EXT.runtime.getURL("han-data.json")).then((r) => r.json()).catch(() => { hanData = null; return null; });
  return hanData;
}
const hanCache = new Map();
async function hanChar(msg) {
  const ch = Array.from(String(msg.ch || "").trim())[0] || "";
  if (!ch) return { error: "nessun carattere" };
  const lang = String(msg.lang || "").split("-")[0], tgt = String(msg.target || "it"), target = tgt.split("-")[0];
  const k = [ch, lang, target].join("|");
  if (hanCache.has(k)) return hanCache.get(k);
  const D = await hanDataLoad();
  const e = (D && D.c && D.c[ch]) || null;
  const out = { ch, found: !!e, meaning: "", alt: [], reading: "", sources: [] };
  if (e) {
    Object.assign(out, { def: e.d || "", jm: e.jm || "", py: e.py || "", yue: e.yue || "", on: [...new Set(e.on || [])], kun: [...new Set(e.kun || [])],
      ko: e.ko || "", vi: e.vi || "", strokes: e.s || 0, jlpt: e.jlpt || 0, grade: e.g || 0, freq: e.f || 0, hsk: e.hsk || 0, tg: e.tg || 0,
      koe: !!e.koe, joyo: !!e.joyo, sv: e.sv || "", tv: e.tv || "" });
    // radicale: "39.5" = radicale 39 più 5 tratti ("'" = forma semplificata del radicale)
    const rm = /^(\d+'*)\.(\d+)/.exec(e.r || "");
    const rd = rm && D.rad && D.rad[rm[1]];
    if (rd) out.radical = { n: parseInt(rm[1], 10), ch: rd[0], def: rd[1], extra: parseInt(rm[2], 10) };
    // parti (scomposizione): solo quelle che sono caratteri con un significato
    const parts = [...new Set(Array.from(String(e.p || "").replace(/[\u2ff0-\u2fff\u31ef]/g, "")))].filter((x) => x !== ch && D.c[x] && D.c[x].d);
    out.parts = parts.slice(0, 5).map((x) => ({ ch: x, def: D.c[x].d.split(/[;,]/)[0].trim(), py: D.c[x].py || "" }));
    out.sources.push("Unihan" + (e.jlpt || e.g || e.jm ? ", KANJIDIC" : "") + (e.hsk ? ", HSK 3.0" : ""));
  }
  const jobs = [];
  // definizioni nella tua lingua (una richiesta a Google per tutte)
  if (e && target !== "en") {
    const texts = [out.def, out.jm, out.radical ? out.radical.def : "", ...(out.parts || []).map((x) => x.def)];
    const idx = texts.map((t, i) => (t ? i : -1)).filter((i) => i >= 0);
    if (idx.length) jobs.push(translateGoogle({ texts: idx.map((i) => texts[i]), target: tgt, source: "en" }).then((tr) => {
      const got = {}; idx.forEach((i, j) => { got[i] = (tr[j] || "").trim(); });
      if (got[0]) out.defTr = got[0];
      if (got[1]) out.jmTr = got[1];
      if (got[2] && out.radical) out.radical.defTr = got[2];
      (out.parts || []).forEach((x, j) => { if (got[3 + j]) x.defTr = got[3 + j]; });
    }).catch(() => {}));
  }
  jobs.push((async () => {
    const sl = "&sl=" + encodeURIComponent(lang === "zh" ? "zh-CN" : lang || "auto");
    const data = await googleRequest(ch, googleLang(tgt), "&dt=rm&dt=bd" + sl);
    out.meaning = googleText(data).trim();
    if (out.meaning === ch) out.meaning = "";
    for (const p of data[0] || []) if (p && p[0] == null && p[1] == null && typeof p[3] === "string") out.reading += p[3];
    out.reading = out.reading.trim();
    for (const x of (Array.isArray(data[1]) ? data[1] : []).slice(0, 3))
      for (const w of (Array.isArray(x[1]) ? x[1] : []).slice(0, 4)) if (typeof w === "string" && !out.alt.includes(w) && w !== out.meaning) out.alt.push(w);
    out.alt = out.alt.slice(0, 6);
    out.sources.unshift("Google");
  })().catch(() => {}));
  await Promise.all(jobs);
  if (!out.sources.length) return { ch, error: "carattere non trovato e Google non ha risposto" };
  hanCache.set(k, out);
  while (hanCache.size > 500) hanCache.delete(hanCache.keys().next().value);
  return out;
}

// ---------- Strumenti per imparare (gratis, senza chiavi) ----------
// Audio registrato (Wiktionary/Commons, Tatoeba): lo scarico qui, la pagina lo suona (così la protezione del sito non lo blocca)
async function fetchB64(msg) {
  const url = String(msg.url || "");
  if (!/^https:\/\/(upload\.wikimedia\.org|commons\.wikimedia\.org\/wiki\/Special:FilePath|audio\.tatoeba\.org|tatoeba\.org|api\.tatoeba\.org)\//.test(url)) throw new Error("indirizzo non permesso");
  const r = await fetch(url);
  if (!r.ok) throw new Error("audio non disponibile (" + r.status + ")");
  const bytes = new Uint8Array(await r.arrayBuffer());
  if (bytes.length > 4 * 1024 * 1024) throw new Error("audio troppo grande");
  return { b64: bytesToB64(bytes), type: r.headers.get("content-type") || "" };
}

// Frasi d'esempio vere (Tatoeba), con traduzione e, se c'è, la registrazione di un madrelingua
async function tatoeba(msg) {
  const l3 = C.LANG3[String(msg.lang || "").split("-")[0]] || "", t3 = C.LANG3[String(msg.target || "").split("-")[0]] || "";
  if (!l3) return { items: [] };
  const word = String(msg.word || "").trim();
  const norm = (x) => String(x || "").toLowerCase();
  const flat = (tr) => (Array.isArray(tr) ? tr.flat(2) : []).filter((x) => x && typeof x === "object");
  const pickTrans = (tr) => { const all = flat(tr); const t = all.find((x) => x.lang === t3) || null; return t ? String(t.text || "") : ""; };
  const audioOf = (s) => {
    const out = [];
    for (const a of s.audios || []) {
      if (!a) continue;
      if (a.download_url) out.push(/^https?:/.test(a.download_url) ? a.download_url : "https://tatoeba.org" + (a.download_url.startsWith("/") ? "" : "/") + a.download_url);
      if (a.id) out.push("https://api.tatoeba.org/v1/audio/" + a.id + "/file", "https://tatoeba.org/en/audio/download/" + a.id);
      if (out.length) break;
    }
    return [...new Set(out)];
  };
  const q = encodeURIComponent(word.replace(/[()|!@~"\/^$<=*\[\]-]+/g, " ").trim());
  // API ufficiale (v1): prima le frasi registrate da un madrelingua, poi le altre per arrivare a 3.
  // Il vecchio indirizzo del sito (api_v0) solo se la v1 non risponde.
  const v1 = `https://api.tatoeba.org/v1/sentences?lang=${l3}&q=${q}&sort=relevance&limit=20&include=audios` + (t3 ? `&showtrans:lang=${t3}` : "");
  const v0 = `https://tatoeba.org/en/api_v0/search?from=${l3}&query=${q}&orphans=no&unapproved=no&sort=relevance` + (t3 ? `&to=${t3}` : "");
  const groups = [[v1 + "&has_audio=yes", v1], [v0 + "&has_audio=yes", v0]];
  let lastErr = "", ok = 0, via = "";
  const seen = new Set(), list = [];
  const w = norm(word), stem = w.length > 4 ? w.slice(0, Math.max(3, w.length - 3)) : w;
  const good = () => list.filter((s) => String(s.text).length <= 140 && norm(s.text).includes(stem)).length;
  for (const urls of groups) {
    if (ok) break;
    for (const u of urls) {
      if (good() >= 3) break;
      try {
        const r = await fetch(u, { headers: { Accept: "application/json" } });
        if (!r.ok) { lastErr = "Tatoeba ha risposto " + r.status; continue; }
        const j = await r.json();
        ok++; via = via || (u.includes("/v1/") ? "v1" : "v0");
        const got = Array.isArray(j.data) ? j.data : Array.isArray(j.results) ? j.results : [];
        for (const x of got) if (x && x.text && !seen.has(x.id || x.text)) { seen.add(x.id || x.text); list.push(x); }
      } catch (e) { lastErr = String(e.message || e); }
    }
  }
  if (!list.length && lastErr && !ok) throw new Error(lastErr);
  // la parola esatta prima, ma vanno bene anche le forme flesse trovate da Tatoeba (кошка → кошку)
  const items = list
    .filter((s) => String(s.text).length <= 140 && norm(s.text).includes(stem))
    .map((s) => { const au = audioOf(s); return { text: String(s.text), trans: pickTrans(s.translations), audio: au[0] || "", audioAlt: au.slice(1), exact: norm(s.text).includes(w) }; })
    .sort((a, b) => (!!b.audio - !!a.audio) || (b.exact - a.exact) || (!!b.trans - !!a.trans) || a.text.length - b.text.length)
    .slice(0, 3);
  // senza traduzione nella tua lingua: Google
  const miss = items.filter((x) => !x.trans);
  if (miss.length && msg.target) {
    try { const tr = await translateGoogle({ texts: miss.map((x) => x.text), target: msg.target, source: msg.lang }); miss.forEach((x, i) => { x.trans = tr[i] || ""; x.google = true; }); } catch {}
  }
  return { items, via, err: lastErr };
}

// Controllo dell'ortografia e della grammatica della frase (LanguageTool, gratis, circa 20 richieste al minuto)
async function langtool(msg) {
  const b = String(msg.lang || "").split("-")[0];
  const code = C.LT_LANGS[b];
  if (!code) return { unsupported: true };
  const body = new URLSearchParams({ text: String(msg.text || "").slice(0, 1500), language: code });
  const r = await fetch("https://api.languagetool.org/v2/check", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
  if (!r.ok) throw await httpError(r, "LanguageTool");
  const j = await r.json();
  return { matches: (j.matches || []).slice(0, 20).map((m) => ({ offset: m.offset, length: m.length, message: String(m.message || ""),
    short: String(m.shortMessage || ""), repl: (m.replacements || []).slice(0, 3).map((x) => x.value), type: (m.rule && m.rule.issueType) || "" })) };
}

// Elenco delle parole più usate in una lingua (dai sottotitoli dei film, progetto FrequencyWords, licenza libera)
async function freqList(msg) {
  const b = String(msg.lang || "").split("-")[0];
  const folder = { zh: "zh_cn", pt: "pt", no: "no", nb: "no" }[b] || b;
  const url = `https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/${folder}/${folder}_50k.txt`;
  const r = await fetch(url);
  if (!r.ok) throw new Error("elenco delle frequenze non disponibile per questa lingua (" + r.status + ")");
  const text = await r.text();
  const words = [];
  for (const line of text.split("\n")) {
    const w = line.split(" ")[0].trim().toLowerCase();
    if (w) words.push(w);
    if (words.length >= 30000) break;
  }
  return { list: words.join("\n") };
}

// Un'immagine per la parola (Wikimedia Commons), cercata con la traduzione inglese: solo per le carte di Anki
// Lettura in lettere latine di una riga con kanji o caratteri cinesi (Google, gratis, nessun token): i kanji
// hanno più letture e una tabella non basta. Una richiesta per riga, salvata.
const romanCache = new Map();
async function romanLine(msg) {
  const text = String(msg.text || "").slice(0, 600);
  if (!text.trim()) return { text: "" };
  const k = (msg.lang || "") + "|" + text;
  if (romanCache.has(k)) return { text: romanCache.get(k) };
  const sl = msg.lang ? "&sl=" + encodeURIComponent(String(msg.lang).split("-")[0] === "zh" ? "zh-CN" : String(msg.lang).split("-")[0]) : "";
  const data = await googleRequest(text, "en", "&dt=rm" + sl);
  let t = "";
  for (const p of data[0] || []) if (p && p[0] == null && p[1] == null && typeof p[3] === "string") t += p[3];
  t = t.trim();
  romanCache.set(k, t);
  while (romanCache.size > 400) romanCache.delete(romanCache.keys().next().value);
  return { text: t };
}

// ---------- Immagini per le carte di Anki (gratis, senza chiavi) ----------
// Fonti: Wikipedia (l'immagine principale della voce, di solito la più adatta), Wikimedia Commons (ricerca tra i
// file), Openverse (foto con licenza libera). La parola si cerca in inglese (tradotta con Google), a meno che tu
// scriva tu cosa cercare. Risposta: { items: [{ url, thumb, source, title }], query }
const imgQueryCache = new Map();
async function imageQuery(msg) {
  let q = String(msg.query || "").trim();
  if (!q || msg.raw || !msg.lang || String(msg.lang).split("-")[0] === "en") return q;
  const k = msg.lang + "|" + q;
  if (imgQueryCache.has(k)) return imgQueryCache.get(k);
  try { q = (await translateGoogle({ texts: [q], target: "en", source: msg.lang }))[0] || q; } catch {}
  q = String(q).replace(/^(the|a|an|to)\s+/i, "").trim();
  imgQueryCache.set(k, q);
  return q;
}
const IMG_OK = /image\/(jpeg|png|webp|gif)/;
async function imgWikipedia(q, n) {
  const url = "https://en.wikipedia.org/w/api.php?action=query&format=json&formatversion=2&origin=*&redirects=1&generator=search&gsrnamespace=0&gsrlimit=" + n +
    "&prop=pageimages&piprop=thumbnail|name&pithumbsize=400&pilicense=any&gsrsearch=" + encodeURIComponent(q);
  const r = await fetch(url);
  if (!r.ok) throw new Error("Wikipedia ha risposto " + r.status);
  const j = await r.json();
  return ((j.query && j.query.pages) || []).sort((a, b) => (a.index || 0) - (b.index || 0))
    .filter((p) => p.thumbnail && p.thumbnail.source && !/\.svg/i.test(p.pageimage || "") && !/\.svg\.png$/i.test(p.thumbnail.source))
    .map((p) => ({ url: p.thumbnail.source, thumb: p.thumbnail.source, source: "Wikipedia", title: p.title }));
}
async function imgCommons(q, n) {
  const url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2&origin=*&generator=search&gsrnamespace=6&gsrlimit=" + n +
    "&prop=imageinfo&iiprop=url|mime&iiurlwidth=400&gsrsearch=" + encodeURIComponent(q + " filetype:bitmap");
  const r = await fetch(url);
  if (!r.ok) throw new Error("Wikimedia Commons ha risposto " + r.status);
  const j = await r.json();
  return ((j.query && j.query.pages) || []).sort((a, b) => (a.index || 0) - (b.index || 0))
    .map((p) => ({ p, ii: (p.imageinfo || [])[0] }))
    .filter(({ ii }) => ii && IMG_OK.test(ii.mime || "") && (ii.thumburl || ii.url))
    .map(({ p, ii }) => ({ url: ii.thumburl || ii.url, thumb: ii.thumburl || ii.url, source: "Commons", title: String(p.title || "").replace(/^File:/, "") }));
}
async function imgOpenverse(q, n) {
  const r = await fetch("https://api.openverse.org/v1/images/?mature=false&page_size=" + n + "&q=" + encodeURIComponent(q));
  if (!r.ok) throw new Error("Openverse ha risposto " + r.status);
  const j = await r.json();
  return (j.results || []).filter((x) => x && (x.thumbnail || x.url))
    .map((x) => ({ url: x.thumbnail || x.url, thumb: x.thumbnail || x.url, source: "Openverse", title: x.title || "" }));
}
async function imageSearch(msg) {
  const q = await imageQuery(msg);
  if (!q) return { items: [], query: "" };
  const src = String(msg.source || "auto");
  const want = { wikipedia: [imgWikipedia], commons: [imgCommons], openverse: [imgOpenverse], all: [imgWikipedia, imgCommons, imgOpenverse] }[src] || [imgWikipedia, imgCommons];
  const n = Math.max(2, Math.min(12, msg.n || 6));
  const res = await Promise.all(want.map((f) => f(q, n).catch((e) => ({ error: String(e.message || e) }))));
  const items = [], seen = new Set(), errors = [];
  for (const r of res) {
    if (!Array.isArray(r)) { errors.push(r.error); continue; }
    for (const it of r) if (!seen.has(it.url)) { seen.add(it.url); items.push(it); }
  }
  return { items: items.slice(0, 16), query: q, error: !items.length && errors.length ? errors.join("; ") : "" };
}
// compatibilità: la prima immagine
async function commonsImage(msg) {
  const s = await DS_EXT.storage.sync.get({ ankiImageSource: "auto" });
  const r = await imageSearch({ ...msg, source: msg.source || s.ankiImageSource });
  return { url: (r.items[0] && r.items[0].url) || "", query: r.query };
}
// L'immagine la scarica l'estensione e la passa ad Anki già pronta: se la scaricasse Anki (AnkiConnect), molti siti
// (Wikipedia/Wikimedia compresi) la rifiutano, e la carta restava senza immagine.
async function imageForAnki(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("immagine non disponibile (" + r.status + ")");
  const type = (r.headers.get("content-type") || "").split(";")[0].trim();
  if (type && !/^image\//.test(type)) throw new Error("non è un'immagine");
  const bytes = new Uint8Array(await r.arrayBuffer());
  if (bytes.length > 5 * 1024 * 1024) throw new Error("immagine troppo grande");
  const ext = (/png/.test(type) && "png") || (/webp/.test(type) && "webp") || (/gif/.test(type) && "gif") || ((url.match(/\.(jpe?g|png|webp|gif)(?:$|[?#])/i) || [, "jpg"])[1].toLowerCase());
  return { data: bytesToB64(bytes), ext: ext === "jpeg" ? "jpg" : ext };
}

// Modi di dire in una frase (Parole al Volo, come l'allineamento dei sottotitoli di Sottotitoli Doppi): una richiesta
// piccola, solo se la scheda resta aperta, salvata per frase. { idioms: [{ text, meaning }] }
async function idiomsFind(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve una chiave di Gemini o Groq");
  const t = C.LANG_EN[msg.target] || msg.target || "Italian";
  const l = langNameEn(msg.lang) || "the language of the sentence";
  const system = `You find idioms in ${l} text for a language learner. List every idiom, figurative expression, phrasal verb or fixed phrase ` +
    `(2 to 7 words) in the sentence whose meaning is NOT simply the sum of its words. Copy "text" exactly as it is written in the sentence. ` +
    `"meaning": what it means, in ${t}, short. Ordinary word combinations are not idioms: if there are none, return an empty list. ` +
    `Reply only with JSON: {"idioms": [{"text": "...", "meaning": "..."}]}`;
  const m = { ...msg, maxTokens: 400 };
  const o = parseObject(await paced(msg.engine, E, () => llmText(E, m, system, JSON.stringify({ sentence: String(msg.sentence || "").slice(0, 500) })), false));
  const sent = String(msg.sentence || "").toLowerCase();
  const idioms = (Array.isArray(o.idioms) ? o.idioms : [])
    .map((x) => ({ text: String((x && x.text) || "").trim(), meaning: llmField(x && x.meaning) }))
    .filter((x) => x.text && x.text.split(/\s+/).length >= 2 && x.text.split(/\s+/).length <= 7 && sent.includes(x.text.toLowerCase()) && !wrongScript(x.meaning, msg.target))
    .slice(0, 5);
  return { idioms, source: E.label.split(" (")[0].split(",")[0] };
}

// Quando Wiktionary non ha l'etimologia: una richiesta al modello (solo se la chiedi con il pulsante)
async function etymLlm(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve una chiave di Gemini o Groq");
  const t = C.LANG_EN[msg.target] || msg.target || "Italian";
  const l = C.LANG_EN[msg.lang] || C.STT_LANGS[msg.lang] || msg.lang || "the language of the sentence";
  const system = `You are an etymologist. Explain the etymology (word origin) of the given ${l} word for a language learner, in ${t}, ` +
    `in 1-3 short sentences: from which older words and languages it comes, and related words in other languages if useful. ` +
    `If you are not sure, say so briefly. Reply only with JSON: {"etymology": "...", "lemma": "dictionary form"}`;
  const user = JSON.stringify({ word: msg.word, sentence: String(msg.sentence || "").slice(0, 300) });
  const m = { ...msg, maxTokens: 600 };
  const o = parseObject(await paced(msg.engine, E, () => llmText(E, m, system, user), true));
  return { text: String(o.etymology || "").trim(), lemma: String(o.lemma || ""), source: E.label.split(" (")[0].split(",")[0] };
}

// ---------- Elenco modelli disponibili ----------
async function listModels(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E) throw new Error("servizio sconosciuto");
  if (E.staticModels) return { models: E.staticModels };
  if (E.kind !== "openai") return { models: [] };
  if (E.needsKey && !msg.key) throw new Error("inserisci prima la chiave");

  const base = openaiBase(E, msg);
  const headers = {};
  if (msg.key) headers.Authorization = "Bearer " + msg.key.trim();
  let r;
  try { r = await fetch(base + "/models", { headers }); } catch (e) { if (E.local) throw localError(base); throw e; }
  if (E.local && r.status === 403) throw new Error("Il modello locale rifiuta la richiesta: imposta OLLAMA_ORIGINS (vedi LEGGIMI).");
  if (!r.ok) throw await httpError(r, E.local ? "Il modello locale" : E.label.split(",")[0]);
  const data = await r.json();

  let ids = (data.data || data.models || []).map((m) => String(m.id || m.name || "").replace(/^models\//, "")).filter(Boolean);
  if (E.modelMatch) ids = ids.filter((id) => new RegExp(E.modelMatch, "i").test(id));
  if (E.modelExclude) ids = ids.filter((id) => !new RegExp(E.modelExclude, "i").test(id));
  ids = [...new Set(ids)].sort();

  let suggested = "";
  for (const p of E.prefer || []) {
    suggested = ids.find((id) => id.toLowerCase().includes(p));
    if (suggested) break;
  }
  return { models: ids, suggested: suggested || ids[0] || "" };
}

// ---------- Trascrizione dell'audio (Whisper) ----------
async function transcribe(msg) {
  const local = msg.stt === "local";
  if (!local && !msg.key) throw new Error("manca la chiave Groq per la trascrizione");
  const base = (local ? msg.url || C.SYNC_DEFAULTS.sttUrl : "https://api.groq.com/openai/v1").trim().replace(/\/+$/, "");

  const bin = atob(msg.audio);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const type = msg.mime.split(";")[0];
  const ext = type.includes("wav") ? "wav" : type.includes("ogg") ? "ogg" : "webm";

  const makeForm = (withWords) => {
    const fd = new FormData();
    fd.append("file", new Blob([bytes], { type }), msg.filename || "audio." + ext);
    fd.append("model", msg.model || "whisper-large-v3-turbo");
    fd.append("response_format", "verbose_json");
    fd.append("temperature", "0");
    if (withWords) { fd.append("timestamp_granularities[]", "word"); fd.append("timestamp_granularities[]", "segment"); }
    if (msg.language) fd.append("language", msg.language);
    if (msg.prompt) fd.append("prompt", msg.prompt.slice(-400));
    return fd;
  };

  const headers = {};
  if (msg.key && !local) headers.Authorization = "Bearer " + msg.key.trim();
  let r;
  try {
    r = await fetch(base + "/audio/transcriptions", { method: "POST", headers, body: makeForm(true) });
    if (r.status === 400) r = await fetch(base + "/audio/transcriptions", { method: "POST", headers, body: makeForm(false) });
  } catch (e) {
    if (local) throw new Error(`Non riesco a collegarmi al server di trascrizione su ${base}: è avviato?`);
    throw e;
  }
  if (r.status === 413) throw new Error("file troppo grande per un invio unico (413)");
  if (!r.ok) throw await httpError(r, local ? "Il server di trascrizione" : "Groq Whisper");
  const data = await r.json();
  let segments = (data.segments || []).map((s) => ({
    start: s.start || 0, end: s.end || 0, text: s.text || "",
    noSpeech: s.no_speech_prob || 0, logprob: s.avg_logprob == null ? 0 : s.avg_logprob, compression: s.compression_ratio || 0
  }));
  if (!segments.length && data.text) segments = [{ start: 0, end: data.duration || 0, text: data.text, noSpeech: 0, logprob: 0 }];
  const words = (data.words || []).map((w) => ({ w: w.word || "", s: w.start || 0, e: w.end || 0 }));
  return { segments, words, language: data.language || "" };
}

// ---------- Pronuncia con la voce online di Google ----------
function ttsCode(l) {
  const low = String(l || "en").replace(/_/g, "-").toLowerCase();
  if (low.startsWith("zh")) return /hant|tw|hk/.test(low) ? "zh-TW" : "zh-CN";
  if (low === "pt-br") return "pt-BR";
  if (low === "iw") return "he";
  return low.split("-")[0] || "en";
}

function bytesToB64(bytes) {
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

// ---------- Anki: invio diretto con il componente aggiuntivo AnkiConnect (Anki deve essere aperto) ----------
// Condiviso con Parole al Volo: le due estensioni usano gli stessi mazzi per lingua ("Lingue::Inglese"…).
async function ankiCall(action, params = {}) {
  let r;
  try {
    r = await fetch("http://127.0.0.1:8765", { method: "POST", body: JSON.stringify({ action, version: 6, params }) });
  } catch {
    throw new Error("Anki non risponde: apri Anki e installa il componente aggiuntivo AnkiConnect (codice 2055492159), poi riavvia Anki.");
  }
  if (!r.ok) throw new Error("Anki ha risposto con un errore (" + r.status + "). Controlla AnkiConnect.");
  const j = await r.json();
  if (j && j.error) throw new Error(String(j.error));
  return j ? j.result : null;
}
// La prima volta Anki chiede (in una finestra sua) se permettere l'accesso a questa estensione
async function ankiPermission() {
  const p = await ankiCall("requestPermission");
  if (!p || p.permission !== "granted") throw new Error("Anki non ha dato il permesso: nella finestra di Anki premi \"Yes\" (Sì), poi riprova.");
}
// Tipo di nota con due campi (Base/Basic) e i nomi dei suoi campi (dipendono dalla lingua di Anki)
async function ankiModel(want) {
  const models = (await ankiCall("modelNames")) || [];
  const pref = [want, "Basic", "Base", "Básico", "Einfach", "Basique", "Basis", "Podstawowy", "Základní", "Базовый", "基本"].filter(Boolean);
  let model = pref.find((m) => models.includes(m));
  let fields = model ? await ankiCall("modelFieldNames", { modelName: model }) : null;
  if (!model || !fields || fields.length < 2) {
    for (const m of models) {
      const f = await ankiCall("modelFieldNames", { modelName: m });
      if (f && f.length === 2) { model = m; fields = f; break; }
    }
  }
  if (!model || !fields || fields.length < 2) throw new Error("In Anki non trovo un tipo di nota con fronte e retro (Base).");
  return { model, fields };
}
// impostazioni del mazzo di questa estensione (defDeck: il mazzo unico se non si divide per lingua)
async function ankiOpts(defDeck) {
  const s = await DS_EXT.storage.sync.get({ ankiDeck: defDeck, ankiPerLang: true, ankiLangDeck: "Lingue::{lingua}", ankiModel: "" });
  return { deck: s.ankiDeck || defDeck, perLang: s.ankiPerLang !== false, tpl: s.ankiLangDeck, model: s.ankiModel };
}
async function ankiCheck(msg = {}) {
  const version = await ankiCall("version");
  await ankiPermission();
  const decks = (await ankiCall("deckNames")) || [];
  const o = await ankiOpts(msg.defDeck || "Sottotitoli Doppi");
  const m = await ankiModel(msg.model || o.model);
  return { version, decks, model: m.model, example: dsAnkiDeckFor(msg.lang || "en", o) };
}
// notes: [{ front, back, tags, lang, image, word }] → una carta ciascuna, nel mazzo della sua lingua
async function ankiAddNotes(notes, defDeck, prefix) {
  await ankiPermission();
  const o = await ankiOpts(defDeck);
  const m = await ankiModel(o.model);
  const made = new Set();
  const ids = [], decks = [];
  let dup = 0, noImg = 0, noImgWhy = "";
  for (const n of notes) {
    const deck = dsAnkiDeckFor(n.lang, o);
    if (!made.has(deck)) { await ankiCall("createDeck", { deck }); made.add(deck); }
    decks.push(deck);
    const note = { deckName: deck, modelName: m.model, fields: { [m.fields[0]]: n.front, [m.fields[1]]: n.back }, tags: n.tags || [], options: { allowDuplicate: false } };
    // immagine (solo se l'hai chiesta nel popup): la scarico io e la passo ad Anki, sotto il fronte
    let imgNote = "";
    if (n.image && /^https:\/\//.test(n.image)) {
      const name = (prefix || "ds") + "-" + String(n.word || "img").replace(/[^\p{L}\p{N}_-]+/gu, "_").slice(0, 40) + "-" + Date.now() % 1e6;
      try {
        const im = await imageForAnki(n.image);
        note.picture = [{ data: im.data, filename: name + "." + im.ext, fields: [m.fields[0]] }];
      } catch (e) {
        // non sono riuscito a scaricarla: provo a farla scaricare ad Anki
        const ext = (n.image.match(/\.(jpe?g|png|webp|gif)(?:$|[?#])/i) || [, "jpg"])[1].toLowerCase();
        note.picture = [{ url: n.image, filename: name + "." + ext, fields: [m.fields[0]] }];
        imgNote = String(e.message || e);
      }
    }
    try { ids.push(await ankiCall("addNote", { note })); }
    catch (err) {
      if (/duplicate/i.test(err.message)) { dup++; ids.push("dup"); }
      else if (note.picture) {   // l'immagine non va: la carta senza immagine è meglio di niente
        delete note.picture;
        try { ids.push(await ankiCall("addNote", { note })); noImg++; } catch (e2) { if (/duplicate/i.test(e2.message)) { dup++; ids.push("dup"); } else throw e2; }
      } else throw err;
    }
    if (imgNote) noImgWhy = imgNote;
  }
  return { ids, dup, decks, deck: [...made].join(", "), noImg, imgNote: noImg ? "senza immagine: Anki non l'ha accettata" + (noImgWhy ? " (" + noImgWhy + ")" : "") : "" };
}
// Sottotitoli Doppi: voci del vocabolario → carte
async function ankiAdd(msg) {
  const notes = (msg.entries || []).map((e) => ({ ...dsAnkiFields(e), lang: e.lang, image: e.image, word: e.word }));
  return ankiAddNotes(notes, "Sottotitoli Doppi", "sd");
}

// ---------- Voci naturali di Microsoft (Azure Speech, con la tua chiave; piano gratuito 500.000 caratteri al mese) ----------
async function azureCfg() {
  const l = await DS_EXT.storage.local.get({ keys: {} });
  const s = await DS_EXT.storage.sync.get({ azureRegion: "westeurope" });
  const key = String((l.keys || {}).azureSpeech || "").trim();
  const region = String(s.azureRegion || "westeurope").trim().toLowerCase().replace(/\s+/g, "");
  if (!key) throw new Error("manca la chiave di Azure Speech (popup → Voci)");
  return { key, region };
}
let azureList = null;
async function azureVoices(msg = {}) {
  const cfg = await azureCfg();
  if (!msg.fresh && azureList && azureList.region === cfg.region && azureList.key === cfg.key) return { list: azureList.list };
  if (!msg.fresh) {
    const st = (await DS_EXT.storage.local.get({ azureVoiceList: null })).azureVoiceList;
    if (st && st.region === cfg.region && Date.now() - st.at < 7 * 86400e3 && st.list && st.list.length) { azureList = { ...st, key: cfg.key }; return { list: st.list }; }
  }
  const r = await fetch(`https://${cfg.region}.tts.speech.microsoft.com/cognitiveservices/voices/list`, { headers: { "Ocp-Apim-Subscription-Key": cfg.key } });
  if (!r.ok) throw await httpError(r, "Azure Speech");
  const j = await r.json();
  const list = (Array.isArray(j) ? j : []).filter((v) => v && v.ShortName && v.Locale)
    .map((v) => ({ name: v.ShortName, locale: v.Locale, label: v.LocalName || v.DisplayName || v.ShortName, gender: v.Gender === "Female" ? "donna" : v.Gender === "Male" ? "uomo" : "", neural: /neural/i.test(v.VoiceType || v.ShortName), multi: /multilingual/i.test(v.ShortName) }));
  azureList = { region: cfg.region, key: cfg.key, at: Date.now(), list };
  await DS_EXT.storage.local.set({ azureVoiceList: { region: cfg.region, at: Date.now(), list } }).catch(() => {});
  return { list };
}
function azurePick(list, lang) {
  const full = String(lang || "").toLowerCase().replace(/_/g, "-");
  const b = full.split("-")[0];
  const same = list.filter((v) => v.locale.toLowerCase().split("-")[0] === b);
  if (!same.length) return null;
  const score = (v) => (v.locale.toLowerCase() === full ? 4 : 0) + (v.neural ? 2 : 0) + (v.multi ? -1 : 0);
  return same.sort((x, y) => score(y) - score(x))[0];
}
const azureAudio = new Map();   // le ultime pronunce, per non ripagarle
async function azureTts(msg) {
  const cfg = await azureCfg();
  const text = String(msg.text || "").slice(0, 600);
  let voice = String(msg.voice || ""), locale = "";
  if (!voice) {
    const v = azurePick((await azureVoices()).list, msg.lang);
    if (!v) throw new Error("Azure non ha voci per questa lingua");
    voice = v.name; locale = v.locale;
  }
  locale = locale || voice.split("-").slice(0, 2).join("-");
  const k = voice + "|" + text;
  if (azureAudio.has(k)) return { audio: azureAudio.get(k), voice };
  const esc = (x) => x.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const ssml = `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="${locale}"><voice name="${voice}">${esc(text)}</voice></speak>`;
  const r = await fetch(`https://${cfg.region}.tts.speech.microsoft.com/cognitiveservices/v1`, {
    method: "POST",
    headers: { "Ocp-Apim-Subscription-Key": cfg.key, "Content-Type": "application/ssml+xml", "X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3" },
    body: ssml
  });
  if (!r.ok) throw await httpError(r, "Azure Speech");
  const audio = bytesToB64(new Uint8Array(await r.arrayBuffer()));
  azureAudio.set(k, audio);
  while (azureAudio.size > 150) azureAudio.delete(azureAudio.keys().next().value);
  return { audio, voice };
}

async function tts(msg) {
  const q = encodeURIComponent(String(msg.text || "").slice(0, 190));
  const tl = encodeURIComponent(ttsCode(msg.lang));
  const urls = [
    `https://translate.googleapis.com/translate_tts?client=gtx&ie=UTF-8&tl=${tl}&q=${q}`,
    `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${tl}&q=${q}`
  ];
  let last = "";
  for (const url of urls) {
    try {
      const r = await fetch(url);
      if (!r.ok) { last = "HTTP " + r.status; continue; }
      const bytes = new Uint8Array(await r.arrayBuffer());
      if (bytes.length < 200) { last = "risposta vuota"; continue; }
      return { audio: bytesToB64(bytes) };
    } catch (e) {
      last = String(e.message || e);
    }
  }
  throw new Error("pronuncia di Google non disponibile (" + last + ")");
}

// ---------- Aggiornamento: da questa versione Gemini usa Flash-Lite ----------
async function dsMigrate() {
  const l = await DS_EXT.storage.local.get({ keys: {}, migrated: {} });
  if (l.migrated.flashLite) return;
  const s = await DS_EXT.storage.sync.get({ models: {} });
  const update = { models: { ...(s.models || {}), gemini: "gemini-flash-lite-latest" } };
  if (l.keys && l.keys.gemini) update.engine = "gemini"; // se hai già una chiave Gemini, la uso per tradurre
  await DS_EXT.storage.sync.set(update);
  await DS_EXT.storage.local.set({ migrated: { ...l.migrated, flashLite: true } });
}
async function dsCleanLiveStream() {
  const all = await DS_EXT.storage.local.get(null);
  const bad = Object.keys(all).filter((k) => /^(live:|livetr:)live_stream/.test(k));
  if (bad.length) await DS_EXT.storage.local.remove(bad);
}
chrome.runtime.onInstalled.addListener(() => { dsMigrate().catch(() => {}); dsCleanLiveStream().catch(() => {}); });

// ---------- Programma di appoggio (yt-dlp) e download dei file interi ----------
const HELPER = "com.sottotitolidoppi.helper";

function helperPing() {
  return new Promise((resolve) => {
    let port;
    const done = (r) => { try { port && port.disconnect(); } catch {} resolve(r); };
    try { port = chrome.runtime.connectNative(HELPER); } catch (e) { return resolve({ installed: false, error: String(e.message || e) }); }
    const timer = setTimeout(() => done({ installed: false, error: "il programma non risponde" }), 15000);
    port.onMessage.addListener((m) => { if (m && m.type === "pong") { clearTimeout(timer); done({ installed: true, ...m }); } });
    port.onDisconnect.addListener(() => {
      clearTimeout(timer);
      const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : "";
      resolve({ installed: false, error: err || "il programma si è chiuso" });
    });
    port.postMessage({ cmd: "ping" });
  });
}

// La pagina del video chiede l'audio intero: dal file diretto se c'è, altrimenti con yt-dlp.
// I dati tornano alla pagina a pezzi, sulla stessa porta.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "sd-full") return;
  let native = null, closed = false;
  port.onDisconnect.addListener(() => { closed = true; try { native && native.disconnect(); } catch {} });
  const post = (m) => { if (!closed) try { port.postMessage(m); } catch {} };

  port.onMessage.addListener(async (req) => {
    // 1) File diretto (mp4, mp3…): lo scarico io, senza programma di appoggio
    if (req.src && /^https?:/.test(req.src)) {
      try {
        post({ type: "status", text: "Scarico il file…" });
        const r = await fetch(req.src);
        if (!r.ok) throw new Error("il sito ha risposto " + r.status);
        const total = Number(r.headers.get("content-length")) || 0;
        const ext = (req.src.split("?")[0].split(".").pop() || "").toLowerCase().slice(0, 5);
        post({ type: "meta", size: total, ext, title: "" });
        const reader = r.body.getReader();
        let got = 0, buf = [], bufLen = 0, lastPct = -1;
        const flush = () => {
          if (!bufLen) return;
          const all = new Uint8Array(bufLen);
          let o = 0;
          for (const b of buf) { all.set(b, o); o += b.length; }
          post({ type: "chunk", data: bytesToB64(all) });
          buf = []; bufLen = 0;
        };
        for (;;) {
          const { done, value } = await reader.read();
          if (done || closed) break;
          buf.push(value); bufLen += value.length; got += value.length;
          if (bufLen >= 600 * 1024) flush();
          const pct = total ? Math.floor((got * 100) / total) : -1;
          if (pct !== lastPct) { lastPct = pct; post({ type: "progress", pct }); }
        }
        flush();
        post({ type: "done" });
        return;
      } catch (e) {
        if (!req.url) { post({ type: "error", code: "fetch", message: "non riesco a scaricare il file: " + (e.message || e) }); return; }
        // provo con yt-dlp qui sotto
      }
    }
    // 2) YouTube, Vimeo, VK e gli altri siti: yt-dlp tramite il programma di appoggio
    try { native = chrome.runtime.connectNative(HELPER); } catch (e) {
      post({ type: "error", code: "nohelper", message: "il programma di appoggio per yt-dlp non è installato" });
      return;
    }
    let finished = false;
    native.onMessage.addListener((m) => {
      if (m.type === "done" || m.type === "error") finished = true;
      post(m);
      if (finished) { try { native.disconnect(); } catch {} }
    });
    native.onDisconnect.addListener(() => {
      if (finished) return;
      const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : "";
      const missing = /not found|not exist|non trovato|No such native/i.test(err);
      post({ type: "error", code: missing ? "nohelper" : "crash",
        message: missing ? "il programma di appoggio per yt-dlp non è installato" : "il programma di appoggio si è chiuso" + (err ? " (" + err + ")" : "") });
    });
    native.postMessage({ cmd: "audio", url: req.url });
  });
});

// Diretta in anticipo: la pagina apre la porta "sd-live" e riceve l'audio della diretta letto da yt-dlp (un secondo
// alla volta) finché la tiene aperta. Chiusa la porta, il programma di appoggio ferma yt-dlp e ffmpeg.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "sd-live") return;
  let native = null, closed = false, finished = false;
  const post = (m) => { if (!closed) try { port.postMessage(m); } catch {} };
  port.onDisconnect.addListener(() => { closed = true; try { native && native.postMessage({ cmd: "stop" }); } catch {} try { native && native.disconnect(); } catch {} });
  port.onMessage.addListener((req) => {
    if (!req || !req.url || native) return;
    try { native = chrome.runtime.connectNative(HELPER); } catch (e) {
      post({ type: "error", code: "nohelper", message: "il programma di appoggio per yt-dlp non è installato" });
      return;
    }
    native.onMessage.addListener((m) => {
      if (m.type === "done" || m.type === "error") finished = true;
      post(m);
    });
    native.onDisconnect.addListener(() => {
      if (finished || closed) return;
      const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : "";
      const missing = /not found|not exist|non trovato|No such native/i.test(err);
      post({ type: "error", code: missing ? "nohelper" : "crash",
        message: missing ? "il programma di appoggio per yt-dlp non è installato" : "il programma di appoggio si è chiuso" + (err ? " (" + err + ")" : "") });
    });
    native.postMessage({ cmd: "live", url: req.url });
  });
});

// ---------- Corrispondenza tra traduzione e originale ----------
// Con un modello: allineamento dell'intera frase, parola per parola (una richiesta per frase)
async function align(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve un modello (Gemini, Groq, Claude o locale)");
  const tl = C.LANG_EN[msg.target] || msg.target || "the learner's language";
  // più frasi in una sola richiesta: quella che stai guardando e le prossime (risparmia quota)
  const items = Array.isArray(msg.items) && msg.items.length ? msg.items : [{ original: msg.original, translation: msg.translation }];
  const system =
    `You align sentences with their translations for a language learner. You get a list of items, each with an original ` +
    `sentence and its translation. Return only JSON in this form, with one entry per item, in the same order: ` +
    `{"items": [{"pairs": [{"t": "words from the translation", "o": "the words of the original they translate", "extra": ["..."]}, ...], ` +
    `"idioms": [{"text": "words from the original", "meaning": "..."}]}, ...]}. ` +
    `For each item go through the translation in order and cover every word of it exactly once. Make the pairs as small as possible: ` +
    `one word with its own counterpart whenever the correspondence is one-to-one (never pair a word with the word next to ` +
    `its counterpart); group words only when they translate together (idioms, compound verb forms, contractions). ` +
    `Copy the words exactly as written in each text (same spelling, apostrophes and accents). ` +
    `"o" is never empty: it is always the part of the original the words of "t" belong to. ` +
    `Words of the translation that do not translate any word of the original (articles, prepositions, auxiliaries, ` +
    `pronouns or particles required only by the grammar of the translation) go in the pair of the word they accompany ` +
    `and are also listed in "extra"; otherwise "extra" is []. ` +
    `Example: original "I like cats", translation "Mi piacciono i gatti" → ` +
    `{"pairs": [{"t": "Mi piacciono", "o": "I like", "extra": []}, {"t": "i gatti", "o": "cats", "extra": ["i"]}]}. ` +
    `In "idioms" list every idiom, figurative expression, phrasal verb or fixed phrase of the ORIGINAL whose meaning ` +
    `is not the sum of its words (e.g. "break the ice", "give up", "tomar el pelo"), copied exactly as written in the ` +
    `original, with its real meaning in ${tl} (1-6 words). Use [] if there are none.`;
  const user = JSON.stringify({ original_language: msg.lang || "unknown",
    items: items.map((x, i) => ({ n: i + 1, original: x.original, translation: x.translation })) });
  const text = await paced(msg.engine, E, () => llmText(E, msg, system, user), true);
  const obj = parseObject(text);
  const list = Array.isArray(obj.items) ? obj.items : [obj];
  const results = items.map((it, i) => {
    const o = list[i] || {};
    const pairs = (Array.isArray(o.pairs) ? o.pairs : [])
      .map((p) => (Array.isArray(p) ? (p.length >= 2 ? [p[0], p[1], p[2]] : null)
        : p && typeof p === "object" ? [p.t ?? p.translation, p.o ?? p.original, p.extra] : null))
      .filter((p) => p && String(p[0] || "").trim())
      .map((p) => [String(p[0] || ""), String(p[1] || ""), (Array.isArray(p[2]) ? p[2] : p[2] ? [p[2]] : []).map(String)]);
    const low = String(it.original || "").toLowerCase();
    const idioms = (Array.isArray(o.idioms) ? o.idioms : [])
      .map((x) => (typeof x === "string" ? { text: x, meaning: "" } : { text: String((x && x.text) || ""), meaning: String((x && x.meaning) || "") }))
      .filter((x) => x.text.trim().split(/\s+/).length > 1 && low.includes(x.text.trim().toLowerCase().split(/\s+/)[0]));
    return { pairs, idioms };
  });
  if (!results[0].pairs.length) throw new Error("allineamento non leggibile");
  return { pairs: results[0].pairs, idioms: results[0].idioms, results };
}

// Senza modello: traduzione inversa della singola parola con Google (gratis), per cercarla nell'originale
async function wordBack(msg) {
  const tl = googleLang(msg.to || "en");
  const sl = msg.from ? "&sl=" + encodeURIComponent(googleLang(msg.from)) : "";
  const data = await googleRequest(msg.word, tl, "&dt=bd" + sl);
  const words = new Set();
  const add = (s) => String(s || "").toLowerCase().split(/[^\p{L}\p{N}']+/u).filter((w) => w.length > 1).forEach((w) => words.add(w));
  add(googleText(data));
  for (const e of Array.isArray(data[1]) ? data[1] : []) for (const t of (e[1] || []).slice(0, 8)) add(t);
  return { candidates: [...words].slice(0, 30) };
}

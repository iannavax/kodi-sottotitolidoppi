// Parole interattive (significato nel contesto, pronuncia) e vocabolario personale.
// Usa: settings, engine, liveEngine, getVideo, overlay, lineOrig (da content.js)

let vocab = {};
let vocabForms = new Set();
let vocabVersion = 0;
let wordsCurrent = null;        // frase mostrata ora: { text, trans, start, end, lang, live }
let wordsOrigKey = "";
let wordsCard = null;
let wordsCardState = null;      // { pinned, word, data }
let wordsAutoPaused = false;
let wordsHovering = false;
let wordsHoverTimer = 0, wordsLeaveTimer = 0, wordsReqId = 0;
let wordsReplayUntil = null;
const wordsDefCache = new Map();
// Le spiegazioni chieste a un modello restano salvate (anche chiudendo il browser): la stessa parola nella stessa
// frase non si richiede più. Le ultime 1500.
let wordsDefSaveTimer = 0;
chrome.storage.local.get({ defCache: [] }, (r) => {
  for (const [k, v] of Array.isArray(r.defCache) ? r.defCache : []) if (!wordsDefCache.has(k)) wordsDefCache.set(k, v);
});
function wordsDefRemember(k, v, persist) {
  wordsDefCache.set(k, v);
  while (wordsDefCache.size > 1500) wordsDefCache.delete(wordsDefCache.keys().next().value);
  if (!persist) return;
  clearTimeout(wordsDefSaveTimer);
  wordsDefSaveTimer = setTimeout(() => {
    const keep = [...wordsDefCache].filter(([, d]) => d && d.persist).slice(-1500);
    DS_EXT.storage.local.set({ defCache: keep }).catch(() => {});
  }, 1500);
}
const wordsSegmenters = new Map();

// ---------- Vocabolario ----------
function vocabId(lang, lemma, word) {
  return `${(lang || "?").split("-")[0].toLowerCase()}|${String(lemma || word).toLowerCase()}`;
}

function vocabRebuild() {
  vocabForms = new Set();
  for (const e of Object.values(vocab)) {
    if (e.status === "known") continue;
    if (e.word) vocabForms.add(e.word.toLowerCase());
    if (e.lemma) vocabForms.add(e.lemma.toLowerCase());
  }
  vocabVersion++;
}

chrome.storage.local.get({ vocab: {} }, (r) => { vocab = r.vocab || {}; vocabRebuild(); });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.vocab) {
    vocab = changes.vocab.newValue || {};
    vocabRebuild();
    wordsRefreshStar();
  }
});

async function vocabToggle(entry) {
  const { vocab: current = {} } = await DS_EXT.storage.local.get({ vocab: {} });
  if (current[entry.id]) delete current[entry.id];
  else current[entry.id] = entry;
  await DS_EXT.storage.local.set({ vocab: current });
}

// ---------- Suddivisione della frase in parole ----------
function wordsTokenize(text, lang) {
  try {
    const key = lang || "";
    if (!wordsSegmenters.has(key)) {
      let seg;
      try { seg = new Intl.Segmenter(lang || undefined, { granularity: "word" }); }
      catch { seg = new Intl.Segmenter(undefined, { granularity: "word" }); }
      wordsSegmenters.set(key, seg);
    }
    return [...wordsSegmenters.get(key).segment(text)].map((s) => ({ text: s.segment, word: dsIsWord(s) }));
  } catch {
    return text.split(/([\p{L}\p{M}\p{N}'’-]+)/u).filter(Boolean).map((t) => ({ text: t, word: /[\p{L}\p{N}]/u.test(t) }));
  }
}

// ---------- Parole della traduzione ↔ parole dell'originale ----------
let wordsTransKey = "";
let wordsAlignTip = null;
let wordsAlignTimer = 0;
const wordsAlignCache = new Map();   // frase + traduzione → coppie allineate dal modello
const wordsAlignAsked = new Set();
const wordsBackCache = new Map();    // parola tradotta → parole originali possibili (Google)
const wordsIdioms = new Map();       // frase originale → modi di dire [{ text, meaning }] (dal modello, nella richiesta dell'allineamento)
let wordsSel = null;                 // selezione a mano di più parole: { start, end, moved }
let wordsNoClickUntil = 0;
let wordsIdiomTimer = 0;
let wordsTSel = null;                // selezione a mano di più parole della traduzione: { start, end, moved }
let wordsCompare = null;             // confronto attivo: { key, tSpans } (parte della traduzione ↔ parte dell'originale)

function wordsRenderTrans(text) {
  const key = text + "\u0001" + (wordsCurrent ? wordsCurrent.text : "");
  if (key === wordsTransKey) return;
  wordsTransKey = key;
  wordsCompare = null;
  lineTrans.textContent = "";
  for (const part of wordsTokenize(text, settings.targetLang)) {
    if (!part.word) { lineTrans.append(part.text); continue; }
    lineTrans.append(Object.assign(document.createElement("span"), { className: "dualsub-tword", textContent: part.text }));
  }
  wordsMarkParticles();
}

const wordsNorm = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/\p{M}/gu, "").replace(/[^\p{L}\p{N}]/gu, "");
function wordsSame(a, b) {
  if (!a || !b) return false;
  if (a === b) return true;
  const n = Math.min(a.length, b.length);
  if (n < 4 || Math.abs(a.length - b.length) > 3) return false;   // "bread" non è "breakfast"
  const k = Math.max(4, n - 2);   // stessa radice (bread/breads, andare/andato)
  return a.slice(0, k) === b.slice(0, k);
}
const wordsSplit = (s) => String(s || "").split(/[^\p{L}\p{N}']+/u).map(wordsNorm).filter(Boolean);
const wordsNoSpaces = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Thai}\p{Script=Lao}\p{Script=Khmer}\p{Script=Myanmar}]/u;

function wordsFindSeq(tokens, seq, from) {
  const at = (i) => seq.every((w, j) => wordsSame(tokens[i + j], w));
  for (let i = from; i + seq.length <= tokens.length; i++) if (at(i)) return i;
  for (let i = 0; i < Math.min(from, tokens.length); i++) if (i + seq.length <= tokens.length && at(i)) return i;
  return -1;
}

// Indici delle parole della frase (già normalizzate) che contengono il pezzo `phrase`, cercando da `from` in poi.
// Se parola per parola non lo trovo (apostrofi diversi "l’acqua"/"l'acqua", trattini, cinese e giapponese
// divisi in parole in modo diverso) lo cerco nel testo unito senza spazi.
function wordsLocate(tok, phrase, from) {
  const seq = wordsSplit(phrase);
  if (!seq.length) return [];
  const i = wordsFindSeq(tok, seq, from);
  if (i >= 0) return seq.map((_, k) => i + k);
  const p = wordsNorm(phrase);
  if (!p) return [];
  let s = "";
  const st = [], en = [];
  tok.forEach((t) => { st.push(s.length); s += t; en.push(s.length); });
  const loose = p.length >= 4 || wordsNoSpaces.test(p);   // pezzi di parola solo se abbastanza lunghi
  let best = null;
  for (let at = s.indexOf(p); at >= 0; at = s.indexOf(p, at + 1)) {
    const end = at + p.length;
    const idx = [];
    tok.forEach((_, k) => { if (st[k] < end && en[k] > at && tok[k]) idx.push(k); });
    if (!idx.length) continue;
    const whole = st[idx[0]] === at && en[idx[idx.length - 1]] === end;
    if (!whole && !loose) continue;
    const score = (whole ? 2 : 0) + (idx[0] >= from ? 1 : 0);
    if (!best || score > best.score) best = { idx, score };
    if (score === 3) break;
  }
  return best ? best.idx : [];
}

// Dalle coppie del modello: per ogni parola della traduzione, le parole dell'originale che traduce.
// Coppie: [parole della traduzione, parole dell'originale, parole "in più" della traduzione].
// Valore: { o: [indici nell'originale], how, group: [indici delle parole della traduzione nella stessa coppia] }
//   "model"    → traduce quella parte dell'originale
//   "particle" → non traduce una parola: la richiede la grammatica della traduzione (articolo, preposizione…);
//                o = la parte dell'originale di cui fa parte
//   "lost"     → il modello l'ha saltata o scritta diversa: va cercata in un altro modo (mai indovinata dalla vicina)
function wordsAlignMap(tTok, oTok, pairs) {
  const t2o = new Map();
  let tp = 0, op = 0;
  for (const p of pairs) {
    const tPhrase = p[0], oPhrase = String(p[1] || "").trim();
    const extra = new Set((Array.isArray(p[2]) ? p[2] : []).flatMap(wordsSplit));
    const ti = wordsLocate(tTok, tPhrase, tp);
    if (!ti.length) continue;
    const oi = oPhrase ? wordsLocate(oTok, oPhrase, op) : [];
    for (const i of ti) {
      const old = t2o.get(i);
      if (old && old.how !== "lost") continue;
      const how = !oPhrase ? "empty" : !oi.length ? "lost" : extra.has(tTok[i]) ? "particle" : "model";
      t2o.set(i, { o: oi, how, group: ti });
    }
    tp = ti[ti.length - 1] + 1;
    if (oi.length) op = oi[oi.length - 1] + 1;
  }
  // originale lasciato vuoto dal modello: è una parola aggiunta dalla traduzione, la lego alla parte che accompagna
  // (di solito la parola dopo: "il gatto", "di fumare"; alla fine della frase quella prima)
  const sure = (i) => { const e = t2o.get(i); return !!e && e.how === "model"; };
  for (const [i, e] of [...t2o]) {
    if (e.how !== "empty") continue;
    let r = i + 1; while (r < tTok.length && !sure(r) && t2o.has(r) && t2o.get(r).how === "empty") r++;
    let l = i - 1; while (l >= 0 && !sure(l) && t2o.has(l) && t2o.get(l).how === "empty") l--;
    const from = sure(r) ? r : sure(l) ? l : -1;
    t2o.set(i, from >= 0 ? { o: t2o.get(from).o, how: "particle", group: [Math.min(i, from), Math.max(i, from)] } : { o: [], how: "lost", group: [i] });
  }
  return t2o;
}

// Parole della traduzione che sono solo particelle (dopo l'allineamento del modello): sottolineate a puntini
function wordsMarkParticles() {
  if (!lineTrans || !wordsCurrent || !wordsCurrent.trans) return;
  const tSpans = [...lineTrans.querySelectorAll(".dualsub-tword")];
  tSpans.forEach((s) => s.classList.remove("dualsub-tpart"));
  const pairs = wordsAlignCache.get(wordsCurrent.text + "\u0001" + wordsCurrent.trans);
  if (!pairs || !lineOrig) return;
  const oTok = [...lineOrig.querySelectorAll(".dualsub-word")].map((s) => wordsNorm(s.textContent));
  for (const [ti, e] of wordsAlignMap(tSpans.map((s) => wordsNorm(s.textContent)), oTok, pairs)) {
    if (e.how === "particle" && tSpans[ti]) {
      tSpans[ti].classList.add("dualsub-tpart");
      tSpans[ti].title = "Particella della traduzione: non traduce una parola dell'originale";
    }
  }
}

function wordsClearAlign() {
  clearTimeout(wordsAlignTimer);
  if (!overlay) return;
  overlay.querySelectorAll(".dualsub-hl, .dualsub-hl-part, .dualsub-hl-group").forEach((x) => x.classList.remove("dualsub-hl", "dualsub-hl-part", "dualsub-hl-group"));
  if (wordsAlignTip) { wordsAlignTip.remove(); wordsAlignTip = null; }
}

// res = { o: [indici nell'originale], how, group } con how:
//   "model" (traduzione di quella parte), "particle" (particella della traduzione), "google" (circa),
//   "zone" (traduzione diretta non trovata: zona della frase), "wait" (sto cercando)
function wordsShowAlign(tEl, res) {
  overlay.querySelectorAll(".dualsub-hl, .dualsub-hl-part, .dualsub-hl-group").forEach((x) => x.classList.remove("dualsub-hl", "dualsub-hl-part", "dualsub-hl-group"));
  const oSpans = [...lineOrig.querySelectorAll(".dualsub-word")];
  const tSpans = [...lineTrans.querySelectorAll(".dualsub-tword")];
  const sorted = [...new Set(res.o || [])].sort((a, b) => a - b);
  const hit = sorted.map((i) => oSpans[i]).filter(Boolean);
  const part = res.how === "particle" || res.how === "zone";
  hit.forEach((s) => { s.classList.add("dualsub-hl"); if (part) s.classList.add("dualsub-hl-part"); });
  tEl.classList.add("dualsub-hl");
  // le altre parole della traduzione che vanno insieme a questa (per esempio "gli" con "angoli")
  const group = (res.group || []).map((i) => tSpans[i]).filter((s) => s && s !== tEl);
  group.forEach((s) => s.classList.add("dualsub-hl-group"));
  if (!wordsAlignTip) {
    wordsAlignTip = document.createElement("div");
    wordsAlignTip.className = "dualsub-align-tip";
    overlay.append(wordsAlignTip);
  }
  wordsAlignTip.textContent = "";
  wordsAlignTip.classList.toggle("dualsub-tip-long", part && hit.length > 0);
  const joined = sorted.every((v, k) => k === 0 || v === sorted[k - 1] + 1);
  const hitText = joined ? wordsRangeText(hit) : hit.map((x) => x.textContent).join(" … ");
  const word = tEl.textContent;
  if (res.how === "wait" || !hit.length) {
    wordsAlignTip.append(el("span", null, "Cerco la parola nell'originale…"));
  } else if (res.how === "particle") {
    const whole = group.length ? wordsRangeText([tEl, ...group].sort((a, b) => tSpans.indexOf(a) - tSpans.indexOf(b))) : "";
    wordsAlignTip.append(el("span", "dualsub-tip-part", "particella"), el("span", null, ` «${word}» non traduce una parola dell'originale: la aggiunge la grammatica della traduzione` +
      (whole ? ` in «${whole}», che traduce ` : `. Fa parte della traduzione di `)), el("b", null, hitText));
  } else if (res.how === "zone") {
    wordsAlignTip.append(el("span", null, `Non trovo la traduzione diretta di «${word}»: è probabilmente una particella della traduzione, o la frase è tradotta liberamente. Zona corrispondente: `),
      el("b", null, hitText), el("span", null, "  ·  circa"));
  } else {
    wordsAlignTip.append(el("b", null, hitText), el("span", null, res.how === "google" ? "  ·  circa · clic per il significato" : "  ·  clic per il significato"));
  }
  const or = overlay.getBoundingClientRect(), r = tEl.getBoundingClientRect();
  wordsAlignTip.style.left = r.left + r.width / 2 - or.left + "px";
  const transFirst = settings.transFirst;
  if (transFirst) { wordsAlignTip.style.top = ""; wordsAlignTip.style.bottom = or.bottom - r.top + 6 + "px"; }
  else { wordsAlignTip.style.bottom = ""; wordsAlignTip.style.top = r.bottom - or.top + 6 + "px"; }
  return hit;
}

// Posizione stimata di una parola della traduzione nell'originale (ultima risorsa)
const wordsGuessAt = (ti, nT, nO) => Math.round((ti / Math.max(1, nT - 1)) * Math.max(0, nO - 1));

// Tra più posizioni possibili tengo quella più vicina alla posizione della parola nella traduzione
function wordsNearest(idx, ti, nT, nO) {
  if (idx.length <= 1) return idx;
  const rel = ti / Math.max(1, nT - 1);
  return [[...idx].sort((a, b) => Math.abs(a / Math.max(1, nO - 1) - rel) - Math.abs(b / Math.max(1, nO - 1) - rel))[0]];
}

// Allineamento del modello in corso per questa frase (vale la pena aspettarlo)?
const wordsAlignPending = (key) => wordsAlignAsked.has(key);

// Senza modello (o se il modello ha saltato la parola): traduzione parola per parola dell'originale con Google
// (una richiesta per frase, gratis) e, se non basta, traduzione inversa della parola. Una parola della traduzione
// rimanda solo a una parola dell'originale che la traduce davvero: mai alla vicina.
const wordsGlossCache = new Map();   // frase originale + lingua → traduzione di ogni parola
async function wordsGloss(cur, oWords) {
  const k = cur.text + "|" + settings.targetLang;
  if (wordsGlossCache.has(k)) return wordsGlossCache.get(k);
  const src = (cur.lang || "").split("-")[0] || DualSubs.guessLang(cur.text) || "";
  let gloss = [];
  try {
    const r = await DS_EXT.runtime.sendMessage({ type: "translate", engine: "google", target: settings.targetLang, source: src,
      texts: oWords.slice(0, 60) });
    gloss = (r && r.translations) || [];
  } catch {}
  if (gloss.length) {
    wordsGlossCache.set(k, gloss);
    if (wordsGlossCache.size > 300) wordsGlossCache.delete(wordsGlossCache.keys().next().value);
  }
  return gloss;
}

async function wordsBack(word, cur) {
  const src = (cur.lang || "").split("-")[0] || DualSubs.guessLang(cur.text) || "";
  const k = word + "|" + src;
  if (wordsBackCache.has(k)) return wordsBackCache.get(k);
  let c = [];
  try {
    const r = await DS_EXT.runtime.sendMessage({ type: "wordBack", word, from: settings.targetLang, to: src || "en" });
    c = (r && r.candidates) || [];
  } catch {}
  wordsBackCache.set(k, c);
  if (wordsBackCache.size > 500) wordsBackCache.delete(wordsBackCache.keys().next().value);
  return c;
}

// Parole dell'originale che traducono la parola ti della traduzione (con Google); [] se nessuna
async function wordsGoogleFind(cur, ti, tSpans, oSpans) {
  const tTok = tSpans.map((s) => wordsNorm(s.textContent)), oTok = oSpans.map((s) => wordsNorm(s.textContent));
  const w = tTok[ti];
  const gloss = await wordsGloss(cur, oSpans.map((s) => s.textContent));
  let idx = [];
  gloss.forEach((g, i) => { if (wordsSplit(g).some((x) => wordsSame(x, w))) idx.push(i); });
  // una parola uguale nelle due lingue (nomi, numeri)
  if (!idx.length) oTok.forEach((o, i) => { if (wordsSame(o, w)) idx.push(i); });
  if (!idx.length) {
    const cands = (await wordsBack(tSpans[ti].textContent, cur)).map(wordsNorm).filter(Boolean);
    oTok.forEach((o, i) => { if (cands.some((c) => wordsSame(o, c))) idx.push(i); });
  }
  return wordsNearest(idx, ti, tTok.length, oTok.length);
}

// Zona della frase dove dovrebbe stare la parola (quando non c'è una traduzione diretta)
function wordsZone(ti, nT, nO) {
  const c = wordsGuessAt(ti, nT, nO);
  return [c - 1, c, c + 1].filter((i) => i >= 0 && i < nO);
}

async function wordsAlignHover(tEl) {
  const cur = wordsCurrent;
  if (!cur || !cur.trans || !tEl.isConnected) return;
  const tSpans = [...lineTrans.querySelectorAll(".dualsub-tword")];
  const oSpans = [...lineOrig.querySelectorAll(".dualsub-word")];
  if (!oSpans.length) return;
  const ti = tSpans.indexOf(tEl);
  const tTok = tSpans.map((s) => wordsNorm(s.textContent)), oTok = oSpans.map((s) => wordsNorm(s.textContent));
  const key = cur.text + "\u0001" + cur.trans;
  // stessa frase ancora sullo schermo (l'oggetto della frase viene ricreato di continuo: confronto il testo)
  const sameLine = () => !!wordsCurrent && wordsCurrent.text + "\u0001" + wordsCurrent.trans === key;
  const still = () => sameLine() && tEl.isConnected && tEl.matches(":hover");

  // 1) allineamento del modello già pronto per questa frase
  const pairs = wordsAlignCache.get(key);
  const e = pairs ? wordsAlignMap(tTok, oTok, pairs).get(ti) : null;
  if (e && e.how === "particle") return wordsShowAlign(tEl, e);
  if (e && e.how === "model") {
    wordsShowAlign(tEl, e);
    // controllo con la traduzione parola per parola di Google (gratis, una richiesta per frase): se dice chiaramente
    // che la parola traduce un'altra parola dell'originale (il modello ha sbagliato di una), mostro quella
    if (tTok[ti].length < 2) return;
    const gloss = await wordsGloss(cur, oSpans.map((s) => s.textContent));
    if (!still()) return;
    const g = [];
    gloss.forEach((x, i) => { if (wordsSplit(x).some((w) => wordsSame(w, tTok[ti]))) g.push(i); });
    if (g.length === 1 && !e.o.includes(g[0])) wordsShowAlign(tEl, { o: g, how: "google", group: e.group });
    return;
  }

  // 2) con Google: la parola dell'originale che la traduce davvero
  wordsShowAlign(tEl, { o: [], how: "wait" });
  if (!pairs) wordsAskAlign(cur);
  const idx = await wordsGoogleFind(cur, ti, tSpans, oSpans);
  if (!still() || (!pairs && wordsAlignCache.has(key))) return;
  if (idx.length) return wordsShowAlign(tEl, { o: idx, how: "google" });
  if (wordsLlmAvailable() && wordsAlignPending(key)) return;   // aspetto il modello: rifarà questo passaggio quando risponde
  // 3) nessuna traduzione diretta: lo dico, e indico la zona della frase
  wordsShowAlign(tEl, { o: wordsZone(ti, tTok.length, oTok.length), how: "zone" });
}

// Una sola richiesta per frase: allineamento parola per parola e modi di dire dell'originale
const wordsAlignFailed = new Map();   // frase → quando è fallita (non riprovo subito, per non consumare quota)
function wordsAskAlign(cur) {
  if (!cur || !cur.text || !cur.trans || !wordsLlmAvailable()) return;
  const key = cur.text + "\u0001" + cur.trans;
  if (wordsAlignCache.has(key) || wordsAlignAsked.has(key)) return;
  if (Date.now() - (wordsAlignFailed.get(key) || 0) < 60000) return;
  // insieme a questa frase chiedo anche le prossime già tradotte (una richiesta ogni 8 frasi invece di una per frase)
  const more = dsUpcomingLines(cur, 7).filter((x) => {
    const k = x.text + "\u0001" + x.trans;
    return !wordsAlignCache.has(k) && !wordsAlignAsked.has(k);
  });
  const keys = [key, ...more.map((x) => x.text + "\u0001" + x.trans)];
  keys.forEach((k) => wordsAlignAsked.add(k));
  const items = [{ original: cur.text, translation: cur.trans }, ...more.map((x) => ({ original: x.text, translation: x.trans }))];
  const e = wordsDefineEngine();
  const done = (ok) => {
    keys.forEach((k) => wordsAlignAsked.delete(k));   // (se la frase esce dalla memoria si potrà richiedere)
    if (!ok) {
      wordsAlignFailed.set(key, Date.now());
      if (wordsAlignFailed.size > 300) wordsAlignFailed.delete(wordsAlignFailed.keys().next().value);
    }
    const same = !!wordsCurrent && wordsCurrent.text + "\u0001" + wordsCurrent.trans === key;
    if (same && ok) wordsMarkParticles();
    const hovered = lineTrans && lineTrans.querySelector(".dualsub-tword:hover");
    // ridisegno l'etichetta: con le coppie del modello, oppure (se è fallito) con Google
    if (hovered && same && !wordsCompare) wordsAlignHover(hovered);
  };
  DS_EXT.runtime.sendMessage({ type: "align", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl,
    original: cur.text, translation: cur.trans, items, lang: cur.lang || "", target: settings.targetLang })
    .then((r) => {
      if (!(r && r.pairs)) {
        if (r && r.daily) dsMarkBlocked(e.id);
        return done(false);
      }
      const res = r.results || [{ pairs: r.pairs, idioms: r.idioms }];
      res.forEach((x, i) => {
        if (!x || !x.pairs || !x.pairs.length || !keys[i]) return;
        wordsAlignCache.set(keys[i], x.pairs);
        wordsAddIdioms(items[i].original, x.idioms || []);
      });
      while (wordsAlignCache.size > 400) wordsAlignCache.delete(wordsAlignCache.keys().next().value);
      done(true);
    }).catch(() => done(false));
}

// ---------- Modi di dire ----------
// Modi di dire segnalati da te: { "testo normalizzato": { bad: true } | { meaning: "corretto" } } (restano salvati)
let wordsIdiomFlags = {};
DS_EXT.storage.local.get({ idiomFlags: {} }).then((r) => { wordsIdiomFlags = r.idiomFlags || {}; }).catch(() => {});
const wordsIdiomKey = (t) => wordsSplit(t).join(" ");
async function wordsIdiomFlag(text, patch) {
  const k = wordsIdiomKey(text);
  if (!k) return;
  if (patch) wordsIdiomFlags[k] = { ...(wordsIdiomFlags[k] || {}), ...patch, at: Date.now() }; else delete wordsIdiomFlags[k];
  const keys = Object.keys(wordsIdiomFlags);
  for (const x of keys.slice(0, Math.max(0, keys.length - 2000))) delete wordsIdiomFlags[x];
  await DS_EXT.storage.local.set({ idiomFlags: wordsIdiomFlags }).catch(() => {});
  wordsMarkIdioms();
}
const wordsIdiomBad = (t) => !!(wordsIdiomFlags[wordsIdiomKey(t)] || {}).bad;
const wordsIdiomMeaning = (t, m) => (wordsIdiomFlags[wordsIdiomKey(t)] || {}).meaning || m || "";
// un "modo di dire" che è quasi tutta la frase (o molto lungo) è un errore del modello: non lo sottolineo
function wordsIdiomPlausible(expr, sentence) {
  const e = wordsSplit(expr), all = wordsSplit(sentence);
  if (e.length < 2 || e.length > 7) return false;
  if (all.length >= 3 && e.length >= Math.max(3, Math.ceil(all.length * 0.75))) return false;
  return !wordsIdiomBad(expr);
}

function wordsAddIdioms(text, list) {
  const have = wordsIdioms.get(text) || [];
  for (const it of list) {
    if (!it || !String(it.text || "").trim()) continue;
    if (!wordsIdiomPlausible(it.text, text)) continue;
    const k = wordsNorm(it.text);
    const old = have.find((x) => wordsNorm(x.text) === k);
    if (old) { if (!old.meaning && it.meaning) old.meaning = it.meaning; }
    else have.push({ text: String(it.text).trim(), meaning: String(it.meaning || "") });
  }
  wordsIdioms.set(text, have);
  if (wordsIdioms.size > 300) wordsIdioms.delete(wordsIdioms.keys().next().value);
  if (wordsCurrent && wordsCurrent.text === text) wordsMarkIdioms();
}

// Posizione di un'espressione tra le parole della frase mostrata (indici delle parole)
function wordsFindExpr(text) {
  if (!lineOrig) return [];
  const oSpans = [...lineOrig.querySelectorAll(".dualsub-word")];
  return wordsLocate(oSpans.map((s) => wordsNorm(s.textContent)), text, 0).map((k) => oSpans[k]).filter(Boolean);
}

function wordsMarkIdioms() {
  if (!lineOrig || !wordsCurrent) return;
  lineOrig.querySelectorAll(".dualsub-idiom").forEach((s) => { s.classList.remove("dualsub-idiom"); delete s.dataset.idiom; });
  if (settings && settings.idioms === false) return;
  (wordsIdioms.get(wordsCurrent.text) || []).forEach((it, n) => {
    if (!wordsIdiomPlausible(it.text, wordsCurrent.text)) return;
    const spans = wordsFindExpr(it.text);
    if (spans.length < 2 || spans.length > wordsSplit(it.text).length + 1) return;
    spans.forEach((s) => { if (s.dataset.idiom == null) { s.classList.add("dualsub-idiom"); s.dataset.idiom = String(n); } });
  });
}

// L'espressione a cui appartiene una parola sottolineata
function wordsIdiomOf(w) {
  if (!w || w.dataset.idiom == null || !wordsCurrent) return null;
  const it = (wordsIdioms.get(wordsCurrent.text) || [])[Number(w.dataset.idiom)];
  if (!it) return null;
  const spans = wordsFindExpr(it.text);
  return spans.length ? { text: wordsRangeText(spans), meaning: wordsIdiomMeaning(it.text, it.meaning), spans, fromWord: w.textContent.trim(), idiom: true } : null;
}

function wordsRangeText(spans) {
  try {
    const r = document.createRange();
    r.setStartBefore(spans[0]);
    r.setEndAfter(spans[spans.length - 1]);
    return r.toString().replace(/\s+/g, " ").trim();
  } catch { return spans.map((s) => s.textContent).join(" "); }
}

function wordsPaint(cls, spans) {
  if (!overlay) return;
  overlay.querySelectorAll("." + cls).forEach((x) => x.classList.remove(cls));
  (spans || []).forEach((s) => s.classList.add(cls));
}

// Selezione a mano: tieni premuto sulla prima parola e trascina fino all'ultima
function wordsSelSpans() {
  if (!wordsSel || !lineOrig) return [];
  const all = [...lineOrig.querySelectorAll(".dualsub-word")];
  const a = Math.min(wordsSel.start, wordsSel.end), b = Math.max(wordsSel.start, wordsSel.end);
  return all.slice(a, b + 1);
}

function wordsTSelSpans() {
  if (!wordsTSel || !lineTrans) return [];
  const all = [...lineTrans.querySelectorAll(".dualsub-tword")];
  const a = Math.min(wordsTSel.start, wordsTSel.end), b = Math.max(wordsTSel.start, wordsTSel.end);
  return all.slice(a, b + 1);
}

function wordsEndCompare() {
  wordsCompare = null;
  wordsPaint("dualsub-tsel", []);
  wordsClearAlign();
}

// Parte della traduzione selezionata → la parte corrispondente dell'originale, illuminata e scritta nell'etichetta
async function wordsCompareShow(tSpans) {
  const cur = wordsCurrent;
  if (!cur || !cur.trans || !tSpans.length) return;
  const key = cur.text + "\u0001" + cur.trans;
  wordsCompare = { key, tSpans };
  wordsPaint("dualsub-tsel", tSpans);
  const all = [...lineTrans.querySelectorAll(".dualsub-tword")];
  const oSpans = [...lineOrig.querySelectorAll(".dualsub-word")];
  const oTok = oSpans.map((s) => wordsNorm(s.textContent));
  const show = (idx, how) => {
    if (!wordsCompare || wordsCompare.key !== key) return;
    idx = [...new Set(idx)].sort((a, b) => a - b);
    // senza buchi: dalla prima all'ultima parola trovata (una frase si confronta per intero)
    const span = idx.length ? oSpans.slice(idx[0], idx[idx.length - 1] + 1) : [];
    const hit = wordsShowAlign(tSpans[Math.floor(tSpans.length / 2)], { o: span.map((s) => oSpans.indexOf(s)), how: how === "zone" ? "zone" : how });
    tSpans.forEach((t) => t.classList.add("dualsub-hl"));
    if (!wordsAlignTip) return;
    wordsAlignTip.textContent = "";
    if (how === "wait" || !hit.length) {
      wordsAlignTip.append(el("span", null, "Cerco la parte corrispondente nell'originale…"));
      return;
    }
    wordsAlignTip.append(el("b", null, wordsRangeText(hit)));
    const more = el("button", "dualsub-tip-btn", "Spiega");
    more.title = "Apri la scheda con il significato di questa parte dell'originale";
    more.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const spans = hit;
      wordsEndCompare();
      wordsOpenCard(spans[Math.floor(spans.length / 2)], true, { text: wordsRangeText(spans), spans });
    });
    const cp = el("button", "dualsub-tip-btn", "Copia");
    cp.title = "Copia la parte originale e la parte della traduzione scelta";
    cp.addEventListener("click", (ev) => { ev.stopPropagation(); wordsCopy(wordsRangeText(hit) + "\n" + wordsRangeText(tSpans), cp); });
    wordsAlignTip.append(el("span", null, how === "zone" ? "  ·  zona corrispondente, circa  " : how === "google" ? "  ·  circa  " : "  "), more, el("span", null, " "), cp);
    const src = (cur.lang || "").split("-")[0] || DualSubs.guessLang(cur.text) || "";
    wordsAlignTip.append(wordsLinksRow(() => wordsRangeText(hit), src, settings.targetLang, hit.length <= 3));
  };
  const tIdx = tSpans.map((t) => all.indexOf(t));
  // con Google: per ogni parola scelta, la parola dell'originale che la traduce
  const viaGoogle = async (list) => {
    const out = [];
    for (const i of list) out.push(...(await wordsGoogleFind(cur, i, all, oSpans)));
    return out;
  };
  // 1) allineamento del modello già pronto (o in arrivo)
  const fromPairs = async () => {
    const pairs = wordsAlignCache.get(key);
    if (!pairs) return null;
    const map = wordsAlignMap(all.map((s) => wordsNorm(s.textContent)), oTok, pairs);
    const known = tIdx.filter((i) => map.has(i) && map.get(i).how !== "lost");
    const lost = tIdx.filter((i) => !known.includes(i));
    const idx = known.flatMap((i) => map.get(i).o);
    if (lost.length) idx.push(...(await viaGoogle(lost)));
    return { idx, how: lost.length ? "google" : "model" };
  };
  let got = await fromPairs();
  if (got && got.idx.length) return show(got.idx, got.how);
  show([], "wait");
  if (!got && wordsLlmAvailable()) {
    wordsAskAlign(cur);
    for (let i = 0; i < 40 && wordsCompare && wordsCompare.key === key && wordsAlignPending(key); i++) {
      await new Promise((r) => setTimeout(r, 500));
      if (!wordsAlignCache.has(key)) continue;
      got = await fromPairs();
      if (got && got.idx.length) return show(got.idx, got.how);
      break;
    }
    if (!got && wordsAlignCache.has(key)) {
      got = await fromPairs();
      if (got && got.idx.length) return show(got.idx, got.how);
    }
  }
  // 2) con Google (gratis): le parole dell'originale che traducono quelle scelte
  if (!wordsCompare || wordsCompare.key !== key) return;
  const idx = await viaGoogle(tIdx);
  if (!wordsCompare || wordsCompare.key !== key) return;
  if (idx.length) return show(idx, "google");
  // 3) nessuna traduzione diretta: la zona corrispondente della frase
  const nT = all.length, nO = oTok.length;
  const lo = wordsGuessAt(Math.min(...tIdx), nT, nO), hi = wordsGuessAt(Math.max(...tIdx), nT, nO);
  const zone = [];
  for (let i = lo; i <= hi; i++) zone.push(i);
  show(zone, "zone");
}

function wordsEndTSelect() {
  if (!wordsTSel) return false;
  const spans = wordsTSel.moved ? wordsTSelSpans() : [];
  wordsTSel = null;
  if (spans.length < 2) { if (!wordsCompare) wordsPaint("dualsub-tsel", []); return false; }
  wordsNoClickUntil = Date.now() + 300;
  wordsCompareShow(spans);
  return true;
}

function wordsEndSelect() {
  if (wordsEndTSelect()) return;
  if (!wordsSel) return;
  const spans = wordsSel.moved ? wordsSelSpans() : [];
  wordsSel = null;
  if (spans.length < 2) { if (!(wordsCardState && wordsCardState.expr)) wordsPaint("dualsub-sel", []); return; }
  wordsNoClickUntil = Date.now() + 300;
  wordsOpenCard(spans[Math.floor(spans.length / 2)], true, { text: wordsRangeText(spans), spans });
}

// Al contrario: parola dell'originale → la sua traduzione (solo se la frase è già allineata)
function wordsReverseHover(oEl) {
  const cur = wordsCurrent;
  if (!cur || !cur.trans) return;
  const pairs = wordsAlignCache.get(cur.text + "\u0001" + cur.trans);
  if (!pairs) return;
  const tSpans = [...lineTrans.querySelectorAll(".dualsub-tword")];
  const oSpans = [...lineOrig.querySelectorAll(".dualsub-word")];
  const map = wordsAlignMap(tSpans.map((s) => wordsNorm(s.textContent)), oSpans.map((s) => wordsNorm(s.textContent)), pairs);
  const oi = oSpans.indexOf(oEl);
  overlay.querySelectorAll(".dualsub-tword.dualsub-hl, .dualsub-tword.dualsub-hl-group").forEach((x) => x.classList.remove("dualsub-hl", "dualsub-hl-group"));
  for (const [ti, e] of map) {
    if (!e.o.includes(oi)) continue;
    // la traduzione vera piena, le particelle che la accompagnano più tenui
    if (e.how === "model") tSpans[ti].classList.add("dualsub-hl");
    else if (e.how === "particle") tSpans[ti].classList.add("dualsub-hl-group");
  }
}

function wordsRenderOriginal(text, lang) {
  const knownOn = settings && settings.learnKnown !== false && settings.learnKnownPage !== false && typeof DS_KNOWN !== "undefined";
  const romanOn = !!(settings && settings.roman && typeof DS_ROMAN !== "undefined" && DS_ROMAN.needs(text));
  const key = text + "\u0001" + vocabVersion + "\u0001" + (knownOn ? DS_KNOWN.version : "") + "\u0001" + (romanOn ? "r" + (settings.romanHan !== false ? "h" : "") : "");
  if (key === wordsOrigKey) return;
  wordsOrigKey = key;
  lineOrig.textContent = "";
  if (!text) return;
  for (const part of wordsTokenize(text, lang)) {
    if (!part.word) { lineOrig.append(part.text); continue; }
    const span = document.createElement("span");
    span.className = "dualsub-word" + (vocabForms.has(part.text.toLowerCase()) ? " dualsub-saved" : "") +
      (knownOn && DS_KNOWN.has((lang || "").split("-")[0], dsCleanWord(part.text)) ? " dualsub-known" : "");
    if (romanOn) wordsRomanize(span, part.text, lang); else span.textContent = part.text;
    lineOrig.append(span);
  }
  lineOrig.classList.toggle("dualsub-roman", romanOn);
  if (romanOn && DS_ROMAN.rtl(text)) lineOrig.dir = "rtl"; else lineOrig.removeAttribute("dir");
  wordsRomanLine(romanOn && settings.romanHan !== false && DS_ROMAN.hasHan(text) ? text : "", lang);
  wordsMarkIdioms();
  wordsMarkParticles();
}

// ---------- Lettere latine sopra le lettere (DS_ROMAN, roman.js): si accende e spegne con "Aa" accanto ai sottotitoli ----------
// La trascrizione è disegnata dal CSS (attributo data-r), quindi non entra nel testo copiato né nelle ricerche.
function wordsRomanize(span, word, lang) {
  span.textContent = "";
  if (DS_ROMAN.rtl(word)) span.dir = "rtl";
  for (const u of DS_ROMAN.units(word, lang)) {
    const x = document.createElement("span");
    x.className = "dsr" + (u.han ? " dsr-han" : "");
    x.dataset.r = u.r || "";
    x.textContent = u.t;
    span.append(x);
  }
}
// righe con kanji o caratteri cinesi: la lettura di tutta la riga (Google, gratis), sopra il sottotitolo
let wordsRomanLineText = "";
function wordsRomanLine(text, lang) {
  let row = overlay && overlay.querySelector(".dualsub-romaline");
  if (!text) { if (row) row.hidden = true; wordsRomanLineText = ""; return; }
  if (!row) { row = document.createElement("div"); row.className = "dualsub-romaline"; lineOrig.before(row); }
  if (wordsRomanLineText === text) { row.hidden = !row.textContent; return; }
  wordsRomanLineText = text;
  row.textContent = ""; row.hidden = true;
  DS_EXT.runtime.sendMessage({ type: "romanLine", text, lang }).then((r) => {
    if (wordsRomanLineText !== text || !r || !r.text) return;
    row.textContent = r.text; row.hidden = false;
    row.title = "Lettura della riga (Google, gratis): i kanji e i caratteri cinesi hanno più letture, quindi non c'è sopra ogni carattere";
  }).catch(() => {});
}
function wordsRomanButton() {
  const b = document.createElement("button");
  b.className = "dualsub-fixbtn dualsub-romabtn";
  b.textContent = "Aa";
  b.addEventListener("click", async (e) => {
    e.stopPropagation();
    settings.roman = !settings.roman;
    wordsOrigKey = "";
    if (wordsCurrent) wordsRenderOriginal(wordsCurrent.text, wordsCurrent.lang);
    wordsRomanButtonUpdate();
    await DS_EXT.storage.sync.set({ roman: settings.roman });
  });
  return b;
}
function wordsRomanButtonUpdate() {
  const b = overlay && overlay.querySelector(".dualsub-romabtn");
  if (!b) return;
  const on = !!(settings && settings.roman);
  b.classList.toggle("on", on);
  b.setAttribute("aria-pressed", String(on));
  b.title = on ? "Lettere latine sopra le parole: accese (clic per spegnerle)" : "Lettere latine sopra le parole (cirillico, greco, arabo, ebraico, giapponese, coreano, hindi…): clic per accenderle";
  b.hidden = !(wordsCurrent && typeof DS_ROMAN !== "undefined" && DS_ROMAN.needs(wordsCurrent.text));
}

// ---------- Eventi del mouse sui sottotitoli ----------
function wordsSetup() {
  // I clic sui sottotitoli non devono arrivare al player (che metterebbe in pausa/play)
  for (const type of ["click", "dblclick", "mousedown", "mouseup", "pointerdown", "pointerup", "touchstart"]) {
    overlay.addEventListener(type, (e) => e.stopPropagation());
  }
  overlay.addEventListener("mousedown", (e) => {
    const tw = e.button === 0 && e.target.closest && e.target.closest(".dualsub-tword");
    if (tw) {
      // selezione di più parole della traduzione, per confrontarle con l'originale
      e.preventDefault();
      if (wordsCompare) wordsEndCompare();
      const i = [...lineTrans.querySelectorAll(".dualsub-tword")].indexOf(tw);
      wordsTSel = { start: i, end: i, moved: false };
      return;
    }
    if (wordsCompare && !(e.target.closest && e.target.closest(".dualsub-align-tip"))) wordsEndCompare();
    const w = e.button === 0 && e.target.closest && e.target.closest(".dualsub-word");
    if (!w) return;
    e.preventDefault();   // niente selezione del testo del browser
    const i = [...lineOrig.querySelectorAll(".dualsub-word")].indexOf(w);
    wordsSel = { start: i, end: i, moved: false };
  });
  overlay.addEventListener("mouseup", wordsEndSelect);
  overlay.addEventListener("mouseover", (e) => {
    clearTimeout(wordsLeaveTimer);
    if (!wordsHovering) {
      wordsHovering = true;
      const v = getVideo();
      if (settings && settings.hoverPause && v && !v.paused && !wordsReplayUntil) { v.pause(); wordsAutoPaused = true; }
    }
    const w = e.target.closest && e.target.closest(".dualsub-word");
    const tw = e.target.closest && e.target.closest(".dualsub-tword");
    clearTimeout(wordsHoverTimer);
    // ti fermi sulle parole dell'originale: chiedo i modi di dire della frase (insieme all'allineamento, una richiesta).
    // Solo dopo un attimo, così passare sopra per andare al pulsante delle correzioni non consuma richieste.
    clearTimeout(wordsIdiomTimer);
    if (w && settings && settings.idioms !== false) wordsIdiomTimer = setTimeout(() => wordsAskAlign(wordsCurrent), 700);
    if (w && wordsCurrent && (!wordsReading || wordsReading.text !== wordsCurrent.text)) wordsMarkReading(wordsCurrent);
    if (wordsSel && w) {
      if (!(e.buttons & 1)) { wordsSel = null; }
      else {
        const i = [...lineOrig.querySelectorAll(".dualsub-word")].indexOf(w);
        if (i !== wordsSel.end) { wordsSel.end = i; wordsSel.moved = wordsSel.moved || i !== wordsSel.start; }
        wordsPaint("dualsub-sel", wordsSelSpans());
        return;
      }
    }
    const idiom = w ? wordsIdiomOf(w) : null;
    wordsPaint("dualsub-idiom-on", idiom ? idiom.spans : []);
    if (w && !(wordsCardState && wordsCardState.pinned)) {
      wordsHoverTimer = setTimeout(() => wordsOpenCard(w, false, idiom), 300);
    }
    if (w) wordsReverseHover(w);
    if (wordsTSel && tw && (e.buttons & 1)) {
      const i = [...lineTrans.querySelectorAll(".dualsub-tword")].indexOf(tw);
      if (i !== wordsTSel.end) { wordsTSel.end = i; wordsTSel.moved = wordsTSel.moved || i !== wordsTSel.start; }
      wordsPaint("dualsub-tsel", wordsTSelSpans());
      return;
    }
    if (wordsCompare) return;   // confronto aperto: resta finché non clicchi altrove
    if (tw) { clearTimeout(wordsAlignTimer); wordsAlignTimer = setTimeout(() => wordsAlignHover(tw), 180); }
    else if (!w) wordsClearAlign();
  });
  overlay.addEventListener("mouseout", (e) => {
    const from = e.target.closest && e.target.closest(".dualsub-tword, .dualsub-word");
    const to = e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest(".dualsub-tword, .dualsub-word");
    if (from && from !== to && !wordsCompare) wordsClearAlign();
    if (from && !(to && to.dataset.idiom != null && to.dataset.idiom === from.dataset.idiom)) wordsPaint("dualsub-idiom-on", []);
  });
  overlay.addEventListener("mouseout", (e) => {
    if (e.relatedTarget && overlay.contains(e.relatedTarget)) return;
    clearTimeout(wordsHoverTimer);
    clearTimeout(wordsIdiomTimer);
    wordsLeaveTimer = setTimeout(wordsOnLeave, 400);
  });
  overlay.addEventListener("click", (e) => {
    if (Date.now() < wordsNoClickUntil) return;   // fine di una selezione a mano
    const w = e.target.closest && e.target.closest(".dualsub-word");
    if (w) {
      // parola dentro un modo di dire: il primo clic apre l'espressione, il secondo (con l'espressione già aperta)
      // apre la parola da sola; e di nuovo l'espressione al clic dopo
      const st = wordsCardState;
      const idiom = wordsIdiomOf(w);
      const inOpenIdiom = idiom && st && st.pinned && st.expr && st.expr.idiom && (st.expr.spans || []).includes(w);
      wordsOpenCard(w, true, inOpenIdiom ? null : idiom);
    }
    // clic su una parola della traduzione: scheda della parola originale corrispondente
    const tw = e.target.closest && e.target.closest(".dualsub-tword");
    if (tw) {
      // se la parte corrispondente ha più parole, apro la più lunga (di solito quella che porta il significato)
      const hl = [...lineOrig.querySelectorAll(".dualsub-word.dualsub-hl")];
      const o = hl.reduce((a, b) => (!a || b.textContent.length > a.textContent.length ? b : a), null);
      if (o) { wordsClearAlign(); wordsOpenCard(o, true); }
    }
  });
}

function wordsOnLeave() {
  wordsHovering = false;
  if (wordsCardState && wordsCardState.pinned) return;
  wordsCloseCard();
}

function wordsResume() {
  if (wordsAutoPaused) {
    wordsAutoPaused = false;
    const v = getVideo();
    if (v && v.paused) v.play().catch(() => {});
  }
}

// Se la scheda sparisce sotto il mouse, il browser non segnala l'uscita dai sottotitoli:
// me ne accorgo quando il mouse passa su qualcos'altro della pagina
document.addEventListener("mouseover", (e) => {
  // il mouse è sopra la scheda anche se un altro elemento della pagina la copre: non la chiudo
  if (wordsCard && wordsCard.isConnected) {
    const r = wordsCard.getBoundingClientRect();
    if (e.clientX >= r.left - 4 && e.clientX <= r.right + 4 && e.clientY >= r.top - 4 && e.clientY <= r.bottom + 4) { clearTimeout(wordsLeaveTimer); return; }
  }
  if (wordsHovering && overlay && !overlay.contains(e.target)) {
    clearTimeout(wordsLeaveTimer);
    wordsLeaveTimer = setTimeout(wordsOnLeave, 400);
  }
}, true);

document.addEventListener("mouseup", () => wordsEndSelect(), true);
document.addEventListener("mousedown", (e) => {
  if (wordsCardState && wordsCardState.pinned && overlay && !overlay.contains(e.target)) wordsCloseCard();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && wordsCompare) wordsEndCompare();
  if (e.key === "Escape" && wordsCardState) wordsCloseCard();
});

// ---------- Scheda della parola ----------
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

function wordsCloseCard() {
  wordsReqId++;
  wordsCardState = null;
  if (wordsCard) { wordsCard.remove(); wordsCard = null; }
  if (overlay) overlay.classList.remove("dualsub-cardopen");
  wordsPaint("dualsub-sel", []);
  if (!wordsHovering) wordsResume();
}

function wordsPlace(anchor) {
  const player = dsPlayerBox();
  if (!wordsCard || !player || !anchor.isConnected) return;
  const pr = player.getBoundingClientRect(), or = overlay.getBoundingClientRect(), wr = anchor.getBoundingClientRect();
  const cw = wordsCard.offsetWidth || 300;
  let center = wr.left + wr.width / 2 - pr.left;
  center = Math.max(cw / 2 + 8, Math.min(pr.width - cw / 2 - 8, center));
  wordsCard.style.left = center + pr.left - or.left + "px";
  wordsCard.style.bottom = or.height + 10 + "px";
  wordsCard.style.maxHeight = Math.max(120, or.top - pr.top - 20) + "px";
}

// Passando il mouse: significato veloce dal dizionario di Google (gratis, nessun limite di richieste).
// Cliccando: spiegazione nel contesto con il servizio scelto (Gemini, Groq, Claude…), una richiesta sola.
// expr = espressione di più parole (modo di dire riconosciuto o selezione a mano): { text, meaning, spans, fromWord }
function wordsOpenCard(wordEl, pinned, expr) {
  if (!wordsCurrent || !overlay) return;
  const word = dsCleanWord(expr ? expr.text : wordEl.textContent.trim());
  if (!word) return;
  // un kanji/carattere aperto dalla scheda della parola: solo Google e dizionari gratuiti (niente richiesta al modello)
  const contextual = pinned && wordsLlmAvailable() && !(expr && expr.han);
  if (wordsCardState && wordsCardState.word === word && wordsCard) {
    wordsCardState.pinned = wordsCardState.pinned || pinned;
    if (contextual && !wordsCardState.contextual) {
      wordsCardState.contextual = true;
      // intanto resta il significato di Google: la spiegazione del modello lo sostituisce appena arriva
      if (wordsCardState.data && !wordsCardState.data.error) wordsCardState.quick = wordsCardState.data;
      wordsCardState.data = null;
      wordsFillCard();
      wordsLoadDefinition(word, wordsCardState.sentence, wordEl, true);
    }
    return;
  }
  if (wordsCard) wordsCard.remove();
  const sentence = wordsCurrent;
  wordsMarkReading(sentence);
  wordsCardState = { pinned, word, sentence, data: null, contextual, expr: expr || null, anchor: wordEl };
  // carattere aperto dalla scheda della parola: subito il significato già trovato, poi arriva quello di Google
  if (expr && expr.quick) wordsCardState.quick = expr.quick;
  wordsPaint("dualsub-sel", expr ? expr.spans : []);
  wordsCard = el("div", "dualsub-card");
  overlay.append(wordsCard);
  // con la scheda aperta i sottotitoli stanno sopra i comandi del lettore (titolo e pulsanti in alto di YouTube):
  // prima la parte alta della scheda finiva sotto di loro e, passandoci col mouse, la scheda si chiudeva
  overlay.classList.add("dualsub-cardopen");
  // modo di dire già spiegato dal modello (nella richiesta dell'allineamento): nessuna richiesta in più
  if (expr && expr.meaning && (!contextual || expr.preset)) {
    wordsCardState.contextual = false;   // un clic sull'espressione chiede poi la spiegazione completa
    wordsCardState.data = { meaning: expr.meaning, source: wordsDefineEngine().E.label.split(" (")[0].split(",")[0] + " · modo di dire", lang: sentence.lang || "" };
    wordsFillCard();
    wordsPlace(wordEl);
    return;
  }
  wordsFillCard();
  wordsPlace(wordEl);
  wordsLoadDefinition(word, sentence, wordEl, contextual);
}

// la parola della scheda nel sottotitolo: se la riga è stata ridisegnata (per esempio dopo «la conosco?»)
// la ritrovo dal testo
function wordsAnchorOf(st) {
  if (st.anchor && st.anchor.isConnected) return st.anchor;
  const w = st.expr && st.expr.han ? st.expr.fromWord : st.word;
  const a = lineOrig && [...lineOrig.querySelectorAll(".dualsub-word")].find((x) => dsCleanWord(x.textContent.trim()) === w);
  if (a) st.anchor = a;
  return a || null;
}

function wordsLlmAvailable() {
  const e = wordsDefineEngine();
  return (e.E.kind === "openai" || e.E.kind === "claude") && (!e.E.needsKey || !!e.key) && !!(e.model || e.E.defaultModel);
}

function wordsFillCard() {
  const st = wordsCardState;
  if (!wordsCard || !st) return;
  const llmWait = !st.data && st.contextual && !!st.quick;
  const d = st.data || st.quick || null;
  wordsCard.textContent = "";

  const head = el("div", "dualsub-card-head");
  const title = el("div", "dualsub-card-title");
  title.append(el("span", "dualsub-card-word", st.word));
  if (d && d.lemma && d.lemma.toLowerCase() !== st.word.toLowerCase()) title.append(el("span", "dualsub-card-lemma", "→ " + d.lemma));
  if (d && d.pos) title.append(el("span", "dualsub-card-pos", d.pos));
  head.append(title);

  const lang = wordsSpeechLang();
  // 🔈 = voce sintetica (sempre); accanto 🔊 = registrazione di una persona (Wiktionary), quando c'è
  const hasLearn = typeof DS_LEARN !== "undefined" && (!st.expr || st.expr.han) && wordsSplit(st.word).length === 1;
  st.learn = st.learn || {};
  const rec = hasLearn && DS_LEARN.recordingOf(st.learn, st.word, settings);
  const speak = el("button", "dualsub-card-btn dualsub-speak", "🔈");
  if (lang) speak.append(el("span", "dualsub-speak-lang", DS_TTS.base(lang).toUpperCase()));
  speak.title = lang ? `Ascolta la pronuncia con la voce sintetica (${lang}). La lingua si può cambiare nel popup.` : "Ascolta la pronuncia (voce sintetica)";
  speak.addEventListener("click", async () => {
    const restore = wordsDuck();
    try {
      const r = await DS_TTS.speak(st.word, wordsSpeechLang(), { lang: settings.ttsLang, voice: settings.ttsVoice });
      speak.title = "Pronuncia: " + r.how;
      await Promise.race([r.done, new Promise((ok) => setTimeout(ok, 10000))]);
    } catch {}
    restore();
  });
  let recBtn = null;
  if (rec) {
    const lb = DS_LEARN.recordingLabel(st.learn, st.word, settings);
    recBtn = el("button", "dualsub-card-btn dualsub-speak dualsub-rec" + (lb && lb.form ? " dsx-recform" : ""), lb && lb.form ? "🔊*" : "🔊");
    recBtn.title = lb ? lb.title : "Ascolta la registrazione di un madrelingua (Wiktionary)";
    recBtn.addEventListener("click", async () => {
      const restore = wordsDuck();
      try {
        const r = await DS_LEARN.playUrl(rec, null);
        if (r) await Promise.race([r.done, new Promise((ok) => setTimeout(ok, 10000))]);
        else recBtn.textContent = "✕";
      } catch {}
      restore();
    });
  }
  const star = el("button", "dualsub-card-btn dualsub-star", "☆");
  star.title = "Salva nel vocabolario";
  star.addEventListener("click", () => wordsSave());
  const close = el("button", "dualsub-card-btn", "×");
  close.title = "Chiudi";
  close.addEventListener("click", wordsCloseCard);
  // ⚙: voce per questa lingua (resta salvata)
  const gear = el("button", "dualsub-card-btn dualsub-voicegear", "⚙");
  gear.title = "Scegli la voce per questa lingua";
  gear.addEventListener("click", (ev) => {
    ev.stopPropagation();
    st.voiceMenu = !st.voiceMenu;
    wordsFillCard();
  });
  // Anki: niente pulsante a parte; con "Manda ad Anki quando salvi con ☆" (popup → Anki) la stella fa anche quello
  star.title = settings.ankiAuto ? "Salva nel vocabolario (e manda ad Anki)" : "Salva nel vocabolario";
  head.append(...(recBtn ? [recBtn] : []), speak, gear, star, close);
  wordsCard.append(head);
  if (llmWait) wordsCard.append(el("div", "dualsub-card-hint", "Chiedo a " + wordsDefineEngine().E.label.split(" (")[0].split(",")[0] + " la spiegazione nel contesto…"));
  if (st.voiceMenu && typeof DS_TTS.voiceMenu === "function") {
    const vl = wordsSpeechLang() || lang;
    wordsCard.append(DS_TTS.voiceMenu(vl, () => { st.voiceMenu = false; if (wordsCardState === st && wordsCard) { wordsFillCard(); const b = wordsCard.querySelector(".dualsub-speak:not(.dualsub-rec)"); if (b) b.click(); } }));
  }
  wordsCardIpa(st, d);

  if (!d) {
    wordsCard.append(el("div", "dualsub-card-loading", "Cerco il significato…"));
  } else if (d.error) {
    wordsCard.append(el("div", "dualsub-card-error", d.error));
  } else {
    if (d.untranslated) {
      wordsCard.append(el("div", "dualsub-card-expl", "Google non ha una traduzione per questa parola da sola (spesso è un nome, o un pezzo di un'espressione)." +
        (wordsLlmAvailable() && !st.contextual ? "" : "")));
    } else {
      const fx = wordsWordFix(st, d);
      wordsCard.append(el("div", "dualsub-card-meaning", (fx || d.meaning || "—") + (fx ? " ✎" : "")));
    }
    // ⚑ significato sbagliato: rifarlo con Google o con il modello, o correggerlo a mano (come in Parole al Volo)
    if (!st.expr || !st.expr.idiom) wordsCard.append(wordsMeaningFixRow(st, d));
    // modo di dire (sottolineato dal modello): si può segnalare, correggere o ricontrollare
    if (st.expr && st.expr.idiom && wordsSplit(st.word).length > 1) wordsCard.append(wordsIdiomFixRow(st, st.word, d.meaning));
    // le traduzioni del dizionario di Google compaiono già (ordinate, con il peso) negli strumenti per imparare
    const gdShown = (!st.contextual || llmWait) && settings.gdAlt !== false && d.gdict && d.gdict.alt && d.gdict.alt.length && typeof DS_LEARN !== "undefined";
    if (d.explanation && !gdShown) wordsCard.append(el("div", "dualsub-card-expl", d.explanation));
    // la parola cliccata fa parte di un modo di dire: lo segnalo e lo sottolineo nella frase
    if (!st.expr && d.expression && wordsNorm(d.expression) !== wordsNorm(st.word) && wordsSplit(d.expression).length > 1 && wordsIdiomPlausible(d.expression, st.sentence.text)) {
      const box = el("div", "dualsub-card-idiom");
      const em = wordsIdiomMeaning(d.expression, d.expressionMeaning);
      box.append(el("b", null, "Modo di dire: "), document.createTextNode(`«${d.expression}»` + (em ? " = " + em : "")));
      box.append(wordsIdiomFixRow(st, d.expression, em));
      const spans = wordsFindExpr(d.expression);
      if (spans.length > 1) {
        const go = el("button", "dualsub-card-link", "Mostra tutta l'espressione");
        go.addEventListener("click", () => wordsOpenCard(spans[Math.floor(spans.length / 2)], true,
          { text: wordsRangeText(spans), meaning: wordsIdiomMeaning(d.expression, d.expressionMeaning), spans, preset: true, idiom: true }));
        box.append(document.createElement("br"), go);
      }
      wordsCard.append(box);
    }
    if (st.contextual && d.sentenceTrans && st.sentence.trans && wordsNorm(d.sentenceTrans) !== wordsNorm(st.sentence.trans)) {
      const t = el("div", "dualsub-card-sentfix");
      t.append(el("b", null, "Frase: "), document.createTextNode(d.sentenceTrans), el("span", "dualsub-card-hint", " (" + String(d.source || "").split(" (")[0] + ")"));
      t.title = "Traduzione della frase intera fatta insieme alla spiegazione. Sotto il video: " + st.sentence.trans;
      wordsCard.append(t);
    }
    if (d.example) {
      const ex = el("div", "dualsub-card-example");
      ex.append(el("div", null, d.example));
      if (d.exampleTrans) ex.append(el("div", "dualsub-card-extrans", d.exampleTrans));
      wordsCard.append(ex);
    }
    wordsCardLearn(st, d);
    wordsCard.append(el("div", "dualsub-card-source", "Fonte: " + d.source + (d.checkNote ? " — " + d.checkNote : "")));
    const tools = el("div", "dualsub-copy-actions");
    const cp = el("button", "dualsub-card-replay", st.expr && !st.expr.han ? "Copia l'espressione" : "Copia la parola");
    cp.addEventListener("click", (ev) => { ev.stopPropagation(); wordsCopy(st.word, cp); });
    const cps = el("button", "dualsub-card-replay", "Copia la frase");
    cps.title = "Copia la frase originale e la sua traduzione";
    cps.addEventListener("click", (ev) => { ev.stopPropagation(); wordsCopy(st.sentence.text + (st.sentence.trans ? "\n" + st.sentence.trans : ""), cps); });
    tools.append(cp, cps);
    wordsCard.append(tools);
    const src = d.lang || (st.sentence.lang || "").split("-")[0] || DualSubs.guessLang(st.sentence.text) || "";
    wordsCard.append(wordsLinksRow(() => st.word, src, settings.targetLang, wordsSplit(st.word).length <= 3, st.expr ? "" : d.lemma));
    if (st.expr && st.expr.han) {
      // scheda di un solo kanji: si torna alla parola intera (senza una nuova richiesta al modello, se prima non c'era)
      const back = el("button", "dualsub-card-link", `‹ Torna alla parola «${st.expr.fromWord}»`);
      back.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const a = wordsAnchorOf(st), ctxl = st.expr.backContextual;
        wordsCloseCard();
        if (!a) return;
        wordsOpenCard(a, ctxl, null);
        if (wordsCardState) wordsCardState.pinned = true;
      });
      wordsCard.append(back);
    } else if (st.expr && st.expr.fromWord) {
      const only = el("button", "dualsub-card-link", `Solo la parola «${st.expr.fromWord}»`);
      only.title = "Oppure clicca di nuovo la parola nel sottotitolo";
      only.addEventListener("click", (ev) => { ev.stopPropagation(); const a = st.anchor; wordsCloseCard(); if (a && a.isConnected) wordsOpenCard(a, true, null); });
      wordsCard.append(only);
    }
    // parola da sola che fa parte di un modo di dire sottolineato: si torna all'espressione intera
    const idiomHere = !st.expr && st.anchor && st.anchor.isConnected ? wordsIdiomOf(st.anchor) : null;
    if (idiomHere) {
      const back = el("button", "dualsub-card-link", `Tutto il modo di dire «${idiomHere.text}» ›`);
      back.title = "Oppure clicca di nuovo la parola nel sottotitolo";
      back.addEventListener("click", (ev) => { ev.stopPropagation(); const a = st.anchor; wordsCloseCard(); if (a && a.isConnected) wordsOpenCard(a, true, wordsIdiomOf(a)); });
      wordsCard.append(back);
    }
    if (!st.contextual && wordsLlmAvailable() && !(st.expr && st.expr.han)) {
      const name = wordsDefineEngine().E.label.split(" (")[0].split(",")[0];
      wordsCard.append(el("div", "dualsub-card-hint", st.expr ? `Clicca l'espressione per la spiegazione nel contesto con ${name}.` : `Clicca la parola per la spiegazione nel contesto con ${name}.`));
    }
  }

  const replay = el("button", "dualsub-card-replay", "↺ Riascolta la frase");
  replay.addEventListener("click", () => wordsReplay(1, 1));
  const slow = el("button", "dualsub-card-replay dualsub-replay-small", "🐢 lenta");
  slow.title = "Riascolta la frase al 75% della velocità";
  slow.addEventListener("click", () => wordsReplay(0.75, 1));
  const loop = el("button", "dualsub-card-replay dualsub-replay-small", "🔁 ×3");
  loop.title = "Riascolta la frase tre volte di fila (per ripeterla insieme)";
  loop.addEventListener("click", () => wordsReplay(1, 3));
  const row = el("div", "dualsub-replay-row");
  row.append(replay, slow, loop);
  wordsCard.append(row);
  wordsRefreshStar();
}

// ⚑ significato della parola sbagliato: le correzioni a mano restano salvate per la stessa parola (in quella lingua)
let wordsFixes = {};
DS_EXT.storage.local.get({ wordFix: {} }).then((r) => { wordsFixes = r.wordFix || {}; }).catch(() => {});
DS_EXT.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.wordFix) wordsFixes = ch.wordFix.newValue || {}; });
function wordsFixKey(st, d) {
  const lang = ((d && d.lang) || st.sentence.lang || "").split("-")[0] || "?";
  return [lang, settings.targetLang, String(st.word).toLowerCase().trim()].join("|");
}
const wordsWordFix = (st, d) => wordsFixes[wordsFixKey(st, d)] || "";
async function wordsSetFix(st, d, value) {
  const k = wordsFixKey(st, d);
  if (value) wordsFixes[k] = value; else delete wordsFixes[k];
  const ks = Object.keys(wordsFixes);
  for (const x of ks.slice(0, Math.max(0, ks.length - 3000))) delete wordsFixes[x];
  await DS_EXT.storage.local.set({ wordFix: wordsFixes }).catch(() => {});
}
function wordsMeaningFixRow(st, d) {
  const row = el("div", "dualsub-idiom-fix");
  const fixed = wordsWordFix(st, d);
  const b = el("button", "dualsub-card-link", st.meanFix ? "chiudi" : "⚑ Traduzione sbagliata?");
  b.title = "Rifai la traduzione con Google o con il modello, oppure correggila a mano (resta salvata)";
  b.addEventListener("click", (ev) => { ev.stopPropagation(); st.meanFix = !st.meanFix; st.meanEdit = false; wordsFillCard(); });
  row.append(b);
  if (fixed) row.append(el("span", "dualsub-card-hint", " ✎ corretta da te"));
  if (!st.meanFix) return row;
  const box = el("div", "dualsub-idiom-fixbox");
  const btn = (label, title, fn) => { const x = el("button", "dualsub-card-replay dualsub-replay-small", label); x.title = title; x.addEventListener("click", (ev) => { ev.stopPropagation(); fn(); }); box.append(x); };
  // rifà la richiesta senza usare la risposta già salvata
  const redo = (contextual) => {
    const w = String(st.word).toLowerCase() + "|" + st.sentence.text + "|";
    for (const k of [...wordsDefCache.keys()]) if (k.startsWith(w)) wordsDefCache.delete(k);
    st.meanFix = false; st.data = null; st.quick = null; st.contextual = contextual;
    wordsFillCard();
    wordsLoadDefinition(st.word, st.sentence, st.anchor, contextual);
  };
  btn("↻ Rifai con Google", "Una nuova traduzione di Google (gratis)", () => redo(false));
  if (wordsLlmAvailable()) btn("Rifai con " + wordsDefineEngine().E.label.split(" (")[0].split(",")[0], "Significato nel contesto della frase (e la frase corretta, nella stessa richiesta): una richiesta", () => redo(true));
  btn("✎ Correggi a mano", "Scrivi tu il significato giusto: resta salvato per le prossime volte", () => { st.meanEdit = !st.meanEdit; wordsFillCard(); });
  if (fixed) btn("Togli la correzione", "", async () => { await wordsSetFix(st, d, ""); st.meanFix = false; wordsFillCard(); });
  if (st.meanEdit) {
    const t = el("textarea", "dsx-input");
    t.rows = 2; t.value = fixed || d.meaning || "";
    t.addEventListener("keydown", (ev) => ev.stopPropagation());
    const save = el("button", "dualsub-card-replay dualsub-replay-small", "Salva");
    save.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      await wordsSetFix(st, d, t.value.trim());
      st.meanEdit = false; st.meanFix = false;
      wordsFillCard(); wordsRefreshStar();
    });
    box.append(t, save);
    setTimeout(() => t.focus(), 0);
  }
  box.append(el("div", "dualsub-card-hint", "La frase intera si corregge con ⚑ accanto al sottotitolo."));
  row.append(box);
  return row;
}

// ⚑ sui modi di dire: a volte il modello se li inventa o sbaglia il significato
function wordsIdiomFixRow(st, text, meaning) {
  const row = el("div", "dualsub-idiom-fix");
  const fixed = (wordsIdiomFlags[wordsIdiomKey(text)] || {}).meaning;
  const b = el("button", "dualsub-card-link", st.idiomFix ? "chiudi" : "⚑ modo di dire sbagliato?");
  b.addEventListener("click", (ev) => { ev.stopPropagation(); st.idiomFix = !st.idiomFix; st.idiomEdit = false; wordsFillCard(); });
  row.append(b);
  if (fixed) row.append(el("span", "dualsub-card-hint", " ✎ corretto da te"));
  if (!st.idiomFix) return row;
  const box = el("div", "dualsub-idiom-fixbox");
  const btn = (label, title, fn) => { const x = el("button", "dualsub-card-replay dualsub-replay-small", label); x.title = title; x.addEventListener("click", (ev) => { ev.stopPropagation(); fn(); }); box.append(x); };
  btn("Non è un modo di dire", "Toglie la sottolineatura arancione per questa espressione (resta salvato)", async () => {
    await wordsIdiomFlag(text, { bad: true });
    st.idiomFix = false;
    if (st.expr && st.expr.idiom) wordsCloseCard(); else wordsFillCard();
  });
  if (wordsLlmAvailable()) btn("Ricontrolla con " + wordsDefineEngine().E.label.split(" (")[0].split(",")[0], "Chiede al modello la spiegazione completa dell'espressione in questa frase (una richiesta)", () => {
    const spans = wordsFindExpr(text);
    st.idiomFix = false;
    const anchor = spans[Math.floor(spans.length / 2)] || st.anchor;
    wordsCloseCard();
    if (anchor && anchor.isConnected) wordsOpenCard(anchor, true, { text: spans.length ? wordsRangeText(spans) : text, spans, fromWord: "" });
  });
  btn("✎ Correggi il significato", "Scrivi tu il significato giusto: resta salvato", () => { st.idiomEdit = !st.idiomEdit; wordsFillCard(); });
  if (fixed || wordsIdiomBad(text)) btn("Togli la mia correzione", "", async () => { await wordsIdiomFlag(text, null); st.idiomFix = false; wordsFillCard(); });
  if (st.idiomEdit) {
    const t = el("textarea", "dsx-input");
    t.rows = 2; t.value = fixed || meaning || "";
    t.addEventListener("keydown", (ev) => ev.stopPropagation());
    const save = el("button", "dualsub-card-replay dualsub-replay-small", "Salva");
    save.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      await wordsIdiomFlag(text, { meaning: t.value.trim(), bad: false });
      st.idiomEdit = false; st.idiomFix = false;
      if (st.data && st.expr) st.data = { ...st.data, meaning: t.value.trim() };
      wordsFillCard();
    });
    box.append(t, save);
    setTimeout(() => t.focus(), 0);
  }
  row.append(box);
  return row;
}

// Pronuncia IPA nella scheda: dalla spiegazione del modello, oppure dalle parole già salvate; se manca la chiedo
// (una richiesta piccola). Con la riga IPA spenta compare un pulsante e si chiede solo se lo premi.
function wordsCardIpa(st, d) {
  // Pronuncia IPA: prima Wiktionary (gratis, sempre, anche con la pronuncia del modello spenta). Se lì non c'è, la
  // scrive il modello solo nella stessa richiesta della spiegazione (clic sulla parola), se l'opzione è accesa.
  if (typeof ipaWordsOf !== "function") return;
  const lang = ipaLang(st.sentence.lang, st.sentence.text);
  const ws = ipaWordsOf(st.word, st.sentence.lang);
  const keyOf = (w) => ipaK(lang, w);
  if (d && d.ipa && ws.length === 1 && !ipaCache.get(keyOf(ws[0]))) { ipaCache.set(keyOf(ws[0]), d.ipa); ipaSave(); }
  const vals = ws.map((w) => ipaCache.get(keyOf(w)));
  const whole = ipaCache.get(keyOf(st.word));   // la parola intera (in giapponese, divisa da sola può spezzarsi diversamente)
  const text = whole || (d && d.ipa && ws.length !== 1 ? d.ipa : vals.every(Boolean) && vals.length ? vals.join(" ") : "");
  st.ipa = text;
  // trascrizione in caratteri latini (alfabeti diversi), da Google, gratis
  if (d && d.translit) st.translit = d.translit;
  if (st.translit) { const t = el("div", "dualsub-card-translit", st.translit); t.title = "Trascrizione in caratteri latini"; wordsCard.append(t); }
  const box = el("div", "dualsub-card-ipa");
  if (text) {
    box.textContent = "/" + text + "/";
    box.title = "Pronuncia in alfabeto fonetico internazionale (IPA)" + (st.ipaSource ? " — da " + st.ipaSource : "");
    wordsCard.append(box);
    return;
  }
  if (!ws.length) return;
  const tryWikt = async () => {
    if (typeof DS_ETYM === "undefined" || ws.length !== 1 || st.wiktIpaTried || !/^[a-z]{2,3}$/.test(lang)) return false;
    st.wiktIpaTried = true;
    const r = await DS_ETYM.ipa(st.word, lang, settings.targetLang);
    if (r.info && st.learn && !st.learn.wikt) st.learn.wikt = r.info;
    if (!r.ipa) return false;
    ipaCache.set(keyOf(st.word), r.ipa); if (ws[0] !== st.word) ipaCache.set(keyOf(ws[0]), r.ipa);
    ipaSave();
    st.ipaSource = r.source || "Wiktionary";
    return true;
  };
  const canWikt = typeof DS_ETYM !== "undefined" && ws.length === 1 && !st.wiktIpaTried && /^[a-z]{2,3}$/.test(lang);
  if (canWikt) {
    box.textContent = "IPA …";
    box.title = "Cerco la pronuncia su Wiktionary (gratis)";
    wordsCard.append(box);
    if (!st.ipaAsked) {
      st.ipaAsked = true;
      // solo se la scheda resta aperta almeno 0,8 secondi (passando veloce sopra le parole non parte niente)
      setTimeout(async () => {
        if (wordsCardState !== st) { st.ipaAsked = false; return; }
        await tryWikt();
        if (wordsCardState === st && wordsCard) wordsFillCard();
      }, 800);
    }
    return;
  }
  // non c'è su Wiktionary: arriva con la spiegazione del modello (una sola richiesta), se l'opzione è accesa
  if (ipaOn() && !st.contextual && wordsLlmAvailable()) {
    const name = wordsDefineEngine().E.label.split(" (")[0].split(",")[0];
    box.className = "dualsub-card-ipa dualsub-card-hint";
    box.textContent = `IPA: non c'è su Wiktionary — clicca la parola e arriva con la spiegazione di ${name}`;
    wordsCard.append(box);
  }
}

// Strumenti per imparare (learn.js): frequenza, "la conosco", genere, scrittura corretta, etimologia, audio di
// madrelingua, tabella, esempi veri, falsi amici. Le parti gratis si caricano se la scheda resta aperta un attimo;
// quelle del modello arrivano con la spiegazione (clic sulla parola), nella stessa richiesta.
function wordsCardLearn(st, d) {
  if (!settings || typeof DS_LEARN === "undefined" || (st.expr && wordsSplit(st.word).length > 2)) return;
  const lang = (d && d.lang) || (st.sentence.lang || "").split("-")[0] || DualSubs.guessLang(st.sentence.text) || "";
  st.learn = st.learn || {};
  if (d && d.gdict) st.learn.gdict = d.gdict;   // dizionario di Google (resta anche dopo la spiegazione del modello)
  const llm = st.contextual && d && !d.error && !d.fallback && d.source && !/^Google/.test(d.source) ? d : null;
  // etimologia arrivata con la spiegazione del modello (solo se Wiktionary non l'aveva)
  if (llm && llm.etymology && (!st.learn.wikt || !st.learn.wikt.trans)) {
    DS_ETYM.put(st.word, lang, settings.targetLang, llm.etymology, String(llm.source || "").split(" (")[0]);
    st.learn.wikt = { ...(st.learn.wikt || {}), text: llm.etymology, trans: llm.etymology, source: String(llm.source || "").split(" (")[0], none: false };
  }
  const name = wordsLlmAvailable() ? wordsDefineEngine().E.label.split(" (")[0].split(",")[0] : "";
  wordsCard.append(DS_LEARN.render({
    word: st.word, lemma: d && d.lemma, lang, target: settings.targetLang, sentence: st.sentence.text, prefs: settings, llm, st: st.learn, gdict: st.learn.gdict,
    rerender: () => { if (wordsCardState === st && wordsCard) wordsFillCard(); },
    stale: () => wordsCardState !== st,
    speak: (t, l) => DS_TTS.speak(t, l || wordsSpeechLang(), { lang: settings.ttsLang, voice: settings.ttsVoice }),
    etymHint: name && !st.contextual ? `Clicca la parola: la chiedo a ${name} insieme alla spiegazione (una richiesta sola).` : "",
    onKnown: () => { wordsOrigKey = ""; },
    // kanji/caratteri della parola nel vocabolario, ognuno come voce a sé (toggle = uno solo: lo salva o lo toglie)
    isSaved: (l, ch) => !!vocab[vocabId(l, "", ch)],
    saveChars: async (entries, toggle) => {
      const { vocab: cur = {} } = await DS_EXT.storage.local.get({ vocab: {} });
      const added = [];
      for (const e of entries) {
        const id = vocabId(e.lang, "", e.word);
        if (cur[id]) { if (toggle) delete cur[id]; continue; }
        cur[id] = { ...e, id, ipa: "", etym: "", sentence: st.sentence.text, sentenceTrans: st.sentence.trans || "",
          videoId: new URLSearchParams(location.search).get("v") || "", time: Math.max(0, Math.floor((st.sentence.start || 0) / 1000)),
          title: document.title.replace(/\s*-\s*YouTube\s*$/, ""), fromWord: st.word, added: Date.now(), status: "learning" };
        added.push(cur[id]);
      }
      await DS_EXT.storage.local.set({ vocab: cur });
      vocab = cur; vocabRebuild();
      if (settings.ankiAuto) for (const e of added) await wordsAnki(null, e);
    },
    // un kanji o carattere cinese della parola, aperto nella sua scheda (resta il collegamento per tornare alla parola)
    openWord: (ch, pre) => {
      const a = wordsAnchorOf(st);
      if (!a) return;
      const back = { fromWord: st.expr && st.expr.han ? st.expr.fromWord : st.word, backContextual: st.contextual };
      wordsCloseCard();
      const quick = pre && pre.meaning ? { meaning: pre.meaning, pos: pre.pos, source: "dizionario dei caratteri (arriva Google…)", lang: pre.lang } : null;
      wordsOpenCard(a, true, { text: ch, spans: [], han: true, quick, ...back });
    },
    // immagine cambiata: se la parola è già nel vocabolario, la aggiorno anche lì
    onImage: (url) => wordsUpdateSavedImage(url),
    engine: () => {
      if (!wordsLlmAvailable()) return null;
      const e = wordsDefineEngine();
      if (!e || !e.E || (e.E.kind !== "openai" && e.E.kind !== "claude")) return null;
      return { ...e, name: e.E.label.split(" (")[0].split(",")[0] };
    }
  }));
}

function wordsEntry() {
  const st = wordsCardState;
  const d = st.data && !st.data.error ? st.data : {};
  const lang = d.lang || st.sentence.lang || "";
  return {
    id: vocabId(lang, d.lemma, st.word),
    word: st.word, lemma: d.lemma || "", pos: d.pos || "", meaning: wordsWordFix(st, d) || d.meaning || "",
    explanation: d.explanation || "", lang, ipa: st.ipa || "",
    ...(typeof DS_LEARN !== "undefined" && st.learn ? DS_LEARN.entryExtras(st.learn, lang) : { etym: st.etym || "" }),
    sentence: st.sentence.text, sentenceTrans: st.sentence.trans || "",
    videoId: new URLSearchParams(location.search).get("v") || "",
    time: Math.max(0, Math.floor((st.sentence.start || 0) / 1000)),
    title: document.title.replace(/\s*-\s*YouTube\s*$/, ""),
    added: Date.now(), status: "learning"
  };
}

function wordsRefreshStar() {
  if (!wordsCard || !wordsCardState) return;
  const star = wordsCard.querySelector(".dualsub-star");
  if (!star) return;
  const saved = !!vocab[wordsEntry().id];
  star.textContent = saved ? "★" : "☆";
  star.title = saved ? "Togli dal vocabolario" : "Salva nel vocabolario";
  star.classList.toggle("on", saved);
}

async function wordsSave() {
  if (!wordsCardState) return;
  const entry = wordsEntry();
  const adding = !vocab[entry.id];
  // immagine per la carta di Anki, solo se l'hai chiesta nel popup: quella scelta nella scheda, altrimenti la prima trovata
  if (settings.ankiImage && adding) entry.image = await wordsImageFor(entry);
  await vocabToggle(entry);
  if (adding && settings.ankiAuto) wordsAnki(null, entry);
}

async function wordsImageFor(entry) {
  if (typeof DS_LEARN === "undefined") return "";
  const st = wordsCardState;
  const ch = st && st.learn ? DS_LEARN.chosenImage(st.learn.img) : undefined;
  return ch !== undefined ? ch : await DS_LEARN.image(entry.lemma || entry.word, entry.lang);
}
async function wordsUpdateSavedImage(url) {
  if (!wordsCardState) return;
  const id = wordsEntry().id;
  const { vocab: cur = {} } = await DS_EXT.storage.local.get({ vocab: {} });
  if (!cur[id]) return;
  cur[id].image = url;
  await DS_EXT.storage.local.set({ vocab: cur });
}

// Anki (AnkiConnect): la carta va nel mazzo della sua lingua ("Lingue::Inglese"), come in Parole al Volo
async function wordsAnki(btn, given) {
  const st = wordsCardState;
  let entry = given || (st && wordsEntry());
  if (!entry) return;
  if (!given && settings.ankiImage) {
    const saved = vocab[entry.id];
    entry.image = saved && saved.image != null ? saved.image : await wordsImageFor(entry);
  }
  if (btn) { btn.disabled = true; btn.textContent = "…"; }
  let r;
  try { r = await DS_EXT.runtime.sendMessage({ type: "ankiAdd", entries: [entry] }); } catch (e) { r = { error: String(e.message || e) }; }
  const ok = r && !r.error;
  if (btn && btn.isConnected) {
    btn.disabled = false;
    btn.textContent = ok ? (r.dup ? "✓ già in Anki" : "✓ Anki") : "Anki";
    btn.title = ok ? `Mazzo «${r.deck}»` + (r.imgNote ? " — " + r.imgNote : "") : r && r.error ? r.error : "Nessuna risposta";
  }
  if (ok) {
    const { vocab: cur = {} } = await DS_EXT.storage.local.get({ vocab: {} });
    if (cur[entry.id]) { cur[entry.id].anki = 1; await DS_EXT.storage.local.set({ vocab: cur }); }
  }
  if (wordsCardState === st && wordsCard) {
    let n = wordsCard.querySelector(".dualsub-anki-note");
    if (!n) { n = el("div", "dualsub-card-hint dualsub-anki-note"); wordsCard.append(n); }
    n.textContent = ok ? (r.dup ? "Era già in Anki" : "Aggiunta ad Anki") + ", mazzo «" + r.deck + "»" + (r.imgNote ? " (" + r.imgNote + ")" : entry.image && !r.dup ? ", con l'immagine" : "") + "." : "Anki: " + ((r && r.error) || "nessuna risposta");
  }
}

function wordsDefineEngine() {
  const e = track && !liveActive() ? trackEngine() : liveEngine();
  if (e.E.kind === "youtube") return GOOGLE_ENGINE;
  const isLlm = (x) => x.E.kind === "openai" || x.E.kind === "claude";
  const u = dsUsable(e);
  if (u === e || isLlm(u) || !isLlm(e)) return u;
  // il modello scelto ha finito la quota di oggi: per spiegazioni e allineamento uso un altro modello di riserva
  const alt = C.FALLBACK.filter((id) => !dsIsBlocked(id) && C.ENGINES[id] && C.ENGINES[id].kind === "openai").map(engineById).find(dsReady);
  return alt || u;
}

async function wordsLoadDefinition(word, sentence, anchor, contextual) {
  const my = ++wordsReqId;
  const e = contextual ? wordsDefineEngine() : GOOGLE_ENGINE;
  // nella stessa richiesta: etimologia (solo se Wiktionary non l'ha data) e pronuncia (solo se accesa)
  const elang = (sentence.lang || "").split("-")[0] || DualSubs.guessLang(sentence.text) || "";
  const known = typeof DS_ETYM !== "undefined" ? DS_ETYM.peek(word, elang, settings.targetLang) : null;
  const wantEtym = contextual && settings.etym !== false && !(known && known.trans);
  const cacheKey = [word.toLowerCase(), sentence.text, e.id, e.model, settings.targetLang].join("|") + (wantEtym ? "|e" : "") +
    (settings.learnLlmExtra !== false || settings.learnSpell !== false ? "|x" : "");
  let data = wordsDefCache.get(cacheKey);
  // clic diretto (senza passare prima il mouse): il significato di Google arriva subito, il modello dopo
  if (!data && contextual && wordsCardState && !wordsCardState.quick) {
    const st0 = wordsCardState;
    DS_EXT.runtime.sendMessage({ type: "define", engine: "google", target: settings.targetLang, word, sentence: sentence.text, lang: sentence.lang || "" })
      .then((g) => { if (wordsCardState === st0 && !st0.data && g && !g.error) { st0.quick = g; wordsFillCard(); wordsPlace(anchor); } }).catch(() => {});
  }
  if (!data) {
    try {
      data = await DS_EXT.runtime.sendMessage({
        type: "define", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl,
        target: settings.targetLang, word, sentence: sentence.text, sentenceTrans: sentence.trans || "", lang: sentence.lang || "",
        etym: wantEtym, ipa: settings.ipa !== false && !(wordsCardState && wordsCardState.ipa), extra: settings.learnLlmExtra !== false || settings.learnSpell !== false,
        // la frase tradotta da Google/DeepL: nella stessa richiesta anche una traduzione corretta della frase intera
        sentFix: contextual && !!sentence.trans && (() => { try { const te = track && !liveActive() ? trackEngine() : liveEngine(); return te.E.kind !== "openai" && te.E.kind !== "claude"; } catch { return false; } })()
      });
    } catch (err) {
      data = { error: String(err.message || err) };
    }
    if (!data) data = { error: "nessuna risposta" };
    if (data.llmDaily) dsMarkBlocked(e.id);   // la prossima spiegazione la chiede al servizio di riserva
    if (data.error) data = { error: "Non riesco a trovare il significato: " + data.error };
    else if (!data.fallback) {
      if (e.id !== "google") data.persist = true;   // solo le spiegazioni dei modelli, quelle di Google sono gratis
      wordsDefRemember(cacheKey, data, e.id !== "google");
    }
  }
  if (data && data.etymology && typeof DS_ETYM !== "undefined") DS_ETYM.put(word, (data.lang || elang), settings.targetLang, data.etymology, data.source.split(" (")[0]);
  if (data && data.expression && wordsSplit(data.expression).length > 1) wordsAddIdioms(sentence.text, [{ text: data.expression, meaning: data.expressionMeaning || "" }]);
  if (my !== wordsReqId || !wordsCardState) return;
  wordsCardState.data = data;
  wordsFillCard();
  wordsPlace(anchor);
}

// Durante la pronuncia abbasso io il video, e alla fine lo riporto esattamente al volume di prima
function wordsDuck() {
  const v = getVideo();
  if (!v || v.paused || v.muted) return () => {};
  const before = v.volume;
  const low = Math.round(before * 0.3 * 100) / 100;
  v.volume = low;
  let restored = false;
  const restore = () => {
    if (restored) return;
    restored = true;
    // se nel frattempo hai cambiato tu il volume, non lo tocco
    if (Math.abs(v.volume - low) < 0.02) v.volume = before;
  };
  setTimeout(restore, 12000); // sicurezza: il volume torna comunque
  return restore;
}

// Lingua della pronuncia: quella scelta nel popup, altrimenti quella della parola o del video
function wordsSpeechLang() {
  const st = wordsCardState;
  if (settings.ttsLang) return settings.ttsLang;
  const d = st && st.data && !st.data.error ? st.data : null;
  return (d && d.lang) || (st && st.sentence.lang) || "";
}

// rate: velocità (0,75 = lenta); times: quante volte di fila
let wordsReplayLoop = null;
// ---------- ↺ Torna alla frase che stavi leggendo ----------
// Ti fermi su una parola (scheda aperta o mouse sulle parole) e intanto il video va avanti: il pulsante ↺ accanto ai
// sottotitoli torna all'inizio di quella frase e la riascolta. Senza una frase ricordata, riascolta quella sotto il video.
let wordsReading = null;
function wordsMarkReading(sentence) {
  if (sentence && sentence.text) wordsReading = { start: sentence.start || 0, end: sentence.end || 0, text: sentence.text, at: Date.now() };
  wordsBackButtonUpdate();
}
function wordsBackTarget() {
  const v = getVideo();
  const r = wordsReading;
  if (r && v && Date.now() - r.at < 10 * 60000 && !(wordsCurrent && wordsCurrent.text === r.text && Math.abs((wordsCurrent.start || 0) - r.start) < 500)) return r;
  return wordsCurrent && wordsCurrent.text ? { start: wordsCurrent.start || 0, end: wordsCurrent.end || 0, text: wordsCurrent.text } : r;
}
function wordsBackButton() {
  const b = document.createElement("button");
  b.className = "dualsub-fixbtn dualsub-backbtn";
  b.textContent = "↺";
  b.addEventListener("click", (e) => {
    e.stopPropagation();
    const v = getVideo(), t = wordsBackTarget();
    if (!v || !t) return;
    wordsReading = null;
    wordsAutoPaused = false;
    if (wordsCardState) wordsCloseCard();
    wordsReplayLoop = null;
    wordsReplayUntil = null;
    v.currentTime = Math.max(0, t.start / 1000 - 0.3);
    v.play().catch(() => {});
    wordsBackButtonUpdate();
  });
  return b;
}
function wordsBackButtonUpdate() {
  const b = overlay && overlay.querySelector(".dualsub-backbtn");
  if (!b) return;
  const t = wordsBackTarget();
  const back = !!(t && wordsReading && t === wordsReading);
  b.classList.toggle("dualsub-has-target", !!t);
  // appena superata la frase che leggevi, ↺ resta in vista (in giallo) per un minuto, anche senza passare il mouse
  b.classList.toggle("dualsub-back-far", back && Date.now() - wordsReading.at < 60000);
  const short = t ? (t.text.length > 40 ? t.text.slice(0, 40) + "…" : t.text) : "";
  b.title = !t ? "Riascolta la frase" : back ? `Torna alla frase che stavi leggendo e riascoltala: «${short}»` : `Riascolta questa frase: «${short}»`;
}

function wordsReplay(rate = 1, times = 1) {
  const v = getVideo();
  if (!v || !wordsCardState) return;
  const s = wordsCardState.sentence;
  wordsAutoPaused = false;
  wordsCloseCard();
  if (!wordsReplayLoop) wordsReplayLoop = { prevRate: v.playbackRate };
  wordsReplayLoop.start = Math.max(0, (s.start || 0) / 1000 - 0.2);
  wordsReplayLoop.left = Math.max(0, times - 1);
  v.playbackRate = rate;
  v.currentTime = wordsReplayLoop.start;
  wordsReplayUntil = s.end || null;
  v.play().catch(() => {});
}

// Chiamata da tick() a ogni aggiornamento
function wordsTick(t, video) {
  if (wordsReplayUntil != null && t >= wordsReplayUntil) {
    if (wordsReplayLoop && wordsReplayLoop.left > 0) {   // ancora una volta
      wordsReplayLoop.left--;
      video.currentTime = wordsReplayLoop.start;
      return;
    }
    wordsReplayUntil = null;
    video.pause();
    if (wordsReplayLoop) { video.playbackRate = wordsReplayLoop.prevRate || 1; wordsReplayLoop = null; }
  }
}

// ---------- Copiare il testo e aprire i servizi di traduzione in un'altra scheda ----------
function wordsCopy(text, btn) {
  text = String(text || "").trim();
  if (!text) return;
  const done = (ok) => {
    if (!btn) return;
    const old = btn.dataset.label || btn.textContent;
    btn.dataset.label = old;
    btn.textContent = ok ? "Copiato ✓" : "Non riesco a copiare";
    setTimeout(() => { if (btn.isConnected) btn.textContent = old; }, 1400);
  };
  const fallback = () => {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
      document.body.append(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      done(ok);
    } catch { done(false); }
  };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(() => done(true), fallback);
  else fallback();
}

// Indirizzi dei servizi per consultare un testo (in config.js, li usa anche la pagina della trascrizione)
const wordsServiceLinks = (text, from, to, isWord, lemma) => dsServiceLinks(text, from, to, isWord, lemma);

// Riga di collegamenti: "Apri in: Google Traduttore · DeepL · …" (si aprono in un'altra scheda)
function wordsLinksRow(getText, from, to, isWord, lemma) {
  const box = el("div", "dualsub-links");
  box.append(el("span", "dualsub-links-label", "Apri in: "));
  const first = wordsServiceLinks(getText() || "x", from, to, isWord, lemma);
  first.forEach((l, i) => {
    const a = el("a", "dualsub-link", l.label);
    a.href = l.url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.title = l.title || "Si apre in un'altra scheda";
    // al momento del clic uso il testo aggiornato (per esempio la parte selezionata): lo leggo quando premi il tasto,
    // prima che il clic tolga la selezione
    const update = () => {
      const cur = wordsServiceLinks(getText(), from, to, isWord, lemma).find((x) => x.label === l.label);
      if (cur) a.href = cur.url;
    };
    a.addEventListener("mousedown", (ev) => { update(); ev.preventDefault(); });
    a.addEventListener("click", (ev) => {
      ev.stopPropagation();
      if (l.copy) wordsCopy(getText());   // da incollare nella pagina del servizio
      const v = getVideo();
      if (v && !v.paused) v.pause();
    });
    if (i) box.append(document.createTextNode(" · "));
    box.append(a);
  });
  return box;
}

// Testo selezionato con il mouse dentro un elemento (se c'è), altrimenti il testo dato
function wordsSelectedIn(node, whole) {
  try {
    const sel = window.getSelection();
    if (sel && !sel.isCollapsed && node && node.contains(sel.anchorNode) && node.contains(sel.focusNode)) {
      const t = sel.toString().replace(/\s+/g, " ").trim();
      if (t) return t;
    }
  } catch {}
  return whole;
}

// Scheda "Copia": la frase intera, selezionabile con il mouse, con i pulsanti per copiarla e consultarla
function wordsOpenLineCard(anchor) {
  if (!wordsCurrent || !overlay) return;
  if (wordsCard) wordsCard.remove();
  const s = wordsCurrent;
  wordsCardState = { pinned: true, word: null, copy: true, sentence: s, data: null };
  wordsCard = el("div", "dualsub-card dualsub-copycard");
  overlay.append(wordsCard);
  const v = getVideo();
  if (v && !v.paused) { v.pause(); wordsAutoPaused = true; }

  const head = el("div", "dualsub-card-head");
  head.append(el("div", "dualsub-card-title", "Copia o consulta la frase"));
  const close = el("button", "dualsub-card-btn", "×");
  close.title = "Chiudi";
  close.addEventListener("click", wordsCloseCard);
  head.append(close);
  const orig = el("div", "dualsub-copy-text", s.text || "");
  const trans = el("div", "dualsub-copy-text dualsub-copy-trans", s.trans || "");
  const hint = el("div", "dualsub-card-hint", "Puoi selezionare una parte del testo con il mouse: i pulsanti useranno solo quella.");
  wordsCard.append(head, orig);
  if (s.trans) wordsCard.append(trans);
  wordsCard.append(hint);

  const row = el("div", "dualsub-copy-actions");
  const b = (label, title, get) => {
    const btn = el("button", "dualsub-card-replay", label);
    btn.title = title;
    btn.addEventListener("click", (ev) => { ev.stopPropagation(); wordsCopy(get(), btn); });
    row.append(btn);
  };
  b("Copia originale", "Copia la frase originale (o la parte selezionata)", () => wordsSelectedIn(orig, s.text));
  if (s.trans) {
    b("Copia traduzione", "Copia la traduzione (o la parte selezionata)", () => wordsSelectedIn(trans, s.trans));
    b("Copia tutte e due", "Copia originale e traduzione, una sotto l'altra", () => s.text + "\n" + s.trans);
  }
  wordsCard.append(row);
  const src = (s.lang || "").split("-")[0] || DualSubs.guessLang(s.text) || "";
  wordsCard.append(wordsLinksRow(() => wordsSelectedIn(orig, s.text), src, settings.targetLang, false));
  wordsPlace(anchor);
}

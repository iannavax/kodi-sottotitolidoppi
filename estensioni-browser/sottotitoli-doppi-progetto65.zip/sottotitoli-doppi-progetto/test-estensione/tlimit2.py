import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', transcribeMode:'live', cleanTranscript:false})
          .then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))""")
        pg = await ctx.new_page()
        await pg.goto("https://www.youtube.com/watch?v=noCapsLimit"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(40000)
        print("rifiutate da Groq:", log.get("glimit"), "| riuscite Groq:", len(log["groq"]), "| passate a Speaches:", log.get("via_local"))
        print("   stato:", await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)"))
        print("   avviso nel menu:", await sw.evaluate("chrome.storage.local.get('sttFallback').then(r=>JSON.stringify(r.sttFallback))"))
        await ctx.close()
asyncio.run(main())

# -*- coding: utf-8 -*-
# Sottotitoli Doppi - menu (aprilo dagli add-on "Programmi" mentre il video è in riproduzione,
# oppure dal lettore: Sottotitoli → Scarica → Sottotitoli Doppi)
import sys

import xbmc
import xbmcgui

from resources.lib import runner

player = xbmc.Player()

if len(sys.argv) > 2 and sys.argv[2].startswith("?"):
    # chiamata dal menu dei sottotitoli del lettore (servizio di sottotitoli di Kodi)
    from resources.lib import subtitles
    subtitles.main(sys.argv)
elif len(sys.argv) > 2 and sys.argv[1] == "upgrade":
    # traduzione con il servizio scelto dopo quella rapida di Google (avviata dal menu dei sottotitoli)
    from resources.lib import subtitles
    runner.run(player, manual_path=subtitles._dec(sys.argv[2])["p"], upgrade=True)
else:
    options = [
        "Crea i sottotitoli doppi per il video in riproduzione",
        "Scegli un file di sottotitoli (.srt, .vtt, .ass)…",
        "Trascrivi l'audio con Whisper (anche se ci sono i sottotitoli)",
        "Impostazioni",
    ]
    choice = xbmcgui.Dialog().select("Sottotitoli Doppi", options)
    if choice == 0:
        runner.run(player, interactive=True)
    elif choice == 1:
        path = xbmcgui.Dialog().browse(1, "Scegli i sottotitoli nella lingua originale", "files", ".srt|.vtt|.ass|.ssa")
        if path:
            runner.run(player, manual_path=path, interactive=True)
    elif choice == 2:
        runner.run(player, force_transcribe=True, interactive=True)
    elif choice == 3:
        runner.ADDON.openSettings()

# -*- coding: utf-8 -*-
# Sottotitoli Doppi - voce nel menu dei sottotitoli del lettore.
# Mentre guardi un film: Sottotitoli → Scarica → "Sottotitoli Doppi". L'elenco propone i sottotitoli
# originali che ci sono (file scaricati, file accanto al video, tracce dentro il video); scegliendone uno
# arriva subito la versione doppia tradotta con Google, e se nelle impostazioni hai scelto Gemini (o un altro
# servizio) la traduzione migliore la sostituisce da sola appena è pronta.
import base64
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

from . import core
from . import runner

# nome inglese (per Kodi: bandierina della lingua) e nome italiano (per le scritte) di ogni lingua
def name_en(code, default=""):
    return (runner._lang_name(code) if code else "") or default


def name_it(code, default=""):
    return core.LANG_IT.get(code, "") or default


def _enc(o):
    return base64.urlsafe_b64encode(json.dumps(o).encode("utf-8")).decode("ascii")


def _dec(s):
    return json.loads(base64.urlsafe_b64decode(s.encode("ascii")).decode("utf-8"))


def options(player, with_transcript=True):
    """Sottotitoli originali disponibili per il video in corso, il più probabile per primo"""
    video = player.getPlayingFile()
    s = runner.settings()
    target = s["target"]
    since = runner.playback_since(player, video)
    orig = runner.original_lang(video)
    prefer = orig or runner.current_sub_lang(player)
    cands = [c for c in runner.item_subtitles(player) + runner.candidates(video) if not runner.looks_dual(c[0])]
    best = runner.find_source(player, video, target)
    seen, out = set(), []
    # prima il file che verrebbe scelto da solo, poi gli altri utilizzabili (stesse regole: niente film di prima)
    ordered = ([c for c in cands if c[0] == best] + [c for c in cands if c[0] != best]) if best else cands
    for c in ordered:
        path = c[0]
        if path in seen or not core.pick_subtitle([c], video, target, since=since):
            continue
        seen.add(path)
        lang = core.lang_from_filename(path) or (prefer if c[0] == best else "")
        out.append({"k": "file", "p": path, "l": lang, "name": os.path.basename(path)})
        if len(out) >= 6:
            break
    for idx, lang, codec, _ in runner.embedded_streams(video, s):
        if lang != target:
            out.append({"k": "stream", "i": idx, "l": lang, "name": "traccia del video n. %d (%s)" % (idx, codec)})
    # dentro il file in streaming che stai guardando (.mkv di Real-Debrid, The Crew…): i più esatti, sempre per primi
    inside = [o for o in runner.mkv_options(video) if o["l"] != target]
    if not inside:
        # streaming HLS di Real-Debrid (quando il .mkv non si può leggere direttamente)
        inside = [o for o in runner.rd_options(video, s) if o["l"] != target]
    inside.sort(key=lambda o: 1 if o.get("forced") else 0)
    out = inside + out
    if prefer:
        out.sort(key=lambda o: 0 if o["l"] == prefer else 1)
    if not any(o["k"] == "file" for o in out):
        for o in runner.online_options(player, video, target, per_lang=5):
            o["name"] = "%s, versione %d" % (o.get("src", "OpenSubtitles"), o["n"])
            out.append(o)
    if not with_transcript:
        return out
    # trascrizione dell'audio: quella già fatta (subito pronta) o da fare
    tpath = runner.transcript_paths(video, s)[0]
    if os.path.isfile(tpath):
        lang = json.load(open(tpath, encoding="utf-8")).get("lang", "")
        out.insert(0, {"k": "trans", "l": lang, "name": "trascrizione dell'audio (già fatta)"})
    else:
        out.append({"k": "dotrans", "l": orig, "name": "trascrivi l'audio originale con Whisper (ci vuole parecchio)"})
    return out


BASE = "plugin://service.subtitles.sottotitolidoppi/"


def search(handle, player):
    s = runner.settings()
    tname = name_it(s["target"], s["target"])
    opts = options(player) if player.isPlayingVideo() else []
    for o in opts:
        src = name_it(o["l"], "lingua originale")
        li = xbmcgui.ListItem(label=name_en(s["target"], "Italian"),
                              label2="Doppi: %s → %s · %s" % (src, tname, o["name"]))
        li.setArt({"icon": "5", "thumb": s["target"]})
        li.setProperty("sync", "false")
        li.setProperty("hearing_imp", "false")
        xbmcplugin.addDirectoryItem(handle=handle, url=BASE + "?action=download&o=" + _enc(o),
                                    listitem=li, isFolder=False)
    if not opts:
        runner.notify("Sottotitoli Doppi: non trovo sottotitoli originali per questo film. Puoi scaricarli con OpenSubtitles "
                      "(qui a sinistra) e poi tornare su Sottotitoli Doppi, oppure far trascrivere l'audio.", 10000)


def download(handle, player, o):
    """Prepara il file doppio. Con Google è completo in pochi secondi; con un altro servizio
    rispondo subito con Google e lascio lavorare in sottofondo il servizio scelto."""
    s = runner.settings()
    video = player.getPlayingFile()
    target = s["target"]
    if o["k"] == "dotrans":
        # la trascrizione richiede minuti: la faccio fare all'add-on, che carica i sottotitoli quando sono pronti
        runner.save_choice(video, source="trascrizione")
        xbmc.executebuiltin("RunScript(script.sottotitolidoppi,transcribe)")
        runner.notify("Trascrivo l'audio: i sottotitoli doppi compaiono da soli quando sono pronti.", 7000)
        return
    if o["k"] == "trans":
        d = json.load(open(runner.transcript_paths(video, s)[0], encoding="utf-8"))
        cues, src_lang, path = d["cues"], d.get("lang", ""), None
        src_id = "trascrizione|" + core.cache_key(*[c["t"] for c in cues])[:10]
        runner.save_choice(video, source="trascrizione")
    else:
        runner.save_choice(video, source="file", pick=o)   # la prossima volta, anche in automatico, gli stessi sottotitoli
        path = o["p"] if o["k"] == "file" else runner.fetch_mkv(o, video) if o["k"] == "mkv" else \
            runner.fetch_online(o) if o["k"] in ("online", "service", "rd") else runner.extract_stream(video, s, o["i"])
        cues = core.parse_subs(runner.read_text(path))
        src_lang = core.lang_from_filename(path) or o.get("l") or core.guess_lang_cues(cues)
        src_id = os.path.basename(path) + "|" + str(len(cues)) + "|" + core.cache_key(*[c["t"] for c in cues])[:10]
    if not cues:
        runner.notify("In quei sottotitoli non ho trovato frasi da tradurre.")
        return
    os.makedirs(runner.CACHE, exist_ok=True)
    engine = s["engine"]
    model = s.get(engine + "_model", "")
    vk = runner.video_key(video)
    best = os.path.join(runner.CACHE, core.cache_key(vk, src_id, target, engine, model) + ".json")
    quick = os.path.join(runner.CACHE, core.cache_key(vk, src_id, target, "google", "") + ".json")
    upgrade = False
    tmode = runner.load_choice(video).get("trans") or s["trans_mode"]
    want_human = tmode == "pronta" or (tmode == "auto" and not src_id.startswith("trascrizione") and not os.path.isfile(best))
    human, how = runner.human_translation(player, video, cues, src_id, target, s, src_lang=src_lang, force=tmode == "pronta") \
        if want_human else (None, "")
    # frasi già tradotte con il servizio scelto (memoria del film): se ci sono tutte, niente richieste
    if not human:
        mem = runner.load_memory(video, target)
        tag = runner.engine_tag(s)
        from_mem = [mem.get(runner._mkey(c["t"]), {}).get(tag) for c in cues]
        from_mem = [None if t and core.is_copy(c["t"], t) and not mem.get(runner._mkey(c["t"]), {}).get("uguale") else t
                    for c, t in zip(cues, from_mem)]
        if all(from_mem):
            human, how = from_mem, "salvata"
    if human and how == "salvata":
        trans = human
        runner.notify("Traduzione già salvata con %s: nessuna richiesta." % engine.capitalize(), 5000)
    elif human:
        # traduzione già fatta da persone (per esempio i sottotitoli italiani dello stesso film): niente Google né Gemini
        trans = human
        runner.notify("Traduzione già pronta: %s" % how, 6000)
    elif os.path.isfile(best):
        trans = json.load(open(best, encoding="utf-8"))["trans"]
        # salvata da una versione precedente con frasi brevi ricopiate ("Ja." → "Ja."): le rifà il servizio scelto
        mem = runner.load_memory(video, target)
        upgrade = engine != "google" and any(t and core.is_copy(c["t"], t) and not mem.get(runner._mkey(c["t"]), {}).get("uguale")
                                             for c, t in zip(cues, trans))
    elif os.path.isfile(quick):
        trans = json.load(open(quick, encoding="utf-8"))["trans"]
        upgrade = engine != "google"
    else:
        trans = core.google_translate_fast([c["t"] for c in cues], target, src_lang)
        json.dump({"trans": trans}, open(quick, "w", encoding="utf-8"), ensure_ascii=False)
        upgrade = engine != "google"
    trans = runner.fill_missing(cues, trans, target, src_lang)
    out = os.path.join(runner.CACHE, "%s.doppi.%s.srt" % (core.cache_key(vk, src_id, target, "menu"), target))
    open(out, "w", encoding="utf-8").write(core.make_dual_srt(cues, trans, s["layout"], s["trans_color"] or "FFFF00"))
    li = xbmcgui.ListItem(label=out)
    xbmcplugin.addDirectoryItem(handle=handle, url=out, listitem=li, isFolder=False)
    if upgrade:
        # la traduzione con il servizio scelto (Gemini…) continua da sola e sostituisce questa quando è pronta
        xbmc.executebuiltin("RunScript(script.sottotitolidoppi,upgrade,%s)" % _enc({"p": path} if path else {"t": 1}))
        runner.notify("Traduzione rapida con Google. Quella con %s arriva da sola tra poco." % engine.capitalize(), 6000)


def main(argv):
    global BASE
    BASE = argv[0].split("?")[0] or BASE
    handle = int(argv[1])
    q = dict(urllib.parse.parse_qsl(argv[2].lstrip("?")))
    player = xbmc.Player()
    try:
        if q.get("action") in ("search", "manualsearch"):
            search(handle, player)
        elif q.get("action") == "download" and q.get("o"):
            download(handle, player, _dec(q["o"]))
    except Exception as e:
        runner.log("menu dei sottotitoli: %r" % e)
        runner.notify("Errore: %s" % e, 8000)
    xbmcplugin.endOfDirectory(handle)

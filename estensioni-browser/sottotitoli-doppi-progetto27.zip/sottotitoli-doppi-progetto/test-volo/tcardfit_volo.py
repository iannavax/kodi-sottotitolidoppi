# 1.4.12: la scheda di Parole al Volo cresce dopo «✨ Spiega con…» (o con l'albero, le immagini): non deve uscire dal
# fondo dello schermo (utente: PDF di Google Libri a schermo intero, la fine della scheda non si raggiungeva più).
# Resta invece attaccata alla parola se si scorre la pagina (tscroll_volo.py).
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
FIT = "(()=>{const c=document.querySelector('.pav-card'); if(!c) return null; const r=c.getBoundingClientRect(); return {top:Math.round(r.top), bottom:Math.round(r.bottom), vh:innerHeight, scroll:c.scrollHeight>c.clientHeight}})()"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, viewport={"width": 1100, "height": 650},
                                                         args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        # la parola a metà schermo, pagina che non scorre (come un lettore a schermo intero)
        await pg.evaluate("document.body.insertAdjacentHTML('afterbegin', '<div style=\"height:300px\"></div>'); document.documentElement.style.overflow='hidden'")
        b = await tvolo.hover(pg, "en", "bread", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1200)
        a = await pg.evaluate(FIT); print("1. aperta:", a)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.get_by_role("button", name="Spiega con Groq").click(); await pg.wait_for_timeout(4000)
        # la spiegazione vera può essere lunga: allungo la scheda come farebbero spiegazione + albero + immagini
        await pg.evaluate("document.querySelector('.pav-card').insertAdjacentHTML('beforeend', '<div class=\"pav-test-long\" style=\"height:900px\">lunga</div>')")
        await pg.wait_for_timeout(500)
        f = await pg.evaluate(FIT); print("2. dopo «Spiega» e contenuto lungo:", f)
        ok = a and a["bottom"] <= a["vh"] and f and f["top"] >= 0 and f["bottom"] <= f["vh"] and f["scroll"]
        await pg.evaluate("(()=>{const c=document.querySelector('.pav-card'); c.scrollTop=c.scrollHeight})()"); await pg.wait_for_timeout(200)
        end = await pg.evaluate("(()=>{const c=document.querySelector('.pav-card'), t=c.querySelector('.pav-test-long').getBoundingClientRect(); return Math.round(t.bottom) <= innerHeight})()")
        print("dentro lo schermo:", ok, "| fine raggiungibile:", end)
        print("errori:", errs if ok and end else errs + ["scheda fuori dallo schermo"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

# PDF "scansionato" come quelli di archive.org/Google Libri: ogni pagina è un'immagine (JBIG2 o JPEG 2000)
# con sotto il testo OCR invisibile. pdf.js 5+ decodifica queste immagini solo con i file in pdfjs/wasm:
# senza, le pagine restano bianche. Serve ImageMagick (convert).
import struct, subprocess, tempfile, os
T = tempfile.mkdtemp()
def img(text, w=800, h=200):
    png = os.path.join(T, "p.png")
    subprocess.run(["convert", "-size", f"{w}x{h}", "xc:white", "-fill", "black", "-pointsize", "48",
                    "-draw", f"text 30,110 '{text}'", "-monochrome", png], check=True)
    return png
def g4(png, w, h):
    tif = os.path.join(T, "p.tif")
    subprocess.run(["convert", png, "-compress", "Group4", "-define", "quantum:polarity=min-is-white", "-define", f"tiff:rows-per-strip={h}", tif], check=True)
    d = open(tif, "rb").read(); e = "<" if d[:2] == b"II" else ">"
    off = struct.unpack(e + "I", d[4:8])[0]; n = struct.unpack(e + "H", d[off:off + 2])[0]; tags = {}
    for i in range(n):
        t, typ, cnt, val = struct.unpack(e + "HHII", d[off + 2 + 12 * i: off + 14 + 12 * i])
        if typ == 3 and cnt == 1: val = struct.unpack(e + "H", d[off + 10 + 12 * i: off + 12 + 12 * i])[0]
        tags[t] = val
    return d[tags[273]: tags[273] + tags[279]]
def jbig2(png, w, h):
    # JBIG2 "incorporato" (senza intestazione di file): pagina + regione generica in MMR (= dati Group 4)
    mmr = g4(png, w, h)
    seg = lambda num, typ, data: struct.pack(">IBBBI", num, typ, 0, 1, len(data)) + data
    page = struct.pack(">IIIIBH", w, h, 0, 0, 0, 0)
    region = struct.pack(">IIIIB", w, h, 0, 0, 0) + bytes([1]) + mmr
    return seg(0, 48, page) + seg(1, 38, region) + seg(2, 49, b"")
def jpx(png):
    jp2 = os.path.join(T, "p.jp2")
    subprocess.run(["convert", png, "-quality", "40", jp2], check=True)
    return open(jp2, "rb").read()
def pdf(path, pages):
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", None, b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    kids = []
    for kind, text in pages:
        w, h = 800, 200; png = img(text, w, h)
        if kind == "jbig2":
            data = jbig2(png, w, h)
            im = b"<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceGray /BitsPerComponent 1 /Filter /JBIG2Decode /Length %d >>" % (w, h, len(data))
        else:
            data = jpx(png)
            im = b"<< /Type /XObject /Subtype /Image /Width %d /Height %d /Filter /JPXDecode /Length %d >>" % (w, h, len(data))
        objs.append(im + b"\nstream\n" + data + b"\nendstream"); imn = len(objs)
        # immagine a tutta pagina e testo OCR invisibile (modo 3) sopra
        c = b"q 600 0 0 150 0 0 cm /Im0 Do Q BT 3 Tr /F1 30 Tf 20 60 Td (" + text.encode("latin-1") + b") Tj ET"
        objs.append(b"<< /Length %d >>\nstream\n" % len(c) + c + b"\nendstream"); cn = len(objs)
        objs.append(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 150] /Resources << /Font << /F1 3 0 R >> /XObject << /Im0 %d 0 R >> >> /Contents %d 0 R >>" % (imn, cn))
        kids.append(len(objs))
    objs[1] = b"<< /Type /Pages /Kids [" + b" ".join(b"%d 0 R" % k for k in kids) + b"] /Count %d >>" % len(kids)
    out = b"%PDF-1.5\n"; offs = []
    for i, o in enumerate(objs, 1):
        offs.append(len(out)); out += str(i).encode() + b" 0 obj\n" + o + b"\nendobj\n"
    x = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1) + b"".join(b"%010d 00000 n \n" % o for o in offs)
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, x)
    open(path, "wb").write(out)
pdf("/tmp/doc_scan.pdf", [("jbig2", "Pagina scansionata JBIG2"), ("jpx", "Pagina scansionata JPEG")])
print("creato /tmp/doc_scan.pdf")

# 1.7.5: la scheda sulle pagine si ridimensiona dai bordi e dagli angoli
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
BOX = "(() => { const c = document.querySelector('.pav-card'); if (!c) return null; const r = c.getBoundingClientRect(); return {l: r.left, t: r.top, w: r.width, h: r.height}; })()"
async def drag(pg, idx, dx, dy):
    b = await pg.locator(".dsx-rzh").nth(idx).bounding_box()
    x, y = b["x"] + b["width"] / 2, b["y"] + b["height"] / 2
    await pg.mouse.move(x, y); await pg.mouse.down(); await pg.mouse.move(x + dx / 2, y + dy / 2, steps=4); await pg.mouse.move(x + dx, y + dy, steps=4); await pg.mouse.up()
    await pg.wait_for_timeout(500)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnFreq:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "market", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1800)
        n = await pg.locator(".dsx-rzh").count()
        b0 = await pg.evaluate(BOX)
        print("1. maniglie:", n, "| scheda:", {k: round(v) for k, v in b0.items()})
        g = await pg.locator(".pav-grip").bounding_box()   # prima sposto la scheda a destra, per avere spazio dal lato sinistro
        await pg.mouse.move(g["x"] + g["width"] / 2, g["y"] + g["height"] / 2); await pg.mouse.down(); await pg.mouse.move(g["x"] + 250, g["y"] + 10, steps=6); await pg.mouse.up(); await pg.wait_for_timeout(500)
        b0 = await pg.evaluate(BOX)
        await drag(pg, 7, 80, 60)
        b1 = await pg.evaluate(BOX)
        print("2. angolo in basso a destra +80/+60:", {k: round(v) for k, v in b1.items()}, "| sinistra ferma:", abs(b1["l"] - b0["l"]) < 2)
        await drag(pg, 3, -50, 0)
        b2 = await pg.evaluate(BOX)
        print("3. bordo sinistro -50:", {k: round(v) for k, v in b2.items()}, "| bordo destro fermo:", abs((b2["l"] + b2["w"]) - (b1["l"] + b1["w"])) < 2)
        await drag(pg, 0, 0, 30)
        b3 = await pg.evaluate(BOX)
        print("4. bordo alto +30:", {k: round(v) for k, v in b3.items()}, "| fondo fermo:", abs((b3["t"] + b3["h"]) - (b2["t"] + b2["h"])) < 2)
        u = await sw.evaluate("chrome.storage.local.get('cardUser').then(r => r.cardUser)")
        print("5. salvato:", u)
        await pg.mouse.click(5, 5); await pg.wait_for_timeout(500)
        b = await tvolo.hover(pg, "en", "walked", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1800)
        b4 = await pg.evaluate(BOX)
        print("6. altra scheda:", {k: round(v) for k, v in b4.items()})
        await pg.locator(".pav-grip").dblclick(); await pg.wait_for_timeout(800)
        b5 = await pg.evaluate(BOX)
        print("7. dopo il doppio clic su ⠿:", {k: round(v) for k, v in b5.items()})
        await pg.mouse.click(5, 5); await pg.wait_for_timeout(600)
        print("maniglie dopo la chiusura:", await pg.locator(".dsx-rzh").count())
        ok = n == 8 and b1["w"] - b0["w"] > 50 and abs(b1["l"] - b0["l"]) < 2 and b2["w"] - b1["w"] > 30 and abs((b2["l"] + b2["w"]) - (b1["l"] + b1["w"])) < 2 and u and u.get("page", {}).get("w") and abs(b4["w"] - b3["w"]) < 3 and b5["w"] < b4["w"] - 30
        print("errori:", errs if ok else errs + ["ridimensionamento sulle pagine non va"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

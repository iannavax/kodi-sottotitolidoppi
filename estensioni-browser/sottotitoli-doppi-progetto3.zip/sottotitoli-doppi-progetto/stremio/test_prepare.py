# 1.3: l'elenco dei sottotitoli (chiesto da Stremio a ogni film) non consuma quota: traduce solo quando scegli i doppi
import json, sys, time, base64, urllib.request
B = "http://127.0.0.1:7000"
def get(p):
    with urllib.request.urlopen(B + p if p.startswith("/") else p, timeout=60) as r: return r.read().decode()
mock = lambda: json.loads(urllib.request.urlopen("http://127.0.0.1:7801/log").read().decode())
for prep in ("file", "full"):
    cfg = base64.urlsafe_b64encode(json.dumps({"target": "it", "engine": "gemini", "key": "AIza-test", "prepare": prep, "model": prep}).encode()).decode().rstrip("=")
    g0 = mock().get("gemini", 0)
    subs = json.loads(get(f"/{cfg}/subtitles/movie/tt0111161/filename=film.mkv.json"))["subtitles"]
    time.sleep(4)
    g1 = mock().get("gemini", 0)
    t0 = time.time(); srt = get(subs[0]["url"]); dt = time.time() - t0
    g2 = mock().get("gemini", 0)
    print(f"{prep}: richieste a Gemini solo per l'elenco: {g1 - g0} | file doppio in {dt:.1f}s, Gemini {srt.count('GEM[')}, Google {srt.count('IT[')} | richieste dopo la scelta: {g2 - g1}")

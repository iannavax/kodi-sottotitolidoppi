// Popup (Sottotitoli Doppi e Parole al Volo): voce per ogni lingua e voci naturali di Microsoft (Azure Speech).
// Usa: DS_EXT, DS_CONFIG (config.js), DS_TTS (tts.js). Disegna dentro l'elemento con id "voicesBox".
(() => {
  const box = document.getElementById("voicesBox");
  if (!box || typeof DS_TTS === "undefined") return;
  const mk = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const name = (code) => { try { return new Intl.DisplayNames([dsUiLocale()], { type: "language" }).of(code) || code; } catch { return code; } };
  const SAMPLE = { it: "Ciao, come stai?", en: "Hello, how are you?", cs: "Ahoj, jak se máš?", de: "Hallo, wie geht es dir?", fr: "Bonjour, comment ça va ?",
    es: "Hola, ¿qué tal?", pt: "Olá, tudo bem?", ru: "Привет, как дела?", uk: "Привіт, як справи?", pl: "Cześć, jak się masz?", ja: "こんにちは、お元気ですか？",
    zh: "你好，你好吗？", ko: "안녕하세요, 잘 지내세요?", nl: "Hallo, hoe gaat het?", sv: "Hej, hur mår du?", da: "Hej, hvordan går det?", no: "Hei, hvordan går det?",
    fi: "Hei, mitä kuuluu?", tr: "Merhaba, nasılsın?", el: "Γεια σου, τι κάνεις;", ar: "مرحبا، كيف حالك؟", he: "שלום, מה שלומך?", hi: "नमस्ते, आप कैसे हैं?", sk: "Ahoj, ako sa máš?", hu: "Szia, hogy vagy?", ro: "Salut, ce faci?" };

  let state = { ttsVoices: {}, azureTts: false, azureRegion: "westeurope" }, keys = {};

  async function load() {
    state = await DS_EXT.storage.sync.get({ ttsVoices: {}, azureTts: false, azureRegion: "westeurope" });
    keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
    render();
  }

  function render() {
    box.textContent = "";
    // --- Azure ---
    const az = mk("div", "stack");
    const on = mk("label", "row", "Voci naturali di Microsoft (Azure) ");
    const chk = mk("input"); chk.type = "checkbox"; chk.checked = !!state.azureTts; on.append(chk);
    on.title = "Le stesse voci \"Natural\" di Edge, in quasi tutte le lingue, anche in Firefox. Serve una chiave gratuita di Azure Speech (500.000 caratteri al mese gratis).";
    const key = mk("input"); key.type = "password"; key.placeholder = "Chiave di Azure Speech"; key.autocomplete = "off"; key.spellcheck = false; key.value = keys.azureSpeech || "";
    const reg = mk("input"); reg.type = "text"; reg.placeholder = "Regione (es. westeurope)"; reg.value = state.azureRegion || "westeurope"; reg.spellcheck = false;
    const test = mk("button", "ghost", "Prova la chiave"); test.type = "button";
    const info = mk("p", "small", "Chiave e regione si trovano nel portale di Azure → risorsa \"Servizi di riconoscimento vocale\" (Speech) → Chiavi ed endpoint.");
    az.append(on, key, reg, test, info);
    box.append(az);
    chk.addEventListener("change", () => { state.azureTts = chk.checked; DS_EXT.storage.sync.set({ azureTts: chk.checked }); renderRows(rows); });
    key.addEventListener("change", async () => {
      keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
      keys.azureSpeech = key.value.trim();
      await DS_EXT.storage.local.set({ keys });
      if (key.value.trim() && !state.azureTts) { state.azureTts = true; chk.checked = true; DS_EXT.storage.sync.set({ azureTts: true }); }
    });
    reg.addEventListener("change", () => { state.azureRegion = reg.value.trim().toLowerCase() || "westeurope"; DS_EXT.storage.sync.set({ azureRegion: state.azureRegion }); });
    test.addEventListener("click", async () => {
      info.textContent = "Provo…";
      try {
        const r = await DS_EXT.runtime.sendMessage({ type: "azureVoices", fresh: true });
        if (!r || r.error) throw new Error((r && r.error) || "nessuna risposta");
        info.textContent = `Funziona: ${r.list.length} voci disponibili.`;
        renderRows(rows);
      } catch (e) { info.textContent = "Non funziona: " + (e.message || e); }
    });

    // --- Voce per ogni lingua ---
    box.append(mk("p", "small", "Voce per ogni lingua: si usa sempre quella che scegli qui (o con ⚙ accanto a 🔈 nella scheda della parola). Senza scelta: Azure se acceso, poi la voce migliore del computer (prima le \"Natural\"), poi Google."));
    const rows = mk("div", "stack");
    box.append(rows);
    renderRows(rows);
    const add = mk("select");
    add.append(new Option("Aggiungi una lingua…", ""));
    const codes = Object.keys((DS_CONFIG && DS_CONFIG.STT_LANGS) || {}).map((c) => [c, name(c)]).sort((a, b) => a[1].localeCompare(b[1], "it"));
    for (const [c, n] of codes) add.append(new Option(n, c));
    add.addEventListener("change", async () => {
      const c = add.value;
      if (!c) return;
      add.value = "";
      if (!(c in (state.ttsVoices || {}))) {
        // nuova riga con "Automatica": la salvo vuota solo in pagina finché non scegli
        pending.add(c);
        renderRows(rows);
      }
    });
    box.append(add);
  }

  const pending = new Set();
  async function renderRows(rows) {
    rows.textContent = "";
    const langs = [...new Set([...Object.keys(state.ttsVoices || {}), ...pending])];
    if (!langs.length) rows.append(mk("p", "small", "Nessuna lingua scelta: tutto automatico."));
    for (const c of langs) {
      const row = mk("div", "row");
      const lab = mk("span", null, name(c));
      const sel = mk("select");
      const play = mk("button", "ghost", "▶"); play.type = "button"; play.title = "Prova";
      const del = mk("button", "ghost", "×"); del.type = "button"; del.title = "Togli (torna automatica)";
      const opts = await DS_TTS.voiceOptions(c);
      for (const o of opts) sel.append(new Option(o.label, o.value));
      sel.value = (state.ttsVoices || {})[c] || "";
      sel.addEventListener("change", async () => {
        await DS_TTS.setVoice(c, sel.value);
        state.ttsVoices = { ...(state.ttsVoices || {}) };
        if (sel.value) state.ttsVoices[c] = sel.value; else delete state.ttsVoices[c];
      });
      play.addEventListener("click", async () => {
        play.textContent = "…";
        try { const r = await DS_TTS.speak(SAMPLE[c] || name(c), c, {}); play.title = "Usata: " + r.how; await r.done; } catch {}
        play.textContent = "▶";
      });
      del.addEventListener("click", async () => {
        pending.delete(c);
        await DS_TTS.setVoice(c, "");
        delete state.ttsVoices[c];
        renderRows(rows);
      });
      const right = mk("span");
      right.style.cssText = "display:flex;gap:4px;align-items:center;min-width:0";
      sel.style.maxWidth = "190px";
      right.append(sel, play, del);
      row.append(lab, right);
      rows.append(row);
    }
  }

  load().catch(() => {});
})();

TEXTS = []
SELECTS = []
SELECT_ANSWER = [-1]
BROWSE_ANSWER = ['']
NOTES = []
OKS = []
class Dialog:
    def notification(self, h, msg, icon=None, ms=0): NOTES.append(msg)
    def select(self, h, opts, autoclose=0, preselect=-1, useDetails=False):
        SELECTS.append(opts)
        return SELECT_ANSWER.pop(0) if len(SELECT_ANSWER) > 1 else SELECT_ANSWER[0]
    def browse(self, *a): return BROWSE_ANSWER[0]
    def textviewer(self, h, text): TEXTS.append(text)
    def yesno(self, *a): return True
    def ok(self, h, msg): OKS.append(msg); return True
BARS = []
class DialogProgressBG:
    def create(self, *a): BARS.append(["create"] + [str(x) for x in a])
    def update(self, *a): BARS.append(["update"] + [str(x) for x in a])
    def close(self): BARS.append(["close"])

PROPS = {}
class Window:
    def __init__(self, wid=10000): pass
    def setProperty(self, k, v): PROPS[k] = v
    def getProperty(self, k): return PROPS.get(k, "")
class ListItem:
    def __init__(self, label="", label2="", path=""):
        self.label, self.label2, self.art, self.props = label, label2, {}, {}
    def setArt(self, a): self.art.update(a)
    def setProperty(self, k, v): self.props[k] = v

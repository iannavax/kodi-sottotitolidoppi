# Interfaccia nella lingua di «Traduci in»: con la casella accesa le scritte del popup e delle schede si traducono
# (qui il traduttore finto scrive «UI-en<…>»), le parole, le traduzioni e i sottotitoli no; spenta, torna l'italiano.
# Uso: python3 tuilang.py <estensione unica o Sottotitoli Doppi>
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'en', ipa:false, hoverPause:true, learnExamples:false, learnFreq:false})")
        pop = await ctx.new_page(); errs = []
        pop.on("pageerror", lambda e: errs.append(str(e)))
        page = "popup-video.html" if os.path.exists(os.path.join(EXT, "popup-video.html")) else "popup.html"
        await pop.goto(f"chrome-extension://{eid}/{page}"); await pop.wait_for_timeout(800)
        print("1. spenta:", await pop.evaluate("document.getElementById('uiLang').parentElement.textContent.trim()"))
        await pop.click("#uiLang"); await pop.wait_for_timeout(3000)
        lab = await pop.evaluate("document.getElementById('uiLang').parentElement.textContent.trim()")
        tl = await pop.evaluate("document.getElementById('targetLang').parentElement.firstChild.textContent.trim()")
        print("2. accesa:", lab, "|", tl, "| title:", (await pop.evaluate("document.getElementById('freqBtn').title"))[:50])
        nit = await pop.evaluate("""[...document.querySelectorAll('button, label, h2, h3, summary')].filter(e=>e.offsetParent && /[a-zà-ù]{4}/i.test(e.textContent) && !/UI-en</.test(e.textContent)).map(e=>e.textContent.trim().slice(0,40))""")
        print("   rimaste in italiano (visibili):", len(nit), nit[:12])
        print("   memoria:", await sw.evaluate("chrome.storage.local.get('uiTr:en').then(r=>Object.keys(r['uiTr:en']||{}).length)"), "scritte tradotte; richieste a Google:", len(set(log.get("uitr", []))))
        pg = await ctx.new_page()
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(4000)
        print("3. scheda:", (await pg.evaluate("(document.querySelector('.dualsub-card')||{}).innerText||''")).replace("\n", " | ")[:400])
        print("   parola e significato intatti:", await pg.evaluate("[(document.querySelector('.dualsub-card-word')||{}).textContent, (document.querySelector('.dualsub-card-meaning')||{}).textContent]"),
              "| sottotitolo:", await pg.evaluate("document.querySelector('.dualsub-orig').textContent.slice(0,40)"))
        await pop.bring_to_front(); await pop.click("#uiLang"); await pop.wait_for_timeout(1500)
        print("4. spenta di nuovo:", await pop.evaluate("document.getElementById('uiLang').parentElement.textContent.trim()"), "| scheda:", (await pg.evaluate("(document.querySelector('.dualsub-card')||{}).innerText||''")).replace("\n", " | ")[:120])
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

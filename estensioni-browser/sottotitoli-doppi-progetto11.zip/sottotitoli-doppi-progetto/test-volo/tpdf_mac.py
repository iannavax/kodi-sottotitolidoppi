# Lettore PDF: PDF ceco in Windows-1250 letto da pdf.js come Mac Roman ("P·novÈ" invece di "Pánové"), con i titoli
# in un altro carattere già giusti. Uso: python3 tpdf_mac.py <estensione> [file.pdf] (senza file: /tmp/doc_mac.pdf di crea_pdf_mac.py)
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
PDF = sys.argv[2] if len(sys.argv) > 2 else "/tmp/doc_mac.pdf"
async def handle(route, request):
    if request.url.split("?")[0].endswith(".pdf"):
        return await route.fulfill(status=200, content_type="application/pdf", body=open(PDF, "rb").read())
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/pdf.html?file=https%3A%2F%2Fexample.test%2Fcs.pdf"); await pg.wait_for_timeout(3000)
        for y in range(0, 60):
            await pg.mouse.wheel(0, 1500); await pg.wait_for_timeout(150)
        await pg.wait_for_timeout(1500)
        text = await pg.evaluate("[...document.querySelectorAll('.textLayer')].map(t=>t.textContent).join(' || ')")
        import re
        print("1. pagine con testo:", text.count("||") + 1, "| inizio:", text[:300].replace("\n", " "))
        bad = re.findall(r"\w*[·¯˝˘ÈÌÏËÚÔûö]\w*", text)
        print("2. parole ancora strane:", len(bad), bad[:10])
        good = [w for w in ("Pánové", "přezíraví", "skeptičtí", "nazpaměť", "Hrabě") if w in text]
        print("3. parole giuste trovate:", good)
        await pg.mouse.wheel(0, -200000); await pg.wait_for_timeout(1500)
        for w in [w for w in ("přezíraví", "Pánové") if w in text][:1]:
            box = await pg.evaluate("""(w)=>{for (const t of document.querySelectorAll('.textLayer')){const tw=document.createTreeWalker(t, NodeFilter.SHOW_TEXT); let n;
              while((n=tw.nextNode())){const i=n.nodeValue.indexOf(w); if(i>=0){n.parentElement.scrollIntoView({block:'center'}); const r=document.createRange(); r.setStart(n,i+1); r.setEnd(n,i+3); const b=r.getBoundingClientRect(); return {x:b.x+b.width/2, y:b.y+b.height/2};}}} return null}""", w)
            await pg.wait_for_timeout(800)
            box = await pg.evaluate("""(w)=>{for (const t of document.querySelectorAll('.textLayer')){const tw=document.createTreeWalker(t, NodeFilter.SHOW_TEXT); let n;
              while((n=tw.nextNode())){const i=n.nodeValue.indexOf(w); if(i>=0){const r=document.createRange(); r.setStart(n,i+1); r.setEnd(n,i+3); const b=r.getBoundingClientRect(); return {x:b.x+b.width/2, y:b.y+b.height/2};}}} return null}""", w)
            await pg.mouse.move(5, 5); await pg.wait_for_timeout(400)
            await pg.mouse.move(box["x"], box["y"], steps=4); await pg.wait_for_timeout(2500)
            print(f"4. scheda su {w}:", (await pg.evaluate("(document.querySelector('.pav-card .pav-word')||{}).textContent||''")))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

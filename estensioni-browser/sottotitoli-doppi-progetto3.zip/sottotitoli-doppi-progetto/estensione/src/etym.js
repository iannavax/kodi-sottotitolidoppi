// Etimologia delle parole (usata da Sottotitoli Doppi e da Parole al Volo).
// Fonte gratuita: Wiktionary in inglese (la pagina la scarica il background, qui si estrae la sezione
// "Etymology" della lingua giusta), poi tradotta con Google nella tua lingua. Se Wiktionary non la ha,
// si può chiedere a Gemini o Groq (solo premendo il pulsante). Tutto resta salvato: una parola, una volta.
var DS_ETYM = (() => {
  const cache = new Map();          // "lingua|parola|arrivo" → { text, trans, url, lemma, source } oppure { none, at }
  let saveTimer = 0;
  const ready = DS_EXT.storage.local.get({ etymCache: {} }).then((r) => {
    for (const [k, v] of Object.entries(r.etymCache || {})) if (!cache.has(k)) cache.set(k, v);
  }).catch(() => {});
  // le correzioni fatte da te si salvano subito (non dopo un attimo), così non si perdono ricaricando la pagina
  function saveNow() {
    clearTimeout(saveTimer);
    while (cache.size > 3000) cache.delete(cache.keys().next().value);
    return DS_EXT.storage.local.set({ etymCache: Object.fromEntries(cache) }).catch(() => {});
  }
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      while (cache.size > 3000) cache.delete(cache.keys().next().value);
      DS_EXT.storage.local.set({ etymCache: Object.fromEntries(cache) }).catch(() => {});
    }, 1500);
  }
  const base = (l) => { const b = String(l || "").split("-")[0].toLowerCase(); return ({ iw: "he", jw: "jv", in: "id", nb: "no", fil: "tl" })[b] || b; };

  // Nomi inglesi delle lingue come li usa Wiktionary per le sezioni ("Czech", "Norwegian Bokmål"…)
  function enNames(code) {
    const b = base(code);
    const extra = { no: ["Norwegian Bokmål", "Norwegian Nynorsk", "Norwegian"], zh: ["Chinese", "Mandarin"], he: ["Hebrew"], fa: ["Persian"],
      sr: ["Serbo-Croatian", "Serbian"], hr: ["Serbo-Croatian", "Croatian"], bs: ["Serbo-Croatian", "Bosnian"], ms: ["Malay"], tl: ["Tagalog"],
      el: ["Greek"], ar: ["Arabic"], ku: ["Kurdish", "Northern Kurdish"], ne: ["Nepali"] }[b] || [];
    let n = "";
    try { n = new Intl.DisplayNames(["en"], { type: "language" }).of(b) || ""; } catch {}
    return [...new Set([...extra, n].filter(Boolean))];
  }

  // Titolo e livello di un elemento se è un'intestazione (vecchio e nuovo HTML di MediaWiki)
  function heading(el) {
    let h = null;
    if (/^H[2-6]$/.test(el.tagName)) h = el;
    else if (el.classList && el.classList.contains("mw-heading")) h = el.querySelector("h2,h3,h4,h5,h6");
    if (!h) return null;
    const span = h.querySelector(".mw-headline");
    const text = (span || h).textContent.replace(/\[\s*edit\s*\]/gi, "").trim();
    return { level: Number(h.tagName[1]), text, id: (span && span.id) || h.id || "" };
  }
  const clean = (n) => {
    n.querySelectorAll("sup, .mw-editsection, style, script, .etymtree, .NavFrame, table, .maintenance-line").forEach((x) => x.remove());
    return n.textContent.replace(/\s+/g, " ").trim();
  };

  // Definizioni da un elenco numerato di Wiktionary (<ol><li>), in qualsiasi edizione: il testo della definizione
  // senza esempi, citazioni e sottoelenchi; il primo esempio a parte.
  const EX_SEL = ".h-usage-example, .e-example, [class*='example'], [class*='Example'], i.example";
  function defItem(li) {
    const exEl = li.querySelector(EX_SEL);
    const ex = exEl ? exEl.textContent.replace(/\s+/g, " ").replace(/^[◆▪•\s]+/, "").trim().slice(0, 200) : "";
    const x = li.cloneNode(true);
    x.querySelectorAll("ul, dl, ol, sup, .reference, style, script, table, .mw-editsection, .citation-whole, .cited-source, .HQToggle, .nyms, .synonym, .antonym, " + EX_SEL).forEach((n) => n.remove());
    const def = x.textContent.replace(/\s+/g, " ").replace(/^\s*\[?\d+\]?\s*/, "").replace(/\s+([,.;:])/g, "$1").replace(/[◆▪•]\s*$/, "").trim().slice(0, 300);
    return def.length > 1 && /\p{L}/u.test(def) ? { def, ex: ex !== def ? ex : "" } : null;
  }
  function defsOfList(ol) {
    if (!ol || ol.closest(".references, .mw-references-wrap, .reflist, .NavFrame, .navbox")) return [];
    if (ol.classList && ol.classList.contains("references")) return [];
    return [...ol.children].filter((li) => li.tagName === "LI").map(defItem).filter(Boolean);
  }
  const POS_EN = /^(noun|proper noun|verb|adjective|adverb|pronoun|preposition|conjunction|interjection|particle|numeral|determiner|article|participle|postposition|phrase|prepositional phrase|proverb|idiom|classifier|counter|suffix|prefix|letter|contraction)\b/i;

  // Dalla pagina, nella sezione della lingua: il paragrafo "Etymology", il lemma se è una forma flessa, l'audio
  // registrato (madrelingua), il genere del nome, la prima tabella di coniugazione o declinazione
  function tableRows(t) {
    const rows = [];
    for (const r of [...t.rows].slice(0, 40)) {
      const cells = [...r.cells].slice(0, 12).map((c) => {
        // la traslitterazione in alfabeto latino (Wiktionary la mette in .tr dentro la cella) va tenuta a parte,
        // altrimenti si attacca alla parola: "исто́чникistóčnik"
        const x = c.cloneNode(true);
        x.querySelectorAll("sup, .mw-editsection, style, script").forEach((n) => n.remove());
        const trEls = [...x.querySelectorAll(".tr, [lang$='-Latn'], .mention-tr")];
        const tr = trEls.map((n) => n.textContent.replace(/\s+/g, " ").trim()).filter(Boolean);
        trEls.forEach((n) => n.remove());
        x.querySelectorAll("br").forEach((n) => n.replaceWith(", "));
        const t = x.textContent.replace(/\s+/g, " ").replace(/(,\s*)+/g, ", ").replace(/^[,\s]+|[,\s]+$/g, "").trim();
        return { t: t.slice(0, 60), tr: [...new Set(tr)].join(", ").slice(0, 60), h: c.tagName === "TH", cs: Math.min(c.colSpan || 1, 12), rs: Math.min(c.rowSpan || 1, 40) };
      });
      if (cells.some((c) => c.t || c.tr)) rows.push(cells);
    }
    return rows.length >= 2 ? rows : null;
  }
  // Registrazioni in un pezzo di pagina: <audio> con le sue <source> (meglio l'mp3, che tutti i browser leggono),
  // altrimenti il nome del file (data-mwtitle, o un collegamento "File:…ogg/wav/mp3"), scaricato da Commons
  const AUDIO_EXT = /\.(ogg|oga|opus|wav|mp3|flac|m4a|webm)$/i;
  const filePath = (name) => "https://commons.wikimedia.org/wiki/Special:FilePath/" + encodeURIComponent(String(name).replace(/^(File|Fichier|Datei|Файл|Soubor|Plik|Archivo|File|Bestand|Fil):/i, "").replace(/ /g, "_"));
  function audioIn(el) {
    const out = [];
    for (const a of (el.matches && el.matches("audio") ? [el] : []).concat([...el.querySelectorAll("audio")])) {
      const srcs = [...a.querySelectorAll("source[src]")].map((x) => ({ src: x.getAttribute("src"), type: x.getAttribute("type") || "" }));
      if (a.getAttribute("src")) srcs.push({ src: a.getAttribute("src"), type: "" });
      const pick = srcs.find((x) => /mpeg|mp3/.test(x.type + x.src)) || srcs.find((x) => /ogg|vorbis|opus/.test(x.type + x.src)) || srcs[0];
      if (pick && pick.src) out.push(pick.src.replace(/^\/\//, "https://"));
      else if (a.getAttribute("data-mwtitle")) out.push(filePath(a.getAttribute("data-mwtitle")));
      if (out.length) return out;
    }
    for (const l of el.querySelectorAll("a[href]")) {
      const h = decodeURIComponent(l.getAttribute("href") || "");
      const m = h.match(/(?:\/wiki\/|title=)((?:[^/:?#&]+):[^?#&]+)$/);
      if (m && AUDIO_EXT.test(m[1])) return [filePath(m[1])];
      if (/upload\.wikimedia\.org\/.+\.(ogg|oga|opus|wav|mp3|flac)$/i.test(h)) return [h.replace(/^\/\//, "https://")];
    }
    return [];
  }

  function extract(html, lang) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const root = doc.querySelector(".mw-parser-output") || doc.body;
    const names = lang ? enNames(lang).map((x) => x.toLowerCase()) : [];
    const kids = [...root.children];
    let inLang = false, seenLang = false, inEty = false, etyLevel = 0, etyDone = false;
    const parts = [], marked = [], mentions = [];
    const out = { text: "", lemma: "", audio: [], gender: "", table: null, exists: false, ipa: "", defs: [] };
    let pos = "";
    for (const el of kids) {
      const h = heading(el);
      if (h) {
        if (h.level === 2) {
          if (seenLang) break;   // finita la sezione della lingua
          const t = (h.text || h.id.replace(/_/g, " ")).toLowerCase();
          inLang = !names.length || names.some((n) => t === n || t.startsWith(n));
          if (inLang) { seenLang = true; out.exists = true; }
          inEty = false;
          continue;
        }
        if (!inLang) continue;
        if (inEty && h.level <= etyLevel) { inEty = false; if (parts.length) etyDone = true; }
        if (/^etymology/i.test(h.text) && !etyDone && !parts.length) { inEty = true; etyLevel = h.level; }
        pos = POS_EN.test(h.text) ? h.text.replace(/\s*\d+$/, "") : "";
        continue;
      }
      if (!inLang || !el.querySelector) continue;
      if (inEty && el.tagName === "P") {
        const x = el.cloneNode(true);
        const t = clean(x.cloneNode(true));
        // le parole straniere citate (<i lang="cs">ten</i>) non vanno tradotte: le sostituisco con ⟦n⟧
        x.querySelectorAll("[lang]").forEach((m) => {
          const l = String(m.getAttribute("lang") || "").toLowerCase();
          if (!l || l === "en" || l.startsWith("en-") || m.closest(".mention-gloss")) return;
          if (m.parentElement && m.parentElement.closest("[lang]") && m.parentElement.closest("[lang]") !== m && !/^en/.test(m.parentElement.closest("[lang]").getAttribute("lang") || "")) return;
          const txt = m.textContent.replace(/\s+/g, " ").trim();
          if (!txt) return;
          mentions.push(txt);
          m.replaceWith(" ⟦" + (mentions.length - 1) + "⟧ ");
        });
        const tm = clean(x);
        if (t) { parts.push(t); marked.push(tm); }
      }
      if (el.tagName === "OL" && pos && out.defs.length < 4) {   // definizioni in inglese (stessa pagina, nessuna richiesta in più)
        const items = defsOfList(el).slice(0, 4);
        const g = out.defs.find((x) => x.pos === pos);
        if (g) g.items.push(...items); else if (items.length) out.defs.push({ pos, items });
      }
      if (!out.lemma) {
        const a = el.querySelector(".form-of-definition-link a[title], .form-of-definition a[title]");
        if (a) out.lemma = a.getAttribute("title").replace(/#.*$/, "");
      }
      if (!out.audio.length) out.audio = audioIn(el);
      if (!out.ipa) {   // pronuncia IPA (la prima trascrizione /…/ della sezione, altrimenti […])
        const all = [...el.querySelectorAll(".IPA")].map((x) => x.textContent.trim()).filter((t) => /^[\/\[].+[\/\]]$/.test(t));
        const pick = all.find((t) => t.startsWith("/")) || all[0];
        if (pick) out.ipa = pick.replace(/^[\/\[]\s*|\s*[\/\]]$/g, "").trim();
      }
      if (!out.gender) {
        const g = el.querySelector(".headword-line .gender abbr, span.gender abbr") || el.querySelector(".headword-line .gender, span.gender");
        if (g) out.gender = (g.getAttribute("title") || g.textContent || "").trim();
      }
      if (!out.table) {
        const t = el.tagName === "TABLE" ? el : el.querySelector("table.inflection-table, .NavFrame table, table.wikitable, table");
        if (t && !el.closest("p")) out.table = tableRows(t);
      }
    }
    out.text = parts.join(" ").slice(0, 800);
    out.marked = marked.join(" ").replace(/\s+/g, " ").replace(/\s+([,.;:)])/g, "$1").slice(0, 900);
    out.mentions = mentions;
    return out;
  }

  // traduce l'etimologia (inglese) nella tua lingua, lasciando com'erano le parole straniere citate
  // (prima "ten" in ceco diventava "dieci"). Se Google perde un segnaposto, rifaccio senza.
  async function translate(text, target, marked, mentions) {
    if (!text || base(target) === "en") return text;
    const g = async (t) => {
      const r = await DS_EXT.runtime.sendMessage({ type: "translate", engine: "google", texts: [t], target, source: "en" });
      return (r && r.translations && r.translations[0]) || "";
    };
    try {
      if (marked && mentions && mentions.length) {
        const tr = await g(marked);
        const seen = new Set();
        const out = tr.replace(/[⟦⟧\[]\s*(\d+)\s*[⟦⟧\]]/g, (all, n) => { const m = mentions[+n]; if (m == null) return all; seen.add(+n); return m; });
        if (tr && seen.size === mentions.length) return out.replace(/\s+([,.;:)])/g, "$1").replace(/\(\s+/g, "(");
      }
      return (await g(text)) || text;
    } catch { return text; }
  }

  // { text (inglese), trans (nella tua lingua), url, lemma, source, audio, gender, table, exists } — none: senza etimologia
  async function get(word, lang, target, lemmaHint) {
    await ready;
    word = String(word || "").trim();
    if (!word) return { none: true };
    const key = [base(lang) || "?", word.toLowerCase(), base(target)].join("|");
    const c = cache.get(key);
    if (c && c.fixed) return c;
    if (c && c.tv === 5 && !(c.none && Date.now() - (c.at || 0) > 7 * 86400e3)) return c;
    const titles = [word];
    if (word.toLowerCase() !== word) titles.push(word.toLowerCase());
    if (lemmaHint && !titles.includes(lemmaHint)) titles.push(lemmaHint);
    const info = { text: "", marked: "", mentions: [], lemma: "", audio: [], audioTitle: "", ipa: "", ipaTitle: "", gender: "", table: null, exists: false, title: "", textTitle: "", defs: [], defsTitle: "" };
    for (let i = 0; i < titles.length && i < 5; i++) {
      const t = titles[i];
      let page;
      try { page = await DS_EXT.runtime.sendMessage({ type: "etymPage", word: t }); } catch (e) { return { error: String(e.message || e) }; }
      if (!page || page.error) return { error: (page && page.error) || "Wiktionary non risponde" };
      if (!page.html) continue;
      const x = extract(page.html, lang);
      if (!x.exists) continue;
      const title = page.title || t;
      if (!info.exists) { info.exists = true; info.title = title; }
      if (!info.text && x.text) { info.text = x.text; info.textTitle = title; info.marked = x.marked; info.mentions = x.mentions; }
      if (!info.audio.length && x.audio.length) { info.audio = x.audio; info.audioTitle = title; }
      if (!info.ipa && x.ipa) { info.ipa = x.ipa; info.ipaTitle = title; }   // anche questa vale solo per la sua pagina
      if (!info.gender && x.gender) info.gender = x.gender;
      if (!info.defs.length && x.defs.length) { info.defs = x.defs; info.defsTitle = title; }
      if (!info.table && x.table) { info.table = x.table; info.tableTitle = title; }
      if (x.lemma && !titles.includes(x.lemma)) { titles.splice(i + 1, 0, x.lemma); if (!info.lemma) info.lemma = x.lemma; }
      if (info.text && info.table) break;
      if (info.text && !x.lemma) break;
    }
    const name = (enNames(lang)[0] || "").replace(/ /g, "_");
    const page = info.textTitle || info.title || word;
    const out = { ...info, tv: 5, none: !info.text, at: Date.now(), source: info.text ? "Wiktionary" : "",
      url: info.exists ? "https://en.wiktionary.org/wiki/" + encodeURIComponent(page) + (name ? "#" + encodeURIComponent(name) : "") : "" };
    if (out.textTitle && out.textTitle.toLowerCase() !== word.toLowerCase()) out.lemma = out.textTitle;
    if (out.text) out.trans = await translate(out.text, target, out.marked, out.mentions);
    else if (c && c.trans && c.source) Object.assign(out, { text: c.text, trans: c.trans, source: c.source, none: false });   // etimologia del modello
    cache.set(key, out);
    save();
    return out;
  }

  // Dal modello (pulsante): salvata come le altre
  async function fromModel(e, word, lang, target, sentence) {
    const key = [base(lang) || "?", String(word).toLowerCase(), base(target)].join("|");
    const r = await DS_EXT.runtime.sendMessage({ type: "etymLlm", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, word, lang: base(lang), target, sentence });
    if (!r || r.error || !r.text) return { error: (r && r.error) || "nessuna risposta" };
    // resta salvata come una correzione (non viene sostituita da Wiktionary); "Togli la correzione" torna a prima
    const out = override(word, lang, target, r.text);
    out.source = r.source;
    if (!out.lemma && r.lemma) out.lemma = r.lemma;
    saveNow();
    return out;
  }

  // etimologia arrivata insieme alla spiegazione del modello (solo se Wiktionary non l'aveva)
  function put(word, lang, target, text, source) {
    if (!text) return;
    const key = [base(lang) || "?", String(word).toLowerCase(), base(target)].join("|");
    const c = cache.get(key);
    if (c && c.trans && c.source === "Wiktionary") return;
    cache.set(key, { ...(c || {}), text, trans: text, source, none: false });
    save();
  }
  // ---------- Pronuncia dalle altre edizioni di Wiktionary ----------
  // Ogni edizione ha il suo formato: cerco gli elementi con classe IPA/API/transcription e, se non ci sono,
  // il testo tra /…/, […] o \…\ con lettere dell'alfabeto fonetico. Solo nella sezione della lingua giusta
  // (titolo nella lingua dell'edizione: "Русский", "čeština", "Brot (Deutsch)", "Tchèque", "Ceco"…).
  const IPA_CH = /[ˈˌːˑəɛɔʃʒθðŋɪʊʌæɑɒɐɕʑʂʐɲʎʁʀɾɫɣχʔʲʷɨʉɯɤøœɜɞɘɵɦɧɥʋⱱɟɖʈɭɳɻɽɬɮβɸʝçħʕʡʢ̩̯̪̥̃]/;
  const ipaClean = (t) => String(t || "").replace(/\s+/g, " ").trim().replace(/^[\/\[\\]\s*|\s*[\/\]\\]$/g, "").trim();
  function ipaPlausible(t) {
    t = String(t || "").replace(/\s+/g, " ").trim();
    if (!t || t.length > 90) return "";
    const m = t.match(/[\/\[\\]([^\/\[\]\\]{1,60})[\/\]\\]/);
    const inner = (m ? m[1] : t).trim();
    if (!inner || /[0-9<>{}=:]/.test(inner) || inner.split(" ").length > 6) return "";
    return m || IPA_CH.test(inner) ? inner : "";
  }
  function langNames(lang, ed) {
    const out = [];
    for (const inL of [ed, "en"]) { try { const n = new Intl.DisplayNames([inL], { type: "language" }).of(base(lang)); if (n && n.toLowerCase() !== base(lang)) out.push(n.toLowerCase()); } catch {} }
    return [...new Set(out)];
  }
  // registrazione della parola in un'altra edizione (sezione della lingua giusta)
  function extractAudioAny(html, lang, ed) {
    const scope = sectionOf(html, lang, ed);
    if (!scope) return [];
    for (const el of scope) { if (!el.querySelectorAll) continue; const a = audioIn(el); if (a.length) return a; }
    return [];
  }
  function sectionOf(html, lang, ed) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const root = doc.querySelector(".mw-parser-output") || doc.body;
    const names = langNames(lang, ed);
    const kids = [...root.children];
    let start = -1, end = kids.length, top = 9;
    for (let i = 0; i < kids.length; i++) {
      const h = heading(kids[i]);
      if (!h) continue;
      const t = (h.text || h.id.replace(/_/g, " ")).toLowerCase();
      if (start < 0) {
        if (h.level <= 3 && names.some((n) => t.includes(n))) { start = i; top = h.level; }
      } else if (h.level <= top) { end = i; break; }
    }
    if (start < 0 && base(ed) !== base(lang)) return null;
    return start >= 0 ? kids.slice(start + 1, end) : kids;
  }
  function extractIpaAny(html, lang, ed) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const root = doc.querySelector(".mw-parser-output") || doc.body;
    const names = langNames(lang, ed);
    const kids = [...root.children];
    let start = -1, end = kids.length, top = 9;
    for (let i = 0; i < kids.length; i++) {
      const h = heading(kids[i]);
      if (!h) continue;
      const t = (h.text || h.id.replace(/_/g, " ")).toLowerCase();
      if (start < 0) {
        if (h.level <= 3 && names.some((n) => t.includes(n))) { start = i; top = h.level; }
      } else if (h.level <= top) { end = i; break; }
    }
    // senza sezione riconosciuta: solo nell'edizione della lingua della parola (spesso c'è una sola lingua)
    if (start < 0 && base(ed) !== base(lang)) return "";
    const scope = start >= 0 ? kids.slice(start + 1, end) : kids;
    for (const el of scope) {
      if (!el.querySelectorAll) continue;
      for (const x of el.querySelectorAll(".IPA, .ipa, .API, .api, [class*='IPA'], [class*='transcription'], [class*='Transcription'], [title*='IPA'], [title*='API']")) {
        const v = ipaPlausible(x.textContent);
        if (v) return v;
      }
    }
    const text = scope.map((el) => el.textContent || "").join("\n").slice(0, 30000);
    for (const m of text.matchAll(/[\/\[\\]([^\/\[\]\\\n]{1,60})[\/\]\\]/g)) {
      if (IPA_CH.test(m[1]) && !/[0-9<>{}=]/.test(m[1])) return m[1].trim();
    }
    return "";
  }
  // stessa parola? (senza accento tonico, ё = е, maiuscole)
  const normW = (w) => String(w || "").normalize("NFD").replace(/\p{M}/gu, "").replace(/ё/g, "е").replace(/Ё/g, "Е").toLowerCase().trim();
  const sameWord = (a, b) => normW(a) === normW(b);
  // la parola nel nome del file audio ("Ru-гордый.ogg" → "гордый"), se si riconosce
  function fileWord(url) {
    try {
      let n = decodeURIComponent(String(url || "").split("/").pop() || "").replace(/\.(ogg|oga|opus|wav|mp3|flac|m4a|webm)(\.mp3)?$/i, "").replace(/_/g, " ");
      n = n.replace(/^(File:|Fichier:|Datei:|Файл:)/i, "").replace(/^[a-z]{2,3}(-[a-z]{2,4})?-/i, "").replace(/^[a-z]{2,3}(-[a-z]{2,4})? /i, "").trim();
      const m = n.match(/^[\p{L}\p{M}'-]+/u);
      return m && m[0].length > 1 && !/^[a-z]+$/i.test(m[0]) ? m[0] : "";
    } catch { return ""; }
  }
  // edizioni da provare dopo quella inglese: la lingua della parola, la tua lingua, poi le più grandi
  // Pronuncia (IPA) e registrazione dalle altre edizioni: una volta per parola, salvate.
  // want: "ipa" o "audio" — ci si ferma appena c'è quello che serve, ma si prende anche l'altro se è sulla stessa pagina
  async function ipaOther(word, lang, target, want = "ipa") {
    const key = ["ipa4", base(lang) || "?", String(word).toLowerCase()].join("|");
    const c = cache.get(key);
    const fresh = c && Date.now() - (c.at || 0) < 7 * 86400e3;
    if (c && (c.done || (want === "ipa" ? c.ipa : (c.audio && c.audio.length))) && (fresh || c.ipa || (c.audio && c.audio.length))) return c;
    const map = { nb: "no", nn: "no", fil: "tl" };
    const eds = [...new Set([base(lang), base(target), "fr", "de", "ru"].map((x) => map[x] || x).filter((x) => x && x !== "en" && x !== "?"))];
    const out = { ipa: (c && c.ipa) || "", audio: (c && c.audio) || [], source: (c && c.source) || "", audioSource: (c && c.audioSource) || "", form: (c && c.form) || "", at: Date.now() };
    for (const ed of eds) {
      for (const t of [...new Set([word, String(word).toLowerCase()])]) {
        let page;
        try { page = await otherPage(t, ed); } catch { page = null; }
        if (!page || page.error || !page.html) continue;
        // la pagina può essere di un'altra forma (rimando: гордую → гордый): la pronuncia IPA no, la registrazione sì ma segnalata
        const same = sameWord(page.title || t, word);
        if (!out.ipa && same) { const v = extractIpaAny(page.html, lang, ed); if (v) { out.ipa = v; out.source = "Wiktionary " + ed; } }
        if (!out.audio.length || (out.form && same)) {
          const a = extractAudioAny(page.html, lang, ed);
          if (a.length) {
            const fw = fileWord(a[0]);
            const form = !same ? page.title : fw && !sameWord(fw, word) ? fw : "";
            if (!out.audio.length || !form) { out.audio = a; out.audioSource = "Wiktionary " + ed; out.form = form; }
          }
        }
        break;   // trovata la pagina di questa edizione: passo alla prossima solo se manca ancora qualcosa
      }
      if (want === "ipa" ? out.ipa : out.audio.length && !out.form) break;
    }
    out.done = true;   // edizioni già provate per questa parola
    out.none = !out.ipa && !out.audio.length;
    cache.set(key, out);
    save();
    return out;
  }
  // pagine delle altre edizioni appena scaricate: pronuncia e definizioni usano la stessa (una richiesta sola)
  const pages = new Map();
  function otherPage(title, ed) {
    const k = ed + "|" + title;
    if (!pages.has(k)) {
      pages.set(k, DS_EXT.runtime.sendMessage({ type: "etymPage", word: title, site: ed }).catch(() => null));
      while (pages.size > 30) pages.delete(pages.keys().next().value);
    }
    return pages.get(k);
  }
  // sezioni con elenchi numerati che non sono definizioni (sinonimi, traduzioni, derivati…), in molte lingue
  const NOT_DEFS = /синоним|антоним|гипер|гипон|холон|мероним|родствен|перевод|этимолог|фразеолог|библиограф|литератур|синонім|антонім|переклад|synonym|antonym|hyper|hypo|holo|mero|übersetz|oberbegriff|unterbegriff|gegenw|wortbild|redewend|sprichw|charakteristische|referenz|quellen|traduction|traduzion|sinonim|contrari|derivat|dériv|compos|apparent|homophon|paronym|vocabul|anagram|référen|sources|fonti|riferiment|voir aussi|vedi anche|překlad|související|odvozen|slovní spojení|tłumacz|pochodne|kolokacj|wyrazy|przysłow|traducci|relacionad|derivad|véase|tradu[cç]|relacionad|vertaling|afgeleid|synonie|antonie|översätt|käännök|çeviri|ετυμολ|μετάφρ|翻訳|類義|対義|派生|关联|同义|反义|翻译/i;

  // Definizioni nella lingua della parola, dall'edizione di Wiktionary in quella lingua (ru.wiktionary per il russo…):
  // gratis, una richiesta per parola, salvate. Elenchi numerati (quasi tutte le edizioni) o "Bedeutungen" (tedesco).
  function extractDefsAny(html, lang, ed) {
    const scope = sectionOf(html, lang, ed);
    if (!scope) return [];
    const out = [];
    let pos = "", dd = false, skip = false;
    const add = (items) => {
      if (!items.length) return;
      const g = out.find((x) => x.pos === pos);
      if (g) g.items.push(...items); else out.push({ pos, items });
    };
    for (const el of scope) {
      const h = heading(el);
      if (h) { dd = /^(bedeutung|significat|definici|signification|betekenis)/i.test(h.text); skip = NOT_DEFS.test(h.text); continue; }
      if (skip) continue;   // le intestazioni cambiano da un'edizione all'altra: niente parte del discorso
      if (!el.querySelectorAll || out.reduce((n, g) => n + g.items.length, 0) >= 8) continue;
      if (el.tagName === "P" && /^(Bedeutungen|Significati|Significato)\s*:?\s*$/i.test(el.textContent.trim())) { dd = true; continue; }
      const lists = el.tagName === "OL" ? [el] : [...el.querySelectorAll(":scope > ol, :scope > div > ol")];
      for (const ol of lists) add(defsOfList(ol));
      if (!lists.length && el.tagName === "DL" && dd) {   // tedesco: «[1] …» in <dl><dd>
        add([...el.querySelectorAll(":scope > dd")].map((d) => {
          const t = d.textContent.replace(/\s+/g, " ").trim();
          return { def: t.replace(/^\[\d+[a-z]?\]\s*/, "").slice(0, 300), ex: "" };
        }).filter((x) => x.def.length > 1 && /\p{L}/u.test(x.def)));
        dd = false;
      }
    }
    return out.map((g) => ({ ...g, items: g.items.slice(0, 5) })).slice(0, 4);
  }
  async function defsNative(word, lang) {
    await ready;
    const b = base(lang);
    const map = { nb: "no", nn: "no", fil: "tl" };
    const ed = map[b] || b;
    if (!ed || ed === "en" || ed === "?" || !/^[a-z]{2,3}$/.test(ed)) return { defs: [] };
    const key = ["defs1", b, String(word).toLowerCase()].join("|");
    const c = cache.get(key);
    if (c && (c.defs.length || Date.now() - (c.at || 0) < 7 * 86400e3)) return c;
    const out = { defs: [], ed, url: "", at: Date.now() };
    for (const t of [...new Set([word, String(word).toLowerCase()])]) {
      let page;
      try { page = await otherPage(t, ed); } catch { page = null; }
      if (!page || page.error || !page.html) continue;
      out.defs = extractDefsAny(page.html, lang, ed);
      out.url = `https://${ed}.wiktionary.org/wiki/` + encodeURIComponent(page.title || t);
      if (out.defs.length) break;
    }
    cache.set(key, out);
    save();
    return out;
  }
  // registrazione della parola esatta da un'altra edizione di Wiktionary (se quella inglese non l'ha)
  async function audioOther(word, lang, target) {
    try { const o = await ipaOther(word, lang, target, "audio"); return { audio: (o && o.audio) || [], source: (o && o.audioSource) || "", form: (o && o.form) || "" }; }
    catch { return { audio: [], source: "" }; }
  }

  // pronuncia IPA da Wiktionary della parola esatta (non della forma base): gratis, senza token.
  // Prima l'edizione inglese (la stessa pagina degli altri strumenti), poi le altre edizioni.
  async function ipa(word, lang, target, ms = 9000) {
    const until = Date.now() + ms;
    const left = () => Math.max(500, until - Date.now());
    const race = (p) => Promise.race([p, new Promise((ok) => setTimeout(() => ok(null), left()))]);
    let r = null;
    try { r = await race(get(word, lang, target)); } catch {}
    const ok = r && r.ipa && String(r.ipaTitle || "").toLowerCase() === String(word || "").toLowerCase();
    if (ok) return { ipa: r.ipa, info: r, source: "Wiktionary" };
    let o = null;
    try { o = await race(ipaOther(word, lang, target)); } catch {}
    return { ipa: (o && o.ipa) || "", info: r, source: (o && o.source) || "" };
  }
  // etimologia corretta da te (⚑ → Correggi a mano): vince su tutto e resta salvata; "" = togli la correzione
  function override(word, lang, target, text) {
    const key = [base(lang) || "?", String(word).toLowerCase(), base(target)].join("|");
    const c = cache.get(key) || {};
    if (text && String(text).trim()) cache.set(key, { ...c, trans: String(text).trim(), fixed: true, prevTrans: c.fixed ? c.prevTrans : c.trans, prevSource: c.fixed ? c.prevSource : c.source, source: "corretta da te", none: false });
    else if (c.fixed) cache.set(key, { ...c, trans: c.prevTrans || "", source: c.prevSource || "", fixed: false, none: !c.prevTrans });
    saveNow();
    return cache.get(key);
  }
  // ritraduce il testo di Wiktionary (senza segnaposto: a volte la prima traduzione è venuta male); toglie le correzioni
  async function retranslate(word, lang, target) {
    const key = [base(lang) || "?", String(word).toLowerCase(), base(target)].join("|");
    const c = cache.get(key);
    if (!c || !c.text) return c;
    const plain = await translate(c.text, target);
    const marked = await translate(c.text, target, c.marked, c.mentions);
    const out = { ...c, trans: c.trans === marked && plain ? plain : marked, fixed: false, source: "Wiktionary" };
    cache.set(key, out);
    saveNow();
    return out;
  }
  const peek = (word, lang, target) => cache.get([base(lang) || "?", String(word || "").toLowerCase(), base(target)].join("|"));
  return { get, fromModel, put, peek, extract, ipa, extractIpaAny, extractAudioAny, audioIn, override, retranslate, audioOther, defsNative, extractDefsAny, sameWord, fileWord };
})();

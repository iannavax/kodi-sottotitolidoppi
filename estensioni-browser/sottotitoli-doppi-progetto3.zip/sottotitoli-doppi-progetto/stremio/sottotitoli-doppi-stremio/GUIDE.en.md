# Sottotitoli Doppi for Stremio

*Versione italiana → [LEGGIMI](LEGGIMI.md)*

A subtitle add-on for Stremio: for films and series it offers the subtitles in the original language with **the translation under every line** (in yellow).

## How it works
A Stremio add-on isn't installed inside the app: it's a small service running on your computer that Stremio asks for subtitles when you open a film or an episode.
1. The add-on takes subtitles from the OpenSubtitles service Stremio already uses, in **every language available** for that film (except the one you translate into).
2. In Stremio's subtitle list you'll find a dual version for each language, e.g. **"Doppi: Francese → Italiano"** (*dual: French → Italian*): choose the one in the language the film is spoken in. Any language works.
3. The dual file has the original on top and the translation below. If it's out of sync, you can ask for 2 or 3 versions per language in the configuration and try the next one.

The film's language is recognised from its country of production and listed first ("lingua del film", *film's language*).

**When to translate** (setting "Quando tradurre", since 1.3): Stremio asks for the subtitle list for every film you open, even those you won't use dual subtitles for. By default the add-on only downloads the original file of the first language (free) and **translates only when you pick a "Doppi" version**: no Gemini quota wasted. Choose "In anticipo" (*in advance*) to translate the first language as soon as you open a film (faster the first time, but it uses quota even for films where you don't use them). Films translated once are saved and load at once either way. If you always want one language only, choose it in "Lingue originali da proporre" (*original languages to offer*).

Translation starts as soon as you open the film's page. Stremio only waits a few seconds for the file, so with Gemini any lines not yet translated are completed instantly with Google and the subtitle always loads. Gemini keeps working and its version is saved: next time you open that film (or if you reselect it after a few minutes) you get Gemini's full translation.

## Installation (Stremio for desktop)
1. Install **Node.js** (LTS version) from nodejs.org, if you don't have it.
2. Unzip the archive into a folder.
3. Start the add-on:
   - **Windows**: double-click `avvia-windows.bat`.
   - **Mac / Linux**: `sh avvia-mac-linux.sh` in the Terminal.

   The configuration page opens and a black window stays open: **leave it open** while you use Stremio.
4. On the page choose the language to translate into and the service. For Gemini, Groq and the others paste your key (the same keys as the browser extension).
5. Press **Installa in Stremio** (*install in Stremio*). If Stremio doesn't open, press **Copia l'indirizzo** (*copy address*) and paste it into the search bar of Stremio's Add-ons section.

To change settings: in Stremio, Add-ons → Sottotitoli Doppi → Configure, then reinstall.

## Phones, tablets, TVs
Stremio's apps on these devices only accept add-ons reachable over the Internet with an **https** address. The add-on therefore has to be put online: for example on a Node.js hosting service, or on your computer behind an https tunnel such as Cloudflare Tunnel. Start it with:
- `HOST=0.0.0.0` to accept outside connections;
- `PUBLIC_URL=https://public-address` so subtitle links point to the right address.

Warning: your translation service key is part of the add-on's address, so don't share it.

## Advanced settings (environment variables)
- `PORT`: port (default 7000).
- `SD_WAIT_MS`: how many milliseconds to wait for the chosen service before completing with Google (default 3000).
- `SD_FILL_MS`: maximum time to complete with Google before answering anyway (default 6000).

Translations are saved in the `cache` folder. You can delete it at any time.

## Updating
Close the black window, replace the files in the same folder (you can keep the `cache` folder) and start it again. No need to reinstall the add-on in Stremio.

## Troubleshooting
The black window logs every request from Stremio, with the time and how long the file took: if a subtitle doesn't appear, the reason is there.

## Limitations
- The film needs original subtitles on OpenSubtitles: for content without them, the add-on offers nothing. Audio transcription isn't possible, because Stremio add-ons have no access to the video (for films on your computer, use the Kodi add-on).
- The add-on only reads OpenSubtitles. If Stremio lists subtitles in a language with no "Doppi" version, they may come from another subtitle add-on you've installed.
- The translation colour works in Stremio for desktop. If on a device you see codes like `<font…>`, turn on **"Traduzione senza colore"** (*translation without colour*) in the configuration.
- Words can't be clicked as in the browser extension.

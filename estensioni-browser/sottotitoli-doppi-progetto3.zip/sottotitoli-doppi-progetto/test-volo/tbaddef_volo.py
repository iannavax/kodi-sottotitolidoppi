# Parole al Volo: risposta del modello sbagliata (parola non tradotta, spiegazione in arabo) → riprova; poi Google
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def run(mode):
    os.environ["BAD_DEFINE"] = mode
    tvolo.log["define_sys"] = []
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'groq', learnExamples:false, learnSpell:false, learnFreq:false, etym:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "ru", "Кошка", 2500)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.get_by_role("button", name="Spiega con Groq").click(); await pg.wait_for_timeout(6000)
        t = await tvolo.card_text(pg)
        print(mode, "→ significato:", await pg.evaluate("(document.querySelector('.pav-meaning')||{}).textContent"), "| arabo nella scheda:", any("؀" <= ch <= "ۿ" for ch in t),
              "| richieste (con istruzioni rigide):", tvolo.log["define_sys"], "| fonte:", await pg.evaluate("(document.querySelector('.pav-source')||{}).textContent"))
        print("   errori:", errs, tvolo.log["errors"])
        await ctx.close()
async def main():
    await run("once"); await run("always")
asyncio.run(main())

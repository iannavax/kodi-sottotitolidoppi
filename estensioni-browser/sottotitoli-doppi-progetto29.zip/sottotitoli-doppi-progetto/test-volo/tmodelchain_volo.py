# 1.6.1: sulle pagine, «Spiega con Gemini»: Flash ha finito le richieste di oggi → rifà subito con Flash-Lite (non si ferma tutto Gemini)
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
os.environ["GEM_DAILY_MODEL"] = "gemini-flash-latest"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
CARD = "(document.querySelector('.pav-card')||{}).innerText||''"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'gemini', pavEngine:'gemini', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "bread", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1200)
        btn = pg.locator(".pav-card button", has_text="Spiega con")
        print("pulsante:", await btn.first.text_content())
        await btn.first.click()
        for _ in range(40):
            if "gemini-flash-lite-latest" in tvolo.log.get("gmodels", []): break
            await pg.wait_for_timeout(500)
        await pg.wait_for_timeout(2500)
        c = await pg.evaluate(CARD)
        print("modelli:", tvolo.log.get("gmodels"), "|", [l for l in c.split("\n") if "pane" in l or "Fonte" in l][:3])
        ok = tvolo.log.get("gmodels", [])[-1:] == ["gemini-flash-lite-latest"] and "pane (nel contesto)" in c
        print("errori:", errs if ok else errs + ["catena dei modelli sulle pagine non va"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

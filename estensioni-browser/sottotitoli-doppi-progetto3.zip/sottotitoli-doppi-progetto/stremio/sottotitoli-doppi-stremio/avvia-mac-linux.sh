#!/bin/sh
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "Serve Node.js: scaricalo da https://nodejs.org (versione LTS), poi rilancia."; exit 1; }
( sleep 1; (command -v open >/dev/null && open http://127.0.0.1:7000/configure) || (command -v xdg-open >/dev/null && xdg-open http://127.0.0.1:7000/configure) ) >/dev/null 2>&1 &
node server.js

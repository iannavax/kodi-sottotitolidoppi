import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
sys.path.insert(0, "/home/claude/e2e")
import charness
async def handle(route, request):
    if request.url.startswith("https://jisho.org/") or ".wiktionary.org/" in request.url: return await charness.handle(route, request)
    return await tvolo.handle(route, request)
EXT = sys.argv[1]
R = "[...document.querySelectorAll('.pav-card .pav-word .pav-dsr')].map(x=>x.dataset.r).join('-')"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', learnExamples:false, learnFreq:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "ru", "Кошка", 2000)
        print("1. spento:", repr(await pg.evaluate(R)), "| Aa:", await pg.locator(".pav-card .pav-romabtn").count())
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.locator(".pav-card .pav-romabtn").click(); await pg.wait_for_timeout(300)
        print("2. acceso:", await pg.evaluate(R), "| parola:", await pg.evaluate("document.querySelector('.pav-card .pav-word').textContent"))
        await pg.keyboard.press("Escape"); await tvolo.hover(pg, "ja", "勉強", 3500)
        print("3. giapponese (lettura di Jisho sopra i kanji):", repr(await pg.evaluate(R)), "| testo:", await pg.evaluate("document.querySelector('.pav-card .pav-word').textContent"))
        await tvolo.hover(pg, "en", "bread", 1500)
        print("4. inglese: Aa", await pg.locator(".pav-card .pav-romabtn").count())
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

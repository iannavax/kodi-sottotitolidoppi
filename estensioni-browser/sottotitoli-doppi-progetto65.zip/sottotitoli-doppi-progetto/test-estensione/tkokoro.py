import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        r = await sw.evaluate("handleMessage ? 0 : 0") if False else None
        pg = await ctx.new_page(); await pg.goto("https://www.youtube.com/watch?v=ruRoman"); await pg.wait_for_timeout(1000)
        ext = sw.url.split("/")[2]
        pop = await ctx.new_page(); await pop.goto(f"chrome-extension://{ext}/popup.html"); await pop.wait_for_timeout(800)
        lst = await pop.evaluate("chrome.runtime.sendMessage({type:'speachesTts', op:'list'})")
        sp = await pop.evaluate("chrome.runtime.sendMessage({type:'speachesTts', op:'speakKokoro', key:'if_sara', text:'Ciao a tutti'}).then(r=>({n:(r.audio||'').length, e:r.error}))")
        print("elenco:", lst, "| voce if_sara:", sp)
        print("richieste al server:", [json.loads(x).get("model","")+"/"+json.loads(x).get("voice","") for x in log.get("speaches_tts", [])])
        v = await pop.evaluate("[dsKokoroVoices('it').map(v=>v.key+':'+v.label), dsKokoroVoices('en').length, dsKokoroVoices('pt').map(v=>v.key)]")
        print("voci:", v)
        await ctx.close()
asyncio.run(main())

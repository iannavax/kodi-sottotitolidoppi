import json, sys, time, base64, urllib.request, re
B = "http://127.0.0.1:7000"
def get(p):
    with urllib.request.urlopen(B + p if p.startswith("/") else p, timeout=60) as r:
        return r.status, r.headers.get("Content-Type"), r.headers.get("Access-Control-Allow-Origin"), r.read().decode("utf-8")
cfgs = json.loads(sys.argv[1])
cfg = base64.urlsafe_b64encode(json.dumps(cfgs).encode()).decode().rstrip("=")
st, ct, cors, body = get("/manifest.json"); m = json.loads(body)
print("1. manifesto base:", st, m["id"], m["resources"], "| da configurare:", m["behaviorHints"]["configurationRequired"], "| CORS:", cors)
st, ct, cors, body = get("/configure"); print("2. pagina di configurazione:", st, ct.split(";")[0], "| contiene il pulsante:", "Installa in Stremio" in body)
st, ct, cors, body = get(f"/{cfg}/manifest.json"); print("3. manifesto configurato:", json.loads(body)["description"])
t0 = time.time()
st, ct, cors, body = get(f"/{cfg}/subtitles/movie/tt0111161/filename=film.mkv&videoHash=abc&videoSize=123.json")
subs = json.loads(body)["subtitles"]
print("4. elenco per Stremio (%.1fs):" % (time.time() - t0), [(s["lang"], s["url"].split("?")[0][-30:]) for s in subs])
time.sleep(float(sys.argv[2]) if len(sys.argv) > 2 else 0)
t0 = time.time()
st, ct, cors, srt = get(subs[0]["url"])
blocks = srt.strip().split("\n\n")
print("5. file doppio (%.1fs): %s, %d sottotitoli" % (time.time() - t0, ct.split(";")[0], len(blocks)))
print("   " + blocks[4].replace("\n", " / "))
gem = sum(1 for b in blocks if "GEM[" in b); goo = sum(1 for b in blocks if "IT[" in b)
ok = sum(1 for i, b in enumerate(blocks) if ("[" + " ".join(w[::-1] for w in ("this is the line number %d of the film" % (i + 1)).split()) + "]") in b)
print("   traduzioni: Gemini %d, Google %d, allineate alla loro frase %d/%d" % (gem, goo, ok, len(blocks)))
print("   servizi:", urllib.request.urlopen("http://127.0.0.1:7801/log").read().decode())

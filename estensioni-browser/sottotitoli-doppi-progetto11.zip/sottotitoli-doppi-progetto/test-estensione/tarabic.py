# 5.21: traduzione che arriva in arabo (alfabeto sbagliato): scartata, al suo posto Google; ⚑ → tutta la traduzione sbagliata
import asyncio, os, sys
os.environ.setdefault("GEM_MODE", "arabic")
sys.path.insert(0, "/home/claude/e2e")
from charness import *
TR = "(document.querySelector('.dualsub-trans')||{}).textContent||''"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', idioms:false}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=arabicTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_timeout(9000)
        seen = set()
        for _ in range(20):
            t = await pg.evaluate(TR)
            if t: seen.add(t[:40])
            await pg.wait_for_timeout(300)
        print("1. traduzioni viste:", sorted(seen)[:4], "| arabe:", [x for x in seen if any('؀' <= c <= 'ۿ' for c in x)])
        saved = await sw.evaluate("chrome.storage.local.get(null).then(r=>JSON.stringify(Object.entries(r).filter(([k])=>k.startsWith('cache:')).map(([k,v])=>[k.slice(0,40), JSON.stringify(v).slice(0,80)])))")
        print("   salvate:", saved[:200])
        await pg.evaluate("document.querySelector('video').currentTime = 2")
        await pg.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent", timeout=10000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
        await pg.evaluate("document.querySelector('.dualsub-fixbtn').click()"); await pg.wait_for_timeout(500)
        print("2. menu ⚑:", await pg.evaluate("[...document.querySelectorAll('.dualsub-fix-whole button')].map(b=>b.textContent)"))
        await pg.evaluate("[...document.querySelectorAll('.dualsub-fix-whole button')].find(b=>/Google/.test(b.textContent)).click()"); await pg.wait_for_timeout(500)
        print("3. servizio per questo video:", await sw.evaluate("chrome.storage.local.get('videoEngine').then(r=>JSON.stringify(r.videoEngine))"))
        await pg.evaluate("document.querySelector('video').currentTime = 1; document.querySelector('video').play()"); await pg.wait_for_timeout(5000)
        print("   ora:", await pg.evaluate(TR), "| stato:", await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status.text)"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

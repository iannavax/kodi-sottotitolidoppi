## Correzioni della 5.2

- **Sottotitoli a blocchi enormi e traduzione sfasata.** Whisper restituiva pezzi di lunghezza molto variabile, da una parola a 30 secondi, e il modello a volte metteva la traduzione di una frase sotto il pezzo accanto. Ora l'estensione chiede a Whisper i tempi delle singole parole e ritaglia lei le frasi: divise ai punti (e alle virgole se troppo lunghe), con i frammenti di una o due parole uniti a quelli vicini. Ogni traduzione viene poi controllata. Se è vuota o sproporzionata rispetto alla sua frase, il blocco viene ritradotto in pezzi più piccoli invece di essere accettato sfasato. Intanto sotto ogni frase resta la traduzione rapida, al posto giusto.
- **Traduzione quasi uguale all'originale** (con una virgola o una parola in più): ora viene riconosciuta per somiglianza, non solo quando è identica. Viene sostituita da Google e non viene salvata.
- **Traduzioni sbagliate salvate dalle versioni precedenti:** quelle vuote, sproporzionate o ricopiate vengono scartate da sole quando riapri il video, e richieste di nuovo. Per i video già trascritti in pezzi enormi, usa **Rifai la trascrizione** nella pagina "Trascrizione e traduzione".
- **Popup su Firefox:** non esce più dai bordi. Anche i menu con opzioni lunghe restano dentro la finestra. Inoltre il campo "Indirizzo del server" ora compare solo quando serve.


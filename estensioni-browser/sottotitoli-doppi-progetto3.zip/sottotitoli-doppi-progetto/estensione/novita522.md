## Correzioni della 5.2.2

- **Video di YouTube incorporati in altri siti** (per esempio i canali di TV Garden e dei siti IPTV): ora la trascrizione parte da sola anche lì, come sul sito di YouTube. Prima partiva solo premendo il pulsante nel popup.
- **Dirette con l'indirizzo "live_stream":** per l'estensione, tutte le dirette incorporate con quell'indirizzo sembravano lo stesso video. Aprendo un secondo canale, caricava il testo del primo e non trascriveva niente. Ora usa l'identificativo vero del video. Le trascrizioni salvate per errore sotto quel nome vengono cancellate all'aggiornamento.
- **Dirette in generale:** non vengono più salvate né ricaricate, perché ogni volta è una trasmissione diversa. In modalità Completa passano da sole a "Mentre guardo", visto che una diretta non si può scaricare tutta.
- **Video muto:** se la trascrizione è attiva ma il video è senza audio, la riga di stato te lo dice.


# 5.8.2: frasi brevi (una o due parole) ricopiate uguali dal modello → Google; i nomi restano e non si richiedono più
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
os.environ["GEM_MODE"] = "shortcopy"; os.environ["GEM_DELAY"] = "0.5"
from charness import *
EXP = {"Ja.": "Sì.", "Nej!": "No!", "Tak.": "Grazie.", "Karen.": "Karen.", "Okay.": "Okay."}
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it'})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        async def cache():
            st = await sw.evaluate("chrome.storage.local.get(null)")
            k = next((k for k in st if k.startswith("cache:shortCopy") and "gemini" in k), None)
            return (st.get(k) if k else None), k, st.get("copieOk", [])
        async def watch():
            await pg.goto("https://www.youtube.com/watch?v=shortCopy"); await pg.wait_for_timeout(1000)
            await pg.evaluate("document.querySelector('video').play()")
            for _ in range(60):
                c, k, ok = await cache()
                if c and all(c): break
                await pg.wait_for_timeout(500)
            await pg.wait_for_timeout(1500)
            return await cache()
        # 1. prima volta
        c, k, ok = await watch()
        res = dict(zip(SHORT_LINES, c or []))
        print("1.", res)
        print("   controllate:", ok)
        ok1 = all(res.get(a) == b for a, b in EXP.items()) and all(str(res.get(l, "")).startswith("GEM[") for l in SHORT_LINES if len(l.split()) > 2)
        ok1 = ok1 and "it|karen" in ok and "it|okay" in ok and "it|ja" not in ok
        # 2. rivisto: nessuna richiesta a Gemini, nessuna a Google per i nomi
        log["gemsegs"] = []; log["gtexts"] = []
        c, k, ok = await watch()
        print("2. rivisto: Gemini", log["gemsegs"], "| Google per i nomi:", [t for t in log["gtexts"] if t in ("Karen.", "Okay.")])
        ok2 = not log["gemsegs"] and not [t for t in log["gtexts"] if t in ("Karen.", "Okay.")]
        # 3. traduzioni salvate da una versione precedente con le brevi ricopiate: si rifanno solo quelle
        old = list(c); old[SHORT_LINES.index("Ja.")] = "Ja."; old[SHORT_LINES.index("Tak.")] = "Tak."
        await sw.evaluate("([k, v]) => chrome.storage.local.set({[k]: v})", [k, old])
        log["gemsegs"] = []
        c, k, ok = await watch()
        res = dict(zip(SHORT_LINES, c or []))
        print("3. vecchia cache: Gemini ha ricevuto", log["gemsegs"], "|", res["Ja."], res["Tak."], res["Karen."])
        ok3 = log["gemsegs"] == [["Ja.", "Tak."]] and res["Ja."] == "Sì." and res["Tak."] == "Grazie." and res["Karen."] == "Karen."
        # 4. sullo schermo
        await pg.evaluate("document.querySelector('video').currentTime = 0.5"); await pg.wait_for_timeout(1200)
        shown = await pg.evaluate("(document.querySelector('.dualsub-trans')||{}).textContent")
        print("4. sullo schermo per 'Ja.':", shown)
        print("errori pagina:", errs[:3], "| simulatore:", log["errors"][:3])
        print("ESITO:", bool(ok1 and ok2 and ok3 and "Sì" in (shown or "") and not errs))
        await ctx.close()
asyncio.run(main())

import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
ST = "chrome.storage.local.get('status').then(r=>(r.status||{}).text)"
async def run(p, sticky, pause):
    ctx, sw = await launch(p, "", None)
    await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', transcribeMode:'live', stt:'local', sttUrl:'http://localhost:8000/v1', sttModel:'Systran/faster-whisper-small', cleanTranscript:false, videoModeSticky:'%s'})" % sticky)
    pg = await ctx.new_page()
    await pg.goto("https://www.youtube.com/watch?v=noCapsLocal"); await pg.wait_for_timeout(1500)
    await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(5000)
    s1 = await sw.evaluate(ST)
    s2 = None
    if pause:
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(4500)
        s2 = await sw.evaluate(ST)
    await ctx.close()
    return s1, s2
async def main():
    async with async_playwright() as p:
        a = await run(p, "", False)
        print("1. Whisper locale, predefinita:", a[0])
        b = await run(p, "live", True)
        print("2. scelto «mentre guardo», poi pausa:", b[0], "→", b[1])
        print("errori:", log["errors"])
asyncio.run(main())

# 1.6.2: nella scheda del singolo kanji, «✨ Spiega il kanji con …»: significati, letture, parole, parti, origine (una richiesta, salvata)
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false, hoverPause:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=jaKanji"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/勉強/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        await pg.locator(".dualsub-orig .dualsub-word", has_text="勉強").first.click()
        await pg.wait_for_selector(".dualsub-card .dsx-hanrow", timeout=8000)
        await pg.locator(".dualsub-card .dsx-hanchip", has_text="勉").click()
        await pg.wait_for_function("/tratti/.test((document.querySelector('.dualsub-card .dsx-hanpanel')||{}).textContent||'')", timeout=8000)
        b = pg.locator(".dualsub-card .dsx-hanask")
        print("1. pulsante:", await b.count(), await b.first.text_content() if await b.count() else "")
        await b.first.click()
        for _ in range(30):
            if log.get("hanexplain"): break
            await pg.wait_for_timeout(500)
        await pg.wait_for_timeout(1500)
        t = await pg.evaluate("(document.querySelector('.dualsub-card .dsx-hanllm')||{}).innerText||''")
        print("   pannello:", (await pg.evaluate("(document.querySelector('.dualsub-card .dsx-hanpanel')||{}).innerText||''"))[-300:].replace("\n"," | "))
        print("2. spiegazione:", t.replace("\n", " | ")[:300], "| richieste:", log.get("hanexplain"))
        ok = "SIGN[勉]" in t and "Parole comuni" in t and log.get("hanexplain") == ["勉"]
        print("errori:", errs if ok else errs + ["kanji con il modello non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

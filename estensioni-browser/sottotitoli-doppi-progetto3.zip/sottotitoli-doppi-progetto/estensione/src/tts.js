// Pronuncia delle parole: voce del sistema nella lingua giusta, altrimenti la voce online di Google.
// Usata dalla scheda delle parole (pagina) e dal pulsante "Prova la voce" (popup).
var DS_TTS = (() => {
  let ctx = null;
  const norm = (l) => String(l || "").trim().replace(/_/g, "-");
  // stessi codici per le stesse lingue (le voci di Windows usano nb-NO, he-IL, fil-PH, jv-ID…)
  const SAME = { nb: "no", iw: "he", fil: "tl", jv: "jw", in: "id" };
  const base = (l) => { const b = norm(l).split("-")[0].toLowerCase(); return SAME[b] || b; };

  // L'elenco delle voci arriva in ritardo: lo chiedo subito al caricamento e lo tengo aggiornato,
  // così al clic su 🔊 è già pronto (aspetto al massimo una volta, e poco)
  // voce scelta per ogni lingua ({ cs: "voiceURI" | "google" | "azure:cs-CZ-VlastaNeural" }) e Azure acceso
  let my = { ttsVoices: {}, azureTts: false };
  try {
    DS_EXT.storage.sync.get({ ttsVoices: {}, azureTts: false }).then((r) => { my = r; }).catch(() => {});
    DS_EXT.storage.onChanged.addListener((ch, area) => {
      if (area !== "sync") return;
      if (ch.ttsVoices) my.ttsVoices = ch.ttsVoices.newValue || {};
      if (ch.azureTts) my.azureTts = !!ch.azureTts.newValue;
    });
  } catch {}

  let cached = [];
  let waited = false;
  if (window.speechSynthesis) {
    cached = speechSynthesis.getVoices();
    speechSynthesis.addEventListener("voiceschanged", () => { cached = speechSynthesis.getVoices(); });
  }
  function voicesReady() {
    return new Promise((res) => {
      if (!window.speechSynthesis) return res([]);
      if (!cached.length) cached = speechSynthesis.getVoices();
      if (cached.length || waited) return res(cached);
      waited = true;
      let done = false;
      const finish = () => { if (!done) { done = true; cached = speechSynthesis.getVoices(); res(cached); } };
      speechSynthesis.addEventListener("voiceschanged", finish, { once: true });
      setTimeout(finish, 600);
    });
  }

  // La voce migliore per una lingua: stessa variante regionale, poi voci "naturali"/online
  function pickVoice(voices, lang) {
    const b = base(lang);
    if (!b) return null;
    const full = norm(lang).toLowerCase();
    const cands = voices.filter((v) => base(v.lang) === b);
    if (!cands.length) return null;
    // prima le voci "Natural", poi quelle online/neurali, poi la variante regionale giusta
    const score = (v) =>
      (/natural/i.test(v.name) ? 6 : /neural|online|google|premium|enhanced/i.test(v.name) ? 3 : 0) +
      (norm(v.lang).toLowerCase() === full ? 2 : 0) +
      (v.default ? 1 : 0);
    return cands.sort((x, y) => score(y) - score(x))[0];
  }

  let speakRate = 0.9;   // velocità della voce (0,6 = lenta), scelta a ogni speak
  // Restituisce una promessa che si risolve quando la voce ha finito di parlare
  function speakSystem(text, voice, lang) {
    return new Promise((res) => {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      if (voice) u.voice = voice;
      u.lang = voice ? voice.lang : norm(lang);
      u.rate = speakRate;
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        // libero subito la sintesi vocale: tenerla aperta può lasciare abbassati gli altri suoni
        setTimeout(() => { try { if (!speechSynthesis.speaking) speechSynthesis.cancel(); } catch {} }, 150);
        res();
      };
      u.onend = u.onerror = finish;
      speechSynthesis.speak(u);
      setTimeout(finish, 10000);
    });
  }

  function b64ToBuffer(b64) {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes.buffer;
  }

  async function speakGoogle(text, lang) {
    const r = await DS_EXT.runtime.sendMessage({ type: "tts", text, lang });
    if (!r || r.error) throw new Error((r && r.error) || "nessuna risposta");
    return playB64(r.audio);
  }
  // voci naturali di Microsoft (Azure Speech, con la tua chiave): le scarica il background
  async function speakAzure(text, lang, voice) {
    const r = await DS_EXT.runtime.sendMessage({ type: "azureTts", text, lang, voice: voice || "" });
    if (!r || r.error) throw new Error((r && r.error) || "nessuna risposta");
    return { voice: r.voice, ended: playB64(r.audio) };
  }
  async function playB64(audio) {
    ctx = ctx || new AudioContext();
    if (ctx.state === "suspended") await ctx.resume();
    const buf = await ctx.decodeAudioData(b64ToBuffer(audio));
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = speakRate / 0.9;
    src.connect(ctx.destination);
    return new Promise((res) => {
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        // spengo il canale audio quando ha finito, invece di lasciarlo aperto
        setTimeout(() => { if (ctx && ctx.state === "running") ctx.suspend().catch(() => {}); }, 300);
        res();
      };
      src.onended = finish;
      src.start();
      setTimeout(finish, buf.duration * 1000 + 2000);
    });
  }

  // Ordine: la voce scelta per quella lingua (⚙ nella scheda o popup) → Azure, se acceso → la voce migliore del
  // computer per la lingua (prima le "Natural") → la voce online di Google.
  // prefs.voice: voce scelta nel popup ("google" = sempre Google; una voce del computer vale solo per la sua lingua)
  // prefs.lang: lingua scelta a mano (vince su quella rilevata)
  async function speak(text, lang, prefs = {}) {
    speakRate = prefs.rate || 0.9;
    const want = norm(prefs.lang || lang);
    const b = base(want);
    const voices = await voicesReady();
    let choice = (b && (my.ttsVoices || {})[b]) || "";
    if (!choice && prefs.voice) {
      if (prefs.voice === "google") choice = "google";
      else { const v = voices.find((x) => x.voiceURI === prefs.voice); if (v && (!b || base(v.lang) === b)) choice = prefs.voice; }
    }
    let note = "";
    // "done" si risolve quando la pronuncia è finita (serve per rialzare il volume del video)
    if (want && (choice.startsWith("azure:") || (!choice && my.azureTts))) {
      try {
        const a = await speakAzure(text, want, choice.startsWith("azure:") ? choice.slice(6) : "");
        await Promise.race([a.ended.then(() => 0), new Promise((r) => setTimeout(r, 50))]);
        return { how: `voce Microsoft "${a.voice}" (Azure)`, done: a.ended, voice: a.voice };
      } catch (e) { note = " (Azure non disponibile: " + e.message + ")"; }
    }
    if (choice && choice !== "google" && !choice.startsWith("azure:")) {
      const v = voices.find((x) => x.voiceURI === choice);
      if (v) return { how: `voce "${v.name}"` + note, done: speakSystem(text, v), voice: v.name };
    }
    if (choice !== "google" && want) {
      const v = pickVoice(voices, want);
      if (v) return { how: `voce "${v.name}"` + note, done: speakSystem(text, v), voice: v.name };
    }
    if (want || choice === "google") {
      try {
        const ended = speakGoogle(text, want || "en");
        await Promise.race([ended.then(() => 0), new Promise((r) => setTimeout(r, 50))]);
        return { how: "voce online di Google" + note, done: ended, voice: "Google" };
      } catch (e) { if (choice === "google") return { how: "voce di Google non disponibile: " + e.message, done: Promise.resolve() }; }
    }
    if (window.speechSynthesis) {
      return { how: "voce predefinita del sistema" + (want ? ` (nessuna voce per "${want}")` : "") + note, done: speakSystem(text, null, want) };
    }
    return { how: "nessuna voce disponibile", done: Promise.resolve() };
  }

  // Le voci tra cui scegliere per una lingua (⚙ nella scheda, popup): { value, label, kind }
  async function voiceOptions(lang) {
    const b = base(lang);
    const out = [{ value: "", label: "Automatica (la migliore disponibile)", kind: "auto" }];
    const sys = (await voicesReady()).filter((v) => base(v.lang) === b)
      .sort((x, y) => (/natural/i.test(y.name) - /natural/i.test(x.name)) || x.name.localeCompare(y.name));
    for (const v of sys) out.push({ value: v.voiceURI, label: v.name + " (" + v.lang + ")", kind: "system" });
    if (my.azureTts) {
      try {
        const r = await DS_EXT.runtime.sendMessage({ type: "azureVoices" });
        for (const v of (r && r.list) || []) if (base(v.locale) === b) out.push({ value: "azure:" + v.name, label: "Azure: " + v.label + " (" + v.locale + (v.gender ? ", " + v.gender : "") + ")", kind: "azure" });
      } catch {}
    }
    out.push({ value: "google", label: "Voce online di Google", kind: "google" });
    return out;
  }
  const voiceFor = (lang) => ((my.ttsVoices || {})[base(lang)] || "");
  async function setVoice(lang, value) {
    const b = base(lang);
    if (!b) return;
    const m = { ...(my.ttsVoices || {}) };
    if (value) m[b] = value; else delete m[b];
    my.ttsVoices = m;
    await DS_EXT.storage.sync.set({ ttsVoices: m }).catch(() => {});
  }

  // Piccolo menu "voce per questa lingua" (⚙ accanto a 🔈 nella scheda). onPick(value) dopo la scelta.
  function voiceMenu(lang, onPick) {
    const box = document.createElement("div");
    box.className = "ds-voicemenu";
    const t = document.createElement("div");
    t.className = "ds-voicemenu-title";
    try { const n = new Intl.DisplayNames(["it"], { type: "language" }).of(base(lang)); t.textContent = "Voce per: " + n; } catch { t.textContent = "Voce per: " + base(lang); }
    box.append(t);
    const list = document.createElement("div");
    list.className = "ds-voicemenu-list";
    list.textContent = "…";
    box.append(list);
    voiceOptions(lang).then((opts) => {
      list.textContent = "";
      const cur = voiceFor(lang);
      for (const o of opts) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "ds-voicemenu-item" + (o.value === cur ? " ds-on" : "");
        btn.textContent = (o.value === cur ? "● " : "") + o.label;
        btn.addEventListener("click", async (e) => {
          e.preventDefault(); e.stopPropagation();
          await setVoice(lang, o.value);
          if (onPick) onPick(o.value);
        });
        list.append(btn);
      }
      if (opts.filter((o) => o.kind === "system").length === 0) {
        const n = document.createElement("div");
        n.className = "ds-voicemenu-note";
        n.textContent = "Sul computer non c'è una voce per questa lingua: si aggiunge da Windows → Impostazioni → Ora e lingua → Voce. Oppure usa Azure (popup).";
        list.append(n);
      }
    });
    return box;
  }

  return { speak, voicesReady, pickVoice, base, voiceOptions, voiceFor, setVoice, voiceMenu };
})();

# 1.7.17: trascrizione già salvata → usata al posto dei sottotitoli automatici di YouTube
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def run(p, on):
    ctx, sw = await launch(p, "", None)
    cues = [{"s": i * 2500, "e": i * 2500 + 2300, "t": f"SALVATA frase numero {i+1} del video"} for i in range(8)]
    await sw.evaluate("chrome.storage.local.set({'live:gdTest': {cues: %s, covered: [[0, 20000]], lang: 'en', full: true}})" % str(cues).replace("'", '"'))
    await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, useSavedTranscript:%s})" % ("true" if on else "false"))
    pg = await ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
    await pg.evaluate("document.querySelector('video').play()")
    await pg.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent", timeout=40000)
    await pg.wait_for_timeout(2500)
    txt = await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent")
    st = await sw.evaluate("chrome.storage.local.get('status').then(r => (r.status||{}).text)")
    await ctx.close()
    return txt, st, errs
async def main():
    async with async_playwright() as p:
        a = await run(p, False); b = await run(p, True)
        print("opzione spenta:", a[0]); print("opzione accesa:", b[0], "|", b[1])
        ok = "SALVATA" not in a[0] and "SALVATA" in b[0]
        print("errori:", a[2] + b[2] if ok else a[2] + b[2] + ["non usa la trascrizione salvata"], log["errors"])
asyncio.run(main())

# 1.10: modi di dire trovati da soli in Parole al Volo, sottolineati sulla pagina, nella scheda con ⚑
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
HL = "CSS.highlights.has('pav-idiom') ? [...CSS.highlights.get('pav-idiom')].map(r=>r.toString()) : []"
IDI = "(document.querySelector('.pav-card .pav-idiom')||{}).innerText||'(nessuno)'"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(1500)
        print("0. prima:", await pg.evaluate(HL))
        await tvolo.hover(pg, "en", "home", 3500)
        print("1. richieste:", tvolo.log.get("idiomsFind"), "| scheda:", (await pg.evaluate(IDI)).replace("\n", " | "))
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(1500)
        print("2. sottolineato sulla pagina:", await pg.evaluate(HL))
        await tvolo.hover(pg, "en", "walked", 2500)
        print("3. walked:", (await pg.evaluate(IDI)).replace("\n", " | "), "| richieste:", len(tvolo.log.get("idiomsFind")))
        await tvolo.hover(pg, "en", "home", 2500)
        print("4. stessa frase di nuovo: richieste", len(tvolo.log.get("idiomsFind")))
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.locator(".pav-card button", has_text="⚑ modo di dire sbagliato?").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card button", has_text="Non è un modo di dire").click(); await pg.wait_for_timeout(1500)
        print("5. tolto:", await pg.evaluate(IDI), "| pagina:", await pg.evaluate(HL))
        await tvolo.hover(pg, "long", "weather", 3000)
        print("6. frase senza modi di dire: richieste", len(tvolo.log.get("idiomsFind")), "| scheda:", await pg.evaluate(IDI))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

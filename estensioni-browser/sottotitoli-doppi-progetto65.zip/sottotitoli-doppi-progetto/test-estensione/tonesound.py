# 1.7.11: premendo più volte 🔈 / 🔊 parte una sola voce alla volta
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
INIT = """(() => { window.__act = 0; window.__max = 0; window.__starts = 0;
  const S = AudioBufferSourceNode.prototype, st = S.start, sp = S.stop;
  S.start = function() { window.__starts++; window.__act++; window.__max = Math.max(window.__max, window.__act); this.addEventListener('ended', () => { if (!this.__d) { this.__d = 1; window.__act--; } }); return st.apply(this, arguments); };
  S.stop = function() { if (!this.__d) { this.__d = 1; window.__act--; } return sp.apply(this, arguments); };
})()"""
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false, ttsVoice:'google', ttsLang:'en'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        cdp = await ctx.new_cdp_session(pg); cids = []
        cdp.on("Runtime.executionContextCreated", lambda e: cids.append(e["context"]) )
        await cdp.send("Runtime.enable")
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        async def ev(expr):
            for c in cids:
                if (c.get("origin") or "").startswith("chrome-extension://") and "dualsub" in str(c.get("name","")).lower() + "dualsub":
                    try:
                        r = await cdp.send("Runtime.evaluate", {"expression": expr, "contextId": c["id"], "returnByValue": True})
                        if "result" in r and not r.get("exceptionDetails"): return r["result"].get("value")
                    except Exception: pass
        ids = [(c["id"], c.get("origin"), c.get("name")) for c in cids]
        print("contesti:", ids[:6])
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        print("patch:", await ev(INIT))
        for sel in (".dualsub-card .dualsub-speak:not(.dualsub-rec)", ".dualsub-card .dualsub-rec"):
            n = await pg.locator(sel).count()
            if not n: print(sel, "assente"); continue
            await ev("window.__max = 0; window.__starts = 0")
            for _ in range(5): await pg.locator(sel).first.click(); await pg.wait_for_timeout(60)
            await pg.wait_for_timeout(3500)
            print(sel, "→ avviati:", await ev("window.__starts"), "| contemporanei al massimo:", await ev("window.__max"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

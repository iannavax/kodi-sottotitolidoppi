import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/popup.html"); await pg.wait_for_timeout(1200)
        print("checkbox:", await pg.evaluate("['learnFreq','learnKnown','ankiImage'].map(k=>document.getElementById(k).checked)"))
        await pg.evaluate("document.getElementById('dLearn').open=true; document.getElementById('dAnki').open=true"); await pg.check("#ankiImage"); await pg.uncheck("#learnFreq"); await pg.wait_for_timeout(400)
        print("salvate:", await sw.evaluate("chrome.storage.sync.get(['ankiImage','learnFreq'])"))
        pv = await ctx.new_page(); await pv.goto(f"chrome-extension://{eid}/vocab.html"); await pv.wait_for_timeout(500)
        await sw.evaluate("chrome.storage.local.set({vocab:{'en|bread':{id:'en|bread',word:'bread',lang:'en',meaning:'pane',gender:'neutro',image:'https://upload.wikimedia.org/x.jpg',status:'learning',added:1}}})")
        await pv.wait_for_timeout(600)
        print("vocab:", await pv.evaluate("document.querySelector('.entry').innerText.replace(/\\n/g,' | ')"), "| img:", await pv.evaluate("!!document.querySelector('.entry img')"))
        await pv.get_by_role("button", name="Segna come imparata").click(); await pv.wait_for_timeout(600)
        print("known:", await sw.evaluate("chrome.storage.local.get('knownWords')"))
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

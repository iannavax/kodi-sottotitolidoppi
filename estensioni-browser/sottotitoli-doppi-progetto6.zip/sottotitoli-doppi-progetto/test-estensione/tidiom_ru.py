# Modo di dire con una parola di una lettera: in "Я, к сожалению, не могу…" anche "к" va sottolineata in arancione
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', hoverPause:true})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ruIdiom"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/сожалению/.test((document.querySelector('.dualsub-orig')||{}).textContent||'') && document.querySelectorAll('.dualsub-tword').length>1", timeout=30000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
        words = pg.locator(".dualsub-orig .dualsub-word")
        texts = await words.all_inner_texts()
        print("parole:", texts)
        await words.nth(0).hover(); await pg.wait_for_timeout(8000)
        print("1. sottolineate:", await pg.evaluate("[...document.querySelectorAll('.dualsub-idiom')].map(x=>x.textContent)"), "| richieste:", len(log.get("align", [])))
        await pg.mouse.move(600, 40); await pg.wait_for_timeout(300)
        await words.nth(texts.index("сожалению")).hover(); await pg.wait_for_timeout(900)
        print("2. illuminate passando su сожалению:", await pg.evaluate("[...document.querySelectorAll('.dualsub-idiom-on')].map(x=>x.textContent)"), "| scheda:", await pg.evaluate("(document.querySelector('.dualsub-card-word')||{}).textContent"))
        # 2b. passo sulla traduzione di "сожалению": si illumina tutto il modo di dire
        tw = await pg.evaluate("[...document.querySelectorAll('.dualsub-tword')].map(x=>x.textContent)")
        print("   traduzione:", tw)
        await pg.mouse.move(600, 40); await pg.wait_for_timeout(300)
        k = next((i for i, t in enumerate(tw) if "юинелажос" in t or "MODO" in t or "purtroppo" in t), None)
        if k is not None:
            await pg.locator(".dualsub-tword").nth(k).hover(); await pg.wait_for_timeout(1200)
            print("2b. passando sulla traduzione:", await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-hl')].map(x=>x.textContent)"))
        # 3. il modo di dire trovato solo nella spiegazione (il modello non l'ha dato con l'allineamento): clic sulla parola
        if os.environ.get("NO_ALIGN_IDIOM"):
            await words.nth(texts.index("сожалению")).click(); await pg.wait_for_timeout(2500)
            print("3. dopo il clic su сожалению: scheda", (await pg.evaluate("(document.querySelector('.dualsub-card-idiom')||{}).textContent||''"))[:60], "| sottolineate:", await pg.evaluate("[...document.querySelectorAll('.dualsub-idiom')].map(x=>x.textContent)"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

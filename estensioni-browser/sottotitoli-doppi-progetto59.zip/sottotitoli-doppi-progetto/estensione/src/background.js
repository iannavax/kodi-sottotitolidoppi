// Chiamate ai servizi esterni: traduzione, significati delle parole, trascrizione.
// In Chrome/Edge gira come service worker, in Firefox come script di background
// (lì config.js è già caricato dal manifest).
if (typeof DS_CONFIG === "undefined" && typeof importScripts === "function") importScripts("config.js");
const C = DS_CONFIG;
dsMigrateShards();   // 1.7.3: cache della pronuncia e dell'etimologia a pezzi per lingua (vedi config.js)

// Messaggi dall'altra estensione (Sottotitoli Doppi ↔ Parole al Volo): parole conosciute e vocabolario
if (chrome.runtime.onMessageExternal) chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== "dsSync") return false;
  dsSyncReceive(msg, sender).then((r) => sendResponse(r), (e) => sendResponse({ error: String((e && e.message) || e) }));
  return true;
});
// Tutte le richieste delle pagine e del popup: la promessa con la risposta, oppure null se il tipo non è mio
function dsRoute(msg, sender) {
  let run;
  if (msg.type === "translate") run = translate(msg);
  else if (msg.type === "define") run = define(msg);
  else if (msg.type === "listModels") run = listModels(msg);
  else if (msg.type === "sttModels") run = sttModels(msg);
  else if (msg.type === "transcribe") run = transcribe(msg);
  else if (msg.type === "tts") run = tts(msg);
  else if (msg.type === "ankiAdd") run = ankiAdd(msg);
  else if (msg.type === "ankiList") run = ankiList(msg);
  else if (msg.type === "ankiUpdate") run = ankiUpdate(msg);
  else if (msg.type === "ankiRestore") run = ankiRestore(msg);
  else if (msg.type === "ankiMoveChars") run = ankiMoveChars(msg);
  else if (msg.type === "ankiMoveUndo") run = ankiMoveUndo(msg);
  else if (msg.type === "openFreq") run = (async () => { await DS_EXT.tabs.create({ url: DS_EXT.runtime.getURL("freq.html") + "?lang=" + encodeURIComponent(msg.lang || "") + "&word=" + encodeURIComponent(msg.word || "") + "&target=" + encodeURIComponent(msg.target || "it") + (msg.level ? "&level=" + encodeURIComponent(msg.level) : "") }); return {}; })();
  else if (msg.type === "openKanji") run = (async () => { await DS_EXT.tabs.create({ url: DS_EXT.runtime.getURL("kanji.html") + "?" + new URLSearchParams({ sys: msg.sys || "jlpt", level: msg.level || "", ch: msg.ch || "", lang: msg.lang || "ja", target: msg.target || "it" }) }); return {}; })();
  else if (msg.type === "openJlpt") run = (async () => { await DS_EXT.tabs.create({ url: DS_EXT.runtime.getURL("jlpt.html") + "?level=" + encodeURIComponent(msg.level || "N5") + "&word=" + encodeURIComponent(msg.word || "") + "&target=" + encodeURIComponent(msg.target || "it") }); return {}; })();
  else if (msg.type === "jlptList") run = jlptList(msg);
  else if (msg.type === "ankiCheck") run = ankiCheck(msg);
  else if (msg.type === "azureTts") run = azureTts(msg);
  else if (msg.type === "azureVoices") run = azureVoices(msg);
  else if (msg.type === "piper") run = piperCall(msg);
  else if (msg.type === "speachesTts") run = speachesTts(msg);
  else if (msg.type === "helperPing") run = helperPing();
  else if (msg.type === "align") run = align(msg);
  else if (msg.type === "wordBack") run = wordBack(msg);
  else if (msg.type === "cleanText") run = cleanText(msg);
  else if (msg.type === "ipa") run = ipa(msg);
  else if (msg.type === "etymPage") run = etymPage(msg);
  else if (msg.type === "wiktSearch") run = wiktSearch(msg);
  else if (msg.type === "googleWebDict") run = googleWebDict(msg);
  else if (msg.type === "ngram") run = ngram(msg);
  else if (msg.type === "fetchB64") run = fetchB64(msg);
  else if (msg.type === "tatoeba") run = tatoeba(msg);
  else if (msg.type === "jisho") run = jisho(msg);
  else if (msg.type === "hanChar") run = hanChar(msg);
  else if (msg.type === "langtool") run = langtool(msg);
  else if (msg.type === "freqList") run = freqList(msg);
  else if (msg.type === "freqRank") run = freqRank(msg);
  else if (msg.type === "commonsImage") run = commonsImage(msg);
  else if (msg.type === "imageSearch") run = imageSearch(msg);
  else if (msg.type === "romanLine") run = romanLine(msg);
  else if (msg.type === "idiomsFind") run = idiomsFind(msg);
  else if (msg.type === "idiomsAbout") run = idiomsAbout(msg);
  else if (msg.type === "etymLlm") run = etymLlm(msg);
  else if (msg.type === "hanExplain") run = hanExplain(msg);
  else if (msg.type === "uiStrings") run = uiStrings();
  else if (msg.type === "uiTranslate") run = uiTranslate(msg);
  else if (msg.type === "idiomDict") run = idiomDict(msg);
  else return null;
  return dsKeepAlive(run);
}
const dsErr = (err) => ({
  error: String((err && err.message) || err),
  rateLimited: !!(err && err.rateLimited),
  daily: !!(err && err.daily),
  fatal: !!(err && err.fatal),
  modelGone: !!(err && err.modelGone),
  hourly: !!(err && err.hourly),
  tooLarge: !!(err && (err.tooLarge || err.tpm)),
  retryAfter: (err && err.retryAfter) || 0
});
// Chrome spegne il service worker dopo 30 secondi senza attività, anche mentre aspetta la risposta di un servizio
// (un modello sul computer può metterci minuti): finché c'è una richiesta in corso lo tengo sveglio
let dsPending = 0, dsAliveTimer = 0;
function dsKeepAlive(p) {
  dsPending++;
  if (!dsAliveTimer) dsAliveTimer = setInterval(() => { try { chrome.runtime.getPlatformInfo(() => {}); } catch {} }, 20000);
  const done = () => { if (--dsPending <= 0) { dsPending = 0; clearInterval(dsAliveTimer); dsAliveTimer = 0; } };
  Promise.resolve(p).then(done, done);
  return p;
}
// registro del sottofondo per il debug: le ultime richieste andate male (popup → «📋 Copia il registro per il debug»)
const dsBgLogBuf = [];
function dsBgLog(text) {
  dsBgLogBuf.push(new Date().toTimeString().slice(0, 8) + " " + text);
  if (dsBgLogBuf.length > 150) dsBgLogBuf.splice(0, dsBgLogBuf.length - 150);
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  if (msg.type === "getBgLog") { sendResponse({ log: dsBgLogBuf.join("\n") }); return false; }
  const run = dsRoute(msg, sender);
  if (!run) return false;
  run.then((res) => { if (res && res.error) dsBgLog(msg.type + ": " + res.error); sendResponse(res); },
    (err) => { dsBgLog(msg.type + ": " + ((err && err.message) || err)); sendResponse(dsErr(err)); });
  return true;
});
// Le richieste lunghe (spiegazioni dei modelli) arrivano su una porta "ds-long": la pagina manda un segnale ogni
// 15 secondi, così il service worker resta acceso anche oltre i 5 minuti che Chrome concede a un messaggio
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "ds-long") return;
  let closed = false;
  port.onDisconnect.addListener(() => { closed = true; });
  const post = (m) => { if (!closed) try { port.postMessage(m); } catch {} };
  port.onMessage.addListener((msg) => {
    if (!msg || msg.ping) return;
    const run = dsRoute(msg, port.sender);
    if (!run) return post({ res: { error: "richiesta sconosciuta" } });
    run.then((res) => post({ res }), (err) => post({ res: dsErr(err) }));
  });
});

// ---------- Errori ----------
async function httpError(r, service) {
  const text = await r.text().catch(() => "");
  let detail = "";
  try {
    const j = JSON.parse(text);
    detail = (j.error && (j.error.message || j.error)) || j.message || "";
    if (Array.isArray(j) && j[0] && j[0].error) detail = j[0].error.message;
  } catch {}
  const e = new Error(`${service} ha risposto ${r.status}${detail ? ": " + String(detail).slice(0, 200) : ""}`);
  if (r.status === 429 || r.status === 503 || r.status === 529) {
    e.rateLimited = true;
    const header = Number(r.headers.get("retry-after"));
    const m = text.match(/"retryDelay"\s*:\s*"(\d+)/);
    e.retryAfter = header > 0 ? header : m ? Number(m[1]) : 0;
    // "Please try again in 22m45.5s" (Groq): quanto manca davvero
    const ta = text.match(/try again in\s+(?:(\d+)h)?\s*(?:(\d+)m)?\s*(?:([\d.]+)s)?/i);
    if (ta && (ta[1] || ta[2] || ta[3])) e.retryAfter = Math.max(e.retryAfter, (+ta[1] || 0) * 3600 + (+ta[2] || 0) * 60 + (+ta[3] || 0));
    if (/per hour|ASPH/i.test(text)) e.hourly = true;
    if (r.status === 429 && /PerDay|per_day|per day|RequestsPerDay|daily/i.test(text)) {
      e.daily = true;
      const lim = text.match(/Limit:?\s*(\d+)/i);
      e.message = `${service}: hai esaurito le richieste gratuite di oggi per questo modello.` + (lim ? ` (Limit ${lim[1]})` : "");
    }
  }
  if (r.status === 413 || /request too large|tokens per minute \(TPM\)/i.test(text)) {
    e.tooLarge = r.status === 413 || /request too large/i.test(text);
    if (/tokens per minute|TPM/i.test(text)) { e.rateLimited = true; e.tpm = true; }
  }
  if (r.status === 402 || /insufficient|credit balance|out of credits|organization_restricted/i.test(text)) {
    e.message = `${service}: credito o quota dell'account finiti. Controlla il tuo account (per Groq: console.groq.com).`;
    e.fatal = true; e.rateLimited = false;
  }
  if (r.status === 401 || r.status === 403) { e.message = `${service}: chiave non valida o senza permessi (${r.status}).`; e.fatal = true; }
  // modello che non esiste (più): non è un errore della chiave. modelGone: si passa al modello successivo dell'elenco
  if (r.status === 404 && /model/i.test(text)) { e.message = `${service}: il modello scelto non esiste più. Nel popup (🔑 Servizi o 📊 Consumo e modelli) scegline un altro.`; e.modelGone = true; e.daily = true; }
  if (r.status === 456) e.message = "DeepL: hai esaurito i caratteri gratuiti di questo mese.";
  return e;
}

function cleanModelText(content) {
  return String(content || "").replace(/<think>[\s\S]*?<\/think>/g, "").replace(/```(?:json)?/g, "");
}

// Legge la risposta di un modello anche se è "sporca": JSON con testo intorno, JSON troncato,
// oppure righe numerate. Toglie i numeri "1. 2. 3." che alcuni modelli aggiungono.
function parseList(content, texts) {
  const n = texts.length;
  const s = cleanModelText(content);
  let arr = null, srcArr = null, idioms = null;
  const o1 = s.indexOf("{"), o2 = s.lastIndexOf("}");
  if (o1 >= 0 && o2 > o1) {
    try {
      const obj = JSON.parse(s.slice(o1, o2 + 1));
      arr = obj.t || obj.translations || obj.segments || Object.entries(obj).find(([k, v]) => k !== "idioms" && Array.isArray(v))?.[1] || null;
      if (Array.isArray(obj.src)) srcArr = obj.src;
      if (Array.isArray(obj.idioms)) idioms = obj.idioms;
    } catch {}
  }
  if (!arr) {
    const a1 = s.indexOf("["), a2 = s.lastIndexOf("]");
    if (a1 >= 0 && a2 > a1) { try { arr = JSON.parse(s.slice(a1, a2 + 1)); } catch {} }
  }
  if (!arr) {
    // JSON troncato o malformato: recupero le stringhe una per una
    const k = s.search(/"(t|translations)"\s*:\s*\[/);
    if (k >= 0) {
      arr = [];
      const re = /"((?:[^"\\]|\\.)*)"/g;
      re.lastIndex = s.indexOf("[", k) + 1;
      let m;
      while ((m = re.exec(s))) { try { arr.push(JSON.parse('"' + m[1] + '"')); } catch { arr.push(m[1]); } }
    }
  }
  if (!arr || !arr.length) {
    const lines = s.split("\n").map((l) => l.match(/^\s*(\d{1,3})[.)]\s+(.*)$/)).filter(Boolean);
    if (lines.length) arr = lines.map((m) => m[2]);
  }
  if (!Array.isArray(arr) || !arr.length) throw new Error("risposta del modello non leggibile");
  arr = arr.map((x) => (typeof x === "string" ? x : x && typeof x === "object" ? String(Object.values(x)[0] || "") : String(x ?? "")));
  const translations = Array.from({ length: n }, (_, i) => {
    let t = (arr[i] || "").trim();
    if (!/^\s*\d/.test(texts[i] || "")) t = t.replace(/^\s*\d{1,3}[.)]\s+/, "");
    return t.replace(/^["“](.*)["”]$/, "$1");
  });
  // pezzi volutamente vuoti in entrambe le versioni = "non è parlato", non uno sfasamento
  const removed = new Set(srcArr ? translations.map((t, i) => (!t && srcArr[i] != null && !String(srcArr[i]).trim() ? i : -1)).filter((i) => i >= 0) : []);
  const out = { translations, misaligned: arr.length !== n || badAlignment(texts.filter((_, i) => !removed.has(i)), translations.filter((_, i) => !removed.has(i))) };
  if (srcArr) {
    out.sources = Array.from({ length: n }, (_, i) => (srcArr[i] == null ? null : String(srcArr[i]).trim()));
    if (srcArr.length !== n) out.misaligned = true;
  }
  // modi di dire trovati nella stessa richiesta (1.6.0): { i: numero della frase, text, m: significato }
  if (idioms) out.idioms = idioms.filter((x) => x && Number.isInteger(+x.i) && +x.i >= 0 && +x.i < n && String(x.text || "").trim())
    .slice(0, 40).map((x) => ({ i: +x.i, text: String(x.text).trim(), meaning: String(x.m || x.meaning || "").trim() }));
  return out;
}

// Il modello a volte sposta la traduzione di una frase sotto quella accanto:
// me ne accorgo da traduzioni vuote o di lunghezza molto diversa dall'originale
function badAlignment(texts, translations) {
  if (texts.length < 2) return false;
  let bad = 0;
  texts.forEach((src, i) => {
    const t = translations[i] || "";
    const words = String(src).trim().split(/\s+/).length;
    if (words < 3) return;
    if (!t.trim()) bad++;
    else if (t.length > src.length * 2.6 + 25 || t.length < src.length * 0.3) bad++;
  });
  return bad > 0;
}

function parseObject(content) {
  const s = cleanModelText(content);
  const o1 = s.indexOf("{"), o2 = s.lastIndexOf("}");
  if (o1 < 0 || o2 <= o1) throw new Error("risposta del modello non leggibile");
  return JSON.parse(s.slice(o1, o2 + 1));
}

// ---------- Ritmo delle richieste ----------
// Ogni servizio gratuito accetta solo un certo numero di richieste al minuto. Tutte le richieste
// (traduzioni, significati, da qualsiasi scheda) passano da qui e vengono distanziate.
// Se il servizio risponde "troppe richieste", l'intervallo si allunga e poi torna piano piano normale.
const nextSlot = new Map();
const currentInterval = new Map();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const lastStart = new Map();

async function waitTurn(id, E, priority) {
  const base = E.minIntervalMs || 0;
  const interval = currentInterval.get(id) || base;
  if (!interval && !nextSlot.has(id)) return;
  const now = Date.now();
  if (priority) {
    // richiesta fatta da te (correzione di una frase): passa davanti alla fila,
    // rispettando solo la distanza dall'ultima richiesta partita
    const at = Math.max(now, (lastStart.get(id) || 0) + interval);
    if (at > now) await sleep(at - now);
    lastStart.set(id, Date.now());
    return;
  }
  const at = Math.max(now, nextSlot.get(id) || 0);
  nextSlot.set(id, at + interval);
  if (at > now) await sleep(at - now);
  lastStart.set(id, Date.now());
}

function rateLimitHit(id, E, err) {
  const base = E.minIntervalMs || 2000;
  currentInterval.set(id, Math.min(20000, (currentInterval.get(id) || base) * 1.5));
  nextSlot.set(id, Date.now() + Math.max(err.retryAfter || 0, 5) * 1000);
}

function requestOk(id, E) {
  const iv = currentInterval.get(id);
  if (iv) currentInterval.set(id, Math.max(E.minIntervalMs || 0, iv * 0.9));
}

// ---------- Richieste di oggi per servizio (popup «Consumo e modelli») e limite giornaliero scelto da te ----------
// Il giorno è quello delle quote (mezzanotte di Los Angeles, come dsBlocked). dsUsage = { day, n: { servizio: richieste } }
const usageDay = () => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return new Date().toISOString().slice(0, 10); } };
let usage = null, usageTimer = 0, dailyCap = {};
DS_EXT.storage.sync.get({ dailyCap: {} }).then((r) => { dailyCap = r.dailyCap || {}; }).catch(() => {});
DS_EXT.storage.onChanged.addListener((ch, area) => { if (area === "sync" && ch.dailyCap) dailyCap = ch.dailyCap.newValue || {}; });
async function usageGet() {
  if (!usage) usage = (await DS_EXT.storage.local.get({ dsUsage: null })).dsUsage || null;
  if (!usage || usage.day !== usageDay()) usage = { day: usageDay(), n: {} };
  return usage;
}
async function usageCount(id) {
  const u = await usageGet();
  u.n[id] = (u.n[id] || 0) + 1;
  clearTimeout(usageTimer);
  usageTimer = setTimeout(() => DS_EXT.storage.local.set({ dsUsage: u }).catch(() => {}), 800);
}
// raggiunto il limite che hai scelto per oggi: si comporta come la quota gratuita finita (si passa al servizio di riserva)
async function usageCheck(id, name) {
  const cap = Number(dailyCap[id]) || 0;
  if (!cap) return;
  const u = await usageGet();
  if ((u.n[id] || 0) >= cap) throw Object.assign(new Error(`${name}: raggiunto il limite che hai scelto (${cap} richieste al giorno, popup → Consumo e modelli).`), { daily: true, rateLimited: true, capped: true });
}

async function paced(id, E, fn, priority) {
  await usageCheck(id, E.label.split(" (")[0].split(",")[0]);
  await waitTurn(id, E, priority);
  usageCount(id);
  try {
    const out = await fn();
    requestOk(id, E);
    return out;
  } catch (e) {
    if (e && e.rateLimited && !e.daily) rateLimitHit(id, E, e);
    throw e;
  }
}

// ---------- Modelli linguistici (compatibili OpenAI e Claude) ----------
function openaiBase(E, msg) {
  return (E.local ? msg.localUrl || C.SYNC_DEFAULTS.localUrl : E.base).trim().replace(/\/+$/, "");
}

function localError(base) {
  return new Error(
    `Non riesco a collegarmi al modello locale su ${base}. Controlla che Ollama o LM Studio sia avviato ` +
    `e che accetti le richieste dalle estensioni (vedi LEGGIMI).`
  );
}

const llmReady = (E, msg) =>
  (E.kind === "openai" || E.kind === "claude") && (!E.needsKey || !!msg.key) && !!(msg.model || E.defaultModel);

const maxTokensCap = new Map();   // "indirizzo|modello" → massimo di token della risposta accettato
async function llmText(E, msg, system, user) {
  if (E.kind === "claude") {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": msg.key.trim(),
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model: msg.model || E.defaultModel, max_tokens: 8000, system,
        messages: [{ role: "user", content: user }]
      })
    });
    if (!r.ok) throw await httpError(r, "Claude");
    const data = await r.json();
    return (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
  }

  const base = openaiBase(E, msg);
  const model = msg.model || E.defaultModel;
  if (!model) throw new Error("scegli un modello nel popup (pulsante \"Carica modelli\")");
  const headers = { "Content-Type": "application/json" };
  if (msg.key) headers.Authorization = "Bearer " + msg.key.trim();
  // limite di token della risposta già imparato per questo modello (alcuni modelli di Groq accettano al massimo 4096)
  const capKey = base + "|" + model;
  const want = msg.maxTokens || E.maxTokens || 8192;
  // (1.4.7 aggiungeva «/no_think» per Qwen 3: tolto. qwen3:4b di Ollama è la versione che ragiona sempre e prendeva
  // «/no_think» come testo da tradurre. Il ragionamento si spegne solo con think: false sui modelli che lo permettono;
  // per gli altri «Prova» consiglia un modello senza ragionamento.)
  const body = {
    model, temperature: 0.2, max_tokens: Math.min(want, maxTokensCap.get(capKey) || want),
    messages: [{ role: "system", content: system }, { role: "user", content: user }],
    ...(E.extra || {})
  };
  const send = (b) => fetch(base + "/chat/completions", { method: "POST", headers, body: JSON.stringify(b) });
  let r;
  try { r = await send(body); } catch (e) { if (E.local) throw localError(base); throw e; }
  if (r.status === 400) {
    // «max_tokens must be less than or equal to 4096»: riprovo subito con quel limite e me lo ricordo per questo modello
    const peek = await r.clone().text().catch(() => "");
    const m = /max(?:_completion)?_tokens[\s\S]{0,80}?(?:less than or equal to|<=|at most|maximum(?: value)?(?: of| is)?)\s*`?(\d{3,6})/i.exec(peek);
    if (m && +m[1] < body.max_tokens) {
      maxTokensCap.set(capKey, +m[1]);
      body.max_tokens = +m[1];
      r = await send(body);
    }
  }
  if (r.status === 400 && E.extra) {
    // alcuni modelli non accettano i parametri extra: riprovo senza
    const plain = { ...body };
    for (const k of Object.keys(E.extra)) delete plain[k];
    r = await send(plain);
  }
  if ((r.status === 413 || r.status === 429) && body.max_tokens > 3000) {
    const peek = await r.clone().text().catch(() => "");
    if (r.status === 413 || /request too large/i.test(peek)) r = await send({ ...body, max_tokens: 3000 });
  }
  if (E.local && r.status === 403) {
    throw new Error("Il modello locale rifiuta la richiesta: devi permettere le estensioni del browser (OLLAMA_ORIGINS, vedi LEGGIMI).");
  }
  // modello che Ollama o LM Studio non hanno (cancellato, o scritto diverso): ne scelgo uno di quelli installati,
  // riprovo e me lo ricordo nel popup. Senza nessun modello lo dico, con il comando per scaricarne uno.
  if (E.local && r.status === 404 && /model/i.test(await r.clone().text().catch(() => ""))) {
    const lm = await listModels({ ...msg, engine: msg.engine || "local" }).catch(() => null);
    if (lm && !lm.models.length) throw new Error("Il programma sul computer non ha nessun modello scaricato: con Ollama, nel Prompt dei comandi scrivi  ollama pull qwen3:8b  (o un altro modello), poi nel popup (🔑 Servizi) premi «Carica modelli».");
    const pick = lm && !lm.models.includes(body.model) ? lm.suggested : "";
    if (pick) {
      body.model = pick;
      r = await send(body);
      if (r.ok) { const s = await DS_EXT.storage.sync.get({ models: {} }); DS_EXT.storage.sync.set({ models: { ...(s.models || {}), [msg.engine || "local"]: pick } }).catch(() => {}); }
    }
  }
  if (!r.ok) throw await httpError(r, E.local ? "Il modello locale" : E.label.split(",")[0]);
  const data = await r.json();
  const m = (data.choices && data.choices[0] && data.choices[0].message) || {};
  const text = Array.isArray(m.content) ? m.content.map((p) => p.text || "").join("") : m.content;
  // modelli che scrivono il ragionamento dentro la risposta: tengo solo quello che viene dopo
  return typeof text === "string" ? text.replace(/^\s*<think>[\s\S]*?<\/think>\s*/i, "") : text;
}

// ---------- Traduzione ----------
async function translate(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E) throw new Error("servizio sconosciuto");
  if (E.needsKey && !msg.key) throw new Error("manca la chiave: inseriscila nel popup dell'estensione");
  if (E.kind === "google") return { translations: await translateGoogle(msg) };
  if (E.kind === "deepl") return { translations: await paced(msg.engine, E, () => translateDeepL(msg)) };
  if (E.kind === "microsoft") return { translations: await paced(msg.engine, E, () => translateMicrosoft(msg)) };
  if (E.kind === "openai" || E.kind === "claude") {
    const text = await paced(msg.engine, E, () =>
      llmText(E, msg, C.prompt(msg.target, msg.texts.length, !!msg.clean, !!msg.idioms), C.userMessage(msg.texts, msg.before, msg.after)), !!msg.priority);
    return parseList(text, msg.texts);
  }
  throw new Error("servizio non supportato qui");
}

// Solo correzione della trascrizione (si traduce poi con Google o DeepL)
async function cleanText(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve un modello per correggere la trascrizione");
  const text = await paced(msg.engine, E, () =>
    llmText(E, msg, C.promptCleanOnly(msg.texts.length), C.userMessage(msg.texts, msg.before, msg.after)));
  const obj = parseObject(text);
  const arr = Array.isArray(obj.src) ? obj.src : Object.values(obj).find(Array.isArray);
  if (!Array.isArray(arr)) throw new Error("risposta del modello non leggibile");
  return { sources: msg.texts.map((_, i) => (arr[i] == null ? null : String(arr[i]).trim())), misaligned: arr.length !== msg.texts.length };
}

const googleLang = (l) => (l === "zh-Hans" ? "zh-CN" : l === "zh-Hant" ? "zh-TW" : l);

async function googleRequest(text, tl, extra = "") {
  const url = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t" + extra +
    "&tl=" + encodeURIComponent(tl) + "&q=" + encodeURIComponent(text) +
    (extra.includes("&sl=") ? "" : "&sl=auto");
  const r = await fetch(url);
  if (!r.ok) throw await httpError(r, "Google Traduttore");
  return r.json();
}
const googleText = (data) => (data[0] || []).map((p) => (p && p[0]) || "").join("");

// Dizionario di Google, nella stessa richiesta della traduzione (gratis): definizioni nella lingua originale,
// sinonimi, esempi, "vedi anche", "forse cercavi", traduzioni con il loro peso e le traduzioni al contrario.
// Google a volte lascia vuote alcune parti: quello che manca semplicemente non c'è.
const GOOGLE_DICT_DT = "&dt=bd&dt=md&dt=ss&dt=ex&dt=rw&dt=qca";
function googleDict(data) {
  const A = (x) => (Array.isArray(x) ? x : []);
  const str = (x) => (typeof x === "string" ? x : "");
  const strip = (x) => str(x).replace(/<[^>]+>/g, "").replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, "&").trim();
  const out = { alt: [], defs: [], syn: [], examples: [], related: [], didYouMean: "" };
  try {
    for (const e of A(data[1]).slice(0, 4)) {
      const items = A(e[2]).slice(0, 6).map((x) => ({ word: str(x[0]), rev: A(x[1]).slice(0, 5).map(str).filter(Boolean), score: typeof x[3] === "number" ? x[3] : 0 })).filter((x) => x.word);
      if (items.length) out.alt.push({ pos: str(e[0]), items });
    }
    for (const e of A(data[12]).slice(0, 3)) {
      const items = A(e[1]).slice(0, 3).map((x) => ({ def: strip(x[0]), ex: strip(x[2]) })).filter((x) => x.def);
      if (items.length) out.defs.push({ pos: str(e[0]), items });
    }
    for (const e of A(data[11]).slice(0, 3)) {
      const words = [];
      for (const g of A(e[1])) for (const w of A(g[0])) if (typeof w === "string" && !words.includes(w)) words.push(w);
      if (words.length) out.syn.push({ pos: str(e[0]), words: words.slice(0, 10) });
    }
    out.examples = A(A(data[13])[0]).slice(0, 3).map((x) => strip(A(x)[0])).filter(Boolean);
    out.related = A(A(data[14])[0]).slice(0, 8).map(str).filter(Boolean);
    const q = A(data[7]);
    if (str(q[1])) out.didYouMean = strip(q[1]);
  } catch {}
  return out;
}

function googleSource(source, target) {
  const b = String(source || "").split("-")[0].toLowerCase();
  if (!b || b === String(target).split("-")[0].toLowerCase()) return "";
  return "&sl=" + encodeURIComponent(b === "zh" ? "zh-CN" : b === "jw" ? "jv" : b);
}

async function translateGoogle({ texts, target, source }) {
  const tl = googleLang(target);
  const sl = googleSource(source, target);
  const lines = googleText(await googleRequest(texts.join("\n"), tl, sl)).split("\n").map((s) => s.trim());
  if (lines.length === texts.length) return lines;
  const out = [];
  for (const t of texts) out.push(googleText(await googleRequest(t, tl, sl)).trim());
  return out;
}

async function translateDeepL({ texts, target, before = [], after = [], key }) {
  const host = key.trim().endsWith(":fx") ? "https://api-free.deepl.com" : "https://api.deepl.com";
  const map = { en: "EN-US", pt: "PT-BR", "zh-Hans": "ZH-HANS" };
  const body = { text: texts, target_lang: map[target] || target.toUpperCase() };
  const context = [...before, ...after].join("\n");
  if (context) body.context = context;
  const r = await fetch(host + "/v2/translate", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "DeepL-Auth-Key " + key.trim() },
    body: JSON.stringify(body)
  });
  if (!r.ok) throw await httpError(r, "DeepL");
  const data = await r.json();
  return texts.map((_, i) => ((data.translations || [])[i] || {}).text || "");
}

// Microsoft Translator (Azure, piano F0 gratuito): fino a 100 frasi per richiesta
async function translateMicrosoft({ texts, target, source, key, region }) {
  if (!region) region = (await DS_EXT.storage.sync.get({ msRegion: "" })).msRegion || "";
  const ms = (l) => ({ "zh-Hans": "zh-Hans", zh: "zh-Hans", he: "he", no: "nb", tl: "fil" }[l] || String(l || "").split("-")[0]);
  const from = source && ms(source) !== ms(target) ? "&from=" + encodeURIComponent(ms(source)) : "";
  const headers = { "Content-Type": "application/json", "Ocp-Apim-Subscription-Key": String(key || "").trim() };
  if (region && region.trim()) headers["Ocp-Apim-Subscription-Region"] = region.trim();
  const r = await fetch("https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=" + encodeURIComponent(ms(target)) + from, {
    method: "POST", headers, body: JSON.stringify(texts.map((t) => ({ Text: t })))
  });
  if (!r.ok) {
    const e = await httpError(r, "Microsoft Translator");
    if (r.status === 403 || /quota/i.test(e.message)) { e.daily = true; e.rateLimited = true; e.message = "Microsoft Translator: hai esaurito i caratteri gratuiti di questo mese."; }
    if (r.status === 401) e.message = "Microsoft Translator: chiave o area sbagliata (controlla anche l'area, per esempio westeurope).";
    throw e;
  }
  const data = await r.json();
  return texts.map((_, i) => (((data[i] || {}).translations || [])[0] || {}).text || "");
}

// ---------- Significato di una parola nel suo contesto ----------
// un campo di testo del modello: vuoto se è un "niente" scritto a parole (false, none, null, n/a, -, nessuno…)
function llmField(v) {
  if (v == null || v === false || v === true) return "";
  const t = String(Array.isArray(v) ? v.filter(Boolean).join(", ") : v).trim();
  return /^(false|true|none|null|nil|n\/?a|no|non|nessun[oa]?|niente|empty|vuoto|-+|—|\.+|undefined)\.?$/i.test(t) ? "" : t;
}

// ---------- Dizionario dei modi di dire (gratis): gli elenchi di Wiktionary per lingua ----------
// «Category:English idioms» ecc.: si scaricano una volta (qualche secondo) e si tengono 60 giorni. Le schede e i
// sottotitoli li cercano nelle frasi sul computer, senza richieste ai modelli.
const idiomDictLocks = new Map();
async function idiomDict(msg) {
  const lang = String(msg.lang || "").split("-")[0].toLowerCase();
  const name = langNameEn(lang);
  if (!lang || !name) return { list: [] };
  const k = "idiomDict:" + lang;
  const have = (await DS_EXT.storage.local.get({ [k]: null }))[k];
  if (have && Date.now() - have.at < 60 * 864e5) return { list: have.list || [] };
  if (idiomDictLocks.has(lang)) return idiomDictLocks.get(lang);
  const job = (async () => {
    const cats = [name + " idioms"].concat(lang === "zh" ? ["Chinese chengyu"] : lang === "ja" ? ["Japanese yojijukugo"] : []);
    const out = new Set();
    for (const cat of cats) {
      let cont = "";
      for (let page = 0; page < 40; page++) {
        const url = "https://en.wiktionary.org/w/api.php?action=query&list=categorymembers&format=json&formatversion=2&origin=*&cmnamespace=0&cmlimit=500&cmtitle=" +
          encodeURIComponent("Category:" + cat) + (cont ? "&cmcontinue=" + encodeURIComponent(cont) : "");
        const r = await fetch(url, { headers: { "Api-User-Agent": "SottotitoliDoppi/1.6 (estensione per imparare le lingue)" } });
        if (!r.ok) throw new Error("Wiktionary ha risposto " + r.status);
        const j = await r.json();
        for (const m of (j.query && j.query.categorymembers) || []) if (m.title && !/^(Appendix|Category|Template|Reconstruction):/.test(m.title)) out.add(m.title);
        cont = j.continue && j.continue.cmcontinue;
        if (!cont) break;
      }
    }
    const list = [...out];
    await DS_EXT.storage.local.set({ [k]: { at: Date.now(), list } });
    return { list };
  })().catch((e) => (have ? { list: have.list || [] } : { list: [], error: String(e.message || e) })).finally(() => idiomDictLocks.delete(lang));
  idiomDictLocks.set(lang, job);
  return job;
}

// Nome inglese di una lingua dalla sigla (per i prompt)
function langNameEn(code) {
  const b = String(code || "").split("-")[0];
  if (!b) return "";
  if (C.LANG_EN[code]) return C.LANG_EN[code];
  try { return new Intl.DisplayNames(["en"], { type: "language" }).of(b) || ""; } catch { return ""; }
}
// Alfabeto atteso per la lingua di arrivo; le parti in un altro alfabeto sono in un'altra lingua
const SCRIPT_OF = { ru: "Cyrillic", uk: "Cyrillic", bg: "Cyrillic", sr: "Cyrillic", mk: "Cyrillic", be: "Cyrillic", kk: "Cyrillic",
  ar: "Arabic", fa: "Arabic", ur: "Arabic", he: "Hebrew", el: "Greek", hi: "Devanagari", mr: "Devanagari", ne: "Devanagari",
  th: "Thai", ko: "Hangul", ja: "Han|Hiragana|Katakana", zh: "Han", ka: "Georgian", hy: "Armenian", bn: "Bengali", ta: "Tamil" };
function wrongScript(text, target) {
  // le parole citate (tra parentesi o virgolette) possono essere nella lingua originale: non le conto
  const t = String(text || "").replace(/\([^)]*\)|«[^»]*»|"[^"]*"|“[^”]*”|'[^']*'/g, " ");
  const letters = t.match(/\p{L}/gu) || [];
  if (letters.length < 3) return false;
  const want = SCRIPT_OF[String(target || "").split("-")[0].toLowerCase()] || "Latin";
  const re = new RegExp("[" + want.split("|").map((x) => "\\p{Script=" + x + "}").join("") + "]", "u");
  const ok = letters.filter((ch) => re.test(ch)).length;
  return ok / letters.length < 0.6;
}
// Un modo di dire deve essere un pezzo della frase, nella sua lingua: ogni parola dell'espressione deve esserci davvero
// (senza accenti/vocali segnate; anche attaccata a un prefisso o a un suffisso, come in arabo «بالغيب»). Il modello a
// volte scrive l'espressione tradotta in inglese («in the secret life»): quella non va mai mostrata.
function exprInSentence(expr, sentence) {
  const norm = (t) => (String(t || "").toLowerCase().normalize("NFD").replace(/\p{M}/gu, "").match(/[\p{L}\p{N}]+/gu) || []);
  const words = norm(expr), sent = " " + norm(sentence).join(" ") + " ";
  return words.length > 0 && words.every((w) => sent.includes(w));
}
// Quali campi della risposta del modello sono sbagliati
// Lingua di un testo secondo il browser (gratis, sul computer): { lang, pct, sure } o null
async function detectLang(text) {
  try {
    const r = await new Promise((ok) => { const p = DS_EXT.i18n.detectLanguage(String(text).slice(0, 2000), ok); if (p && p.then) p.then(ok, () => ok(null)); });
    const top = r && r.languages && r.languages[0];
    return top ? { lang: top.language.split("-")[0], pct: top.percentage, sure: !!r.isReliable } : null;
  } catch { return null; }
}
// Un testo scritto in un'altra lingua invece di quella scelta in «Traduci in» (per esempio una spiegazione in inglese
// per chi traduce in italiano): stesso alfabeto, quindi lo dice il riconoscimento della lingua
async function wrongLanguage(text, target) {
  const t = String(text || "").replace(/["«»“”'‘’][^"«»“”'‘’]{0,40}["«»“”'‘’]/g, " ");   // senza le parole citate
  if (t.trim().split(/\s+/).length < 5) return false;
  const d = await detectLang(t);
  const want = String(target || "").split("-")[0];
  return !!(d && want && d.sure && d.pct >= 70 && d.lang !== want && !(want === "no" && /^n[bn]$/.test(d.lang)) && !(want === "zh" && d.lang === "zh"));
}
async function defineProblems(o, msg) {
  const bad = [];
  const m = String(o.meaning || "");
  // significato vuoto, o in un altro alfabeto (per esempio la parola russa ricopiata così com'è). Una parola uguale
  // nello stesso alfabeto può essere giusta (computer, weekend…): quella la lascio
  if (!m.trim() || wrongScript(m, msg.target)) bad.push("meaning");
  for (const f of ["explanation", "expression_meaning", "example_translation", "pos", "false_friend", "etymology", "sentence_translation"]) {
    if (!o[f] || typeof o[f] !== "string") continue;
    if (wrongScript(o[f], msg.target) || await wrongLanguage(o[f], msg.target)) bad.push(f);
  }
  return bad;
}
// Falso amico: solo un avviso vero, su una parola della lingua scelta. Il modello a volte scrive che la parola
// "non è un falso amico", o la confronta con una parola inglese anche se traduci in italiano (embarazada → embarrassed):
// in quei casi non deve comparire niente.
const FF_OTHER = { en: /\b(english|inglese|ingles[ei]|anglais|englisch|inglés|inglês|angielsk\w*|anglick\w*|английск\w*)\b/i };
function falseFriendClean(text, target) {
  const t = String(text || "").trim();
  if (!t) return "";
  const want = String(target || "").split("-")[0];
  if (want !== "en" && FF_OTHER.en.test(t)) return "";
  const negative = /^(non\s+(è|e'|si\s+tratta|c'è|ci\s+sono|ha|esiste)|nessun|it\s+is\s+not|it's\s+not|this\s+is\s+not|is\s+not|not\s+a|there\s+is\s+no|no\s+false|no\s+hay|no\s+es|ce\s+n'est\s+pas|il\s+n'y\s+a|kein|es\s+ist\s+kein)/i;
  const warning = /(non\s+significa|non\s+vuol\s+dire|does\s*n[o']t\s+mean|attenzione|occhio|careful|cuidado|attention|vorsicht)/i;
  if (negative.test(t) && !warning.test(t)) return "";
  if (/falso\s+amico|false\s+friend|faux\s+ami|falso\s+amigo|falscher\s+freund/i.test(t) && /\b(non|not|no|nicht|pas)\b/i.test(t) && !warning.test(t)) return "";
  return t;
}

async function define(msg) {
  let E = C.ENGINES[msg.engine] || C.ENGINES.google;
  // 1.6.3: «🎯 Rifai più precisa»: Gemini ragiona un po' prima di rispondere (di serie no: costa risposte troncate e richieste lente)
  if (msg.precise && E.kind === "openai" && /generativelanguage/.test(E.base || "")) E = { ...E, extra: { ...(E.extra || {}), reasoning_effort: "medium" } };
  let llmError = "";
  if (llmReady(E, msg)) {
    try {
      const avoid = (Array.isArray(msg.avoid) ? msg.avoid : []).map((x) => String(x || "").trim()).filter(Boolean).slice(0, 4);
      const user = `${/\s/.test(String(msg.word).trim()) ? "Expression" : "Word"}: "${msg.word}"\nSentence: "${msg.sentence}"` +
        (msg.sentenceTrans ? `\nSentence translation: "${msg.sentenceTrans}"` : "") +
        (avoid.length ? `\nPrevious explanations of this word (the learner wants a DIFFERENT, better one: other angle, other example, no repetition):\n- ${avoid.join("\n- ")}` : "");
      // una risposta breve: poche migliaia di token bastano (Groq conta max_tokens nel limite al minuto:
      // con 8192 la richiesta veniva rifiutata come "troppo grande" e la spiegazione non arrivava)
      const dm = { ...msg, maxTokens: msg.precise ? 8192 : msg.engine === "gemini" ? 4096 : 2500 };
      const system = C.definePrompt(msg.target, msg.lang, { etym: !!msg.etym, ipa: msg.ipa !== false, extra: !!msg.extra, sentence: !!msg.sentFix && /\s/.test(String(msg.sentence || "").trim()), idioms: !!msg.idioms && !/\s/.test(String(msg.word || "").trim()) }) +
        (msg.precise ? " PRECISION MODE: the learner found the previous answer too vague or wrong. Work carefully: decide the exact sense of the word in THIS sentence (and in the whole context), " +
          "check the part of speech and the dictionary form, give the most precise translation (not the most common one), mention register or nuance in the explanation when it matters, " +
          "and make the example sentence natural and clearly showing this sense. If the word is ambiguous, say which sense you chose and why." : "");
      let text;
      try { text = await paced(msg.engine, E, () => llmText(E, dm, system, user), true); }
      catch (e) { if (!e.tooLarge) throw e; text = await paced(msg.engine, E, () => llmText(E, { ...dm, maxTokens: 1200 }, system, user), true); }
      let o;
      try { o = parseObject(text); }
      catch { o = parseObject(await paced(msg.engine, E, () => llmText(E, { ...dm, maxTokens: Math.max(dm.maxTokens * 2, 8192) }, system, user), true)); }   // risposta tagliata (anche dal ragionamento del modello): riprovo una volta con più spazio
      // Controllo della risposta: a volte (soprattutto con i modelli piccoli) il "significato" è la parola stessa
      // non tradotta, o la spiegazione è in un'altra lingua (per esempio in arabo per una parola russa).
      // Riprovo una volta con istruzioni più rigide; se è ancora sbagliata, quelle parti le tolgo e il
      // significato lo prende Google.
      let bad = await defineProblems(o, msg);
      if (bad.length) {
        const tName = C.LANG_EN[msg.target] || langNameEn(msg.target) || msg.target;
        const strict = system + ` IMPORTANT: "meaning", "explanation", "pos", "expression_meaning", "example_translation", "false_friend", "etymology" MUST be written in ${tName} only` +
          ` (never in another language)${msg.lang ? `; the word is ${langNameEn(msg.lang) || msg.lang}: TRANSLATE it into ${tName}, do not copy it` : ""}.`;
        try {
          const o2 = parseObject(await paced(msg.engine, E, () => llmText(E, dm, strict, user), true));
          const bad2 = await defineProblems(o2, msg);
          if (bad2.length < bad.length) { o = o2; bad = bad2; }
        } catch {}
      }
      let fixedByGoogle = false;
      if (bad.length) {
        for (const f of bad) o[f] = "";
        if (bad.includes("meaning")) {
          try {
            const g = await googleRequest(msg.word, googleLang(msg.target), googleSource(msg.lang, msg.target) || "&sl=auto");
            o.meaning = googleText(g); fixedByGoogle = true;
          } catch {}
        }
      }
      return {
        checkNote: bad.some((f) => /^(meaning|explanation|expression_meaning|example_translation)$/.test(f)) ? "Una parte della risposta era sbagliata (lingua o parola non tradotta): " + (fixedByGoogle ? "il significato è di Google." : "tolta.") : "",
        source: E.label.split(" (")[0].split(",")[0],
        lemma: String(o.lemma || ""), pos: String(o.pos || ""), meaning: String(o.meaning || ""),
        explanation: String(o.explanation || ""), example: String(o.example || ""),
        exampleTrans: String(o.example_translation || ""), lang: String(o.lang || msg.lang || ""),
        // modo di dire solo se è davvero nella frase, nella lingua della frase
        ...(() => { const ex = llmField(o.expression); const ok = ex && exprInSentence(ex, msg.sentence) && !(msg.lang && wrongScript(ex, msg.lang));
          return { expression: ok ? ex : "", expressionMeaning: ok ? llmField(o.expression_meaning) : "" }; })(),
        // 1.6.7: i modi di dire in generale con la parola cliccata, nella stessa richiesta della spiegazione (stessi controlli di idiomsAbout)
        wordIdioms: !msg.idioms ? undefined : (() => {
          const nrm = (x) => x.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""), w0 = nrm(String(msg.word || "").trim()), sw = w0.length > 4 ? w0.slice(0, Math.max(3, w0.length - 2)) : w0;
          const lg = String(msg.lang || o.lang || "").split("-")[0].toLowerCase();
          return (Array.isArray(o.idioms) ? o.idioms : []).map((x) => ({ text: String((x && x.text) || "").trim(), meaning: llmField(x && x.meaning), example: llmField(x && x.example) }))
            .map((x) => ({ ...x, inSentence: String(msg.sentence || "").toLowerCase().includes(x.text.toLowerCase()) || exprInSentence(x.text, String(msg.sentence || "")) }))
            .filter((x) => x.text && x.text.split(/\s+/).length >= 2 && x.text.split(/\s+/).length <= 8 && !wrongScript(x.meaning, msg.target) && !(lg && wrongScript(x.text, lg)) &&
              nrm(x.text).split(/[\s'’-]+/).some((p) => p === w0 || (sw.length >= 3 && p.startsWith(sw)))).slice(0, 6);
        })(),
        ipa: String(o.ipa || "").replace(/^[\s\/\[]+|[\s\/\]]+$/g, ""),
        etymology: llmField(o.etymology),
        // il modello a volte scrive "false", "none", "N/A"… invece di lasciare vuoto: compariva "⚠ false"
        falseFriend: falseFriendClean(llmField(o.false_friend), msg.target), related: llmField(o.related),
        sentenceTrans: llmField(o.sentence_translation),
        spelling: o.spelling && typeof o.spelling === "object" ? { score: Number(o.spelling.score), correct: String(o.spelling.correct || ""), note: String(o.spelling.note || "") } : null
      };
    } catch (e) {
      // ripiego su Google qui sotto
      llmError = e && e.modelGone ? "modello non disponibile" : e && e.daily ? "richieste gratuite di oggi esaurite" : e && e.rateLimited ? "troppe richieste in questo momento" :
        "non ha risposto" + (e && e.message ? " — " + String(e.message).replace(/^[^:]*ha risposto\s*/, "").slice(0, 160) : "");
    }
  }
  const tl = googleLang(msg.target);
  const same = (d) => googleText(d).trim().toLowerCase() === String(msg.word).trim().toLowerCase();
  const sl = googleSource(msg.lang, msg.target);
  let data = await googleRequest(msg.word, tl, GOOGLE_DICT_DT + "&dt=rm&hl=" + encodeURIComponent(tl) + sl);
  if (same(data) && !(Array.isArray(data[1]) && data[1].length)) {
    // la lingua indicata forse è sbagliata: lascio decidere a Google
    const retry = await googleRequest(msg.word, tl, GOOGLE_DICT_DT + "&dt=rm&hl=" + encodeURIComponent(tl) + (sl ? "&sl=auto" : ""));
    if (!same(retry) || (Array.isArray(retry[1]) && retry[1].length)) data = retry;
  }
  const entries = Array.isArray(data[1]) ? data[1] : [];
  const untranslated = same(data) && !entries.length;
  return {
    source: "Google Traduttore" + (llmError ? ` (${E.label.split(" (")[0].split(",")[0]}: ${llmError})` : ""),
    fallback: !!llmError, llmDaily: llmError === "richieste gratuite di oggi esaurite" || llmError === "modello non disponibile", llmFailed: !!llmError,
    lemma: "", pos: entries[0] ? String(entries[0][0] || "") : "",
    meaning: untranslated ? "" : googleText(data),
    untranslated,
    explanation: entries.slice(0, 3).map((e) => `${e[0]}: ${(e[1] || []).slice(0, 5).join(", ")}`).join(" · "),
    example: "", exampleTrans: "",
    lang: msg.lang || (typeof data[2] === "string" ? data[2] : ""),
    gdict: googleDict(data),
    // trascrizione in caratteri latini (alfabeti diversi: кошка → koshka), gratis
    translit: (() => { let t = ""; for (const p of data[0] || []) if (p && p[0] == null && p[1] == null && typeof p[3] === "string") t += p[3];
      t = t.trim(); return t && t.toLowerCase() !== String(msg.word).toLowerCase() && /[^\p{Script=Latin}\p{Script=Common}\p{Script=Inherited}\s]/u.test(msg.word) ? t : ""; })()
  };
}

// ---------- Pronuncia IPA di più parole in una richiesta (le parole già note non vengono mai richieste) ----------
async function ipa(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve una chiave di Gemini o Groq");
  const words = (Array.isArray(msg.words) ? msg.words : []).map(String).filter(Boolean).slice(0, 400);
  if (!words.length) return { ipa: {} };
  // a pezzi: Gemini ha molti token al minuto, Groq pochi (12000 al minuto per llama-3.3-70b, compresa la risposta
  // massima prenotata): con 300 parole e max_tokens 8192 la richiesta era "troppo grande" e non passava mai
  const size = msg.engine === "gemini" ? 200 : 80;
  const out = {};
  const queue = [];
  for (let i = 0; i < words.length; i += size) queue.push(words.slice(i, i + size));
  while (queue.length) {
    const part = queue.shift();
    try {
      Object.assign(out, await ipaPart(E, msg, part));
    } catch (e) {
      // troppo grande per il limite al minuto: divido a metà e riprovo (non oltre 10 parole)
      if (e && (e.tooLarge || e.tpm) && part.length > 10) { const h = Math.ceil(part.length / 2); queue.unshift(part.slice(0, h), part.slice(h)); continue; }
      if (Object.keys(out).length) break;   // quello che è arrivato lo tengo
      throw e;
    }
  }
  return { ipa: out };
}

async function ipaPart(E, msg, words) {
  const lang = String(msg.lang || "").split("-")[0];
  // per cinese, giapponese e coreano la lettura dipende dalla frase (kanji con più letture): la mando sempre
  const withSentence = !lang || /^(ja|zh|ko)$/.test(lang);
  const user = JSON.stringify(withSentence && msg.sentence ? { sentence: String(msg.sentence).slice(0, 400), words } : { words });
  // risposta massima su misura (circa 14 token per parola): prenota meno token al minuto
  const m = { ...msg, maxTokens: Math.min(E.maxTokens || 8192, 300 + words.length * 16) };
  const obj = parseObject(await paced(msg.engine, E, () => llmText(E, m, C.ipaPrompt(lang), user), !!msg.priority));
  let src = obj && obj.ipa != null ? obj.ipa : obj || {};
  const clean = (v) => String(v || "").trim().replace(/^[\/\[]+|[\/\]]+$/g, "").trim();
  const out = {};
  // anche in forma di elenco: ["ipa", …] oppure [{"word": …, "ipa": …}, …]
  if (Array.isArray(src)) {
    if (src.every((x) => typeof x === "string")) { if (src.length === words.length) words.forEach((w, i) => { if (src[i]) out[w] = clean(src[i]); }); return out; }
    const o = {};
    for (const x of src) if (x && typeof x === "object") o[String(x.word || x.w || x.text || "")] = x.ipa || x.pronunciation || x.p || "";
    src = o;
  }
  const norm = (k) => String(k || "").normalize("NFKC").toLowerCase().trim();
  const low = new Map(Object.keys(src).map((k) => [norm(k), src[k]]));
  for (const w of words) {
    const v = src[w] != null ? src[w] : low.get(norm(w));
    if (typeof v === "string" && clean(v)) out[w] = clean(v);
  }
  // il modello ha cambiato le chiavi (per esempio le ha scritte in kana o in caratteri latini) ma ha risposto a tutte,
  // nello stesso ordine: le abbino per posizione
  const vals = Object.values(src).filter((v) => typeof v === "string");
  if (Object.keys(out).length < words.length * 0.6 && vals.length === words.length) words.forEach((w, i) => { if (!out[w] && clean(vals[i])) out[w] = clean(vals[i]); });
  return out;
}

// ---------- Etimologia ----------
// La pagina della parola su Wiktionary (gratis, senza chiave): la leggo qui e la pagina estrae la sezione giusta
// Pagine di Wiktionary che contengono una parola (per trovare il lemma di una forma senza pagina sua)
async function wiktSearch(msg) {
  const q = String(msg.q || "").trim();
  if (!q) return { titles: [] };
  const limit = Math.min(20, Math.max(1, Number(msg.limit) || 6));
  // prefix: le pagine il cui titolo comincia così (per la radice: «cantav» → cantare, cantante…)
  const url = msg.prefix
    ? "https://en.wiktionary.org/w/api.php?action=query&list=prefixsearch&format=json&formatversion=2&origin=*&psnamespace=0&pslimit=" + limit + "&pssearch=" + encodeURIComponent(q)
    : "https://en.wiktionary.org/w/api.php?action=query&list=search&format=json&formatversion=2&origin=*&srnamespace=0&srlimit=" + limit + "&srprop=&srsearch=" + encodeURIComponent('"' + q + '"');
  const r = await fetch(url, { headers: { "Api-User-Agent": "SottotitoliDoppi/5.9 (estensione per imparare le lingue)" } });
  if (!r.ok) throw new Error("Wiktionary ha risposto " + r.status);
  const j = await r.json();
  return { titles: ((j.query && (j.query.search || j.query.prefixsearch)) || []).map((x) => x.title) };
}

// 1.6.6: di una pagina di Wiktionary serve solo la sezione della lingua della parola (le pagine delle parole comuni hanno
// decine di lingue: anche megabyte di HTML che la pagina di ogni scheda dovrebbe interpretare). Taglio qui, prima di mandarla.
function wiktTrim(html, names) {
  if (!Array.isArray(names) || !names.length || html.length < 30000) return html;
  const starts = [];
  const re = /<div class="mw-heading mw-heading2[^"]*">|<h2[\s>]/g;
  let m;
  while ((m = re.exec(html))) {
    // un <h2> dentro il riquadro mw-heading è la stessa intestazione
    if (starts.length && m[0].startsWith("<h2") && m.index - starts[starts.length - 1] < 120) continue;
    starts.push(m.index);
  }
  if (!starts.length) return html;
  const want = names.map((x) => String(x).toLowerCase());
  for (let i = 0; i < starts.length; i++) {
    const end = i + 1 < starts.length ? starts[i + 1] : html.length;
    const head = html.slice(starts[i], Math.min(end, starts[i] + 400));
    const id = (head.match(/\bid="([^"]+)"/) || [])[1];
    const t = String(id || "").replace(/_/g, " ").toLowerCase();
    if (id && want.some((n) => t === n || t.startsWith(n))) return html.slice(0, starts[0]) + html.slice(starts[i], end);
  }
  return html;
}
async function etymPage(msg) {
  const title = String(msg.word || "").trim();
  if (!title) return { html: "" };
  // site: l'edizione di Wiktionary (en di solito; anche quella nella lingua della parola, per la pronuncia)
  const site = /^[a-z]{2,3}(-[a-z]{2,8})*$|^simple$/.test(String(msg.site || "")) ? msg.site : "en";
  const url = `https://${site}.wiktionary.org/w/api.php?action=parse&format=json&formatversion=2&prop=text&redirects=1&origin=*&page=` + encodeURIComponent(title);
  const r = await fetch(url, { headers: { "Api-User-Agent": "SottotitoliDoppi/5.9 (estensione per imparare le lingue)" } });
  if (!r.ok) throw new Error("Wiktionary" + (site !== "en" ? " (" + site + ")" : "") + " ha risposto " + r.status);
  const j = await r.json();
  if (j.error) return { html: "", missing: true };
  return { html: wiktTrim((j.parse && j.parse.text) || "", msg.langs), title: (j.parse && j.parse.title) || title };
}

// Le parole di un livello JLPT (Jisho, gratis): 20 per pagina, salvate per non richiederle
const jlptCache = new Map();
async function jlptList(msg) {
  const level = String(msg.level || "N5").toLowerCase().replace(/[^n1-5]/g, "");
  const page = Math.max(1, Math.min(200, parseInt(msg.page, 10) || 1));
  const k = level + "|" + page;
  if (jlptCache.has(k)) return jlptCache.get(k);
  const r = await fetch("https://jisho.org/api/v1/search/words?keyword=" + encodeURIComponent("#jlpt-" + level) + "&page=" + page);
  if (!r.ok) throw new Error("Jisho ha risposto " + r.status);
  const j = await r.json();
  const items = (j.data || []).map((d) => ({
    word: String((d.japanese && d.japanese[0] && (d.japanese[0].word || d.japanese[0].reading)) || d.slug || ""),
    reading: String((d.japanese && d.japanese[0] && d.japanese[0].reading) || ""),
    common: !!d.is_common,
    meanings: ((d.senses && d.senses[0] && d.senses[0].english_definitions) || []).slice(0, 4).map(String),
    pos: ((d.senses && d.senses[0] && d.senses[0].parts_of_speech) || []).slice(0, 2).map(String)
  })).filter((x) => x.word);
  const out = { items, more: items.length >= 20 };
  jlptCache.set(k, out);
  while (jlptCache.size > 300) jlptCache.delete(jlptCache.keys().next().value);
  return out;
}

// Dizionario giapponese Jisho (gratis): lettura in kana, livello JLPT, parola comune, significati in inglese
async function jisho(msg) {
  const w = String(msg.word || "").trim();
  if (!w) return { items: [] };
  const r = await fetch("https://jisho.org/api/v1/search/words?keyword=" + encodeURIComponent(w));
  if (!r.ok) throw new Error("Jisho ha risposto " + r.status);
  const j = await r.json();
  const items = (j.data || []).slice(0, 5).map((d) => ({
    word: String((d.japanese && d.japanese[0] && (d.japanese[0].word || d.japanese[0].reading)) || d.slug || ""),
    reading: String((d.japanese && d.japanese[0] && d.japanese[0].reading) || ""),
    common: !!d.is_common, jlpt: (d.jlpt || []).map((x) => String(x).replace(/^jlpt-/i, "").toUpperCase()).sort().reverse(),
    meanings: ((d.senses && d.senses[0] && d.senses[0].english_definitions) || []).slice(0, 4).map(String),
    pos: ((d.senses && d.senses[0] && d.senses[0].parts_of_speech) || []).slice(0, 2).map(String)
  }));
  // prima la voce scritta esattamente così (o con quella lettura)
  items.sort((a, b) => ((b.word === w || b.reading === w) - (a.word === w || a.reading === w)));
  return { items };
}

// Un kanji o un carattere cinese da solo (gratis, senza chiavi): per imparare i caratteri uno per uno.
// I dati sono dentro l'estensione (han-data.json, uguali per giapponese, cinese, coreano e vietnamita: Unihan di
// Unicode, parti di BabelStone, KANJIDIC, HSK 3.0, lista ufficiale cinese dei caratteri comuni; si rifà con
// tools/crea_han_data.py). Google (gratis) dà il significato del carattere da solo nella tua lingua e traduce le
// definizioni inglesi. Risposta: { ch, found, def, defTr, jm, jmTr, py, yue, on, kun, ko, vi, strokes, radical, parts,
// jlpt, grade, freq, hsk, tg, koe, joyo, sv, tv, meaning, alt, reading, sources }
let hanData = null;
async function hanDataLoad() {
  if (!hanData) hanData = fetch(DS_EXT.runtime.getURL("han-data.json")).then((r) => r.json()).catch(() => { hanData = null; return null; });
  return hanData;
}
const hanCache = new Map();
async function hanChar(msg) {
  const ch = Array.from(String(msg.ch || "").trim())[0] || "";
  if (!ch) return { error: "nessun carattere" };
  const lang = String(msg.lang || "").split("-")[0], tgt = String(msg.target || "it"), target = tgt.split("-")[0];
  const k = [ch, lang, target].join("|");
  if (hanCache.has(k)) return hanCache.get(k);
  const D = await hanDataLoad();
  const e = (D && D.c && D.c[ch]) || null;
  const out = { ch, found: !!e, meaning: "", alt: [], reading: "", sources: [] };
  if (e) {
    Object.assign(out, { def: e.d || "", jm: e.jm || "", py: e.py || "", yue: e.yue || "", on: [...new Set(e.on || [])], kun: [...new Set(e.kun || [])],
      ko: e.ko || "", vi: e.vi || "", strokes: e.s || 0, jlpt: e.jlpt || 0, grade: e.g || 0, freq: e.f || 0, hsk: e.hsk || 0, tg: e.tg || 0,
      koe: !!e.koe, joyo: !!e.joyo, sv: e.sv || "", tv: e.tv || "" });
    // radicale: "39.5" = radicale 39 più 5 tratti ("'" = forma semplificata del radicale)
    const rm = /^(\d+'*)\.(\d+)/.exec(e.r || "");
    const rd = rm && D.rad && D.rad[rm[1]];
    if (rd) out.radical = { n: parseInt(rm[1], 10), ch: rd[0], def: rd[1], extra: parseInt(rm[2], 10) };
    // parti (scomposizione): solo quelle che sono caratteri con un significato
    const parts = [...new Set(Array.from(String(e.p || "").replace(/[\u2ff0-\u2fff\u31ef]/g, "")))].filter((x) => x !== ch && D.c[x] && D.c[x].d);
    out.parts = parts.slice(0, 5).map((x) => ({ ch: x, def: D.c[x].d.split(/[;,]/)[0].trim(), py: D.c[x].py || "" }));
    out.sources.push("Unihan" + (e.jlpt || e.g || e.jm ? ", KANJIDIC" : "") + (e.hsk ? ", HSK 3.0" : ""));
  }
  const jobs = [];
  // definizioni nella tua lingua (una richiesta a Google per tutte)
  if (e && target !== "en") {
    const texts = [out.def, out.jm, out.radical ? out.radical.def : "", ...(out.parts || []).map((x) => x.def)];
    const idx = texts.map((t, i) => (t ? i : -1)).filter((i) => i >= 0);
    if (idx.length) jobs.push(translateGoogle({ texts: idx.map((i) => texts[i]), target: tgt, source: "en" }).then((tr) => {
      const got = {}; idx.forEach((i, j) => { got[i] = (tr[j] || "").trim(); });
      if (got[0]) out.defTr = got[0];
      if (got[1]) out.jmTr = got[1];
      if (got[2] && out.radical) out.radical.defTr = got[2];
      (out.parts || []).forEach((x, j) => { if (got[3 + j]) x.defTr = got[3 + j]; });
    }).catch(() => {}));
  }
  jobs.push((async () => {
    const sl = "&sl=" + encodeURIComponent(lang === "zh" ? "zh-CN" : lang || "auto");
    const data = await googleRequest(ch, googleLang(tgt), "&dt=rm&dt=bd" + sl);
    out.meaning = googleText(data).trim();
    if (out.meaning === ch) out.meaning = "";
    for (const p of data[0] || []) if (p && p[0] == null && p[1] == null && typeof p[3] === "string") out.reading += p[3];
    out.reading = out.reading.trim();
    for (const x of (Array.isArray(data[1]) ? data[1] : []).slice(0, 3))
      for (const w of (Array.isArray(x[1]) ? x[1] : []).slice(0, 4)) if (typeof w === "string" && !out.alt.includes(w) && w !== out.meaning) out.alt.push(w);
    out.alt = out.alt.slice(0, 6);
    out.sources.unshift("Google");
  })().catch(() => {}));
  await Promise.all(jobs);
  if (!out.sources.length) return { ch, error: "carattere non trovato e Google non ha risposto" };
  hanCache.set(k, out);
  while (hanCache.size > 500) hanCache.delete(hanCache.keys().next().value);
  return out;
}

// ---------- Strumenti per imparare (gratis, senza chiavi) ----------
// Audio registrato (Wiktionary/Commons, Tatoeba): lo scarico qui, la pagina lo suona (così la protezione del sito non lo blocca)
async function fetchB64(msg) {
  const url = String(msg.url || "");
  if (!/^https:\/\/(upload\.wikimedia\.org|commons\.wikimedia\.org\/wiki\/Special:FilePath|audio\.tatoeba\.org|tatoeba\.org|api\.tatoeba\.org|ssl\.gstatic\.com|www\.gstatic\.com|[a-z0-9-]+\.googleusercontent\.com|www\.google\.com)\//.test(url)) throw new Error("indirizzo non permesso");
  const r = await fetch(url);
  if (!r.ok) throw new Error("audio non disponibile (" + r.status + ")");
  const bytes = new Uint8Array(await r.arrayBuffer());
  if (bytes.length > 4 * 1024 * 1024) throw new Error("audio troppo grande");
  return { b64: bytesToB64(bytes), type: r.headers.get("content-type") || "" };
}

// Frasi d'esempio vere (Tatoeba), con traduzione e, se c'è, la registrazione di un madrelingua
async function tatoeba(msg) {
  const l3 = C.LANG3[String(msg.lang || "").split("-")[0]] || "", t3 = C.LANG3[String(msg.target || "").split("-")[0]] || "";
  if (!l3) return { items: [] };
  const word = String(msg.word || "").trim();
  const norm = (x) => String(x || "").toLowerCase();
  const flat = (tr) => (Array.isArray(tr) ? tr.flat(2) : []).filter((x) => x && typeof x === "object");
  const pickTrans = (tr) => { const all = flat(tr); const t = all.find((x) => x.lang === t3) || null; return t ? String(t.text || "") : ""; };
  const audioOf = (s) => {
    const out = [];
    for (const a of s.audios || []) {
      if (!a) continue;
      if (a.download_url) out.push(/^https?:/.test(a.download_url) ? a.download_url : "https://tatoeba.org" + (a.download_url.startsWith("/") ? "" : "/") + a.download_url);
      if (a.id) out.push("https://api.tatoeba.org/v1/audio/" + a.id + "/file", "https://tatoeba.org/en/audio/download/" + a.id);
      if (out.length) break;
    }
    return [...new Set(out)];
  };
  const q = encodeURIComponent(word.replace(/[()|!@~"\/^$<=*\[\]-]+/g, " ").trim());
  // API ufficiale (v1): prima le frasi registrate da un madrelingua, poi le altre per arrivare a 3.
  // Il vecchio indirizzo del sito (api_v0) solo se la v1 non risponde.
  const v1 = `https://api.tatoeba.org/v1/sentences?lang=${l3}&q=${q}&sort=relevance&limit=20&include=audios` + (t3 ? `&showtrans:lang=${t3}` : "");
  const v0 = `https://tatoeba.org/en/api_v0/search?from=${l3}&query=${q}&orphans=no&unapproved=no&sort=relevance` + (t3 ? `&to=${t3}` : "");
  const groups = [[v1 + "&has_audio=yes", v1], [v0 + "&has_audio=yes", v0]];
  let lastErr = "", ok = 0, via = "";
  const seen = new Set(), list = [];
  const w = norm(word), stem = w.length > 4 ? w.slice(0, Math.max(3, w.length - 3)) : w;
  const good = () => list.filter((s) => String(s.text).length <= 140 && norm(s.text).includes(stem)).length;
  for (const urls of groups) {
    if (ok) break;
    for (const u of urls) {
      if (good() >= 3) break;
      try {
        const r = await fetch(u, { headers: { Accept: "application/json" } });
        if (!r.ok) { lastErr = "Tatoeba ha risposto " + r.status; continue; }
        const j = await r.json();
        ok++; via = via || (u.includes("/v1/") ? "v1" : "v0");
        const got = Array.isArray(j.data) ? j.data : Array.isArray(j.results) ? j.results : [];
        for (const x of got) if (x && x.text && !seen.has(x.id || x.text)) { seen.add(x.id || x.text); list.push(x); }
      } catch (e) { lastErr = String(e.message || e); }
    }
  }
  if (!list.length && lastErr && !ok) throw new Error(lastErr);
  // la parola esatta prima, ma vanno bene anche le forme flesse trovate da Tatoeba (кошка → кошку)
  const items = list
    .filter((s) => String(s.text).length <= 140 && norm(s.text).includes(stem))
    .map((s) => { const au = audioOf(s); return { text: String(s.text), trans: pickTrans(s.translations), audio: au[0] || "", audioAlt: au.slice(1), exact: norm(s.text).includes(w) }; })
    .sort((a, b) => (!!b.audio - !!a.audio) || (b.exact - a.exact) || (!!b.trans - !!a.trans) || a.text.length - b.text.length)
    .slice(0, 3);
  // senza traduzione nella tua lingua: Google
  const miss = items.filter((x) => !x.trans);
  if (miss.length && msg.target) {
    try { const tr = await translateGoogle({ texts: miss.map((x) => x.text), target: msg.target, source: msg.lang }); miss.forEach((x, i) => { x.trans = tr[i] || ""; x.google = true; }); } catch {}
  }
  return { items, via, err: lastErr };
}

// Controllo dell'ortografia e della grammatica della frase (LanguageTool, gratis, circa 20 richieste al minuto)
async function langtool(msg) {
  const b = String(msg.lang || "").split("-")[0];
  const code = C.LT_LANGS[b];
  if (!code) return { unsupported: true };
  const body = new URLSearchParams({ text: String(msg.text || "").slice(0, 1500), language: code });
  const r = await fetch("https://api.languagetool.org/v2/check", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
  if (!r.ok) throw await httpError(r, "LanguageTool");
  const j = await r.json();
  return { matches: (j.matches || []).slice(0, 20).map((m) => ({ offset: m.offset, length: m.length, message: String(m.message || ""),
    short: String(m.shortMessage || ""), repl: (m.replacements || []).slice(0, 3).map((x) => x.value), type: (m.rule && m.rule.issueType) || "" })) };
}

// Elenco delle parole più usate in una lingua (dai sottotitoli dei film, progetto FrequencyWords, licenza libera)
// 1.6.6: la posizione di una parola nell'elenco di frequenza la calcola il sottofondo (una copia dell'elenco per lingua in
// memoria, cercata con indexOf): prima ogni scheda caricava nella pagina l'intero elenco (mezzo megabyte, 50.000 voci in una
// Map) in ogni scheda del browser. → { rank }: posizione, 0 = non c'è, null = elenco non disponibile
const freqTexts = new Map();
async function freqRank(msg) {
  const b = String(msg.lang || "").split("-")[0].toLowerCase();
  const w = String(msg.word || "").toLowerCase().trim();
  if (!b || !w || /[\n\r]/.test(w)) return { rank: null };
  let p = freqTexts.get(b);
  if (!p) {
    p = (async () => {
      const key = "freq:" + b;
      const got = await DS_EXT.storage.local.get({ [key]: null, freqFail: {} }).catch(() => ({}));
      let text = got && got[key];
      if (text) return text;
      const fail = (got && got.freqFail) || {};
      if (fail[b] && Date.now() - fail[b] < 86400e3) return null;   // non c'era: riprovo domani
      try {
        const r = await freqList({ lang: b });
        if (!r || !r.list) throw new Error("vuoto");
        await DS_EXT.storage.local.set({ [key]: r.list }).catch(() => {});
        return r.list;
      } catch {
        await DS_EXT.storage.local.set({ freqFail: { ...fail, [b]: Date.now() } }).catch(() => {});
        return null;
      }
    })();
    freqTexts.set(b, p);
    p.then((t) => { if (!t) freqTexts.delete(b); });
    while (freqTexts.size > 4) freqTexts.delete(freqTexts.keys().next().value);
  }
  const text = await p;
  if (!text) return { rank: null };
  const hay = "\n" + text + "\n", i = hay.indexOf("\n" + w + "\n");
  if (i < 0) return { rank: 0 };
  let n = 0;
  for (let k = 0; k <= i; k++) if (hay.charCodeAt(k) === 10) n++;
  return { rank: n };
}
async function freqList(msg) {
  const b = String(msg.lang || "").split("-")[0];
  const folder = { zh: "zh_cn", pt: "pt", no: "no", nb: "no" }[b] || b;
  const url = `https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/${folder}/${folder}_50k.txt`;
  const r = await fetch(url);
  if (!r.ok) throw new Error("elenco delle frequenze non disponibile per questa lingua (" + r.status + ")");
  const text = await r.text();
  const words = [];
  for (const line of text.split("\n")) {
    const w = line.split(" ")[0].trim().toLowerCase();
    if (w) words.push(w);
    if (words.length >= 30000) break;
  }
  return { list: words.join("\n") };
}

// Un'immagine per la parola (Wikimedia Commons), cercata con la traduzione inglese: solo per le carte di Anki
// Lettura in lettere latine di una riga con kanji o caratteri cinesi (Google, gratis, nessun token): i kanji
// hanno più letture e una tabella non basta. Una richiesta per riga, salvata.
const romanCache = new Map();
async function romanLine(msg) {
  const text = String(msg.text || "").slice(0, 600);
  if (!text.trim()) return { text: "" };
  const k = (msg.lang || "") + "|" + text;
  if (romanCache.has(k)) return { text: romanCache.get(k) };
  const sl = msg.lang ? "&sl=" + encodeURIComponent(String(msg.lang).split("-")[0] === "zh" ? "zh-CN" : String(msg.lang).split("-")[0]) : "";
  const data = await googleRequest(text, "en", "&dt=rm" + sl);
  let t = "";
  for (const p of data[0] || []) if (p && p[0] == null && p[1] == null && typeof p[3] === "string") t += p[3];
  t = t.trim();
  romanCache.set(k, t);
  while (romanCache.size > 400) romanCache.delete(romanCache.keys().next().value);
  return { text: t };
}

// ---------- Immagini per le carte di Anki (gratis, senza chiavi) ----------
// Fonti: Wikipedia (l'immagine principale della voce, di solito la più adatta), Wikimedia Commons (ricerca tra i
// file), Openverse (foto con licenza libera). La parola si cerca in inglese (tradotta con Google), a meno che tu
// scriva tu cosa cercare. Risposta: { items: [{ url, thumb, source, title }], query }
const imgQueryCache = new Map();
// 1.7.10: in che lingua si cerca (msg.qlang): "word" = la lingua della parola, com'è (di serie: le foto sono taggate nella lingua
// del posto, quindi si trovano immagini più adatte), "en" = tradotta in inglese (come prima), "ui" = nella lingua di «Traduci in»,
// oppure il codice di una lingua. Risposta: { q, lang } (la lingua in cui è scritta la ricerca).
async function imageQuery(msg) {
  let q = String(msg.query || "").trim();
  const wl = String(msg.lang || "").split("-")[0];
  let want = msg.qlang ? String(msg.qlang) : String((await DS_EXT.storage.sync.get({ ankiImageLang: "word" })).ankiImageLang || "word");
  if (want === "ui") want = (await DS_EXT.storage.sync.get({ targetLang: "it" })).targetLang || "it";
  if (want === "word") want = wl || "en";
  const to = want.split("-")[0] === "zh" ? want : want.split("-")[0];
  if (!q || msg.raw || !wl || to === wl) return { q, lang: msg.raw ? (to || "en") : wl || "en" };
  const k = msg.lang + "|" + to + "|" + q;
  if (imgQueryCache.has(k)) return { q: imgQueryCache.get(k), lang: to };
  try { q = (await translateGoogle({ texts: [q], target: to, source: msg.lang }))[0] || q; } catch {}
  if (to === "en") q = String(q).replace(/^(the|a|an|to)\s+/i, "").trim();
  imgQueryCache.set(k, q);
  return { q, lang: to };
}
const IMG_OK = /image\/(jpeg|png|webp|gif)/;
async function imgWikipedia(q, n, lang) {
  const wl = /^[a-z]{2,3}$/.test(lang || "") ? lang : "en";
  const url = "https://" + wl + ".wikipedia.org/w/api.php?action=query&format=json&formatversion=2&origin=*&redirects=1&generator=search&gsrnamespace=0&gsrlimit=" + n +
    "&prop=pageimages&piprop=thumbnail|name&pithumbsize=400&pilicense=any&gsrsearch=" + encodeURIComponent(q);
  const r = await fetch(url);
  if (!r.ok) throw new Error("Wikipedia ha risposto " + r.status);
  const j = await r.json();
  return ((j.query && j.query.pages) || []).sort((a, b) => (a.index || 0) - (b.index || 0))
    .filter((p) => p.thumbnail && p.thumbnail.source && !/\.svg/i.test(p.pageimage || "") && !/\.svg\.png$/i.test(p.thumbnail.source))
    .map((p) => ({ url: p.thumbnail.source, thumb: p.thumbnail.source, source: "Wikipedia", title: p.title }));
}
async function imgCommons(q, n, lang) {
  const url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2&origin=*&generator=search&gsrnamespace=6&gsrlimit=" + n +
    "&prop=imageinfo&iiprop=url|mime&iiurlwidth=400&gsrsearch=" + encodeURIComponent(q + " filetype:bitmap");
  const r = await fetch(url);
  if (!r.ok) throw new Error("Wikimedia Commons ha risposto " + r.status);
  const j = await r.json();
  return ((j.query && j.query.pages) || []).sort((a, b) => (a.index || 0) - (b.index || 0))
    .map((p) => ({ p, ii: (p.imageinfo || [])[0] }))
    .filter(({ ii }) => ii && IMG_OK.test(ii.mime || "") && (ii.thumburl || ii.url))
    .map(({ p, ii }) => ({ url: ii.thumburl || ii.url, thumb: ii.thumburl || ii.url, source: "Commons", title: String(p.title || "").replace(/^File:/, "") }));
}
async function imgOpenverse(q, n, lang) {
  const r = await fetch("https://api.openverse.org/v1/images/?mature=false&page_size=" + n + "&q=" + encodeURIComponent(q));
  if (!r.ok) throw new Error("Openverse ha risposto " + r.status);
  const j = await r.json();
  return (j.results || []).filter((x) => x && (x.thumbnail || x.url))
    .map((x) => ({ url: x.thumbnail || x.url, thumb: x.thumbnail || x.url, source: "Openverse", title: x.title || "" }));
}
// Google Immagini: non ha un'interfaccia gratuita ufficiale; leggo la pagina dei risultati (può smettere di funzionare se Google
// cambia la pagina o chiede il consenso: in quel caso c'è «Apri Google Immagini» per sceglierla a mano)
async function imgGoogle(q, n, lang) {
  const hl = String(lang || "en").split("-")[0];
  const r = await fetch("https://www.google.com/search?tbm=isch&safe=active&hl=" + encodeURIComponent(hl) + "&q=" + encodeURIComponent(q), { credentials: "include" });
  if (!r.ok) throw new Error("Google ha risposto " + r.status);
  const html = (await r.text()).replace(/\\u003d/g, "=").replace(/\\u0026/g, "&").replace(/\\\//g, "/");
  const thumbs = [...new Set(html.match(/https:\/\/encrypted-tbn\d\.gstatic\.com\/images\?q=tbn:[A-Za-z0-9_-]+/g) || [])];
  const fulls = [];
  const re = /\["(https?:\/\/[^"\\]+?\.(?:jpe?g|png|webp))",\s*\d+,\s*\d+\]/gi;
  for (let m; (m = re.exec(html)); ) if (!/gstatic\.com|google\./i.test(m[1]) && !fulls.includes(m[1])) fulls.push(m[1]);
  const out = [];
  for (let i = 0; i < Math.max(thumbs.length, fulls.length) && out.length < n; i++) {
    const thumb = thumbs[i] || fulls[i], url = fulls[i] || thumbs[i];
    if (thumb) out.push({ url, thumb: thumbs.length >= fulls.length ? thumb : url, source: "Google", title: q });
  }
  if (!out.length) throw new Error("Google non ha dato immagini (pagina del consenso o formato cambiato)");
  return out;
}
async function imageSearch(msg) {
  const { q, lang: ql } = await imageQuery(msg);
  if (!q) return { items: [], query: "" };
  const src = String(msg.source || "auto");
  const want = { wikipedia: [imgWikipedia], commons: [imgCommons], openverse: [imgOpenverse], google: [imgGoogle], all: [imgWikipedia, imgCommons, imgOpenverse, imgGoogle] }[src] || [imgWikipedia, imgCommons];
  const n = Math.max(2, Math.min(12, msg.n || 6));
  const res = await Promise.all(want.map((f) => f(q, n, ql).catch((e) => ({ error: String(e.message || e) }))));
  const items = [], seen = new Set(), errors = [];
  for (const r of res) {
    if (!Array.isArray(r)) { errors.push(r.error); continue; }
    for (const it of r) if (!seen.has(it.url)) { seen.add(it.url); items.push(it); }
  }
  return { items: items.slice(0, 16), query: q, qlang: ql, error: !items.length && errors.length ? errors.join("; ") : "" };
}
// compatibilità: la prima immagine
async function commonsImage(msg) {
  const s = await DS_EXT.storage.sync.get({ ankiImageSource: "auto" });
  const r = await imageSearch({ ...msg, source: msg.source || s.ankiImageSource });
  return { url: (r.items[0] && r.items[0].url) || "", query: r.query };
}
// L'immagine la scarica l'estensione e la passa ad Anki già pronta: se la scaricasse Anki (AnkiConnect), molti siti
// (Wikipedia/Wikimedia compresi) la rifiutano, e la carta restava senza immagine.
async function imageForAnki(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("immagine non disponibile (" + r.status + ")");
  const type = (r.headers.get("content-type") || "").split(";")[0].trim();
  if (type && !/^image\//.test(type)) throw new Error("non è un'immagine");
  const bytes = new Uint8Array(await r.arrayBuffer());
  if (bytes.length > 5 * 1024 * 1024) throw new Error("immagine troppo grande");
  const ext = (/png/.test(type) && "png") || (/webp/.test(type) && "webp") || (/gif/.test(type) && "gif") || ((url.match(/\.(jpe?g|png|webp|gif)(?:$|[?#])/i) || [, "jpg"])[1].toLowerCase());
  return { data: bytesToB64(bytes), ext: ext === "jpeg" ? "jpg" : ext };
}

// Modi di dire in una frase (Parole al Volo, come l'allineamento dei sottotitoli di Sottotitoli Doppi): una richiesta
// piccola, solo se la scheda resta aperta, salvata per frase. { idioms: [{ text, meaning }] }
// 1.6.3: errori momentanei dei modelli (503 «high demand», 429 al minuto, rete): riprovo un paio di volte con una pausa,
// senza consumare altro che la richiesta; i limiti di oggi (daily), le chiavi sbagliate (fatal) e i modelli spariti no
async function llmRetry(fn, tries = 3) {
  let last;
  for (let i = 0; i < tries; i++) {
    try { return await fn(); }
    catch (e) {
      last = e;
      const transient = e && !e.daily && !e.fatal && !e.modelGone && !e.tooLarge && (e.rateLimited || /\b(5\d\d)\b|overload|high demand|unavailable|fetch|network|timeout|illeggibile/i.test(String(e.message || e)));
      if (!transient || i === tries - 1) throw e;
      const wait = Math.min(8000, Math.max(e.retryAfter ? e.retryAfter * 1000 : 0, 1500 * (i + 1) * (i + 1)));
      await new Promise((ok) => setTimeout(ok, wait));
    }
  }
  throw last;
}

async function idiomsFind(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve una chiave di Gemini o Groq");
  const t = C.LANG_EN[msg.target] || msg.target || "Italian";
  const l = langNameEn(msg.lang) || "the language of the sentence";
  const system = `You find idioms in ${l} text for a language learner. List every idiom, figurative expression, phrasal verb or fixed phrase ` +
    `(2 to 7 words) in the sentence whose meaning is NOT simply the sum of its words. Copy "text" exactly as it is written in the sentence. ` +
    `"meaning": what it means, in ${t}, short. Ordinary word combinations are not idioms: if there are none, return an empty list. ` +
    `Reply only with JSON: {"idioms": [{"text": "...", "meaning": "..."}]}` +
    // «🔎 Modi di dire con questa parola» nella scheda: quelli che contengono quella parola (anche in un'altra forma)
    (msg.word ? ` Look especially for the expressions that contain the word "${String(msg.word).slice(0, 60)}" (in any form).` : "");
  const m = { ...msg, maxTokens: 400 };
  const o = await llmRetry(async () => parseObject(await paced(msg.engine, E, () => llmText(E, m, system, JSON.stringify({ sentence: String(msg.sentence || "").slice(0, 500) })), false)));
  const sent = String(msg.sentence || "").toLowerCase();
  const idioms = (Array.isArray(o.idioms) ? o.idioms : [])
    .map((x) => ({ text: String((x && x.text) || "").trim(), meaning: llmField(x && x.meaning) }))
    .filter((x) => x.text && x.text.split(/\s+/).length >= 2 && x.text.split(/\s+/).length <= 7 && (sent.includes(x.text.toLowerCase()) || exprInSentence(x.text, sent)) && !wrongScript(x.meaning, msg.target))
    .slice(0, 5);
  return { idioms, source: E.label.split(" (")[0].split(",")[0] };
}

// 1.6.3: i modi di dire che contengono una parola, in generale (non solo in una frase): prima l'elenco gratuito di Wiktionary
// (dizionario scaricato una volta per lingua), poi, solo se lo chiedi, il modello (con esempio e significato)
async function idiomsAbout(msg) {
  const word = String(msg.word || "").trim().slice(0, 60);
  if (!word) return { dict: [], idioms: [] };
  const lang = String(msg.lang || "").split("-")[0].toLowerCase();
  const stem = (x) => { const w = x.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); return w.length > 4 ? w.slice(0, Math.max(3, w.length - 2)) : w; };
  const sw = stem(word);
  const out = { dict: [], idioms: [], source: "" };
  try {
    const d = await idiomDict({ lang });
    out.dict = (d.list || []).filter((t) => /\s/.test(t) && t.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").split(/[\s'’-]+/).some((p) => p === word.toLowerCase() || (sw.length >= 3 && p.startsWith(sw)))).slice(0, 40);
  } catch (e) { out.dictError = String(e.message || e); }
  if (!msg.engine) return out;
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve una chiave di Gemini o Groq");
  const t = C.LANG_EN[msg.target] || msg.target || "Italian";
  const l = langNameEn(lang) || "the given language";
  const system = `You are a lexicographer helping a language learner. List the most common idioms, figurative expressions, phrasal verbs and fixed phrases in ${l} ` +
    `(2 to 7 words) that contain the word "${word}" (in any form). Only real expressions that native speakers use, whose meaning is NOT simply the sum of the words. ` +
    `"text": the expression in ${l}; "meaning": what it means, in ${t}, short; "example": one short natural example sentence in ${l}. ` +
    (msg.sentence ? `The learner met the word in this sentence: "${String(msg.sentence).slice(0, 300)}". If an expression with the word occurs in that sentence, put it first, copy "text" exactly as written there and add "in_sentence": true. ` : "") +
    (out.dict.length ? `Known from a dictionary (include them with their meaning, and add others you know): ${out.dict.slice(0, 12).join("; ")}. ` : "") +
    `At most 8, most common first; if there are none, an empty list. Reply only with JSON: {"idioms": [{"text": "...", "meaning": "...", "example": "..."}]}`;
  const m = { ...msg, maxTokens: 1200 };
  const o = await llmRetry(async () => parseObject(await paced(msg.engine, E, () => llmText(E, m, system, JSON.stringify({ word, sentence: String(msg.sentence || "").slice(0, 300) })), false)));
  out.idioms = (Array.isArray(o.idioms) ? o.idioms : [])
    .map((x) => ({ text: String((x && x.text) || "").trim(), meaning: llmField(x && x.meaning), example: llmField(x && x.example) }))
    .map((x) => ({ ...x, inSentence: !!msg.sentence && (String(msg.sentence).toLowerCase().includes(x.text.toLowerCase()) || exprInSentence(x.text, msg.sentence)) }))
    .filter((x) => x.text && x.text.split(/\s+/).length >= 2 && x.text.split(/\s+/).length <= 8 && !wrongScript(x.meaning, msg.target) && !(lang && wrongScript(x.text, lang)) &&
      x.text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").split(/[\s'’-]+/).some((p) => p === word.toLowerCase() || (sw.length >= 3 && p.startsWith(sw))))
    .slice(0, 8);
  out.source = E.label.split(" (")[0].split(",")[0];
  return out;
}

// 1.6.2: un kanji / carattere cinese / hanja spiegato dal modello (pulsante nella scheda del carattere): significati,
// letture, parole comuni, come è fatto, un aiuto per ricordarlo, origine del segno. Una richiesta, salvata (storage.local hanLlm)
async function hanExplain(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve un modello (Gemini, Groq…)");
  const ck = [msg.lang, msg.ch, msg.target, msg.engine, msg.model].join("|");
  const store = (await DS_EXT.storage.local.get({ hanLlm: {} })).hanLlm || {};
  if (store[ck]) return { ...store[ck], cached: true };
  const t = C.LANG_EN[msg.target] || langNameEn(msg.target) || "Italian";
  const l = msg.lang === "ja" ? "Japanese (kanji)" : msg.lang === "ko" ? "Korean (hanja)" : msg.lang === "zh" ? "Chinese" : (langNameEn(msg.lang) || "Chinese/Japanese");
  const system = `You explain a single ${l} character to a language learner, in ${t}. Be accurate; if unsure, say so briefly. ` +
    `Reply only with JSON: {"meaning": "main meanings, short", "readings": "readings with when each is used (for Japanese: on'yomi and kun'yomi in kana and romaji; ` +
    `for Chinese: pinyin with tones; for Korean: hangul reading)", "words": [{"w": "common word containing it", "r": "its reading", "t": "translation in ${t}"}] (4-6 items, ` +
    `most useful first), "parts": "how the character is built (components and radical, with their meaning)", "mnemonic": "a short memory aid that uses the parts", ` +
    `"origin": "origin of the glyph (pictograph, ideograph, phono-semantic compound...) and how the meaning developed", "note": "anything a learner often confuses (similar characters, usage), or empty"}. ` +
    `Everything except the character itself, the words and the readings MUST be in ${t}.`;
  const user = JSON.stringify({ character: msg.ch, in_word: msg.word || "", sentence: String(msg.sentence || "").slice(0, 300) });
  const o = parseObject(await paced(msg.engine, E, () => llmText(E, { ...msg, maxTokens: 3000 }, system, user), true));
  const out = {
    meaning: llmField(o.meaning), readings: llmField(o.readings), parts: llmField(o.parts), mnemonic: llmField(o.mnemonic),
    origin: llmField(o.origin), note: llmField(o.note),
    words: (Array.isArray(o.words) ? o.words : []).filter((x) => x && x.w).slice(0, 8).map((x) => ({ w: String(x.w), r: llmField(x.r), t: llmField(x.t) })),
    source: E.label.split(" (")[0].split(",")[0] + (msg.model ? " · " + msg.model : ""), at: Date.now()
  };
  if (!out.meaning && !out.words.length) throw new Error("risposta del modello non leggibile");
  store[ck] = out;
  const ks = Object.keys(store);
  for (const k of ks.slice(0, Math.max(0, ks.length - 600))) delete store[k];
  await DS_EXT.storage.local.set({ hanLlm: store });
  return out;
}

// Quando Wiktionary non ha l'etimologia: una richiesta al modello (solo se la chiedi con il pulsante)
async function etymLlm(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve una chiave di Gemini o Groq");
  const t = C.LANG_EN[msg.target] || msg.target || "Italian";
  const l = C.LANG_EN[msg.lang] || C.STT_LANGS[msg.lang] || msg.lang || "the language of the sentence";
  const system = `You are an etymologist. Explain the etymology (word origin) of the given ${l} word for a language learner, in ${t}, ` +
    `in 1-3 short sentences. Do not stop at the verb or noun it is derived from in the same language (an inflected form or a participle ` +
    `is not an etymology): trace it back step by step through every language it passed through to the oldest known root, with ` +
    `the original meaning of that root in ${t}, as a good etymological dictionary does; related words in other languages if useful. ` +
    `If you are not sure, say so briefly. Reply only with JSON: {"etymology": "...", "lemma": "dictionary form"}`;
  // «✨ Spiegala meglio»: c'è già il testo di Wiktionary, ma è scarno; il modello lo spiega e lo completa (accanto, non al posto)
  const deeper = msg.wikt ? `\nThe learner already has this dictionary entry (Wiktionary): «${String(msg.wikt).slice(0, 1200)}». It is too terse: ` +
    `explain it more fully and clearly in 3-6 sentences (what each step means, the original meanings, how the meaning changed, related words ` +
    `the learner may know), correcting it only if you are sure it is wrong.` : "";
  const user = JSON.stringify({ word: msg.word, sentence: String(msg.sentence || "").slice(0, 300) });
  const m = { ...msg, maxTokens: deeper ? 1000 : 600 };
  const o = parseObject(await paced(msg.engine, E, () => llmText(E, m, system + deeper, user), true));
  return { text: String(o.etymology || "").trim(), lemma: String(o.lemma || ""), source: E.label.split(" (")[0].split(",")[0] };
}

// ---------- Elenco modelli disponibili ----------
async function listModels(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E) throw new Error("servizio sconosciuto");
  if (E.staticModels) return { models: E.staticModels };
  if (E.kind !== "openai") return { models: [] };
  if (E.needsKey && !msg.key) throw new Error("inserisci prima la chiave");

  const base = openaiBase(E, msg);
  const headers = {};
  if (msg.key) headers.Authorization = "Bearer " + msg.key.trim();
  let r;
  try { r = await fetch(base + "/models", { headers }); } catch (e) { if (E.local) throw localError(base); throw e; }
  if (E.local && r.status === 403) throw new Error("Il modello locale rifiuta la richiesta: imposta OLLAMA_ORIGINS (vedi LEGGIMI).");
  if (!r.ok) throw await httpError(r, E.local ? "Il modello locale" : E.label.split(",")[0]);
  const data = await r.json();

  let ids = (data.data || data.models || []).map((m) => String(m.id || m.name || "").replace(/^models\//, "")).filter(Boolean);
  if (E.modelMatch) ids = ids.filter((id) => new RegExp(E.modelMatch, "i").test(id));
  if (E.modelExclude) ids = ids.filter((id) => !new RegExp(E.modelExclude, "i").test(id));
  ids = [...new Set(ids)].sort();

  let suggested = "";
  for (const p of E.prefer || []) {
    suggested = ids.find((id) => id.toLowerCase().includes(p));
    if (suggested) break;
  }
  // l'elenco resta salvato: serve alle tendine di «Modello per ogni compito»
  DS_EXT.storage.local.get({ dsModelLists: {} }).then((r) => DS_EXT.storage.local.set({ dsModelLists: { ...(r.dsModelLists || {}), [msg.engine]: ids } })).catch(() => {});
  return { models: ids, suggested: suggested || ids[0] || "" };
}

// ---------- Trascrizione dell'audio (Whisper) ----------
// Suggerimento per Whisper: le ultime frasi, al massimo 400 caratteri e 800 byte (Groq accetta al massimo 896 byte)
function whisperPrompt(text) {
  let t = String(text || "").slice(-400);
  const enc = new TextEncoder();
  while (t && enc.encode(t).length > 800) t = t.slice(Math.ceil(t.length / 10));
  return t;
}

async function transcribe(msg) {
  const local = msg.stt === "local";
  if (!local && !msg.key) throw new Error("manca la chiave Groq per la trascrizione");
  const base = (local ? msg.url || C.SYNC_DEFAULTS.sttUrl : "https://api.groq.com/openai/v1").trim().replace(/\/+$/, "");

  const bin = atob(msg.audio);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const type = msg.mime.split(";")[0];
  const ext = type.includes("wav") ? "wav" : type.includes("ogg") ? "ogg" : "webm";

  let model = msg.model || "whisper-large-v3-turbo";
  let withPrompt = true;
  const makeForm = (withWords) => {
    const fd = new FormData();
    fd.append("file", new Blob([bytes], { type }), msg.filename || "audio." + ext);
    fd.append("model", model);
    fd.append("response_format", "verbose_json");
    fd.append("temperature", "0");
    if (withWords) { fd.append("timestamp_granularities[]", "word"); fd.append("timestamp_granularities[]", "segment"); }
    if (msg.language) fd.append("language", msg.language);
    if (msg.prompt && withPrompt) fd.append("prompt", whisperPrompt(msg.prompt));
    return fd;
  };

  const headers = {};
  if (msg.key && !local) headers.Authorization = "Bearer " + msg.key.trim();
  if (!local) { await usageCheck("whisper", "Groq Whisper"); usageCount("whisper"); }
  let r;
  try {
    r = await fetch(base + "/audio/transcriptions", { method: "POST", headers, body: makeForm(true) });
    // Groq: «prompt length must be 896 characters or fewer» (conta i byte: in giapponese ogni carattere ne vale 3).
    // Il suggerimento è già accorciato (whisperPrompt); se non basta, riprovo senza
    if (r.status === 400 && /prompt/i.test(await r.clone().text().catch(() => ""))) { withPrompt = false; r = await fetch(base + "/audio/transcriptions", { method: "POST", headers, body: makeForm(true) }); }
    if (r.status === 400) r = await fetch(base + "/audio/transcriptions", { method: "POST", headers, body: makeForm(false) });
  } catch (e) {
    if (local) throw new Error(`Non riesco a collegarmi al server di trascrizione su ${base}: è avviato?`);
    throw e;
  }
  // server sul computer (Speaches, faster-whisper-server…) che non conosce il nome del modello (quello predefinito è di
  // Groq): leggo i suoi modelli Whisper, scelgo il migliore, riprovo e me lo ricordo nel popup
  if (local && (r.status === 404 || r.status === 400 || r.status === 422) && /model/i.test(await r.clone().text().catch(() => ""))) {
    const have = await sttLocalModels(base).catch(() => []);
    if (!have.length) throw Object.assign(new Error(`Il server di trascrizione su ${base} non ha nessun modello Whisper scaricato. Con Speaches: nel Prompt dei comandi scrivi  curl.exe -X POST ${base}/models/deepdml/faster-whisper-large-v3-turbo-ct2  (scarica Whisper turbo, circa 1,6 GB), poi riprova.`), { fatal: true });
    const pick = have.includes(model) ? model : sttBestModel(have);
    if (pick !== model) {
      model = pick;
      r = await fetch(base + "/audio/transcriptions", { method: "POST", headers, body: makeForm(true) });
      if (r.status === 400) r = await fetch(base + "/audio/transcriptions", { method: "POST", headers, body: makeForm(false) });
      if (r.ok) DS_EXT.storage.sync.set({ sttModel: pick }).catch(() => {});
    }
  }
  // Groq con un nome di modello che non ha (per esempio quello di Speaches rimasto dopo aver cambiato servizio):
  // torno al suo modello predefinito e me lo ricordo
  if (!local && (r.status === 404 || r.status === 400) && model !== "whisper-large-v3-turbo" && /model/i.test(await r.clone().text().catch(() => ""))) {
    model = "whisper-large-v3-turbo";
    r = await fetch(base + "/audio/transcriptions", { method: "POST", headers, body: makeForm(true) });
    if (r.status === 400) r = await fetch(base + "/audio/transcriptions", { method: "POST", headers, body: makeForm(false) });
    if (r.ok) DS_EXT.storage.sync.set({ sttModel: model }).catch(() => {});
  }
  if (r.status === 413) throw new Error("file troppo grande per un invio unico (413)");
  if (!r.ok) {
    const err = await httpError(r, local ? "Il server di trascrizione" : "Groq Whisper");
    if (local && /modello scelto non esiste/.test(err.message)) err.message = `Il server di trascrizione non ha il modello «${model}». Nel popup (📊 Consumo e modelli → Modello per ogni compito → Trascrizione dell'audio) premi ↻ e scegline uno.`;
    throw err;
  }
  const data = await r.json();
  let segments = (data.segments || []).map((s) => ({
    start: s.start || 0, end: s.end || 0, text: s.text || "",
    noSpeech: s.no_speech_prob || 0, logprob: s.avg_logprob == null ? 0 : s.avg_logprob, compression: s.compression_ratio || 0
  }));
  if (!segments.length && data.text) segments = [{ start: 0, end: data.duration || 0, text: data.text, noSpeech: 0, logprob: 0 }];
  const words = (data.words || []).map((w) => ({ w: w.word || "", s: w.start || 0, e: w.end || 0 }));
  return { segments, words, language: data.language || "" };
}

// I modelli Whisper del server sul computer (GET /models, formato OpenAI: { data: [{ id }] }); niente voci (tts)
async function sttLocalModels(base) {
  const r = await fetch(base.replace(/\/+$/, "") + "/models");
  if (!r.ok) throw new Error("il server di trascrizione ha risposto " + r.status);
  const j = await r.json();
  const ids = (j.data || j.models || []).map((m) => (typeof m === "string" ? m : m.id || m.name || "")).filter(Boolean);
  return ids.filter((id) => /whisper|distil|parakeet|canary/i.test(id) && !/tts|kokoro|piper/i.test(id));
}
// il più adatto: turbo (veloce e buono), poi large-v3, poi large, poi il primo
function sttBestModel(ids) {
  return ids.find((x) => /turbo/i.test(x)) || ids.find((x) => /large-v3/i.test(x)) || ids.find((x) => /large/i.test(x)) || ids.find((x) => /medium/i.test(x)) || ids[0];
}
async function sttModels(msg) {
  const base = String(msg.url || C.SYNC_DEFAULTS.sttUrl).trim().replace(/\/+$/, "");
  let ids;
  try { ids = await sttLocalModels(base); } catch (e) { throw new Error(`Non riesco a leggere i modelli del server di trascrizione su ${base}: è avviato? (${e.message || e})`); }
  // l'elenco resta salvato per la tendina «Trascrizione dell'audio» di «Modello per ogni compito»
  DS_EXT.storage.local.get({ dsModelLists: {} }).then((r) => DS_EXT.storage.local.set({ dsModelLists: { ...(r.dsModelLists || {}), whisperLocal: ids } })).catch(() => {});
  return { models: ids, suggested: ids.length ? sttBestModel(ids) : "" };
}

// ---------- Pronuncia con la voce online di Google ----------
function ttsCode(l) {
  const low = String(l || "en").replace(/_/g, "-").toLowerCase();
  if (low.startsWith("zh")) return /hant|tw|hk/.test(low) ? "zh-TW" : "zh-CN";
  if (low === "pt-br") return "pt-BR";
  if (low === "iw") return "he";
  return low.split("-")[0] || "en";
}

function bytesToB64(bytes) {
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

// ---------- Anki: invio diretto con il componente aggiuntivo AnkiConnect (Anki deve essere aperto) ----------
// Condiviso con Parole al Volo: le due estensioni usano gli stessi mazzi per lingua ("Lingue::Inglese"…).
async function ankiCall(action, params = {}) {
  let r;
  try {
    r = await fetch("http://127.0.0.1:8765", { method: "POST", body: JSON.stringify({ action, version: 6, params }) });
  } catch {
    throw new Error("Anki non risponde: apri Anki e installa il componente aggiuntivo AnkiConnect (codice 2055492159), poi riavvia Anki.");
  }
  if (!r.ok) throw new Error("Anki ha risposto con un errore (" + r.status + "). Controlla AnkiConnect.");
  const j = await r.json();
  if (j && j.error) throw new Error(String(j.error));
  return j ? j.result : null;
}
// La prima volta Anki chiede (in una finestra sua) se permettere l'accesso a questa estensione
async function ankiPermission() {
  const p = await ankiCall("requestPermission");
  if (!p || p.permission !== "granted") throw new Error("Anki non ha dato il permesso: nella finestra di Anki premi \"Yes\" (Sì), poi riprova.");
}
// Tipo di nota con due campi (Base/Basic) e i nomi dei suoi campi (dipendono dalla lingua di Anki)
// 1.6.4: un tipo di nota nostro («Sottotitoli Doppi», campi Fronte e Retro) con un template pulito: «Base» o i tipi dell'utente
// a volte mostrano il retro con {{text:Retro}} o con un CSS monospace e l'impaginazione della carta si perdeva
const DS_ANKI_MODEL = "Sottotitoli Doppi";
async function ankiOwnModel(models) {
  if (!models.includes(DS_ANKI_MODEL)) {
    await ankiCall("createModel", {
      modelName: DS_ANKI_MODEL, inOrderFields: ["Fronte", "Retro"],
      css: ".card { font-family: 'Segoe UI', system-ui, -apple-system, Roboto, Arial, sans-serif; font-size: 20px; line-height: 1.4; text-align: center; }\n.card img { max-width: 92%; }\nhr#answer { border: 0; border-top: 1px solid rgba(128,128,128,.4); margin: 14px 18px; }\na { text-decoration: none; }",
      cardTemplates: [{ Name: "Carta 1", Front: "{{Fronte}}", Back: "{{FrontSide}}\n\n<hr id=answer>\n\n{{Retro}}" }]
    });
  }
  return { model: DS_ANKI_MODEL, fields: ["Fronte", "Retro"] };
}
// scrive fronte e retro di una carta; se è di un altro tipo la porta nel nostro (updateNoteModel), altrimenti solo i campi
async function ankiWrite(id, curModel, curNames, front, back, tags, ours) {
  if (ours && curModel !== ours.model) {
    try {
      await ankiCall("updateNoteModel", { note: { id, modelName: ours.model, fields: { [ours.fields[0]]: front, [ours.fields[1]]: back }, tags: tags || [] } });
      return ours.model;
    } catch {}
  }
  await ankiCall("updateNoteFields", { note: { id, fields: { [curNames[0]]: front, [curNames[1]]: back } } });
  return curModel;
}
async function ankiModel(want) {
  const models = (await ankiCall("modelNames")) || [];
  if (!want) { try { return await ankiOwnModel(models); } catch {} }
  const pref = [want, "Basic", "Base", "Básico", "Einfach", "Basique", "Basis", "Podstawowy", "Základní", "Базовый", "基本"].filter(Boolean);
  let model = pref.find((m) => models.includes(m));
  let fields = model ? await ankiCall("modelFieldNames", { modelName: model }) : null;
  if (!model || !fields || fields.length < 2) {
    for (const m of models) {
      const f = await ankiCall("modelFieldNames", { modelName: m });
      if (f && f.length === 2) { model = m; fields = f; break; }
    }
  }
  if (!model || !fields || fields.length < 2) throw new Error("In Anki non trovo un tipo di nota con fronte e retro (Base).");
  return { model, fields };
}
// impostazioni del mazzo di questa estensione (defDeck: il mazzo unico se non si divide per lingua)
async function ankiOpts(defDeck) {
  const s = await DS_EXT.storage.sync.get({ ankiDeck: defDeck, ankiPerLang: true, ankiLangDeck: "Lingue::{lingua}", ankiModel: "", ankiAudio: true, ankiCharDeck: true });
  return { deck: s.ankiDeck || defDeck, perLang: s.ankiPerLang !== false, tpl: s.ankiLangDeck, model: s.ankiModel, audio: s.ankiAudio !== false, charDeck: s.ankiCharDeck !== false };
}
async function ankiCheck(msg = {}) {
  const version = await ankiCall("version");
  await ankiPermission();
  const decks = (await ankiCall("deckNames")) || [];
  const o = await ankiOpts(msg.defDeck || "Sottotitoli Doppi");
  const m = await ankiModel(msg.model || o.model);
  return { version, decks, model: m.model, example: dsAnkiDeckFor(msg.lang || "en", o) };
}
// 1.6.2: la pronuncia sulla carta: la registrazione di un madrelingua (rec: indirizzi trovati dalla scheda), altrimenti
// la voce sintetica di Google. → { data, ext, how: "rec" | "tts" } oppure null
async function ankiAudioFor(n) {
  for (const url of (n.rec || []).slice(0, 3)) {
    try {
      const a = await fetchB64({ url: /^\/\//.test(url) ? "https:" + url : url });
      if (!a.b64) continue;
      const ext = /mpeg|mp3/.test(a.type) ? "mp3" : /wav/.test(a.type) ? "wav" : /ogg|opus/.test(a.type) ? "ogg"
        : ((String(url).match(/\.(mp3|ogg|oga|opus|wav|m4a)(?:$|[?#])/i) || [, "ogg"])[1].toLowerCase());
      return { data: a.b64, ext, how: "rec" };
    } catch {}
  }
  const text = String(n.word || "").trim();
  if (!text) return null;
  // 1.7.21: prima la voce che hai scelto per quella lingua (Piper, Speaches, Azure), poi Google (non ha tutte le lingue: per esempio
  // lo sloveno), poi una voce Piper già scaricata per la lingua o Azure, se acceso. Se nessuna va, { fail } dice cosa è successo a ognuna.
  const lg = String(n.lang || "").split("-")[0].toLowerCase();
  const s = await DS_EXT.storage.sync.get({ ttsVoices: {}, ttsVoice: "", sttUrl: "", azureTts: false }).catch(() => ({ ttsVoices: {} }));
  let choice = (s.ttsVoices || {})[lg] || "";
  // la voce scelta nel menu «Voce» del popup (una sola, per la lingua parlata) vale per la sua lingua: la voce Piper/Speaches/Azure
  // scelta lì (per esempio la voce slovena di Speaches) è quella da usare anche per le carte di Anki
  if (!choice && s.ttsVoice) {
    const g = String(s.ttsVoice);
    const fam = /^(piper|speaches):/.test(g) ? g.replace(/^[a-z]+:/, "").split("_")[0].toLowerCase() : /^azure:/.test(g) ? g.slice(6).split("-")[0].toLowerCase() : "";
    if (fam && fam === lg) choice = g;
  }
  const why = [];
  const msgOf = (err) => String((err && err.message) || err).slice(0, 90);
  const piper = async (key) => ({ data: (await piperCall({ op: "speak", key, text, rate: 0.9 })).audio, ext: "wav", how: "tts" });
  if (/^piper:/.test(choice)) { try { return await piper(choice.slice(6)); } catch (err) { why.push("voce Piper scelta: " + msgOf(err)); } }
  else if (/^speaches:/.test(choice)) { try { return { data: (await speachesTts({ op: "speak", key: choice.slice(9), text, rate: 0.9, url: s.sttUrl || undefined })).audio, ext: "wav", how: "tts" }; } catch (err) { why.push("voce Speaches scelta: " + msgOf(err)); } }
  else if (/^azure:/.test(choice)) { try { return { data: (await azureTts({ text, lang: n.lang, voice: choice.slice(6) })).audio, ext: "mp3", how: "tts" }; } catch (err) { why.push("voce Azure scelta: " + msgOf(err)); } }
  else if (choice && choice !== "google") why.push("la voce scelta è una voce del computer: Anki non può usarla, serve Piper, Speaches o Azure");
  try { const t = await tts({ text, lang: n.lang }); return { data: t.audio, ext: "mp3", how: "tts" }; } catch (err) { why.push("Google (" + (lg || "?") + "): " + msgOf(err)); }
  try {
    const list = ((await piperCall({ op: "voices" })).voices || []).filter((v) => v.have && String(v.family || "").split("-")[0].toLowerCase() === lg).sort((a, c) => (c.dl || 0) - (a.dl || 0));
    if (!list.length) why.push("nessuna voce Piper scaricata per «" + (lg || "?") + "»");
    for (const v of list.slice(0, 2)) { try { return await piper(v.key); } catch (err) { why.push("Piper " + v.key + ": " + msgOf(err)); } }
  } catch (err) { why.push("Piper: " + msgOf(err)); }
  if (s.azureTts) { try { return { data: (await azureTts({ text, lang: n.lang })).audio, ext: "mp3", how: "tts" }; } catch (err) { why.push("Azure: " + msgOf(err)); } }
  return { fail: why.join(" · ") };
}
// 1.6.3: i file (pronuncia, immagine) li metto io in Anki (storeMediaFile) e scrivo io i riferimenti nel punto giusto della
// carta: prima AnkiConnect li attaccava in fondo al fronte, senza a capo, e la carta usciva disordinata
const ankiSafe = (w) => String(w || "x").replace(/[^\p{L}\p{N}_-]+/gu, "_").slice(0, 40);
async function ankiStore(filename, data) {
  const r = await ankiCall("storeMediaFile", { filename, data });
  return typeof r === "string" && r ? r : filename;
}
// → { snd, img, how: "rec"|"tts"|"", imgNote }
async function ankiMedia(e, prefix, want) {
  const out = { snd: "", img: "", how: "", imgNote: "", imgFailed: false, audioNote: "" };
  const tag = (prefix || "ds") + "-" + ankiSafe(e.word) + "-";
  if (want.audio && e.word) {
    // 1.7.20: anche le frasi e i modi di dire («testo»), se corti (Google legge al massimo ~190 caratteri); il motivo se manca resta in audioNote
    if (e.kind === "text" && String(e.word).length > 190) out.audioNote = "testo troppo lungo per la voce";
    else {
      const au = await ankiAudioFor({ rec: e.rec, word: e.word, lang: e.lang });
      if (!au || au.fail) out.audioNote = au && au.fail ? au.fail : "nessuna voce disponibile";
      else {
        try { out.snd = await ankiStore(tag + (au.how === "rec" ? "rec" : "tts") + "-" + Date.now() % 1e6 + "." + au.ext, au.data); out.how = au.how; }
        catch (err) { out.audioNote = "Anki non ha accettato il file: " + String((err && err.message) || err).slice(0, 80); }
      }
    }
  }
  if (want.image && e.image && /^https:\/\//.test(e.image)) {
    try { const im = await imageForAnki(e.image); out.img = await ankiStore(tag + "img-" + Date.now() % 1e6 + "." + im.ext, im.data); }
    catch (err) {
      // non sono riuscito a scaricarla io: provo a farla scaricare ad Anki
      try {
        const ext = (e.image.match(/\.(jpe?g|png|webp|gif)(?:$|[?#])/i) || [, "jpg"])[1].toLowerCase();
        const name = tag + "img-" + Date.now() % 1e6 + "." + ext;
        out.img = await ankiCall("storeMediaFile", { filename: name, url: e.image }) || name;
        out.imgNote = String(err.message || err);
      } catch (e2) { out.imgFailed = true; out.imgNote = String(e2.message || e2); }
    }
  }
  return out;
}
// le carte nostre già in Anki (etichetta sottotitoli-doppi o parole-al-volo): [{ id, model, tags, names, front, back }]
async function ankiOurNotes() {
  const ids = (await ankiCall("findNotes", { query: "tag:sottotitoli-doppi or tag:parole-al-volo" })) || [];
  const out = [];
  for (let i = 0; i < ids.length; i += 150) {
    const info = (await ankiCall("notesInfo", { notes: ids.slice(i, i + 150) })) || [];
    for (const n of info) {
      if (!n || !n.fields) continue;
      const f = Object.entries(n.fields).sort((a, b) => (a[1].order || 0) - (b[1].order || 0));
      if (f.length < 2) continue;
      out.push({ id: n.noteId, model: n.modelName, tags: n.tags || [], names: [f[0][0], f[1][0]], front: f[0][1].value || "", back: f[1][1].value || "", cards: n.cards || [] });
    }
  }
  return out;
}
const ankiKey = (lang, word) => String(lang || "").split("-")[0].toLowerCase() + "|" + String(word || "").toLowerCase().replace(/\s+/g, " ").trim();
async function ankiList() {
  await ankiPermission();
  return { notes: await ankiOurNotes() };
}
// entries: voci del vocabolario → carte. Una carta già in Anki (stessa lingua e parola) si aggiorna se update è acceso
// («Rimanda ad Anki»), altrimenti è «già c'era». Un errore su una carta non ferma le altre: finisce in errors.
async function ankiPush(entries, defDeck, prefix, fieldsFn, update) {
  await ankiPermission();
  const o = await ankiOpts(defDeck);
  const m = await ankiModel(o.model);
  const s2 = await DS_EXT.storage.sync.get({ ankiImage: false });
  const made = new Set();
  const ids = [], decks = [], errors = [];
  let dup = 0, upd = 0, noImg = 0, rec = 0, synth = 0, noImgWhy = "";
  let index = null;
  for (const e of entries) {
    try {
      const deck = dsAnkiDeckOf(e, o);   // 1.7.7: un carattere da solo (kanji, hanzi, hanja) va nel sottomazzo dei caratteri
      if (!made.has(deck)) { await ankiCall("createDeck", { deck }); made.add(deck); }
      decks.push(deck);
      if (!index) { index = new Map(); for (const n of await ankiOurNotes()) index.set(ankiKey(n.tags.find((t) => !/^(sottotitoli-doppi|parole-al-volo)$/.test(t)), dsAnkiParse(n.front, "", n.tags).word), n); }
      const old = index.get(ankiKey(e.lang, e.word));
      if (old && !update) { dup++; ids.push("dup"); continue; }
      const md = await ankiMedia(e, prefix, { audio: o.audio, image: !!(e.image || s2.ankiImage) && !!e.image });
      if (md.imgFailed) noImg++;
      if (md.imgNote) noImgWhy = md.imgNote;
      const keep = old ? dsAnkiParse(old.front, "", old.tags).keep.filter((x) => !(md.snd && /^\[sound:/.test(x)) && !(md.img && /^<img/i.test(x))) : [];
      const f = fieldsFn(e, { snd: md.snd, img: md.img, keep });
      if (old) {
        await ankiWrite(old.id, old.model, old.names, f.front, f.back, f.tags, m.model === DS_ANKI_MODEL ? m : null);
        await ankiEnsureDeck(old.cards, deck);
        upd++; ids.push(old.id);
      } else {
        const note = { deckName: deck, modelName: m.model, fields: { [m.fields[0]]: f.front, [m.fields[1]]: f.back }, tags: f.tags || [], options: { allowDuplicate: false } };
        try { ids.push(await ankiCall("addNote", { note })); }
        catch (err) { if (/duplicate/i.test(err.message)) { dup++; ids.push("dup"); continue; } throw err; }
      }
      if (md.how === "rec") rec++; else if (md.how === "tts") synth++;
    } catch (err) {
      errors.push({ word: e.word, error: String((err && err.message) || err).slice(0, 160) });
      ids.push(null);
    }
  }
  if (errors.length === entries.length && entries.length) throw new Error(errors[0].error);
  return { ids, dup, upd, decks, deck: [...made].join(", "), noImg, rec, synth, errors,
    imgNote: noImg ? "senza immagine: Anki non l'ha accettata" + (noImgWhy ? " (" + noImgWhy + ")" : "") : "" };
}
// 1.7.7: le carte (card id) di una nota nel mazzo giusto; restituisce [{card, deck}] di quelle spostate (per annullare)
async function ankiEnsureDeck(cards, deck) {
  if (!cards || !cards.length) return [];
  await ankiCall("createDeck", { deck });
  const info = (await ankiCall("cardsInfo", { cards })) || [];
  const wrong = info.filter((c) => c && c.deckName !== deck);
  if (!wrong.length) return [];
  await ankiCall("changeDeck", { cards: wrong.map((c) => c.cardId), deck });
  return wrong.map((c) => ({ card: c.cardId, deck: c.deckName }));
}
// «📦 Sposta i caratteri nel sottomazzo»: le carte nostre che sono UN SOLO carattere cinese (kanji, hanzi, hanja) vanno nel sottomazzo dei
// caratteri della loro lingua. msg.dry = solo contare. Si ricorda dove stavano (annullabile).
async function ankiMoveChars(msg = {}) {
  await ankiPermission();
  const o = await ankiOpts("Sottotitoli Doppi");
  const notes = await ankiOurNotes();
  const todo = [];
  for (const n of notes) {
    const lang = n.tags.find((t) => !/^(sottotitoli-doppi|parole-al-volo)$/.test(t)) || "";
    const word = dsAnkiParse(n.front, "", n.tags).word;
    if (dsIsHanChar(word)) todo.push({ n, deck: dsAnkiCharDeck(lang, o) });
  }
  const moved = [];
  let already = 0;
  if (!msg.dry) {
    for (const t of todo) {
      const m = await ankiEnsureDeck(t.n.cards, t.deck);
      if (m.length) moved.push(...m); else already++;
    }
    if (moved.length) await DS_EXT.storage.local.set({ ankiMoveUndo: moved });
  }
  const decks = [...new Set(todo.map((t) => t.deck))];
  return { found: todo.length, moved: moved.length, already, decks, dry: !!msg.dry };
}
async function ankiMoveUndo() {
  await ankiPermission();
  const { ankiMoveUndo: list = [] } = await DS_EXT.storage.local.get({ ankiMoveUndo: [] });
  const by = {};
  for (const x of list) (by[x.deck] = by[x.deck] || []).push(x.card);
  for (const [deck, cards] of Object.entries(by)) { await ankiCall("createDeck", { deck }); await ankiCall("changeDeck", { cards, deck }); }
  await DS_EXT.storage.local.remove("ankiMoveUndo");
  return { restored: list.length };
}
// Sottotitoli Doppi: voci del vocabolario → carte
async function ankiAdd(msg) {
  return ankiPush(msg.entries || [], "Sottotitoli Doppi", "sd", dsAnkiFields, !!msg.update);
}
// 1.6.3: una carta già in Anki rifatta con i dati dell'entry (impaginazione di dsAnkiFields), con pronuncia e immagine nuove
// se richieste. msg = { id, names: [fronte, retro], entry, keep: [file già sulla carta], audio: bool, image: bool }
async function ankiUpdate(msg) {
  await ankiPermission();
  const e = msg.entry || {};
  const md = await ankiMedia(e, "sd", { audio: !!msg.audio, image: !!msg.image });
  const keep = (msg.keep || []).filter((x) => !(md.snd && /^\[sound:/.test(x)) && !(md.img && /^<img/i.test(x)));
  const f = dsAnkiFields(e, { snd: md.snd, img: md.img, keep }, msg.tag);
  const o = await ankiOpts("Sottotitoli Doppi");
  const ours = o.model ? null : await ankiModel("");
  await ankiWrite(msg.id, msg.model, msg.names, f.front, f.back, f.tags, ours && ours.model === DS_ANKI_MODEL ? ours : null);
  // 1.7.7: un carattere da solo (kanji, hanzi, hanja) passa anche nel suo sottomazzo
  let moved = 0;
  if (msg.cards && msg.cards.length && dsIsHanChar(e.word)) moved = (await ankiEnsureDeck(msg.cards, dsAnkiCharDeck(e.lang, o))).length;
  return { ok: true, front: f.front, back: f.back, how: md.how, audioNote: md.audioNote, imgNote: md.imgNote, moved };
}
// «Annulla l'ultimo aggiornamento»: rimette com'erano fronte e retro
async function ankiRestore(msg) {
  await ankiPermission();
  let n = 0;
  for (const it of msg.items || []) {
    try {
      let done = false;
      if (it.model) { try { const cur = await ankiCall("notesInfo", { notes: [it.id] }); if (cur[0] && cur[0].modelName !== it.model) { await ankiCall("updateNoteModel", { note: { id: it.id, modelName: it.model, fields: { [it.names[0]]: it.front, [it.names[1]]: it.back }, tags: it.tags || [] } }); done = true; } } catch {} }
      if (!done) await ankiCall("updateNoteFields", { note: { id: it.id, fields: { [it.names[0]]: it.front, [it.names[1]]: it.back } } });
      n++;
    } catch {}
  }
  return { restored: n };
}

// ---------- Voci naturali di Microsoft (Azure Speech, con la tua chiave; piano gratuito 500.000 caratteri al mese) ----------
async function azureCfg() {
  const l = await DS_EXT.storage.local.get({ keys: {} });
  const s = await DS_EXT.storage.sync.get({ azureRegion: "westeurope" });
  const key = String((l.keys || {}).azureSpeech || "").trim();
  const region = String(s.azureRegion || "westeurope").trim().toLowerCase().replace(/\s+/g, "");
  if (!key) throw new Error("manca la chiave di Azure Speech (popup → Voci)");
  return { key, region };
}
let azureList = null;
async function azureVoices(msg = {}) {
  const cfg = await azureCfg();
  if (!msg.fresh && azureList && azureList.region === cfg.region && azureList.key === cfg.key) return { list: azureList.list };
  if (!msg.fresh) {
    const st = (await DS_EXT.storage.local.get({ azureVoiceList: null })).azureVoiceList;
    if (st && st.region === cfg.region && Date.now() - st.at < 7 * 86400e3 && st.list && st.list.length) { azureList = { ...st, key: cfg.key }; return { list: st.list }; }
  }
  const r = await fetch(`https://${cfg.region}.tts.speech.microsoft.com/cognitiveservices/voices/list`, { headers: { "Ocp-Apim-Subscription-Key": cfg.key } });
  if (!r.ok) throw await httpError(r, "Azure Speech");
  const j = await r.json();
  const list = (Array.isArray(j) ? j : []).filter((v) => v && v.ShortName && v.Locale)
    .map((v) => ({ name: v.ShortName, locale: v.Locale, label: v.LocalName || v.DisplayName || v.ShortName, gender: v.Gender === "Female" ? "donna" : v.Gender === "Male" ? "uomo" : "", neural: /neural/i.test(v.VoiceType || v.ShortName), multi: /multilingual/i.test(v.ShortName) }));
  azureList = { region: cfg.region, key: cfg.key, at: Date.now(), list };
  await DS_EXT.storage.local.set({ azureVoiceList: { region: cfg.region, at: Date.now(), list } }).catch(() => {});
  return { list };
}
function azurePick(list, lang) {
  const full = String(lang || "").toLowerCase().replace(/_/g, "-");
  const b = full.split("-")[0];
  const same = list.filter((v) => v.locale.toLowerCase().split("-")[0] === b);
  if (!same.length) return null;
  const score = (v) => (v.locale.toLowerCase() === full ? 4 : 0) + (v.neural ? 2 : 0) + (v.multi ? -1 : 0);
  return same.sort((x, y) => score(y) - score(x))[0];
}
const azureAudio = new Map();   // le ultime pronunce, per non ripagarle
async function azureTts(msg) {
  const cfg = await azureCfg();
  const text = String(msg.text || "").slice(0, 600);
  let voice = String(msg.voice || ""), locale = "";
  if (!voice) {
    const v = azurePick((await azureVoices()).list, msg.lang);
    if (!v) throw new Error("Azure non ha voci per questa lingua");
    voice = v.name; locale = v.locale;
  }
  locale = locale || voice.split("-").slice(0, 2).join("-");
  const k = voice + "|" + text;
  if (azureAudio.has(k)) return { audio: azureAudio.get(k), voice };
  const esc = (x) => x.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const ssml = `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="${locale}"><voice name="${voice}">${esc(text)}</voice></speak>`;
  const r = await fetch(`https://${cfg.region}.tts.speech.microsoft.com/cognitiveservices/v1`, {
    method: "POST",
    headers: { "Ocp-Apim-Subscription-Key": cfg.key, "Content-Type": "application/ssml+xml", "X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3" },
    body: ssml
  });
  if (!r.ok) throw await httpError(r, "Azure Speech");
  const audio = bytesToB64(new Uint8Array(await r.arrayBuffer()));
  azureAudio.set(k, audio);
  while (azureAudio.size > 150) azureAudio.delete(azureAudio.keys().next().value);
  return { audio, voice };
}

async function tts(msg) {
  const q = encodeURIComponent(String(msg.text || "").slice(0, 190));
  const tl = encodeURIComponent(ttsCode(msg.lang));
  const urls = [
    `https://translate.googleapis.com/translate_tts?client=gtx&ie=UTF-8&tl=${tl}&q=${q}`,
    `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${tl}&q=${q}`
  ];
  let last = "";
  for (const url of urls) {
    try {
      const r = await fetch(url);
      if (!r.ok) { last = "HTTP " + r.status; continue; }
      const bytes = new Uint8Array(await r.arrayBuffer());
      if (bytes.length < 200) { last = "risposta vuota"; continue; }
      return { audio: bytesToB64(bytes) };
    } catch (e) {
      last = String(e.message || e);
    }
  }
  throw new Error("pronuncia di Google non disponibile (" + last + ")");
}

// ---------- 1.7.0: voci Piper (gratuite, sul computer) ----------
// La sintesi gira in una pagina nascosta dell'estensione (piper/piper.html, con onnxruntime-web e espeak-ng in WebAssembly):
// Chrome la apre come «offscreen document», Firefox come iframe nella pagina di sottofondo. Il sottofondo le passa le richieste.
let piperFrame = null, piperRpcId = 0;
// Chrome: messaggi dell'estensione verso la pagina offscreen. Firefox: postMessage verso l'iframe nascosto.
function piperSend(msg, ms) {
  if (piperFrame && piperFrame.contentWindow) {
    return new Promise((resolve) => {
      const id = ++piperRpcId;
      const on = (ev) => { if (ev.data && ev.data.target === "piper-reply" && ev.data.id === id) { clearTimeout(t); removeEventListener("message", on); resolve(ev.data.res); } };
      const t = setTimeout(() => { removeEventListener("message", on); resolve(null); }, ms || 600000);
      addEventListener("message", on);
      try { piperFrame.contentWindow.postMessage({ ...msg, target: "piper-host", id }, DS_EXT.runtime.getURL("").replace(/\/$/, "")); } catch { clearTimeout(t); removeEventListener("message", on); resolve(null); }
    });
  }
  return Promise.race([DS_EXT.runtime.sendMessage({ ...msg, target: "piper-host" }).catch(() => null), ...(ms ? [new Promise((r) => setTimeout(() => r(null), ms))] : [])]);
}
const piperPing = () => piperSend({ op: "ping" }, 700);
async function piperEnsure() {
  { const p = await piperPing(); if (p && p.ok) return; }
  if (typeof chrome !== "undefined" && chrome.offscreen && chrome.offscreen.createDocument) {
    try { await chrome.offscreen.createDocument({ url: "piper/piper.html", reasons: ["WORKERS"], justification: "Voci Piper: sintesi vocale sul computer (WebAssembly)" }); }
    catch (e) { if (!/single|already|exist/i.test(String(e && e.message))) throw e; }
  } else if (typeof document !== "undefined" && document.body) {
    if (piperFrame) piperFrame.remove();
    piperFrame = document.createElement("iframe");
    piperFrame.id = "piperHost"; piperFrame.style.display = "none"; piperFrame.src = DS_EXT.runtime.getURL("piper/piper.html");
    document.body.append(piperFrame);
  } else throw new Error("questo browser non può far girare le voci Piper");
  for (let i = 0; i < 60; i++) {
    const p = await piperPing();
    if (p && p.ok) return;
    await new Promise((r) => setTimeout(r, 150));
  }
  throw new Error("la pagina delle voci Piper non si avvia");
}
async function piperCall(msg) {
  await piperEnsure();
  // (una pagina offscreen non ha chrome.storage: l'indirizzo dell'archivio delle voci glielo passo io)
  const st = await DS_EXT.storage.local.get({ piperBase: "", piperPopUrl: "" }).catch(() => ({}));
  const r = await piperSend({ op: msg.op, key: msg.key, text: msg.text, rate: msg.rate, speaker: msg.speaker, base: st.piperBase || "", popUrl: st.piperPopUrl || "" });
  if (!r) throw new Error("la pagina delle voci Piper non ha risposto");
  if (r.error) throw new Error(r.error);
  return r;
}
// voci Piper del server Speaches (lo stesso della trascrizione sul computer): /audio/speech, /models
const speachesVoiceOk = new Map();   // voce Piper → il valore di «voice» che il server ha accettato
async function speachesTts(msg) {
  const base = String(msg.url || C.SYNC_DEFAULTS.sttUrl).trim().replace(/\/+$/, "");
  const id = (k) => "speaches-ai/piper-" + k;
  try {
    if (msg.op === "list") {
      const r = await fetch(base + "/models");
      if (!r.ok) throw new Error("il server ha risposto " + r.status);
      const j = await r.json();
      const ids = (j.data || j.models || []).map((m) => (typeof m === "string" ? m : m.id || m.name || "")).filter((x) => /piper/i.test(x));
      return { installed: ids.map((x) => x.replace(/^.*piper-/i, "")) };
    }
    if (msg.op === "install") {
      const r = await fetch(base + "/models/" + id(msg.key), { method: "POST" });
      if (!r.ok) {
        const t = (await r.text().catch(() => "")).slice(0, 160);
        if (r.status === 404) throw new Error("questa voce non esiste tra i pacchetti Piper di Speaches (speaches-ai): non si può installare sul server. Se c'è, usa la stessa voce tra «Voci Piper gratuite (sul computer)». Risposta del server: " + t);
        throw new Error("il server ha risposto " + r.status + " " + t);
      }
      return { ok: true };
    }
    // il server vuole sempre il campo «voice» (422 «Field required»). Per una voce Piper di solito è il nome della voce
    // (it_IT-riccardo-x_low → «riccardo»); se non lo accetta provo «default» e poi quelle che il server dichiara per quel modello
    const namePart = String(msg.key || "").split("-").slice(1, -1).join("-");
    const tryVoices = [speachesVoiceOk.get(msg.key), namePart, "default", "0"].filter((v, i, a) => v && a.indexOf(v) === i);
    let modelVoices = null, last = null;
    for (let i = 0; i < tryVoices.length + 1; i++) {
      let voice = tryVoices[i];
      if (voice === undefined) {   // finite le ipotesi: chiedo al server quali voci ha questo modello
        if (modelVoices) break;
        try {
          const mr = await fetch(base + "/models/" + id(msg.key));
          const mj = mr.ok ? await mr.json() : {};
          modelVoices = (Array.isArray(mj.voices) ? mj.voices : []).map((x) => (typeof x === "string" ? x : x && (x.voice_id || x.id || x.name))).filter(Boolean);
        } catch { modelVoices = []; }
        tryVoices.push(...modelVoices.filter((v) => !tryVoices.includes(v)));
        voice = tryVoices[i];
        if (voice === undefined) break;
      }
      const body = { model: id(msg.key), input: String(msg.text || "").slice(0, 1500), voice, response_format: "wav", speed: Math.max(0.5, Math.min(2, (msg.rate || 0.9) / 0.9)) };
      const r = await fetch(base + "/audio/speech", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      if (r.ok) { speachesVoiceOk.set(msg.key, voice); return { audio: bytesToB64(new Uint8Array(await r.arrayBuffer())) }; }
      const t = (await r.text().catch(() => "")).slice(0, 300);
      last = { status: r.status, text: t };
      if (/model/i.test(t) && (r.status === 404 || /not found|not.*installed|download/i.test(t)) && !/voice/i.test(t)) throw new Error("la voce non è installata sul server (popup ▸ Voce ▸ Installa sul server)");
      if (!(r.status === 400 || r.status === 404 || r.status === 422 || r.status === 500)) break;
    }
    throw new Error("il server ha risposto " + (last ? last.status + " " + last.text : "senza voce valida") + " — provate le voci: " + tryVoices.join(", "));
  } catch (e) {
    if (e instanceof TypeError) throw new Error(`non riesco a collegarmi al server su ${base}: è avviato?`);
    throw e;
  }
}

// ---------- Aggiornamento: da questa versione Gemini usa Flash-Lite ----------
async function dsMigrate() {
  const l = await DS_EXT.storage.local.get({ keys: {}, migrated: {} });
  if (l.migrated.flashLite) return;
  const s = await DS_EXT.storage.sync.get({ models: {} });
  const update = { models: { ...(s.models || {}), gemini: "gemini-flash-lite-latest" } };
  if (l.keys && l.keys.gemini) update.engine = "gemini"; // se hai già una chiave Gemini, la uso per tradurre
  await DS_EXT.storage.sync.set(update);
  await DS_EXT.storage.local.set({ migrated: { ...l.migrated, flashLite: true } });
}
async function dsCleanLiveStream() {
  const all = await DS_EXT.storage.local.get(null);
  const bad = Object.keys(all).filter((k) => /^(live:|livetr:)live_stream/.test(k));
  if (bad.length) await DS_EXT.storage.local.remove(bad);
}
// 1.6.0: «Consumo» bilanciato all'aggiornamento (diretta 45 s indietro, correzione solo delle frasi incerte, Gemini
// Flash-Lite per tradurre e Flash per spiegare), una volta sola; poi lo cambi dal popup
async function dsMigrateConsumo() {
  const l = await DS_EXT.storage.local.get({ migrated: {} });
  if (l.migrated.consumo16) return;
  const s = await DS_EXT.storage.sync.get({ taskModels: {} });
  await DS_EXT.storage.sync.set(dsConsumoValues("balanced", s.taskModels));
  await DS_EXT.storage.local.set({ migrated: { ...l.migrated, consumo16: true } });
}
chrome.runtime.onInstalled.addListener((d) => {
  // (installazione nuova: i valori predefiniti sono già quelli bilanciati)
  dsMigrate().catch(() => {}).then(() => (d && d.reason === "update" ? dsMigrateConsumo() : null)).catch(() => {});
  dsCleanLiveStream().catch(() => {});
});

// ---------- Programma di appoggio (yt-dlp) e download dei file interi ----------
const HELPER = "com.sottotitolidoppi.helper";

function helperPing() {
  return new Promise((resolve) => {
    let port;
    const done = (r) => { try { port && port.disconnect(); } catch {} resolve(r); };
    try { port = chrome.runtime.connectNative(HELPER); } catch (e) { return resolve({ installed: false, error: String(e.message || e) }); }
    const timer = setTimeout(() => done({ installed: false, error: "il programma non risponde" }), 15000);
    port.onMessage.addListener((m) => { if (m && m.type === "pong") { clearTimeout(timer); done({ installed: true, ...m }); } });
    port.onDisconnect.addListener(() => {
      clearTimeout(timer);
      const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : "";
      resolve({ installed: false, error: err || "il programma si è chiuso" });
    });
    port.postMessage({ cmd: "ping" });
  });
}

// La pagina del video chiede l'audio intero: dal file diretto se c'è, altrimenti con yt-dlp.
// I dati tornano alla pagina a pezzi, sulla stessa porta.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "sd-full") return;
  let native = null, closed = false;
  port.onDisconnect.addListener(() => { closed = true; try { native && native.disconnect(); } catch {} });
  const post = (m) => { if (!closed) try { port.postMessage(m); } catch {} };

  port.onMessage.addListener(async (req) => {
    // 1) File diretto (mp4, mp3…): lo scarico io, senza programma di appoggio
    if (req.src && /^https?:/.test(req.src)) {
      try {
        post({ type: "status", text: "Scarico il file…" });
        const r = await fetch(req.src);
        if (!r.ok) throw new Error("il sito ha risposto " + r.status);
        const total = Number(r.headers.get("content-length")) || 0;
        const ext = (req.src.split("?")[0].split(".").pop() || "").toLowerCase().slice(0, 5);
        post({ type: "meta", size: total, ext, title: "" });
        const reader = r.body.getReader();
        let got = 0, buf = [], bufLen = 0, lastPct = -1;
        const flush = () => {
          if (!bufLen) return;
          const all = new Uint8Array(bufLen);
          let o = 0;
          for (const b of buf) { all.set(b, o); o += b.length; }
          post({ type: "chunk", data: bytesToB64(all) });
          buf = []; bufLen = 0;
        };
        for (;;) {
          const { done, value } = await reader.read();
          if (done || closed) break;
          buf.push(value); bufLen += value.length; got += value.length;
          if (bufLen >= 600 * 1024) flush();
          const pct = total ? Math.floor((got * 100) / total) : -1;
          if (pct !== lastPct) { lastPct = pct; post({ type: "progress", pct }); }
        }
        flush();
        post({ type: "done" });
        return;
      } catch (e) {
        if (!req.url) { post({ type: "error", code: "fetch", message: "non riesco a scaricare il file: " + (e.message || e) }); return; }
        // provo con yt-dlp qui sotto
      }
    }
    // 2) YouTube, Vimeo, VK e gli altri siti: yt-dlp tramite il programma di appoggio
    try { native = chrome.runtime.connectNative(HELPER); } catch (e) {
      post({ type: "error", code: "nohelper", message: "il programma di appoggio per yt-dlp non è installato" });
      return;
    }
    let finished = false;
    native.onMessage.addListener((m) => {
      if (m.type === "done" || m.type === "error") finished = true;
      post(m);
      if (finished) { try { native.disconnect(); } catch {} }
    });
    native.onDisconnect.addListener(() => {
      if (finished) return;
      const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : "";
      const missing = /not found|not exist|non trovato|No such native/i.test(err);
      post({ type: "error", code: missing ? "nohelper" : "crash",
        message: missing ? "il programma di appoggio per yt-dlp non è installato" : "il programma di appoggio si è chiuso" + (err ? " (" + err + ")" : "") });
    });
    native.postMessage({ cmd: "audio", url: req.url });
  });
});

// Diretta in anticipo: la pagina apre la porta "sd-live" e riceve l'audio della diretta letto da yt-dlp (un secondo
// alla volta) finché la tiene aperta. Chiusa la porta, il programma di appoggio ferma yt-dlp e ffmpeg.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "sd-live") return;
  let native = null, closed = false, finished = false;
  const post = (m) => { if (!closed) try { port.postMessage(m); } catch {} };
  port.onDisconnect.addListener(() => { closed = true; try { native && native.postMessage({ cmd: "stop" }); } catch {} try { native && native.disconnect(); } catch {} });
  port.onMessage.addListener((req) => {
    if (!req || !req.url || native) return;
    try { native = chrome.runtime.connectNative(HELPER); } catch (e) {
      post({ type: "error", code: "nohelper", message: "il programma di appoggio per yt-dlp non è installato" });
      return;
    }
    native.onMessage.addListener((m) => {
      if (m.type === "done" || m.type === "error") finished = true;
      post(m);
    });
    native.onDisconnect.addListener(() => {
      if (finished || closed) return;
      const err = chrome.runtime.lastError ? chrome.runtime.lastError.message : "";
      const missing = /not found|not exist|non trovato|No such native/i.test(err);
      post({ type: "error", code: missing ? "nohelper" : "crash",
        message: missing ? "il programma di appoggio per yt-dlp non è installato" : "il programma di appoggio si è chiuso" + (err ? " (" + err + ")" : "") });
    });
    native.postMessage({ cmd: "live", url: req.url, hls: req.hls || "" });
  });
});

// ---------- Corrispondenza tra traduzione e originale ----------
// Con un modello: allineamento dell'intera frase, parola per parola (una richiesta per frase)
async function align(msg) {
  const E = C.ENGINES[msg.engine];
  if (!E || !llmReady(E, msg)) throw new Error("serve un modello (Gemini, Groq, Claude o locale)");
  const tl = C.LANG_EN[msg.target] || msg.target || "the learner's language";
  // più frasi in una sola richiesta: quella che stai guardando e le prossime (risparmia quota)
  const items = Array.isArray(msg.items) && msg.items.length ? msg.items : [{ original: msg.original, translation: msg.translation }];
  const system =
    `You align sentences with their translations for a language learner. You get a list of items, each with an original ` +
    `sentence and its translation. Return only JSON in this form, with one entry per item, in the same order: ` +
    `{"items": [{"pairs": [{"t": "words from the translation", "o": "the words of the original they translate", "extra": ["..."]}, ...], ` +
    `"idioms": [{"text": "words from the original", "meaning": "..."}]}, ...]}. ` +
    `For each item go through the translation in order and cover every word of it exactly once. Make the pairs as small as possible: ` +
    `one word with its own counterpart whenever the correspondence is one-to-one (never pair a word with the word next to ` +
    `its counterpart); group words only when they translate together (idioms, compound verb forms, contractions). ` +
    `Copy the words exactly as written in each text (same spelling, apostrophes and accents). ` +
    `"o" is never empty: it is always the part of the original the words of "t" belong to. ` +
    `Words of the translation that do not translate any word of the original (articles, prepositions, auxiliaries, ` +
    `pronouns or particles required only by the grammar of the translation) go in the pair of the word they accompany ` +
    `and are also listed in "extra"; otherwise "extra" is []. ` +
    `Example: original "I like cats", translation "Mi piacciono i gatti" → ` +
    `{"pairs": [{"t": "Mi piacciono", "o": "I like", "extra": []}, {"t": "i gatti", "o": "cats", "extra": ["i"]}]}. ` +
    `In "idioms" list every idiom, figurative expression, phrasal verb or fixed phrase of the ORIGINAL whose meaning ` +
    `is not the sum of its words (e.g. "break the ice", "give up", "tomar el pelo"), copied exactly as written in the ` +
    `original, with its real meaning in ${tl} (1-6 words). Use [] if there are none.`;
  const user = JSON.stringify({ original_language: msg.lang || "unknown",
    items: items.map((x, i) => ({ n: i + 1, original: x.original, translation: x.translation })) });
  const text = await paced(msg.engine, E, () => llmText(E, msg, system, user), true);
  const obj = parseObject(text);
  const list = Array.isArray(obj.items) ? obj.items : [obj];
  const results = items.map((it, i) => {
    const o = list[i] || {};
    const pairs = (Array.isArray(o.pairs) ? o.pairs : [])
      .map((p) => (Array.isArray(p) ? (p.length >= 2 ? [p[0], p[1], p[2]] : null)
        : p && typeof p === "object" ? [p.t ?? p.translation, p.o ?? p.original, p.extra] : null))
      .filter((p) => p && String(p[0] || "").trim())
      .map((p) => [String(p[0] || ""), String(p[1] || ""), (Array.isArray(p[2]) ? p[2] : p[2] ? [p[2]] : []).map(String)]);
    const low = String(it.original || "").toLowerCase();
    const idioms = (Array.isArray(o.idioms) ? o.idioms : [])
      .map((x) => (typeof x === "string" ? { text: x, meaning: "" } : { text: String((x && x.text) || ""), meaning: String((x && x.meaning) || "") }))
      .filter((x) => x.text.trim().split(/\s+/).length > 1 && exprInSentence(x.text, low));
    return { pairs, idioms };
  });
  if (!results[0].pairs.length) throw new Error("allineamento non leggibile");
  return { pairs: results[0].pairs, idioms: results[0].idioms, results };
}

// Senza modello: traduzione inversa della singola parola con Google (gratis), per cercarla nell'originale
async function wordBack(msg) {
  const tl = googleLang(msg.to || "en");
  const sl = msg.from ? "&sl=" + encodeURIComponent(googleLang(msg.from)) : "";
  const data = await googleRequest(msg.word, tl, "&dt=bd" + sl);
  const words = new Set();
  const add = (s) => String(s || "").toLowerCase().split(/[^\p{L}\p{N}']+/u).filter((w) => w.length > 1).forEach((w) => words.add(w));
  add(googleText(data));
  for (const e of Array.isArray(data[1]) ? data[1] : []) for (const t of (e[1] || []).slice(0, 8)) add(t);
  return { candidates: [...words].slice(0, 30) };
}

// ---------- Interfaccia nella lingua di «Traduci in» (ui-i18n.js) ----------
let uiStringsCache = null;
async function uiStrings() {
  if (!uiStringsCache) uiStringsCache = await (await fetch(DS_EXT.runtime.getURL("ui-strings.json"))).json();
  return uiStringsCache;
}
// Traduce le scritte dell'interfaccia dall'italiano con Google (gratis) e le ricorda in storage.local ("uiTr:<lingua>"):
// ogni scritta si traduce una volta sola, per tutte le pagine. I segnaposto {0} {1} devono restare.
const uiLocks = new Map();
async function uiTranslate(msg) {
  const lang = String(msg.target || "").split("-")[0];
  if (!lang || lang === "it") return { map: {} };
  const k = "uiTr:" + lang;
  // una traduzione alla volta per lingua, così due pagine non si sovrascrivono la memoria
  const prev = uiLocks.get(lang) || Promise.resolve();
  let release;
  uiLocks.set(lang, new Promise((r) => { release = r; }));
  await prev;
  try {
    const store = (await DS_EXT.storage.local.get({ [k]: {} }))[k] || {};
    const want = [...new Set((msg.texts || []).map(String))].filter((t) => t && !store[t]).slice(0, 300);
    const map = {};
    for (const t of msg.texts || []) if (store[t]) map[t] = store[t];
    // a gruppi (Google prende testi di qualche migliaio di caratteri)
    for (let i = 0; i < want.length;) {
      const group = [];
      let len = 0;
      while (i < want.length && group.length < 40 && len + want[i].length < 3500) { group.push(want[i]); len += want[i].length + 1; i++; }
      if (!group.length) { group.push(want[i]); i++; }
      let out;
      try { out = await translateGoogle({ texts: group.map((t) => t.replace(/\n/g, " ")), target: lang, source: "it" }); } catch { break; }
      group.forEach((t, j) => {
        let x = String(out[j] || "").trim();
        const ph = t.match(/\{\d+\}/g) || [];
        // Google a volte scrive "{ 0 }" o "{0 }": li rimetto a posto; se ne manca uno, la scritta resta in italiano
        x = x.replace(/\{\s*(\d+)\s*\}/g, "{$1}");
        if (!x || ph.some((p) => !x.includes(p))) x = t;
        map[t] = x; store[t] = x;
      });
    }
    if (want.length) await DS_EXT.storage.local.set({ [k]: store });
    return { map };
  } finally { release(); }
}

// ---------- Dizionario di Google (quello delle ricerche, dati Oxford Languages) ----------
// Non è un'API ufficiale: è la stessa richiesta che fa la pagina dei risultati di Google per il riquadro del dizionario.
// Dà pronuncia (con audio), significati con esempi, sinonimi e contrari, forme della parola e origine (a volte con
// l'albero etimologico in un'immagine). Lingue: quelle dei dizionari di Google. Se Google cambia il formato, la parte
// sparisce dalla scheda (niente errori).
const GDICT_CORPUS = { en: "en", es: "es", fr: "fr", de: "de", it: "it", pt: "pt-BR", ru: "ru", hi: "hi", ja: "ja", ko: "ko", ar: "ar", tr: "tr" };
const GDICT_FC = "ErUBCndBTlVfTnFUN29LdXdNSlQ2VlZoWUIwWE1HaElOclFNU29TOFF4ZGxGbV9zbzA3YmQ2NnJyQXlHNVlrb3l3OXgtREpRbXpNZ0M1NWZPeFo4NjQyVlA3S2ZQOHpYa292MFBMaDQweGRNQjR4eTlld1E4bDlCbXFJMBIWU2JzSllkLVpHc3J5OVFPb3Q2aVlDZxoiQU9NWVJ3QmU2cHRlbjZEZmw5U0lXT1lOR3hsM2xBWGFldw";
const gwCache = new Map();
const gwUrl = (u) => (typeof u === "string" && u ? (u.startsWith("//") ? "https:" + u : u) : "");
// cerca dentro un oggetto il primo valore che va bene (il formato di Google cambia un po' da lingua a lingua)
function gwFind(o, test, depth = 0) {
  if (!o || depth > 8) return null;
  if (Array.isArray(o)) { for (const x of o) { const r = gwFind(x, test, depth + 1); if (r != null) return r; } return null; }
  if (typeof o !== "object") return null;
  for (const [k, v] of Object.entries(o)) { const r = test(k, v); if (r != null) return r; }
  for (const v of Object.values(o)) { const r = gwFind(v, test, depth + 1); if (r != null) return r; }
  return null;
}
const gwText = (x) => (x == null ? "" : typeof x === "string" ? x : typeof x.text === "string" ? x.text : "");
function gwNyms(list) {
  const out = [];
  for (const g of list || []) for (const n of (g && g.nyms) || []) { const t = gwText(n.nym != null ? n.nym : n); if (t && !out.includes(t)) out.push(t); }
  return out.slice(0, 8);
}
function gwEntry(e) {
  const phon = (e.phonetics || []).map((p) => ({ text: gwText(p.text != null ? p.text : p), audio: gwUrl(p.oxford_audio || p.audio || "") })).filter((p) => p.text || p.audio);
  const ety = e.etymology || {};
  const origin = gwText(ety.etymology) || gwText(ety);
  // albero etimologico: un'immagine dentro "etymology" (se c'è)
  const tree = gwUrl(gwFind(ety, (k, v) => (typeof v === "string" && /^(https?:)?\/\/.+\.(png|svg|gif|jpe?g|webp)(\?|$)/i.test(v) ? v : null)) || "");
  const groups = [];
  for (const f of e.sense_families || []) {
    let pos = (f.parts_of_speech || []).map((x) => x.value).filter(Boolean)[0] || "";
    const senses = [];
    for (const sn of f.senses || []) {
      if (!pos) pos = ((sn.parts_of_speech || [])[0] || {}).value || "";
      const def = gwText(sn.definition);
      if (!def) continue;
      const exg = (sn.example_groups || [])[0] || {};
      const th = (sn.thesaurus_entries || [])[0] || {};
      senses.push({ def, ex: gwText((exg.examples || [])[0]), syn: gwNyms(th.synonyms), ant: gwNyms(th.antonyms),
        labels: [...(sn.label_set && sn.label_set.register_labels || []), ...(sn.label_set && sn.label_set.subject_labels || [])].map(gwText).filter(Boolean).slice(0, 3) });
      if (senses.length >= 6) break;
    }
    const forms = (f.morph_units || []).map((m) => ({ type: gwText(m.form_type && (m.form_type.description || m.form_type)), form: gwText(m.word_form) })).filter((m) => m.form).slice(0, 8);
    if (senses.length || forms.length) groups.push({ pos, senses, forms });
  }
  return { headword: gwText(e.headword) || gwText(e.lemma), phonetics: phon, origin, tree, groups };
}
const GDICT_ON = false;
let gwRefusedAt = 0, gwRefusedCode = 0;
async function googleWebDict(msg) {
  const word = String(msg.word || "").trim();
  const corpus = GDICT_CORPUS[String(msg.lang || "").split("-")[0]];
  if (!word || !corpus) return { unsupported: !corpus, entries: [] };
  // Google ha tolto il dizionario dalle ricerche (2026: solo AI Overview; questo indirizzo risponde 400): non chiedo più
  if (!GDICT_ON) return { entries: [], corpus, gone: true };
  const key = corpus + "|" + word.toLowerCase();
  if (gwCache.has(key)) return gwCache.get(key);
  const url = "https://www.google.com/async/callback:5493?fc=" + GDICT_FC + "&fcv=3&async=term:" + encodeURIComponent(word) +
    ",corpus:" + corpus + ",hhdr:true,hwdgt:true,wfp:true,ttl:,tsl:,ptl:";
  // Google ha rifiutato da poco (400/403/404: l'indirizzo non ufficiale è cambiato): non riprovo per 12 ore
  if (Date.now() - gwRefusedAt < 12 * 3600e3) { const e = new Error("Google non risponde (" + gwRefusedCode + ")"); e.gone = true; throw e; }
  const r = await fetch(url, { credentials: "include" });
  if ([400, 403, 404].includes(r.status)) { gwRefusedAt = Date.now(); gwRefusedCode = r.status; }
  if (!r.ok) throw new Error("Google ha risposto " + r.status + (r.redirected ? " (" + new URL(r.url).host + ")" : ""));
  const body = await r.text();
  // pagina del consenso dei cookie (Europa) o altra pagina HTML invece dei dati
  if (/consent\.google|<html/i.test(body.slice(0, 600)) && body.indexOf("single_results") < 0)
    throw new Error("Google ha risposto con una pagina invece dei dati" + (/consent/i.test(body) ? " (consenso dei cookie: apri google.com e accetta, poi riprova)" : ""));
  let data;
  try { data = JSON.parse(body.slice(body.indexOf("{"))); } catch { throw new Error("risposta di Google non leggibile: «" + body.slice(0, 80).replace(/\s+/g, " ") + "»"); }
  const singles = gwFind(data, (k, v) => (k === "single_results" && Array.isArray(v) ? v : null)) || [];
  const entries = singles.map((x) => x && x.entry).filter(Boolean).map(gwEntry).filter((e) => e.groups.length || e.origin || e.phonetics.length).slice(0, 3);
  // per capire i casi in cui Google risponde ma senza voci: le chiavi principali della risposta
  const out = { entries, corpus, shape: entries.length ? "" : Object.keys(data || {}).slice(0, 4).join(",") + (singles.length ? " · " + singles.length + " risultati senza voce" : " · nessun risultato") };
  gwCache.set(key, out);
  while (gwCache.size > 500) gwCache.delete(gwCache.keys().next().value);
  return out;
}

// ---------- Uso nel tempo (Google Books Ngram): quanto compare la parola nei libri, anno per anno ----------
// Prima la raccolta del 2022 (quella che Google Books Ngram Viewer mostra di serie: «en», «it»…, fino al 2022), poi
// quella del 2019 e il vecchio numero. L'ultimo anno si ricava dalla lunghezza dei dati (un valore per anno).
const NGRAM_CORPUS = { en: ["en", "en-2019", "26"], fr: ["fr", "fr-2019", "30"], de: ["de", "de-2019", "31"], it: ["it", "it-2019", "33"],
  es: ["es", "es-2019", "32"], ru: ["ru", "ru-2019", "36"], he: ["iw", "iw-2019", "35"], zh: ["zh-Hans", "zh-Hans-2019", "34"] };
async function ngram(msg) {
  const word = String(msg.word || "").trim().replace(/\s+/g, " ");
  const cs = NGRAM_CORPUS[String(msg.lang || "").split("-")[0]];
  if (!word || !cs || word.split(" ").length > 5) return { unsupported: true };
  const key = cs[0] + "|" + word.toLowerCase();
  if (ngramCache.has(key)) return ngramCache.get(key);
  let err = "";
  const pick = (arr) => Array.isArray(arr) && arr.find((x) => x && Array.isArray(x.timeseries) && x.timeseries.length > 10);
  for (const c of cs) {
    const end = /-2019$|^\d+$/.test(c) ? 2019 : 2022;
    const q = "content=" + encodeURIComponent(word) + "&year_start=1800&year_end=" + end + "&smoothing=3&corpus=" + encodeURIComponent(c);
    // il servizio di Google ogni tanto risponde 429/500 o una pagina: riprovo una volta, poi l'altro indirizzo (la pagina del grafico ha gli stessi dati dentro)
    for (const [url, html] of [["https://books.google.com/ngrams/json?" + q, false], ["https://books.google.com/ngrams/json?" + q, false], ["https://books.google.com/ngrams/graph?" + q, true]]) {
      try {
        const r = await fetch(url);
        if (!r.ok) { err = "Google Books ha risposto " + r.status; if (r.status === 429) await new Promise((ok) => setTimeout(ok, 1200)); continue; }
        let series;
        if (html) {
          const t = await r.text();
          const m = t.match(/ngrams\.data\s*=\s*(\[[\s\S]*?\]);\s*(?:\n|<)/) || t.match(/var\s+data\s*=\s*(\[[\s\S]*?\]);/);
          if (m) { try { series = pick(JSON.parse(m[1])); } catch {} }
        } else series = pick(await r.json());
        if (series) {
          const out = { start: 1800, end: 1800 + series.timeseries.length - 1, values: series.timeseries.map(Number), corpus: c, word };
          ngramCache.set(key, out);
          while (ngramCache.size > 200) ngramCache.delete(ngramCache.keys().next().value);
          return out;
        }
        if (!html) break;   // risposta valida ma senza dati per quella raccolta: la prossima
      } catch (e) { err = String(e.message || e); }
    }
  }
  return { values: [], error: err };
}
const ngramCache = new Map();

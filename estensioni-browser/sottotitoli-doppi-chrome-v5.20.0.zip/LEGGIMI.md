*Versione 5.20.0*

# Sottotitoli Doppi — estensione per il browser

*English version → [GUIDE.en](GUIDE.en.md)*

**Impara le lingue guardando video.** Sotto i sottotitoli originali compare la traduzione nella tua lingua, in un altro colore. Ogni parola si può toccare con il mouse per vederne il significato in quella frase, sentirne la pronuncia e salvarla in un vocabolario personale.

Funziona su YouTube e su quasi tutti i siti con video o audio. Se un video non ha sottotitoli, l'estensione ascolta l'audio e li scrive da sola.

Browser: **Edge, Chrome, Brave** (e gli altri basati su Chromium) e **Firefox**.

---

## Indice

1. [Cosa fa, in breve](#1-cosa-fa-in-breve)
2. [Installazione e aggiornamenti](#2-installazione-e-aggiornamenti)
3. [Primi passi (5 minuti)](#3-primi-passi-5-minuti)
4. [Dove funziona](#4-dove-funziona)
5. [I sottotitoli sul video](#5-i-sottotitoli-sul-video)
6. [Imparare con le parole](#6-imparare-con-le-parole)
7. [Il vocabolario personale](#7-il-vocabolario-personale)
8. [Video senza sottotitoli: la trascrizione dell'audio](#8-video-senza-sottotitoli-la-trascrizione-dellaudio)
9. [La pagina "Trascrizione e traduzione"](#9-la-pagina-trascrizione-e-traduzione)
10. [I servizi di traduzione](#10-i-servizi-di-traduzione)
11. [Consumare meno richieste gratuite](#11-consumare-meno-richieste-gratuite)
12. [Un modello di traduzione sul tuo computer](#12-un-modello-di-traduzione-sul-tuo-computer)
13. [Se qualcosa non va](#13-se-qualcosa-non-va)
14. [Privacy e note](#14-privacy-e-note)

---

## 1. Cosa fa, in breve

| Funzione | Cosa fa |
|---|---|
| 🎬 **Doppia riga** | Originale sopra, traduzione sotto (o al contrario), sul video stesso. |
| 🧠 **Traduzione che capisce il discorso** | Con Gemini e gli altri modelli la traduzione tiene conto delle frasi vicine, non riga per riga. |
| 👆 **Parole interattive** | Passi il mouse su una parola e vedi il significato in quella frase; clicchi per una spiegazione completa. |
| 🔗 **Traduzione ↔ originale** | Passando su una parola tradotta si illumina quella originale da cui viene. Articoli e preposizioni "aggiunte" dalla traduzione sono segnalate. |
| 🗣️ **Pronuncia** | Ogni parola si può ascoltare; il video si abbassa da solo mentre parla. |
| ⭐ **Vocabolario** | Salvi parole ed espressioni con la frase e il punto del video; esporti tutto per Anki. |
| 🎙️ **Trascrizione dell'audio** | Video senza sottotitoli? L'audio viene trascritto con Whisper (gratis con una chiave Groq). |
| 📄 **Testo completo** | Una pagina con tutto il testo del video, da leggere, copiare o scaricare (.txt, .srt). |
| ✏️ **Correzioni** | Una frase tradotta o trascritta male si rifà con un clic, o si corregge a mano. |
| 💸 **Pochi consumi** | Tutto viene salvato: rivedere un video non costa niente. Se un servizio gratuito finisce le richieste, si passa da soli a un altro. |

---

## 2. Installazione e aggiornamenti

### Edge, Chrome, Brave
1. Estrai lo zip `sottotitoli-doppi-chrome-vX.Y.Z.zip` in una cartella **che non cancellerai** (per esempio `Documenti\Sottotitoli Doppi`).
2. Apri `edge://extensions` (su Chrome `chrome://extensions`).
3. Attiva **Modalità sviluppatore** (interruttore in basso a sinistra su Edge, in alto a destra su Chrome).
4. Premi **Carica estensione non pacchettizzata** e scegli la cartella del punto 1.
5. Fissa l'icona dell'estensione nella barra (icona del puzzle → puntina), così il popup è a un clic.

### Firefox
1. Apri `about:addons`, premi l'ingranaggio ⚙ → **Installa componente aggiuntivo da file…**
2. Scegli il file `sottotitoli-doppi-firefox-vX.Y.Z.xpi`.

### Aggiornare senza perdere niente
- **Edge/Chrome:** estrai la nuova versione **nella stessa cartella**, sostituendo i file vecchi, poi in `edge://extensions` premi ↻ sulla scheda dell'estensione e ricarica le pagine aperte.
- **Firefox:** installa il nuovo .xpi sopra quello vecchio.

> ⚠️ **Non rimuovere mai l'estensione per aggiornarla**: con lei si cancellano le chiavi, le traduzioni salvate e il vocabolario.

### Video e audio sul tuo computer
Per i file aperti con doppio clic nel browser (indirizzi che iniziano con `file:///`): in `edge://extensions` apri **Dettagli** dell'estensione e attiva **Consenti l'accesso agli URL dei file**.

---

## 3. Primi passi (5 minuti)

1. **Apri il popup** (clic sull'icona dell'estensione) e in alto scegli **Traduci in**: la tua lingua.
2. Nella sezione **Traduzione → Come tradurre** lascia **Google Traduttore** per cominciare subito, senza chiavi.
3. Apri un video di YouTube nella lingua che studi e accendi i sottotitoli (**CC**). Compare la doppia riga.
4. Passa il mouse su una parola della riga originale: il video si ferma e compare la scheda con il significato.

**Per una traduzione molto migliore (consigliato, gratis):**
1. Vai su **aistudio.google.com/apikey** con il tuo account Google e premi *Create API key* (non serve la carta).
2. Nel popup scegli **Come tradurre → Gemini**, incolla la chiave in **Chiave API** e premi Invio. Il modello si sceglie da solo.

**Per i video senza sottotitoli** serve anche una chiave **Groq**, gratuita: vedi la [sezione 8](#8-video-senza-sottotitoli-la-trascrizione-dellaudio).

---

## 4. Dove funziona

- **YouTube**, anche nei video di YouTube inseriti in altri siti.
- **Qualsiasi sito con un video o un audio**: Vimeo, VK, siti di notizie, podcast, corsi online, siti di TV in diretta. Se il video ha già dei sottotitoli propri li usa e li traduce; altrimenti puoi farli trascrivere.
- **File aperti direttamente nel browser**, da un link o dal computer (mp4, webm, mp3, m4a, ogg, wav, flac…): la trascrizione parte da sola premendo Play.
- **Non funziona** con i siti a contenuti protetti (Netflix, Disney+, Prime Video…): il browser non lascia ascoltarne l'audio. La riga di stato del popup te lo dice.
- Se su un sito l'estensione non ti serve: popup → **Altro** → togli l'attivazione su quel sito.

---

## 5. I sottotitoli sul video

### Accendere e spegnere: il pulsante DS
- **Su YouTube** c'è il pulsante **DS** nella barra dei comandi del video, accanto a CC. **Sugli altri siti** è un piccolo "DS" in alto a destra del video.
- **Acceso** (bordo giallo): si vedono i sottotitoli doppi. **Spento**: spariscono e la trascrizione si ferma, così non consuma quota.
- Se i sottotitoli doppi spariscono per qualsiasi motivo, premi DS: tornano.
- La stessa cosa si fa nel popup, **Altro → Sottotitoli doppi attivi**.

### I pulsanti accanto ai sottotitoli
Passando il mouse sui sottotitoli compaiono a destra:
- **⚑ — Frase sbagliata?** Apre una scheda con:
  - **↻ Ritraduci**: chiede di nuovo la traduzione di quella frase (passa davanti alle altre richieste);
  - **🎙 Ritrascrivi** (solo per le frasi trascritte dall'audio): la fa riascoltare a Whisper con il modello più preciso;
  - **✎ Correggi a mano**: scrivi tu l'originale e/o la traduzione giusta;
  - **✕ Togli**: per le frasi inventate durante la musica.

  Le correzioni restano salvate con il video e valgono anche nei file scaricati.
- **⧉ — Copia o consulta la frase.** Ferma il video e mostra la frase, selezionabile con il mouse:
  - **Copia originale**, **Copia traduzione**, **Copia tutte e due** (se selezioni una parte, copiano solo quella);
  - **Apri in: Google Traduttore · DeepL · Reverso**: la frase (o la parte selezionata) si apre in un'altra scheda, con le lingue già impostate. Reverso mostra le parole dentro tante frasi vere. Per le lingue che Reverso non apre già pronte (per esempio il ceco) il testo viene copiato: incollalo nella sua casella.
- **Sigla della lingua (per esempio EN)** — solo per le frasi trascritte dall'audio: se la trascrizione è nella lingua sbagliata, cliccala e scegli quella giusta (vedi "La lingua della trascrizione").

### Pronuncia IPA delle parole
Nella scheda della parola, sotto la parola, c'è la sua **pronuncia IPA** (alfabeto fonetico internazionale) e, per gli alfabeti diversi dal nostro, la **trascrizione in caratteri latini** (*кошка* → koshka).
- L'IPA viene **sempre da Wiktionary**, gratis e senza token (prima quello inglese, poi quello della lingua della parola, il tuo e i più grandi). Passando il mouse sulla pronuncia leggi da dove viene.
- Se Wiktionary non l'ha (capita con le forme flesse), **clicca la parola**: la pronuncia arriva **nella stessa richiesta** della spiegazione del modello, mai con una richiesta a parte. Questo succede solo con l'opzione **Aspetto → IPA anche dal modello, se manca su Wiktionary** accesa; spenta, solo Wiktionary.

### Etimologia delle parole
Nella scheda di una parola, sotto il significato, c'è la sua **etimologia**: da dove viene (per esempio *bread* → dall'inglese antico *brēad*, imparentato con il tedesco *Brot*).

- Viene da **Wiktionary** (gratis, senza chiave), tradotta nella tua lingua con Google; il collegamento "Wiktionary" apre la pagina completa. Per le forme flesse (*walked*, *went*) cerca la forma base.
- Si chiede solo se la scheda resta aperta un attimo, poi resta salvata. Finisce anche nel vocabolario e nelle carte per Anki.
- Se Wiktionary non la ha, **clicca la parola**: la spiegazione nel contesto di Gemini (o del servizio scelto) porta anche l'etimologia, nella stessa richiesta (una sola, non due).
- Si accende e spegne nel popup → **Aspetto → Etimologia nella scheda della parola**.

### Aspetto
Popup → **Aspetto dei sottotitoli**: cosa mostrare (entrambe, solo originale, solo traduzione), traduzione sopra o sotto, dimensione del testo e della traduzione, colori, sfondo, altezza sul video, carattere. Le modifiche si vedono subito; **Ripristina l'aspetto predefinito** rimette tutto com'era.

Popup → **Altro → Nascondi i sottotitoli del sito**: nasconde quelli originali del sito, per non vederli due volte.

---

## 6. Imparare con le parole

### La scheda di una parola
- **Passa il mouse** su una parola della riga originale: il video si ferma e compare una scheda con il significato dal dizionario di Google (gratis, nessuna richiesta consumata).
- **Clicca** la parola: la scheda si fissa, mostra subito il significato di Google e chiede al servizio scelto (Gemini, Groq, Mistral, Claude…) **il significato in quella frase**: forma base (per esempio *went → go*), tipo di parola, spiegazione ed esempio. Una sola richiesta, solo quando la vuoi.
- Nella scheda:
  - **🔈** pronuncia con la voce sintetica (la sigla accanto, per esempio *DA*, dice in che lingua); quando esiste una registrazione vera della parola (Wiktionary), accanto compare anche **🔊**, la voce di una persona. In tutta l'estensione **🔊** = registrazione vera, **🔈** = voce sintetica;
  - **☆** salva nel vocabolario;
  - **↺ Riascolta la frase**: torna all'inizio della frase e si ferma alla fine;
  - **Copia la parola / Copia la frase**;
  - **Apri in:** Google Traduttore, DeepL, Reverso, **WordReference** (tra inglese e italiano, spagnolo, francese, tedesco, portoghese) e **Wiktionary** (spiega quasi ogni parola di quasi ogni lingua).
- La scheda si chiude con **×** o **Esc**. Spostando il mouse via dai sottotitoli il video riparte da solo (si può spegnere: **Altro → Pausa quando passi sulle parole**).
- Le spiegazioni restano salvate, anche chiudendo il browser: la stessa parola nella stessa frase non si richiede più.

### Strumenti per imparare
Nella scheda di una parola, sotto il significato, ci sono altri aiuti. Sono tutti **gratis e senza chiavi** e ognuno si spegne nel popup → **Strumenti per imparare**. Si chiedono solo se la scheda resta aperta almeno un attimo, e restano salvati.
- **Dizionario di Google** (nella stessa richiesta della traduzione, gratis): **traduzioni con il loro peso** (la più usata in evidenza, una barretta per quanto è comune; passando il mouse le traduzioni al contrario), **definizioni nella lingua della parola** con un esempio, **sinonimi** e **"vedi anche"**, e **"Forse cercavi…"** nel controllo della scrittura. Google a volte non dà alcune parti: in quel caso non compaiono. Le **definizioni** arrivano anche dal Wiktionary della lingua della parola (e, se mancano, da quello inglese), ognuna con **traduci**; le altre con **altre ›**.
- **Lettere latine sopra le lettere**: con **Aa** accanto ai sottotitoli (o nel popup → Aspetto) sopra ogni lettera di cirillico, greco, armeno, georgiano, ebraico, kana giapponesi e coreano compare la trascrizione; in arabo, persiano, urdu e hindi sopra ogni parola. Tabelle scritte nell'estensione, nessun servizio. Per kanji e caratteri cinesi c'è la lettura della riga intera (Google, gratis). Le grandezze si regolano separatamente nel popup → Aspetto: «Lettere sopra i caratteri» e «Lettura della riga (romaji)».
- **Immagine per Anki** (popup → Anki): nella scheda la vedi e la cambi con ‹ ›, «altre…» (cerca, scegli la fonte, incolla un indirizzo) o ✕; nel vocabolario con 🖼.
- **Parole che conosco** (pulsante in alto nel popup): l'elenco delle parole più usate, con lingua, «segna le prime N», **⇄ Sincronizza adesso** (passa le parole conosciute a Parole al Volo e viceversa, senza file), esporta e importa. Nel vocabolario ⇄ Esporta/Importa passa vocabolario e parole conosciute a Parole al Volo e viceversa.
- **Livelli**: «livello ≈ B1 ›» accanto alla frequenza (indicativo, A1…C2 dalla posizione nell'elenco) apre le parole di quel livello; per il giapponese «JLPT N5 ›» apre tutte le parole di quel livello JLPT (Jisho), con «la conosco?».
- **Modi di dire sottolineati**: il primo clic su una parola apre tutta l'espressione, il secondo la parola da sola (e così via).
- **🔊\*** arancione: la registrazione è di un'altra forma della parola (te lo dice passando il mouse).
- **⚑ Traduzione sbagliata?** sotto il significato: rifai con Google, rifai con il modello nel contesto, o correggi a mano (resta salvata).
- **Frequenza**: quanto è usata la parola (per esempio "molto comune · tra le 1000 più usate"). L'elenco della lingua si scarica una volta sola. **Cliccandola** si apre l'elenco delle parole più usate di quella lingua, con la parola evidenziata al suo posto, la ricerca e «la conosco?» per segnare quelle che sai.
- **«la conosco?»**: premilo per le parole che sai già. Diventano **verdi** nei sottotitoli, e in cima al popup leggi **quante parole del video conosci** (per esempio "Conosci il 72% delle parole di questo video"). Anche "Segna come imparata" nel vocabolario la aggiunge.
- **Genere** dei nomi (maschile, femminile, neutro; in tedesco anche *der/die/das*).
- **Giapponese**: dal dizionario **Jisho** (gratis) la lettura in kana, il livello JLPT, se è una parola comune e il significato in inglese.
- **Kanji e caratteri cinesi uno per uno**: nella scheda di una parola giapponese o cinese, la riga «Kanji uno per uno» ha un pulsante per ogni carattere. Cliccandolo vedi solo quel kanji: significato, letture nella lingua del testo e nelle altre (on/kun, pinyin, cantonese, coreano, vietnamita), parti e radicale cliccabili, forma semplificata/tradizionale, tratti, livelli JLPT/classe, HSK, hanja scolastico; «lo conosco?», Jisho, Wiktionary e «scheda del carattere ›» per aprirlo come una parola (vocabolario, Anki) e poi «‹ Torna alla parola». ☆ salva il kanji / ☆ salva tutti i kanji: i singoli caratteri nel vocabolario. Gratis, nessuna richiesta a Gemini o Groq.
- **↺ a sinistra dei sottotitoli**: riascolta la frase; se intanto il video è andato avanti (è giallo) torna alla frase che stavi leggendo.
- **Dirette in anticipo** (popup → Video senza sottotitoli → «Dirette: sottotitoli in anticipo»): nelle dirette di YouTube il video resta qualche secondo indietro e yt-dlp legge l'audio più avanti, così i sottotitoli trascritti arrivano in orario invece che 5–10 secondi dopo. Serve il programma per yt-dlp (con ffmpeg, che l'installatore scarica da solo su Windows; su Mac e Linux va installato a parte).
- **Scrittura**: se la parola è scritta bene. Senza modello lo controlla LanguageTool (o, per le lingue che non conosce, il dizionario: "parola presente nel dizionario"); cliccando la parola, il modello dà anche un **voto da 0 a 100** e la forma corretta. Utile con i sottotitoli automatici, che a volte sbagliano.
- **Registrazione vera**: quando Wiktionary ha la parola registrata da una persona, in alto nella scheda compare **🔊** accanto a 🔈 (si spegne con "Pronuncia di madrelingua" nel popup). Vale solo per la parola esatta, non per la forma base.
- **Etimologia**: da Wiktionary, tradotta nella tua lingua (le parole straniere citate restano come sono). **originale** la mostra com'è scritta su Wiktionary; **⚑** se è sbagliata: ritraduci, rifai con Gemini/Groq, correggi a mano (resta salvata).
- **▦ tabella**: coniugazione del verbo o declinazione del nome (Wiktionary; per le forme flesse quella della forma base).
- **Esempi veri** (Tatoeba): fino a 3 frasi scritte da persone, con la traduzione; **🔊** = registrata da un madrelingua, **🔈** = voce sintetica.
- **Falsi amici e parole parenti**: arrivano cliccando la parola, **nella stessa richiesta** della spiegazione (nessuna richiesta in più).
- **🐢 lenta** e **🔁 ×3** accanto a "↺ Riascolta la frase": riascolti la frase più lentamente o tre volte di fila.
- **Immagine nelle carte di Anki** (popup → Anki → "Metti un'immagine nelle carte di Anki", spenta di serie): quando salvi la parola cerca un'immagine su Wikimedia Commons e la mette sul fronte della carta (con l'invio diretto Anki la scarica; nel file si vede quando sei collegato a internet).

### Dalla traduzione all'originale
- **Passa il mouse su una parola della traduzione**: si illumina la parola originale da cui viene, e un'etichetta la scrive. Clic → scheda della parola originale.
- Con Gemini e gli altri modelli il collegamento è preciso (si chiede per 8 frasi alla volta, in una richiesta). Con Google è approssimato: l'etichetta dice "circa".
- **Particelle**: articoli, preposizioni e ausiliari che la traduzione aggiunge ma che non traducono una parola dell'originale (per esempio *i* in *i gatti* per l'inglese *cats*) sono **sottolineati a puntini**. Passandoci sopra, l'etichetta "particella" spiega a quale parte dell'originale appartengono.
- **Al contrario**: passando su una parola originale si illumina la sua traduzione (le particelle più tenui).

### Pezzi di frase ed espressioni
- **Modi di dire**: con un modello, le espressioni che non si traducono parola per parola (*break the ice*, *give up*…) vengono **sottolineate in arancione**. Passandoci sopra si illumina tutta l'espressione e la scheda ne dà il significato. (Si spegne in **Altro → Evidenzia i modi di dire**.)
- **Selezione a mano nell'originale**: tieni premuto sulla prima parola e trascina fino all'ultima → scheda con il significato dell'espressione intera.
- **Selezione nella traduzione**: trascina su più parole tradotte → nell'originale si illumina la parte corrispondente; l'etichetta ha **Spiega**, **Copia** e i collegamenti ai servizi. Si chiude con Esc.

### Pronuncia
La lingua si prende dalla parola o dal video. La voce è quella del computer (le voci "Natural" di Edge sono ottime); se manca, si usa la voce online di Google. Durante la pronuncia il video si abbassa e poi torna al volume di prima.

Popup → **Pronuncia delle parole**: lingua (con ricerca tra 98 lingue), voce, **Prova la voce**.

**Voce per ogni lingua.** Nella scheda della parola **⚙** accanto a 🔈 apre le voci per quella lingua: quella che scegli resta salvata e si usa sempre per quella lingua (anche dal popup → Pronuncia delle parole → "Aggiungi una lingua…"). Senza scelta l'estensione prende da sola la migliore: Azure (se acceso), poi le voci "Natural" del computer, poi le altre voci del computer, poi Google. Dopo aver premuto 🔈, passandoci sopra il mouse leggi quale voce ha parlato.

**Voci naturali di Microsoft (Azure Speech), anche in Firefox.** Firefox non vede le voci "Natural" di Edge; con una chiave gratuita di Azure Speech (500.000 caratteri al mese gratis) l'estensione usa le stesse voci in quasi tutte le lingue. Come fare: crea un account su portal.azure.com → "Crea una risorsa" → **Servizi di riconoscimento vocale** (Speech) con il piano gratuito **F0** → "Chiavi ed endpoint": copia la **chiave** e la **regione** (per esempio *westeurope*) nel popup → Pronuncia delle parole, poi **Prova la chiave**.

---

## 7. Il vocabolario personale

- Nella scheda di una parola o di un'espressione premi **☆**: viene salvata con la frase, la traduzione e il punto del video.
- Le parole salvate compaiono **sottolineate in azzurro** nei sottotitoli di tutti i video.
- Popup → **Il mio vocabolario**: cerca, riapri il video nel punto giusto, segna una parola come imparata (non viene più evidenziata in azzurro, e conta tra le parole che conosci) o eliminala.
- **Anki direttamente** (consigliato): installa in Anki il componente aggiuntivo **AnkiConnect** (Strumenti → Componenti aggiuntivi → Scarica, codice **2055492159**) e riavvia Anki. Con Anki aperto premi **Anki** nella scheda della parola (o **Manda ad Anki** nel vocabolario); la prima volta Anki chiede il permesso: premi **Yes**. Popup → **Anki**: **un mazzo per ogni lingua** ("Lingue::Inglese", "Lingue::Ceco"…: gli stessi di Parole al Volo), oppure un mazzo unico; invio automatico quando salvi con ☆; prova del collegamento.
- **Esporta per Anki**: scarica un file di testo (con il mazzo di ogni carta). In Anki: *File → Importa* → scegli il file (tipo di nota "Base"). Sul fronte la parola con la frase, sul retro significato, traduzione e link al video.

---

## 8. Video senza sottotitoli: la trascrizione dell'audio

Se un video non ha sottotitoli, l'estensione ascolta l'audio e lo trascrive con **Whisper**; le frasi vengono poi tradotte come le altre, con le parole interattive.

### Preparazione (una volta sola)
1. Crea una chiave gratuita su **console.groq.com/keys** (senza carta).
2. Popup → **Video senza sottotitoli → Chiave Groq**: incollala e premi Invio.

### Tre modi di trascrivere (popup → Video senza sottotitoli)
- **Mentre guardo**: trascrive quello che stai guardando, con pochi secondi di ritardo. L'audio viene mandato a pezzi (al massimo 9 secondi, tagliati nelle pause): quando un pezzo arriva con le sue frasi già passate, le frasi vengono mostrate tutte, in ordine, ognuna almeno il tempo per leggerla, e il ritardo si recupera piano piano (nelle pause del parlato sparisce). Se vuoi sottotitoli sempre in pari con il video, usa **Completa**. Se in modalità Completa lo scaricamento dell'audio va per le lunghe, dopo 12 secondi parte intanto la trascrizione mentre guardi; se è fermo da un minuto e mezzo viene interrotto con un messaggio. La traduzione compare subito in una versione rapida di Google (un po' trasparente) e poi viene sostituita da quella del servizio scelto.
- **Completa**: appena apri il video, l'audio intero viene scaricato e trascritto in pezzi, a partire dal punto in cui sei. I sottotitoli sono in pari con il video, anche saltando avanti e indietro. Su YouTube, Vimeo e simili serve il **programma per yt-dlp** (qui sotto); sui file diretti no.
- **Spenta**: non parte da sola; si avvia con **Trascrivi l'audio di questo video**.

Puoi scegliere una **modalità predefinita** e una diversa **per questo video**. "Completa solo fino a… minuti" evita di consumare la quota con un film aperto per sbaglio.

### Il programma per yt-dlp (solo per "Completa" su YouTube e simili)
Il browser non permette alle estensioni di scaricare l'audio da YouTube: serve un piccolo programma, installato una volta.
1. Popup → **Video senza sottotitoli → Programma per yt-dlp**.
2. **Scarica l'installatore** e lancialo (su Windows doppio clic; se Windows avvisa: *Ulteriori informazioni → Esegui comunque*).
3. Torna sulla pagina e premi **Verifica di nuovo**: deve comparire "Installato e funzionante".

Si aggiorna da solo. L'audio viene usato solo per la trascrizione e poi cancellato (i termini di YouTube non permettono di scaricare i video).

### La lingua della trascrizione
**Se la trascrizione è nella lingua sbagliata** (succede soprattutto con le canzoni: Whisper sente una canzone ceca e scrive in inglese), clicca il pulsante con la sigla della lingua accanto ai sottotitoli (per esempio **EN**), oppure ⚑ → **🌐 Lingua sbagliata?**: cerca la lingua giusta e la trascrizione di quel video viene rifatta in quella lingua. La scelta resta per quel video e vince su quella del popup; "Automatica" la toglie.

- **Video con i sottotitoli automatici di YouTube**: se chiedi la trascrizione, è sempre nella loro lingua (quella dell'audio), anche con "Rileva da sola", e quei sottotitoli aiutano Whisper a capire le parole. Un pezzo che arriva in inglese o in un altro alfabeto viene rifatto (anche con il modello più preciso) e, se resta sbagliato, saltato.
- **Lingua parlata**: lasciala su "Rileva da sola". L'estensione decide la lingua dai primi pezzi con abbastanza parlato e poi la **impone a Whisper**, così non cambia lingua e non scrive la traduzione in inglese al posto della trascrizione. Un vero cambio di lingua nel video viene seguito.
- Se Whisper sbaglia lingua in un video, scegli tu la lingua parlata (c'è una casella di ricerca).

### Trascrizione corretta
**Correggi la grammatica della trascrizione** (attiva di serie): le frasi capite male vengono corrette prima di essere tradotte (solo piccole correzioni nella stessa lingua: le frasi non vengono riscritte). Con Gemini e gli altri modelli avviene nella stessa richiesta della traduzione; con Google o DeepL la fa Gemini (o Groq) a gruppi.

### Trascrivere sul tuo computer
Con un server Whisper compatibile (per esempio Speaches): **Trascrizione con → Server sul tuo computer**, indirizzo (di solito `http://localhost:8000/v1`) e modello.

### Firefox
Per catturare l'audio Firefox deve ammutolire il video, e l'estensione lo rimanda subito alle casse. Se non senti l'audio o la trascrizione non parte, clicca una volta sul video.

---

## 9. La pagina "Trascrizione e traduzione"

Si apre dal popup con **Trascrizione e traduzione**. Contiene tutto il testo del video aperto.

- **Testo unico**: originale e traduzione a paragrafi (o solo uno dei due), da leggere.
- **Frase per frase (e correzioni)**: ogni frase con il suo tempo e i pulsanti **⧉** (copia), **↻** (ritraduci), **🎙** (ritrascrivi), **✎** (correggi), **✕** (togli).
- **Selezionare e copiare**: seleziona una parte con il mouse → sopra compare una barra con **Copia** e i collegamenti a Google Traduttore, DeepL, Reverso (se selezioni nella traduzione, il verso è al contrario). La pagina non si ridisegna mentre selezioni.
- **Copia il testo**, **Scarica testo (.txt)**, **Sottotitoli originali / tradotti / doppi (.srt)**: per tenerli o usarli in un altro lettore.
- **Trascrivere un file intero**: dal computer o dal video della scheda, senza doverlo guardare. Funziona anche senza nessun video aperto.
- **Carica sottotitoli da file (.srt, .vtt)**: per i film scaricati con i sottotitoli a parte.
- **Rifai la traduzione / Rifai la trascrizione**: cancellano quello salvato per il video e lo rifanno (le correzioni a mano restano).

### Tradurre con una chat, senza consumare quote
1. Premi **Copia trascrizione**: copia le frasi numerate con le istruzioni (per i video lunghi a parti di 250: il pulsante dice quale parte copierà).
2. Incollale in una chat (ChatGPT, Claude, Gemini…) e copia la sua risposta.
3. Premi **Incolla traduzione**, incolla la risposta e conferma. L'estensione legge le righe numerate, controlla che sia davvero una traduzione e la usa sul video. Resta salvata.

---

## 10. I servizi di traduzione

Si scelgono nel popup, **Traduzione → Come tradurre**. Scegli il servizio, incolla la chiave in **Chiave API**, premi Invio: il modello si sceglie da solo (per cambiarlo: **Carica modelli**).

| Servizio | Costo | Qualità | Cosa serve |
|---|---|---|---|
| Google Traduttore | gratis | discreta | niente |
| **Gemini** ⭐ consigliato | gratis | ottima, capisce il discorso | chiave da aistudio.google.com/apikey |
| Groq | gratis | buona, velocissimo | chiave da console.groq.com/keys (la stessa della trascrizione) |
| Mistral | gratis | buona, ottima per le lingue europee | chiave da console.mistral.ai |
| OpenRouter | gratis (modelli ":free") | varia | chiave da openrouter.ai/keys |
| Microsoft Translator | gratis fino a 2 milioni di caratteri al mese | molto buona | account Azure, risorsa "Translator" piano F0: chiave e **area** (es. *westeurope*) |
| DeepL | gratis fino a un limite mensile | molto alta | chiave "API Free" da deepl.com/pro-api (chiede una carta per verifica) |
| Modello sul computer | gratis, senza limiti | dipende dal PC | Ollama o LM Studio ([sezione 12](#12-un-modello-di-traduzione-sul-tuo-computer)) |
| Claude | a pagamento (pochi centesimi a video) | ottima | chiave da console.anthropic.com |
| YouTube riga per riga | gratis | scarsa | niente |

Gemini, Groq, Mistral, OpenRouter, Claude e il modello sul computer sono **modelli linguistici**: oltre a tradurre capiscono il discorso, spiegano le parole nel contesto, trovano i modi di dire e correggono la trascrizione. Google, Microsoft e DeepL sono **traduttori classici**: traducono bene, ma non fanno il resto.

Le chiavi si vedono e si copiano con i pulsanti **Mostra** e **Copia** accanto alla casella (utile per l'add-on di Kodi). Non mostrarle in video o in foto: chi le vede le può usare.

### Servizi di riserva
Quando il servizio scelto ha finito le richieste gratuite di oggi, nel popup sotto "Come tradurre" compare un avviso giallo: dice a che ora tornano (le quote di Gemini si azzerano a mezzanotte della California, verso le 9 in Italia) e quale servizio si usa intanto. Con **"Riprova … adesso"** la traduzione del video riprende subito con il servizio scelto (utile se hai cambiato chiave o modello).
Con **Se finiscono le richieste gratuite, continua con un altro servizio di cui hai la chiave** (attiva di serie), quando un servizio esaurisce la quota del giorno l'estensione continua da sola con il primo altro servizio di cui hai inserito la chiave, in quest'ordine: **Gemini → Groq → Mistral → OpenRouter → Microsoft → DeepL**, e alla fine **Google**. Il servizio esaurito viene saltato fino al giorno dopo.

Per inserire più chiavi: scegli un servizio, incolla la sua chiave, poi torna al servizio che preferisci. Sotto la casella vedi l'elenco dei servizi pronti e di quelli finiti per oggi.

---

## 11. Consumare meno richieste gratuite

- **Niente si traduce due volte**: traduzioni, trascrizioni, spiegazioni e correzioni restano salvate. Rivedere un video, anche guardato solo in parte, non costa niente.
- La traduzione si chiede a **gruppi di 120 frasi**: un film di due ore costa circa 12 richieste a Gemini.
- Al passaggio del mouse si usa il dizionario di Google (gratis); il modello solo quando clicchi.
- Il modello predefinito di Gemini è **gemini-flash-lite-latest**, quello con più richieste gratuite al giorno.
- Le quote di Gemini si azzerano verso le **9 del mattino** (ora italiana). Quanto hai usato lo vedi su aistudio.google.com.
- Per un film intero senza toccare le quote: **Copia trascrizione / Incolla traduzione** con una chat ([sezione 9](#9-la-pagina-trascrizione-e-traduzione)).

---

## 12. Un modello di traduzione sul tuo computer

Gratis, senza limiti e privato. Serve un PC abbastanza potente (16 GB di RAM consigliati).

### Con Ollama
1. Installa Ollama da **ollama.com**.
2. Scarica un modello: `ollama pull gemma3:12b` (o `gemma3:4b` se il PC è meno potente).
3. Permetti le richieste del browser (senza questo passaggio Ollama le rifiuta):
   - **Windows**: nel prompt dei comandi `setx OLLAMA_ORIGINS "chrome-extension://*,moz-extension://*"`, poi chiudi Ollama (icona vicino all'orologio → Quit) e riaprilo;
   - **Mac**: `launchctl setenv OLLAMA_ORIGINS "chrome-extension://*,moz-extension://*"`, poi riapri Ollama;
   - **Linux**: `sudo systemctl edit ollama`, aggiungi `[Service]` e `Environment="OLLAMA_ORIGINS=chrome-extension://*,moz-extension://*"`, poi `sudo systemctl restart ollama`.
4. Nel popup scegli **Modello sul tuo computer** (indirizzo `http://localhost:11434/v1`) e premi **Carica modelli**.

### Con LM Studio
Scarica un modello, nella sezione *Developer* avvia il server e attiva **Enable CORS**. Nel popup scrivi l'indirizzo `http://localhost:1234/v1` e premi **Carica modelli**.

---

## 13. Se qualcosa non va

Guarda prima la **riga di stato in fondo al popup**: dice cosa sta facendo l'estensione e perché si è fermata.

| Cosa vedi | Cosa fare |
|---|---|
| "Nessun segnale da YouTube" | Premi **Concedi accesso** se compare, poi ricarica la pagina. |
| I sottotitoli doppi non compaiono | Controlla che **DS** sia acceso e che il video abbia i sottotitoli (CC) accesi. Su YouTube, se non basta, cambia lingua dei sottotitoli dall'ingranaggio e rimetti quella giusta. |
| "Hai finito i minuti di trascrizione" (Groq) | La quota gratuita di Whisper è finita (all'ora o al giorno): il messaggio dice tra quanto si libera. Le frasi già trascritte restano. |
| "Limite di richieste raggiunto" | Il servizio ha rifiutato perché hai superato la quota: l'estensione aspetta e riprova da sola (al minuto) o passa a un servizio di riserva (al giorno). Non si perde niente. |
| "Chiave non valida" | Ricopia la chiave (pulsante **Mostra** per controllarla). |
| La trascrizione è nella lingua sbagliata | Imposta **Lingua parlata**, poi nella pagina "Trascrizione e traduzione" premi **Rifai la trascrizione**. |
| Una frase è tradotta o trascritta male | Pulsante **⚑** sui sottotitoli → Ritraduci, Ritrascrivi o Correggi a mano. |
| Netflix, Disney+, Prime Video | Non si può: il browser protegge l'audio di questi siti. |
| Firefox: il video resta muto | Clicca una volta sul video. |

---

## 14. Privacy e note

- Le chiavi e tutto quello che salvi (traduzioni, vocabolario, correzioni) restano **nel tuo browser**. Non c'è nessun server dell'estensione.
- I testi vengono mandati solo al servizio che scegli (Google, Gemini, Groq…). Gli strumenti per imparare mandano la parola (e, per il controllo della scrittura, la frase) a Wiktionary, Tatoeba, LanguageTool e Wikimedia Commons; si spengono nel popup. Con i piani gratuiti alcuni servizi (per esempio Gemini) possono usare i testi per migliorare i loro modelli.
- Il programma per yt-dlp scarica l'audio solo per trascriverlo e lo cancella subito.


# 5.12: voce per ogni lingua (⚙ nella scheda), Azure Speech, popup
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=voiceTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        W = lambda t: words.nth(texts.index(t))
        await W("market").click(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-card .dualsub-speak:not(.dualsub-rec)").click(); await pg.wait_for_timeout(1500)
        print("1. senza scelta (nessuna voce nel computer):", await pg.evaluate("document.querySelector('.dualsub-card .dualsub-speak:not(.dualsub-rec)').title"), "| google tts:", len(log.get("tts", [])))
        # Azure: chiave dal popup
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append("popup: " + str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1000)
        await pp.evaluate("document.getElementById('dTts').open=true")
        box = pp.locator("#voicesBox")
        await box.locator("input[type=password]").fill("AZ-SBAGLIATA"); await box.locator("input[type=password]").dispatch_event("change"); await pp.wait_for_timeout(300)
        await box.get_by_role("button", name="Prova la chiave").click(); await pp.wait_for_timeout(1200)
        print("2. chiave sbagliata:", await box.locator("p.small").first.inner_text())
        await box.locator("input[type=password]").fill("AZ-OK"); await box.locator("input[type=password]").dispatch_event("change"); await pp.wait_for_timeout(300)
        await box.get_by_role("button", name="Prova la chiave").click(); await pp.wait_for_timeout(1200)
        print("   chiave giusta:", await box.locator("p.small").first.inner_text(), "| azureTts:", await sw.evaluate("chrome.storage.sync.get('azureTts')"))
        await pg.bring_to_front()
        await pg.locator(".dualsub-card .dualsub-speak:not(.dualsub-rec)").click(); await pg.wait_for_timeout(1500)
        print("3. con Azure acceso:", await pg.evaluate("document.querySelector('.dualsub-card .dualsub-speak:not(.dualsub-rec)').title"), "| richieste:", [(a[1], (a[3] or "")[-80:]) for a in log.get("azure", []) if a[1] == "v1"])
        # ⚙: scelgo Sonia per l'inglese
        await pg.locator(".dualsub-card .dualsub-voicegear").click(); await pg.wait_for_timeout(800)
        items = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .ds-voicemenu-item')].map(b=>b.textContent)")
        print("4. menu voci:", items)
        await pg.locator(".dualsub-card .ds-voicemenu-item", has_text="Sonia").click(); await pg.wait_for_timeout(1500)
        print("   salvata:", await sw.evaluate("chrome.storage.sync.get('ttsVoices')"), "| ultima richiesta Azure:", [(a[3] or "")[-70:] for a in log.get("azure", []) if a[1] == "v1"][-1:])
        await pg.locator(".dualsub-card .dualsub-voicegear").click(); await pg.wait_for_timeout(600)
        await pg.locator(".dualsub-card .ds-voicemenu-item", has_text="Google").click(); await pg.wait_for_timeout(1500)
        print("5. scelta Google:", await sw.evaluate("chrome.storage.sync.get('ttsVoices')"), "| google tts:", len(log.get("tts", [])))
        await pp.reload(); await pp.wait_for_timeout(1200); await pp.evaluate("document.getElementById('dTts').open=true")
        print("6. popup righe:", await pp.evaluate("[...document.querySelectorAll('#voicesBox .row')].map(r=>r.innerText.replace(/\\n/g,' ').slice(0,80))"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# Mettere online il repository Kodi su GitHub, passo per passo

Alla fine avrai un indirizzo internet, **https://iannavax.github.io/kodi-sottotitolidoppi/**, da scrivere una volta sola in ogni Kodi (TV box, Fire TV, computer). Da lì Kodi installa l'add-on Sottotitoli Doppi e lo aggiorna da solo.

Ti servono:
- il file **repository-kodi-da-caricare-su-github.zip** che ti ho consegnato;
- l'account GitHub **iannavax**, con la password;
- Edge o Chrome sul computer (il caricamento di cartelle trascinandole funziona bene con questi due; con Firefox i passi sono gli stessi).

Si fa una volta sola e richiede circa 10 minuti.

---

## Parte 1 – Preparare i file sul computer

1. Trova il file **repository-kodi-da-caricare-su-github.zip** (di solito nella cartella **Download**).
2. Cliccaci sopra con il **tasto destro** → **Estrai tutto…** → **Estrai**.
   Si apre una cartella con lo stesso nome. Dentro devono esserci esattamente questi elementi:

   | Nome | Tipo |
   |---|---|
   | `repository.sottotitolidoppi` | cartella |
   | `script.sottotitolidoppi` | cartella |
   | `addons.xml` | file |
   | `addons.xml.md5` | file |
   | `index.html` | file |
   | `repository.sottotitolidoppi-1.0.0.zip` | file zip |
   | `.nojekyll` | file vuoto (a volte Windows non lo mostra: non importa) |

3. **Attenzione:** dentro ci sono altri file .zip (per esempio `repository.sottotitolidoppi-1.0.0.zip`). **Non estrarli e non aprirli**: Kodi ha bisogno proprio dei file .zip così come sono.
4. Lascia aperta questa cartella: ti servirà nella Parte 3.

---

## Parte 2 – Creare il repository su GitHub

1. Apri **https://github.com** e accedi con l'utente **iannavax** (in alto a destra **Sign in**).
   - Se GitHub chiede un codice di verifica (via email o app), inseriscilo.
   - Se l'indirizzo email dell'account non è mai stato confermato, GitHub potrebbe chiederlo prima di creare repository: apri la sua email e clicca il collegamento di conferma.
2. In alto a destra clicca il pulsante **+** (accanto alla tua immagine del profilo) → **New repository**.
3. Compila la pagina "Create a new repository":
   - **Repository name**: scrivi `kodi-sottotitolidoppi`
     Tutto minuscolo, con il trattino, senza spazi. Deve essere **esattamente** così, perché l'indirizzo del repository è già scritto dentro i file.
   - **Description**: facoltativa (per esempio "Repository Kodi di Sottotitoli Doppi").
   - Scegli **Public**. Con "Private" GitHub Pages gratuito non funziona e Kodi non riuscirebbe a leggere i file.
   - **Non** spuntare "Add a README file", e lascia "None" in ".gitignore" e "license". Il repository deve nascere vuoto.
4. Clicca il pulsante verde **Create repository** in fondo.

---

## Parte 3 – Caricare i file

1. Ora sei nella pagina del repository vuoto. In alto c'è un riquadro "Quick setup". Cerca la frase
   *"Get started by creating a new file or **uploading an existing file**"* e clicca **uploading an existing file**.
2. Si apre una pagina con un grande riquadro "Drag files here to add them to your repository".
3. Torna alla cartella che hai estratto nella Parte 1. Premi **Ctrl+A** per selezionare tutto quello che c'è dentro (le due cartelle e i file). Seleziona il **contenuto** della cartella, non la cartella stessa.
4. Trascina tutto nel riquadro di GitHub e rilascia.
5. Aspetta che finisca il caricamento: sotto il riquadro compare l'elenco dei file. Controlla che ci siano anche quelli dentro le cartelle, per esempio `script.sottotitolidoppi/script.sottotitolidoppi-1.1.0.zip`.
   - Se le due cartelle non compaiono, il browser non le ha accettate trascinandole. In quel caso trascina a parte le cartelle `repository.sottotitolidoppi` e `script.sottotitolidoppi`.
6. In fondo alla pagina, in "Commit changes", lascia il testo proposto (oppure scrivi "Prima pubblicazione") e clicca il pulsante verde **Commit changes**.
7. Dopo qualche secondo torni alla pagina del repository. Devi vedere le cartelle `repository.sottotitolidoppi` e `script.sottotitolidoppi` e i file `addons.xml`, `addons.xml.md5`, `index.html` e `repository.sottotitolidoppi-1.0.0.zip`.
   - Se manca qualcosa: clicca **Add file → Upload files** (in alto a destra nell'elenco dei file), trascina quello che manca e fai di nuovo **Commit changes**.

---

## Parte 4 – Accendere GitHub Pages (rende i file raggiungibili da Kodi)

1. Nella pagina del repository clicca **Settings**: è l'ultima voce nella fila di schede in alto (Code, Issues, Pull requests, … , **Settings**).
2. Nel menu a sinistra, nella sezione "Code and automation", clicca **Pages**.
3. In "Build and deployment":
   - **Source**: deve essere **Deploy from a branch** (se è diverso, sceglilo dal menu).
   - **Branch**: nel primo menu scegli **main**, nel secondo **/ (root)**.
   - Clicca **Save**.
4. Aspetta 1–3 minuti e ricarica la pagina (F5). In alto compare un riquadro:
   *"Your site is live at https://iannavax.github.io/kodi-sottotitolidoppi/"*.
   Se non compare ancora, aspetta un altro minuto e ricarica.

---

## Parte 5 – Controllare che funzioni

1. Apri nel browser **https://iannavax.github.io/kodi-sottotitolidoppi/**
   Deve comparire una pagina semplice con il titolo **"Sottotitoli Doppi per Kodi"** e un collegamento a `repository.sottotitolidoppi-1.0.0.zip`.
2. Apri anche **https://iannavax.github.io/kodi-sottotitolidoppi/addons.xml**
   Deve comparire un testo che contiene `script.sottotitolidoppi` e `version="1.1.0"`.

Se una delle due pagine dà **404**:
- aspetta qualche minuto (la prima pubblicazione può richiedere fino a 10 minuti) e riprova;
- controlla che il nome del repository sia esattamente `kodi-sottotitolidoppi` (Settings → General → Repository name);
- controlla che i file siano nella pagina principale del repository e non dentro un'altra cartella. Per esempio, se vedi una sola cartella `repository-kodi-da-caricare-su-github` con tutto dentro, hai trascinato la cartella invece del suo contenuto. In quel caso cancella il repository (Settings → in fondo "Delete this repository") e ricomincia dalla Parte 2.

---

## Parte 6 – Installare in Kodi (su ogni dispositivo)

1. Kodi → **Impostazioni** (l'ingranaggio) → **Sistema** → **Add-on** → attiva **Sorgenti sconosciute** e conferma con **Sì**.
2. Torna a **Impostazioni** → **File manager** → **Aggiungi sorgente** → clicca **<Nessuno>** e scrivi, esattamente:
   `https://iannavax.github.io/kodi-sottotitolidoppi/`
   (con la barra finale). Premi **OK**. Come nome scrivi `sottotitolidoppi`, poi **OK**.
3. **Impostazioni** → **Add-on** → **Installa da un file zip** → **sottotitolidoppi** → **repository.sottotitolidoppi-1.0.0.zip**.
   In alto a destra compare "Add-on installato".
4. Nella stessa pagina: **Installa da repository** → **Sottotitoli Doppi (repository)** → **Add-on programmi** → **Sottotitoli Doppi** → **Installa**.
5. Apri le impostazioni dell'add-on e scegli lingua e servizio, come spiegato nel LEGGIMI dell'add-on.

### Se compare "Could not connect to repository" (Impossibile connettersi al repository)

I file su GitHub sono giusti: li ho controllati (cartelle, `addons.xml` e somma di controllo corrispondono). Il problema è quindi tra Kodi e internet. Prova in quest'ordine:

1. **Aspetta 10 minuti e riavvia Kodi** (chiudilo del tutto e riaprilo). Se Kodi ha provato a collegarsi prima che il sito fosse online, può aver tenuto in memoria l'errore; anche GitHub tiene in memoria per qualche minuto la pagina "non trovato".
2. **Controlla data e ora del dispositivo** (Impostazioni del TV box o di Android → Data e ora → automatiche). Se la data è sbagliata, i collegamenti https non funzionano.
3. **Controlla che Kodi raggiunga il sito**: Impostazioni → File manager → apri la sorgente `sottotitolidoppi`. Devi vedere le cartelle e i file del repository. Se non si apre o è vuota, quel dispositivo non riesce a collegarsi a GitHub (rete, DNS o un blocco del fornitore).
4. **Controlla la versione di Kodi**: Impostazioni → Informazioni di sistema. Serve Kodi **19 (Matrix) o più recente**.
5. Se ancora non va, mandami il registro di Kodi: Impostazioni → Sistema → Registrazione → attiva **Abilita registrazione di debug**, riprova ad aprire il repository, poi installa dal repository ufficiale di Kodi l'add-on **Kodi Logfile Uploader** (Add-on → Installa da repository → Kodi Add-on repository → Add-on programmi), aprilo e premi **Invia**: ti dà un indirizzo da copiarmi.

**Intanto puoi installare l'add-on anche senza repository** (ma senza aggiornamenti automatici): Impostazioni → Add-on → **Installa da un file zip** → `sottotitolidoppi` → cartella `script.sottotitolidoppi` → `script.sottotitolidoppi-1.1.0.zip`.

---

## Quando ti consegno una versione nuova dell'add-on

Ti consegno anche un nuovo `repository-kodi-da-caricare-su-github.zip`.

1. Estrailo come nella Parte 1.
2. Apri il repository su GitHub → **Add file** → **Upload files**.
3. Trascina di nuovo **tutto il contenuto** della cartella. GitHub sostituisce i file con lo stesso nome e aggiunge quelli nuovi, per esempio il nuovo `script.sottotitolidoppi-1.2.0.zip`.
4. **Commit changes**.
5. Dopo qualche minuto i Kodi si aggiornano da soli, di solito entro un giorno. Per farlo subito: in Kodi, **Add-on → Il mio add-on → Repository di add-on → Sottotitoli Doppi (repository)** → tasto menu (o tasto destro) → **Controlla aggiornamenti**.

Non serve rifare le Parti 2, 4, 5 e 6: si fanno una volta sola.

---

Per rifare la cartella da zero sul computer (serve Python): `python3 crea_repository.py iannavax`.

import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', transcribeMode:'live'})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsLang"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_timeout(72000)
        await pg.wait_for_timeout(12000)
        dbg = json.loads(await pg.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))
        print("richieste a Whisper (pezzo, lingua chiesta, risultato):")
        for r in log["groq_req"]: print("  ", r)
        print("frasi sul video:")
        for c in dbg: print(f"  {c['start']/1000:5.1f}s [{c['lang']}] {'(TOLTA) ' if c['removed'] else ''}{c['text'][:55]:55} | {(c['trans'] or '')[:40]}")
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

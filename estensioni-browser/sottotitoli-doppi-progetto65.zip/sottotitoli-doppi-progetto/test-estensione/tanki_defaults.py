# 1.7.25: di serie le immagini per Anki sono accese e vengono da Google Immagini
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1200)
        on = await pp.evaluate("document.getElementById('ankiImage').checked")
        src = await pp.evaluate("document.getElementById('ankiImageSource').value")
        opts = await pp.evaluate("[...document.querySelectorAll('#ankiImageSource option')].map(o => o.textContent)")
        print("immagini accese:", on, "| fonte:", src, "|", opts)
        print("errori:", errs if on and src == "google" else errs + ["i valori di serie non sono quelli voluti"], log["errors"])
        await ctx.close()
asyncio.run(main())

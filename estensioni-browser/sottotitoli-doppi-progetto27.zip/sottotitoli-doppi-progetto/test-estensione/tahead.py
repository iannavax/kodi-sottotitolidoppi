# 5.20: diretta in anticipo. yt-dlp (finto) legge l'audio della diretta 15 s più avanti del video; l'estensione lo mette
# a tempo con il video confrontando i volumi, trascrive in anticipo e mostra le frasi in orario.
# Confronto: con la trascrizione normale le frasi compaiono qualche secondo dopo l'inizio del parlato.
import asyncio, os, sys, subprocess, shutil, time, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
PROFILE = "/tmp/pwprofile-ahead"
MODE = os.environ.get("MODE", "ahead")
# inizio di ogni "frase" dell'audio di prova (crea_audio.py: durate, ognuna seguita da 0,6 s di pausa)
DUR = [2.6, 3.8, 1.9, 5.2, 3.1, 16.0, 2.4, 4.4, 3.0, 2.2, 3.6, 2.8, 4.0, 3.3]
STARTS = []; t = 0
for d in DUR: STARTS.append(t); t += d + 0.6
async def main():
    shutil.rmtree(PROFILE, ignore_errors=True); shutil.rmtree("/tmp/sdhome-ahead", ignore_errors=True)
    os.makedirs("/tmp/sdhome-ahead", exist_ok=True)
    env = dict(os.environ, FAKE_LIVE_OFFSET=os.environ.get("FAKE_LIVE_OFFSET", "15"), FAKE_LOG="/tmp/fake-ytdlp.log")
    async with async_playwright() as p:
        ctx, sw = await launch(p, PROFILE, env)
        ext = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, liveAhead:%s}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test'}}))" % ("true" if MODE == "ahead" else "false"))
        errs = []
        if MODE == "ahead":
            hp = await ctx.new_page()
            await hp.goto(f"chrome-extension://{ext}/helper.html"); await hp.wait_for_timeout(1000)
            await hp.select_option("#os", "linux")
            async with hp.expect_download() as d:
                await hp.click("#download")
            path = await (await d.value).path()
            r = subprocess.run(["sh", path], capture_output=True, text=True, env=dict(os.environ, HOME="/tmp/sdhome-ahead",
                SD_YTDLP_URL="file:///home/claude/e2e/fake/yt-dlp", SD_DENO_URL="file:///tmp/fakedeno.zip", SD_EXTRA_CHROME_DIRS=PROFILE + "/NativeMessagingHosts"))
            print("installatore:", r.returncode, "|", [l.strip() for l in r.stdout.splitlines() if "ffmpeg" in l])
            await hp.close()
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        if os.environ.get("DEBUG"): pg.on("console", lambda m: print("   CONSOLE", m.text) if "ALLINEA" in m.text else None)
        await pg.goto("https://www.youtube.com/embed/direttaAhead?autoplay=1"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        shown, statuses = [], []
        for i in range(int(os.environ.get("SECS", "60")) * 5):
            txt = await pg.evaluate("(document.querySelector('.dualsub-overlay:not([hidden]) .dualsub-orig')||{}).textContent||''")
            vt = await pg.evaluate("document.querySelector('video').currentTime")
            st = await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text||'')")
            if st and (not statuses or statuses[-1] != st): statuses.append(st)
            if os.environ.get("DEBUG") and i % 25 == 0: print("   DBG", round(vt, 1), await pg.evaluate("document.documentElement.dataset.aheadDebug||''"))
            if txt and (not shown or shown[-1][1] != txt):
                cues = json.loads(await pg.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))
                c = next((c for c in reversed(cues) if c.get("text") == txt), None)
                shown.append((vt, txt, c["start"] / 1000 if c else None))
            await pg.wait_for_timeout(200)
        for s_ in statuses: print("  stato:", s_[:120])
        late = []
        for vt, txt, cs in shown:
            d = round(vt - cs, 1) if cs is not None else None
            if d is not None and vt > 30: late.append(d)
            print(f"  mostrata a {vt:5.1f} s, la frase inizia a {cs if cs is None else round(cs, 1)} s  (ritardo {d} s)  {txt[:30]}")
        print(MODE, "| ritardo medio delle frasi dopo 30 s:", round(sum(late) / max(1, len(late)), 2), "s su", len(late), "frasi | pezzi a Whisper:", len(log["groq"]))
        if os.environ.get("SHOWLOG"): print("\n".join(json.loads(await pg.evaluate("document.documentElement.dataset.dsLiveLog||'[]'"))))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

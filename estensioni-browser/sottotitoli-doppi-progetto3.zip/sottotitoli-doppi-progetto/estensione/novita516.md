## Novità della 5.16.1
- **Spiegazioni del modello controllate**: se il "significato" è la parola stessa non tradotta o la spiegazione è in un'altra lingua (per esempio in arabo per una parola russa), si riprova una volta con istruzioni più rigide; se è ancora sbagliata, quella parte si toglie e il significato lo dà Google (la scheda lo scrive accanto alla fonte). Nel prompt ora c'è anche il nome della lingua della parola.
- **Immagine nelle carte di Anki**: l'opzione ora è nel popup → **Anki** ("Metti un'immagine nelle carte di Anki"), insieme all'invio automatico con ☆.

## Novità della 5.16
- **Quando Gemini (o il servizio scelto) finisce le richieste gratuite di oggi**, il popup lo dice chiaramente sotto "Come tradurre": a che ora tornano (verso le 9), quale servizio di riserva si usa intanto, e il pulsante **"Riprova Gemini adesso"**. Premendolo la traduzione del video riprende subito con Gemini.
- **Stessi servizi e stessa sezione in Parole al Volo**: Google, Gemini, Groq, OpenRouter, Mistral, Microsoft, DeepL, un modello sul tuo computer e Claude, con chiave, modello, "Carica modelli" e servizi di riserva, come qui.
- Nella scheda della parola, mentre si aspetta la spiegazione del modello, non compare più due volte l'elenco delle traduzioni.

*Versione 1.13.0*

# Parole al Volo — estensione per il browser

Traduce le parole di **qualsiasi pagina** mentre leggi: passi il mouse su una parola e compare la sua scheda, selezioni un pezzo di testo e te lo traduce tutto insieme. È la sorella di Sottotitoli Doppi: stesse schede, stessa pronuncia, stesso vocabolario per Anki, ma per i testi invece che per i video.

## 1. Cosa fa
- **Passando il mouse su una parola** (dopo un attimo fermo) compare la scheda con:
  - la parola, la sua traduzione e le altre traduzioni del dizionario di Google (nomi, verbi…);
  - la **pronuncia IPA** (alfabeto fonetico internazionale, per esempio *bread* → /brɛd/);
  - per le lingue con un altro alfabeto (russo, greco, giapponese, cinese, arabo…) la **trascrizione in caratteri latini** (*кошка* → koshka);
  - l'**etimologia**: da dove viene la parola, da Wiktionary (gratis), tradotta nella tua lingua (se manca, la porta "Spiega con Gemini" insieme alla spiegazione);
  - la **frase** in cui si trova la parola, con la sua traduzione;
  - 🔈 per ascoltare la parola con la voce sintetica e, quando esiste una registrazione vera (Wiktionary), accanto 🔊 con la voce di una persona; "🔈 frase" e "🔈 lenta" per ascoltare la frase intera (voce sintetica). Sempre: **🔊** = registrazione vera, **🔈** = voce sintetica;
  - ☆ per salvarla nel **vocabolario**, **Anki** per mandarla subito ad Anki;
  - "Copia", "Copia la frase" e i collegamenti a Google Traduttore, DeepL, Reverso, WordReference e Wiktionary.
- **Strumenti per imparare** (tutti gratis, ognuno si spegne nel popup → "Strumenti per imparare"):
  - **dizionario di Google** (stessa richiesta della traduzione): traduzioni con il loro peso (la più usata in evidenza; passando il mouse le traduzioni al contrario), definizioni nella lingua della parola con un esempio, sinonimi e "vedi anche", "Forse cercavi…" nel controllo della scrittura;
  - **definizioni anche dal Wiktionary della lingua della parola** (e da quello inglese se mancano), ognuna con **traduci**, gratis;
  - **frequenza** della parola ("molto comune · tra le 1000 più usate", "rara"…): cliccandola si apre l'elenco delle parole più usate della lingua, con la posizione della parola;
  - **«la conosco?»**: segna le parole che sai già. Nel popup leggi **quante parole della pagina conosci** (in percentuale); se accendi "Colora sulla pagina le parole che conosco" diventano verde chiaro nel testo;
  - **genere** dei nomi (in tedesco con der/die/das);
  - per il **giapponese**, dal dizionario Jisho: lettura in kana, livello JLPT, parola comune, significato in inglese;
  - **kanji e caratteri cinesi uno per uno**: nella scheda di una parola giapponese o cinese c'è un pulsante per ogni carattere; cliccandolo vedi solo quel kanji, con le stesse informazioni in ogni lingua (significato, letture on/kun, pinyin, cantonese, coreano, vietnamita, parti e radicale cliccabili, forme semplificata/tradizionale, tratti, JLPT, HSK) e con «scheda del carattere ›» lo apri come una parola, per salvarlo nel vocabolario o in Anki ("‹ Torna alla parola" per tornare indietro); «☆ salva tutti i kanji» mette nel vocabolario ogni carattere della parola; con **Aa** sopra i kanji compare la lettura della parola (da Jisho o Google, divisa tra kanji e kana: 食べる → ta·be·ru);
  - **scrittura**: se la parola è scritta bene (LanguageTool o dizionario; con "Spiega con Gemini" anche un voto da 0 a 100 e la forma corretta);
  - **▦ tabella** di coniugazione o declinazione (Wiktionary);
  - **esempi veri** da Tatoeba, con traduzione e spesso con la registrazione di un madrelingua (🔊; 🔈 = voce sintetica);
- Con una chiave di **Gemini o Groq**, il pulsante **"Spiega con Gemini"** (una sola richiesta) dà il significato della parola *in quella frase*, la forma base (per esempio *went* → go), se fa parte di un modo di dire, e un esempio; nella stessa richiesta anche l'etimologia (se Wiktionary non l'ha), la pronuncia IPA (se accesa e mancante), i **falsi amici**, le **parole parenti** e il voto alla scrittura.
- **Selezionando più parole** (trascinando con il mouse) compare il pannello con la traduzione di tutto il testo insieme, la trascrizione in caratteri latini, il pulsante **Pronuncia IPA** (solo se lo premi), 🔊 per ascoltarlo, ☆ e Anki. Con Gemini o Groq c'è anche **"Traduci meglio"**, una traduzione che tiene conto del contesto.
- **Doppio clic su una parola**: la sua scheda, che resta aperta.
- **⚑ Traduzione sbagliata?** In fondo alla scheda e al pannello del testo selezionato: **↻ Rifai con Google** (traduzione nuova), **Rifai con Gemini/Groq** (significato nel contesto e traduzione della frase, una richiesta), **✎ Correggi a mano** (scrivi tu la traduzione giusta: resta salvata e la ritrovi le volte dopo, segnata con ✎; "Togli la correzione" per tornare indietro), **Lingua sbagliata**.
- **Voce per ogni lingua**: ⚙ accanto a 🔈 apre le voci per quella lingua; quella che scegli resta salvata. Con una chiave gratuita di **Azure Speech** (popup → Voce) anche in Firefox si usano le voci "Natural" di Microsoft, in quasi tutte le lingue.
- I testi già nella tua lingua vengono ignorati: passando il mouse su un articolo in italiano non compare niente.
- **Lingua riconosciuta male?** In fondo alla scheda (e al pannello del testo selezionato) c'è "Lingua del testo: … — **sbagliata? cambia**": cerca la lingua giusta (per esempio "ceco"), premi Invio e la traduzione viene rifatta da quella lingua. Con **Ricorda per questo sito** la scelta vale per tutte le pagine del sito.

Le schede si chiudono con **Esc**, con un clic fuori, o allontanando il mouse (se ci entri dentro restano aperte).

## 2. Installazione e aggiornamenti
**Edge, Chrome, Brave:** estrai lo zip in una cartella che non cancellerai. Apri `edge://extensions` (o `chrome://extensions`), accendi **Modalità sviluppatore**, premi **Carica estensione decompressa** e scegli la cartella.
Per aggiornare: copia i file nuovi **nella stessa cartella** e premi il pulsante ↻ dell'estensione. Non rimuoverla: perderesti vocabolario, chiavi e pronunce salvate.

**Firefox (Nightly o Developer Edition):** in `about:config` imposta `xpinstall.signatures.required` su `false`, poi apri `about:addons`, ingranaggio → **Installa componente aggiuntivo da file** e scegli il file `.xpi`. Per aggiornare installa il nuovo `.xpi` sopra il vecchio.

## 3. Il popup (clic sull'icona)
- L'interruttore in alto accende e spegne tutto. Lo stesso con la tastiera: **Alt+Maiusc+Y**.
- Subito sotto ci sono i due interruttori principali, che si usano separatamente:
  - **Scheda passando il mouse**: la scheda che compare fermandoti su una parola. Tastiera: **Alt+Maiusc+M**.
  - **Traduzione quando evidenzi**: il pannello che traduce il testo che selezioni. Tastiera: **Alt+Maiusc+S**.

  Si spengono anche dalla scheda stessa ("Spegni la scheda al passaggio del mouse") e dal pannello ("Spegni la traduzione quando evidenzi"). Quando li cambi compare per un attimo un avviso in basso sulla pagina. Con la scheda del mouse spenta, un **doppio clic** su una parola apre comunque la sua scheda (se la traduzione quando evidenzi è accesa). Le scorciatoie si possono cambiare in `edge://extensions/shortcuts` (Chrome: `chrome://extensions/shortcuts`; Firefox: about:addons → ⚙ → Gestisci scorciatoie delle estensioni).
- **Attiva su questo sito**: per spegnerla solo su un sito.
- **Traduci in**: la tua lingua.
- **Lingua del testo**: di solito *riconosciuta da sola*; se sbaglia spesso, scegli qui la lingua giusta per tutti i siti. **Lingua del testo su (sito)**: la stessa cosa solo per il sito aperto (vince su quella generale).
- **La scheda compare**: *subito* oppure *solo tenendo premuto Alt* (comodo se ti disturba mentre leggi).
- **Attesa prima della scheda**: quanto tempo fermo sulla parola prima che compaia.
- **Traduzione della frase nella scheda**, **Pronuncia IPA (usa token)**, **Etimologia della parola**: si accendono e spengono qui. Con la pronuncia IPA spenta non si vede e non si chiede mai (zero token); nella scheda c'è anche "spegni IPA".
- **Traduzione e chiavi**: lo stesso elenco di servizi di Sottotitoli Doppi, con chiave, modello e servizi di riserva. Con Google tutto è gratis; con Gemini, Groq o un altro modello compaiono «Spiega con…» e «Traduci meglio»; con DeepL o Microsoft traducono loro la frase e il testo selezionato. Le chiavi sono le stesse di Sottotitoli Doppi (lì le copi con "Copia").
- **Voce**: automatica (quella del computer nella lingua giusta, altrimenti Google), sempre Google, o una voce precisa. Si può far pronunciare la parola appena compare la scheda.
- **Anki**: mazzo in cui mettere le carte, invio automatico quando salvi con ☆, prova del collegamento.

## 4. Quante richieste consuma
- **Google** (significato, traduzione della frase e del testo, trascrizione in caratteri latini, voce): gratis, nessuna chiave.
- **Pronuncia IPA**: da **Wiktionary** (gratis, nessun token), sempre. Se non c'è, la scrive Gemini o Groq solo dentro la richiesta di «Spiega con…» (se nel popup è accesa "IPA anche dal modello"). Si chiede **solo la parola che guardi**, quando la scheda resta aperta almeno un attimo (passando veloce sopra le parole non parte niente), prima a Gemini e poi a Groq; per un testo selezionato solo se premi il pulsante. Le pronunce restano salvate (fino a 30.000 parole). Se non hai chiavi la pronuncia non compare; puoi anche spegnerla nel popup (resta il pulsante per chiederla).
- **Spiega nel contesto** e **Traduci meglio**: una richiesta ogni volta che premi il pulsante, mai da sole.

## 5. Vocabolario e Anki
Il pulsante **Il mio vocabolario** nel popup apre l'elenco di quello che hai salvato con ☆: parole (con frase, traduzione, IPA, genere, pagina da cui vengono) e pezzi di testo. Puoi cercare, segnare come imparate (contano anche tra le parole che conosci), eliminare.

**Anki, invio diretto (consigliato):**
1. In Anki: Strumenti → Componenti aggiuntivi → Scarica componenti aggiuntivi, codice **2055492159** (AnkiConnect). Riavvia Anki.
2. Con Anki aperto, premi **Anki** su una scheda (o **Manda ad Anki** nel vocabolario). La prima volta Anki chiede in una sua finestra se permettere l'accesso: premi **Yes**.
3. Se nel popup accendi **Immagine nelle carte di Anki** (spenta di serie), la carta riceve anche un'immagine della parola presa da Wikimedia Commons.
4. Le carte vanno nel mazzo della loro lingua ("Lingue::Inglese", "Lingue::Ceco"…: gli stessi mazzi di Sottotitoli Doppi), oppure in un mazzo unico se nel popup togli "Un mazzo per ogni lingua" (predefinito "Parole al Volo"), con il tipo di nota Base: sul fronte la parola con la frase, sul retro traduzione, IPA, trascrizione e frase tradotta, con il collegamento alla pagina. Le carte già presenti non vengono duplicate.

**Anki senza AnkiConnect:** nel vocabolario premi **Esporta file per Anki**, poi in Anki File → Importa e scegli il file.

## 6. Insieme a Sottotitoli Doppi
Le due estensioni possono stare accese insieme: Parole al Volo non tocca i sottotitoli di Sottotitoli Doppi (lì restano le sue schede). Chiavi e vocabolario sono separati.

## 7. Se qualcosa non va
- **Non compare niente**: controlla l'interruttore generale, i due interruttori "Scheda passando il mouse" e "Traduzione quando evidenzi" e "Attiva su questo sito" nel popup; nelle pagine interne del browser (impostazioni, negozio delle estensioni, PDF) le estensioni non possono funzionare. Dopo l'installazione ricarica le pagine già aperte. In Firefox controlla anche `about:addons` → Parole al Volo → **Permessi**: deve essere acceso "Accedere ai dati su tutti i siti".
- **Niente IPA**: serve la chiave di Groq o Gemini nel popup ("Spiegazioni e chiavi").
- **Anki non risponde**: Anki deve essere aperto, con AnkiConnect installato; se la finestra del permesso è stata chiusa con "No", riprova con "Prova il collegamento con Anki".
- **Dentro le caselle di testo** la scheda non compare (per non disturbare mentre scrivi).

## 8. Privacy
Le parole e le frasi su cui passi il mouse vengono mandate a Google Traduttore (e, se le usi, a Gemini o Groq) per la traduzione; gli strumenti per imparare mandano la parola (e la frase, per il controllo della scrittura) a Wiktionary, Tatoeba, LanguageTool e Wikimedia Commons. Chiavi, vocabolario e pronunce restano nel tuo browser. Anki riceve le carte solo sul tuo computer (127.0.0.1).

## Novità
- **1.9.1**: le spiegazioni del modello vengono controllate (parola non tradotta o spiegazione in un'altra lingua → si riprova, poi Google); l'opzione dell'immagine per Anki è nella sezione Anki del popup.
- **1.9**: nel popup "Traduzione e chiavi" gli stessi servizi di Sottotitoli Doppi (Google, Gemini, Groq, OpenRouter, Mistral, Microsoft, DeepL, modello sul computer, Claude) con chiave, modello e servizi di riserva. Se Gemini finisce le richieste di oggi, la scheda e il popup lo dicono, si usa il servizio di riserva e c'è "Riprova Gemini". Con DeepL o Microsoft la frase e il testo selezionato li traducono loro.
- **1.13.0**: le schede e i colori di Parole al Volo non compaiono sopra i sottotitoli di Sottotitoli Doppi (e le pagine con un video non vengono più ricolorate di continuo); pronta anche come parte dell'estensione unica «Sottotitoli Doppi + Parole al Volo».
- **1.12.0**: kanji e caratteri cinesi uno per uno nella scheda della parola, con le stesse informazioni per giapponese, cinese e coreano (gratis, senza Gemini/Groq); salvataggio dei singoli kanji; **Aa** ora scrive la lettura anche sopra i kanji; la scheda resta attaccata alla parola quando scorri la pagina (prima, guardando le foto, scendeva sempre più giù).
- **1.11.2**: in giapponese si possono evidenziare anche le sillabe che Firefox non considera parole (は, い…).
- **1.11.1**: **⇄ Sincronizza adesso** nella pagina delle parole più usate (parole conosciute) e nel vocabolario (anche le voci): passa tutto da Parole al Volo a Sottotitoli Doppi e viceversa con un clic, senza file. Su Edge/Chrome la prima volta il browser chiede il permesso di vedere le estensioni installate.
- **1.11**: «JLPT N5 ›» nella scheda apre tutte le parole di quel livello JLPT (Jisho), con «la conosco?»; per tutte le lingue «livello ≈ B1 ›» (indicativo, dalla frequenza) apre le parole di quel livello nell'elenco delle più usate, che ora ha la barra dei livelli A1…C2.
- **1.10**: definizioni nella lingua della parola anche dal Wiktionary di quella lingua (o inglese), con «traduci». **Modi di dire**: il modello li cerca da solo nella frase quando la scheda resta aperta (una richiesta piccola per frase, una volta; si spegne nel popup), vengono sottolineati in arancione su tutte le pagine e si correggono con ⚑. Parole del vocabolario sottolineate in celeste sulla pagina. Lettere latine sopra le lettere della parola (**Aa** nella scheda). Immagini di Anki che arrivano davvero, da vedere e cambiare prima di salvare (‹ ›, altre…, ✕) e nel vocabolario (🖼); fonti nel popup. «Parole che conosco» nel popup: elenco per frequenza con esporta/importa; ⇄ nel vocabolario per scambiare tutto con Sottotitoli Doppi. Pronuncia IPA sempre della parola esatta; 🔊* arancione = registrazione di un'altra forma. Si possono selezionare anche le parole di una lettera.
- **1.8**: pronuncia IPA da Wiktionary sempre (anche con l'IPA del modello spenta); se manca, la porta «Spiega con…» nella stessa richiesta, insieme a una traduzione migliore della frase. Definizioni traducibili, sinonimi e "vedi anche" cliccabili. Tolto il pulsante Anki (resta ☆ con l'invio automatico dal popup). Vocabolario nuovo, uguale a quello di Sottotitoli Doppi (ascolto, esempi, filtro per lingua, "Cosa mostrare").
- **1.7.1**: le registrazioni di Wiktionary si trovano anche quando la pagina ha solo il collegamento al file, e si cercano anche nel Wiktionary della lingua della parola (per esempio *примечание* nel Wiktionary russo).
- **1.7**: dizionario di Google nella scheda: traduzioni con il loro peso e al contrario, definizioni nella lingua originale, sinonimi, "vedi anche", "Forse cercavi…" (gratis, nessuna richiesta in più; ognuno si spegne nel popup).
- **1.6**: un mazzo Anki per ogni lingua ("Lingue::Inglese"…), gli stessi di Sottotitoli Doppi; etimologia tradotta senza tradurre le parole straniere citate, pulsante "originale" e ⚑ per correggerla; il badge della frequenza apre l'elenco delle parole più usate con la posizione della parola.
- **1.5**: ⚑ traduzione sbagliata (rifai con Google o con il modello, o correggi a mano: la correzione resta salvata); voce scelta per ogni lingua (⚙ nella scheda e nel popup); voci naturali di Microsoft con Azure Speech, anche in Firefox. Tolta la dicitura "prova".
- **1.4.6**: nelle tabelle di Wiktionary la traslitterazione in alfabeto latino è separata dalla parola (sotto, più piccola), non più attaccata.
- **1.4.5**: pronuncia IPA cercata in tutte le edizioni di Wiktionary (inglese, poi quella della lingua della parola, la tua e le più grandi) prima di chiederla al modello; per il giapponese il dizionario Jisho (lettura in kana, livello JLPT, significato).
- **1.4.4**: la pronuncia IPA si prende prima da Wiktionary (gratis, senza token, anche senza chiavi); Gemini o Groq solo se lì manca.
- **1.4.3**: in alto nella scheda 🔊 (registrazione vera, quando c'è) accanto a 🔈 (voce sintetica), al posto del pulsante "madrelingua"; icone uguali ovunque (🔊 = persona, 🔈 = voce sintetica). Corretto "Spiega con Groq" che non dava risposta: la richiesta superava il limite al minuto di Groq.
- **1.4.2**: esempi di Tatoeba con la registrazione del madrelingua tramite l'API ufficiale di Tatoeba; se per una parola non ci sono frasi registrate, la scheda lo dice.
- **1.4.1**: gli esempi di Tatoeba usano la registrazione del madrelingua (prima si chiedono le frasi registrate). Le parole spezzate dalla pagina (accento colorato come *Дореф<b>о́</b>рменная*, una parte in corsivo) diventano una parola sola; selezionando una parola con il triplo clic o una cella di tabella ora compare la sua scheda e non solo la traduzione.
- **1.4**: strumenti per imparare nella scheda (frequenza, parole che conosci con percentuale e colore sulla pagina, genere, controllo della scrittura, pronuncia di madrelingua, tabelle, esempi veri da Tatoeba, frase lenta); falsi amici e parole parenti nella stessa richiesta di "Spiega con"; immagine facoltativa nelle carte di Anki. Corretto: le parole russe con l'accento tonico o trattini invisibili (*Дорефо́рменная*) aprivano solo la traduzione invece della scheda.
- **1.3.1**: un solo pulsante "Spiega con Gemini" che con una richiesta porta significato nel contesto, etimologia (se manca) e pronuncia (se accesa).
- **1.3**: etimologia della parola nella scheda (Wiktionary, gratis, tradotta; si accende e spegne nel popup). Pronuncia IPA spenta = non si vede e non si chiede mai; "spegni IPA" nella scheda.
- **1.2**: si può correggere la lingua del testo quando viene riconosciuta male: dalla scheda ("sbagliata? cambia", anche per tutto il sito) e dal popup (per tutti i siti o per il sito aperto).
- **1.1.3**: la pronuncia IPA si chiede solo per la parola che guardi (non più per tutta la frase) e solo se la scheda resta aperta almeno 0,8 secondi; per il testo selezionato solo con il pulsante. Molti meno token.
- **1.1.2**: la pronuncia IPA si chiede prima a Gemini e poi a Groq; se uno dei due ha raggiunto il limite si passa subito all'altro.
- **1.1.1**: il pulsante "Mostra la pronuncia IPA" non faceva niente con il giapponese (il modello riscriveva le parole in un'altra forma, o le saltava). Ora funziona; provato con cinese, giapponese, coreano, arabo, ebraico, greco, thai, hindi, russo, ucraino, ceco, danese, tedesco, vietnamita e turco. La scheda su cui hai cliccato non viene più sostituita dalla parola che resta sotto il mouse.
- **1.1**: interruttori separati per la scheda passando il mouse e per la traduzione quando evidenzi (popup, scorciatoie Alt+Maiusc+M e Alt+Maiusc+S, pulsante dentro la scheda e il pannello), con un avviso sulla pagina quando cambiano.
- **1.0**: prima versione.

import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', hoverPause:true})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console: " + m.text) if m.type == "error" else None)
        await pg.goto("https://www.youtube.com/watch?v=idiomTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'') && document.querySelectorAll('.dualsub-tword').length>1", timeout=30000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
        print("frase:", await pg.inner_text(".dualsub-orig"), "|", await pg.inner_text(".dualsub-trans"))
        words = pg.locator(".dualsub-orig .dualsub-word")
        texts = await words.all_inner_texts()
        W = lambda t: words.nth(texts.index(t))
        # 1. fermandomi sui sottotitoli parte una richiesta (allineamento + modi di dire)
        await W(texts[0]).hover(); await pg.wait_for_timeout(8000)
        print("1. richieste di allineamento:", len(log.get("align", [])), "| parole sottolineate:", await pg.evaluate("[...document.querySelectorAll('.dualsub-idiom')].map(x=>x.textContent)"))
        # 2. passo su 'bread': si illumina tutta l'espressione e la scheda la spiega senza richieste
        await pg.mouse.move(600, 40); await pg.wait_for_timeout(300)
        n0 = len(log["gcalls"])
        await W("bread").hover(); await pg.wait_for_timeout(900)
        print("2. illuminate:", await pg.evaluate("[...document.querySelectorAll('.dualsub-idiom-on')].map(x=>x.textContent)"),
              "| scheda:", await pg.evaluate("(document.querySelector('.dualsub-card-word')||{}).textContent"), "=",
              await pg.evaluate("(document.querySelector('.dualsub-card-meaning')||{}).textContent"), "| richieste a Gemini:", len(log["gcalls"]) - n0)
        # 3. clic: spiegazione dell'espressione intera nel contesto
        await W("bread").click(); await pg.wait_for_timeout(9000)
        print("3. clic → chiesto al modello:", log.get("expr"), "| scheda:", await pg.evaluate("(document.querySelector('.dualsub-card-meaning')||{}).textContent"))
        btn = pg.locator(".dualsub-card-link")
        print("   pulsante:", await btn.all_inner_texts())
        await btn.first.click(); await pg.wait_for_timeout(1500)
        print("   'solo la parola' → scheda per:", await pg.evaluate("(document.querySelector('.dualsub-card-word')||{}).textContent"))
        await pg.keyboard.press("Escape"); await pg.wait_for_timeout(300)
        # 4. selezione a mano trascinando da 'bought' a 'some'
        b1 = await W("bought").bounding_box(); b2 = await W("some").bounding_box()
        await pg.mouse.move(b1["x"] + 5, b1["y"] + b1["height"] / 2); await pg.mouse.down()
        await pg.mouse.move(b1["x"] + b1["width"] + 4, b1["y"] + b1["height"] / 2, steps=3)
        await pg.mouse.move(b2["x"] + 5, b2["y"] + b2["height"] / 2, steps=4)
        print("4. durante il trascinamento:", await pg.evaluate("[...document.querySelectorAll('.dualsub-sel')].map(x=>x.textContent)"))
        await pg.mouse.up(); await pg.wait_for_timeout(9000)
        print("   scheda:", await pg.evaluate("(document.querySelector('.dualsub-card-word')||{}).textContent"), "=",
              await pg.evaluate("(document.querySelector('.dualsub-card-meaning')||{}).textContent"),
              "| selezione visibile:", await pg.evaluate("[...document.querySelectorAll('.dualsub-sel')].map(x=>x.textContent)"),
              "| testo del browser selezionato:", repr(await pg.evaluate("String(getSelection())")))
        await pg.keyboard.press("Escape"); await pg.wait_for_timeout(300)
        print("   dopo Esc: selezione", await pg.evaluate("document.querySelectorAll('.dualsub-sel').length"), "| scheda", await pg.evaluate("!!document.querySelector('.dualsub-card')"))
        # 5. un clic normale su una parola funziona ancora
        await W("really").click(); await pg.wait_for_timeout(9000)
        print("5. clic su 'really' → scheda:", await pg.evaluate("(document.querySelector('.dualsub-card-word')||{}).textContent"),
              "| clic arrivati al lettore:", await pg.evaluate("window.__playerClicks||0"), "| video in pausa:", await pg.evaluate("document.querySelector('video').paused"))
        # 6. salvo l'espressione nel vocabolario
        await pg.keyboard.press("Escape"); await W("bread").click(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-star").click(); await pg.wait_for_timeout(800)
        v = await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab||{}).map(e=>e.word))")
        print("6. vocabolario:", v)
        # 7. clic su una parola che fa parte di un modo di dire non ancora noto: il modello lo segnala
        await pg.keyboard.press("Escape"); await pg.wait_for_timeout(300)
        await W("walked").click(); await pg.wait_for_timeout(9000)
        print("7. riquadro:", await pg.evaluate("(document.querySelector('.dualsub-card-idiom')||{}).textContent"),
              "| ora sottolineate:", await pg.evaluate("[...document.querySelectorAll('.dualsub-idiom')].map(x=>x.textContent)"))
        await pg.locator(".dualsub-card-idiom .dualsub-card-link", has_text="Mostra tutta").click(); await pg.wait_for_timeout(800)
        print("   → scheda:", await pg.evaluate("(document.querySelector('.dualsub-card-word')||{}).textContent"), "=",
              await pg.evaluate("(document.querySelector('.dualsub-card-meaning')||{}).textContent"),
              "| evidenziate:", await pg.evaluate("[...document.querySelectorAll('.dualsub-sel')].map(x=>x.textContent)"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# 1.7.9: sulle pagine, ✎ forma base: si scrive (o sceglie) la radice e si apre la sua scheda intera, con il pulsante per tornare indietro
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
WORD = "(document.querySelector('.pav-card .pav-word')||{}).textContent||''"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnFreq:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "walked", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1800)
        print("1. scheda:", await pg.evaluate(WORD), "| pulsante:", await pg.locator(".pav-lemmabtn").count())
        await pg.locator(".pav-lemmabtn").click(); await pg.wait_for_timeout(1500)
        print("2. pannello:", await pg.locator(".pav-card .dsx-lemmabox").count(), "| casella:", await pg.evaluate("(document.querySelector('.pav-card .dsx-lemmabox input')||{}).value"))
        inp = pg.locator(".pav-card .dsx-lemmabox input"); await inp.fill("walk"); await inp.press("Enter"); await pg.wait_for_timeout(2500)
        back = pg.locator(".pav-card .pav-back")
        print("3. scheda aperta:", await pg.evaluate(WORD), "| torna indietro:", await back.count())
        await back.click(); await pg.wait_for_timeout(1200)
        print("4. dopo «Torna alla parola»:", await pg.evaluate(WORD))
        print("   etimologia salvata:", await sw.evaluate("chrome.storage.local.get('etymBase').then(r=>JSON.stringify(r.etymBase))"))
        ok = True
        print("errori:", errs if ok else errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

# Crea src/pdf-enc.js: le tabelle delle codifiche a un byte (byte 0x80–0xFF → carattere) per riparare i PDF
# il cui testo è in una codifica ma pdf.js lo legge con un'altra. Uso: python3 tools/crea_pdf_enc.py
import json, os
# lingue del riconoscimento del browser per cui ogni codifica ha senso
CE = ["cs", "sk", "pl", "hu", "sl", "hr", "ro", "sq", "bs", "sr", "lt"]
CYR = ["ru", "uk", "bg", "sr", "mk", "be", "kk", "ky", "mn", "tg"]
WEST = ["fr", "it", "es", "pt", "ca", "de", "nl", "en", "da", "no", "nb", "nn", "sv", "fi", "is", "et", "ga", "cy", "eu", "gl", "lb", "af", "oc", "br", "co", "la", "mt"]
# codifica: (nome per l'utente, gruppo, lingue)
TARGETS = {
    "cp1250": ("Windows-1250", "Europa centrale", CE), "iso8859_2": ("ISO-8859-2", "Europa centrale", CE),
    "mac_latin2": ("Mac Europa centrale", "Europa centrale", CE), "cp852": ("DOS 852", "Europa centrale", CE),
    "iso8859_16": ("ISO-8859-16", "Europa centrale", CE),
    "cp1251": ("Windows-1251", "Cirillico", CYR), "koi8_r": ("KOI8-R", "Cirillico", CYR), "koi8_u": ("KOI8-U", "Cirillico", CYR),
    "iso8859_5": ("ISO-8859-5", "Cirillico", CYR), "mac_cyrillic": ("Mac cirillico", "Cirillico", CYR), "cp866": ("DOS 866", "Cirillico", CYR),
    "cp1253": ("Windows-1253", "Greco", ["el"]), "iso8859_7": ("ISO-8859-7", "Greco", ["el"]), "mac_greek": ("Mac greco", "Greco", ["el"]),
    "cp1254": ("Windows-1254", "Turco", ["tr", "az"]), "iso8859_9": ("ISO-8859-9", "Turco", ["tr", "az"]), "mac_turkish": ("Mac turco", "Turco", ["tr", "az"]),
    "cp1257": ("Windows-1257", "Baltico", ["lt", "lv", "et"]), "iso8859_13": ("ISO-8859-13", "Baltico", ["lt", "lv", "et"]), "iso8859_4": ("ISO-8859-4", "Baltico", ["lt", "lv", "et"]),
    "iso8859_3": ("ISO-8859-3", "Europa del sud", ["mt", "eo", "tr"]),
    "cp1255": ("Windows-1255", "Ebraico", ["he", "iw", "yi"]), "iso8859_8": ("ISO-8859-8", "Ebraico", ["he", "iw", "yi"]),
    "cp1256": ("Windows-1256", "Arabo", ["ar", "fa", "ur"]), "iso8859_6": ("ISO-8859-6", "Arabo", ["ar", "fa", "ur"]),
    "cp874": ("Windows-874", "Thai", ["th"]), "cp1258": ("Windows-1258", "Vietnamita", ["vi"]),
    "cp1252": ("Windows-1252", "Europa occidentale", WEST), "mac_roman": ("Mac Roman", "Europa occidentale", WEST),
    "cp850": ("DOS 850", "Europa occidentale", WEST), "cp437": ("DOS 437", "Europa occidentale", WEST), "mac_iceland": ("Mac islandese", "Europa occidentale", WEST),
}
# a più byte: si decodificano con TextDecoder del browser
MULTI = {"utf-8": ("UTF-8", "Unicode", None), "gbk": ("GBK", "Cinese", ["zh", "zh-CN"]), "big5": ("Big5", "Cinese", ["zh", "zh-TW"]),
         "shift_jis": ("Shift_JIS", "Giapponese", ["ja"]), "euc-jp": ("EUC-JP", "Giapponese", ["ja"]), "euc-kr": ("EUC-KR", "Coreano", ["ko"])}
# come pdf.js può aver letto i byte (le codifiche dei caratteri dei PDF)
SOURCES = {"cp1252": "WinAnsi", "mac_roman": "MacRoman"}
def table(codec):
    out = ""
    for b in range(0x80, 0x100):
        try: out += bytes([b]).decode(codec)
        except UnicodeDecodeError: out += "�"
    return out
# Adobe StandardEncoding (caratteri Type 1 senza codifica): solo i byte che hanno un carattere
STD = {0xA1: "¡", 0xA2: "¢", 0xA3: "£", 0xA4: "⁄", 0xA5: "¥", 0xA6: "ƒ", 0xA7: "§", 0xA8: "¤", 0xA9: "'", 0xAA: "“", 0xAB: "«", 0xAC: "‹",
       0xAD: "›", 0xAE: "ﬁ", 0xAF: "ﬂ", 0xB1: "–", 0xB2: "†", 0xB3: "‡", 0xB4: "·", 0xB6: "¶", 0xB7: "•", 0xB8: "‚", 0xB9: "„", 0xBA: "”",
       0xBB: "»", 0xBC: "…", 0xBD: "‰", 0xBF: "¿", 0xC1: "`", 0xC2: "´", 0xC3: "ˆ", 0xC4: "˜", 0xC5: "¯", 0xC6: "˘", 0xC7: "˙", 0xC8: "¨",
       0xCA: "˚", 0xCB: "¸", 0xCD: "˝", 0xCE: "˛", 0xCF: "ˇ", 0xD0: "—", 0xE1: "Æ", 0xE3: "ª", 0xE8: "Ł", 0xE9: "Ø", 0xEA: "Œ", 0xEB: "º",
       0xF1: "æ", 0xF5: "ı", 0xF8: "ł", 0xF9: "ø", 0xFA: "œ", 0xFB: "ß"}
src = {k: table(k) for k in SOURCES}
src["standard"] = "".join(STD.get(b, "�") for b in range(0x80, 0x100))
data = {
    "sources": src,
    "targets": {k: {"name": v[0], "group": v[1], "langs": v[2], "table": table(k)} for k, v in TARGETS.items()},
    "multi": {k: {"name": v[0], "group": v[1], "langs": v[2]} for k, v in MULTI.items()},
}
here = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(here, "..", "src", "pdf-enc.js"), "w", encoding="utf-8") as f:
    f.write("// Creato da tools/crea_pdf_enc.py: tabelle delle codifiche (byte 0x80–0xFF) per riparare il testo dei PDF.\n")
    f.write("export const PDF_ENC = " + json.dumps(data, ensure_ascii=False) + ";\n")
print("scritto src/pdf-enc.js")

# Sottotitoli Doppi

*[English version → READ-ME-FIRST](READ-ME-FIRST.html)*

**Impara le lingue guardando video, film e serie con i sottotitoli originali e la traduzione insieme.**

Sotto ogni frase nella lingua originale compare la traduzione nella tua lingua, in un altro colore. Senti la lingua vera, leggi cosa si dice e capisci cosa significa, tutto nello stesso momento.

Sottotitoli Doppi funziona in tre posti diversi. Scegli quello che usi per guardare:

| | 🌐 **Browser** | 📺 **Kodi** | 🎬 **Stremio** |
|---|---|---|---|
| **Per guardare** | YouTube e quasi tutti i siti con video o audio; in più qualsiasi pagina web e i PDF | Film e serie su Kodi: file sul dispositivo o in streaming | Film e serie su Stremio |
| **Funziona su** | Edge, Chrome, Brave, Firefox (computer) | Kodi 19 o più recente (PC, TV box, Fire TV…) | Stremio per computer |
| **Sottotitoli originali** | Quelli del sito, oppure la trascrizione dell'audio | Dentro il film, accanto al video, da internet, oppure la trascrizione dell'audio | Da OpenSubtitles |
| **Parole cliccabili, vocabolario, Anki** | ✅ (anche sulle pagine e nei PDF) | — | — |
| **Salvare i sottotitoli (.srt)** | ✅ | ✅ | — |
| **Guida** | [browser/LEGGIMI](browser/LEGGIMI.html) | [kodi/LEGGIMI](kodi/LEGGIMI.html) | [stremio/LEGGIMI](stremio/LEGGIMI.html) |

L'estensione per il browser fa due cose in una: **Sottotitoli Doppi** nei video e **Parole al Volo** sulle pagine e nei PDF (passi il mouse su una parola e vedi traduzione, pronuncia, spiegazione; selezioni un pezzo di testo e lo traduce tutto insieme). Vocabolario, parole che conosci, chiavi e Anki sono in comune.

Tutti traducono gratis con **Google Traduttore**, oppure molto meglio con **Gemini** (gratis con una chiave) e altri servizi. Quello che viene tradotto o trascritto resta salvato: rivedere un video non costa niente.

---

## Cosa c'è nella confezione

```
LEGGIMI-PRIMA.html        → questa pagina
READ-ME-FIRST.html        → questa pagina, in inglese

browser/
  sottotitoli-parole-chrome-vX.Y.Z.zip     → per Edge, Chrome, Brave
  sottotitoli-parole-firefox-vX.Y.Z.xpi    → per Firefox
  LEGGIMI.html   /  GUIDE.en.html          → guida completa (italiano / inglese)

kodi/
  script.sottotitolidoppi-1.12.0.zip            → l'add-on
  service.subtitles.sottotitolidoppi-1.0.0.zip  → voce nel menu Sottotitoli del lettore
  service.subtitles.subdl-1.0.0.zip             → sottotitoli da subdl.com (facoltativo)
  LEGGIMI.html   /  GUIDE.en.html               → guida completa (italiano / inglese)

stremio/
  sottotitoli-doppi-stremio-1.3.0.zip     → l'add-on per Stremio
  LEGGIMI.html   /  GUIDE.en.html         → guida (italiano / inglese)
```

Le guide si aprono con un doppio clic sui file **.html**: si vedono nel browser, con l'indice cliccabile. Le stesse guide sono anche in formato .md (testo semplice).

---

## Partire in 5 minuti

### Browser (Edge, Chrome, Brave)
1. Estrai `sottotitoli-parole-chrome-vX.Y.Z.zip` in una cartella che non cancellerai (per esempio in Documenti).
2. Apri la pagina delle estensioni (`edge://extensions` oppure `chrome://extensions`), attiva **Modalità sviluppatore**, premi **Carica estensione non pacchettizzata** e scegli quella cartella.
3. Clic sull'icona dell'estensione → **Traduci in**: la tua lingua.
4. Apri un video di YouTube e accendi i sottotitoli (CC): compare la doppia riga. Passa il mouse su una parola per vedere cosa significa.

**Firefox** (Nightly o Developer Edition): apri `about:addons` → ⚙ → **Installa componente aggiuntivo da file…** → scegli il file `.xpi`.

Sulle pagine web non serve fare niente: passa il mouse su una parola di un testo in un'altra lingua e compare la sua scheda.

### Kodi
1. Kodi → **Impostazioni → Sistema → Add-on**: attiva **Sorgenti sconosciute**.
2. **Impostazioni → Add-on → Installa da un file zip**: prima `script.sottotitolidoppi-1.12.0.zip`, poi `service.subtitles.sottotitolidoppi-1.0.0.zip` (e, se vuoi, `service.subtitles.subdl-1.0.0.zip`).
3. Nelle impostazioni dell'add-on scegli **Traduci in** e il **Servizio** di traduzione.
4. Fai partire un film: dopo pochi secondi l'add-on chiede se vuoi i sottotitoli doppi (sì, no, sempre o mai per la serie). Puoi cambiare in **Generale → Quando parte un video**: chiedi, sempre, mai.

### Stremio
1. Installa **Node.js** (versione LTS) da nodejs.org.
2. Estrai `sottotitoli-doppi-stremio-1.3.0.zip` e avvia `avvia-windows.bat` (Windows) o `avvia-mac-linux.sh` (Mac/Linux).
3. Nella pagina che si apre scegli la lingua e premi **Installa in Stremio**.

### La chiave gratuita di Gemini (consigliata)
Google Traduttore funziona subito, ma traduce frase per frase. **Gemini** capisce il contesto e traduce molto meglio, ed è gratis:
1. Vai su **aistudio.google.com/apikey** e accedi con un account Google.
2. Premi *Create API key* (non serve la carta di credito) e copia la chiave.
3. Incollala nell'estensione (icona → 🌐 Traduzione e modelli → Traduci i sottotitoli con → Gemini), nelle impostazioni dell'add-on di Kodi (Servizio → gemini) o nella pagina di Stremio.

Per **i video senza sottotitoli** (browser e Kodi) serve anche una chiave **Groq**, sempre gratuita, per trascrivere l'audio: **console.groq.com/keys**.

---

## Aggiornare senza perdere niente

Quando ricevi una versione nuova:

- **Edge / Chrome / Brave**: estrai la versione nuova **nella stessa cartella** di prima (sovrascrivendo i file) e premi ↻ sull'estensione nella pagina delle estensioni.
- **Firefox**: installa il nuovo `.xpi` sopra quello vecchio.
- **Kodi**: installa lo zip nuovo sopra quello vecchio (Installa da un file zip).
- **Stremio**: chiudi la finestra nera, sostituisci i file nella stessa cartella e riavvia.

**Non disinstallare mai** l'estensione o l'add-on per aggiornarli: insieme a loro si cancellano le chiavi, le traduzioni salvate e il vocabolario.

---

## Privacy

Sottotitoli Doppi non ha server propri e non raccoglie dati. Chiavi, traduzioni e vocabolario restano sul tuo computer, nel tuo browser o nel tuo Kodi. I testi da tradurre (e l'audio da trascrivere, se lo chiedi) vengono mandati solo ai servizi che scegli tu: Google, Gemini, Groq e così via, secondo le loro condizioni d'uso.

---

## Serve aiuto?

Ogni guida ha in fondo una sezione **"Se qualcosa non va"** con i problemi più comuni e come risolverli.

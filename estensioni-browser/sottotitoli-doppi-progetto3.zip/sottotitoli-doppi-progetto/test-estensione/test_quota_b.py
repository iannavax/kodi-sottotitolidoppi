import asyncio, json, sys, os, time
from bharness import *
MODE = os.environ["MODE"]

def summary(t0):
    g = log.get("gcalls", [])
    ok = sum(1 for c in g if c[1] == 200); mn = sum(1 for c in g if c[1] == "min"); dy = sum(1 for c in g if c[1] == "day")
    gaps = [round(g[i][0] - g[i-1][0], 1) for i in range(1, len(g))]
    return f"richieste a Gemini: {len(g)} (riuscite {ok}, rifiutate per limite al minuto {mn}, per limite giornaliero {dy})"

async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-latest'}, targetLang:'it', autoTranscribe:true, hoverPause:true})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}}))""")
        st = lambda: sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)")
        page = await ctx.new_page()
        t0 = time.time()
        if MODE == "rivedere":
            # 1a visione: chiudo dopo 12 s (traduzione ancora in corso)
            await page.goto("https://www.youtube.com/watch?v=longA"); await page.evaluate("document.querySelector('video').play()")
            await page.wait_for_timeout(12000)
            n1 = len(log.get("gcalls", []))
            print("  1a visione (12 s):", summary(t0), "| stato:", await st())
            await page.goto("about:blank"); await page.wait_for_timeout(500)
            # 2a visione dello stesso video
            await page.goto("https://www.youtube.com/watch?v=longA"); await page.evaluate("document.querySelector('video').play()")
            await page.wait_for_timeout(30000)
            print("  2a visione (30 s): richieste in più:", len(log.get("gcalls", [])) - n1, "|", summary(t0))
            print("  stato:", await st())
            # 3a visione: tutto dovrebbe essere già salvato
            n2 = len(log.get("gcalls", []))
            await page.goto("about:blank"); await page.wait_for_timeout(500)
            await page.goto("https://www.youtube.com/watch?v=longA"); await page.evaluate("document.querySelector('video').play()")
            await page.wait_for_timeout(6000)
            print("  3a visione: richieste in più:", len(log.get("gcalls", [])) - n2, "| stato:", await st())
        elif MODE == "parole":
            await page.goto("https://www.youtube.com/watch?v=capsW"); await page.evaluate("document.querySelector('video').play()")
            await page.wait_for_selector(".dualsub-orig .dualsub-word", timeout=15000)
            await page.wait_for_timeout(8000)
            n0 = len(log.get("gcalls", []))
            words = page.locator(".dualsub-orig .dualsub-word")
            for i in range(8):
                await words.nth(i).hover(); await page.wait_for_timeout(700)
            print("  passaggio del mouse su 8 parole: richieste a Gemini:", len(log.get("gcalls", [])) - n0)
            await words.nth(2).click()
            await page.wait_for_selector(".dualsub-card-meaning", timeout=15000); await page.wait_for_timeout(1500)
            print("  clic su una parola: richieste a Gemini:", len(log.get("gcalls", [])) - n0, "| scheda:", await page.inner_text(".dualsub-card-meaning"), "|", await page.inner_text(".dualsub-card-source"))
        elif MODE == "giornaliero":
            await page.goto("https://www.youtube.com/watch?v=longB"); await page.evaluate("document.querySelector('video').play()")
            await page.wait_for_timeout(35000)
            print(" ", summary(t0))
            print("  stato:", await st())
            print("  riga tradotta sul video:", await page.inner_text(".dualsub-trans"))
        elif MODE == "trascrizione":
            await page.goto("https://www.youtube.com/watch?v=noCapsR"); await page.wait_for_timeout(1000)
            await page.evaluate("document.querySelector('video').play()")
            await page.wait_for_timeout(28000)
            w1, g1 = len(log["groq"]), len(log.get("gcalls", []))
            print(f"  1a visione (28 s): Whisper {w1}, Gemini {g1}")
            await page.goto("about:blank"); await page.wait_for_timeout(2500)
            await page.goto("https://www.youtube.com/watch?v=noCapsR"); await page.wait_for_timeout(1000)
            await page.evaluate("document.querySelector('video').play()")
            await page.wait_for_timeout(10000)
            print("  a 10 s:", await page.inner_text(".dualsub-orig"), "|", await page.inner_text(".dualsub-trans"))
            await page.wait_for_timeout(10000)
            print(f"  2a visione (primi 20 s): Whisper +{len(log['groq']) - w1}, Gemini +{len(log.get('gcalls', [])) - g1}")
            print("  sul video:", await page.inner_text(".dualsub-orig"), "|", await page.inner_text(".dualsub-trans"))
            print("  stato:", await st())
        await ctx.close()
asyncio.run(main())

import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        ext = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it'}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page()
        await pg.goto("https://example.test/iptv.html"); await pg.wait_for_timeout(2500)
        await pg.frames[1].evaluate("document.querySelector('video').play()")
        await pg.wait_for_timeout(20000)
        tid = await sw.evaluate("chrome.tabs.query({}).then(t=>t.find(x=>(x.url||'').includes('iptv.html')).id)")
        tp = await ctx.new_page()
        await tp.goto(f"chrome-extension://{ext}/transcript.html?tab={tid}")
        seen = []
        for _ in range(8):
            await tp.wait_for_timeout(3100)
            seen.append(await tp.inner_text("#subtitle") or "(vuoto)")
        print("pagina della trascrizione, ogni 3 s:", seen)
        states = [await sw.evaluate(f"chrome.tabs.sendMessage({tid}, {{type:'liveState'}}).then(r=>r.running)") for _ in range(8)]
        print("il popup vede la trascrizione attiva:", states)
        # un comando dal popup (ferma) deve arrivare al riquadro giusto
        fr = await sw.evaluate(f"chrome.tabs.sendMessage({tid}, {{type:'liveState'}}).then(r=>r.frame)")
        r = await sw.evaluate(f"chrome.tabs.sendMessage({tid}, {{type:'live', action:'stop', target:'{fr}'}}).then(r=>r.running)")
        print("dopo 'Ferma' mandato al riquadro:", "fermata" if r is False else r)
        await ctx.close()
asyncio.run(main())


// sonda per le prove (solo nella copia di debug)
setInterval(() => { try { document.documentElement.dataset.dualsubDebug = JSON.stringify(live.cues.map((c) => ({ start: c.start, end: c.end, text: c.text, trans: c.trans, removed: !!c.removed, quick: !!c.quick, cleaned: !!c.cleaned, lang: c.lang || "", late: !!c.late }))); } catch (e) {} }, 500);

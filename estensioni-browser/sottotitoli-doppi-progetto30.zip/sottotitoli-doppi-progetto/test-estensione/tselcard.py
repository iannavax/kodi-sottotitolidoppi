# 1.6.2: il testo dentro la scheda di una parola (video) si seleziona con il mouse e si copia
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        el = pg.locator(".dualsub-card .dualsub-card-meaning").first
        b = await el.bounding_box()
        print("significato:", await el.text_content(), b)
        await pg.mouse.move(b["x"] + 2, b["y"] + b["height"] / 2); await pg.mouse.down()
        await pg.mouse.move(b["x"] + b["width"] - 2, b["y"] + b["height"] / 2, steps=8); await pg.mouse.up()
        await pg.wait_for_timeout(600)
        sel = await pg.evaluate("String(window.getSelection())")
        still = await pg.evaluate("!!document.querySelector('.dualsub-card')")
        print("selezionato:", repr(sel), "| scheda ancora aperta:", still)
        ok = len(sel.strip()) >= 2 and still
        print("errori:", errs if ok else errs + ["testo della scheda non selezionabile"], log["errors"])
        await ctx.close()
asyncio.run(main())

# 5.9.3: trascrizione nella lingua sbagliata → scelta della lingua per il video (pulsante accanto ai sottotitoli)
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
os.environ["GROQ_LANG"] = "1"
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsCanzone"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent", timeout=60000)
        print("1. trascrizione:", await pg.inner_text(".dualsub-orig"), "| pulsante:", await pg.inner_text(".dualsub-langbtn"), "| lingue chieste:", log.get("groq_lang"))
        await pg.evaluate("document.querySelector('video').pause()")
        await pg.locator(".dualsub-orig").hover(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-langbtn").click(); await pg.wait_for_timeout(500)
        print("2. scheda:", (await pg.inner_text(".dualsub-card"))[:160].replace("\n", " | "))
        await pg.locator(".dualsub-lang-search").fill("ceco"); await pg.wait_for_timeout(300)
        print("   cercando 'ceco':", await pg.locator(".dualsub-lang-list button").all_inner_texts())
        await pg.keyboard.press("Enter"); await pg.wait_for_timeout(1500)
        n0 = len(log["groq_lang"])
        await pg.mouse.move(5, 5)
        await pg.evaluate("document.querySelector('video').currentTime = 0; document.querySelector('video').play()")
        await pg.wait_for_timeout(15000)
        print("   debug:", await pg.evaluate("document.documentElement.dataset.dsLang"))
        print("3. salvata:", await sw.evaluate("chrome.storage.local.get('videoLang').then(r=>JSON.stringify(r.videoLang))"),
              "| lingue chieste dopo:", log["groq_lang"][n0:], "| pulsante:", await pg.inner_text(".dualsub-langbtn"), "| sul video:", await pg.inner_text(".dualsub-orig"))
        # 4. riaprendo il video la lingua resta
        await pg.reload(); await pg.wait_for_timeout(1200)
        n1 = len(log["groq_lang"])
        await pg.evaluate("document.querySelector('video').currentTime = 30; document.querySelector('video').play()"); await pg.wait_for_timeout(12000)
        print("4. riaperto: lingue chieste:", log["groq_lang"][n1:], "| pulsante:", await pg.evaluate("(document.querySelector('.dualsub-langbtn')||{}).textContent"))
        # 5. ⚑ ha la voce della lingua
        await pg.evaluate("document.querySelector('video').pause()")
        await pg.locator(".dualsub-orig").hover(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-fixbtn").first.click(); await pg.wait_for_timeout(400)
        print("5. ⚑:", [t for t in await pg.locator(".dualsub-card button").all_inner_texts() if "Lingua" in t])
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

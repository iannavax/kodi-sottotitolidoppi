# 5.15: IPA da Wiktionary sempre (anche con l'IPA del modello spenta); dal modello solo nella richiesta unica del clic
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
IPA = "(document.querySelector('.dualsub-card-ipa')||{}).textContent"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', ipa:false, hoverPause:true, idioms:false, learnExamples:false, learnSpell:false})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ipaWikt"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'') && document.querySelectorAll('.dualsub-tword').length>1", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        W = lambda t: words.nth(texts.index(t))
        n = len(log.get("ipa", []))
        await W("bread").hover(); await pg.wait_for_timeout(3000)
        print("1. IPA del modello SPENTA, bread:", await pg.evaluate(IPA), "|", await pg.evaluate("(document.querySelector('.dualsub-card-ipa')||{}).title"), "| richieste IPA:", len(log.get("ipa", [])) - n)
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(800)
        await sw.evaluate("chrome.storage.sync.set({ipa:true})"); await pg.wait_for_timeout(300)
        await W("market").hover(); await pg.wait_for_timeout(4000)
        print("2. accesa, market (it.wiktionary):", await pg.evaluate(IPA), "| richieste IPA:", len(log.get("ipa", [])) - n)
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(800)
        await W("walked").hover(); await pg.wait_for_timeout(6000)
        print("3. walked (in nessun Wiktionary):", await pg.evaluate(IPA), "| richieste IPA a parte:", len(log.get("ipa", [])) - n)
        await W("walked").click(); await spiega(pg, 8000)
        print("4. clic su walked:", await pg.evaluate(IPA), "| spiegazioni (parola, etim, ipa):", log.get("define"), "| richieste IPA a parte:", len(log.get("ipa", [])) - n)
        await pg.keyboard.press("Escape"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(600)
        await W("bread").click(); await spiega(pg, 8000)
        print("5. clic su bread (IPA già da Wiktionary):", log.get("define")[-1])
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

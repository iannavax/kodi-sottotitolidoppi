#!/bin/bash
# Build di Parole al Volo: usa i servizi di Sottotitoli Doppi (config.js, background.js, tts.js) presi da ../estensione/src.
# Uso: ./build.sh 1.0.0
set -e; cd "$(dirname "$0")"; V=${1:-1.0.0}
SD=../estensione/src
OWN="volo-config.js volo.js volo-bg.js volo.css popup.html popup.js pdf.html pdf-viewer.js pdf-enc.js pdf-text.css"
python3 ../estensione/tools/crea_ui_strings.py
rm -rf build && for b in chrome firefox; do mkdir -p build/$b/icons
  for f in han-data.json ui-strings.json ui-i18n.js config.js background.js tts.js etym.js learn.js roman.js voices-ui.js freq.js jlpt.html jlpt.js kanji.html kanji.js vocab.js engines-ui.js; do cp $SD/$f build/$b/; done
  sed 's#<script src="config.js"></script>#<script src="config.js"></script>\n<script src="volo-config.js"></script>#' $SD/freq.html > build/$b/freq.html
  # vocabolario comune alle due estensioni: qui serve anche volo-config.js
  sed 's#<script src="config.js"></script>#<script src="config.js"></script>\n<script src="volo-config.js"></script>#' $SD/vocab.html > build/$b/vocab.html
  for f in $OWN; do cp src/$f build/$b/; done
  mkdir -p build/$b/pdfjs && cp -r src/pdfjs/* build/$b/pdfjs/   # lettore PDF (pdf.js di Mozilla)
  cp src/icons/icon-*.png build/$b/icons/
  sed "s/\"version\": \"[^\"]*\"/\"version\": \"$V\"/" manifest.$b.json > build/$b/manifest.json
  { echo "*Versione $V*"; echo; cat LEGGIMI.md; } > build/$b/LEGGIMI.md
done
for f in build/chrome/*.js; do node --check $f; done
(cd build/chrome && cat config.js ui-i18n.js tts.js volo-config.js etym.js learn.js roman.js volo.js > /tmp/pav-all.js) && node --check /tmp/pav-all.js
(cd build/chrome && cat config.js volo-config.js background.js volo-bg.js > /tmp/pav-bg.js) && node --check /tmp/pav-bg.js
rm -f *.zip *.xpi; (cd build/chrome && zip -rq ../../parole-al-volo-chrome-v$V.zip .); (cd build/firefox && zip -rq ../../parole-al-volo-firefox-v$V.xpi .)
echo "fatto: parole-al-volo-chrome-v$V.zip e parole-al-volo-firefox-v$V.xpi"

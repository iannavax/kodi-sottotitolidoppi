// Correzioni delle singole frasi: ritraduci, ritrascrivi, correggi a mano, togli.
// Le correzioni restano salvate con il video ("fix:<video>") e hanno la precedenza su tutto il resto,
// anche su "Rifai la traduzione".
// Usa: settings, live, track, segTrans, transCues, askTranslate, liveEngine, trackEngine, GOOGLE_ENGINE,
//      wordsCard*, el, wordsPlace, wordsCloseCard, getVideo, currentVideoId, setStatus (dagli altri moduli)

let dsFixes = {};
let dsFixVid = null;
let dsFixLoading = null;

const fixKey = (start) => String(Math.round(start / 100));   // tolleranza di un decimo di secondo

function fixLoad(v) {
  if (dsFixVid === v && !dsFixLoading) return Promise.resolve();
  if (dsFixVid === v && dsFixLoading) return dsFixLoading;
  dsFixVid = v;
  dsFixes = {};
  dsFixLoading = DS_EXT.storage.local.get(`fix:${v}`).then((r) => {
    if (dsFixVid === v) dsFixes = r[`fix:${v}`] || {};
    dsFixLoading = null;
  });
  return dsFixLoading;
}

// Frase come va mostrata, tenendo conto delle correzioni salvate
function fixApply(v, start, text, trans) {
  if (!v) return { text, trans };
  if (dsFixVid !== v) { fixLoad(v); return { text, trans }; }
  const f = dsFixes[fixKey(start)];
  if (!f) return { text, trans };
  const tr = f.tr && f.tr[settings.targetLang];
  // traduzione incollata da una chat (Copia trascrizione → Incolla traduzione): vale come le altre correzioni,
  // ma non è segnata come "corretta a mano" frase per frase
  const onlyChat = f.chat && f.chat[settings.targetLang] && f.t == null && !f.x;
  return { text: f.t != null ? f.t : text, trans: tr != null ? tr : trans, gone: !!f.x, fixed: !onlyChat, chat: !!onlyChat };
}

// Molte traduzioni insieme (incollate da una chat): una sola scrittura in memoria
async function fixSaveMany(v, items, force) {
  await fixLoad(v);
  let n = 0;
  for (const it of items) {
    // (force: unione e spostamento delle traduzioni: anche le frasi vuote e quelle corrette a mano vengono scritte)
    if (!it || it.trans == null || (!force && !String(it.trans).trim())) continue;
    const k = fixKey(it.start);
    const f = { ...(dsFixes[k] || {}) };
    if (!force && f.tr && f.tr[settings.targetLang] != null && !(f.chat && f.chat[settings.targetLang])) continue;   // corretta a mano: resta
    f.tr = { ...(f.tr || {}), [settings.targetLang]: String(it.trans).trim() };
    f.chat = { ...(f.chat || {}), [settings.targetLang]: 1 };
    dsFixes[k] = f;
    n++;
  }
  await saveCache(`fix:${v}`, dsFixes);
  return n;
}

async function fixSave(v, start, patch) {
  await fixLoad(v);
  const k = fixKey(start);
  const f = { ...(dsFixes[k] || {}) };
  if ("t" in patch) { if (patch.t == null) delete f.t; else f.t = patch.t; }
  if ("tr" in patch) {
    f.tr = { ...(f.tr || {}) };
    if (patch.tr == null) delete f.tr[settings.targetLang]; else f.tr[settings.targetLang] = patch.tr;
  }
  if ("x" in patch) { if (patch.x) f.x = 1; else delete f.x; }
  if (Object.keys(f).length && !(Object.keys(f).length === 1 && f.tr && !Object.keys(f.tr).length)) dsFixes[k] = f;
  else delete dsFixes[k];
  await saveCache(`fix:${v}`, dsFixes);
}

// ---------- Trovare la frase ----------
function fixFind(start) {
  const near = (x) => Math.abs(x - start) < 60;
  if (liveActive()) {
    const i = live.cues.findIndex((c) => near(c.start));
    if (i >= 0) return { kind: "live", i, cue: live.cues[i], list: live.cues };
  }
  if (track) {
    const line = trackEngine().E.kind === "youtube";
    const list = line ? track.cues : track.segments;
    const i = list.findIndex((c) => near(c.start));
    if (i >= 0) return { kind: line ? "line" : "segment", i, cue: list[i], list };
  }
  return null;
}

function fixCurrent(ref) {
  const f = fixApply(currentVideoId(), ref.cue.start, ref.cue.text, "");
  return f.text;
}

// ---------- Ritraduci ----------
async function fixRetranslate(start) {
  const v = currentVideoId();
  const ref = fixFind(start);
  if (!ref) return { ok: false, error: "frase non trovata" };
  const text = fixCurrent(ref);
  const ctx = (a, b) => ref.list.slice(Math.max(0, a), Math.max(0, b)).filter((c) => !c.removed).map((c) => c.text);
  const e0 = ref.kind === "live" ? liveEngine() : trackEngine();
  const e = e0.E.kind === "youtube" ? GOOGLE_ENGINE : e0;
  const lang = ref.cue.lang || (ref.kind === "live" ? liveSourceLang() : (track && track.lang) || "");
  let r = await askTranslate(e, [text], ctx(ref.i - 4, ref.i), ctx(ref.i + 1, ref.i + 3), () => true, "", lang, false, true);
  let t = r && !r.error ? (r.translations[0] || "") : "";
  if (!t || dsIsEcho(text, t) || dsUncheckedCopy(text, t, settings.targetLang)) {
    // il servizio scelto non ha dato una traduzione valida (o ha ricopiato la frase): provo con Google
    const g = await askTranslate(GOOGLE_ENGINE, [text], [], [], () => true, "", lang);
    const gt = g && !g.error ? (g.translations[0] || "") : "";
    if (gt && !dsIsEcho(text, gt)) {
      if (dsIsCopy(text, gt)) dsMarkCopyOk(text, settings.targetLang);   // anche Google la lascia uguale: è un nome
      t = gt; r = { via: "Google" };
    }
  }
  if (!t) return { ok: false, error: (r && r.error) || "nessuna traduzione valida" };
  await fixSave(v, ref.cue.start, { tr: t });
  if (ref.kind === "live") { ref.cue.trans = t; ref.cue.quick = false; ref.cue.saved = true; liveScheduleSave(); }
  return { ok: true, trans: t };
}

// ---------- Ritrascrivi (solo trascrizione di Whisper) ----------
async function fixRetranscribe(start) {
  const v = currentVideoId();
  const ref = fixFind(start);
  if (!ref || ref.kind !== "live") return { ok: false, error: "si possono ritrascrivere solo le frasi trascritte dall'audio" };
  const c = ref.cue;
  await fixSave(v, c.start, { t: null, tr: null, x: false });
  // 1) l'audio di quella frase è ancora in memoria: la ritrascrivo subito, con il modello più preciso
  const item = c.item && c.item.pcm ? c.item : null;
  if (item) {
    const r = await liveRequest(item, dsSttLang() || c.lang || live.domLang || "", liveBetterModel());
    if (r && !r.error) {
      const fresh = DualSubs.fromWhisper((r.segments || []).filter((s) => !DualSubs.isJunk(s)), r.words || [], item.s, item.rate)
        .filter((n) => (n.start + n.end) / 2 >= c.start - 400 && (n.start + n.end) / 2 <= c.end + 400)
        .map((n) => ({ start: n.start, end: n.end, text: n.text, trans: null, quick: false, late: false, item, lang: c.lang }));
      live.cues = live.cues.filter((x) => x === c ? false : !((x.start + x.end) / 2 >= c.start && (x.start + x.end) / 2 <= c.end && x.item === item));
      if (!fresh.length) { live.dirty = true; liveScheduleSave(); return { ok: true, text: "", note: "Whisper non ha sentito parlato in quel punto: la frase è stata tolta." }; }
      live.cues.push(...fresh);
      live.cues.sort((a, b) => a.start - b.start);
      live.dirty = true;
      liveScheduleSave();
      liveQueueTranslation(fresh);
      return { ok: true, text: fresh.map((x) => x.text).join(" ") };
    }
  }
  // 2) audio non più in memoria: torno all'inizio della frase e la riascolto
  const a = c.start - 500, b = c.end + 500;
  live.cues = live.cues.filter((x) => x !== c);
  live.covered = live.covered.flatMap(([x, y]) => (y <= a || x >= b ? [[x, y]] : [[x, a], [b, y]].filter(([p, q]) => q - p > 500)));
  live.redo = live.redo.filter((r) => r.b <= a || r.a >= b);   // la stessa frase chiesta due volte: una sola
  live.redo.push({ a, b, done: a, at: Date.now() });
  live.dirty = true;
  liveScheduleSave();
  const video = getVideo();
  if (!live.running) { live.redoAutoStarted = true; liveStart(true, { fill: true, quiet: true }); }
  if (video) { video.currentTime = Math.max(0, c.start / 1000 - 1); video.play().catch(() => {}); }
  setStatus("Riascolto la frase per ritrascriverla con il modello più preciso…");
  return { ok: true, pending: true, note: "Il video torna all'inizio della frase e la riascolta: la nuova versione compare tra pochi secondi." };
}

function liveBetterModel() {
  // su Groq, il modello non "turbo" è più lento ma più preciso
  return settings.stt === "groq" ? "whisper-large-v3" : settings.sttModel;
}

// ---------- Correggi a mano / togli ----------
async function fixEdit(start, text, trans) {
  const v = currentVideoId();
  const ref = fixFind(start);
  if (!ref) return { ok: false, error: "frase non trovata" };
  const patch = {};
  const oldText = fixCurrent(ref);
  if (text != null && text.trim() && text.trim() !== oldText) patch.t = text.trim();
  if (trans != null && trans.trim()) patch.tr = trans.trim();
  if (!Object.keys(patch).length) return { ok: true };
  await fixSave(v, ref.cue.start, patch);
  if (ref.kind === "live") {
    if (patch.t) ref.cue.text = patch.t;
    if (patch.tr) { ref.cue.trans = patch.tr; ref.cue.saved = true; }
    live.dirty = true;
    liveScheduleSave();
  }
  // originale corretto senza una traduzione nuova: la rifaccio io
  if (patch.t && !patch.tr) return fixRetranslate(ref.cue.start);
  return { ok: true };
}

async function fixRemove(start) {
  const v = currentVideoId();
  const ref = fixFind(start);
  if (!ref) return { ok: false, error: "frase non trovata" };
  await fixSave(v, ref.cue.start, { x: true });
  if (ref.kind === "live") { ref.cue.removed = true; live.dirty = true; liveScheduleSave(); }
  return { ok: true };
}

async function fixDo(action, start, text, trans) {
  try {
    if (action === "retranslate") return await fixRetranslate(start);
    if (action === "retranscribe") return await fixRetranscribe(start);
    if (action === "edit") return await fixEdit(start, text, trans);
    if (action === "remove") return await fixRemove(start);
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
  return { ok: false, error: "azione sconosciuta" };
}

// 1.7.28: il pezzo tra l'ultimo sottotitolo e il prossimo (dove magari si parla ma Whisper non ha sentito niente): si riascolta con il modello
// più preciso e le frasi nuove compaiono (e si traducono) come le altre. Ritorna { a, b } in ms, o null se non c'è un buco.
function fixGapAround(tMs) {
  const cues = (live.cues || []).filter((c) => !c.removed).sort((x, y) => x.start - y.start);
  const prev = [...cues].reverse().find((c) => c.end <= tMs + 200);
  const next = cues.find((c) => c.start >= tMs - 200);
  let a = prev ? prev.end : Math.max(0, tMs - 15000);
  let b = next ? next.start : tMs + 15000;
  if (b - a > 60000) { a = Math.max(a, tMs - 30000); b = Math.min(b, tMs + 30000); }
  return b - a >= 1200 ? { a, b } : null;
}
const fixClock = (ms) => { const s = Math.round(ms / 1000); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
function fixRetranscribeGap(gap) {
  const a = Math.max(0, gap.a - 400), b = gap.b + 400;
  live.covered = live.covered.flatMap(([x, y]) => (y <= a || x >= b ? [[x, y]] : [[x, a], [b, y]].filter(([p, q]) => q - p > 500)));
  live.redo = live.redo.filter((r) => r.b <= a || r.a >= b);
  live.redo.push({ a, b, done: a, at: Date.now() });
  live.dirty = true;
  liveScheduleSave();
  const video = getVideo();
  if (!live.running) { live.redoAutoStarted = true; liveStart(true, { fill: true, quiet: true }); }
  if (video) { video.currentTime = Math.max(0, a / 1000); video.play().catch(() => {}); }
  setStatus(`Riascolto il pezzo senza sottotitoli (${fixClock(gap.a)}–${fixClock(gap.b)}) con il modello più preciso…`);
}

// Mentre la scheda è aperta i sottotitoli restano fermi: dopo una correzione ridisegno subito la frase
// sul video, così la nuova traduzione si vede sotto l'originale (non solo nella scheda)
function fixRefreshLine(s) {
  wordsOrigKey = "";
  wordsTransKey = "";
  wordsRenderOriginal(s.text, s.lang);
  if (s.trans && s.trans !== "…") wordsRenderTrans(s.trans);
  else setText(lineTrans, s.trans || "");
  lineTrans.classList.remove("dualsub-quick");
}

// ---------- Scheda sul video ----------
function fixOpenCard(anchor) {
  if (!overlay) return;
  if (wordsCard) wordsCard.remove();
  // senza nessuna frase sullo schermo la scheda offre solo le azioni su tutto il video (trascrizione, traduzione, lingua)
  const vid = getVideo();
  const sentence = wordsCurrent || { text: "", trans: "", start: vid ? vid.currentTime * 1000 : 0, empty: true, live: live.running || (live.videoId === currentVideoId() && live.cues.length > 0) || !track };
  wordsCardState = { pinned: true, word: null, fix: true, sentence, data: null };
  wordsCard = el("div", "dualsub-card dualsub-fixcard");
  overlay.append(wordsCard);
  fixFillCard();
  wordsPlace(anchor);
}

function fixFillCard(message) {
  const st = wordsCardState;
  if (!wordsCard || !st) return;
  const s = st.sentence;
  wordsCard.textContent = "";
  const head = el("div", "dualsub-card-head");
  head.append(el("div", "dualsub-card-title", s.empty ? "Non compare niente o è tutto sbagliato?" : "Questa frase è sbagliata?"));
  const close = el("button", "dualsub-card-btn", "×");
  close.title = "Chiudi";
  close.addEventListener("click", wordsCloseCard);
  head.append(close);
  if (s.empty) wordsCard.append(head, el("div", "dualsub-card-expl", "Qui non c'è nessuna frase: puoi rifare per intero la trascrizione o la traduzione di questo video, o scegliere la lingua parlata."));
  else wordsCard.append(head, el("div", "dualsub-card-expl", s.text), el("div", "dualsub-card-meaning dualsub-fix-trans", s.trans || "—"));

  const busy = (label) => { fixFillCard(label); };
  const run = async (action, label, text, trans) => {
    busy(label);
    const r = await fixDo(action, s.start, text, trans);
    if (!wordsCardState || wordsCardState.sentence !== s) return;
    if (!r.ok) { fixFillCard("Non ci sono riuscito: " + r.error); return; }
    if (r.pending) { wordsCloseCard(); return; }
    const now = fixApply(currentVideoId(), s.start, r.text != null && r.text !== "" ? r.text : s.text, r.trans != null ? r.trans : s.trans);
    s.text = now.text; s.trans = now.trans;
    fixRefreshLine(s);
    fixFillCard(r.note || "Fatto ✓");
  };

  const actions = el("div", "dualsub-fix-actions");
  if (s.empty && s.live) {
    const gap = fixGapAround(s.start);
    const bg = el("button", "dualsub-card-replay", gap ? `🎙 Riascolta il pezzo senza sottotitoli (${fixClock(gap.a)}–${fixClock(gap.b)})` : "🎙 Riascolta questo punto");
    bg.title = "Tra l'ultimo sottotitolo e il prossimo: si riascolta l'audio con il modello più preciso. Se c'è parlato che non era stato trascritto, compare (e si traduce) come le altre frasi";
    bg.addEventListener("click", () => {
      const g = gap || { a: Math.max(0, s.start - 8000), b: s.start + 8000 };
      wordsCloseCard(); fixRetranscribeGap(g);
    });
    actions.append(bg);
  }
  const b1 = el("button", "dualsub-card-replay", "↻ Ritraduci");
  b1.title = "Chiede di nuovo la traduzione di questa frase, con le frasi vicine come contesto";
  b1.addEventListener("click", () => run("retranslate", "Ritraduco…"));
  if (!s.empty) actions.append(b1);
  if (s.live) {
    const bl = el("button", "dualsub-card-replay", `🌐 Lingua sbagliata? (ora: ${dsLangName(liveSourceLang() || "") || "automatica"})`);
    bl.title = "Se la trascrizione è in un'altra lingua (per esempio in inglese invece che in ceco): scegli la lingua parlata in questo video";
    bl.addEventListener("click", () => fixLangPicker());
    actions.append(bl);
    const b2 = el("button", "dualsub-card-replay", "🎙 Ritrascrivi");
    b2.title = "Fa riascoltare questa frase a Whisper, con il modello più preciso";
    b2.addEventListener("click", () => run("retranscribe", "Ritrascrivo…"));
    if (!s.empty) actions.append(b2);
  }
  const b3 = el("button", "dualsub-card-replay", "✎ Correggi a mano");
  b3.addEventListener("click", () => fixEditForm());
  const b4 = el("button", "dualsub-card-replay", "✕ Togli questa frase");
  b4.title = "Per le frasi inventate (per esempio durante la musica)";
  b4.addEventListener("click", async () => { await fixDo("remove", s.start); wordsCloseCard(); });
  if (!s.empty) actions.append(b3, b4);
  if (actions.children.length) wordsCard.append(actions);
  // tutta la traduzione del video sbagliata (per esempio nella lingua sbagliata): si rifà tutta
  const whole = el("div", "dualsub-fix-whole");
  whole.append(el("div", "dualsub-card-hint", "Tutta la traduzione di questo video è sbagliata?"));
  const wa = el("div", "dualsub-fix-actions");
  const cur = engine();
  const w1 = el("button", "dualsub-card-replay", `↻ Rifalla tutta (${cur.E.label.split(" (")[0].split(",")[0]})`);
  w1.title = "Cancella la traduzione salvata di questo video e la rifà da capo con lo stesso servizio";
  w1.addEventListener("click", async () => { wordsCloseCard(); await dsRedoWholeTranslation(); });
  wa.append(w1);
  if (cur.id !== "google") {
    const w2 = el("button", "dualsub-card-replay", "↻ Rifalla con Google Traduttore");
    w2.title = "Per questo video traduce sempre con Google Traduttore (la scelta resta salvata solo per questo video)";
    w2.addEventListener("click", async () => { wordsCloseCard(); await dsRedoWholeTranslation("google"); });
    wa.append(w2);
  }
  if (dsVideoEngine[currentVideoId()]) {
    const w3 = el("button", "dualsub-card-replay", "Torna al servizio scelto nel popup");
    w3.addEventListener("click", async () => { wordsCloseCard(); await dsRedoWholeTranslation(null); });
    wa.append(w3);
  }
  whole.append(wa);
  wordsCard.append(whole);
  // 1.8.0: traduzione già pronta (unire) e traduzione sfasata (spostare)
  { const mg = el("div", "dualsub-fix-whole");
    mg.append(el("div", "dualsub-card-hint", "Il video ha già la traduzione (o ce l'hai in un file)?"));
    const ma = el("div", "dualsub-fix-actions");
    const m1 = el("button", "dualsub-card-replay", "🔗 Unisci sottotitoli…");
    m1.title = "Unisce una traccia di YouTube nella tua lingua, o un file .srt/.vtt, alla trascrizione di questo video: niente da tradurre";
    m1.addEventListener("click", () => fixMergePanel());
    ma.append(m1);
    mg.append(ma);
    wordsCard.append(mg);
    if (!s.empty || fixLines()) {
      const sh = el("div", "dualsub-fix-whole");
      sh.append(el("div", "dualsub-card-hint", "La traduzione non corrisponde a quello che si dice (è sfasata)?"));
      const row1 = el("div", "dualsub-fix-actions");
      const num = el("input", "dualsub-fix-input dualsub-shift-n");
      num.type = "number"; num.min = "1"; num.max = "200"; num.value = "1"; num.title = "Di quante frasi spostare la traduzione";
      num.style.cssText = "width:4.5em;display:inline-block";
      num.addEventListener("keydown", (e) => e.stopPropagation());
      const fromHere = el("label", "dualsub-card-hint");
      const cb = el("input"); cb.type = "checkbox"; cb.checked = true;
      fromHere.append(cb, document.createTextNode(" solo da questa frase in poi"));
      const note = el("div", "dualsub-card-source", "");
      const go = async (dir) => {
        const k = Math.max(1, Math.min(200, Math.round(Number(num.value) || 1))) * dir;
        note.textContent = "Sposto…";
        const r = await fixShiftTrans(k, cb.checked ? s.start : null);
        note.textContent = r.ok ? `Fatto ✓${r.empty ? " (" + r.empty + (r.empty === 1 ? " frase è rimasta senza traduzione" : " frasi sono rimaste senza traduzione") + ": ↻ Ritraduci)" : ""}` : "Non ci sono riuscito: " + r.error;
        if (r.ok && wordsCardState && wordsCardState.sentence === s) { const now = fixApply(currentVideoId(), s.start, s.text, ""); s.trans = now.trans; fixRefreshLine(s); }
      };
      const bBack = el("button", "dualsub-card-replay", "⏪ Traduzione in ritardo: portala avanti");
      bBack.title = "La frase mostra la traduzione di una frase di PRIMA: ogni traduzione sale di N frasi";
      bBack.addEventListener("click", () => go(-1));
      const bFwd = el("button", "dualsub-card-replay", "⏩ Traduzione in anticipo: portala indietro");
      bFwd.title = "La frase mostra la traduzione di una frase di DOPO: ogni traduzione scende di N frasi";
      bFwd.addEventListener("click", () => go(1));
      const bRedo = el("button", "dualsub-card-replay", "↻ Rifai la traduzione da questa frase in poi");
      bRedo.title = "Cancella le traduzioni da qui alla fine e le chiede di nuovo al servizio scelto";
      bRedo.addEventListener("click", async () => { note.textContent = "Rifaccio…"; const r = await fixRedoFrom(s.start); if (r.ok) wordsCloseCard(); else note.textContent = "Non ci sono riuscito: " + r.error; });
      row1.append(el("span", "dualsub-card-hint", "Sposta di "), num, el("span", "dualsub-card-hint", " frasi "), fromHere);
      const row2 = el("div", "dualsub-fix-actions");
      row2.append(bBack, bFwd, bRedo);
      sh.append(row1, row2, note);
      wordsCard.append(sh);
    }
  }
  // tutta la trascrizione sbagliata (parole capite male dappertutto): si cancella e si rifà da capo
  if (s.live) {
    const wt = el("div", "dualsub-fix-whole");
    wt.append(el("div", "dualsub-card-hint", "Tutta la trascrizione di questo video è sbagliata?"));
    const ta = el("div", "dualsub-fix-actions");
    const t1 = el("button", "dualsub-card-replay", "🎙 Rifai la trascrizione");
    t1.title = "Cancella la trascrizione salvata di questo video (e la sua traduzione) e la rifà da capo";
    t1.addEventListener("click", async () => { wordsCloseCard(); await liveRedo("transcription"); });
    ta.append(t1);
    if (liveBetterModel() !== settings.sttModel) {
      const t2 = el("button", "dualsub-card-replay", "🎙 Rifalla con il modello più preciso");
      t2.title = "Come sopra, ma con " + liveBetterModel() + ": più lento, sbaglia meno parole";
      t2.addEventListener("click", async () => { wordsCloseCard(); await liveRedo("transcription", true); });
      ta.append(t2);
    }
    wt.append(ta);
    wordsCard.append(wt);
  }
  // sottotitoli automatici di YouTube senza punteggiatura né maiuscole: il modello li riscrive
  if (typeof track !== "undefined" && track && track.kind === "asr" && !liveActive()) {
    const wa2 = el("div", "dualsub-fix-whole");
    wa2.append(el("div", "dualsub-card-hint", "I sottotitoli automatici di YouTube sono senza punteggiatura, maiuscole o con parole sbagliate?"));
    const ab = el("div", "dualsub-fix-actions");
    const a1 = el("button", "dualsub-card-replay", "✨ Correggili con il modello");
    a1.title = "Il modello (Gemini, Groq, Claude o locale) riscrive tutti i sottotitoli automatici di questo video con punteggiatura, maiuscole e parole corrette, poi si ritraduce";
    a1.addEventListener("click", async () => { wordsCloseCard(); await asrRun(true); });
    ab.append(a1);
    wa2.append(ab);
    wordsCard.append(wa2);
  }
  if (message) wordsCard.append(el("div", "dualsub-card-source", message));
}

function fixEditForm() {
  const st = wordsCardState;
  if (!wordsCard || !st) return;
  const s = st.sentence;
  wordsCard.textContent = "";
  wordsCard.append(el("div", "dualsub-card-title", "Correggi a mano"));
  const t1 = el("textarea", "dualsub-fix-input");
  t1.value = s.text;
  const t2 = el("textarea", "dualsub-fix-input");
  t2.value = s.trans && s.trans !== "…" ? s.trans : "";
  t2.placeholder = "Traduzione (se la lasci vuota e cambi l'originale, la rifaccio io)";
  for (const t of [t1, t2]) t.addEventListener("keydown", (e) => e.stopPropagation()); // i tasti non vanno al lettore
  const save = el("button", "dualsub-card-replay", "Salva");
  save.addEventListener("click", async () => {
    fixFillCard("Salvo…");
    const r = await fixDo("edit", s.start, t1.value, t2.value);
    if (r.ok) {
      const now = fixApply(currentVideoId(), s.start, s.text, r.trans != null ? r.trans : s.trans);
      s.text = now.text; s.trans = now.trans;
      fixRefreshLine(s);
    }
    fixFillCard(r.ok ? "Salvato ✓" : "Non ci sono riuscito: " + r.error);
  });
  const back = el("button", "dualsub-card-replay", "Annulla");
  back.addEventListener("click", () => fixFillCard());
  wordsCard.append(el("div", "dualsub-card-source", "Originale"), t1, el("div", "dualsub-card-source", "Traduzione"), t2, save, back);
  t1.focus();
}

// ---------- Lingua parlata nel video (trascrizione in una lingua sbagliata, per esempio in inglese) ----------
const DS_LANG_TOP = ["cs", "en", "it", "de", "fr", "es", "pt", "ru", "pl", "sk", "uk", "nl", "da", "sv", "no", "fi", "hu", "ro", "el", "tr", "ja", "zh", "ko", "ar", "he", "hi"];
function fixLangOpen(anchor) {
  if (!overlay) return;
  if (wordsCard) wordsCard.remove();
  wordsCardState = { pinned: true, word: null, fix: true, sentence: wordsCurrent || { text: "", start: 0 }, data: null };
  wordsCard = el("div", "dualsub-card dualsub-fixcard");
  overlay.append(wordsCard);
  fixLangPicker();
  wordsPlace(anchor);
}
function fixLangPicker() {
  if (!wordsCard || !wordsCardState) return;
  const v = live.videoId || currentVideoId();
  const chosen = (v && dsVideoLang[v]) || "";
  wordsCard.textContent = "";
  const head = el("div", "dualsub-card-head");
  head.append(el("div", "dualsub-card-title", "Lingua parlata in questo video"));
  const close = el("button", "dualsub-card-btn", "×");
  close.addEventListener("click", wordsCloseCard);
  head.append(close);
  wordsCard.append(head);
  const now = liveSourceLang();
  wordsCard.append(el("div", "dualsub-card-expl", (now ? `La trascrizione adesso è in ${dsLangName(now)}` : "Lingua riconosciuta da sola") +
    (chosen ? " (scelta da te)." : ". Se è sbagliata (succede soprattutto con le canzoni: Whisper scrive in inglese), scegli quella giusta: la trascrizione di questo video viene rifatta in quella lingua.")));
  const q = el("input", "dualsub-fix-input dualsub-lang-search");
  q.placeholder = "Cerca: ceco, czech, čeština…";
  q.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") { const b = list.querySelector("button"); if (b) b.click(); } });
  const list = el("div", "dualsub-lang-list");
  const names = Object.keys(C.STT_LANGS).map((code) => {
    let native = "";
    try { native = new Intl.DisplayNames([code], { type: "language" }).of(code) || ""; } catch {}
    const it = dsLangName(code);
    return { code, label: it + (native && native.toLowerCase() !== it.toLowerCase() ? " · " + native : ""), key: [code, it, native, C.STT_LANGS[code]].join(" ").toLowerCase() };
  });
  const fill = () => {
    const t = q.value.trim().toLowerCase();
    list.textContent = "";
    const shown = t ? names.filter((n) => n.key.includes(t)) : DS_LANG_TOP.map((c) => names.find((n) => n.code === c)).filter(Boolean);
    if (!t || "automatica".includes(t)) {
      const a = el("button", "dualsub-card-replay", (chosen ? "" : "► ") + "Automatica (la riconosce da sola)");
      a.addEventListener("click", () => fixLangApply(""));
      list.append(a);
    }
    for (const n of shown.slice(0, 40)) {
      const b = el("button", "dualsub-card-replay", (n.code === chosen ? "► " : "") + n.label);
      b.addEventListener("click", () => fixLangApply(n.code));
      list.append(b);
    }
    if (!t) list.append(el("div", "dualsub-card-source", "Scrivi nella casella per le altre lingue (98 in tutto)."));
  };
  q.addEventListener("input", fill);
  wordsCard.append(q, list);
  fill();
  setTimeout(() => q.focus(), 0);
}
async function fixLangApply(code) {
  if (wordsCard) {
    wordsCard.textContent = "";
    wordsCard.append(el("div", "dualsub-card-expl", code ? `Rifaccio la trascrizione in ${dsLangName(code)}…` : "Torno alla lingua automatica…"));
  }
  await liveSetVideoLang(code);
  wordsCloseCard();
}

// ---------- Unisci sottotitoli e traduzione sfasata (1.8.0) ----------
// Le frasi come si vedono adesso: la trascrizione dall'audio, oppure i sottotitoli di YouTube (a frasi o riga per riga)
function fixLines() {
  if (liveActive()) return { kind: "live", list: live.cues.filter((c) => !c.removed) };
  if (track) { const line = trackEngine().E.kind === "youtube"; return { kind: line ? "line" : "segment", list: line ? track.cues : track.segments }; }
  return null;
}
// per ogni frase di items, il testo delle righe di traduzione (trCues) che cadono nel suo tempo; null se non ce n'è
function fixMergeText(items, trCues) {
  const n = items.length, out = new Array(n).fill(null);
  if (!n || !trCues.length) return out;
  const win = items.map((it, i) => [it.start - 400, Math.min(i + 1 < n ? items[i + 1].start : Infinity, (it.end || it.start) + 3000)]);
  let j = 0;
  for (const c of trCues) {
    const mid = (c.start + c.end) / 2;
    while (j < n - 1 && mid >= win[j][1]) j++;
    if (mid < win[j][0] || mid >= win[j][1]) continue;
    out[j] = out[j] ? out[j] + " " + c.text : c.text;
  }
  return out;
}
// la traduzione che si vede ora per la frase i (correzioni comprese)
function fixShown(mode, i) {
  const it = mode.list[i];
  let base = "";
  if (mode.kind === "live") base = it.trans && it.trans !== "…" ? it.trans : "";
  else if (mode.kind === "segment") base = segTrans[i] || "";
  else base = DualSubs.activeText(transCues, ((it.start + (it.end || it.start)) / 2)) || "";
  const f = fixApply(currentVideoId(), it.start, it.text, base);
  return f.trans != null ? String(f.trans) : "";
}
const fixMergeKey = (v) => `mergedtr:${v}|${baseLang(track && track.lang)}|${baseLang(settings.targetLang)}`;

// scrive le traduzioni (una per frase di mode.list) come correzioni salvate e le mette subito a video
async function fixWriteTrans(mode, texts, extraLists) {
  const v = currentVideoId();
  const items = new Map();
  const add = (list, tx) => list.forEach((it, i) => { if (tx[i] != null) items.set(fixKey(it.start), { start: it.start, trans: tx[i] }); });
  add(mode.list, texts);
  if (extraLists) for (const [list, tx] of extraLists) add(list, tx);
  await fixSaveMany(v, [...items.values()], true);
  if (mode.kind === "live") {
    const done = new Set();
    mode.list.forEach((c, i) => { if (texts[i] != null) { c.trans = texts[i] || null; c.quick = false; c.saved = !!texts[i]; done.add(c); } });
    live.pendingTr = live.pendingTr.filter((c) => !done.has(c));
    liveScheduleSave();
  } else {
    ++job; translating = false;
    if (mode.kind === "segment") mode.list.forEach((s, i) => { if (texts[i] != null) segTrans[i] = texts[i]; });
  }
}

// traccia di YouTube → righe [{start,end,text}]. L'indirizzo della traccia viene dal lettore; i parametri del lettore stesso
// (pot, c, cver…) li prendo da quello dei sottotitoli già aperti, altrimenti YouTube risponde vuoto
async function fixFetchTrack(tr) {
  const u = new URL(tr.url, location.origin);
  try {
    const o = new URL(track.baseUrl, location.origin);
    for (const k of ["pot", "c", "cver", "cplayer", "cbrand", "cbr", "cbrver", "cos", "cosver", "cplatform", "xorb", "xobt", "xovt"]) if (o.searchParams.has(k)) u.searchParams.set(k, o.searchParams.get(k));
  } catch {}
  u.searchParams.set("fmt", "json3"); u.searchParams.delete("tlang");
  const ev = await fetchYT(u.toString());
  return DualSubs.parseCues(ev);
}

// unisce trCues alla trascrizione che si vede: { ok, got, total } oppure { ok:false, error }
async function fixMergeApply(trCues, label) {
  const mode = fixLines();
  if (!mode || !mode.list.length) return { ok: false, error: "non c'è ancora nessuna frase a cui unire la traduzione" };
  const extra = mode.kind !== "live" && track ? [[mode.kind === "line" ? track.segments : track.cues, null]] : [];
  const main = fixMergeText(mode.list, trCues);
  for (const x of extra) x[1] = fixMergeText(x[0], trCues);
  const got = main.filter(Boolean).length;
  if (!got) return { ok: false, error: "nessuna riga della traduzione coincide in tempo con la trascrizione di questo video" };
  await fixWriteTrans(mode, main, extra);
  if (mode.kind !== "live" && track) await DS_EXT.storage.local.set({ [fixMergeKey(track.videoId)]: { n: track.segments.length, at: Date.now(), label } }).catch(() => {});
  wordsOrigKey = ""; wordsTransKey = "";
  return { ok: true, got, total: mode.list.length };
}

// automatico: se il video ha già una traccia nella tua lingua (non automatica) la si unisce al posto di tradurre
async function dsTryBuiltinTrans(t) {
  try {
    if (!settings || !t || t.kind === "file" || !t.videoId || !t.segments || !t.segments.length) return false;
    const tl = baseLang(settings.targetLang);
    if (baseLang(t.lang) === tl) return false;
    const v = t.videoId, my = ++job;
    await fixLoad(v);
    // un'unione fatta da te in passato (traccia scelta o file): torna uguale, dalle correzioni salvate
    const flag = (await DS_EXT.storage.local.get(fixMergeKey(v)))[fixMergeKey(v)];
    if (my !== job) return true;
    if (flag && flag.n === t.segments.length) {
      const tx = t.segments.map((s) => { const f = fixApply(v, s.start, s.text, ""); return f.trans || null; });
      if (tx.filter(Boolean).length >= t.segments.length * 0.5) {
        segTrans = tx; transCues = []; translating = false;
        setStatus(`Traduzione unita ai sottotitoli (${flag.label || "salvata"}): nessuna richiesta necessaria.`);
        return true;
      }
    }
    if (settings.useBuiltinTrans === false) return false;
    const cand = (t.avail || []).filter((x) => baseLang(x.lang) === tl && x.kind !== "asr");
    if (!cand.length) return false;
    const trCues = await fixFetchTrack(cand[0]);
    if (my !== job || track !== t) return true;
    const tx = fixMergeText(t.segments, trCues);
    const got = tx.filter(Boolean).length;
    if (got < t.segments.length * 0.6) { dsLiveLog(`traccia ${cand[0].lang} del video: coincide solo con ${got} frasi su ${t.segments.length}: traduco normalmente`); return false; }
    segTrans = tx; transCues = []; translating = false;
    const label = "YouTube, " + (dsLangName(cand[0].lang) || cand[0].lang);
    // anche come correzioni salvate (così restano, e si possono correggere frase per frase)
    const extra = [[t.cues, fixMergeText(t.cues, trCues)]];
    await fixSaveMany(v, [...new Map([...t.segments.map((s, i) => [fixKey(s.start), { start: s.start, trans: tx[i] }]), ...t.cues.map((c, i) => [fixKey(c.start), { start: c.start, trans: extra[0][1][i] }])]).values()].filter((x) => x.trans != null), true);
    await DS_EXT.storage.local.set({ [fixMergeKey(v)]: { n: t.segments.length, at: Date.now(), label } }).catch(() => {});
    setStatus(`Questo video ha già la traduzione (${label}): l'ho unita ai sottotitoli, senza tradurre (${got}/${t.segments.length} frasi). Si può correggere con ⚑.`);
    return true;
  } catch (e) {
    dsLiveLog("unione con la traccia del video non riuscita: " + (e && e.message || e));
    return false;
  }
}

// toglie le traduzioni unite o spostate (non quelle corrette a mano) e il segno dell'unione
async function fixClearChat(v) {
  await fixLoad(v);
  const tl = settings.targetLang;
  let n = 0;
  for (const [k, f0] of Object.entries(dsFixes)) {
    const f = { ...f0 };
    if (!(f.chat && f.chat[tl])) continue;
    f.chat = { ...f.chat }; delete f.chat[tl];
    f.tr = { ...(f.tr || {}) }; delete f.tr[tl];
    n++;
    if (!Object.keys(f.chat).length) delete f.chat;
    if (!Object.keys(f.tr).length) delete f.tr;
    if (Object.keys(f).length) dsFixes[k] = f; else delete dsFixes[k];
  }
  await saveCache(`fix:${v}`, dsFixes);
  if (track && track.videoId === v) await DS_EXT.storage.local.remove(fixMergeKey(v)).catch(() => {});
  return n;
}

// traduzione sfasata: sposta le traduzioni di k frasi (k > 0: a una frase più avanti; k < 0: più indietro), da una frase in poi o tutte
async function fixShiftTrans(k, fromStart) {
  const mode = fixLines();
  if (!mode || !mode.list.length || !k) return { ok: false, error: "non c'è niente da spostare" };
  const n = mode.list.length;
  const i0 = fromStart == null ? 0 : Math.max(0, mode.list.findIndex((c) => (c.end || c.start) > fromStart));
  const cur = Array.from({ length: n }, (_, i) => fixShown(mode, i));
  const out = new Array(n).fill(null);
  for (let i = i0; i < n; i++) { const j = i - k; out[i] = j >= i0 && j < n ? cur[j] : ""; }
  const extra = [];   // (le liste dell'altra modalità non si spostano: sono due modi di vedere gli stessi sottotitoli)
  await fixWriteTrans(mode, out, extra);
  wordsOrigKey = ""; wordsTransKey = "";
  return { ok: true, empty: out.filter((x, i) => i >= i0 && !x).length };
}

// ritraduce da una frase in poi (le traduzioni di prima restano)
async function fixRedoFrom(fromStart) {
  const v = currentVideoId();
  const mode = fixLines();
  if (!mode || !mode.list.length) return { ok: false, error: "non c'è niente da rifare" };
  const i0 = Math.max(0, mode.list.findIndex((c) => (c.end || c.start) > fromStart));
  await fixLoad(v);
  const tl = settings.targetLang;
  for (let i = i0; i < mode.list.length; i++) {      // via le correzioni "incollate/spostate" di queste frasi
    const k = fixKey(mode.list[i].start), f0 = dsFixes[k];
    if (!f0 || !(f0.chat && f0.chat[tl])) continue;
    const f = { ...f0, chat: { ...f0.chat }, tr: { ...(f0.tr || {}) } };
    delete f.chat[tl]; delete f.tr[tl];
    if (!Object.keys(f.chat).length) delete f.chat;
    if (!Object.keys(f.tr).length) delete f.tr;
    if (Object.keys(f).length) dsFixes[k] = f; else delete dsFixes[k];
  }
  await saveCache(`fix:${v}`, dsFixes);
  if (mode.kind === "live") {
    const tail = mode.list.slice(i0);
    const key = liveTransKey(v);
    const map = (await DS_EXT.storage.local.get(key))[key] || {};
    for (const c of tail) { delete map[Math.round(c.start)]; c.trans = null; c.quick = false; c.saved = false; }
    await DS_EXT.storage.local.set({ [key]: map });
    live.pendingTr = live.pendingTr.filter((c) => !tail.includes(c));
    liveQueueTranslation(tail);
  } else {
    const ck = cacheKey(track, trackEngine());
    const saved = (await DS_EXT.storage.local.get(ck))[ck];
    if (Array.isArray(saved)) { for (let i = i0; i < saved.length; i++) saved[i] = null; await saveCache(ck, saved); }
    if (track && track.videoId === v) await DS_EXT.storage.local.remove(fixMergeKey(v)).catch(() => {});
    startTranslation();
  }
  wordsOrigKey = ""; wordsTransKey = "";
  return { ok: true };
}

// ---------- Pannello «Unisci sottotitoli» ----------
function fixMergeOpen(anchor) {
  if (!overlay) return;
  if (wordsCard) wordsCard.remove();
  wordsCardState = { pinned: true, word: null, fix: true, sentence: wordsCurrent || { text: "", start: 0 }, data: null };
  wordsCard = el("div", "dualsub-card dualsub-fixcard");
  overlay.append(wordsCard);
  fixMergePanel();
  wordsPlace(anchor);
}
function fixMergePanel(message) {
  const st = wordsCardState;
  if (!wordsCard || !st) return;
  const v = currentVideoId();
  wordsCard.textContent = "";
  const head = el("div", "dualsub-card-head");
  head.append(el("div", "dualsub-card-title", "🔗 Unisci sottotitoli"));
  const close = el("button", "dualsub-card-btn", "×");
  close.title = "Chiudi";
  close.addEventListener("click", wordsCloseCard);
  head.append(close);
  wordsCard.append(head, el("div", "dualsub-card-expl", "Mette insieme la trascrizione di questo video con una traduzione già pronta (una traccia di YouTube nella tua lingua, o un file .srt/.vtt), invece di tradurre di nuovo. Le righe si abbinano per il tempo; poi puoi correggere frase per frase con ⚑."));
  const avail = (track && track.avail && track.avail.length ? track.avail : dsAvailTracks[v]) || [];
  const here = track ? { lang: baseLang(track.lang), kind: track.kind === "asr" ? "asr" : "" } : null;
  const busy = async (label, fn) => {
    fixMergePanel(label);
    let r;
    try { r = await fn(); } catch (e) { r = { ok: false, error: String((e && e.message) || e) }; }
    if (!wordsCardState || wordsCardState !== st) return;
    if (!r.ok) { fixMergePanel("Non ci sono riuscito: " + r.error); return; }
    const poor = r.got < r.total * 0.6 ? " Poche frasi coincidono: se la traduzione è sfasata, usa «Traduzione sfasata» in ⚑." : "";
    fixMergePanel(`Fatto ✓ ${r.got === 1 ? "Unita 1 frase" : "Unite " + r.got + " frasi"} su ${r.total}.${poor}`);
  };
  const list = el("div", "dualsub-fix-actions");
  let n = 0;
  for (const tr of avail) {
    if (here && baseLang(tr.lang) === here.lang && (tr.kind === "asr" ? "asr" : "") === here.kind) continue;   // la traccia che sta già sotto
    n++;
    const label = (dsLangName(baseLang(tr.lang)) || tr.lang) + (tr.name && tr.name.toLowerCase() !== (dsLangName(baseLang(tr.lang)) || "").toLowerCase() ? " – " + tr.name : "") + (tr.kind === "asr" ? " (automatici)" : "");
    const b = el("button", "dualsub-card-replay", "▶ " + label);
    b.title = "Scarica questa traccia da YouTube e la unisce alla trascrizione";
    b.addEventListener("click", () => busy("Scarico «" + label + "»…", async () => {
      const cues = await fixFetchTrack(tr);
      if (!cues.length) return { ok: false, error: "YouTube non ha dato nessuna riga per questa traccia" };
      return fixMergeApply(cues, "YouTube, " + label);
    }));
    list.append(b);
  }
  if (!n) list.append(el("div", "dualsub-card-hint", DS_IS_YT ? "Questo video non offre altre tracce di sottotitoli (oltre a quella che stai usando)." : "Qui non ci sono altre tracce di sottotitoli."));
  const f = el("button", "dualsub-card-replay", "📄 Da un file (.srt o .vtt)…");
  f.title = "Scegli un file di sottotitoli già tradotto: viene unito alla trascrizione per il tempo";
  f.addEventListener("click", () => {
    const inp = document.createElement("input");
    inp.type = "file"; inp.accept = ".srt,.vtt,.txt,text/vtt,text/plain";
    inp.addEventListener("change", () => {
      const file = inp.files && inp.files[0];
      if (!file) return;
      busy("Leggo «" + file.name + "»…", async () => {
        const cues = DualSubs.parseCues(dsParseSubs(await file.text()));
        if (!cues.length) return { ok: false, error: "nel file non ho trovato sottotitoli validi (.srt o .vtt)" };
        return fixMergeApply(cues, "file " + file.name);
      });
    });
    inp.click();
  });
  list.append(f);
  wordsCard.append(list);
  const un = el("div", "dualsub-fix-actions");
  const b2 = el("button", "dualsub-card-replay", "↩ Togli le traduzioni unite o spostate");
  b2.title = "Cancella le traduzioni messe qui con «Unisci» o «Sposta» (non le correzioni fatte a mano) e traduce di nuovo con il servizio scelto";
  b2.addEventListener("click", async () => { wordsCloseCard(); await fixClearChat(v); await dsRedoWholeTranslation(); });
  un.append(b2);
  wordsCard.append(un);
  if (message) wordsCard.append(el("div", "dualsub-card-source", message));
}

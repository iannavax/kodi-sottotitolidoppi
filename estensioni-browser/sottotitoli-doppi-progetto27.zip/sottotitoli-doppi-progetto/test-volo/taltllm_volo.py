# 1.5.4: «⇄ Altro modello» nella scheda delle pagine: la stessa parola spiegata da un altro modello (Gemini dopo Groq)
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
CARD = "(document.querySelector('.pav-card')||{}).innerText||''"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test', gemini:'AIza-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "bread", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1200)
        await pg.get_by_role("button", name="Spiega con Groq").click(); await pg.wait_for_timeout(4000)
        c1 = await pg.evaluate(CARD)
        print("1. dopo Groq:", c1.replace("\n", " | ")[:160], "| richieste:", tvolo.log.get("define_by"))
        alt = pg.locator(".pav-card button", has_text="Altro modello")
        print("2. pulsante:", await alt.count())
        await alt.first.click(); await pg.wait_for_timeout(300)
        opts = await pg.evaluate("[...document.querySelectorAll('.pav-card .pav-altllm button')].map(b=>b.textContent)")
        print("3. scelte:", opts)
        await pg.locator(".pav-card .pav-altllm button", has_text="Gemini").first.click(); await pg.wait_for_timeout(4000)
        c2 = await pg.evaluate(CARD)
        by = tvolo.log.get("define_by")
        print("4. dopo Gemini:", c2.replace("\n", " | ")[-300:], "| richieste:", by)
        opts2 = await pg.evaluate("(document.querySelector('.pav-card .pav-altllm')? 'aperta':'chiusa')")
        await alt.first.click(); await pg.wait_for_timeout(300)
        opts3 = await pg.evaluate("[...document.querySelectorAll('.pav-card .pav-altllm button')].map(b=>b.textContent)")
        print("5. scelte dopo Gemini:", opts3)
        ok = by == ["groq", "gemini"] and any("Gemini" in o for o in opts) and not any("Groq" in o for o in opts) and "Fonte: Gemini" in c2 and "🗂 2" in c2 and any("Groq" in o for o in opts3) and opts2 == "chiusa"
        print("errori:", errs if ok else errs + ["altro modello non va"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        ext = sw.url.split("/")[2]
        for lang in ["", "it", "cs"]:
            await sw.evaluate("chrome.storage.sync.set({ttsSpeaches:true, ttsLang:'%s'})" % lang)
            pop = await ctx.new_page(); await pop.goto(f"chrome-extension://{ext}/popup.html"); await pop.wait_for_timeout(2500)
            print(repr(lang), await pop.evaluate("(()=>{const g=document.getElementById('ttsKokoroG'); return [g.hidden, g.label, [...g.querySelectorAll('option')].map(o=>o.textContent)]})()"))
            await pop.close()
        await ctx.close()
asyncio.run(main())

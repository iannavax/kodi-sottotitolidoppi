// Interfaccia nella lingua di «Traduci in» (popup → «Interfaccia in questa lingua»).
// Le scritte dell'estensione sono in italiano; quelle che compaiono (popup, pagine, schede, pulsanti) vengono tradotte
// con Google Traduttore (gratis) e ricordate per sempre: una scritta si traduce una volta sola. Si traduce SOLO quello
// che è nell'elenco delle scritte dell'interfaccia (ui-strings.json, preso dal codice): parole, traduzioni,
// sottotitoli e testi dei siti non sono nell'elenco e restano come sono.
var DS_UI = (() => {
  const roots = new Set();
  const observers = new Map();
  let lang = "", strings = null, exact = new Set(), tpls = [], tr = {}, loading = null;
  const pending = new Set();
  let flushTimer = 0;
  const textOrig = new Map();   // nodo di testo → testo originale (in italiano)
  const attrOrig = new Map();   // elemento → { attributo: originale }
  const ATTRS = ["title", "placeholder", "aria-label"];
  // dove ci sono parole e testi veri (sottotitoli, significati, frasi, pagine dei PDF…): mai tradurre lì
  const SKIP = "script, style, textarea, code, pre, [contenteditable='true'], .dsui-skip, .dualsub-orig, .dualsub-trans, " +
    ".dualsub-card-word, .dualsub-card-meaning, .dualsub-card-expl, .dualsub-card-sentfix, .dualsub-word, .dualsub-tword, " +
    ".pav-word, .pav-meaning, .pav-sentence, .pav-sentrans, .pav-example, .pav-sel-text, .textLayer, .dsx-ex-item, .dsx-def-text";
  const base = (l) => String(l || "").split("-")[0].toLowerCase();
  const key = () => "uiTr:" + lang;
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  function compile(t) {
    const re = new RegExp("^" + esc(t).replace(/\\\{\d+\\\}/g, "(.+?)") + "$", "s");
    const order = [...t.matchAll(/\{(\d+)\}/g)].map((m) => +m[1]);
    return { t, re, order };
  }
  // traduzione di un testo dell'interfaccia, se c'è già; altrimenti la chiedo (e intanto resta in italiano)
  function lookup(core) {
    if (exact.has(core)) {
      if (tr[core]) return tr[core];
      pending.add(core); schedule(); return null;
    }
    for (const p of tpls) {
      const m = core.match(p.re);
      if (!m) continue;
      const t = tr[p.t];
      if (!t) { pending.add(p.t); schedule(); return null; }
      const vals = {};
      p.order.forEach((n, i) => { vals[n] = m[i + 1]; });
      return t.replace(/\{(\d+)\}/g, (a, n) => (vals[n] != null ? vals[n] : a));
    }
    return null;
  }
  // simboli e numeri ai bordi (✓, 🗂, ›, ▾, «(», «2 »…) restano come sono: si cerca la scritta in mezzo
  const EDGE = /^([^\p{L}]*)([\s\S]*?)([^\p{L}]*)$/u;
  function lookupEdges(t) {
    const m = t.match(EDGE);
    if (!m || !m[2]) return null;
    const x = lookup(m[2]);
    return x ? m[1] + x + m[3] : null;
  }
  // scritte fatte di pezzi («comune · tra le 5000 più usate ›», «Al contrario: bread · uso: comune», «🗂 2 spiegazioni
  // salvate ▾»): se la scritta intera non è nell'elenco, traduco i pezzi che ci sono (prima restava tutta in italiano)
  const SEP = /(\s*[·—–|•›‹▾▴]\s*|:\s+|\s*[()]\s*|\s*[«»]\s*)/u;
  function lookupParts(core) {
    const parts = core.split(SEP);
    if (parts.length < 2) return null;
    let any = false;
    const out = parts.map((p, i) => {
      if (i % 2 || !/\p{L}{2}/u.test(p)) return p;
      const x = lookup(p.trim()) || lookupEdges(p.trim());
      if (x) { any = true; return p.replace(p.trim(), x); }
      return p;
    });
    return any ? out.join("") : null;
  }
  function translateText(s) {
    const core = s.trim();
    if (!core || core.length > 400 || !/\p{L}/u.test(core)) return null;
    const t = lookup(core) || lookupEdges(core) || lookupParts(core) || lookupParts(core.replace(EDGE, "$2"));
    return t ? s.replace(core, t) : null;
  }
  const skip = (el) => !el || !!el.closest(SKIP);
  function doText(n) {
    if (!lang || skip(n.parentElement)) return;
    const cur = n.nodeValue;
    const orig = textOrig.get(n);
    if (orig != null) {
      const want = translateText(orig);
      if (want != null && cur === want) return;
      if (cur !== want) textOrig.delete(n);   // il codice ha cambiato il testo: è un testo nuovo
    }
    const t = translateText(cur);
    if (t != null && t !== cur) { textOrig.set(n, cur); n.nodeValue = t; }
  }
  function doAttrs(el) {
    if (!lang || skip(el)) return;
    for (const a of ATTRS) {
      if (!el.hasAttribute(a)) continue;
      const cur = el.getAttribute(a);
      const o = attrOrig.get(el) || {};
      if (o[a] != null && translateText(o[a]) === cur) continue;
      const t = translateText(cur);
      if (t != null && t !== cur) { o[a] = cur; attrOrig.set(el, o); el.setAttribute(a, t); }
    }
  }
  function scan(root) {
    if (!lang || !root) return;
    if (root.nodeType === 3) return doText(root);
    if (root.nodeType !== 1 && root.nodeType !== 9) return;
    if (root.nodeType === 1) doAttrs(root);
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    let n;
    while ((n = w.nextNode())) {
      if (n.nodeType === 3) doText(n);
      else doAttrs(n);
    }
  }
  function rescan() {
    for (const r of roots) if (r.isConnected) scan(r);
    if (document.title && lang) { const t = translateText(document.title); if (t) document.title = t; }
  }
  function revert() {
    for (const [n, o] of textOrig) if (n.isConnected) n.nodeValue = o;
    for (const [el, o] of attrOrig) for (const [a, v] of Object.entries(o)) el.setAttribute(a, v);
    textOrig.clear(); attrOrig.clear();
  }
  function schedule() {
    if (flushTimer) return;
    flushTimer = setTimeout(flush, 250);
  }
  async function flush() {
    flushTimer = 0;
    if (!lang || !pending.size) return;
    const texts = [...pending].slice(0, 300);
    texts.forEach((t) => pending.delete(t));
    let r;
    try { r = await DS_EXT.runtime.sendMessage({ type: "uiTranslate", texts, target: lang }); } catch { r = null; }
    if (r && r.map) { Object.assign(tr, r.map); rescan(); }
    if (pending.size) schedule();
  }
  // pulizia: i nodi tolti dalla pagina non servono più
  setInterval(() => { for (const n of textOrig.keys()) if (!n.isConnected) textOrig.delete(n); for (const e of attrOrig.keys()) if (!e.isConnected) attrOrig.delete(e); }, 60000);

  async function load() {
    let s;
    try { s = await DS_EXT.storage.sync.get({ targetLang: "it", uiLang: false }); } catch { return; }
    const want = s.uiLang && base(s.targetLang) !== "it" ? base(s.targetLang) : "";
    if (want === lang) return;
    revert();
    lang = want;
    if (!lang) return;
    if (!strings) {
      try { strings = await DS_EXT.runtime.sendMessage({ type: "uiStrings" }); } catch { strings = null; }
      if (!strings || !strings.exact) { strings = null; lang = ""; return; }
      exact = new Set(strings.exact);
      tpls = (strings.templates || []).map(compile);
    }
    try { tr = (await DS_EXT.storage.local.get({ [key()]: {} }))[key()] || {}; } catch { tr = {}; }
    rescan();
  }
  function ready() { return loading || (loading = load()); }
  DS_EXT.storage.onChanged.addListener((ch, area) => {
    if (area === "sync" && (ch.uiLang || ch.targetLang)) { loading = null; ready(); }
    if (area === "local" && lang && ch[key()] && ch[key()].newValue) { Object.assign(tr, ch[key()].newValue); rescan(); }
  });

  // segue un pezzo di interfaccia (la pagina intera, il contenitore delle schede): anche quello che compare dopo
  function watch(root) {
    if (!root || roots.has(root)) return;
    roots.add(root);
    const mo = new MutationObserver((list) => {
      if (!lang) return;
      for (const m of list) {
        if (m.type === "characterData") doText(m.target);
        else if (m.type === "attributes") doAttrs(m.target);
        else for (const n of m.addedNodes) scan(n);
      }
    });
    mo.observe(root, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    observers.set(root, mo);
    ready().then(() => scan(root));
  }
  // nelle pagine dell'estensione (popup, vocabolario, trascrizione…) tutta la pagina
  if (/^(chrome|moz)-extension:$/.test(location.protocol)) {
    const go = () => watch(document.documentElement);
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", go); else go();
  }
  return { watch, ready, get lang() { return lang; }, t: (s) => (lang && translateText(s)) || s };
})();

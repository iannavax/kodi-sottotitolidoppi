// Gira dentro la pagina di YouTube (world: MAIN).
// Intercetta i sottotitoli scaricati dal player quando premi CC e li passa all'estensione.
(() => {
  if (window.__dualSubsInstalled) return;
  window.__dualSubsInstalled = true;

  const nativeFetch = window.fetch.bind(window);
  // I messaggi viaggiano come stringhe JSON: più affidabile tra Chrome e Firefox
  const post = (msg) => window.postMessage(JSON.stringify({ __dualsub: "page", ...msg }), location.origin);
  const isTimedText = (u) => typeof u === "string" && u.includes("/api/timedtext");
  // registro per il debug (popup → «📋 Copia il registro»): cosa succede ai sottotitoli dentro la pagina
  const dlog = (text) => post({ type: "log", text });
  let lastKey = null, lastAt = 0, goodTrackFor = null;
  // le tracce di sottotitoli del video aperto (dalla risposta del lettore), solo se è proprio quel video
  // elenco semplice delle tracce del video (per «Unisci sottotitoli»): lingua, tipo (asr = automatici), nome, indirizzo
  function availTracks(videoId) {
    const tr = currentTracks(videoId) || [];
    return tr.filter((t) => t && t.languageCode && t.baseUrl).map((t) => ({
      lang: t.languageCode, kind: t.kind || "", url: t.baseUrl,
      name: String((t.name && (t.name.simpleText || (t.name.runs || []).map((r) => r.text).join(""))) || "")
    }));
  }
  function currentTracks(videoId) {
    try {
      const p = document.getElementById("movie_player");
      const pr = p && p.getPlayerResponse && p.getPlayerResponse();
      if (!pr || !pr.videoDetails || pr.videoDetails.videoId !== videoId) return null;
      return (((pr.captions || {}).playerCaptionsTracklistRenderer || {}).captionTracks) || null;
    } catch { return null; }
  }

  // fino a 3 tentativi con una pausa (YouTube risponde ogni tanto 429/503 o vuoto)
  async function getJson3(url) {
    let last;
    for (let i = 0; i < 3; i++) {
      try {
        const r = await nativeFetch(url, { credentials: "include" });
        if (!r.ok) throw new Error("HTTP " + r.status);
        const t = await r.text();
        if (!t) throw new Error("risposta vuota");
        return JSON.parse(t);
      } catch (e) { last = e; await new Promise((ok) => setTimeout(ok, 700 * (i + 1))); }
    }
    throw last;
  }

  async function onCaptured(rawUrl, body) {
    let url;
    try { url = new URL(rawUrl, location.origin); } catch { return; }
    const hadTlang = url.searchParams.has("tlang");
    const fmt = url.searchParams.get("fmt");
    url.searchParams.delete("tlang");
    url.searchParams.set("fmt", "json3");

    const videoId = url.searchParams.get("v");
    const lang = url.searchParams.get("lang");
    const kind = url.searchParams.get("kind") || "";
    const key = `${videoId}|${lang}|${kind}`;
    dlog(`sottotitoli richiesti dal lettore: video ${videoId}, lingua ${lang || "?"}${kind ? " (" + kind + ")" : ""}, formato ${fmt || "?"}${hadTlang ? ", tradotti da YouTube" : ""}, risposta ${body == null ? "non letta" : typeof body === "string" ? body.length + " caratteri" : "oggetto"}`);
    // la stessa richiesta due volte di fila (il lettore la fa a volte doppia) la ignoro; riaccendendo i CC dopo qualche secondo
    // invece i sottotitoli si rimandano (prima restavano "già mandati" e DS non li riceveva più)
    if (key === lastKey && Date.now() - lastAt < 4000) { dlog("stessi sottotitoli di un attimo fa: non li rimando"); return; }
    lastKey = key; lastAt = Date.now();

    // 1.7.38: YouTube a volte chiede i sottotitoli nella lingua del video di prima (la scelta del lettore resta da un video all'altro:
    // video inglese con sottotitoli «polacco automatico»). Se la lingua richiesta non è fra le tracce di QUESTO video, non la mando:
    // chiedo al lettore la traccia giusta (si scarica da sola e arriva qui), e se non basta la scarico io
    if (!hadTlang && lang) {
      const tr = (currentTracks(videoId) || []).filter((t) => t && t.languageCode);
      const base = (x) => String(x || "").toLowerCase().split("-")[0];
      if (tr.length && !tr.some((t) => base(t.languageCode) === base(lang))) {
        const pick = tr.find((t) => (t.kind || "") === kind) || tr.find((t) => t.kind === "asr") || tr[0];
        dlog(`la traccia ${lang}${kind ? " (" + kind + ")" : ""} non è fra quelle di questo video (${tr.map((t) => t.languageCode + (t.kind ? " " + t.kind : "")).join(", ")}): uso ${pick.languageCode}${pick.kind ? " " + pick.kind : ""}`);
        lastKey = null;
        try {
          const p = document.getElementById("movie_player");
          let obj = null;
          try { obj = ((p.getOption("captions", "tracklist") || []).find((t) => base(t.languageCode) === base(pick.languageCode) && (t.kind || "") === (pick.kind || ""))) || null; } catch {}
          p.setOption("captions", "track", obj || (pick.kind ? { languageCode: pick.languageCode, kind: pick.kind } : { languageCode: pick.languageCode }));
        } catch (e) { dlog("non riesco a cambiare traccia nel lettore: " + e.message); }
        setTimeout(async () => {
          if (goodTrackFor === videoId) return;
          try {
            const u = new URL(pick.baseUrl, location.origin); u.searchParams.set("fmt", "json3");
            const d = await getJson3(u.toString());
            if (goodTrackFor === videoId) return;
            goodTrackFor = videoId;
            dlog(`sottotitoli mandati all'estensione: ${(d.events || []).length} eventi (traccia scaricata direttamente)`);
            post({ type: "track", videoId, lang: pick.languageCode, kind: pick.kind || "", baseUrl: u.toString(), events: d.events || [], avail: availTracks(videoId) });
          } catch (e) { dlog("scaricamento della traccia giusta fallito: " + e.message); }
        }, 4000);
        return;
      }
    }
    goodTrackFor = videoId;
    let data = null;
    if (!hadTlang && fmt === "json3" && body) {
      try { data = typeof body === "string" ? JSON.parse(body) : body; } catch {}
    }
    try {
      if (!data) data = await getJson3(url.toString());
    } catch (e) {
      lastKey = null;
      dlog("scaricamento dei sottotitoli fallito: " + e.message);
      post({ type: "error", text: "Non riesco a scaricare i sottotitoli da YouTube (" + e.message + ")." });
      return;
    }
    dlog(`sottotitoli mandati all'estensione: ${(data.events || []).length} eventi`);
    post({ type: "track", videoId, lang, kind, baseUrl: url.toString(), events: data.events || [], avail: availTracks(videoId) });
  }

  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    try {
      const u = String(url);
      if (isTimedText(u)) {
        this.addEventListener("load", () => {
          let body = null;
          try {
            if (this.responseType === "" || this.responseType === "text") body = this.responseText;
            else if (this.responseType === "json") body = this.response;
          } catch {}
          onCaptured(u, body);
        });
      }
    } catch {}
    return origOpen.call(this, method, url, ...rest);
  };

  window.fetch = function (input, init) {
    const p = nativeFetch(input, init);
    try {
      const u = input instanceof Request ? input.url : String(input);
      if (isTimedText(u)) {
        p.then((r) => r.clone().text()).then((t) => onCaptured(u, t)).catch(() => onCaptured(u, null));
      }
    } catch {}
    return p;
  };

  window.addEventListener("message", async (e) => {
    if (e.origin !== location.origin || typeof e.data !== "string" || !e.data.startsWith('{"__dualsub":"ext"')) return;
    let m;
    try { m = JSON.parse(e.data); } catch { return; }
    if (m.type === "reset") lastKey = null;
    // diretta sincronizzata: il video va indietro con i comandi del lettore di YouTube (lo spostamento diretto del
    // video a volte viene annullato dal lettore, che torna alla diretta)
    if (m.type === "seekTo") {
      try {
        const p = document.getElementById("movie_player");
        if (p && typeof p.seekTo === "function") p.seekTo(m.t, true);
        else { const v = document.querySelector("video"); if (v) v.currentTime = m.t; }
      } catch {}
    }
    // spostamento relativo (secondi, negativo = indietro): nelle dirette il punto preciso non si può calcolare dal
    // video (video.seekable copre solo i pochi secondi già scaricati), il lettore invece sa tornare indietro
    if (m.type === "seekBy") {
      try {
        const p = document.getElementById("movie_player");
        if (p && typeof p.seekBy === "function") p.seekBy(m.s);
        else if (p && typeof p.seekTo === "function" && typeof p.getCurrentTime === "function") p.seekTo(p.getCurrentTime() + m.s, true);
        else { const v = document.querySelector("video"); if (v) v.currentTime += m.s; }
      } catch {}
    }
    // di nuovo al momento attuale della diretta
    if (m.type === "seekLive") {
      try {
        const p = document.getElementById("movie_player");
        if (p && typeof p.seekToLiveHead === "function") p.seekToLiveHead();
        else if (p && typeof p.seekTo === "function" && typeof p.getDuration === "function") p.seekTo(p.getDuration(), true);
        else { const v = document.querySelector("video"), b = v && v.buffered; if (b && b.length) v.currentTime = b.end(b.length - 1) - 1; }
      } catch {}
    }
    // diretta sincronizzata: l'indirizzo HLS della diretta che il lettore di YouTube ha già (così il programma di
    // appoggio la legge con ffmpeg senza passare da yt-dlp, che con alcune dirette resta bloccato senza dire niente)
    if (m.type === "hlsUrl") {
      let url = "";
      try {
        const p = document.getElementById("movie_player");
        const pr = (p && typeof p.getPlayerResponse === "function" && p.getPlayerResponse()) || window.ytInitialPlayerResponse || {};
        url = (pr.streamingData && pr.streamingData.hlsManifestUrl) || "";
      } catch {}
      post({ type: "hlsResult", id: m.id, url });
    }
    if (m.type === "fetchYT") {
      try {
        const d = await getJson3(m.url);
        post({ type: "ytResult", id: m.id, events: d.events || [] });
      } catch (err) {
        post({ type: "ytResult", id: m.id, error: String(err.message || err) });
      }
    }
  });

  // Controlla se il video ha sottotitoli (anche automatici)
  let reportedId = null;
  setInterval(() => {
    try {
      const p = document.getElementById("movie_player");
      if (!p || !p.getVideoData || !p.getPlayerResponse) return;
      const vd = p.getVideoData() || {};
      const id = vd.video_id;
      const embedded = /^\/embed\//.test(location.pathname);
      const urlId = new URLSearchParams(location.search).get("v");
      if (!id || id === reportedId || (!embedded && id !== urlId)) return;
      const pr = p.getPlayerResponse();
      if (!pr || !pr.videoDetails || pr.videoDetails.videoId !== id) return;
      const tracks = (((pr.captions || {}).playerCaptionsTracklistRenderer || {}).captionTracks) || [];
      reportedId = id;
      post({ type: "captionsInfo", videoId: id, has: tracks.length > 0, live: !!(vd.isLive || pr.videoDetails.isLive), embedded, avail: availTracks(id) });
    } catch {}
  }, 1000);

  post({ type: "ready" });
})();

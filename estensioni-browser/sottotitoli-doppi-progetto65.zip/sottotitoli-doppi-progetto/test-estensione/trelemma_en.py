# 1.7.9: ✎ forma base: si sceglie la radice di una forma flessa e si apre la sua scheda intera (da vedere e salvare)
import asyncio, os, sys
os.environ.setdefault("NO_ALIGN_IDIOM", "1")
sys.path.insert(0, "/home/claude/e2e")
from charness import *
WORD = "(document.querySelector('.dualsub-card .dualsub-card-word')||{}).textContent||''"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({idioms:true, engine:'gemini', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnFreq:false, learnSpell:false, ankiImage:true, ankiImageLang:'en'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ruIdiom"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/сожалению/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=30000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("сожалению")).click(); await pg.wait_for_timeout(2500)
        print("1. scheda:", await pg.evaluate(WORD))
        print("   pulsanti:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card button')].map(b=>b.textContent)"))
        q0 = list(log.get("wp", [])); print("   ricerche immagine prima:", q0)
        await pg.locator(".dualsub-card .dualsub-explainbtn").click(); await pg.wait_for_timeout(5000)
        q1 = list(log.get("wp", [])); print("2. dopo la spiegazione:", q1)
        ok = len(q1) > len(q0) and any("rimpianto" in q for q in q1[len(q0):])
        print("errori:", errs if ok else errs + ["la ricerca non è stata aggiornata"], log["errors"])
        await ctx.close()
asyncio.run(main())

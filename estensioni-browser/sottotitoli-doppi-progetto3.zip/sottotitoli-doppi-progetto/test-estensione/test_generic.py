import asyncio, json, sys
from bharness import *
EXT_DIR = sys.argv[1]
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', autoTranscribe:true})
          .then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))""")
        errs = []
        async def open_page(url):
            pg = await ctx.new_page()
            pg.on("pageerror", lambda e: errs.append(f"{url}: {e}"))
            await pg.goto(url)
            return pg
        async def tab_id(url_part):
            return await sw.evaluate(f"chrome.tabs.query({{}}).then(t=>t.find(x=>(x.url||'').includes('{url_part}')).id)")
        async def send(tid, msg):
            return await sw.evaluate(f"chrome.tabs.sendMessage({tid}, {json.dumps(msg)})")
        async def lines(pg):
            return await pg.evaluate("""(()=>{const o=document.querySelector('.dualsub-orig'),t=document.querySelector('.dualsub-trans'),l=document.querySelector('.dualsub-layer');
               return {o:o?o.textContent:'', t:t?t.textContent:'', layer: l? l.className + ' ' + Math.round(l.getBoundingClientRect().width)+'x'+Math.round(l.getBoundingClientRect().height):'nessuno'}})()""")

        # 1. video con sottotitoli propri (<track>)
        pg = await open_page("https://example.test/track.html")
        await pg.evaluate("document.getElementById('v').play()")
        await pg.wait_for_function("(document.querySelector('.dualsub-trans')||{}).textContent?.startsWith('IT[')", timeout=15000)
        print("1. video con <track>:", await lines(pg))
        print("   sottotitoli nativi nascosti:", await pg.evaluate("document.getElementById('v').textTracks[0].mode"))

        # 2. sito qualsiasi senza sottotitoli: trascrizione avviata dal popup
        pg2 = await open_page("https://example.test/video.html")
        await pg2.evaluate("document.getElementById('v').play()")
        await pg2.wait_for_timeout(1500)
        tid = await tab_id("video.html")
        st = await send(tid, {"type": "liveState"})
        print("2. sito qualsiasi, stato:", st)
        print("   avvio trascrizione:", await send(tid, {"type": "live", "action": "start"}))
        await pg2.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent?.includes('frase')", timeout=25000)
        await pg2.wait_for_timeout(1500)
        print("   sottotitoli:", await lines(pg2))

        # 3. file audio/video aperto direttamente: parte da solo
        n0 = len(log["groq"])
        pg3 = await open_page("https://example.test/altro.wav")
        await pg3.wait_for_timeout(800)
        print("3. file diretto (nuovo indirizzo, niente cache): tipo pagina =", await pg3.evaluate("document.contentType"), "| elementi:", await pg3.evaluate("[...document.querySelectorAll('video,audio')].map(x=>x.tagName).join(',')"))
        await pg3.evaluate("document.querySelector('video,audio').play()")
        await pg3.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent?.includes('frase')", timeout=25000)
        print("   trascrizione partita da sola:", len(log["groq"]) - n0, "richieste |", await lines(pg3))

        # 4. pagina con solo audio
        pg4 = await open_page("https://example.test/audio.html")
        await pg4.evaluate("document.getElementById('v').play()")
        await pg4.wait_for_timeout(1000)
        tid4 = await tab_id("audio.html")
        await send(tid4, {"type": "live", "action": "start"})
        await pg4.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent?.includes('frase')", timeout=25000)
        print("4. solo audio:", await lines(pg4))

        # 5. aspetto personalizzato
        await sw.evaluate("chrome.storage.sync.set({origColor:'#00ff00', transColor:'#ff00ff', bgOpacity:0.2, subFont:'serif', subShow:'both', transFirst:true, fontSize:30})")
        await pg4.wait_for_timeout(600)
        look = await pg4.evaluate("""(()=>{const o=document.querySelector('.dualsub-orig'),t=document.querySelector('.dualsub-trans'),cs=getComputedStyle;
           return {coloreOrig: cs(o).color, coloreTrad: cs(t).color, sfondo: cs(o).backgroundColor, carattere: cs(o).fontFamily.split(',')[0], dimensione: cs(o).fontSize,
                   tradSopra: t.getBoundingClientRect().top < o.getBoundingClientRect().top}})()""")
        print("5. aspetto:", look)
        await sw.evaluate("chrome.storage.sync.set({subShow:'trans'})"); await pg4.wait_for_timeout(500)
        print("   solo traduzione -> originale visibile:", await pg4.evaluate("getComputedStyle(document.querySelector('.dualsub-orig')).display"))

        # 6. disattivare un sito
        await sw.evaluate("chrome.storage.sync.set({disabledSites:['example.test'], subShow:'both', transFirst:false})"); await pg4.wait_for_timeout(600)
        print("6. sito disattivato -> sottotitoli nascosti:", await pg4.evaluate("document.querySelector('.dualsub-overlay').hidden"))
        await sw.evaluate("chrome.storage.sync.set({disabledSites:[]})")

        # 7. pagina Trascrizione e traduzione, collegata alla scheda del punto 2
        await pg2.wait_for_timeout(8000)
        tp = await ctx.new_page()
        tp.on("pageerror", lambda e: errs.append(f"transcript: {e}"))
        await tp.goto(f"chrome-extension://{sw.url.split('/')[2]}/transcript.html?tab={tid}")
        await tp.wait_for_timeout(1500)
        print("7. pagina trascrizione:", await tp.inner_text("#subtitle"))
        print("   testo unico:", (await tp.inner_text("#textView"))[:160].replace("\n", " / "))
        print("   copertura:", (await tp.inner_text("#coverage"))[:90])
        async with tp.expect_download() as d:
            await tp.click("#dlSrtBoth")
        print("   SRT doppio:", open(await (await d.value).path(), encoding="utf-8-sig").read()[:120].replace("\n", " / "))
        # trascrizione del file intero della scheda
        print("   pulsante 'file di questa scheda' visibile:", await tp.is_visible("#fromTab"))
        n1 = len(log["groq"])
        await tp.click("#fromTab")
        for _ in range(60):
            if "Trascrizione completa" in await tp.inner_text("#status") or "Errore" in await tp.inner_text("#status"): break
            await tp.wait_for_timeout(500)
        print("   ", await tp.inner_text("#status"), "| richieste a Groq:", len(log["groq"]) - n1)
        await tp.wait_for_timeout(6000)
        print("   dopo la traduzione della scheda:", await tp.inner_text("#subtitle"))
        await pg2.evaluate("const v=document.getElementById('v'); v.currentTime=50; v.play()"); await pg2.wait_for_timeout(800)
        print("   sul video a 50 s:", await lines(pg2))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

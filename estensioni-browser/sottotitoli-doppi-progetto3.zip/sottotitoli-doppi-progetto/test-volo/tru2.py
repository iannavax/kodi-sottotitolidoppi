# Parole al Volo: parole russe (accento tonico, parole spezzate da tag, selezioni di Windows) → scheda, non solo traduzione
import asyncio, os, sys, json
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
orig = tvolo.handle
PAGE = """<!doctype html><html lang="ru"><head><meta charset="utf-8"></head><body style="margin:40px;font:20px/2 sans-serif">
<p id="f"><b>Дорефо́рменная орфогра́фия</b> — система правописания.</p>
<p id="g">Слово <a href="#x">Совреме́нная</a> орфография.</p>
<p id="h">Это Дореф<span style="color:red">о́</span>рменная форма.</p>
<p id="i">Это <i>Совре</i>менная форма.</p>
<table><tr><th id="d">Дореформенная</th><th id="e">Современная</th></tr></table>
<p id="k"><span>Дореформенная</span> орфография.</p>
</body></html>"""
async def handle(route, request):
    if request.url.startswith("https://example.test/"):
        return await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=PAGE)
    return await orig(route, request)
STATE = """[(document.querySelector('.pav-word')||{}).textContent||null, !!document.querySelector('.pav-textcard'), (document.querySelector('.pav-textcard')||{}).innerText ? document.querySelector('.pav-textcard').innerText.slice(0,40) : '']"""
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, etym:false, learnExamples:false, learnFreq:false, learnSpell:false, learnAudio:false, learnTable:false, learnGender:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        async def hov(pid, w):
            await tvolo.hover(pg, pid, w, 1800); r = await pg.evaluate(STATE); await pg.keyboard.press("Escape"); return r
        async def dbl(pid, w):
            await pg.mouse.move(5, 5); await pg.wait_for_timeout(300)
            b = await tvolo.word_box(pg, pid, w); await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
            r = await pg.evaluate(STATE) + [await pg.evaluate("String(getSelection())")]; await pg.keyboard.press("Escape"); await pg.mouse.click(5, 5); return r
        async def sel(js):
            await pg.mouse.move(5, 5); await pg.wait_for_timeout(300)
            await pg.evaluate(js)
            await pg.evaluate("document.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, button:0}))"); await pg.wait_for_timeout(1500)
            r = await pg.evaluate(STATE) + [await pg.evaluate("String(getSelection())")]; await pg.keyboard.press("Escape"); await pg.mouse.click(5, 5); return r
        for pid, w in [("f", "Дорефо"), ("g", "Совреме"), ("h", "Дореф"), ("h", "рменная"), ("i", "Совре"), ("i", "менная"), ("d", "Дореф"), ("e", "Соврем")]:
            print("mouse", pid, w, "→", await hov(pid, w))
        for pid, w in [("f", "Дорефо"), ("g", "Совреме"), ("h", "Дореф"), ("d", "Дореф")]:
            print("dblclick", pid, w, "→", await dbl(pid, w))
        # selezione come su Windows: parola + spazio dopo
        print("sel+spazio →", await sel("const t=document.querySelector('#k span').firstChild; const r=document.createRange(); r.setStart(t,0); r.setEnd(document.querySelector('#k').lastChild,1); getSelection().removeAllRanges(); getSelection().addRange(r)"))
        # selezione che parte dall'elemento (non dal testo)
        print("sel da elemento →", await sel("const s=document.querySelector('#k span'); const r=document.createRange(); r.setStart(document.querySelector('#k'),0); r.setEnd(s.firstChild, s.firstChild.length); getSelection().removeAllRanges(); getSelection().addRange(r)"))
        # cella intera (tripla selezione)
        print("sel cella →", await sel("const r=document.createRange(); r.selectNodeContents(document.getElementById('d')); getSelection().removeAllRanges(); getSelection().addRange(r)"))
        # parola spezzata dal tag selezionata
        print("sel spezzata →", await sel("const p=document.getElementById('h'); const r=document.createRange(); r.setStart(p.firstChild,4); r.setEnd(p.lastChild,7); getSelection().removeAllRanges(); getSelection().addRange(r)"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

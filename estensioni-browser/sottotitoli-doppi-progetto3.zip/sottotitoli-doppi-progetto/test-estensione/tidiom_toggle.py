import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', hoverPause:true})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console: " + m.text) if m.type == "error" else None)
        await pg.goto("https://www.youtube.com/watch?v=idiomTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'') && document.querySelectorAll('.dualsub-tword').length>1", timeout=30000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
        print("frase:", await pg.inner_text(".dualsub-orig"), "|", await pg.inner_text(".dualsub-trans"))
        words = pg.locator(".dualsub-orig .dualsub-word")
        texts = await words.all_inner_texts()
        W = lambda t: words.nth(texts.index(t))
        # 1. fermandomi sui sottotitoli parte una richiesta (allineamento + modi di dire)
        await W(texts[0]).hover(); await pg.wait_for_timeout(8000)
        print("1. richieste di allineamento:", len(log.get("align", [])), "| parole sottolineate:", await pg.evaluate("[...document.querySelectorAll('.dualsub-idiom')].map(x=>x.textContent)"))
        # 2. passo su 'bread': si illumina tutta l'espressione e la scheda la spiega senza richieste
        await pg.mouse.move(600, 40); await pg.wait_for_timeout(300)
        n0 = len(log["gcalls"])
        await W("bread").hover(); await pg.wait_for_timeout(900)
        print("2. illuminate:", await pg.evaluate("[...document.querySelectorAll('.dualsub-idiom-on')].map(x=>x.textContent)"),
              "| scheda:", await pg.evaluate("(document.querySelector('.dualsub-card-word')||{}).textContent"), "=",
              await pg.evaluate("(document.querySelector('.dualsub-card-meaning')||{}).textContent"), "| richieste a Gemini:", len(log["gcalls"]) - n0)
        # 3. clic: spiegazione dell'espressione intera nel contesto
        await W("bread").click(); await pg.wait_for_timeout(9000)
        print("3. clic → chiesto al modello:", log.get("expr"), "| scheda:", await pg.evaluate("(document.querySelector('.dualsub-card-meaning')||{}).textContent"))
        CW = "(document.querySelector('.dualsub-card-word')||{}).textContent"
        print("   scheda:", await pg.evaluate(CW))
        await W("bread").click(); await pg.wait_for_timeout(2500)
        print("4. secondo clic su 'bread':", await pg.evaluate(CW), "| pulsanti:", await pg.locator(".dualsub-card-link").all_inner_texts())
        await W("bread").click(); await pg.wait_for_timeout(2500)
        print("5. terzo clic:", await pg.evaluate(CW))
        await pg.locator(".dualsub-card-link", has_text="Solo la parola").click(); await pg.wait_for_timeout(2500)
        print("6. 'Solo la parola':", await pg.evaluate(CW))
        await pg.locator(".dualsub-card-link", has_text="Tutto il modo di dire").click(); await pg.wait_for_timeout(2500)
        print("7. 'Tutto il modo di dire':", await pg.evaluate(CW))
        await W("fresh").click(); await pg.wait_for_timeout(2500)
        print("8. clic su 'fresh' (stessa espressione aperta):", await pg.evaluate(CW))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

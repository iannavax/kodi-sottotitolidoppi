import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        ext = sw.url.split("/")[2]
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', transcribeMode:'live', hoverPause:false})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsFix"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(26000)
        await pg.evaluate("const v=document.querySelector('video'); v.pause(); v.currentTime=10"); await pg.wait_for_timeout(8000)
        line = lambda: pg.evaluate("({o:(document.querySelector('.dualsub-orig')||{}).textContent, t:(document.querySelector('.dualsub-trans')||{}).textContent})")
        print("0. frase a 10 s:", await line())

        # 1. Ritraduci dalla scheda sul video
        await pg.hover(".dualsub-orig"); await pg.click(".dualsub-fixbtn")
        await pg.wait_for_selector(".dualsub-fixcard")
        await pg.click("text=↻ Ritraduci"); await pg.wait_for_timeout(8000)
        print("1. dopo 'Ritraduci':", await pg.inner_text(".dualsub-fix-trans"), "|", await pg.inner_text(".dualsub-fixcard .dualsub-card-source"))
        await pg.click(".dualsub-fixcard .dualsub-card-btn[title='Chiudi']"); await pg.wait_for_timeout(500)
        print("   sul video:", await line())

        # 2. Ritrascrivi: audio ancora in memoria → subito, con il modello più preciso
        n = len(log["groq_req"])
        await pg.hover(".dualsub-orig"); await pg.click(".dualsub-fixbtn"); await pg.wait_for_selector(".dualsub-fixcard")
        await pg.click("text=🎙 Ritrascrivi"); await pg.wait_for_timeout(9000)
        print("2. richieste a Whisper:", log["groq_req"][n:])
        await pg.click(".dualsub-fixcard .dualsub-card-btn[title='Chiudi']"); await pg.wait_for_timeout(1500)
        print("   sul video:", await line())

        # 3. Correggi a mano
        await pg.hover(".dualsub-orig"); await pg.click(".dualsub-fixbtn"); await pg.wait_for_selector(".dualsub-fixcard")
        await pg.click("text=✎ Correggi a mano")
        ta = pg.locator(".dualsub-fix-input")
        await ta.nth(0).fill("Frase corretta a mano"); await ta.nth(1).fill("Traduzione scritta da me")
        await pg.click(".dualsub-fixcard >> text=Salva"); await pg.wait_for_timeout(1500)
        await pg.click(".dualsub-fixcard .dualsub-card-btn[title='Chiudi']"); await pg.wait_for_timeout(600)
        print("3. dopo la correzione a mano:", await line())

        # 4. Togli una frase (quella a 17 s)
        await pg.evaluate("document.querySelector('video').currentTime=17"); await pg.wait_for_timeout(700)
        before = await line()
        await pg.hover(".dualsub-orig"); await pg.click(".dualsub-fixbtn"); await pg.wait_for_selector(".dualsub-fixcard")
        await pg.click("text=✕ Togli questa frase"); await pg.wait_for_timeout(800)
        print("4. tolta:", before["o"], "→ ora sul video:", await line())
        await pg.wait_for_timeout(3000)
        await pg.close()

        # 5. Ricarico la pagina: le correzioni restano; poi "Ritrascrivi" senza audio in memoria
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsFix"); await pg.wait_for_timeout(1500)
        await pg.evaluate("const v=document.querySelector('video'); v.currentTime=10; v.play()"); await pg.wait_for_timeout(700)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(500)
        print("5. dopo il ricaricamento, a 10 s:", await line())
        await pg.evaluate("document.querySelector('video').currentTime=3"); await pg.wait_for_timeout(700)
        n = len(log["groq_req"])
        await pg.hover(".dualsub-orig"); await pg.click(".dualsub-fixbtn"); await pg.wait_for_selector(".dualsub-fixcard")
        await pg.click("text=🎙 Ritrascrivi"); await pg.wait_for_timeout(12000)
        print("   ritrascrivi senza audio in memoria → richieste:", log["groq_req"][n:])
        await pg.evaluate("const v=document.querySelector('video'); v.pause(); v.currentTime=3"); await pg.wait_for_timeout(800)
        print("   a 3 s:", await line())

        # 6. Pagina della trascrizione: ritraduci dalla riga
        tid = await sw.evaluate("chrome.tabs.query({}).then(t=>t.filter(x=>(x.url||'').includes('noCapsFix')).pop().id)")
        tp = await ctx.new_page(); tp.on("pageerror", lambda e: errs.append("pagina: " + str(e)))
        await tp.goto(f"chrome-extension://{ext}/transcript.html?tab={tid}"); await tp.wait_for_timeout(2000)
        await tp.click("#tabTime")
        rows = tp.locator("#timeView .line")
        print("6. righe:", await rows.count(), "| riga 2:", (await rows.nth(1).inner_text()).replace("\n", " | ")[:110])
        await rows.nth(1).locator("button[title='Ritraduci questa frase']").click(); await tp.wait_for_timeout(9000)
        print("   dopo 'Ritraduci' dalla pagina:", (await tp.locator("#timeView .line").nth(1).inner_text()).replace("\n", " | ")[:110], "|", await tp.inner_text("#status"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# Sottotitoli Doppi + Parole al Volo — estensione per il browser

*English version → [GUIDE.en](GUIDE.en.md)*

**Impara le lingue guardando video e leggendo.** Una sola estensione per due cose:

- **🎬 nei video** (Sottotitoli Doppi): sotto i sottotitoli originali compare la traduzione nella tua lingua, in un altro colore. Ogni parola si tocca con il mouse per vederne il significato in quella frase, sentirne la pronuncia e salvarla in un vocabolario personale. Funziona su YouTube e su quasi tutti i siti con video o audio; se un video non ha sottotitoli, l'estensione ascolta l'audio e li scrive da sola;
- **📄 sulle pagine e nei PDF** (Parole al Volo): passi il mouse su una parola di qualsiasi pagina e compare la sua scheda; selezioni un pezzo di testo e te lo traduce tutto insieme.

Vocabolario, parole che conosci, chiavi dei servizi, voci e Anki sono gli stessi per tutte e due.

Browser: **Edge, Chrome, Brave** (e gli altri basati su Chromium) e **Firefox**.

> **Lingua dell'interfaccia.** Le scritte dell'estensione sono in italiano. Nel popup, sotto **Traduci in**, accendi **Interfaccia in questa lingua**: popup, schede e pagine compaiono nella lingua in cui traduci (tradotte una volta con Google Traduttore e ricordate; le parole, le traduzioni e i sottotitoli non cambiano). Spegnendola torna l'italiano.

---

## Indice

1. [Cosa fa, in breve](#1-cosa-fa-in-breve)
2. [Installazione e aggiornamenti](#2-installazione-e-aggiornamenti)
3. [Primi passi (5 minuti)](#3-primi-passi-5-minuti)
4. [Il popup: Video e Pagine](#4-il-popup-video-e-pagine)
5. [Dove funziona](#5-dove-funziona)
6. [I sottotitoli sul video](#6-i-sottotitoli-sul-video)
7. [Imparare con le parole](#7-imparare-con-le-parole)
8. [Sulle pagine web](#8-sulle-pagine-web)
9. [I PDF](#9-i-pdf)
10. [Il vocabolario personale](#10-il-vocabolario-personale)
11. [Video senza sottotitoli: la trascrizione dell'audio](#11-video-senza-sottotitoli-la-trascrizione-dellaudio)
12. [La pagina "Trascrizione e traduzione"](#12-la-pagina-trascrizione-e-traduzione)
13. [I servizi di traduzione](#13-i-servizi-di-traduzione)
14. [Consumare meno richieste gratuite](#14-consumare-meno-richieste-gratuite)
15. [Un modello di traduzione sul tuo computer](#15-un-modello-di-traduzione-sul-tuo-computer)
16. [Se qualcosa non va](#16-se-qualcosa-non-va)
17. [Privacy e note](#17-privacy-e-note)

---

## 1. Cosa fa, in breve

| Funzione | Cosa fa |
|---|---|
| 🎬 **Doppia riga** | Originale sopra, traduzione sotto (o al contrario), sul video stesso. |
| 🧠 **Traduzione che capisce il discorso** | Con Gemini e gli altri modelli la traduzione tiene conto delle frasi vicine, non riga per riga. |
| 👆 **Parole interattive** | Passi il mouse su una parola e vedi il significato; con **✨ Spiega con…** la spiegazione completa in quella frase. |
| 🔗 **Traduzione ↔ originale** | Passando su una parola tradotta si illumina quella originale da cui viene. Articoli e preposizioni "aggiunte" dalla traduzione sono segnalate. |
| 🗣️ **Pronuncia** | Ogni parola si può ascoltare; il video si abbassa da solo mentre parla. |
| ⭐ **Vocabolario** | Salvi parole ed espressioni con la frase e il punto del video; esporti tutto per Anki. |
| 🎙️ **Trascrizione dell'audio** | Video senza sottotitoli? L'audio viene trascritto con Whisper (gratis con una chiave Groq). |
| 📄 **Testo completo** | Una pagina con tutto il testo del video, da leggere, copiare o scaricare (.txt, .srt). |
| ✏️ **Correzioni** | Una frase tradotta o trascritta male si rifà con un clic, o si corregge a mano. |
| 📄 **Pagine web** | Su qualsiasi pagina: scheda della parola passando il mouse, traduzione del testo che selezioni. |
| 📕 **PDF** | Un lettore PDF suo, con le stesse schede (anche i libri scansionati con il testo riconosciuto). |
| 💸 **Pochi consumi** | Tutto viene salvato: rivedere un video non costa niente. Se un servizio gratuito finisce le richieste, si passa da soli a un altro. |

---

## 2. Installazione e aggiornamenti

### Edge, Chrome, Brave
1. Estrai lo zip `sottotitoli-parole-chrome-vX.Y.Z.zip` in una cartella **che non cancellerai** (per esempio `Documenti\Sottotitoli Doppi`).
2. Apri `edge://extensions` (su Chrome `chrome://extensions`).
3. Attiva **Modalità sviluppatore** (interruttore in basso a sinistra su Edge, in alto a destra su Chrome).
4. Premi **Carica estensione non pacchettizzata** e scegli la cartella del punto 1.
5. Fissa l'icona dell'estensione nella barra (icona del puzzle → puntina), così il popup è a un clic.

### Firefox
1. Con le versioni normali di Firefox le estensioni non firmate non si installano: usa **Firefox Nightly** o **Developer Edition** e in `about:config` metti `xpinstall.signatures.required` su **false**.
2. Apri `about:addons`, premi l'ingranaggio ⚙ → **Installa componente aggiuntivo da file…** e scegli `sottotitoli-parole-firefox-vX.Y.Z.xpi`.
3. In `about:addons` → l'estensione → **Permessi**: deve essere acceso "Accedere ai dati su tutti i siti". Se nel popup compare **Concedi accesso**, cliccalo.

### Aggiornare senza perdere niente
- **Edge/Chrome:** estrai la nuova versione **nella stessa cartella**, sostituendo i file vecchi, poi in `edge://extensions` premi ↻ sulla scheda dell'estensione e ricarica le pagine aperte.
- **Firefox:** installa il nuovo .xpi sopra quello vecchio.

> ⚠️ **Non rimuovere mai l'estensione per aggiornarla**: con lei si cancellano le chiavi, le traduzioni salvate e il vocabolario.

### Video e audio sul tuo computer
Per i file aperti con doppio clic nel browser (indirizzi che iniziano con `file:///`): in `edge://extensions` apri **Dettagli** dell'estensione e attiva **Consenti l'accesso agli URL dei file**.

### Se usavi le due estensioni separate
Sottotitoli Doppi e Parole al Volo separate non vengono più aggiornate: questa le sostituisce tutte e due. È un'estensione nuova, quindi parte vuota:
1. installala accanto alle due vecchie (non toglierle subito);
2. porta qui le **parole che conosci** (tutte le lingue insieme) e il **vocabolario**, in uno di questi due modi:
   - **senza file**: qui premi **⇄ Sincronizza adesso** nella pagina **Parole che conosco**, e nel vocabolario **⇄ Sincronizza con le altre estensioni**: prende da tutte e due le vecchie, se sono installate (servono almeno Sottotitoli Doppi 5.20.1 e Parole al Volo 1.13.1);
   - **con un file** (funziona anche con le versioni più vecchie): nell'estensione vecchia apri **Parole che conosco** e premi **Esporta in un file**, poi qui, nella stessa pagina, **Importa da un file…**. Per il vocabolario: **Il mio vocabolario → ⇄ Esporta** nella vecchia e **⇄ Importa…** qui;
3. le **chiavi** (Gemini, Groq…) e le **impostazioni** passano anche loro con ⇄ (solo quelle che qui non hai ancora scelto). Se il messaggio dice che le chiavi non sono arrivate, premi ⇄ anche dentro l'estensione vecchia; altrimenti inseriscile a mano nel popup;
4. per il programma per yt-dlp: apri la sua pagina dal popup (🎬 Video → Video senza sottotitoli → Programma per yt-dlp) e rilancia l'installatore, così riconosce anche questa estensione;
5. quando tutto funziona, togli le due vecchie. Non usare le vecchie e la nuova insieme: le schede comparirebbero due volte.

---

## 3. Primi passi (5 minuti)

1. **Apri il popup** (clic sull'icona dell'estensione), scheda **🎬 Video**, e in alto scegli **Traduci in**: la tua lingua.
2. Nella sezione **Traduzione → Come tradurre** lascia **Google Traduttore** per cominciare subito, senza chiavi.
3. Apri un video di YouTube nella lingua che studi e accendi i sottotitoli (**CC**). Compare la doppia riga.
4. Passa il mouse su una parola della riga originale: il video si ferma e compare la scheda con il significato.

**Per una traduzione molto migliore (consigliato, gratis):**
1. Vai su **aistudio.google.com/apikey** con il tuo account Google e premi *Create API key* (non serve la carta).
2. Nel popup scegli **Come tradurre → Gemini**, incolla la chiave in **Chiave API** e premi Invio. Il modello si sceglie da solo.

**Sulle pagine** non serve fare niente: passa il mouse su una parola di un articolo in un'altra lingua e compare la sua scheda (dettagli nella [sezione 8](#8-sulle-pagine-web)).

**Per i video senza sottotitoli** serve anche una chiave **Groq**, gratuita: vedi la [sezione 11](#11-video-senza-sottotitoli-la-trascrizione-dellaudio).

---

## 4. Il popup: Video e Pagine

Il pulsante dell'estensione apre il popup con due schede in alto. Il popup si riapre sull'ultima scheda che hai usato.

- **🎬 Video**: tutto quello che riguarda i video (sottotitoli, aspetto, trascrizione, dirette, servizio di traduzione dei sottotitoli, pronuncia, Anki…). Quando questa guida dice «popup → …» parlando di video, è qui.
- **📄 Pagine**: le pagine web e i PDF (scheda passando il mouse, traduzione quando evidenzi, lettore PDF, servizio per spiegare le parole…). Vedi la [sezione 8](#8-sulle-pagine-web).

Sotto **Traduci in** c'è **Interfaccia in questa lingua**: accesa, tutte le scritte dell'estensione (popup, schede, pagine del vocabolario, della trascrizione, del lettore PDF…) compaiono in quella lingua. La prima volta servono un paio di secondi (le scritte si traducono con Google, gratis), poi sono ricordate. Le pagine già aperte si aggiornano da sole.

In comune tra le due schede: le chiavi dei servizi (Gemini, Groq…), la lingua in cui traduci (e quella dell'interfaccia), il **vocabolario**, le **parole che conosci**, le voci della pronuncia, Anki, il programma per yt-dlp.

Separati (hanno lo stesso nome ma servono a cose diverse): il servizio scelto (nei video traduce i sottotitoli, sulle pagine spiega le parole; finché nelle «Pagine» non ne scegli uno, si usa quello dei «Video»), i siti in cui è spenta, il mazzo di Anki unico, il colore delle parole che conosci sulla pagina, le lettere latine «Aa».

---

## 5. Dove funziona

- **YouTube**, anche nei video di YouTube inseriti in altri siti.
- **Qualsiasi sito con un video o un audio**: Vimeo, VK, siti di notizie, podcast, corsi online, siti di TV in diretta. Se il video ha già dei sottotitoli propri li usa e li traduce; altrimenti puoi farli trascrivere.
- **File aperti direttamente nel browser**, da un link o dal computer (mp4, webm, mp3, m4a, ogg, wav, flac…): la trascrizione parte da sola premendo Play.
- **Non funziona** con i siti a contenuti protetti (Netflix, Disney+, Prime Video…): il browser non lascia ascoltarne l'audio. La riga di stato del popup te lo dice.
- **Su qualsiasi pagina web e nei PDF** per le parole scritte: [sezione 8](#8-sulle-pagine-web) e [sezione 9](#9-i-pdf).
- Se su un sito l'estensione non ti serve: popup → 🎬 Video → **Altro** → togli l'attivazione su quel sito (per le pagine: 📄 Pagine → **Attiva su questo sito**).

---

## 6. I sottotitoli sul video

### Accendere e spegnere: il pulsante DS
- **Su YouTube** c'è il pulsante **DS** nella barra dei comandi del video, accanto a CC. **Sugli altri siti** è un piccolo "DS" in alto a destra del video.
- **Acceso** (bordo giallo): si vedono i sottotitoli doppi. **Spento**: spariscono e la trascrizione si ferma, così non consuma quota.
- Se i sottotitoli doppi spariscono per qualsiasi motivo, premi DS: tornano.
- La stessa cosa si fa nel popup, **Altro → Sottotitoli doppi attivi**.

### I pulsanti accanto ai sottotitoli
Passando il mouse sui sottotitoli compaiono a destra:
- **⚑ — Frase sbagliata?** Apre una scheda con:
  - **↻ Ritraduci**: chiede di nuovo la traduzione di quella frase (passa davanti alle altre richieste);
  - **🎙 Ritrascrivi** (solo per le frasi trascritte dall'audio): la fa riascoltare a Whisper con il modello più preciso;
  - **✎ Correggi a mano**: scrivi tu l'originale e/o la traduzione giusta;
  - **✕ Togli**: per le frasi inventate durante la musica.

  Le correzioni restano salvate con il video e valgono anche nei file scaricati.
- **⧉ — Copia o consulta la frase.** Ferma il video e mostra la frase, selezionabile con il mouse:
  - **Copia originale**, **Copia traduzione**, **Copia tutte e due** (se selezioni una parte, copiano solo quella);
  - **Apri in: Google Traduttore · DeepL · Reverso**: la frase (o la parte selezionata) si apre in un'altra scheda, con le lingue già impostate. Reverso mostra le parole dentro tante frasi vere. Per le lingue che Reverso non apre già pronte (per esempio il ceco) il testo viene copiato: incollalo nella sua casella.
- **Sigla della lingua (per esempio EN)** — solo per le frasi trascritte dall'audio: se la trascrizione è nella lingua sbagliata, cliccala e scegli quella giusta (vedi "La lingua della trascrizione").

### Pronuncia IPA delle parole
Nella scheda della parola, sotto la parola, c'è la sua **pronuncia IPA** (alfabeto fonetico internazionale) e, per gli alfabeti diversi dal nostro, la **trascrizione in caratteri latini** (*кошка* → koshka).
- L'IPA viene **sempre da Wiktionary**, gratis e senza token (prima quello inglese, poi quello della lingua della parola, il tuo e i più grandi). Passando il mouse sulla pronuncia leggi da dove viene.
- Se Wiktionary non l'ha (capita con le forme flesse), premi **✨ Spiega con …**: la pronuncia arriva **nella stessa richiesta** della spiegazione del modello, mai con una richiesta a parte. Questo succede solo con l'opzione **Aspetto → IPA anche dal modello, se manca su Wiktionary** accesa; spenta, solo Wiktionary.

### Etimologia delle parole
Nella scheda di una parola, sotto il significato, c'è la sua **etimologia**: da dove viene (per esempio *bread* → dall'inglese antico *brēad*, imparentato con il tedesco *Brot*).

- Viene da **Wiktionary** (gratis, senza chiave), tradotta nella tua lingua con Google; il collegamento "Wiktionary" apre la pagina completa. Per le forme flesse (*walked*, *went*) cerca la forma base.
- Si chiede solo se la scheda resta aperta un attimo, poi resta salvata. Finisce anche nel vocabolario e nelle carte per Anki.
- Se Wiktionary non la ha, premi **✨ Spiega con …**: la spiegazione nel contesto di Gemini (o del servizio scelto) porta anche l'etimologia, nella stessa richiesta (una sola, non due).
- Si accende e spegne nel popup → **Aspetto → Etimologia nella scheda della parola**.

### Aspetto
Popup → **Aspetto dei sottotitoli**: cosa mostrare (entrambe, solo originale, solo traduzione), traduzione sopra o sotto, dimensione del testo e della traduzione, colori, sfondo, altezza sul video, carattere. Le modifiche si vedono subito; **Ripristina l'aspetto predefinito** rimette tutto com'era.

Popup → **Altro → Nascondi i sottotitoli del sito**: nasconde quelli originali del sito, per non vederli due volte.

---

## 7. Imparare con le parole

### La scheda di una parola
- **Passa il mouse** su una parola della riga originale: il video si ferma e compare una scheda con il significato dal dizionario di Google (gratis, nessuna richiesta consumata).
- **Clicca** la parola: la scheda si fissa (resta aperta), sempre con il significato di Google: nessun token consumato.
- **✨ Spiega con …** (il pulsante nella scheda, con il nome del servizio scelto: Gemini, Groq, Mistral, Claude…): chiede **il significato in quella frase**: forma base (per esempio *went → go*), tipo di parola, spiegazione ed esempio, e insieme pronuncia ed etimologia se mancano. Una sola richiesta, **solo quando premi il pulsante**: il modello non parte mai da solo.
- Nella scheda:
  - **🔈** pronuncia con la voce sintetica (la sigla accanto, per esempio *DA*, dice in che lingua); quando esiste una registrazione vera della parola (Wiktionary), accanto compare anche **🔊**, la voce di una persona. In tutta l'estensione **🔊** = registrazione vera, **🔈** = voce sintetica;
  - **☆** salva nel vocabolario;
  - **↺ Riascolta la frase**: torna all'inizio della frase e si ferma alla fine;
  - **Copia la parola / Copia la frase**;
  - **Apri in:** Google Traduttore, DeepL, Reverso, **WordReference** (tra inglese e italiano, spagnolo, francese, tedesco, portoghese) e **Wiktionary** (spiega quasi ogni parola di quasi ogni lingua).
- La scheda si chiude con **×** o **Esc**. Spostando il mouse via dai sottotitoli il video riparte da solo (si può spegnere: **Altro → Pausa quando passi sulle parole**).
- Le spiegazioni restano salvate, anche chiudendo il browser: la stessa parola nella stessa frase non si richiede più.

### Strumenti per imparare
Nella scheda di una parola, sotto il significato, ci sono altri aiuti. Sono tutti **gratis e senza chiavi** e ognuno si spegne nel popup → **Strumenti per imparare**. Si chiedono solo se la scheda resta aperta almeno un attimo, e restano salvati.
- **Dizionario di Google** (nella stessa richiesta della traduzione, gratis): **traduzioni con il loro peso** (la più usata in evidenza, una barretta per quanto è comune; passando il mouse le traduzioni al contrario), **definizioni nella lingua della parola** con un esempio, **sinonimi** e **"vedi anche"**, e **"Forse cercavi…"** nel controllo della scrittura. Google a volte non dà alcune parti: in quel caso non compaiono. Le **definizioni** arrivano anche dal Wiktionary della lingua della parola (e, se mancano, da quello inglese), ognuna con **traduci**; le altre con **altre ›**.
- **Lettere latine sopra le lettere**: con **Aa** accanto ai sottotitoli (o nel popup → Aspetto) sopra ogni lettera di cirillico, greco, armeno, georgiano, ebraico, kana giapponesi e coreano compare la trascrizione; in arabo, persiano, urdu e hindi sopra ogni parola. Tabelle scritte nell'estensione, nessun servizio. Per kanji e caratteri cinesi c'è la lettura della riga intera (Google, gratis). Le grandezze si regolano separatamente nel popup → Aspetto: «Lettere sopra i caratteri» e «Lettura della riga (romaji)».
- **Immagine per Anki** (popup → Anki): nella scheda la vedi e la cambi con ‹ ›, «altre…» (cerca, scegli la fonte, incolla un indirizzo) o ✕; nel vocabolario con 🖼.
- **Parole che conosco** (pulsante in alto nel popup): l'elenco delle parole più usate, con lingua, «segna le prime N», **⇄ Sincronizza adesso** (scambia le parole conosciute con le estensioni vecchie, senza file), esporta e importa. Nel vocabolario ⇄ Esporta/Importa salva e ricarica vocabolario e parole conosciute in un file.
- **Livelli**: «livello ≈ B1 ›» accanto alla frequenza (indicativo, A1…C2 dalla posizione nell'elenco) apre le parole di quel livello; per il giapponese «JLPT N5 ›» apre tutte le parole di quel livello JLPT (Jisho), con «la conosco?».
- **Modi di dire sottolineati**: il primo clic su una parola apre tutta l'espressione, il secondo la parola da sola (e così via).
- **🔊\*** arancione: la registrazione è di un'altra forma della parola (te lo dice passando il mouse).
- **⚑ Traduzione sbagliata?** sotto il significato: rifai con Google, rifai con il modello nel contesto, o correggi a mano (resta salvata).
- **Frequenza**: quanto è usata la parola (per esempio "molto comune · tra le 1000 più usate"). L'elenco della lingua si scarica una volta sola. **Cliccandola** si apre l'elenco delle parole più usate di quella lingua, con la parola evidenziata al suo posto, la ricerca e «la conosco?» per segnare quelle che sai.
- **«la conosco?»**: premilo per le parole che sai già. Diventano **verdi** nei sottotitoli, e in cima al popup leggi **quante parole del video conosci** (per esempio "Conosci il 72% delle parole di questo video"). Anche "Segna come imparata" nel vocabolario la aggiunge.
- **Genere** dei nomi (maschile, femminile, neutro; in tedesco anche *der/die/das*).
- **Giapponese**: dal dizionario **Jisho** (gratis) la lettura in kana, il livello JLPT, se è una parola comune e il significato in inglese.
- **Kanji e caratteri cinesi uno per uno**: nella scheda di una parola giapponese o cinese, la riga «Kanji uno per uno» ha un pulsante per ogni carattere. Cliccandolo vedi solo quel kanji: significato, letture nella lingua del testo e nelle altre (on/kun, pinyin, cantonese, coreano, vietnamita), parti e radicale cliccabili, forma semplificata/tradizionale, tratti, livelli JLPT/classe, HSK, hanja scolastico; «lo conosco?», Jisho, Wiktionary e «scheda del carattere ›» per aprirlo come una parola (vocabolario, Anki) e poi «‹ Torna alla parola». ☆ salva il kanji / ☆ salva tutti i kanji: i singoli caratteri nel vocabolario. Gratis, nessuna richiesta a Gemini o Groq.
- **↺ a sinistra dei sottotitoli**: riascolta la frase; se intanto il video è andato avanti (è giallo) torna alla frase che stavi leggendo.
- **Dirette in anticipo** (popup → Video senza sottotitoli → «Dirette: sottotitoli in anticipo»): nelle dirette di YouTube il video resta qualche secondo indietro e yt-dlp legge l'audio più avanti, così i sottotitoli trascritti arrivano in orario invece che 5–10 secondi dopo. Serve il programma per yt-dlp (con ffmpeg, che l'installatore scarica da solo su Windows; su Mac e Linux va installato a parte).
- **Dirette: normali o sincronizzate**: quando guardi una diretta, il popup mostra in alto «🔴 Questo video è una diretta» con la scelta; sul video il pulsante **⏱** accanto ai sottotitoli fa lo stesso.
- **Kanji e caratteri**: nel riquadro di un kanji i distintivi si cliccano (ordine dei tratti, elenco di tutti i kanji di quel livello JLPT/classe/HSK, radicale…).
- **Scrittura**: se la parola è scritta bene. Senza modello lo controlla LanguageTool (o, per le lingue che non conosce, il dizionario: "parola presente nel dizionario"); con **✨ Spiega con …** il modello dà anche un **voto da 0 a 100** e la forma corretta. Utile con i sottotitoli automatici, che a volte sbagliano.
- **Registrazione vera**: quando Wiktionary ha la parola registrata da una persona, in alto nella scheda compare **🔊** accanto a 🔈 (si spegne con "Pronuncia di madrelingua" nel popup). Vale solo per la parola esatta, non per la forma base. Se la parola non ha una registrazione sua, si usa quella del suo **lemma** (lo stesso usato per l'etimologia: dalla pagina «forma di…», dalla tabella delle forme o scelto da te), e se non c'è nemmeno quella, la pronuncia registrata del dizionario di Google. In quel caso 🔊 è arancione e, passandoci sopra, dice di quale parola è la registrazione.
- **Etimologia**: da Wiktionary, tradotta nella tua lingua (le parole straniere citate restano come sono). Quando Wiktionary dà solo un rimando («participio di *embarazar*», «dal portoghese *embaraçar*»), la scheda segue la catena fino a 3 passaggi, anche in altre lingue, e arriva alla radice (*embarazada* ← *embarazar* ← portoghese *embaraçar* ← *baraço*, «corda»). Vale per tutte le parole, gratis, senza modello.
- **🌳 Albero etimologico**: nella riga dell'etimologia c'è quasi sempre **🌳 albero etimologico**: lo apri e lo chiudi con un clic. Mostra i rami dalla radice più antica fino alla parola (per esempio protogermanico *braudą → inglese antico brēad «pezzo» → medio inglese breed → inglese bread) e, a parte, le parole **parenti** in altre lingue (tedesco Brot, olandese brood). Se Wiktionary ha un albero vero si usa quello; altrimenti l'albero si costruisce dalla catena dell'etimologia scritta su Wiktionary (c'è quasi sempre); se non c'è nemmeno quella, si usa l'immagine del dizionario di Google, quando c'è. Anche l'albero si prende dal lemma o dalla catena dei rimandi se la parola non ne ha uno suo.
- **📈 uso nel tempo**: quanto la parola compare nei libri dal 1800 a oggi (Google Books Ngram), solo quando premi il pulsante. *Il «📖 Dizionario di Google» (Oxford) delle versioni precedenti non c'è più: Google l'ha tolto dalle ricerche (mostra solo l'AI Overview). Significati, sinonimi e traduzioni arrivano da Google Traduttore e da Wiktionary; origine e albero etimologico da Wiktionary.*
- **Etimologia dal lemma**: le forme flesse (declinazioni, tempi verbali: *подошве*, *cantavamo*…) spesso non hanno un'etimologia loro. La scheda la prende dal **lemma**, cioè la forma del dizionario (*подошва*, *cantare*) quando può risalirci con certezza: Wiktionary dice che è una sua forma, oppure la forma compare davvero nella tabella di declinazione o coniugazione del lemma (le parole che non la contengono vengono scartate). Accanto all'etimologia c'è scritto «(di «подошва», lemma…)» e come è stata trovata. Se il lemma è sbagliato: **⚑ → lemma sbagliato?** e scrivi quello giusto, oppure **nessuno**; resta salvato. Se una forma flessa non viene riconosciuta da sola, premi **🔍 cerca radice** (accanto a «Etimologia: non trovata», o nel ⚑ → «lemma sbagliato?»): compaiono le parole candidate: quelle di Wiktionary che contengono quella forma, quelle che cominciano con la stessa radice (*cantavamo* → *cantare*), il lemma suggerito dal modello e le parole di «**Vedi anche**» del dizionario di Google. Prima quelle **✓** sicure (la forma è nella loro tabella), poi le più vicine che hanno un'etimologia («stessa radice»); un clic e l'etimologia (e la registrazione) si prende da lì. Con **scrivilo tu…** lo scrivi a mano. **originale** la mostra com'è scritta su Wiktionary; **⚑** se è sbagliata: ritraduci, rifai con Gemini/Groq, correggi a mano (resta salvata).
- **▦ tabella**: coniugazione del verbo o declinazione del nome (Wiktionary; per le forme flesse quella della forma base).
- **Esempi veri** (Tatoeba): fino a 3 frasi scritte da persone, con la traduzione; **🔊** = registrata da un madrelingua, **🔈** = voce sintetica.
- **Falsi amici e parole parenti**: arrivano con **✨ Spiega con …**, **nella stessa richiesta** della spiegazione (nessuna richiesta in più). Il falso amico compare solo se esiste davvero una parola simile **nella tua lingua** con un altro significato (per *embarazada* in italiano: «imbarazzata»); se non c'è, non compare niente.
- **Tutto nella tua lingua**: spiegazione, falso amico, etimologia e note sono scritte nella lingua di «Traduci in». Se un servizio risponde in un'altra lingua (per esempio in inglese), la richiesta viene rifatta con istruzioni più rigide; se sbaglia ancora, quella parte non compare.
- **🐢 lenta** e **🔁 ×3** accanto a "↺ Riascolta la frase": riascolti la frase più lentamente o tre volte di fila.
- **Immagine nelle carte di Anki** (popup → Anki → "Metti un'immagine nelle carte di Anki", spenta di serie): quando salvi la parola cerca un'immagine su Wikimedia Commons e la mette sul fronte della carta (con l'invio diretto Anki la scarica; nel file si vede quando sei collegato a internet).

### Dalla traduzione all'originale
- **Passa il mouse su una parola della traduzione**: si illumina la parola originale da cui viene, e un'etichetta la scrive. Clic → scheda della parola originale.
- Di serie il collegamento lo fa Google (gratis, approssimato: l'etichetta dice "circa"). Se nel popup accendi **Altro → Modi di dire e collegamento preciso con il modello (consuma richieste)**, Gemini o gli altri modelli lo fanno preciso (una richiesta ogni 8 frasi, passando il mouse).
- **Particelle**: articoli, preposizioni e ausiliari che la traduzione aggiunge ma che non traducono una parola dell'originale (per esempio *i* in *i gatti* per l'inglese *cats*) sono **sottolineati a puntini**. Passandoci sopra, l'etichetta "particella" spiega a quale parte dell'originale appartengono.
- **Al contrario**: passando su una parola originale si illumina la sua traduzione (le particelle più tenui). Senza il modello si usano le traduzioni del dizionario di Google della parola, riconoscendole anche con un'altra desinenza (*bread* → «pani»).

### Pezzi di frase ed espressioni
- **Modo di dire nella scheda**: quando la spiegazione dice che la parola fa parte di un modo di dire (*к сожалению* per *сожалению*), la scheda lo segnala e le altre parole si illuminano con un tratteggio leggero. Il modo di dire resta **ricordato**: se rifai la spiegazione con un altro servizio che non lo riporta, la scheda lo mostra lo stesso. **☆ Salva il modo di dire** lo mette nel vocabolario (e in Anki, se l'invio automatico è acceso).
- **Modi di dire** (solo con l'opzione «Modi di dire e collegamento preciso con il modello» accesa, spenta di serie): con un modello, le espressioni che non si traducono parola per parola (*break the ice*, *give up*…) vengono **sottolineate in arancione**. Passandoci sopra si illumina tutta l'espressione e la scheda ne dà il significato. 
- **Selezione a mano nell'originale**: tieni premuto sulla prima parola e trascina fino all'ultima → scheda con il significato dell'espressione intera.
- **Selezione nella traduzione**: trascina su più parole tradotte → nell'originale si illumina la parte corrispondente; l'etichetta ha **Spiega**, **Copia** e i collegamenti ai servizi. Si chiude con Esc.

### Pronuncia
La lingua si prende dalla parola o dal video. La voce è quella del computer (le voci "Natural" di Edge sono ottime); se manca, si usa la voce online di Google. Durante la pronuncia il video si abbassa e poi torna al volume di prima.

Popup → **Pronuncia delle parole**: lingua (con ricerca tra 98 lingue), voce, **Prova la voce**.

**Voce per ogni lingua.** Nella scheda della parola **⚙** accanto a 🔈 apre le voci per quella lingua: quella che scegli resta salvata e si usa sempre per quella lingua (anche dal popup → Pronuncia delle parole → "Aggiungi una lingua…"). Senza scelta l'estensione prende da sola la migliore: Azure (se acceso), poi le voci "Natural" del computer, poi le altre voci del computer, poi Google. Dopo aver premuto 🔈, passandoci sopra il mouse leggi quale voce ha parlato.

**Voci naturali di Microsoft (Azure Speech), anche in Firefox.** Firefox non vede le voci "Natural" di Edge; con una chiave gratuita di Azure Speech (500.000 caratteri al mese gratis) l'estensione usa le stesse voci in quasi tutte le lingue. Come fare: crea un account su portal.azure.com → "Crea una risorsa" → **Servizi di riconoscimento vocale** (Speech) con il piano gratuito **F0** → "Chiavi ed endpoint": copia la **chiave** e la **regione** (per esempio *westeurope*) nel popup → Pronuncia delle parole, poi **Prova la chiave**.

---

## 8. Sulle pagine web

Su qualsiasi pagina (articoli, Wikipedia, libri online…) le parole scritte in un'altra lingua hanno la loro scheda. Sopra i sottotitoli dei video queste schede non compaiono: lì ci sono già quelle della [sezione 7](#7-imparare-con-le-parole).

### La scheda passando il mouse
**Passando il mouse su una parola** (dopo un attimo fermo) compare la scheda con:
- la parola, la sua traduzione e le altre traduzioni del dizionario di Google (nomi, verbi…);
- la **pronuncia IPA** e, per gli alfabeti diversi dal nostro (russo, greco, giapponese, cinese, arabo…), la **trascrizione in caratteri latini** (*кошка* → koshka);
- l'**etimologia** da Wiktionary, tradotta nella tua lingua;
- la **frase** in cui si trova la parola, con la sua traduzione;
- 🔈 per ascoltare la parola (🔊 quando c'è la registrazione di una persona), "🔈 frase" e "🔈 lenta";
- ☆ per salvarla nel **vocabolario** (con l'invio automatico ad Anki, se acceso);
- "Copia", "Copia la frase" e i collegamenti a Google Traduttore, DeepL, Reverso, WordReference e Wiktionary;
- gli stessi **strumenti per imparare** dei video (frequenza, «la conosco?», livelli, genere, Jisho e kanji uno per uno, scrittura, tabelle, esempi di Tatoeba…), che si spengono nel popup → 📄 Pagine → "Strumenti per imparare".

Con una chiave di **Gemini o Groq**, il pulsante **"Spiega con Gemini"** (una sola richiesta) dà il significato della parola *in quella frase*, la forma base (per esempio *went* → go), se fa parte di un modo di dire, e un esempio; nella stessa richiesta anche l'etimologia (se manca), la pronuncia IPA, i falsi amici, le parole parenti e il voto alla scrittura.

Le schede si chiudono con **Esc**, con un clic fuori, o allontanando il mouse (se ci entri dentro restano aperte). Un **doppio clic** su una parola apre la sua scheda, che resta aperta. Dentro le caselle di testo la scheda non compare, per non disturbare mentre scrivi.

### Il testo selezionato
**Selezionando più parole** (trascinando con il mouse) compare il pannello con la traduzione di tutto il testo insieme, la trascrizione in caratteri latini, il pulsante **Pronuncia IPA** (solo se lo premi), 🔊 per ascoltarlo, ☆ e Anki. Con Gemini o Groq c'è anche **"Traduci meglio"**, una traduzione che tiene conto del contesto.

### Modi di dire
Se nel popup accendi la ricerca automatica dei modi di dire (spenta di serie, perché consuma richieste), quando la scheda resta aperta il modello li cerca nella frase (una richiesta piccola per frase, una volta sola); altrimenti arrivano con «Spiega con…». La scheda li segnala; le altre parole dell'espressione si illuminano con un tratteggio, diverso dalla parola selezionata. La selezione resta sempre tua. Restano ricordati, e **☆ Salva il modo di dire** li mette nel vocabolario.

### Correzioni
- **⚑ Traduzione sbagliata?** In fondo alla scheda e al pannello: **↻ Rifai con Google**, **Rifai con Gemini/Groq** (significato nel contesto e traduzione della frase), **✎ Correggi a mano** (resta salvata, segnata con ✎; "Togli la correzione" per tornare indietro), **Lingua sbagliata**.
- **Lingua riconosciuta male?** In fondo alla scheda c'è "Lingua del testo: … — **sbagliata? cambia**": cerca la lingua giusta, premi Invio e la traduzione viene rifatta. Con **Ricorda per questo sito** la scelta vale per tutte le pagine del sito.
- I testi già nella tua lingua vengono ignorati: passando il mouse su un articolo in italiano non compare niente.

### Il popup → 📄 Pagine
- L'interruttore in alto accende e spegne tutto. Con la tastiera: **Alt+Maiusc+Y**.
- **Scheda passando il mouse** (tastiera **Alt+Maiusc+M**) e **Traduzione quando evidenzi** (tastiera **Alt+Maiusc+S**): si usano separatamente; si spengono anche dalla scheda e dal pannello. Quando li cambi compare per un attimo un avviso in basso sulla pagina. Le scorciatoie si cambiano in `edge://extensions/shortcuts` (Chrome: `chrome://extensions/shortcuts`; Firefox: about:addons → ⚙ → Gestisci scorciatoie delle estensioni).
- **Attiva su questo sito**: per spegnerla solo su un sito.
- **Lingua del testo**: di solito *riconosciuta da sola*; se sbaglia spesso, scegli qui la lingua giusta per tutti i siti, o solo per il sito aperto.
- **La scheda compare**: *subito* oppure *solo tenendo premuto Alt*; **Attesa prima della scheda**: quanto tempo fermo sulla parola prima che compaia.
- **Traduzione della frase nella scheda**, **Pronuncia IPA**, **Etimologia della parola**: si accendono e spengono qui.
- **Colora sulla pagina le parole che conosco**: diventano verde chiaro nel testo; in alto leggi **quante parole della pagina conosci**.
- **Traduzione e chiavi**: gli stessi servizi dei video. Con Google tutto è gratis; con Gemini, Groq o un altro modello compaiono «Spiega con…» e «Traduci meglio»; con DeepL o Microsoft traducono loro la frase e il testo selezionato.

### Quante richieste consuma
- **Google** (significato, traduzione della frase e del testo, trascrizione in caratteri latini, voce): gratis, nessuna chiave.
- **Pronuncia IPA**: da Wiktionary (gratis); se manca, la scrive il modello solo dentro la richiesta di «Spiega con…». Si chiede solo per la parola che guardi, quando la scheda resta aperta almeno un attimo.
- **Spiega nel contesto** e **Traduci meglio**: una richiesta ogni volta che premi il pulsante, mai da sole.

---

## 9. I PDF

Il lettore PDF del browser non lascia entrare le estensioni, quindi l'estensione ha un lettore suo (pdf.js di Mozilla). Lì la scheda passando il mouse e la traduzione del testo evidenziato funzionano come sulle pagine.

- Popup → 📄 Pagine → **«📄 Apri questo PDF con Parole al Volo»** quando la scheda aperta è un PDF, oppure **«📄 Lettore PDF»** → «📂 Apri un PDF…» per un file del computer.
- Con **«Apri sempre i PDF con Parole al Volo»** i PDF si aprono da soli nel lettore.
- In alto: zoom, numero di pagine e **«Caratteri»**.
- **Lettere strane** («Pøíliš», «P¯ÌliöÌ», «Ïðèâåò» invece di «Příliš», «Привет»): molti PDF un po' vecchi hanno il testo in una codifica ma ne dichiarano un'altra (per esempio quelli fatti con Word sul Mac). Il lettore se ne accorge da solo e corregge, controllando con il riconoscimento della lingua del browser che ne esca davvero una lingua: Europa centrale (ceco, slovacco, polacco, ungherese…), cirillico (Windows, KOI8, DOS, Mac), greco, turco, baltico, ebraico, arabo, thai, vietnamita, codifiche Mac e DOS, UTF-8 letto male («Ã©» invece di «é»), cinese, giapponese e coreano. Accanto a «Caratteri» compare quale codifica ha corretto; se sbaglia, scegli tu dall'elenco. I titoli già giusti non vengono toccati, e i PDF giusti (francese, tedesco…) restano come sono. Anche gli accenti scritti a parte (PDF fatti con LaTeX: «ˇcesk´y») vengono riuniti alla loro lettera.
- **Libri scansionati** (archive.org, Google Libri…): le pagine sono immagini (JBIG2, JPEG 2000) e si vedono; se il PDF contiene anche il testo riconosciuto (OCR), le schede funzionano. Se un PDF non contiene il testo vero, accanto a «Caratteri» lo dice.

---

## 10. Il vocabolario personale

- Nella scheda di una parola o di un'espressione premi **☆**: viene salvata con la frase, la traduzione e il punto del video.
- Le parole salvate compaiono **sottolineate in azzurro** nei sottotitoli di tutti i video e sulle pagine.
- Popup → **Il mio vocabolario**: cerca, riapri il video nel punto giusto, segna una parola come imparata (non viene più evidenziata in azzurro, e conta tra le parole che conosci) o eliminala.
- **Anki direttamente** (consigliato): installa in Anki il componente aggiuntivo **AnkiConnect** (Strumenti → Componenti aggiuntivi → Scarica, codice **2055492159**) e riavvia Anki. Con Anki aperto premi **Anki** nella scheda della parola (o **Manda ad Anki** nel vocabolario); la prima volta Anki chiede il permesso: premi **Yes**. Popup → **Anki**: **un mazzo per ogni lingua** ("Lingue::Inglese", "Lingue::Ceco"…), oppure un mazzo unico; invio automatico quando salvi con ☆; prova del collegamento.
- **Immagine nelle carte di Anki** (popup → Anki, spenta di serie): la carta riceve anche un'immagine della parola da Wikimedia Commons, da vedere e cambiare prima di salvare (‹ ›, altre…, ✕) e nel vocabolario (🖼).
- **Esporta per Anki**: scarica un file di testo (con il mazzo di ogni carta). In Anki: *File → Importa* → scegli il file (tipo di nota "Base"). Sul fronte la parola con la frase, sul retro significato, traduzione e link al video.

---

## 11. Video senza sottotitoli: la trascrizione dell'audio

Se un video non ha sottotitoli, l'estensione ascolta l'audio e lo trascrive con **Whisper**; le frasi vengono poi tradotte come le altre, con le parole interattive.

### Preparazione (una volta sola)
1. Crea una chiave gratuita su **console.groq.com/keys** (senza carta).
2. Popup → **Video senza sottotitoli → Chiave Groq**: incollala e premi Invio.

### Tre modi di trascrivere (popup → Video senza sottotitoli)
- **Mentre guardo**: trascrive quello che stai guardando, con pochi secondi di ritardo. L'audio viene mandato a pezzi (al massimo 9 secondi, tagliati nelle pause): quando un pezzo arriva con le sue frasi già passate, le frasi vengono mostrate tutte, in ordine, ognuna almeno il tempo per leggerla, e il ritardo si recupera piano piano (nelle pause del parlato sparisce). Se vuoi sottotitoli sempre in pari con il video, usa **Completa**. Se in modalità Completa lo scaricamento dell'audio va per le lunghe, dopo 12 secondi parte intanto la trascrizione mentre guardi; se è fermo da un minuto e mezzo viene interrotto con un messaggio. La traduzione compare subito in una versione rapida di Google (un po' trasparente) e poi viene sostituita da quella del servizio scelto.
- **Completa**: appena apri il video, l'audio intero viene scaricato e trascritto in pezzi, a partire dal punto in cui sei. I sottotitoli sono in pari con il video, anche saltando avanti e indietro. Su YouTube, Vimeo e simili serve il **programma per yt-dlp** (qui sotto); sui file diretti no.
- **Spenta**: non parte da sola; si avvia con **Trascrivi l'audio di questo video**.

Puoi scegliere una **modalità predefinita** e una diversa **per questo video**. "Completa solo fino a… minuti" evita di consumare la quota con un film aperto per sbaglio.

### Il programma per yt-dlp (solo per "Completa" su YouTube e simili)
Il browser non permette alle estensioni di scaricare l'audio da YouTube: serve un piccolo programma, installato una volta.
1. Popup → **Video senza sottotitoli → Programma per yt-dlp**.
2. **Scarica l'installatore** e lancialo (su Windows doppio clic; se Windows avvisa: *Ulteriori informazioni → Esegui comunque*).
3. Torna sulla pagina e premi **Verifica di nuovo**: deve comparire "Installato e funzionante".

Si aggiorna da solo. L'audio viene usato solo per la trascrizione e poi cancellato (i termini di YouTube non permettono di scaricare i video).

### La lingua della trascrizione
**Se la trascrizione è nella lingua sbagliata** (succede soprattutto con le canzoni: Whisper sente una canzone ceca e scrive in inglese), clicca il pulsante con la sigla della lingua accanto ai sottotitoli (per esempio **EN**), oppure ⚑ → **🌐 Lingua sbagliata?**: cerca la lingua giusta e la trascrizione di quel video viene rifatta in quella lingua. La scelta resta per quel video e vince su quella del popup; "Automatica" la toglie.

- **Video con i sottotitoli automatici di YouTube**: se chiedi la trascrizione, è sempre nella loro lingua (quella dell'audio), anche con "Rileva da sola", e quei sottotitoli aiutano Whisper a capire le parole. Un pezzo che arriva in inglese o in un altro alfabeto viene rifatto (anche con il modello più preciso) e, se resta sbagliato, saltato.
- **Lingua parlata**: lasciala su "Rileva da sola". L'estensione decide la lingua dai primi pezzi con abbastanza parlato e poi la **impone a Whisper**, così non cambia lingua e non scrive la traduzione in inglese al posto della trascrizione. Un vero cambio di lingua nel video viene seguito.
- Se Whisper sbaglia lingua in un video, scegli tu la lingua parlata (c'è una casella di ricerca).

### Trascrizione corretta
**Correggi la grammatica della trascrizione** (attiva di serie): le frasi capite male vengono corrette prima di essere tradotte (solo piccole correzioni nella stessa lingua: le frasi non vengono riscritte). Con Gemini e gli altri modelli avviene nella stessa richiesta della traduzione; con Google o DeepL la fa Gemini (o Groq) a gruppi.

### Trascrivere sul tuo computer
Con un server Whisper compatibile (per esempio Speaches): **Trascrizione con → Server sul tuo computer**, indirizzo (di solito `http://localhost:8000/v1`) e modello.

### Firefox
Per catturare l'audio Firefox deve ammutolire il video, e l'estensione lo rimanda subito alle casse. Se non senti l'audio o la trascrizione non parte, clicca una volta sul video.

---

## 12. La pagina "Trascrizione e traduzione"

Si apre dal popup con **Trascrizione e traduzione**. Contiene tutto il testo del video aperto.

- **Testo unico**: originale e traduzione a paragrafi (o solo uno dei due), da leggere.
- **Frase per frase (e correzioni)**: ogni frase con il suo tempo e i pulsanti **⧉** (copia), **↻** (ritraduci), **🎙** (ritrascrivi), **✎** (correggi), **✕** (togli).
- **Selezionare e copiare**: seleziona una parte con il mouse → sopra compare una barra con **Copia** e i collegamenti a Google Traduttore, DeepL, Reverso (se selezioni nella traduzione, il verso è al contrario). La pagina non si ridisegna mentre selezioni.
- **Copia il testo**, **Scarica testo (.txt)**, **Sottotitoli originali / tradotti / doppi (.srt)**: per tenerli o usarli in un altro lettore.
- **Trascrivere un file intero**: dal computer o dal video della scheda, senza doverlo guardare. Funziona anche senza nessun video aperto.
- **Carica sottotitoli da file (.srt, .vtt)**: per i film scaricati con i sottotitoli a parte.
- **Rifai la traduzione / Rifai la trascrizione**: cancellano quello salvato per il video e lo rifanno (le correzioni a mano restano).

### Tradurre con una chat, senza consumare quote
1. Premi **Copia trascrizione**: copia le frasi numerate con le istruzioni (per i video lunghi a parti di 250: il pulsante dice quale parte copierà).
2. Incollale in una chat (ChatGPT, Claude, Gemini…) e copia la sua risposta.
3. Premi **Incolla traduzione**, incolla la risposta e conferma. L'estensione legge le righe numerate, controlla che sia davvero una traduzione e la usa sul video. Resta salvata.

---

## 13. I servizi di traduzione

Si scelgono nel popup, **Traduzione → Come tradurre**. Scegli il servizio, incolla la chiave in **Chiave API**, premi Invio: il modello si sceglie da solo (per cambiarlo: **Carica modelli**).

| Servizio | Costo | Qualità | Cosa serve |
|---|---|---|---|
| Google Traduttore | gratis | discreta | niente |
| **Gemini** ⭐ consigliato | gratis | ottima, capisce il discorso | chiave da aistudio.google.com/apikey |
| Groq | gratis | buona, velocissimo | chiave da console.groq.com/keys (la stessa della trascrizione) |
| Mistral | gratis | buona, ottima per le lingue europee | chiave da console.mistral.ai |
| OpenRouter | gratis (modelli ":free") | varia | chiave da openrouter.ai/keys |
| Microsoft Translator | gratis fino a 2 milioni di caratteri al mese | molto buona | account Azure, risorsa "Translator" piano F0: chiave e **area** (es. *westeurope*) |
| DeepL | gratis fino a un limite mensile | molto alta | chiave "API Free" da deepl.com/pro-api (chiede una carta per verifica) |
| Modello sul computer | gratis, senza limiti | dipende dal PC | Ollama o LM Studio ([sezione 15](#15-un-modello-di-traduzione-sul-tuo-computer)) |
| Claude | a pagamento (pochi centesimi a video) | ottima | chiave da console.anthropic.com |
| YouTube riga per riga | gratis | scarsa | niente |

Gemini, Groq, Mistral, OpenRouter, Claude e il modello sul computer sono **modelli linguistici**: oltre a tradurre capiscono il discorso, spiegano le parole nel contesto, trovano i modi di dire e correggono la trascrizione. Google, Microsoft e DeepL sono **traduttori classici**: traducono bene, ma non fanno il resto.

Le chiavi si vedono e si copiano con i pulsanti **Mostra** e **Copia** accanto alla casella (utile per l'add-on di Kodi). Non mostrarle in video o in foto: chi le vede le può usare.

### Servizi di riserva
Quando il servizio scelto ha finito le richieste gratuite di oggi, nel popup sotto "Come tradurre" compare un avviso giallo: dice a che ora tornano (le quote di Gemini si azzerano a mezzanotte della California, verso le 9 in Italia) e quale servizio si usa intanto. Con **"Riprova … adesso"** la traduzione del video riprende subito con il servizio scelto (utile se hai cambiato chiave o modello).
Con **Se finiscono le richieste gratuite, continua con un altro servizio di cui hai la chiave** (attiva di serie), quando un servizio esaurisce la quota del giorno l'estensione continua da sola con il primo altro servizio di cui hai inserito la chiave, nell'ordine di **Ordine dei servizi** (di serie **Gemini → Groq → Mistral → OpenRouter → Ollama/LM Studio → Claude → Microsoft → DeepL**), e alla fine **Google**. Il servizio esaurito viene saltato fino al giorno dopo.

### Modello per ogni compito
In cima alla sezione c'è una tendina per ogni lavoro: **sottotitoli dei video**, **testi delle pagine e PDF**, **trascrizione dell'audio**, **spiegazioni («✨ Spiega con…»)**, **correzione della trascrizione**, **pronuncia IPA del testo selezionato** e **collegamento parole e modi di dire**. «Automatico» usa il primo modello pronto della fila qui sotto; se il modello scelto non risponde o ha finito le richieste di oggi, lo sostituisce il primo pronto.

### Ordine dei servizi
Sotto, **Ordine dei servizi** mostra la fila di tutti i servizi, ognuno con il suo stato (*pronto*, *manca la chiave*, *manca il modello*, *richieste finite per oggi*):
- **↑ ↓** cambiano l'ordine; la **casella** spenta toglie il servizio dalla fila (non si usa mai da solo);
- **Usa adesso** lo mette primo e lo sceglie subito anche per tradurre, poi fa una prova;
- **Prova** traduce una frase di prova e dice *✓ Funziona* (con la traduzione e i secondi) o *✗ Non funziona* con il motivo (per Ollama: programma spento, OLLAMA_ORIGINS mancante, modello non scelto…).

L'ordine vale per i servizi di riserva, per **✨ Spiega con…** (se traduci con Google, DeepL o Microsoft si usa il primo modello pronto della fila, sempre e solo quando premi il pulsante), per la pronuncia IPA e per la correzione della trascrizione. Per provare Ollama: scegli «Modello sul tuo computer», premi «Carica modelli», poi **Usa adesso**.

**Spiegazioni («✨ Spiega con…») con**: un modello solo per le spiegazioni, diverso da quello dei sottotitoli. Per esempio sottotitoli con **Gemini** (veloce) e spiegazioni con **Ollama** (sul computer: nessun limite, nessuna richiesta consumata). Se il modello scelto non risponde o ha finito le richieste di oggi, la spiegazione la fa il primo modello pronto della fila, e la scheda lo dice; dopo 5 minuti si riprova con quello scelto.

I modelli che «pensano» prima di rispondere (Gemma 4, Qwen 3…: in Ollama scrivono «Thinking…») con l'estensione rispondono senza ragionamento, molto più in fretta. Se il computer fatica (ventole, schermo esterno che si stacca), usa un modello più piccolo, per esempio `gemma4:e2b`.

Per inserire più chiavi: scegli un servizio, incolla la sua chiave, poi torna al servizio che preferisci. Sotto la casella vedi l'elenco dei servizi pronti e di quelli finiti per oggi.

---

## 14. Consumare meno richieste gratuite

- **Niente si traduce due volte**: traduzioni, trascrizioni, spiegazioni e correzioni restano salvate. Rivedere un video, anche guardato solo in parte, non costa niente.
- La traduzione si chiede a **gruppi di 120 frasi**: un film di due ore costa circa 12 richieste a Gemini.
- Al passaggio del mouse e al clic si usa il dizionario di Google (gratis); il modello solo quando premi **✨ Spiega con …** (o «Spiega con…» sulle pagine).
- Il modello predefinito di Gemini è **gemini-flash-lite-latest**, quello con più richieste gratuite al giorno.
- Le quote di Gemini si azzerano verso le **9 del mattino** (ora italiana). Quanto hai usato lo vedi su aistudio.google.com.
- Per un film intero senza toccare le quote: **Copia trascrizione / Incolla traduzione** con una chat ([sezione 12](#12-la-pagina-trascrizione-e-traduzione)).

---

## 15. Un modello di traduzione sul tuo computer

Gratis, senza limiti e privato. Serve un PC abbastanza potente (16 GB di RAM consigliati).

### Con Ollama
1. Installa Ollama da **ollama.com**.
2. Scarica un modello: `ollama pull gemma3:12b` (o `gemma3:4b` se il PC è meno potente).
3. Permetti le richieste del browser (senza questo passaggio Ollama le rifiuta):
   - **Windows**: nel prompt dei comandi `setx OLLAMA_ORIGINS "chrome-extension://*,moz-extension://*"`, poi chiudi Ollama (icona vicino all'orologio → Quit) e riaprilo;
   - **Mac**: `launchctl setenv OLLAMA_ORIGINS "chrome-extension://*,moz-extension://*"`, poi riapri Ollama;
   - **Linux**: `sudo systemctl edit ollama`, aggiungi `[Service]` e `Environment="OLLAMA_ORIGINS=chrome-extension://*,moz-extension://*"`, poi `sudo systemctl restart ollama`.
4. Nel popup scegli **Modello sul tuo computer** (indirizzo `http://localhost:11434/v1`) e premi **Carica modelli**.

### Con LM Studio
Scarica un modello, nella sezione *Developer* avvia il server e attiva **Enable CORS**. Nel popup scrivi l'indirizzo `http://localhost:1234/v1` e premi **Carica modelli**.

---

## 16. Se qualcosa non va

Guarda prima la **riga di stato in fondo al popup**: dice cosa sta facendo l'estensione e perché si è fermata.

| Cosa vedi | Cosa fare |
|---|---|
| "Nessun segnale da YouTube" | Premi **Concedi accesso** se compare, poi ricarica la pagina. |
| I sottotitoli doppi non compaiono | Controlla che **DS** sia acceso e che il video abbia i sottotitoli (CC) accesi. Su YouTube, se non basta, cambia lingua dei sottotitoli dall'ingranaggio e rimetti quella giusta. |
| "Hai finito i minuti di trascrizione" (Groq) | La quota gratuita di Whisper è finita (all'ora o al giorno): il messaggio dice tra quanto si libera. Le frasi già trascritte restano. |
| "Limite di richieste raggiunto" | Il servizio ha rifiutato perché hai superato la quota: l'estensione aspetta e riprova da sola (al minuto) o passa a un servizio di riserva (al giorno). Non si perde niente. |
| "Chiave non valida" | Ricopia la chiave (pulsante **Mostra** per controllarla). |
| La trascrizione è nella lingua sbagliata | Imposta **Lingua parlata**, poi nella pagina "Trascrizione e traduzione" premi **Rifai la trascrizione**. |
| Una frase è tradotta o trascritta male | Pulsante **⚑** sui sottotitoli → Ritraduci, Ritrascrivi o Correggi a mano. |
| Netflix, Disney+, Prime Video | Non si può: il browser protegge l'audio di questi siti. |
| Firefox: il video resta muto | Clicca una volta sul video. |
| Sulle pagine non compare la scheda | Controlla nel popup → 📄 Pagine l'interruttore generale, "Scheda passando il mouse", "Traduzione quando evidenzi" e "Attiva su questo sito". Dopo l'installazione ricarica le pagine già aperte. Nelle pagine interne del browser (impostazioni, negozio delle estensioni) le estensioni non funzionano. In Firefox: about:addons → l'estensione → **Permessi** → "Accedere ai dati su tutti i siti". |
| Un PDF si apre senza schede | Apri il PDF con il lettore dell'estensione ([sezione 9](#9-i-pdf)). Se le parole escono strane prova «Caratteri»; se è una scansione senza testo riconosciuto, non ci sono parole da leggere. |
| Anki non risponde | Anki deve essere aperto, con AnkiConnect installato; se la finestra del permesso è stata chiusa con "No", riprova con "Prova il collegamento con Anki". |
| Le schede compaiono due volte | Sono ancora accese le estensioni vecchie (Sottotitoli Doppi o Parole al Volo separate): toglile. |

---

## 17. Privacy e note

- Le chiavi e tutto quello che salvi (traduzioni, vocabolario, correzioni) restano **nel tuo browser**. Non c'è nessun server dell'estensione.
- I testi vengono mandati solo al servizio che scegli (Google, Gemini, Groq…): sulle pagine, le parole e le frasi su cui passi il mouse. Gli strumenti per imparare mandano la parola (e, per il controllo della scrittura, la frase) a Wiktionary, Tatoeba, LanguageTool e Wikimedia Commons; si spengono nel popup. Con i piani gratuiti alcuni servizi (per esempio Gemini) possono usare i testi per migliorare i loro modelli.
- Anki riceve le carte solo sul tuo computer (127.0.0.1).
- Il programma per yt-dlp scarica l'audio solo per trascriverlo e lo cancella subito.

---

## Novità

- **1.4.10**: **diretta sincronizzata**, programma per yt-dlp **1.4** (rilancia l'installatore): yt-dlp non è più «muto» (i suoi messaggi finiscono nel registro della diretta, così si vede perché non manda l'audio) e, se dopo 25 s non arriva audio, c'è un **piano B**: yt-dlp dà solo l'indirizzo della diretta e la legge direttamente ffmpeg. Se YouTube rifiuta (errore 403) il messaggio lo dice.
- **1.4.9**: **scheda della parola**: resta sempre dentro lo schermo, anche a schermo intero e quando cresce dopo l'apertura (etimologia, albero, immagini: prima la fine non si raggiungeva più); cliccando le frecce delle immagini per Anki resta dov'eri (prima tornava su a ogni clic). Il pulsante **Prova** dice quando un modello sul computer è lento perché ragiona prima di ogni risposta.
- **1.4.8**: **📈 uso nel tempo** si vede di nuovo: sulle pagine la curva spariva e gli anni erano neri (lo stile di base delle schede cancellava il disegno), e sui siti con regole proprie per i disegni (anche YouTube) poteva succedere lo stesso; ora colori e forme sono fissati sul grafico. tolto il «/no_think» aggiunto nella 1.4.7: il `qwen3:4b` di Ollama è la versione di Qwen 3 che ragiona sempre e lo prendeva come testo da tradurre. Ora **Prova**, se il modello sul computer è lento perché ragiona prima di ogni risposta, lo dice e consiglia un modello senza ragionamento (per esempio `gemma3:4b`).
- **1.4.7**: **Qwen 3 sul computer** non «pensa» più prima di rispondere (prima, con alcune versioni di Ollama, scriveva migliaia di parole di ragionamento e ci metteva più di un minuto anche per «good morning»): l'estensione aggiunge alla richiesta l'interruttore di Qwen, `/no_think`, che funziona con tutte le versioni.
- **1.4.6**: **Whisper sul computer** (Speaches, faster-whisper-server…): se il server non conosce il nome del modello (quello predefinito è di Groq: prima ogni pezzo dava «il modello scelto non esiste più» e i sottotitoli non comparivano), l'estensione legge i modelli del server, sceglie il migliore (turbo) e se lo ricorda; nel popup c'è **Carica modelli** anche per la trascrizione. **Modello sul computer** (Ollama, LM Studio): se il modello scritto nel popup non c'è più (per esempio cancellato), ne sceglie uno installato e se lo ricorda; se non ce n'è nessuno lo dice, con il comando per scaricarne uno.
- **1.4.5**: **📈 uso nel tempo** come il grafico vero: dati della raccolta 2022 di Google Books (quella che mostra Ngram Viewer, fino al 2022), curva morbida invece dei segmenti dritti (niente più scalini e salite che sembravano errori). **Modello per ogni compito** nel popup (sopra «Ordine dei servizi»): una tendina per ogni lavoro, cioè sottotitoli dei video, testi delle pagine e PDF, trascrizione dell'audio (Whisper di Groq o sul computer), spiegazioni, correzione della trascrizione, pronuncia IPA del testo selezionato, collegamento parole e modi di dire. «Automatico» usa il primo modello pronto della fila; un modello scelto che non risponde o ha finito le richieste viene sostituito dal primo pronto. Per esempio: sottotitoli con Gemini, spiegazioni e pronuncia con Ollama, correzione con Groq.
- **1.4.4**: **📈 uso nel tempo**: anni più grandi e leggibili, e sotto la fonte (Google Books Ngram Viewer) con «Apri il grafico completo ↗». **🌳 albero etimologico vero di Wiktionary** in tutte le lingue: si legge dai dati che Wiktionary mette nella pagina (prima veniva fuori vuoto, per esempio per *embarazado*). Si legge dall'alto in basso, dall'origine più antica alla parola: ogni passo con la lingua in italiano, la parola, la traslitterazione e il significato, e fra un passo e l'altro com'è arrivata (prestito, prestito dotto, ereditata, derivata…); le parole composte («embarazado è formata da: embarazar + -ado») hanno l'origine di ogni parte in un riquadro che si apre; le influenze (per esempio *\*trís* su *\*dwís*) sono a parte. La riga dell'etimologia non dice più «di …, lemma» quando l'etimologia è della parola stessa. **Diretta sincronizzata**: se yt-dlp non manda l'audio, dopo 20 s il registro lo dice (con l'ultimo messaggio di yt-dlp) e dopo 60 s la modalità si ferma e il video torna alla diretta, invece di restare «a metà» per sempre; il programma per yt-dlp (1.3, rilancia l'installatore) aggiorna yt-dlp prima di leggere una diretta.
- **1.4.3**: **diretta sincronizzata**: i sottotitoli non slittano più in ritardo nel parlato fitto (ogni frase compare esattamente al suo momento) e, se l'audio letto da yt-dlp si sposta, si rimettono a tempo anche le frasi già pronte; l'avviso ⏱ sopra i sottotitoli non è più stretto (andava a capo a ogni parola); il salto indietro, se YouTube arriva solo a metà, completa il resto con una pausa breve (prima il video finiva troppo indietro) e la messa a tempo non viene più interrotta da un secondo salto troppo presto. **📈 uso nel tempo** più chiaro: anni sotto nel punto giusto, scala («volte ogni milione di parole»), riassunto (anno di massimo uso, andamento negli ultimi 50 anni) e, passando il mouse, il valore di ogni anno.
- **1.4.2**: **Ordine dei servizi** nel popup: la fila dei modelli si sposta su e giù, si spegne, **Usa adesso** sceglie subito un servizio (per esempio Ollama) e **Prova** dice se risponde. Il **📖 Dizionario di Google** è tolto (Google non lo dà più: rispondeva «400»); **📈 uso nel tempo** resta come pulsante a sé. **Spiegazioni con** un modello diverso da quello dei sottotitoli (per esempio Gemini per i sottotitoli e Ollama per le spiegazioni). Le spiegazioni dei modelli lenti (Ollama sul computer) non si interrompono più con «Receiving end does not exist»: l'estensione aspetta anche per minuti. Nell'albero etimologico i pezzi della parola (per esempio на- + -чина́ть) stanno in una riga «formata da: …» e non si mescolano più con gli antenati. **diretta sincronizzata**: se YouTube non lascia tornare indietro con un salto, il video si mette in pausa per quei secondi (con il conto alla rovescia) e poi riparte indietro, invece di spegnere la modalità; le dirette non ripartono più da capo (perdendo i sottotitoli) ogni volta che YouTube ricarica il flusso. **🌳 Albero etimologico** quasi sempre (costruito dalla catena dell'etimologia di Wiktionary, con i parenti). **Registrazioni dal lemma** (e dal dizionario di Google). **🔍 cerca radice** propone anche le parole con la stessa radice e quelle di «Vedi anche». Il **📖 dizionario di Google**, se non risponde, ora dice il perché nella scheda.
- **1.4.1**: **🌳 alberi etimologici** di Wiktionary nella scheda; niente più errore di Groq «max_tokens must be less than or equal to 4096» (si riprova da sola con il limite del modello); un **modo di dire** compare solo se è davvero un pezzo della frase, nella sua lingua (mai un'espressione tradotta come «in the secret life» per una parola araba); **il modello non parte mai da solo**: nei video la spiegazione arriva solo con il pulsante **✨ Spiega con …** (prima partiva al clic sulla parola); il collegamento traduzione ↔ originale e i modi di dire con il modello sono spenti di serie (si accendono nel popup), e senza modello passando su una parola dell'originale si illumina comunque la sua traduzione (dizionario di Google). **📖 Dizionario di Google** nella scheda (pronuncia, significati, sinonimi, forme, origine, albero etimologico, uso nel tempo) e la sua origine quando Wiktionary non ha l'etimologia; etimologia presa dal lemma per le forme flesse (declinazioni, tempi verbali), solo se la parentela è sicura; si corregge con ⚑ → «lemma sbagliato?»; pulsante **🔍 cerca radice** per le forme non riconosciute da sole.
- **1.4.0** (da qui in poi esce solo questa estensione, con questa guida unica):
  - **Interfaccia nella lingua di «Traduci in»** (casella **Interfaccia in questa lingua** nel popup).
  - **Spiegazioni sempre nella tua lingua**: una risposta in un'altra lingua (per esempio in inglese dopo averla rifatta con Groq) viene richiesta di nuovo o tolta; il falso amico compare solo se è vero e riguarda una parola della tua lingua (niente più «embarrassed in inglese» o frasi come «non è un falso amico…»).
  - **Modi di dire ricordati** nella scheda anche quando una spiegazione rifatta non li riporta, e **☆ Salva il modo di dire**.
  - **Etimologie più complete**: la catena di Wiktionary si segue fino alla radice, anche attraverso altre lingue.
  - **PDF**: lettere strane corrette in tutte le codifiche comuni (anche i PDF fatti con Word sul Mac, come «Blues pro bláznivou holku» di Hrabě); i libri scansionati di archive.org non restano più con le pagine bianche.
- **1.3.0**: traduzione in lingua sbagliata (per esempio in arabo) rifiutata, con «Rifai tutta la traduzione» nel ⚑; dirette sincronizzate più robuste; prima correzione dei PDF cechi.

# 1.4.13: con «Interfaccia in questa lingua» accesa, cosa resta in italiano nella scheda della parola, nella scheda ⚑ e
# sul video? (il traduttore finto scrive «UI-en<…>»). Elenca i testi visibili non tradotti fuori dalle parti con
# parole vere (sottotitoli, significati, frasi).
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
LEFT = """(sel) => {
  const SKIP = ".dualsub-orig, .dualsub-trans, .dualsub-card-word, .dualsub-card-meaning, .dualsub-card-expl, .dualsub-card-sentfix, .dualsub-word, .dualsub-tword, .dsx-ex-item, .dsx-def-text, .dsui-skip, textarea, .dualsub-saved-mean";
  const out = new Set();
  for (const root of document.querySelectorAll(sel)) {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const p = n.parentElement, t = n.nodeValue.trim();
      if (!p || p.closest(SKIP) || !p.offsetParent || !/[a-zà-ù]{3}/i.test(t) || /UI-en</.test(t)) continue;
      out.add(t.slice(0, 80));
    }
    for (const e of root.querySelectorAll('[title]')) if (!e.closest(SKIP) && e.offsetParent && /[a-zà-ù]{4}/i.test(e.title) && !/UI-en</.test(e.title)) out.add("title: " + e.title.slice(0, 80));
  }
  return [...out];
}"""
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'en', uiLang:true, ipa:true, hoverPause:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(6000)
        a = await pg.evaluate(LEFT, ".dualsub-card")
        await spiega(pg, 5000); await pg.wait_for_timeout(5000)
        b = await pg.evaluate(LEFT, ".dualsub-card")
        await pg.evaluate("(document.querySelector('.dualsub-savedbtn')||{click(){}}).click()"); await pg.wait_for_timeout(3000)
        c = await pg.evaluate(LEFT, ".dualsub-card")
        await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-card-btn')].find(b=>b.textContent==='×').click()"); await pg.wait_for_timeout(300)
        await pg.evaluate("document.querySelector('.dualsub-fixbtn').click()"); await pg.wait_for_timeout(3000)
        d = await pg.evaluate(LEFT, ".dualsub-card")
        e = await pg.evaluate(LEFT, ".dualsub-overlay")
        allleft = sorted(set(a + b + c + d + e))
        print("rimasti in italiano:", len(allleft))
        for t in allleft: print("   -", t)
        print("NUM", len(allleft))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

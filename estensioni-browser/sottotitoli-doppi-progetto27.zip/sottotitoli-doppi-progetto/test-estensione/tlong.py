# 1.4.2: spiegazione con un modello lento (40 s, come Ollama sul computer): arriva lo stesso, sulla porta "ds-long"
import asyncio, sys, time
sys.path.insert(0, "/home/claude/e2e")
from charness import *
MEAN = "(document.querySelector('.dualsub-card .dualsub-card-meaning')||{}).textContent"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        slow = {"n": 0}
        async def lento(route, request):
            if request.method == "POST" and "chat/completions" in request.url and "define" not in str(slow) and b"meaning" in (request.post_data_buffer or b""):
                slow["n"] += 1
                await asyncio.sleep(40)
            await route.fallback()
        await ctx.route("https://generativelanguage.googleapis.com/**", lento)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, learnExamples:false, learnSpell:false, learnFreq:false, learnLlmExtra:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        print("1. pulsante:", await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-explainbtn')||{}).textContent"))
        t0 = time.time()
        await spiega(pg)
        await pg.wait_for_function("!document.querySelector('.dualsub-card') || !/Chiedo a/.test(document.querySelector('.dualsub-card').innerText)", timeout=120000, polling=500)
        print("2. dopo %.0f s (richieste lente: %d):" % (time.time() - t0, slow["n"]), await pg.evaluate(MEAN))
        print("   errore?", await pg.evaluate("/Non riesco|Receiving end|non disponibile/.test((document.querySelector('.dualsub-card')||{}).innerText||'')"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

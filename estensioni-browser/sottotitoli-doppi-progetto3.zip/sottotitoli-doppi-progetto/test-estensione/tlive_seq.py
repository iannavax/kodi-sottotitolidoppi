# 5.9: trascrizione "mentre guardo": le frasi arrivate a gruppi (e già passate) si vedono tutte, in ordine, e non di corsa
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
os.environ.setdefault("GROQ_LONG", "1")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsSeq"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        seq = []
        for _ in range(int(os.environ.get("SECS", "60")) * 10):
            t = await pg.evaluate("(document.querySelector('.dualsub-overlay:not([hidden]) .dualsub-orig')||{}).textContent||''")
            seq.append(t); await pg.wait_for_timeout(100)
        runs = []
        for t in seq:
            if runs and runs[-1][0] == t: runs[-1][1] += 0.1
            else: runs.append([t, 0.1])
        shown = [(t, round(d, 1)) for t, d in runs if t]
        for t, d in shown: print(f"  {d:4.1f}s  {t[:70]}")
        cues = json.loads(await pg.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))
        allt = [c["text"] for c in cues if not c["removed"]]
        texts = [t for t, _ in shown]
        last_shown = max((allt.index(t) for t in texts if t in allt), default=-1)
        missed = [t for t in allt[:last_shown + 1] if t not in texts]
        print("frasi trascritte fino all'ultima mostrata:", last_shown + 1, "| mai mostrate:", len(missed), missed[:4])
        print("frasi mostrate:", len(set(texts)), "| più brevi di 1 s:", [round(d, 1) for t, d in shown if d < 1.0][:10], "| pezzi a Whisper:", len(log["groq"]))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

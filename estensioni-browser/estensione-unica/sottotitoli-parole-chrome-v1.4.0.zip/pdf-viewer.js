// Lettore PDF di Parole al Volo: il lettore del browser non lascia entrare le estensioni, quindi i PDF si aprono qui
// (pdf.js di Mozilla). Ogni pagina è disegnata con sopra il suo testo vero (trasparente): la scheda passando il
// mouse, la selezione e la traduzione funzionano come sulle pagine web (volo.js è caricato in questa pagina).
import * as pdfjsLib from "./pdfjs/pdf.min.mjs";
import { PDF_ENC } from "./pdf-enc.js";
pdfjsLib.GlobalWorkerOptions.workerSrc = "./pdfjs/pdf.worker.min.mjs";

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
let scale = 1.4, doc = null, gen = 0;
// codifica del testo: "auto" (decido io guardando le prime pagine), "none" o una codifica di pdf-enc.js ("cp1250"…)
let encPref = "auto";
try { encPref = localStorage.getItem("pavPdfEnc") || "auto"; } catch {}
try { scale = Number(localStorage.getItem("pavPdfScale")) || 1.4; } catch {}

function message(html) { $("pages").innerHTML = `<div class="msg">${html}</div>`; }

async function openData(data, name) {
  const my = ++gen;
  $("name").textContent = name || "PDF";
  document.title = (name || "PDF") + " — Parole al Volo";
  $("pages").textContent = "";
  message("Apro il PDF…");
  try {
    // tabelle dei caratteri e caratteri standard: senza, in alcuni PDF il testo esce con caratteri sbagliati
    doc = await pdfjsLib.getDocument({ data, isEvalSupported: false,
      cMapUrl: new URL("pdfjs/cmaps/", location.href).href, cMapPacked: true,
      standardFontDataUrl: new URL("pdfjs/standard_fonts/", location.href).href,
      // decodificatori delle immagini JBIG2 e JPEG 2000 (i libri scansionati, es. archive.org) e dei colori ICC:
      // senza, pdf.js lascia quelle pagine bianche
      wasmUrl: new URL("pdfjs/wasm/", location.href).href,
      iccUrl: new URL("pdfjs/iccs/", location.href).href }).promise;
  } catch (e) {
    if (my === gen) message(`<b>Non riesco ad aprire questo PDF.</b><br>${String(e && e.message || e).replace(/</g, "&lt;")}`);
    return;
  }
  if (my !== gen) return;
  $("count").textContent = doc.numPages + (doc.numPages === 1 ? " pagina" : " pagine");
  await chooseEncoding(my);
  await layout(my);
}

// Le pagine si preparano tutte (misure giuste per scorrere), ma si disegnano solo quando arrivano sullo schermo
async function layout(my) {
  $("pages").textContent = "";
  $("zoom").textContent = Math.round(scale * 100) + "%";
  const obs = new IntersectionObserver((entries) => {
    for (const en of entries) if (en.isIntersecting) { obs.unobserve(en.target); drawPage(en.target, my).catch((e) => console.error("Parole al Volo, pagina del PDF:", e)); }
  }, { rootMargin: "800px 0px" });
  for (let n = 1; n <= doc.numPages; n++) {
    const page = await doc.getPage(n);
    if (my !== gen) return;
    const vp = page.getViewport({ scale });
    const div = document.createElement("div");
    div.className = "page";
    div.dataset.n = n;
    div.style.width = Math.floor(vp.width) + "px";
    div.style.height = Math.floor(vp.height) + "px";
    div.style.setProperty("--scale-factor", String(scale));
    div.style.setProperty("--total-scale-factor", String(scale));
    div.style.setProperty("--user-unit", "1");
    const num = document.createElement("span"); num.className = "num"; num.textContent = n;
    div.append(num);
    $("pages").append(div);
    obs.observe(div);
  }
}

async function drawPage(div, my) {
  const page = await doc.getPage(Number(div.dataset.n));
  if (my !== gen) return;
  const vp = page.getViewport({ scale });
  const ratio = window.devicePixelRatio || 1;
  const canvas = document.createElement("canvas");
  canvas.width = Math.floor(vp.width * ratio);
  canvas.height = Math.floor(vp.height * ratio);
  div.prepend(canvas);
  await page.render({ canvas, canvasContext: canvas.getContext("2d"), viewport: vp, transform: ratio !== 1 ? [ratio, 0, 0, ratio, 0, 0] : null }).promise;
  if (my !== gen) return;
  const tl = document.createElement("div");
  tl.className = "textLayer";
  div.append(tl);
  const tc = await page.getTextContent();
  fixAccents(tc.items);
  await new pdfjsLib.TextLayer({ textContentSource: tc, container: tl, viewport: vp }).render();
}

// Accenti staccati. Molti PDF (soprattutto quelli fatti con LaTeX) scrivono "č" come due caratteri: "ˇ" e "c"
// (spesso l'accento prima della lettera, a volte perfino in un pezzo di testo diverso). A vedersi è giusto, ma il
// testo è "ˇcesk´y" e la traduzione non lo capisce. Riunisco l'accento alla lettera, solo quando insieme formano
// davvero una lettera accentata (č, ý, ů, ž, ő, ç…), così il testo normale non cambia.
const MARKS = { "\u02C7": "\u030C", "\u00B4": "\u0301", "\u02DA": "\u030A", "\u00A8": "\u0308", "\u02DD": "\u030B", "\u02D8": "\u0306",
  "\u00B8": "\u0327", "\u02DB": "\u0328", "\u02D9": "\u0307", "\u0060": "\u0300", "\u02C6": "\u0302", "\u02DC": "\u0303" };
const MARK_RE = new RegExp("[" + Object.keys(MARKS).join("") + "]");
const isLetter = (c) => !!c && /\p{L}/u.test(c);
const compose = (letter, mark) => { const x = (letter + MARKS[mark]).normalize("NFC"); return x.length === 1 ? x : null; };
function fixString(str) {
  if (!MARK_RE.test(str)) return str.normalize("NFC");
  const a = Array.from(str);
  const out = [];
  for (let i = 0; i < a.length; i++) {
    const c = a[i];
    if (MARKS[c]) {
      // prima la lettera dopo (ordine di LaTeX), poi quella prima se la parola finisce qui
      const n = a[i + 1], prev = out[out.length - 1];
      if (isLetter(n) && compose(n, c)) { out.push(compose(n, c)); i++; continue; }
      if (isLetter(prev) && !isLetter(n) && compose(prev, c)) { out[out.length - 1] = compose(prev, c); continue; }
    }
    out.push(c);
  }
  return out.join("").normalize("NFC");
}
// ---------- Testo dei PDF in una codifica letta con un'altra ----------
// Molti PDF un po' vecchi hanno il testo in una codifica (ceco in Windows-1250, russo in Windows-1251 o KOI8,
// greco, turco…) ma il carattere dice un'altra cosa (WinAnsi, MacRoman, la codifica standard di Adobe): pdf.js
// allora mostra "Pøíliš" o "P¯ÌliöÌ" invece di "Příliš", "Ïðèâåò" invece di "Привет", "Ã©" invece di "é" (UTF-8).
// Riporto ogni carattere al suo byte e lo rileggo con la codifica giusta. Quale? Provo tutte le coppie
// (lettura sbagliata → codifica giusta), tengo quelle che rendono il testo più "da parola vera" e chiedo al
// riconoscimento della lingua del browser se ne esce davvero una lingua che usa quella codifica. Si decide carattere
// per carattere (font): lo stesso PDF può avere i titoli giusti e il testo sbagliato.
const SRC = {};
for (const [k, t] of Object.entries(PDF_ENC.sources)) {
  const m = new Map();
  Array.from(t).forEach((c, i) => { if (c !== "�" && !m.has(c)) m.set(c, 0x80 + i); });
  SRC[k] = m;
}
const TGT = {};
for (const [k, v] of Object.entries(PDF_ENC.targets)) TGT[k] = { ...v, chars: Array.from(v.table) };
for (const [k, v] of Object.entries(PDF_ENC.multi)) {
  try { TGT[k] = { ...v, dec: new TextDecoder(k) }; } catch { /* codifica che questo browser non conosce */ }
}
const MODES = [];
for (const src of Object.keys(SRC)) for (const tgt of Object.keys(TGT)) if (src !== tgt) MODES.push(src + ":" + tgt);
// i vecchi nomi della scelta a mano
const OLD_PREF = { "1250": "cp1250", "88592": "iso8859_2", "mac1250": "cp1250" };
// byte che pdf.js non sa mostrare e cambia: quelli che WinAnsi non usa diventano "•", il trattino morbido (0xAD) "-".
// Vicino a una lettera sono quasi sempre una lettera della codifica vera: provo i byte possibili e tengo il migliore.
const AMBIG = { "•": [0x95, 0x9D, 0x81, 0x8D, 0x8F, 0x90], "-": [0x2D, 0xAD] };
function decodeBytes(bytes, orig, tgt) {
  const t = TGT[tgt];
  const one = (bs) => {
    if (t.dec) return t.dec.decode(Uint8Array.from(bs));   // i byte sbagliati diventano "�" (plaus li punisce)
    let out = "";
    for (let i = 0; i < bs.length; i++) { const b = bs[i]; const c = b < 0x80 ? String.fromCharCode(b) : t.chars[b - 0x80]; out += c === "�" ? orig[i] : c; }
    return out;
  };
  const pick = bytes.map((b) => (Array.isArray(b) ? b[0] : b));
  for (let i = 0; i < bytes.length; i++) {
    if (!Array.isArray(bytes[i])) continue;
    let best = null, bestScore = -Infinity;
    for (const x of bytes[i]) {
      pick[i] = x;
      const d = one(pick);
      const sc = plaus(d) + 1.5 * count(d, /\p{L}/gu);   // a parità, meglio una lettera che un simbolo
      if (sc > bestScore) { best = x; bestScore = sc; }
    }
    pick[i] = best;
  }
  const d = one(pick);
  return t.dec && d.includes("�") ? orig.join("") : d;
}
function recode(str, mode) {
  if (!mode || mode === "none") return str;
  const [src, tgt] = mode.split(":");
  const map = SRC[src];
  if (!map || !TGT[tgt]) return str;
  const chars = Array.from(str);
  let out = "", bytes = [], orig = [];
  const flush = () => { if (bytes.length) out += decodeBytes(bytes, orig, tgt); bytes = []; orig = []; };
  const isL = (c) => !!c && /\p{L}/u.test(c);
  for (let i = 0; i < chars.length; i++) {
    const c = chars[i], code = c.codePointAt(0);
    let b = code < 0x80 ? code : map.get(c);
    if (b == null && code >= 0x80 && code < 0xA0) b = code;   // caratteri di controllo: il byte è quello
    const prev = chars[i - 1], next = chars[i + 1];
    if (AMBIG[c] && (c === "-" ? isL(prev) && (isL(next) || prev > "\u007F") : isL(prev) || isL(next))) b = AMBIG[c];
    // parola per parola: un pezzo che non si decodifica resta com'era senza rovinare il resto
    if (b == null || /\s/.test(c)) { flush(); out += c; continue; }
    bytes.push(b); orig.push(c);
  }
  flush();
  return out;
}
const count = (t, re) => (t.match(re) || []).length;
const CE_LETTERS = /[čřěůňďťľĺŕąęłńśźżőűăşţČŘĚŮŇĎŤĽĹŔĄĘŁŃŚŹŻŐŰĂŞŢ]/gu;
const SCRIPTS = [["L", /\p{Script=Latin}/u], ["C", /\p{Script=Cyrillic}/u], ["G", /\p{Script=Greek}/u], ["H", /\p{Script=Hebrew}/u],
  ["A", /\p{Script=Arabic}/u], ["T", /\p{Script=Thai}/u], ["J", /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u], ["K", /\p{Script=Hangul}/u]];
const scriptOf = (c) => { for (const [k, re] of SCRIPTS) if (re.test(c)) return k; return "O"; };
// quanto sembra testo vero: parole di un solo alfabeto, poche lettere strane, niente maiuscole o simboli in mezzo
function plaus(t) {
  let s = 0;
  for (const w of t.match(/[\p{L}\p{M}]+/gu) || []) {
    const letters = Array.from(w).filter((c) => /\p{L}/u.test(c));
    if (!letters.length) continue;
    const scripts = new Set(letters.map(scriptOf));
    if (scripts.size > 1) { s -= 3; continue; }
    const sc = scripts.values().next().value;
    if (sc === "L") {
      const non = letters.filter((c) => c > "\u007F").length;
      if (letters.length >= 4 && non / letters.length > 0.6) s -= 2;
      else s += non ? 1 : 0;
      s += 0.5 * count(w, CE_LETTERS);
    } else s += sc === "O" ? -1 : 1;
    // maiuscole e minuscole mescolate a caso ("íÏÒÏÚ", "ŪŌŕ"): una parola vera è tutta minuscola, tutta maiuscola
    // o con la prima maiuscola
    if (/\p{Ll}\p{Lu}/u.test(w) || (letters.length > 2 && /\p{Lu}/u.test(letters.slice(1).join("")) && /\p{Ll}/u.test(letters.slice(1).join("")))) s -= 2;
  }
  s -= 2 * count(t, /\p{L}[^\p{L}\p{M}\s\d'’.,;:!?()"«»„“”\-–—/]\p{L}/gu);
  s -= 3 * count(t, /[�-]/gu);
  return s;
}
// il testo così com'è, anche con gli accenti staccati già riuniti (LaTeX: "ˇcesk´y" è giusto, non va ricodificato)
const baseScore = (t) => Math.max(plaus(t), MARK_RE.test(t) ? plaus(fixString(t)) : -Infinity);
const nonAscii = (t) => count(t, /[^\x00-\x7F]/gu);
async function detect(text) {
  try {
    const api = (globalThis.browser && browser.i18n && browser.i18n.detectLanguage) ? browser.i18n : chrome.i18n;
    const r = await new Promise((ok) => { const p = api.detectLanguage(text.slice(0, 3000), ok); if (p && p.then) p.then(ok, () => ok(null)); });
    const top = r && r.languages && r.languages[0];
    return top ? { lang: top.language.split("-")[0], pct: top.percentage, sure: !!r.isReliable } : null;
  } catch { return null; }
}
const langOk = (mode, d) => { const t = TGT[mode.split(":")[1]]; return !!d && d.pct >= 50 && (!t.langs || t.langs.some((l) => l.split("-")[0] === d.lang)); };
// automatico, per il testo di un carattere: il modo giusto, "none" se è già giusto, null se c'è troppo poco testo
async function judgeAuto(text) {
  if (nonAscii(text) < 3) return null;
  const base = baseScore(text);
  const cands = MODES.map((m) => ({ m, sc: plaus(recode(text, m)) })).filter((x) => x.sc >= base + 2).sort((x, y) => y.sc - x.sc).slice(0, 12);
  if (!cands.length) return "none";
  const orig = await detect(text);
  for (const c of cands) {
    const d = await detect(recode(text, c.m));
    if (!d) { if (c.sc >= base + 4) return c.m; continue; }
    if (!langOk(c.m, d)) continue;
    // testo che sembra già vero e che il browser riconosce con sicurezza in una lingua che con questa codifica non
    // c'entra (francese con è, ù, ò…): è giusto così. Il testo rovinato spesso sembra vietnamita: lì non conta.
    if (base > 0 && base >= c.sc - 4 && orig && orig.sure && orig.pct >= 80 && !langOk(c.m, orig) && orig.lang !== d.lang) continue;
    return c.m;
  }
  return "none";
}
// scelta a mano di una codifica giusta: la lettura sbagliata che le va meglio, solo dove migliora il testo
function judgeManual(text, tgt) {
  const base = baseScore(text);
  let best = "none", bestScore = base;
  for (const src of Object.keys(SRC)) { const m = src + ":" + tgt; if (src === tgt) continue; const sc = plaus(recode(text, m)); if (sc > bestScore) { best = m; bestScore = sc; } }
  return best;
}
// per le prove (test-volo/tpdf_enc.py)
globalThis.pavPdfEnc = { plaus, recode, judgeAuto, detect, MODES };
let fontMode = new Map(), docMode = "none";
async function chooseEncoding(my) {
  fontMode = new Map(); docMode = "none";
  if (OLD_PREF[encPref]) encPref = OLD_PREF[encPref];
  if (encPref !== "auto" && encPref !== "none" && !TGT[encPref]) encPref = "auto";
  let note = "";
  if (encPref !== "none") {
    const byFont = new Map();
    for (let n = 1; n <= Math.min(doc.numPages, 5); n++) {
      const tc = await (await doc.getPage(n)).getTextContent();
      for (const it of tc.items) if (it.str) byFont.set(it.fontName, (byFont.get(it.fontName) || "") + it.str + " ");
    }
    if (my !== gen) return;
    const weight = {};
    for (const [f, t] of byFont) {
      const j = encPref === "auto" ? await judgeAuto(t) : judgeManual(t, encPref);
      if (my !== gen) return;
      if (j) { fontMode.set(f, j); weight[j] = (weight[j] || 0) + t.length; }
    }
    docMode = Object.keys(weight).filter((k) => k !== "none").sort((x, y) => weight[y] - weight[x])[0] || "none";
    const all = [...byFont.values()].join("");
    if (docMode !== "none") note = "(corretti: " + TGT[docMode.split(":")[1]].name + ")";
    else if (all.length > 50 && count(all, /[�-]/gu) > all.replace(/\s/g, "").length * 0.2)
      note = "(questo PDF non contiene il testo vero: si vede ma non si può leggere)";
  }
  fillEncSelect();
  $("encNote").textContent = note;
}
function fillEncSelect() {
  const sel = $("enc");
  if (!sel.dataset.filled) {
    sel.dataset.filled = "1";
    const groups = new Map();
    for (const [k, t] of Object.entries(TGT)) { if (!groups.has(t.group)) groups.set(t.group, []); groups.get(t.group).push([k, t.name]); }
    for (const [g, list] of groups) {
      const og = document.createElement("optgroup"); og.label = g;
      for (const [k, name] of list) { const o = document.createElement("option"); o.value = k; o.textContent = name; og.append(o); }
      sel.append(og);
    }
  }
  sel.value = encPref;
}
function recodeItems(items) {
  if (encPref === "none" || (docMode === "none" && ![...fontMode.values()].some((m) => m !== "none"))) return;
  const texts = new Map();
  for (const it of items) if (it.str) texts.set(it.fontName, (texts.get(it.fontName) || "") + it.str + " ");
  // caratteri che nelle prime pagine non c'erano: il modo del documento, se migliora il loro testo
  for (const [f, t] of texts) if (!fontMode.has(f) && nonAscii(t) >= 3) {
    if (encPref === "auto") fontMode.set(f, plaus(recode(t, docMode)) >= baseScore(t) + 2 ? docMode : "none");
    else fontMode.set(f, judgeManual(t, encPref));
  }
  for (const it of items) {
    if (typeof it.str !== "string" || !it.str) continue;
    let m = fontMode.get(it.fontName);
    if (m == null) m = docMode !== "none" && plaus(recode(it.str, docMode)) > baseScore(it.str) ? docMode : "none";
    if (m !== "none") it.str = recode(it.str, m);
  }
}
function fixAccents(items) {
  recodeItems(items);
  const list = items.filter((it) => typeof it.str === "string");
  // accento alla fine di un pezzo e lettera all'inizio del pezzo dopo: lo sposto lì
  for (let i = 0; i + 1 < list.length; i++) {
    const s = list[i].str, m = s.slice(-1), next = list[i + 1].str;
    if (MARKS[m] && isLetter(next.charAt(0)) && compose(next.charAt(0), m) && !list[i].hasEOL) {
      list[i].str = s.slice(0, -1);
      list[i + 1].str = m + next;
    }
  }
  for (const it of list) it.str = fixString(it.str);
}

async function openUrl(url) {
  $("orig").href = url; $("orig").hidden = false;
  const name = decodeURIComponent((url.split("?")[0].split("/").pop() || "PDF"));
  message("Scarico il PDF…");
  try {
    const r = await fetch(url, { credentials: "include" });
    if (!r.ok) throw new Error("il sito ha risposto " + r.status);
    await openData(new Uint8Array(await r.arrayBuffer()), name);
  } catch (e) {
    const local = /^file:/i.test(url);
    message(`<b>Non riesco a leggere questo PDF da qui</b> (${String(e && e.message || e).replace(/</g, "&lt;")}).<br><br>` +
      (local ? "È un file del computer: premi <b>📂 Apri un PDF…</b> qui sopra e sceglilo (oppure, in Edge/Chrome, nella pagina delle estensioni attiva «Consenti l'accesso agli URL dei file» per Parole al Volo)."
        : "Scaricalo e aprilo con <b>📂 Apri un PDF…</b> qui sopra."));
  }
}

$("file").addEventListener("change", async () => {
  const f = $("file").files[0];
  if (!f) return;
  $("orig").hidden = true;
  history.replaceState(null, "", location.pathname);
  await openData(new Uint8Array(await f.arrayBuffer()), f.name);
});
const rezoom = (k) => {
  if (!doc) return;
  scale = Math.min(4, Math.max(0.5, Math.round(scale * k * 10) / 10));
  try { localStorage.setItem("pavPdfScale", String(scale)); } catch {}
  const top = window.scrollY / Math.max(1, document.body.scrollHeight);
  layout(++gen).then(() => window.scrollTo(0, top * document.body.scrollHeight));
};
$("zoomIn").addEventListener("click", () => rezoom(1.15));
$("enc").addEventListener("change", async () => {
  encPref = $("enc").value;
  try { localStorage.setItem("pavPdfEnc", encPref); } catch {}
  if (!doc) return;
  const my = ++gen;
  await chooseEncoding(my);
  if (my === gen) layout(my);
});
$("zoomOut").addEventListener("click", () => rezoom(1 / 1.15));

const file = params.get("file");
if (file) openUrl(file);
else message("Premi <b>📂 Apri un PDF…</b> qui sopra per leggere un PDF del computer con Parole al Volo: passa il mouse sulle parole per la loro scheda, evidenzia un pezzo per tradurlo.<br><br>" +
  "I PDF aperti nel browser si aprono qui anche dal popup («📄 Apri questo PDF con Parole al Volo») o da soli, se lo scegli nel popup.");

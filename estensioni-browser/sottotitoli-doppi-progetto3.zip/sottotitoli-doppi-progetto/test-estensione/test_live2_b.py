import asyncio, time, json, os
from bharness import *

async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-latest'}, targetLang:'it', autoTranscribe:true})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}}))""")
        page = await ctx.new_page(); errs = []
        page.on("pageerror", lambda e: errs.append("PAGEERROR " + str(e)))
        await page.goto("https://www.youtube.com/watch?v=noCaps")
        await page.wait_for_timeout(1500)
        await page.evaluate("document.querySelector('video').play()")
        empty = shown = 0
        t0 = time.time()
        while time.time() - t0 < 85:
            await page.wait_for_timeout(500)
            st = await page.evaluate("({v: document.querySelector('video').currentTime, ended: document.querySelector('video').ended, o: (document.querySelector('.dualsub-orig')||{}).textContent||''})")
            if st["v"] > 9: 
                if st["o"]: shown += 1
                else: empty += 1
            if st["ended"]: break
        await page.wait_for_timeout(12000)
        dbg = json.loads(await page.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))
        print("pezzi a Whisper:", log["groq"], "totale", round(sum(log["groq"]),1), "s")
        print("richieste a Gemini (frasi per richiesta):", log["gemini"])
        print(f"riga visibile dopo i primi 9 s: {shown}/{shown+empty} controlli")
        print("frasi (inizio-fine in s, testo, traduzione):")
        for c in dbg: print(f"  {c['start']/1000:5.1f}-{c['end']/1000:5.1f}  {c['text']:16} {c['trans']}")
        # controllo di coerenza testo/traduzione
        bad = [c for c in dbg if c['trans'] and tr(c['text']) not in c['trans']]
        print("traduzioni non corrispondenti:", bad)
        for sec in [4, 12, 25, 40]:
            await page.evaluate(f"const v=document.querySelector('video'); v.currentTime={sec}; v.play()")
            await page.wait_for_timeout(700)
            o = await page.inner_text(".dualsub-orig"); t = await page.inner_text(".dualsub-trans")
            print(f"  ritorno a {sec:2d} s: {o} | {t}")
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

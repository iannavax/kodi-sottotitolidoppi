# 1.7.1: con la lingua «Automatica» le voci Piper non spariscono: il menu dice di scegliere prima una lingua
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({ttsLang:''})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1500)
        await pp.evaluate("document.getElementById('dTts').open=true"); await pp.wait_for_timeout(1500)
        print("1. lingua automatica:", await pp.evaluate("[...document.querySelectorAll('#ttsPiper option')].map(o=>o.textContent)"), "| gruppo visibile:", await pp.evaluate("!document.getElementById('ttsPiper').hidden"))
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

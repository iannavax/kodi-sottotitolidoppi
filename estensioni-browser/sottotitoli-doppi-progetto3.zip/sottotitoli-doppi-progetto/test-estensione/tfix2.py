import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        ext = sw.url.split("/")[2]
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', hoverPause:false})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console: " + m.text) if m.type == "error" else None)
        await pg.goto("https://www.youtube.com/watch?v=longFix"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(9000)
        await pg.evaluate("const v=document.querySelector('video'); v.pause(); v.currentTime=4"); await pg.wait_for_timeout(600)
        line = lambda: pg.evaluate("({o:(document.querySelector('.dualsub-orig')||{}).textContent, t:(document.querySelector('.dualsub-trans')||{}).textContent})")
        print("A. sottotitoli YouTube a 4 s:", await line())
        await pg.hover(".dualsub-orig"); await pg.click(".dualsub-fixbtn"); await pg.wait_for_selector(".dualsub-fixcard")
        print("   azioni offerte:", [x.strip() for x in await pg.locator(".dualsub-fix-actions button").all_inner_texts()])
        await pg.click("text=↻ Ritraduci"); await pg.wait_for_timeout(8000)
        print("   messaggio della scheda:", await pg.inner_text(".dualsub-fixcard"))
        print("   errori finora:", errs)
        await pg.click(".dualsub-fixcard .dualsub-card-btn[title='Chiudi']"); await pg.wait_for_timeout(500)
        print("   dopo 'Ritraduci':", await line())
        print("   correzioni salvate:", await sw.evaluate("chrome.storage.local.get(null).then(a=>Object.keys(a).filter(k=>k.startsWith('fix:')).map(k=>JSON.stringify(a[k])))"))
        await pg.reload(); await pg.wait_for_timeout(1500)
        await pg.evaluate("const v=document.querySelector('video'); v.currentTime=4; v.play()"); await pg.wait_for_timeout(6000)
        await pg.evaluate("const v=document.querySelector('video'); v.pause(); v.currentTime=4"); await pg.wait_for_timeout(600)
        print("   dopo aver ricaricato:", await line())

        # B. file trascritto nella pagina, senza video aperto
        tp = await ctx.new_page(); tp.on("pageerror", lambda e: errs.append("pagina: " + str(e)))
        await tp.goto(f"chrome-extension://{ext}/transcript.html"); await tp.wait_for_timeout(800)
        await tp.set_input_files("#pickFile", "/tmp/speech.wav")
        for _ in range(60):
            await tp.wait_for_timeout(500)
            if "Fatto" in await tp.inner_text("#status"): break
        await tp.click("#tabTime")
        rows = tp.locator("#timeView .line")
        print("B. file senza video: righe", await rows.count(), "| pulsanti:", await rows.nth(0).locator("button").count())
        await rows.nth(0).locator("button[title='Correggi a mano']").click()
        await tp.locator("textarea.edit").nth(0).fill("Testo corretto")
        await tp.locator("textarea.edit").nth(1).fill("")
        await tp.click("text=Salva"); await tp.wait_for_timeout(8000)
        print("   dopo la correzione dell'originale (traduzione rifatta da sola):", (await rows.nth(0).inner_text()).replace("\n", " | ")[:90])
        await rows.nth(1).locator("button[title^='Togli']").click(); await tp.wait_for_timeout(800)
        print("   dopo 'Togli' sulla seconda riga: righe", await tp.locator("#timeView .line").count())
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

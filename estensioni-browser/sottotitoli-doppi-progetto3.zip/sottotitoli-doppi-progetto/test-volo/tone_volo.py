import asyncio, os, sys, re
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
PAGE = '<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>t</title></head><body style="margin:40px;font:18px Georgia"><p id="ru" lang="ru">Я живу в доме и у реки.</p><p id="cs" lang="cs">Byl jsem v Praze a s ním.</p><p id="en" lang="en">I saw a cat.</p></body></html>'
async def handle(route, request):
    if request.url.startswith("https://example.test/"): return await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=PAGE)
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', learnExamples:false, learnFreq:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/g.html"); await pg.wait_for_timeout(800)
        async def hov(pid, w):
            await pg.mouse.move(5, 5); await pg.wait_for_timeout(500)
            b = await pg.evaluate("""([pid, w]) => { const n = document.getElementById(pid).firstChild; const m = new RegExp('(^|\\\\s)' + w + '(?=\\\\s|$)').exec(n.data); const i = m.index + m[1].length;
              const r = document.createRange(); r.setStart(n, i); r.setEnd(n, i + w.length); const b = r.getBoundingClientRect(); return {x: b.left + b.width / 2, y: b.top + b.height / 2}; }""", [pid, w])
            await pg.mouse.move(b["x"], b["y"], steps=4); await pg.wait_for_timeout(1500)
        for pid, w in [("ru", "в"), ("ru", "Я"), ("ru", "у"), ("ru", "и"), ("cs", "v"), ("cs", "a"), ("cs", "s"), ("en", "I"), ("en", "a")]:
            await hov(pid, w)
            print(pid, w, "→", await pg.evaluate("(document.querySelector('.pav-card .pav-word')||{}).textContent||'(niente)'"))
        # selezione di una lettera
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(400)
        await pg.evaluate("""()=>{const p=document.getElementById('cs').firstChild; const i=p.data.indexOf(' v ')+1; const r=document.createRange(); r.setStart(p,i); r.setEnd(p,i+1); const s=getSelection(); s.removeAllRanges(); s.addRange(r); document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));}""")
        await pg.wait_for_timeout(1500)
        print("selezione 'v' →", await pg.evaluate("(document.querySelector('.pav-card .pav-word')||{}).textContent||'(niente)'"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

## Novità della 5.10.1
- **Una sola richiesta al modello per tutto.** Cliccando una parola, la spiegazione nel contesto di Gemini (o del servizio scelto) porta con sé anche l'etimologia, se Wiktionary non l'aveva, e la pronuncia IPA, solo se è accesa: una richiesta invece di due. Tolto il pulsante separato "Chiedila a Gemini" per l'etimologia.

## Novità della 5.10
- **Etimologia nella scheda della parola.** Sotto il significato compare da dove viene la parola (per esempio *bread* → dall'inglese antico *brēad*), presa da Wiktionary (gratis, senza chiave) e tradotta nella tua lingua, con il collegamento alla pagina. Per le forme flesse (*walked*) cerca la forma base (*walk*). Si chiede solo se la scheda resta aperta un attimo, e resta salvata; finisce anche nel vocabolario e nelle carte per Anki. Se Wiktionary non la ha, il pulsante "Chiedila a Gemini" la chiede al modello (una richiesta). Si accende e spegne nel popup → Aspetto → "Etimologia nella scheda della parola".
- **Pronuncia IPA: spenta = zero token.** Con "Pronuncia IPA nella scheda della parola" spenta la pronuncia non si vede e non si chiede mai (prima restava il pulsante per chiederla). Nella scheda c'è anche "spegni IPA" per spegnerla al volo.


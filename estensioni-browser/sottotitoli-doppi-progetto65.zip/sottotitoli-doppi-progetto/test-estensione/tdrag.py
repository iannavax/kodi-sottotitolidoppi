# 1.6.6: scheda spostabile con la maniglia ⠿ (video): si trascina, resta dove l'hai messa per la scheda dopo, doppio clic = torna al posto
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnNgram:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.set_viewport_size({"width": 1300, "height": 800})
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        box = lambda: pg.evaluate("(()=>{const r=document.querySelector('.dualsub-card').getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top)]})()")
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(1800)
        b0 = await box()
        g = await pg.locator(".dualsub-card .dualsub-card-grip").bounding_box()
        await pg.mouse.move(g["x"] + g["width"] / 2, g["y"] + 5); await pg.mouse.down()
        await pg.mouse.move(g["x"] + g["width"] / 2 - 300, g["y"] + 5 + 120, steps=8); await pg.mouse.up(); await pg.wait_for_timeout(500)
        b1 = await box()
        print("1. dopo il trascinamento:", b0, "→", b1)
        await pg.keyboard.press("Escape"); await pg.wait_for_timeout(400)
        await words.nth(texts.index("market")).click(); await pg.wait_for_timeout(1800)
        b2 = await box()
        print("2. scheda dopo (stessa posizione):", b2, "| salvata:", await sw.evaluate("chrome.storage.local.get('cardUser').then(r=>JSON.stringify(r.cardUser))"))
        g = await pg.locator(".dualsub-card .dualsub-card-grip").bounding_box()
        await pg.mouse.dblclick(g["x"] + g["width"] / 2, g["y"] + 5); await pg.wait_for_timeout(800)
        b3 = await box()
        print("3. dopo doppio clic:", b3)
        ok = abs(b1[0] - b0[0] + 300) < 40 and abs(b1[1] - b0[1] - 120) < 40 and abs(b2[0] - b1[0]) < 30 and abs(b2[1] - b1[1]) < 40 and abs(b3[1] - b0[1]) < 30
        print("errori:", errs if ok else errs + ["scheda spostabile non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

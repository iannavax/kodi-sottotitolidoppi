# Sottotitoli Doppi + Parole al Volo — le due estensioni in una

Questa è **una sola estensione** che fa tutto quello che fanno Sottotitoli Doppi (sottotitoli doppi nei video, trascrizione, scheda delle parole, dirette) e Parole al Volo (scheda delle parole e traduzione su qualsiasi pagina web). Le due estensioni separate continuano a esistere: questa è un'alternativa, per chi preferisce averne una sola.

## Come si usa
- Il pulsante dell'estensione apre il popup con due schede in alto: **🎬 Video** (le impostazioni di Sottotitoli Doppi) e **📄 Pagine** (quelle di Parole al Volo). Il popup si riapre sull'ultima scheda che hai usato.
- Nei video funziona come Sottotitoli Doppi; sulle pagine come Parole al Volo. Sopra i sottotitoli dei video le schede di Parole al Volo non compaiono (ci sono già quelle dei sottotitoli).
- Le scorciatoie da tastiera di Parole al Volo restano: Alt+Maiusc+Y (accendi/spegni), Alt+Maiusc+M (scheda passando il mouse), Alt+Maiusc+S (traduzione quando evidenzi).

## PDF
Il lettore PDF del browser non lascia entrare le estensioni: dal popup, scheda **📄 Pagine**, premi **«📄 Apri questo PDF con Parole al Volo»** (o **«📄 Lettore PDF»** per un file del computer), oppure accendi «Apri sempre i PDF con Parole al Volo».

## Cosa è in comune e cosa no
- **In comune**: le chiavi dei servizi (Gemini, Groq…), la lingua in cui traduci, il **vocabolario**, le **parole che conosci**, le voci della pronuncia, Anki, il programma per yt-dlp.
- **Separati** (perché hanno lo stesso nome ma servono a cose diverse): il servizio scelto (nei video traduce i sottotitoli, sulle pagine spiega le parole), i siti in cui è spenta, il mazzo di Anki unico, il colore delle parole che conosci sulla pagina, le lettere latine «Aa».

## Passare dalle due estensioni a questa
È un'estensione nuova, quindi parte vuota:
1. installala accanto alle due vecchie (non toglierle subito);
2. porta qui le **parole che conosci** (tutte le lingue insieme) e il **vocabolario**, in uno di questi due modi:
   - **con un file** (funziona anche con le versioni vecchie): nell'estensione vecchia apri **Parole che conosco** (dal popup) e premi **Esporta in un file**; poi qui, nella stessa pagina, **Importa da un file…** e scegli quel file. Per il vocabolario: **Il mio vocabolario → ⇄ Esporta** nella vecchia e **⇄ Importa…** qui;
   - **senza file**: aggiorna prima le estensioni vecchie (Sottotitoli Doppi 5.20.1, Parole al Volo 1.13.1), poi qui premi **⇄ Sincronizza adesso** (parole conosciute) e nel vocabolario **⇄ Sincronizza con le altre estensioni**: prende da tutte e due quelle installate;
3. le **chiavi** (Gemini, Groq…) e le **impostazioni** passano anche loro con ⇄ (solo quelle che qui non hai ancora scelto). Se il messaggio dice che le chiavi non sono arrivate, premi ⇄ anche dentro l'estensione vecchia; altrimenti inseriscile a mano nel popup. Finché nelle «Pagine» non scegli un servizio, per spiegare le parole si usa quello scelto per i «Video»;
4. per il programma yt-dlp: apri la sua pagina dal popup (Video → Video senza sottotitoli → Programma per yt-dlp) e rilancia l'installatore, così riconosce anche questa estensione;
5. quando tutto funziona, puoi togliere le due vecchie. Non usare le vecchie e la nuova insieme sulle stesse pagine: le schede comparirebbero due volte.

## Aggiornare
Come per le altre: su Edge sostituisci i file nella stessa cartella e premi ↻; su Firefox installa il nuovo .xpi sopra quello vecchio. Non rimuovere l'estensione, perderesti chiavi, vocabolario e parole conosciute.

Per tutto il resto valgono le guide delle due estensioni.

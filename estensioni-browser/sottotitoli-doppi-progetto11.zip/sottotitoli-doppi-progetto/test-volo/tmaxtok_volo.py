# Groq con un modello che accetta al massimo 4096 token di risposta: «Traduci meglio» e «Spiega con Groq» non danno
# l'errore 400, l'estensione riprova con il limite e se lo ricorda. Uso: GROQ_MAXTOK=4096 python3 tmaxtok_volo.py <estensione>
import asyncio, os, sys
os.environ.setdefault("GROQ_MAXTOK", "4096")
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b1 = await tvolo.word_box(pg, "long", "The"); b2 = await tvolo.word_box(pg, "long", "fire")
        await pg.mouse.move(b1["l"] + 1, b1["y"]); await pg.mouse.down(); await pg.mouse.move(b2["r"], b2["y"], steps=8); await pg.mouse.up()
        await pg.wait_for_timeout(2500)
        await pg.get_by_text("Traduci meglio").click(); await pg.wait_for_timeout(2500)
        print("1. traduci meglio:", await pg.evaluate("(document.querySelector('.pav-trans')||{}).textContent"), "| testo:", (await pg.evaluate("(document.querySelector('.pav-root')||{}).innerText||''")).replace("\n", " | ")[:200])
        print("   max_tokens chiesti:", [m for w, m in tvolo.log.get("maxtok", []) if w == "groq"], "| rifiutati:", tvolo.log.get("maxtok400"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

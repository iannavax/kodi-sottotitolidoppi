## Novità della 5.14.1
- **Registrazioni di Wiktionary trovate meglio** (per esempio *примечание*): oltre al lettore audio, anche quando la pagina ha solo il nome del file o un collegamento al file; e se il Wiktionary inglese non ha la registrazione di quella parola, si cerca in quello della lingua della parola (russo, ceco…) e negli altri grandi. Così compare 🔊 al posto della sola voce sintetica.

## Novità della 5.14
- **Dizionario di Google nella scheda della parola** (gratis, nella stessa richiesta della traduzione, nessuna richiesta in più):
  - **traduzioni con il loro peso**: la più usata in evidenza, una barretta per quanto è comune ciascuna; passando il mouse, le traduzioni al contrario (le parole originali a cui corrisponde);
  - **definizioni nella lingua della parola**, con un esempio;
  - **sinonimi** e **"vedi anche"**;
  - **"Forse cercavi…"** nel controllo della scrittura, quando la parola sembra scritta male.
  Ognuno si spegne nel popup → Strumenti per imparare. Google a volte non dà alcune parti per certe parole o lingue: in quel caso semplicemente non compaiono.

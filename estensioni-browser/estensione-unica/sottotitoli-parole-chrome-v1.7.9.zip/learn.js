// Strumenti per imparare nella scheda della parola (Sottotitoli Doppi e Parole al Volo) — versione di prova.
// Tutti gratis e senza chiavi: frequenza della parola (elenchi FrequencyWords), parole che conosci, genere,
// pronuncia registrata da madrelingua e tabelle di coniugazione/declinazione (Wiktionary), frasi d'esempio
// (Tatoeba), controllo della scrittura (LanguageTool / dizionario). Le parti del modello (falsi amici, parole
// parenti, voto alla scrittura) arrivano nella stessa richiesta della spiegazione, senza richieste in più.
// Usa: DS_EXT, DS_ETYM (etym.js), DS_TTS (tts.js).

// ---------- Spiegazioni salvate (🗂) ----------
// Ogni spiegazione chiesta a un modello («✨ Spiega con…») resta salvata per parola, con la frase e il modello: la
// stessa parola nella stessa frase si mostra subito (anche se nel frattempo hai cambiato modello), e il pulsante 🗂
// della scheda apre l'elenco di tutte le spiegazioni di quella parola (frasi diverse, modelli diversi). Le più vecchie
// si cancellano da sole (al massimo 1200 spiegazioni, 6 per parola). Si salva solo quello che chiedi: nessuna richiesta in più.
var DS_EXPL = (() => {
  // 1.7.3: un pezzo per lingua ("expl:it"), letto solo quando serve e riscritto da solo se cambia (prima: un oggetto solo di 1200
  // spiegazioni, letto da ogni pagina e riscritto intero — e mandato a ogni scheda del browser — a ogni spiegazione chiesta)
  const MAX = 1200, PER = 6;
  const norm = (t) => String(t || "").replace(/\s+/g, " ").trim();
  const base = (lang) => String(lang || "").split("-")[0].toLowerCase() || "?";
  const key = (lang, w) => base(lang) + "|" + norm(w).toLowerCase();
  // "lingua|parola" → [{ s: frase, e: servizio, m: modello, at, d: risposta }]; al massimo ~300 parole per lingua
  const store = dsShardMap("expl", Math.round(MAX / 4), (k) => String(k).split("|")[0]);
  const ready = Promise.resolve();
  const hooks = [];
  const onLoad = (fn) => { hooks.push(fn); };   // chiamata quando un pezzo finisce di leggersi: la scheda si ridisegna
  const kicked = new Set();
  const kick = (lang) => {
    const sh = base(lang);
    if (store.loadedShard(sh) || kicked.has(sh)) return;
    kicked.add(sh);
    store.loadShard(sh).then(() => { for (const f of hooks) try { f(sh); } catch {} });
  };
  const load = (lang) => store.loadShard(base(lang));
  // la risposta senza le parti pesanti o che non servono più (le immagini si ricaricano da sole)
  const slim = (d) => { const o = { ...d }; delete o.persist; delete o.fallback; delete o.error; return o; };
  function list(lang, w) {
    kick(lang);
    const arr = store.get(key(lang, w)) || [];
    return arr.slice().sort((a, b) => (b.at || 0) - (a.at || 0));
  }
  function put(lang, w, sentence, engine, model, d) {
    if (!w || !d || d.error || d.fallback) return;
    const k = key(lang, w), s = norm(sentence).slice(0, 400), item = { s, e: engine, m: model || "", at: Date.now(), d: slim(d) };
    load(lang).then(() => {   // prima il pezzo letto, così non si perdono le spiegazioni già salvate di questa parola
      const arr = (store.get(k) || []).filter((x) => !(x.s === s && x.e === engine && x.m === (model || "")));
      arr.push(item);
      store.delete(k);   // (riparte in coda: le più vecchie sono le prime a uscire)
      store.set(k, arr.slice(-PER), 400);
    });
  }
  // quella della stessa frase (la più recente), per mostrarla subito
  const same = (lang, w, sentence) => list(lang, w).find((x) => x.s === norm(sentence).slice(0, 400)) || null;
  function remove(lang, w, at) {
    const k = key(lang, w), arr = store.get(k);
    if (!arr) return;
    const rest = arr.filter((x) => x.at !== at);
    if (rest.length) store.set(k, rest, 400); else store.delete(k);
  }
  const when = (at) => { try { return new Date(at).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }); } catch { return ""; } };
  return { ready, load, onLoad, list, put, same, remove, when, norm };
})();

// ---------- Parole che conosci ----------
var DS_KNOWN = (() => {
  let map = {};          // lingua → Set di parole (minuscole)
  let version = 0;
  const base = (l) => String(l || "").split("-")[0].toLowerCase() || "?";
  const load = (obj) => { map = {}; for (const [l, s] of Object.entries(obj || {})) map[l] = new Set(String(s || "").split("\n").filter(Boolean)); version++; };
  const ready = DS_EXT.storage.local.get({ knownWords: {} }).then((r) => load(r.knownWords)).catch(() => {});
  DS_EXT.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.knownWords) load(ch.knownWords.newValue); });
  let timer = 0;
  const save = () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      const out = {};
      for (const [l, s] of Object.entries(map)) out[l] = [...s].slice(-50000).join("\n");
      DS_EXT.storage.local.set({ knownWords: out }).catch(() => {});
    }, 300);
  };
  function has(lang, w) {
    w = String(w || "").toLowerCase();
    const b = base(lang);
    if (b !== "?") return !!(map[b] && map[b].has(w));
    return Object.values(map).some((s) => s.has(w));
  }
  function set(lang, w, on) {
    const b = base(lang);
    w = String(w || "").toLowerCase().trim();
    if (!w) return;
    if (!map[b]) map[b] = new Set();
    if (on) map[b].add(w); else map[b].delete(w);
    version++;
    save();
  }
  // quante parole di un testo conosci (contando le ripetizioni) e quante parole diverse
  function stats(words, lang) {
    let known = 0;
    const uniq = new Set(), uniqKnown = new Set();
    for (const w0 of words) {
      const w = String(w0).toLowerCase();
      if (!/\p{L}/u.test(w)) continue;
      uniq.add(w);
      if (has(lang, w)) { known++; uniqKnown.add(w); }
    }
    const total = words.filter((w) => /\p{L}/u.test(w)).length;
    return { known, total, pct: total ? Math.round((known * 100) / total) : 0, unique: uniq.size, uniqueKnown: uniqKnown.size };
  }
  return { ready, has, set, stats, get version() { return version; }, count: (lang) => base(lang) === "?" ? Object.values(map).reduce((n, x) => n + x.size, 0) : (map[base(lang)] || new Set()).size };
})();

// ---------- Frequenza delle parole ----------
var DS_FREQ = (() => {
  const lists = new Map();      // lingua → Map(parola → posizione) | null (non disponibile) | Promise
  const base = (l) => String(l || "").split("-")[0].toLowerCase();
  async function load(lang) {
    const b = base(lang);
    if (!b) return null;
    if (lists.has(b)) return lists.get(b);
    const p = (async () => {
      const key = "freq:" + b;
      const got = await DS_EXT.storage.local.get({ [key]: null, freqFail: {} }).catch(() => ({}));
      let text = got && got[key];
      if (!text) {
        const fail = (got && got.freqFail) || {};
        if (fail[b] && Date.now() - fail[b] < 86400e3) return null;   // non c'era: riprovo domani
        try {
          const r = await DS_EXT.runtime.sendMessage({ type: "freqList", lang: b });
          if (!r || r.error || !r.list) throw new Error((r && r.error) || "vuoto");
          text = r.list;
          await DS_EXT.storage.local.set({ [key]: text }).catch(() => {});
        } catch {
          await DS_EXT.storage.local.set({ freqFail: { ...fail, [b]: Date.now() } }).catch(() => {});
          return null;
        }
      }
      const m = new Map();
      text.split("\n").forEach((w, i) => { if (w && !m.has(w)) m.set(w, i + 1); });
      return m;
    })();
    lists.set(b, p);
    const m = await p;
    lists.set(b, m);
    return m;
  }
  // 1.6.6: la posizione la calcola il sottofondo (non si carica più l'elenco intero in ogni pagina); le risposte restano in memoria
  const ranks = new Map();
  async function rank(word, lang) {
    const k = base(lang) + "|" + String(word || "").toLowerCase();
    if (ranks.has(k)) return ranks.get(k);
    let r;
    try { const x = await DS_EXT.runtime.sendMessage({ type: "freqRank", word, lang }); r = x && x.rank !== undefined ? x.rank : null; }
    catch { r = null; }
    ranks.set(k, r);
    while (ranks.size > 400) ranks.delete(ranks.keys().next().value);
    return r;
  }
  function label(r) {
    if (r == null) return "";
    if (!r) return "molto rara (o un nome)";
    if (r <= 1000) return "molto comune · tra le 1000 più usate";
    if (r <= 5000) return "comune · tra le 5000 più usate";
    if (r <= 15000) return "poco comune · n. " + r;
    return "rara · n. " + r;
  }
  return { rank, label, load };
})();

// ---------- La parte della scheda ----------
var DS_LEARN = (() => {
  const exCache = new Map(), ltCache = new Map();
  let ctxAudio = null;
  const mk = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const btn = (label, title, fn, cls) => {
    const b = mk("button", "dsx-btn" + (cls ? " " + cls : ""), label);
    b.type = "button";
    if (title) b.title = title;
    b.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); fn(b); });
    return b;
  };

  // url: un indirizzo o un elenco (si prova il successivo se il primo non va)
  async function playUrl(url, btnEl) {
    const urls = (Array.isArray(url) ? url : [url]).filter(Boolean);
    if (btnEl) btnEl.textContent = "…";
    let err = "audio non disponibile";
    for (const u of urls) {
      try {
        const r = await DS_EXT.runtime.sendMessage({ type: "fetchB64", url: u });
        if (!r || r.error) throw new Error((r && r.error) || "audio non disponibile");
        const bin = atob(r.b64), bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        ctxAudio = ctxAudio || new AudioContext();
        if (ctxAudio.state === "suspended") await ctxAudio.resume();
        const buf = await ctxAudio.decodeAudioData(bytes.buffer);
        const src = ctxAudio.createBufferSource();
        src.buffer = buf; src.connect(ctxAudio.destination);
        const done = new Promise((res) => { src.onended = res; setTimeout(res, (buf.duration + 1) * 1000); });
        src.start();
        if (btnEl) btnEl.textContent = btnEl.dataset.label || "🔊";
        return { done };
      } catch (e) { err = e.message || String(e); }
    }
    if (btnEl) { btnEl.textContent = "✕"; btnEl.title = "Registrazione non riproducibile: " + err; }
    return false;
  }

  const GENDER = [[/^m|masc/i, "maschile", "dsx-m"], [/^f|fem/i, "femminile", "dsx-f"], [/^n|neut/i, "neutro", "dsx-n"], [/^c|common/i, "comune", "dsx-c"]];
  function genderInfo(g, lang) {
    if (!g) return null;
    const hit = GENDER.find(([re]) => re.test(g.trim()));
    if (!hit) return null;
    const art = String(lang).startsWith("de") ? { maschile: "der", femminile: "die", neutro: "das" }[hit[1]] : "";
    const plural = /\bpl|plural/i.test(g) ? " plurale" : "";
    return { text: hit[1] + plural + (art ? " · " + art : ""), cls: hit[2] };
  }

  // risultato di LanguageTool per la parola cliccata dentro la frase
  function ltForWord(lt, sentence, word) {
    if (!lt || !lt.matches) return null;
    const s = String(sentence || ""), w = String(word || "");
    const at = s.toLowerCase().indexOf(w.toLowerCase());
    if (at < 0) return { ok: !lt.matches.length };
    const m = lt.matches.find((x) => x.offset < at + w.length && x.offset + x.length > at);
    return m ? { ok: false, message: m.message || m.short, repl: m.repl } : { ok: true };
  }

  const GW_LANGS = /^(en|es|fr|de|it|pt|ru|hi|ja|ko|ar|tr)$/;
  // Il dizionario delle ricerche di Google (Oxford) non c'è più: nel 2026 Google mostra solo l'AI Overview e
  // l'indirizzo non ufficiale risponde 400. Spento: significati, sinonimi e traduzioni arrivano da Google Traduttore e
  // da Wiktionary, origine e albero da Wiktionary. Se Google lo rimette, basta true.
  const GW_ON = false;
  // immagine (albero etimologico) presa dal sottofondo: nelle pagine dei siti un'immagine di Google può essere bloccata
  function gwImage(url, holder, st, done) {
    st.gwImg = st.gwImg || {};
    if (st.gwImg[url]) return st.gwImg[url];
    st.gwImg[url] = { wait: true };
    DS_EXT.runtime.sendMessage({ type: "fetchB64", url }).then((r) => {
      st.gwImg[url] = r && r.b64 ? { src: "data:" + (r.type || (/\.svg/i.test(url) ? "image/svg+xml" : "image/png")) + ";base64," + r.b64 } : { error: true };
      done();
    }).catch(() => { st.gwImg[url] = { error: true }; done(); });
    return st.gwImg[url];
  }
  function gwTree(url, st, ctx) {
    const im = gwImage(url, null, st, () => { if (!ctx.stale()) ctx.rerender(); });
    const d = mk("div", "dsx-gwtree");
    if (im.src) { const i = mk("img"); i.src = im.src; i.alt = "Albero etimologico (Google)"; d.append(i); }
    else d.append(mk("span", "dsx-muted", im.error ? "Albero non disponibile" : "Albero etimologico …"));
    return d;
  }
  // albero etimologico di Wiktionary: rami annidati, dalla radice più antica alla parola
  // ---------- Albero etimologico vero di Wiktionary ({ ety: nodo }, da parseEtytree in etym.js) ----------
  // Si legge dall'alto in basso, dall'origine più antica alla parola: ogni passo con la lingua (nella lingua di «Traduci
  // in» quando il browser la conosce), la parola, la traslitterazione, il significato e, fra un passo e l'altro, come la
  // parola sotto viene da quella sopra (prestito, ereditata, derivata…). Le parole composte («formata da: a + b»)
  // hanno l'origine di ogni parte in un riquadro che si apre.
  const ETY_REL = {
    "bor": "prestito", "lbor": "prestito dotto", "slbor": "prestito semidotto", "obor": "prestito ortografico", "ubor": "prestito non adattato",
    "inh": "ereditata", "der": "derivata", "from": "derivata", "cal": "calco", "clq": "calco", "pcal": "calco parziale", "pclq": "calco parziale",
    "sl": "prestito di significato", "bf": "retroformazione", "clip": "accorciamento", "abbr": "abbreviazione", "abbrev": "abbreviazione",
    "rdp": "raddoppiamento", "translit": "traslitterazione", "uder": "derivazione incerta", "af": "", "affix": "", "acro": "acronimo",
    "init": "sigla", "meta": "metatesi", "ellip": "ellissi", "univ": "univerbazione", "denom": "denominale",
    "loanword": "prestito", "borrowed": "prestito", "learned borrowing": "prestito dotto", "semi-learned borrowing": "prestito semidotto",
    "orthographic borrowing": "prestito ortografico", "unadapted borrowing": "prestito non adattato", "derived terms": "derivata",
    "derived": "derivata", "inherited": "ereditata", "calque": "calco", "partial calque": "calco parziale", "semantic loan": "prestito di significato",
    "contamination": "per contaminazione", "influence": "influenza", "back-formation": "retroformazione", "clipping": "accorciamento",
    "abbreviation": "abbreviazione", "blend": "incrocio", "transliteration": "traslitterazione", "undefined derivation": "derivazione incerta",
    "reduplication": "raddoppiamento", "ellipsis": "ellissi", "univerbation": "univerbazione", "deverbal": "deverbale", "denominal": "denominale",
    "metathesis": "metatesi", "acronym": "acronimo", "initialism": "sigla", "apheretic": "aferesi"
  };
  const ETY_PROTO = { "ine-pro": "protoindoeuropeo", "gem-pro": "protogermanico", "gmw-pro": "protogermanico occidentale", "itc-pro": "protoitalico",
    "sla-pro": "protoslavo", "grk-pro": "protoellenico", "cel-pro": "protoceltico", "iir-pro": "protoindoiranico", "urj-pro": "protouralico",
    "sem-pro": "protosemitico", "bat-pro": "protobaltico", "ine-bsl-pro": "protobaltoslavo", "trk-pro": "prototurco", "ira-pro": "protoiranico",
    "inc-pro": "protoindoario", "fiu-fin-pro": "protofinnico", "la-lat": "tardo latino", "la-med": "latino medievale", "la-new": "latino moderno",
    "la-vul": "latino volgare", "grc-koi": "greco della koinè", "roa-opt": "galiziano-portoghese antico", "osp": "spagnolo antico", "orv": "slavo orientale antico",
    "cu": "antico slavo ecclesiastico", "roa-oit": "italiano antico", "pro": "provenzale antico", "ofs": "frisone antico", "odt": "olandese antico",
    "gml": "basso tedesco medio", "osx": "sassone antico", "dum": "olandese medio", "ota": "turco ottomano", "xno": "anglo-normanno",
    // lingue antiche che il browser spesso non sa nominare in italiano
    "ang": "inglese antico", "enm": "inglese medio", "fro": "francese antico", "frm": "francese medio", "grc": "greco antico",
    "goh": "alto tedesco antico", "gmh": "medio alto tedesco", "non": "norreno", "akk": "accadico", "syc": "siriaco classico",
    "sga": "irlandese antico", "mga": "irlandese medio", "owl": "gallese antico", "peo": "persiano antico", "pal": "medio persiano",
    "sux": "sumerico", "egy": "egizio", "hit": "ittita", "got": "gotico", "arc": "aramaico", "he": "ebraico", "hbo": "ebraico antico",
    "sa": "sanscrito", "pi": "pali", "xcl": "armeno classico", "oge": "georgiano antico", "ofr": "frisone antico", "nds": "basso tedesco",
    "okm": "coreano medio", "ojp": "giapponese antico", "ltc": "cinese medio", "och": "cinese antico", "zh": "cinese", "osc": "osco",
    "xum": "umbro", "ett": "etrusco", "oc": "occitano", "ca": "catalano", "an": "aragonese", "lad": "giudeo-spagnolo",
    "ruo": "rumeno istriano", "dlm": "dalmatico", "sla": "slavo", "zle-ort": "ruteno", "zle-mru": "russo medio" };
  function etyLangName(n, target) {
    const code = String(n.code || "");
    if (ETY_PROTO[code]) return /^it/.test(target || "it") ? ETY_PROTO[code] : n.lang;
    if (code && !/-pro$/.test(code)) {
      try { const x = new Intl.DisplayNames([target || "it"], { type: "language", fallback: "none" }).of(code.split("-")[0].length <= 3 && !/-/.test(code) ? code : code.split("-")[0]); if (x && x.toLowerCase() !== code) return x; } catch {}
    }
    return n.lang || code;
  }
  // indirizzo di Etymology Explorer per un passo dell'albero: /word/<lingua in inglese, come la scrive Wiktionary>/<parola>
  function etyExplorerFor(n) {
    const term = String(n.term || "").replace(/^\*/, "").trim();
    let lang = String(n.lang || "").trim();
    if (!lang || /[^\x20-\x7e]/.test(lang)) { try { lang = new Intl.DisplayNames(["en"], { type: "language" }).of(String(n.code || "").split("-")[0]) || ""; } catch { lang = ""; } }
    if (!term || !lang || lang.toLowerCase() === String(n.code || "").toLowerCase()) return "";
    return "https://etymologyexplorer.com/word/" + encodeURIComponent(lang) + "/" + encodeURIComponent(term);
  }
  function etyTreeView(root, target, of) {
    const box = mk("div", "dsx-wtree dsx-etytree");
    box.append(mk("div", "dsx-muted", "Albero etimologico di Wiktionary" + (of ? " di «" + of + "»" : "") + ": dall'origine più antica (in alto) alla parola (in basso)"));
    const stepLine = (n) => {
      const d = mk("div", "dsx-ety-step" + (n.self ? " dsx-ety-self" : "") + (n.dup ? " dsx-ety-dup" : ""));
      d.append(mk("span", "dsx-ety-lang", etyLangName(n, target)), document.createTextNode(" "), mk("b", "dsx-ety-term", n.term));
      if (n.tr && n.tr !== n.term) d.append(document.createTextNode(" (" + n.tr + ")"));
      if (n.gloss) d.append(mk("span", "dsx-ety-gloss", " «" + n.gloss + "»"));
      if (n.dup) d.append(mk("span", "dsx-muted", " (già sopra)"));
      // ↗ questa parola su Etymology Explorer: se la parola della scheda lì non c'è, si apre l'antenato più vicino
      const ee = etyExplorerFor(n);
      if (ee) { const a = mk("a", "dsx-link dsx-ety-ee", "↗"); a.href = ee; a.target = "_blank"; a.rel = "noopener noreferrer"; a.title = "Apri «" + n.term + "» su Etymology Explorer (la mappa delle origini)"; d.append(document.createTextNode(" "), a); }
      return d;
    };
    const how = (p, child) => {
      const key = String(p.rel || "").toLowerCase();
      let t = key in ETY_REL ? ETY_REL[key] : key;
      if (!t) t = p.code && child.code && p.code.split("-")[0] !== child.code.split("-")[0] ? "ereditata" : "derivata";
      return (p.unc ? "forse " : "") + t;
    };
    const oldest = (n) => { let x = n; while (x.parents && x.parents.length === 1) x = x.parents[0]; return x; };
    const render = (node, depth) => {
      const wrap = mk("div", "dsx-ety-chain");
      // la catena senza bivi sopra questo nodo (dalla più antica)
      const chain = [node];
      while (chain[0].parents && chain[0].parents.length === 1) chain.unshift(chain[0].parents[0]);
      const top = chain[0];
      if (top.parents && top.parents.length > 1) {
        const parts = mk("div", "dsx-ety-parts");
        // parti di un composto (a + b) oppure più origini possibili / diverse (a; b)
        const joined = top.parts !== false ? top.parents.map((p) => p.term).join(" + ") : top.parents.map((p) => (how(p, top) ? how(p, top) + " " : "") + p.term).join("; ");
        parts.append(mk("div", "dsx-ety-partshead", (top.term ? "«" + top.term + "» " + (top.parts !== false ? "è formata da: " : "viene da: ") : "Formata da: ") + joined));
        for (const p of top.parents) {
          const det = document.createElement("details");
          det.className = "dsx-ety-part";
          if (depth === 0 && top.parents.length <= 3) det.open = true;
          const o = oldest(p);
          const sum = document.createElement("summary");
          sum.textContent = "origine di «" + p.term + "»" + (o !== p && o.term ? " — la più antica: " + etyLangName(o, target) + " " + o.term : "");
          det.append(sum, render(p, depth + 1));
          parts.append(det);
        }
        wrap.append(parts);
        if (!top.term) chain.shift();   // unione senza parola propria
        else wrap.append(mk("div", "dsx-ety-arrow", "↓ si uniscono in"));
      }
      chain.forEach((n, i) => {
        wrap.append(stepLine(n));
        // influenze (non antenati): «*dwís» influenzata da «*trís»
        for (const s of n.side || []) wrap.append(mk("div", "dsx-ety-side", "↳ " + (s.unc ? "forse " : "") + "con l'influenza di: " + etyLangName(s, target) + " " + s.term + (s.gloss ? " «" + s.gloss + "»" : "")));
        if (i < chain.length - 1) wrap.append(mk("div", "dsx-ety-arrow", "↓ " + how(n, chain[i + 1])));
      });
      return wrap;
    };
    box.append(render(root.ety, 0));
    return box;
  }
  function wiktTree(tree, of, fromChain, target) {
    if (tree && tree.ety) return etyTreeView(tree, target, of);
    const d = mk("div", "dsx-wtree");
    d.append(mk("div", "dsx-muted", fromChain ? "Dalla catena dell'etimologia di Wiktionary" + (of ? " di «" + of + "»" : "") : "Albero di Wiktionary" + (of ? " di «" + of + "»" : "")));
    const list = (items) => {
      const ul = mk("ul");
      for (const it of items) {
        const li = mk("li", null, it.text);
        if (it.kids && it.kids.length) li.append(list(it.kids));
        ul.append(li);
      }
      return ul;
    };
    d.append(list(tree));
    return d;
  }
  // uso nel tempo: piccolo grafico dai libri (Google Books Ngram)
  // Uso nel tempo (Google Books Ngram): quante volte la parola compare ogni milione di parole nei libri, anno per
  // anno. Grafico piccolo e disegnato qui (SVG, niente librerie): anni sotto nel punto giusto, il valore più alto a
  // sinistra, una frase che riassume l'andamento e, passando il mouse, il valore di ogni anno.
  function sparkline(ng) {
    const v = (ng.values || []).map((x) => (Number(x) || 0) * 1e6);   // per milione di parole
    const y0 = ng.start, y1 = ng.end, n = v.length;
    const nf = (x) => (x > 0 && x < 0.01 ? "meno di 0,01" : new Intl.NumberFormat("it-IT", { maximumSignificantDigits: 2 }).format(x));
    const W = 280, H = 84, L = 6, R = 6, T = 6, B = 20, PW = W - L - R, PH = H - T - B;
    const max = Math.max(...v, 1e-9), peak = v.indexOf(Math.max(...v));
    const X = (i) => L + (i / Math.max(1, n - 1)) * PW, Y = (x) => T + PH - (x / max) * PH;
    const NS = "http://www.w3.org/2000/svg";
    // colori, spessori e caratteri anche come stile scritto sull'elemento: le regole delle pagine (YouTube, siti con
    // «all: revert», «svg path { fill: … }») vincono sugli attributi del disegno e il grafico spariva o veniva nero
    const STYLE = new Set(["fill", "stroke", "stroke-width", "fill-opacity", "stroke-opacity", "stroke-dasharray", "stroke-linejoin", "stroke-linecap",
      "font-size", "font-weight", "font-family", "paint-order", "visibility", "vector-effect", "text-anchor"]);
    const el = (tag, at) => {
      const e = document.createElementNS(NS, tag);
      const css = [];
      for (const k in at) { e.setAttribute(k, at[k]); if (STYLE.has(k)) css.push(k + ":" + (k === "font-size" ? at[k] + "px" : at[k])); }
      if (css.length) e.setAttribute("style", css.join(";"));
      return e;
    };
    const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, class: "dsx-spark", role: "img" });
    svg.style.cssText = "display:block;width:100%;max-width:280px;height:auto;overflow:visible";
    // righe di riferimento: in cima (il massimo) e la base (zero)
    svg.append(el("line", { x1: L, x2: W - R, y1: T, y2: T, stroke: "currentColor", "stroke-opacity": "0.25", "stroke-dasharray": "2 3" }));
    svg.append(el("line", { x1: L, x2: W - R, y1: T + PH, y2: T + PH, stroke: "currentColor", "stroke-opacity": "0.45" }));
    // anni: un segno ogni 50 anni, nel punto giusto
    for (let yr = Math.ceil(y0 / 50) * 50; yr <= y1; yr += 50) {
      const x = X(yr - y0);
      svg.append(el("line", { x1: x, x2: x, y1: T + PH, y2: T + PH + 3, stroke: "currentColor", "stroke-opacity": "0.45" }));
      // anni ben leggibili: più grandi, chiari (non del colore della linea) e con un bordo scuro intorno
      const t = el("text", { x, y: H - 4, "font-size": "11.5", "font-weight": "600", "text-anchor": yr === y0 ? "start" : yr + 50 > y1 && x > W - 20 ? "end" : "middle",
        fill: "#eef2f7", stroke: "#10151d", "stroke-width": "3", "paint-order": "stroke", "font-family": "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif" });
      t.textContent = yr; svg.append(t);
    }
    // curva morbida e monotona (Fritsch-Carlson) come nel grafico vero: con le linee dritte fra un anno e l'altro, in
    // un grafico piccolo, gli anni con pochi libri facevano scalini e salite che sembravano errori. La curva passa
    // esattamente per i valori di ogni anno e non inventa picchi o discese che non ci sono.
    // per il disegno: media mobile su 5 anni (in 270 px ci sono più di 200 anni: un anno «ballerino» dei libri vecchi
    // diventava un dente). I valori letti col mouse, il massimo e il riassunto restano quelli veri.
    const vs = v.map((_, i) => { let s = 0, c = 0; for (let k = Math.max(0, i - 2); k <= Math.min(n - 1, i + 2); k++) { s += v[k]; c++; } return s / c; });
    const P = vs.map((x, i) => [X(i), Y(x)]);
    const curve = (() => {
      const m = P.length;
      if (m < 3) return "M" + P.map((p) => p[0].toFixed(1) + "," + p[1].toFixed(1)).join(" L");
      const dx = [], sl = [], tg = new Array(m);
      for (let i = 0; i < m - 1; i++) { dx.push(P[i + 1][0] - P[i][0]); sl.push((P[i + 1][1] - P[i][1]) / dx[i]); }
      tg[0] = sl[0]; tg[m - 1] = sl[m - 2];
      for (let i = 1; i < m - 1; i++) tg[i] = sl[i - 1] * sl[i] <= 0 ? 0 : (sl[i - 1] + sl[i]) / 2;
      for (let i = 0; i < m - 1; i++) {
        if (sl[i] === 0) { tg[i] = tg[i + 1] = 0; continue; }
        const a = tg[i] / sl[i], b = tg[i + 1] / sl[i], h = a * a + b * b;
        if (h > 9) { const t = 3 / Math.sqrt(h); tg[i] = t * a * sl[i]; tg[i + 1] = t * b * sl[i]; }
      }
      let d = "M" + P[0][0].toFixed(2) + "," + P[0][1].toFixed(2);
      for (let i = 0; i < m - 1; i++) {
        const h = dx[i] / 3;
        d += ` C${(P[i][0] + h).toFixed(2)},${(P[i][1] + tg[i] * h).toFixed(2)} ${(P[i + 1][0] - h).toFixed(2)},${(P[i + 1][1] - tg[i + 1] * h).toFixed(2)} ${P[i + 1][0].toFixed(2)},${P[i + 1][1].toFixed(2)}`;
      }
      return d;
    })();
    svg.append(el("path", { d: `${curve} L${(W - R).toFixed(2)},${T + PH} L${L},${T + PH} Z`, fill: "currentColor", "fill-opacity": "0.15", stroke: "none" }));
    svg.append(el("path", { d: curve, fill: "none", stroke: "currentColor", "stroke-width": "1.5", "stroke-linejoin": "round", "stroke-linecap": "round", "vector-effect": "non-scaling-stroke" }));
    // il punto più alto
    svg.append(el("circle", { cx: X(peak), cy: Y(vs[peak]), r: 2.4, fill: "currentColor" }));
    // guida verticale per il mouse
    const guide = el("line", { y1: T, y2: T + PH, stroke: "currentColor", "stroke-opacity": "0.6", visibility: "hidden" });
    const dot = el("circle", { r: 2.6, fill: "#fff", stroke: "currentColor", visibility: "hidden" });
    // l'anno e il valore proprio accanto al punto, a colpo d'occhio (sotto resta la riga di testo)
    const lab = el("text", { y: T + 9, "font-size": "11.5", "font-weight": "700", fill: "#fff", stroke: "#10151d", "stroke-width": "3", "paint-order": "stroke", visibility: "hidden",
      "font-family": "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif" });
    svg.append(guide, dot, lab);
    // riassunto: anno di massimo uso e andamento recente (ultimi 10 anni rispetto a 50 anni prima)
    const avg = (a, b) => { const s = v.slice(Math.max(0, a - y0), Math.max(0, b - y0 + 1)); return s.length ? s.reduce((x, y) => x + y, 0) / s.length : 0; };
    const now = avg(y1 - 9, y1), before = avg(y1 - 59, y1 - 50);
    const ch = before > 0 ? Math.round(((now - before) / before) * 100) : null;
    const trend = ch == null ? "" : Math.abs(ch) < 15 ? `Negli ultimi 50 anni più o meno stabile.` : ch > 0 ? `Rispetto a 50 anni fa: in aumento (+${ch}%).` : `Rispetto a 50 anni fa: in calo (−${-ch}%).`;
    const wrap = mk("div", "dsx-sparkwrap");
    const sum = mk("div", "dsx-sparksum", `Più usata intorno al ${y0 + peak}. ${trend}`);
    const scale = mk("div", "dsx-muted dsx-sparkscale", `in cima: ${nf(max)} volte ogni milione di parole · base: 0`);
    const read = mk("div", "dsx-sparkread");
    const show = (i) => { read.textContent = `${y0 + i}: ${nf(v[i])} volte ogni milione di parole`; };
    const rest = () => { guide.style.visibility = "hidden"; dot.style.visibility = "hidden"; lab.style.visibility = "hidden"; read.textContent = `Ultimo anno (${y1}): ${nf(v[n - 1])} volte ogni milione di parole · passa il mouse sul grafico per gli altri anni`; };
    svg.addEventListener("mousemove", (e) => {
      const r = svg.getBoundingClientRect();
      const i = Math.max(0, Math.min(n - 1, Math.round((((e.clientX - r.left) / r.width) * W - L) / PW * (n - 1))));
      guide.setAttribute("x1", X(i)); guide.setAttribute("x2", X(i)); guide.style.visibility = "visible";
      dot.setAttribute("cx", X(i)); dot.setAttribute("cy", Y(vs[i])); dot.style.visibility = "visible";
      lab.textContent = `${y0 + i} · ${nf(v[i])}`; lab.setAttribute("x", X(i) + (X(i) > W * 0.6 ? -6 : 6)); lab.setAttribute("text-anchor", X(i) > W * 0.6 ? "end" : "start"); lab.style.visibility = "visible";
      show(i);
    });
    svg.addEventListener("mouseleave", rest);
    rest();
    wrap.append(sum, svg, scale, read);
    // da dove vengono i dati: il grafico vero di Google Books Ngram Viewer, da aprire in un'altra scheda
    const CORP = { en: "in inglese", it: "in italiano", fr: "in francese", de: "in tedesco", es: "in spagnolo", ru: "in russo", iw: "in ebraico", "zh-Hans": "in cinese" };
    const cl = CORP[String(ng.corpus || "").replace(/-\d{4}$/, "")] || "";
    const src = mk("div", "dsx-muted dsx-sparksrc", "Dati: Google Books Ngram Viewer (libri" + (cl ? " " + cl : "") + ", " + y0 + "–" + y1 + "). ");
    if (ng.word) {
      const a = mk("a", "dsx-sparklink", "Apri il grafico completo ↗");
      a.href = "https://books.google.com/ngrams/graph?" + new URLSearchParams({ content: ng.word, year_start: y0, year_end: y1, corpus: ng.corpus || "en", smoothing: "3" });
      a.target = "_blank"; a.rel = "noopener";
      a.title = "Apre Google Books Ngram Viewer con questa parola: il grafico grande, da confrontare con altre parole";
      a.addEventListener("click", (e) => e.stopPropagation());
      src.append(a);
    }
    wrap.append(src);
    return wrap;
  }
  // uso nel tempo (Google Books Ngram): il grafico compare da solo quando la scheda resta aperta un attimo (una richiesta
  // gratuita a Google per parola, ricordata); con «Grafico dell'uso nel tempo» spento resta il pulsante
  const NGRAM_LANG = /^(en|fr|de|it|es|ru|he|iw|zh)/;
  const ngWord = (ctx) => String(ctx.word || "").trim().toLowerCase();
  const ngCache = new Map();
  function ngramLoad(ctx, done) {
    const st = ctx.st, w = ngWord(ctx);
    if (!w || w.split(/\s+/).length > 5 || st.ngram) return;
    const k = String(ctx.lang).split("-")[0] + "|" + w;
    if (ngCache.has(k)) { st.ngram = ngCache.get(k); return; }
    st.ngram = { wait: true };
    DS_EXT.runtime.sendMessage({ type: "ngram", word: w, lang: ctx.lang })
      .then((r) => { st.ngram = r || { values: [] }; if (st.ngram.values && st.ngram.values.length) ngCache.set(k, st.ngram); })
      .catch((e) => { st.ngram = { values: [], error: String(e.message || e) }; })
      .then(() => { if (!ctx.stale()) (done || ctx.rerender)(); });
  }
  function ngramRow(ctx) {
    const st = ctx.st;
    if (!NGRAM_LANG.test(String(ctx.lang || ""))) return null;
    const w = ngWord(ctx);
    if (!w || w.split(/\s+/).length > 5) return null;
    const box = mk("div", "dsx-ngramrow");
    const ng = st.ngram;
    const open = (txt) => { const a = mk("a", "dsx-sparklink", txt); a.href = "https://books.google.com/ngrams/graph?" + new URLSearchParams({ content: w, year_start: 1800, year_end: 2022, corpus: String(ctx.lang).split("-")[0] === "he" ? "iw" : String(ctx.lang).split("-")[0] === "zh" ? "zh-Hans" : String(ctx.lang).split("-")[0], smoothing: "3" }); a.target = "_blank"; a.rel = "noopener"; a.addEventListener("click", (e) => e.stopPropagation()); return a; };
    const go = async () => { st.ngram = null; ngCache.delete(String(ctx.lang).split("-")[0] + "|" + w); ngramLoad(ctx); ctx.rerender(); };
    if (!ng) box.append(btn("📈 uso nel tempo", "Quanto compare nei libri dal 1800 a oggi (Google Books Ngram). Passa il mouse sul grafico per vedere ogni anno", go));
    else if (ng.wait) box.append(mk("div", "dsx-muted", "Uso nel tempo …"));
    else if (ng.values && ng.values.length) {
      const d = mk("div", "dsx-gwngram");
      d.append(mk("b", null, `Uso nel tempo: quanto compare nei libri, ${ng.start}–${ng.end}`)); d.append(sparkline(ng)); box.append(d);
    } else {
      const d = mk("div", "dsx-muted", "Uso nel tempo: nessun dato" + (ng.error ? " (" + ng.error + ")" : "") + ". ");
      d.append(btn("Riprova", "Chiede di nuovo il grafico a Google Books", go, "dsx-link"), document.createTextNode(" "), open("Apri su Google Books ↗"));
      box.append(d);
    }
    return box;
  }

  // il grafico dell'uso nel tempo da solo (pagina del vocabolario, dei kanji…): { word, lang } → elemento
  function ngramWidget(word, lang) {
    const wrap = mk("div", "dsx");
    const ctx = { st: {}, word, lang, stale: () => !wrap.isConnected, rerender: () => { wrap.textContent = ""; const r = ngramRow(ctx); if (r) wrap.append(r); } };
    ngramLoad(ctx); ctx.rerender();
    return wrap;
  }

  // 1.7.9: scegliere la forma base (radice, lemma) da cui deriva la forma flessa di una parola e aprire la scheda intera di quella
  // parola (da vedere e salvare). ctx = { word, lang, target, lemma, hints: [parole da provare], store: oggetto dove ricordare le proposte,
  // open(lemma), rerender() }. Le proposte vengono da Wiktionary (✓ = la forma è nella tabella di quella parola, quindi è sicura).
  function lemmaPicker(ctx) {
    const box = mk("div", "dsx-fix dsx-lemmabox");
    box.append(mk("div", "dsx-muted", `Forma base (radice) di «${ctx.word}»: scrivila o scegli una proposta. Si apre la scheda intera di quella parola, da vedere e salvare; la scelta resta anche per l'etimologia.`));
    const t = mk("input", "dsx-input");
    t.value = ctx.lemma || ""; t.placeholder = "forma base";
    const go = (b) => {
      b = String(b || "").trim();
      if (!b) return;
      // la scelta resta salvata (vale anche per l'etimologia di questa forma); la scheda si apre subito
      try { DS_ETYM.setBase(ctx.word, ctx.lang, ctx.target, b); } catch {}
      ctx.open(b);
    };
    for (const ev of ["keydown", "keyup", "keypress"]) t.addEventListener(ev, (e) => { e.stopPropagation(); if (ev === "keydown" && e.key === "Enter") go(t.value); });
    box.append(t, btn("apri la scheda", "Apre la scheda intera di questa parola: la puoi vedere e salvare", () => go(t.value), "dsx-known-on"));
    const list = mk("div", "dsx-baselist");
    box.append(list);
    const draw = (bs) => {
      list.textContent = "";
      const seen = new Set();
      const add = (title, label, tip, sure) => { if (!title || seen.has(title.toLowerCase())) return; seen.add(title.toLowerCase()); list.append(btn(label, tip, () => go(title), sure ? "dsx-known-on" : "")); };
      if (ctx.lemma && String(ctx.lemma).toLowerCase() !== ctx.word.toLowerCase()) add(ctx.lemma, ctx.lemma + " (trovata dalla scheda)", "La forma base trovata dalla scheda", false);
      if (bs === "…") { list.append(mk("div", "dsx-muted", "Cerco le forme base su Wiktionary…")); return; }
      if (bs && bs.error) list.append(mk("div", "dsx-muted", "Wiktionary non risponde (" + bs.error + "): scrivila tu qui sopra."));
      else if (bs && bs.list) {
        if (!bs.list.length && !seen.size) list.append(mk("div", "dsx-muted", "Nessuna proposta trovata: scrivila tu qui sopra."));
        for (const c of bs.list) add(c.title, (c.sure ? "✓ " : "") + c.title + (c.sure ? "" : c.near >= 0.5 ? " (stessa radice)" : ""), c.sure ? "«" + ctx.word + "» è una forma di questa parola" : "Questa pagina contiene «" + ctx.word + "», ma non nella tabella delle forme: controlla", c.sure);
      }
    };
    const store = ctx.store || {};
    if (store.cands) draw(store.cands);
    else {
      draw("…");
      store.cands = "…";
      DS_ETYM.searchBases(ctx.word, ctx.lang, [ctx.lemma, ...(ctx.hints || [])].filter(Boolean)).then((bs) => {
        store.cands = bs;
        if (box.isConnected) draw(bs); else if (ctx.rerender) ctx.rerender();
      }).catch(() => { store.cands = null; });
    }
    setTimeout(() => { try { t.focus(); t.select(); } catch {} }, 0);
    return box;
  }
  // ---------- 1.6.3: modi di dire con una parola, in generale (non solo nella frase) ----------
  // pn = { word, wait, dict: [titoli di Wiktionary], idioms: [{ text, meaning, example, inSentence }], error, source, noLlm }
  // o = { searchWord(w), save(item), isSaved(item), retry(), lang }. Ogni parola di un modo di dire è un pulsante: cercarne altri partendo da lì.
  // 1.7.2: un clic su una parola di un modo di dire apre una scheda piccola (traduzione gratuita di Google) con il pulsante per
  // cercare altri modi di dire con quella parola: la ricerca non parte più da sola. Fuori dal pannello (la parola cliccata della
  // scheda principale) il clic cerca subito, come prima.
  function idiomMini(anchor, word, o) {
    const host = anchor.closest(".dsx-idline, .dsx-iddict"), panel = anchor.closest(".dsx-idpanel");
    if (!host || !panel) return o.searchWord(word);
    const old = panel.querySelector(".dsx-idmini");
    if (old) old.remove();
    if (old && old.dataset.w === word && old._host === host) return;   // secondo clic sulla stessa parola: la chiude
    const ctxText = ((anchor.closest(".dsx-idtext") || {}).textContent || word).trim();   // il modo di dire intero, come contesto della parola
    const card = mk("div", "dsx-idmini"); card.dataset.w = word; card._host = host;
    const head = mk("div", "dsx-idmhead");
    head.append(mk("span", "dsx-idmw", word), btn("×", "Chiudi", () => card.remove(), "dsx-btn dsx-idmx"));
    // alfabeto non latino (cirillico, greco, arabo, ebraico, hindi, kana, hangul…): le lettere latine, subito e senza servizi
    let rom = "";
    try { if (typeof DS_ROMAN !== "undefined" && DS_ROMAN.needs(word)) rom = DS_ROMAN.word(word, o.lang || ""); } catch {}
    if (rom && rom.toLowerCase() !== word.toLowerCase()) head.firstChild.after(mk("span", "dsx-idmrom dsx-muted", " [" + rom + "]"));
    const tr = mk("div", "dsx-idmtr", "…"), defs = mk("div", "dsx-idmdefs dsx-muted"), exp = mk("div", "dsx-idmexp");
    const actions = mk("div", "dsx-idmacts");
    card.append(head, tr, defs, exp, actions);
    // gratis: traduzione (Google) e definizioni del dizionario di Google, subito
    if (o.target) {
      DS_EXT.runtime.sendMessage({ type: "define", engine: "google", target: o.target, word, sentence: ctxText, lang: o.lang || "" })
        .then((r) => { if (!card.isConnected) return; tr.textContent = r && r.meaning ? "→ " + r.meaning + (r.pos ? " (" + r.pos + ")" : "") : ""; if (!tr.textContent) tr.remove(); })
        .catch(() => { if (card.isConnected) tr.remove(); });
    } else tr.remove();
    if (o.lang) {
      DS_EXT.runtime.sendMessage({ type: "googleWebDict", word, lang: o.lang }).then((r) => {
        if (!card.isConnected) return;
        const senses = [];
        for (const e of (r && r.entries) || []) for (const g of e.groups || []) for (const sn of g.senses || []) if (sn.def && senses.length < 3) senses.push(sn.def);
        if (senses.length) senses.forEach((d) => defs.append(mk("div", "dsx-idmdef", "• " + d)));
      }).catch(() => {});
    }
    // la spiegazione del modello solo su richiesta (i modelli non partono mai da soli)
    const e = o.llm && o.llm();
    if (e) {
      const eb = btn("✨ Spiega con " + (e.name || "il modello"), "Spiega questa parola nel modo di dire (una richiesta al modello)", async (b) => {
        b.disabled = true; b.textContent = "✨ …";
        let r;
        try { r = await dsSendLong({ type: "define", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, target: o.target, word, sentence: ctxText, lang: o.lang || "", ipa: false, etym: false, extra: false }); }
        catch (x) { r = { error: String(x.message || x) }; }
        if (!card.isConnected) return;
        exp.textContent = "";
        if (!r || r.error || r.fallback) { exp.append(mk("div", "dsx-muted", "Spiegazione non disponibile: " + ((r && (r.error || r.source)) || "nessuna risposta"))); b.disabled = false; b.textContent = "✨ Riprova"; return; }
        if (r.meaning && tr.isConnected) tr.textContent = "→ " + r.meaning + (r.pos ? " (" + r.pos + ")" : "");
        if (r.explanation) exp.append(mk("div", "dsx-idmexpl", r.explanation));
        if (r.example) exp.append(mk("div", "dsx-idex dsx-muted", r.example + (r.exampleTrans ? " — " + r.exampleTrans : "")));
        if (r.source) exp.append(mk("div", "dsx-muted dsx-idsrc", "Modello: " + String(r.source).split(" (")[0]));
        b.remove();
      }, "dsx-btn dsx-idmai");
      actions.append(eb);
    }
    actions.append(btn(`🔎 Altri modi di dire con «${word}»`, "Cerca i modi di dire che contengono questa parola (dizionario gratuito di Wiktionary e, se c'è, il modello)", () => { card.remove(); o.searchWord(word); }, "dsx-btn dsx-idmgo"));
    host.after(card);
  }
  function idiomWords(text, o, cls) {
    const span = mk("span", cls || "dsx-idtext");
    String(text).split(/(\s+)/).forEach((part) => {
      if (!part.trim()) { span.append(document.createTextNode(part)); return; }
      const clean = part.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "");
      if (clean.length < 3) { span.append(document.createTextNode(part)); return; }
      const w = mk("button", "dsx-idw", part); w.type = "button";
      w.title = `Apri la scheda di «${clean}»: da lì puoi cercare altri modi di dire con questa parola`;
      w.addEventListener("click", (e) => { e.stopPropagation(); idiomMini(w, clean, o); });
      span.append(w);
    });
    return span;
  }
  function idiomPanel(pn, o) {
    const box = mk("div", "dsx-idpanel");
    box.append(mk("div", "dsx-idhead", `Modi di dire con «${pn.word}»` + (pn.wait ? " …" : "")));
    if (pn.error) {
      const d = mk("div", "dsx-muted", "Non riesco a chiederli al modello: " + pn.error + " ");
      if (o.retry) d.append(btn("Riprova", "Chiede di nuovo, con il modello successivo se questo è occupato", o.retry, "dsx-link"));
      box.append(d);
    }
    for (const it of pn.idioms || []) {
      const row = mk("div", "dsx-iditem");
      const head = mk("div", "dsx-idline");
      head.append(idiomWords(it.text, o, "dsx-idtext"));
      if (it.inSentence) head.append(mk("span", "dsx-idin", " · in questa frase"));
      if (o.save) {
        const sv = btn(o.isSaved && o.isSaved(it) ? "★" : "☆", "Salva il modo di dire nel vocabolario", async (b) => {
          await o.save(it);
          if (b && b.isConnected) b.textContent = o.isSaved && o.isSaved(it) ? "★" : "☆";
        }, "dsx-btn dsx-idsave");
        head.append(sv);
      }
      row.append(head);
      if (it.meaning) row.append(mk("div", "dsx-idmean", it.meaning));
      if (it.example) row.append(mk("div", "dsx-idex dsx-muted", it.example));
      box.append(row);
    }
    const dict = (pn.dict || []).filter((t) => !(pn.idioms || []).some((it) => it.text.toLowerCase() === t.toLowerCase()));
    if (dict.length) {
      const d = mk("div", "dsx-iddict");
      d.append(mk("span", "dsx-muted", "Dal dizionario (Wiktionary): "));
      dict.slice(0, 16).forEach((t, i) => { if (i) d.append(document.createTextNode(" · ")); d.append(idiomWords(t, o, "dsx-idtext")); });
      box.append(d);
    }
    if (!pn.wait && !pn.error && !(pn.idioms || []).length && !dict.length) box.append(mk("div", "dsx-muted", pn.noLlm ? "Nel dizionario non ce ne sono: per cercarne altri serve un modello (chiave in 🔑 Servizi)." : "Non ne ho trovati."));
    else if (!pn.wait && pn.noLlm && (pn.dict || []).length) box.append(mk("div", "dsx-muted", "Per altri, con significato ed esempio, serve un modello (chiave in 🔑 Servizi)."));
    if (pn.source && !pn.wait) box.append(mk("div", "dsx-muted dsx-idsrc", "Modello: " + pn.source));
    return box;
  }

  function gwBox(ctx) {
    const st = ctx.st, g = st.gweb;
    const box = mk("div", "dsx-gw");
    if (!g || g.wait) { box.append(mk("span", "dsx-muted", "Dizionario di Google …")); return box; }
    const es = g.entries || [];
    // niente voci (o Google non risponde: il suo indirizzo non ufficiale cambia ogni tanto): il riquadro non compare.
    // Il motivo si legge nella console della pagina
    if (!es.length) { if (g.error || g.shape) console.debug("Dizionario di Google:", g.error || "nessuna voce (" + g.shape + ")"); return null; }
    const n = es.reduce((a, e) => a + e.groups.reduce((b, gr) => b + gr.senses.length, 0), 0);
    const head = btn((st.gwOpen ? "▾ " : "▸ ") + "📖 Dizionario di Google" + (n ? " · " + n + (n === 1 ? " significato" : " significati") : "") + (es.some((e) => e.origin) ? " · origine" : "") + (es.some((e) => e.tree) ? " · albero" : ""),
      "Il dizionario delle ricerche di Google (Oxford Languages): pronuncia, significati con esempi, sinonimi e contrari, forme, origine, uso nel tempo", () => { st.gwOpen = !st.gwOpen; ctx.rerender(); }, "dsx-gwhead");
    box.append(head);
    if (!st.gwOpen) return box;
    st.gwTr = st.gwTr || {};
    const trBtn = (text, key) => {
      const t = st.gwTr[key];
      if (t && t !== "…") return mk("div", "dsx-gwtrans", t);
      return btn(t === "…" ? "…" : "traduci", "Traduci nella tua lingua (Google, gratis)", async () => {
        st.gwTr[key] = "…"; ctx.rerender();
        st.gwTr[key] = (await quickTrans(text, g.corpus || ctx.lang, ctx.target)) || "—";
        if (!ctx.stale()) ctx.rerender();
      });
    };
    es.forEach((e, ei) => {
      const ent = mk("div", "dsx-gwentry");
      const hw = mk("div", "dsx-gwhw");
      hw.append(mk("b", null, e.headword || ctx.word));
      for (const ph of e.phonetics.slice(0, 2)) {
        if (ph.text) hw.append(mk("span", "dsx-muted", " /" + ph.text.replace(/^\/|\/$/g, "") + "/"));
        if (ph.audio) hw.append(btn("🔊", "Pronuncia registrata (dizionario di Google)", (el) => playUrl(ph.audio, el)));
      }
      ent.append(hw);
      e.groups.forEach((gr, gi) => {
        if (gr.pos) ent.append(mk("div", "dsx-gwpos", gr.pos));
        if (gr.forms.length) ent.append(mk("div", "dsx-muted dsx-gwforms", "Forme: " + gr.forms.map((f) => (f.type ? f.type + " " : "") + f.form).join(" · ")));
        const ol = mk("ol", "dsx-gwsenses");
        gr.senses.forEach((sn, si) => {
          const li = mk("li");
          if (sn.labels.length) li.append(mk("span", "dsx-muted", sn.labels.join(", ") + " · "));
          li.append(mk("span", "dsx-gwdef", sn.def), document.createTextNode(" "), trBtn(sn.def, `d${ei}.${gi}.${si}`));
          if (sn.ex) li.append(mk("div", "dsx-gwex", "«" + sn.ex + "»"));
          if (sn.syn.length) li.append(mk("div", "dsx-gwnyms", "Sinonimi: " + sn.syn.join(", ")));
          if (sn.ant.length) li.append(mk("div", "dsx-gwnyms", "Contrari: " + sn.ant.join(", ")));
          ol.append(li);
        });
        if (gr.senses.length) ent.append(ol);
      });
      if (e.origin) {
        const o = mk("div", "dsx-gworigin");
        o.append(mk("b", null, "Origine: "), document.createTextNode(e.origin + " "), trBtn(e.origin, `o${ei}`));
        ent.append(o);
      }
      if (e.tree) ent.append(gwTree(e.tree, st, ctx));
      box.append(ent);
    });
    const ngr = ngramRow(ctx);
    if (ngr) box.append(ngr);
    box.append(mk("div", "dsx-muted dsx-gwsrc", "Fonte: dizionario di Google (Oxford Languages)"));
    return box;
  }

  function load(ctx) {
    const st = ctx.st, p = ctx.prefs;
    if (st.learnStarted) return;
    st.learnStarted = true;
    setTimeout(() => {
      if (ctx.stale()) { st.learnStarted = false; return; }
      const done = () => { if (!ctx.stale()) ctx.rerender(); };
      const needWikt = p.etym !== false || p.learnAudio !== false || p.learnTable !== false || p.learnGender !== false || p.learnSpell !== false || p.gdDefs !== false;
      // la registrazione: se il Wiktionary inglese non l'ha per questa parola, la cerco nelle altre edizioni
      const moreAudio = () => {
        const exact = recordingInfo({ wikt: st.wikt }, ctx.word, p);
        if (p.learnAudio === false || st.audio2 || (exact && !exact.form) || !/^[a-z]{2,3}$/.test(String(ctx.lang || "").split("-")[0])) return;
        st.audio2 = { wait: true };
        DS_ETYM.audioOther(ctx.word, ctx.lang, ctx.target).then((r) => { st.audio2 = r || { audio: [] }; done(); }).catch(() => { st.audio2 = { audio: [] }; });
      };
      if (needWikt && !st.wikt) DS_ETYM.get(ctx.word, ctx.lang, ctx.target, ctx.lemma).then((r) => { st.wikt = r || { none: true }; done(); moreAudio(); });
      else if (st.wikt) moreAudio();
      // definizioni nella lingua della parola dal Wiktionary di quella lingua (gratis): per le parole non inglesi
      if (p.gdDefs !== false && !st.wdefs && typeof DS_ETYM.defsNative === "function" && /^[a-z]{2,3}$/.test(String(ctx.lang || "").split("-")[0]) && !/^en/.test(String(ctx.lang))) {
        st.wdefs = { wait: true, defs: [] };
        DS_ETYM.defsNative(ctx.word, ctx.lang).then((r) => { st.wdefs = r || { defs: [] }; done(); }).catch(() => { st.wdefs = { defs: [] }; done(); });
      }
      // dizionario di Google (Oxford): pronuncia, significati, sinonimi, forme, origine (gratis, una richiesta)
      if (GW_ON && p.learnGweb !== false && !st.gweb && GW_LANGS.test(String(ctx.lang || "").split("-")[0])) {
        st.gweb = { wait: true };
        const ask = (t) => DS_EXT.runtime.sendMessage({ type: "googleWebDict", word: t, lang: ctx.lang });
        ask(ctx.word).then((r) => (r && r.entries && !r.entries.length && ctx.lemma && ctx.lemma !== ctx.word ? ask(ctx.lemma) : r))
          .then((r) => { st.gweb = r && !r.error ? r : { entries: [], error: (r && r.error) || "" }; done(); })
          .catch((e) => { st.gweb = { entries: [], error: String(e.message || e) }; done(); });
      }
      if (p.learnNgram !== false && NGRAM_LANG.test(String(ctx.lang || ""))) ngramLoad(ctx, done);
      if (p.learnFreq !== false && st.freq === undefined) DS_FREQ.rank(ctx.word, ctx.lang).then((r) => { st.freq = r; done(); }).catch(() => { st.freq = null; done(); });
      if (p.learnExamples !== false && !st.examples) {
        const k = [ctx.lang, ctx.word.toLowerCase(), ctx.target].join("|");
        const have = exCache.get(k);
        (have ? Promise.resolve(have) : DS_EXT.runtime.sendMessage({ type: "tatoeba", word: ctx.word, lang: ctx.lang, target: ctx.target }))
          .then((r) => { if (r && !r.error) exCache.set(k, r); st.examples = r || { items: [] }; done(); })
          .catch((e) => { st.examples = { error: String(e.message || e) }; done(); });
      }
      // immagine per Anki (solo con l'opzione accesa): la vedi e la cambi prima di salvare
      if (p.ankiImage && !st.img && ctx.word) {
        st.img = { list: [], i: 0 };
        loadImages(st.img, ctx.lemma || ctx.word, ctx.lang, null, false, done);
      }
      if (p.learnJisho !== false && /^ja/.test(String(ctx.lang || "")) && !st.jisho) {
        DS_EXT.runtime.sendMessage({ type: "jisho", word: ctx.word }).then((r) => { st.jisho = r && !r.error ? r : { items: [], error: (r && r.error) || "" }; done(); })
          .catch((e) => { st.jisho = { items: [], error: String(e.message || e) }; done(); });
      }
      if (p.learnSpell !== false && !st.lt && ctx.sentence) {
        const k = ctx.lang + "|" + ctx.sentence;
        const have = ltCache.get(k);
        (have ? Promise.resolve(have) : DS_EXT.runtime.sendMessage({ type: "langtool", text: ctx.sentence, lang: ctx.lang }))
          .then((r) => { if (r && !r.error) ltCache.set(k, r); st.lt = r || {}; done(); })
          .catch(() => { st.lt = { error: true }; done(); });
      }
    }, 800);
  }

  // traduzione veloce con Google (gratis) di una parola o di una definizione
  const qtCache = new Map();
  async function quickTrans(text, from, to) {
    const k = [from, to, text].join("|");
    if (qtCache.has(k)) return qtCache.get(k);
    try {
      const r = await DS_EXT.runtime.sendMessage({ type: "translate", engine: "google", texts: [text], target: to, source: String(from || "").split("-")[0] });
      const t = (r && r.translations && r.translations[0]) || "";
      if (t) qtCache.set(k, t);
      return t;
    } catch { return ""; }
  }

  // parole da provare come lemma: quella del modello e i «vedi anche» del dizionario di Google
  function baseHints(ctx) {
    const gd = ctx.gdict || (ctx.st && ctx.st.gdict) || {};
    const g = ctx.st && ctx.st.gweb && ctx.st.gweb.entries ? ctx.st.gweb.entries.map((e) => e.headword) : [];
    return [ctx.lemma, ...g, ...((gd.related || []).slice(0, 6))].filter(Boolean);
  }
  // Parola madre dell'etimologia (подошве → подошва): sbagliata? Scrivi quella giusta, oppure «nessuna»; resta salvata
  function etymBaseBox(ctx, st, w) {
    const box = mk("div", "dsx-fix dsx-etymbase");
    box.append(mk("div", "dsx-muted", w.lemma ? `Etimologia presa dal lemma «${w.lemma}». È sbagliato? Scrivi quello giusto:` : `Scrivi il lemma di «${ctx.word}» (la forma del dizionario: l'infinito di un verbo, il nominativo di un nome…): l'etimologia si prende da lì.`));
    const t = mk("input", "dsx-input");
    t.value = w.lemma || "";
    t.addEventListener("keydown", (ev) => { ev.stopPropagation(); if (ev.key === "Enter") go(t.value); });
    t.addEventListener("keyup", (ev) => ev.stopPropagation());
    const go = async (b) => {
      st.etymWait = "b"; ctx.rerender();
      const r = await DS_ETYM.setBase(ctx.word, ctx.lang, ctx.target, b);
      st.etymWait = false; st.etymBaseEdit = false; st.etymFix = false;
      if (r && !r.error) st.wikt = r;
      if (!ctx.stale()) ctx.rerender();
    };
    box.append(t, btn(st.etymWait === "b" ? "…" : "salva", "Prendi l'etimologia da questa parola (resta salvato)", () => go(t.value), "dsx-known-on"));
    // 🔍 cerca radice su Wiktionary: le pagine che contengono questa forma; ✓ = la forma è nella sua tabella
    box.append(btn(st.baseSearch === "…" ? "…" : "🔍 cerca radice", "Cerca su Wiktionary le parole che hanno «" + ctx.word + "» tra le loro forme (declinazioni, coniugazioni)", async () => {
      if (st.baseSearch === "…") return;
      st.baseSearch = "…"; ctx.rerender();
      st.baseSearch = await DS_ETYM.searchBases(ctx.word, ctx.lang, baseHints(ctx));
      if (!ctx.stale()) ctx.rerender();
    }));
    const bs = st.baseSearch;
    if (bs && bs !== "…") {
      const list = mk("div", "dsx-baselist");
      if (bs.error) list.append(mk("div", "dsx-muted", "Wiktionary non risponde: " + bs.error));
      else if (!bs.list.length) list.append(mk("div", "dsx-muted", "Nessuna parola trovata. Scrivila tu qui sopra."));
      else {
        list.append(mk("div", "dsx-muted", "Scegli il lemma (✓ = «" + ctx.word + "» è nella sua tabella, quindi è sicura):"));
        for (const c of bs.list) {
          const b = btn((c.sure ? "✓ " : "") + c.title + (c.etym ? "" : " (senza etimologia)") + (c.model && !c.sure ? " (suggerita)" : !c.sure && c.near >= 0.5 ? " (stessa radice)" : ""),
            c.sure ? "«" + ctx.word + "» è una forma di questa parola" : "Questa pagina contiene «" + ctx.word + "», ma non nella tabella delle forme: controlla", () => go(c.title), c.sure ? "dsx-known-on" : "");
          list.append(b);
        }
      }
      box.append(list);
    }
    box.append(btn("nessuno: solo «" + ctx.word + "»", "Non cercare un lemma per questa parola", () => go("-")));
    if (w.baseMine) box.append(btn("scelta automatica", "Torna al lemma trovato da solo", () => go("")));
    setTimeout(() => t.focus(), 0);
    return box;
  }
  // Etymology Explorer (etymologyexplorer.com): la mappa delle origini, aperta sulla parola di cui la scheda mostra
  // l'etimologia (il lemma della pagina di Wiktionary). Indirizzo: /word/<lingua in inglese>/<parola>, es. /word/English/bread
  function etymExplorerUrl(ctx, w) {
    let word = "";
    try { if (w && w.url && w.url.includes("/wiki/")) word = decodeURIComponent(w.url.split("/wiki/")[1].split("#")[0]).replace(/_/g, " "); } catch {}
    word = word || (w && w.title) || ctx.word || "";
    const code = String(ctx.lang || "").split("-")[0];
    if (!word || !code) return "";
    let lang = "";
    try { lang = new Intl.DisplayNames(["en"], { type: "language" }).of(code) || ""; } catch {}
    if (!lang || lang.toLowerCase() === code) return "";
    return "https://etymologyexplorer.com/word/" + encodeURIComponent(lang) + "/" + encodeURIComponent(word);
  }
  // ⚑ sull'etimologia: originale inglese, rifarla con il modello, correggerla a mano (resta salvata)
  function etymFixBox(ctx, st, w) {
    const box = mk("div", "dsx-fix");
    const e = ctx.engine ? ctx.engine() : null;
    if (w.text && w.text !== w.trans) box.append(btn(st.etymOrig ? "nascondi l'originale" : "mostra l'originale (inglese)", "Il testo di Wiktionary prima della traduzione automatica", () => { st.etymOrig = !st.etymOrig; ctx.rerender(); }));
    if (w.text && w.text !== w.trans) box.append(btn(st.etymWait === "g" ? "…" : "ritraduci (Google)", "Una nuova traduzione automatica del testo di Wiktionary", async () => {
      if (st.etymWait) return;
      st.etymWait = "g"; ctx.rerender();
      const r = await DS_ETYM.retranslate(ctx.word, ctx.lang, ctx.target);
      st.etymWait = false;
      if (r && r.trans) { st.wikt = { ...st.wikt, ...r }; st.etymFix = false; }
      if (!ctx.stale()) ctx.rerender();
    }));
    if (e) box.append(btn(st.etymWait ? "…" : "rifai con " + (e.name || "il modello"), "Una richiesta al modello: etimologia scritta direttamente nella tua lingua; resta salvata", async () => {
      if (st.etymWait) return;
      st.etymWait = true; ctx.rerender();
      const r = await DS_ETYM.fromModel(e, ctx.word, ctx.lang, ctx.target, ctx.sentence);
      st.etymWait = false;
      if (r && !r.error) { st.wikt = { ...st.wikt, ...r }; st.etymFix = false; }
      else st.etymErr = (r && r.error) || "nessuna risposta";
      if (!ctx.stale()) ctx.rerender();
    }));
    box.append(btn("✎ correggi a mano", "Scrivi tu l'etimologia giusta: resta salvata", () => { st.etymEdit = !st.etymEdit; ctx.rerender(); }));
    box.append(btn(w.lemma ? "lemma sbagliato?" : "prendila dal lemma…", "L'etimologia viene dal lemma (la forma del dizionario): sceglilo tu", () => { st.etymBaseEdit = !st.etymBaseEdit; ctx.rerender(); }));
    if (w.fixed) box.append(btn("togli la correzione", "Torna all'etimologia di Wiktionary", () => { st.wikt = { ...st.wikt, ...DS_ETYM.override(ctx.word, ctx.lang, ctx.target, "") }; st.etymFix = false; ctx.rerender(); }));
    if (st.etymErr) box.append(mk("div", "dsx-muted", "Non riesco: " + st.etymErr));
    if (st.etymEdit) {
      const t = mk("textarea", "dsx-input");
      t.rows = 3; t.value = w.trans || "";
      t.addEventListener("keydown", (ev) => ev.stopPropagation());
      t.addEventListener("keyup", (ev) => ev.stopPropagation());
      box.append(t, btn("salva", "", () => {
        st.wikt = { ...st.wikt, ...DS_ETYM.override(ctx.word, ctx.lang, ctx.target, t.value) };
        st.etymEdit = false; st.etymFix = false; ctx.rerender();
      }, "dsx-known-on"));
      setTimeout(() => t.focus(), 0);
    }
    return box;
  }

  // ctx: { word, lemma, lang, target, sentence, prefs, llm, st, rerender, stale, speak(text, lang, rate), etymHint, engine() }
  // ---------- Kanji e caratteri cinesi uno per uno (si impara anche il singolo carattere, non solo la parola) ----------
  // Prima si apre la parola intera (come per le altre lingue); nella scheda ogni carattere si può isolare con un clic.
  const HAN = /\p{Script=Han}/u;
  const hanChars = (w) => [...new Set(Array.from(String(w || "")).filter((c) => HAN.test(c)))];
  const hanName = (lang) => (/^ja/.test(lang) ? "Kanji" : /^ko/.test(lang) ? "Hanja" : "Caratteri");
  function hanLoad(ctx, ch) {
    const st = ctx.st;
    st.han = st.han || {};
    if (st.han[ch]) return;
    st.han[ch] = { wait: true };
    DS_EXT.runtime.sendMessage({ type: "hanChar", ch, lang: ctx.lang, target: ctx.target })
      .then((r) => { st.han[ch] = r || { error: "nessuna risposta" }; if (!ctx.stale()) ctx.rerender(); })
      .catch((e) => { st.han[ch] = { error: String(e.message || e) }; if (!ctx.stale()) ctx.rerender(); });
  }
  const GRADE = { 1: "1ª elementare", 2: "2ª elementare", 3: "3ª elementare", 4: "4ª elementare", 5: "5ª elementare", 6: "6ª elementare", 8: "jōyō (scuole medie)", 9: "jinmeiyō (nomi di persona)", 10: "jinmeiyō (nomi di persona)" };
  // letture del carattere in ogni lingua: prima quella del testo, poi le altre (stesse informazioni per tutte)
  function hanReadings(h, lang) {
    const L = [
      ["ja", "giapponese", [h.on && h.on.length ? "on " + h.on.join("、") : "", h.kun && h.kun.length ? "kun " + h.kun.join("、") : ""].filter(Boolean).join(" · "),
        "on = lettura di origine cinese (di solito nelle parole di più kanji); kun = lettura giapponese (di solito con il kanji da solo o seguito da kana; il punto separa la parte in kana)"],
      ["zh", "cinese", h.py ? h.py.split(" ").join(", ") : "", "Lettura in mandarino, con i toni"],
      ["yue", "cantonese", h.yue ? h.yue.split(" ").join(", ") : "", "Lettura in cantonese (jyutping: il numero è il tono)"],
      ["ko", "coreano", h.ko || "", "Lettura dell'hanja in coreano (hangul)"],
      ["vi", "vietnamita", h.vi || "", "Lettura sino-vietnamita"]
    ].filter((x) => x[2]);
    const first = lang === "zh" && /yue|hk|mo/i.test(String(h.langFull || "")) ? "yue" : lang;
    L.sort((x, y) => (y[0] === first) - (x[0] === first));
    return L;
  }
  // voce del vocabolario per un solo carattere (significato, letture, tratti, parti, livelli)
  function hanEntry(h, ch, lang) {
    const rd = hanReadings(h, lang).map((x) => x[1] + ": " + x[2]);
    const lv = [h.strokes ? h.strokes + " tratti" : "", h.jlpt ? "JLPT N" + h.jlpt : "", h.grade && GRADE[h.grade] ? GRADE[h.grade] : "",
      h.hsk ? "HSK " + (h.hsk >= 7 ? "7-9" : h.hsk) : "", h.koe ? "hanja scolastico" : ""].filter(Boolean);
    const parts = (h.parts || []).map((x) => x.ch + " " + (x.defTr || x.def)).join(" + ");
    const meaning = [h.meaning, lang === "ja" && h.jm ? (h.jmTr || h.jm) : (h.defTr || h.def)].filter(Boolean)
      .filter((x, i, a) => a.findIndex((y) => y.toLowerCase() === x.toLowerCase()) === i).join("; ");
    return { word: ch, lemma: "", pos: lang === "ja" ? "kanji" : lang === "ko" ? "hanja" : "carattere", meaning, lang,
      explanation: [rd.join(" · "), parts ? "parti: " + parts : "", h.radical ? "radicale: " + h.radical.ch + " " + (h.radical.defTr || h.radical.def) : "", lv.join(", ")].filter(Boolean).join(" — "),
      translit: lang === "zh" ? h.py || "" : "" };
  }
  async function hanInfo(ctx, ch) {
    const st = ctx.st;
    st.han = st.han || {};
    if (st.han[ch] && !st.han[ch].wait && !st.han[ch].error) return st.han[ch];
    const r = await DS_EXT.runtime.sendMessage({ type: "hanChar", ch, lang: ctx.lang, target: ctx.target }).catch(() => null);
    if (r && !r.error) st.han[ch] = r;
    return r && !r.error ? r : null;
  }

  function hanBox(ctx) {
    const st = ctx.st, lang = String(ctx.lang || "").split("-")[0];
    const chars = hanChars(ctx.word);
    const single = Array.from(String(ctx.word).trim()).length === 1;
    if (!chars.length) return null;
    const wrap = mk("div", "dsx-han");
    if (single && !st.hanSel) st.hanSel = chars[0];
    // un carattere porta a un altro (parti, radicale, forma semplificata/tradizionale): si può tornare indietro
    const go = (ch) => { if (ch === st.hanSel) return; st.hanBack = (st.hanBack || []).concat(st.hanSel ? [st.hanSel] : []).slice(-8); st.hanSel = ch; hanLoad(ctx, ch); ctx.rerender(); };
    const chip = (ch, title, extra) => btn(ch, title, () => go(ch), "dsx-hanchip dsx-hanmini" + (extra || ""));
    if (!single) {
      const row = mk("div", "dsx-hanrow");
      row.append(mk("b", null, hanName(lang) + " uno per uno: "));
      for (const ch of chars) {
        const known = DS_KNOWN.has(lang, ch);
        row.append(btn(ch + (known ? "✓" : ""), `Solo «${ch}»: significato, letture, tratti, parti` + (known ? " (lo conosci)" : ""),
          () => { st.hanBack = []; st.hanSel = st.hanSel === ch ? "" : ch; if (st.hanSel) hanLoad(ctx, ch); ctx.rerender(); },
          "dsx-hanchip" + (st.hanSel === ch ? " dsx-on" : "") + (known ? " dsx-known-on" : "")));
      }
      // tutti i caratteri della parola nel vocabolario, ognuno come voce a sé (quelli già salvati restano come sono)
      if (ctx.saveChars) {
        const all = chars.every((c) => ctx.isSaved && ctx.isSaved(lang, c));
        row.append(btn(st.hanSaving ? "…" : all ? "★ tutti salvati" : "☆ salva tutti i " + (lang === "ja" ? "kanji" : "caratteri"),
          all ? "Tutti i caratteri di questa parola sono già nel vocabolario" : "Salva nel vocabolario ogni carattere di questa parola, come voce a sé (significato, letture, tratti, parti)",
          async () => {
            if (all || st.hanSaving) return;
            st.hanSaving = true; ctx.rerender();
            const entries = [];
            for (const c of chars) { const h = await hanInfo(ctx, c); if (h) entries.push(hanEntry(h, c, lang)); }
            await ctx.saveChars(entries, false);
            st.hanSaving = false;
            if (!ctx.stale()) ctx.rerender();
          }, "dsx-mini dsx-hansave" + (all ? " dsx-known-on" : "")));
      }
      wrap.append(row);
    }
    const ch = st.hanSel;
    if (!ch) return wrap;
    hanLoad(ctx, ch);
    const h = st.han[ch] || { wait: true };
    const panel = mk("div", "dsx-hanpanel");
    if (st.hanBack && st.hanBack.length) {
      const prev = st.hanBack[st.hanBack.length - 1];
      panel.append(btn("‹ " + prev, "Torna al carattere di prima", () => { st.hanSel = st.hanBack.pop(); ctx.rerender(); }, "dsx-mini"));
    }
    const top = mk("div", "dsx-hantop");
    top.append(mk("span", "dsx-hanbig", ch));
    const info = mk("div", "dsx-haninfo");
    if (h.wait) info.append(mk("span", "dsx-muted", "Cerco il carattere…"));
    else if (h.error) info.append(mk("span", "dsx-muted", "Non trovo informazioni su questo carattere: " + h.error));
    else {
      const line = (label, content, title) => {
        if (!content) return null;
        const d = mk("div", "dsx-hanline");
        d.append(mk("b", null, label + ": "));
        if (typeof content === "string") d.append(document.createTextNode(content)); else d.append(...content);
        if (title) d.title = title;
        info.append(d);
        return d;
      };
      // significato: Google con il carattere da solo (nella tua lingua) e il dizionario dei caratteri (tradotto)
      const gm = [h.meaning, ...(h.alt || [])].filter(Boolean).join(", ");
      const dictM = lang === "ja" && h.jm ? (h.jmTr || h.jm) : (h.defTr || h.def);
      if (gm && (!single || !dictM)) line("Significato", gm, "Google, con il carattere da solo");
      if (dictM) line(lang === "ja" && h.jm ? "Come kanji" : "Nel dizionario", dictM, "Dizionario dei caratteri (" + (lang === "ja" && h.jm ? "KANJIDIC" : "Unihan") + "), in inglese: " + (lang === "ja" && h.jm ? h.jm : h.def));
      const rd = hanReadings({ ...h, langFull: ctx.lang }, lang);
      const mine = rd.length && (rd[0][0] === lang || (lang === "zh" && rd[0][0] === "yue")) ? rd[0] : null;
      if (mine) line("Lettura (" + (mine[0] === "zh" ? "pinyin" : mine[1]) + ")", mine[2], mine[3]);
      else if (h.reading) line("Lettura", h.reading, "Google");
      const others = rd.filter((x) => x !== mine);
      if (others.length) line(mine ? "Nelle altre lingue" : "Letture", others.map((x) => x[1] + " " + x[2]).join(" · "),
        "Lo stesso carattere si usa (o si usava) in cinese, giapponese, coreano e vietnamita, con letture diverse");
      // parti del carattere e radicale: ognuno si apre con un clic
      if (h.parts && h.parts.length) {
        const bits = [];
        h.parts.forEach((x, i) => { if (i) bits.push(document.createTextNode(" + ")); bits.push(chip(x.ch, (x.py ? x.py + " — " : "") + (x.defTr || x.def)), document.createTextNode(" " + (x.defTr || x.def))); });
        line("Parti", bits, "Come è composto il carattere (scomposizione di BabelStone)");
      }
      if (h.radical) line("Radicale", [chip(h.radical.ch, "Radicale n. " + h.radical.n), document.createTextNode(" " + (h.radical.defTr || h.radical.def) + " (n. " + h.radical.n + " di 214)")],
        "Il radicale è la parte con cui il carattere si cerca nei dizionari; spesso indica l'area di significato");
      const vars = [];
      if (h.sv) vars.push(document.createTextNode("semplificato "), ...Array.from(h.sv).map((x) => chip(x, "Forma semplificata (Cina continentale, Singapore)")));
      if (h.tv) vars.push(document.createTextNode((vars.length ? " · " : "") + "tradizionale "), ...Array.from(h.tv).map((x) => chip(x, "Forma tradizionale (Taiwan, Hong Kong; spesso anche il kanji giapponese)")));
      if (vars.length) line("Altre forme", vars);
      const b = mk("div", "dsx-badges");
      // ogni distintivo si apre: la pagina "Kanji e caratteri" a quel livello (con questo carattere evidenziato)
      const open = (sys, level) => () => DS_EXT.runtime.sendMessage({ type: "openKanji", sys, level: String(level), ch, lang, target: ctx.target }).catch(() => {});
      const badge = (text, title, cls, fn) => fn ? btn(text + " ›", title, fn, "dsx-badge dsx-freqbtn" + (cls ? " " + cls : "")) : (() => { const x = mk("span", "dsx-badge" + (cls ? " " + cls : ""), text); if (title) x.title = title; return x; })();
      const lv = [];
      // tratti: l'animazione dell'ordine dei tratti, qui nella scheda (Wikimedia Commons)
      if (h.strokes) lv.push(["*", btn(h.strokes + " tratti " + (st.hanOrder && st.hanOrder[ch] ? "▴" : "✍"), "Mostra l'ordine dei tratti (animazione)", () => {
        st.hanOrder = st.hanOrder || {};
        if (st.hanOrder[ch]) { st.hanOrder[ch] = null; ctx.rerender(); return; }
        st.hanOrder[ch] = { wait: true }; ctx.rerender();
        (async () => {
          for (const name of [ch + "-order.gif", ch + "-red.png", ch + "-bw.png"]) {
            const r = await DS_EXT.runtime.sendMessage({ type: "fetchB64", url: "https://commons.wikimedia.org/wiki/Special:FilePath/" + encodeURIComponent(name) }).catch(() => null);
            if (r && r.b64) { st.hanOrder[ch] = { src: "data:" + (/\.gif$/.test(name) ? "image/gif" : "image/png") + ";base64," + r.b64 }; if (!ctx.stale()) ctx.rerender(); return; }
          }
          st.hanOrder[ch] = { none: true }; if (!ctx.stale()) ctx.rerender();
        })();
      }, "dsx-badge dsx-freqbtn")]);
      if (h.jlpt) lv.push(["ja", badge("JLPT N" + h.jlpt, "Livello del kanji nel JLPT (N5 il più facile, N1 il più difficile): apri tutti i kanji di questo livello", "dsx-jlpt", open("jlpt", h.jlpt))]);
      if (h.grade && GRADE[h.grade]) lv.push(["ja", badge(GRADE[h.grade], "Quando si studia nelle scuole giapponesi: apri tutti i kanji di questa classe", h.grade <= 6 ? "dsx-common" : "", open("grade", h.grade === 10 ? 9 : h.grade))]);
      else if (h.joyo) lv.push(["ja", badge("jōyō", "Tra i kanji di uso comune in Giappone")]);
      if (h.freq) lv.push(["ja", badge("n. " + h.freq + " in Giappone", "Posizione tra i kanji più usati nei giornali giapponesi: apri l'elenco", "", open("freq", [1, 501, 1001, 1501, 2001].filter((x) => h.freq >= x).pop()))]);
      if (h.hsk) lv.push(["zh", badge("HSK " + (h.hsk >= 7 ? "7-9" : h.hsk), "Livello del carattere nell'esame di cinese HSK 3.0: apri tutti i caratteri di questo livello", "dsx-jlpt", open("hsk", h.hsk))]);
      if (h.tg) lv.push(["zh", badge(h.tg === 1 ? "comune in Cina" : h.tg === 2 ? "meno comune in Cina" : "raro in Cina", "Lista ufficiale cinese dei caratteri di uso comune (通用规范汉字表): apri l'elenco", h.tg === 1 ? "dsx-common" : "", open("tg", h.tg))]);
      if (h.koe) lv.push(["ko", badge("hanja scolastico", "Tra i 1800 hanja delle scuole coreane: apri l'elenco", "", open("koe", 1))]);
      if (h.radical) lv.push(["*", badge("radicale " + h.radical.ch, "Tutti i caratteri con questo radicale", "", open("radical", h.radical.n))]);
      lv.sort((x, y) => (y[0] === "*") - (x[0] === "*") || (y[0] === lang) - (x[0] === lang));
      for (const [, x] of lv) b.append(x);
      if (b.childNodes.length) info.append(b);
      const ord = st.hanOrder && st.hanOrder[ch];
      if (ord && ord.src) { const im = mk("img", "dsx-hanorder"); im.src = ord.src; im.alt = "Ordine dei tratti di " + ch; info.append(im); }
      else if (ord && ord.wait) info.append(mk("div", "dsx-muted dsx-small", "Cerco l'ordine dei tratti…"));
      else if (ord && ord.none) info.append(mk("div", "dsx-muted dsx-small", "Ordine dei tratti non disponibile per questo carattere (prova Jisho o Wiktionary)."));
    }
    top.append(info);
    panel.append(top);
    const tools = mk("div", "dsx-tools");
    if (ctx.speak) tools.append(btn("🔈", "Ascolta (voce sintetica: da solo un carattere può avere più letture)", () => ctx.speak(ch, ctx.lang)));
    const known = DS_KNOWN.has(lang, ch);
    if (!single || ch !== chars[0]) tools.append(btn(known ? "✓ lo conosco" : "lo conosco?", known ? "Togli dai caratteri che conosci" : "Segna questo carattere come conosciuto",
      () => { DS_KNOWN.set(lang, ch, !known); ctx.rerender(); if (ctx.onKnown) ctx.onKnown(); }, known ? "dsx-known-on" : ""));
    if (ctx.saveChars && !h.wait && !h.error && (!single || ch !== chars[0])) {
      const on = ctx.isSaved && ctx.isSaved(lang, ch);
      tools.append(btn(on ? "★ salvato" : "☆ salva " + (lang === "ja" ? "il kanji" : "il carattere"), on ? "Togli questo carattere dal vocabolario" : "Salva solo questo carattere nel vocabolario (con significato, letture, tratti e parti)",
        async () => { await ctx.saveChars([hanEntry(h, ch, lang)], true); if (!ctx.stale()) ctx.rerender(); }, on ? "dsx-known-on" : ""));
    }
    if (ctx.openWord && (!single || ch !== chars[0])) tools.append(btn("scheda del carattere ›", `Apri «${ch}» come una parola: esempi, etimologia, salvataggio nel vocabolario e in Anki`, () => ctx.openWord(ch, h && !h.wait && !h.error ? hanEntry(h, ch, lang) : null)));
    const link = (label, href, title) => { const a = mk("a", "dsx-link", label); a.href = href; a.target = "_blank"; a.rel = "noopener noreferrer"; if (title) a.title = title; tools.append(a); };
    const q = encodeURIComponent(ch);
    if (lang === "ja") {
      link("Jisho", "https://jisho.org/search/" + q + "%20%23kanji", "Scheda del kanji su Jisho: radicale, parti, ordine dei tratti");
      link("parole con " + ch, "https://jisho.org/search/*" + q + "*", "Parole che contengono questo kanji (Jisho)");
    } else if (lang === "ko") link("Naver hanja", "https://hanja.dict.naver.com/#/search?query=" + q, "Dizionario degli hanja di Naver");
    else link("MDBG", "https://www.mdbg.net/chinese/dictionary?page=chardict&cdqchi=" + q, "Dizionario cinese MDBG: carattere, parole con il carattere, ordine dei tratti");
    link("Wiktionary", "https://en.wiktionary.org/wiki/" + q, "Wiktionary (inglese): origine, ordine dei tratti, letture in tutte le lingue");
    tools.append(btn("tutti i " + (lang === "ja" ? "kanji" : "caratteri") + " ›", "Apri la pagina «Kanji e caratteri»: tutti i caratteri per livello, con quelli che conosci", () => {
      const e = st.han[ch] || {};
      const sys = lang === "ja" ? (e.jlpt ? "jlpt" : e.grade ? "grade" : "strokes") : lang === "ko" ? (e.koe ? "koe" : "strokes") : (e.hsk ? "hsk" : e.tg ? "tg" : "strokes");
      const level = sys === "jlpt" ? e.jlpt : sys === "grade" ? (e.grade === 10 ? 9 : e.grade) : sys === "koe" ? 1 : sys === "hsk" ? e.hsk : sys === "tg" ? e.tg : Math.min(24, e.strokes || 1);
      DS_EXT.runtime.sendMessage({ type: "openKanji", sys, level: String(level || ""), ch, lang, target: ctx.target }).catch(() => {});
    }));
    panel.append(tools);
    // 1.6.2: ✨ il carattere spiegato dal modello (una richiesta, solo quando lo premi; resta salvato)
    const eng = ctx.engine ? ctx.engine() : null;
    st.hanLlm = st.hanLlm || {};
    const hl = st.hanLlm[ch];
    if (eng && !hl) {
      panel.append(btn("✨ Spiega " + (lang === "ja" ? "il kanji" : "il carattere") + " con " + eng.name + (eng.model ? " · " + eng.model : ""),
        "Una richiesta al modello: significati, letture, parole comuni che lo contengono, come è fatto, un aiuto per ricordarlo e l'origine del segno. Resta salvata",
        () => hanAsk(ctx, ch, lang), "dsx-btn dsx-hanask"));
    }
    if (hl && hl.wait) panel.append(mk("div", "dsx-muted", "Chiedo al modello…"));
    else if (hl && hl.error) panel.append(mk("div", "dsx-muted", "Spiegazione non disponibile: " + hl.error));
    else if (hl) {
      const box = mk("div", "dsx-hanllm");
      const line = (label, text) => { if (!text) return; const d = mk("div", "dsx-hanline"); d.append(mk("b", null, label + ": "), document.createTextNode(text)); box.append(d); };
      line("Significato", hl.meaning);
      line("Letture", hl.readings);
      if (hl.words && hl.words.length) {
        const d = mk("div", "dsx-hanline"); d.append(mk("b", null, "Parole comuni: "));
        hl.words.forEach((x, i) => { if (i) d.append(document.createTextNode(" · ")); d.append(mk("span", "dsx-hanword", x.w), document.createTextNode((x.r ? " (" + x.r + ")" : "") + (x.t ? " " + x.t : ""))); });
        box.append(d);
      }
      line("Come è fatto", hl.parts);
      line("Per ricordarlo", hl.mnemonic);
      line("Origine", hl.origin);
      line("Attenzione", hl.note);
      box.append(mk("div", "dsx-muted dsx-small", "Fonte: " + hl.source));
      panel.append(box);
    }
    if (h.sources && h.sources.length) panel.append(mk("div", "dsx-muted dsx-small", "Fonte: " + h.sources.join(", ")));
    wrap.append(panel);
    return wrap;
  }
  async function hanAsk(ctx, ch, lang, tries = 0) {
    const st = ctx.st, e = ctx.engine ? ctx.engine() : null;
    if (!e) return;
    st.hanLlm = st.hanLlm || {};
    st.hanLlm[ch] = { wait: true }; ctx.rerender();
    let r;
    try {
      r = await dsSendLong({ type: "hanExplain", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, ch, lang, target: ctx.target, word: ctx.word, sentence: ctx.sentence || "" });
    } catch (err) { r = { error: String(err.message || err) }; }
    // finite le richieste di oggi con quel modello: il prossimo modello o servizio (come per le spiegazioni)
    if (r && r.error && r.daily && ctx.onLlmDaily && tries < 4) { ctx.onLlmDaily(e); return hanAsk(ctx, ch, lang, tries + 1); }
    st.hanLlm[ch] = r && !r.error ? r : { error: (r && r.error) || "nessuna risposta" };
    if (!ctx.stale()) ctx.rerender();
  }

  function render(ctx) {
    const p = ctx.prefs || {}, st = ctx.st, llm = ctx.llm || null;
    const box = mk("div", "dsx");
    load(ctx);
    const w = st.wikt;

    // 1. frequenza, genere, "la so"
    const badges = mk("div", "dsx-badges");
    if (p.learnFreq !== false) {
      if (st.freq === undefined) badges.append(mk("span", "dsx-badge dsx-muted", "frequenza …"));
      else if (st.freq !== null) {
        // cliccando: l'elenco delle parole più usate della lingua, con la posizione di questa parola
        const b = btn(DS_FREQ.label(st.freq) + " ›", "Apri l'elenco delle parole più usate in questa lingua, con la posizione di questa parola",
          () => DS_EXT.runtime.sendMessage({ type: "openFreq", lang: ctx.lang, word: ctx.word, target: ctx.target }).catch(() => {}),
          "dsx-badge dsx-freq dsx-freqbtn" + (st.freq && st.freq <= 5000 ? " dsx-common" : ""));
        badges.append(b);
        // livello indicativo (A1…C2, solo dalla frequenza): apre l'elenco a quel livello
        const lv = typeof dsLevelOf === "function" && dsLevelOf(st.freq);
        if (lv) badges.append(btn("livello ≈ " + lv.id + " ›", `Livello indicativo dalla frequenza (parole n. ${lv.from}–${lv.to}). Apri le parole di questo livello`,
          () => DS_EXT.runtime.sendMessage({ type: "openFreq", lang: ctx.lang, target: ctx.target, level: lv.id }).catch(() => {}), "dsx-badge dsx-freqbtn dsx-level"));
      }
    }
    if (p.learnGender !== false && w && w.gender) {
      const g = genderInfo(w.gender, ctx.lang);
      if (g) badges.append(mk("span", "dsx-badge " + g.cls, g.text));
    }
    if (p.learnKnown !== false) {
      const known = DS_KNOWN.has(ctx.lang, ctx.word);
      badges.append(btn(known ? "✓ la conosco" : "la conosco?", known ? "Togli dalle parole che conosci" : "Segna come parola che conosci (conta nella percentuale e viene colorata)",
        () => { DS_KNOWN.set(ctx.lang, ctx.word, !known); ctx.rerender(); if (ctx.onKnown) ctx.onKnown(); }, known ? "dsx-known-on" : ""));
    }
    if (badges.childNodes.length) box.append(badges);

    // giapponese: lettura, livello JLPT e significato dal dizionario Jisho (gratis)
    if (p.learnJisho !== false && /^ja/.test(String(ctx.lang || ""))) {
      const j = st.jisho, it = j && j.items && j.items[0];
      const row = mk("div", "dsx-jisho");
      if (!j) row.append(mk("span", "dsx-muted", "Jisho …"));
      else if (!it) row.append(mk("span", "dsx-muted", j.error ? "Jisho non disponibile" : "Non trovata su Jisho"));
      else {
        const b2 = mk("div", "dsx-badges");
        if (it.reading && it.reading !== ctx.word) b2.append(mk("span", "dsx-badge dsx-common", "lettura: " + it.reading));
        // livello JLPT: apre l'elenco delle parole di quel livello (Jisho)
        if (it.jlpt && it.jlpt.length) b2.append(btn("JLPT " + it.jlpt[0] + " ›", "Apri le parole del livello " + it.jlpt[0] + " del JLPT, con questa parola",
          () => DS_EXT.runtime.sendMessage({ type: "openJlpt", level: it.jlpt[0], word: it.word || ctx.word, target: ctx.target }).catch(() => {}), "dsx-badge dsx-freqbtn dsx-jlpt"));
        if (it.common) b2.append(mk("span", "dsx-badge", "parola comune"));
        row.append(b2);
        if (it.meanings && it.meanings.length) {
          const m = mk("div", "dsx-muted");
          m.textContent = "Jisho (inglese): " + it.meanings.join(", ") + (it.pos && it.pos.length ? " — " + it.pos.join(", ") : "") + (it.word && it.word !== ctx.word ? " · voce: " + it.word : "");
          row.append(m);
        }
      }
      box.append(row);
    }

    // kanji e caratteri cinesi: ogni carattere si può isolare (per impararli anche uno per uno)
    if (p.learnHan !== false) { const hb = hanBox(ctx); if (hb) box.append(hb); }

    // dizionario di Google (arriva con la traduzione della parola, nessuna richiesta in più)
    const gd = ctx.gdict;
    if (gd) {
      const lname = (() => { try { return new Intl.DisplayNames([dsUiLocale()], { type: "language" }).of(String(ctx.lang || "").split("-")[0]) || ""; } catch { return ""; } })();
      if (p.gdAlt !== false && gd.alt && gd.alt.length) {
        const d = mk("div", "dsx-gd dsx-alt");
        d.append(mk("b", null, "Traduzioni: "));
        for (const g of gd.alt.slice(0, 3)) {
          const grp = mk("span", "dsx-altgrp");
          if (g.pos) grp.append(mk("span", "dsx-muted", g.pos + " "));
          g.items.slice(0, 5).forEach((it, i) => {
            const w = mk("span", "dsx-altw" + (i === 0 && it.score >= 0.05 ? " dsx-main" : ""), it.word);
            const bar = mk("span", "dsx-bar");
            bar.style.width = Math.max(3, Math.round(Math.min(1, it.score || 0) * 28)) + "px";
            w.append(bar);
            w.title = (it.rev.length ? "Al contrario: " + it.rev.join(", ") : "") + (it.score ? (it.rev.length ? " · " : "") + "uso: " + (it.score >= 0.1 ? "comune" : it.score >= 0.01 ? "meno comune" : "raro") : "");
            grp.append(w);
          });
          d.append(grp);
        }
        box.append(d);
      }
      if (p.gdSyn !== false && ((gd.syn && gd.syn.length) || (gd.related && gd.related.length))) {
        const d = mk("div", "dsx-gd");
        // parole cliccabili: la loro traduzione compare qui sotto (Google, gratis), con 🔈 e Wiktionary
        const wordsRow = (list) => {
          const span = mk("span");
          list.forEach((w, i) => {
            if (i) span.append(document.createTextNode(", "));
            const a = btn(w, "Traduci «" + w + "»", async () => {
              if (st.peek && st.peek.word === w) { st.peek = null; ctx.rerender(); return; }
              st.peek = { word: w, trans: null }; ctx.rerender();
              const t = await quickTrans(w, ctx.lang, ctx.target);
              if (st.peek && st.peek.word === w) { st.peek.trans = t || "—"; if (!ctx.stale()) ctx.rerender(); }
            }, "dsx-wordlink" + (st.peek && st.peek.word === w ? " dsx-on" : ""));
            span.append(a);
          });
          return span;
        };
        if (gd.syn && gd.syn.length) { d.append(mk("b", null, "Sinonimi: ")); d.append(wordsRow(gd.syn.slice(0, 2).flatMap((g) => g.words.slice(0, 6)))); }
        if (gd.related && gd.related.length) { if (gd.syn && gd.syn.length) d.append(mk("br")); d.append(mk("b", null, "Vedi anche: ")); d.append(wordsRow(gd.related.slice(0, 6))); }
        if (st.peek) {
          const pk = mk("div", "dsx-peek");
          pk.append(mk("b", null, st.peek.word), document.createTextNode(" = " + (st.peek.trans === null ? "…" : st.peek.trans) + " "));
          pk.append(btn("🔈", "Ascolta (voce sintetica)", () => ctx.speak && ctx.speak(st.peek.word, ctx.lang)));
          const a = mk("a", "dsx-link", "Wiktionary"); a.href = "https://en.wiktionary.org/wiki/" + encodeURIComponent(st.peek.word); a.target = "_blank"; a.rel = "noopener noreferrer";
          pk.append(document.createTextNode(" "), a);
          d.append(pk);
        }
        box.append(d);
      }
    }

    // definizioni: Google (nella lingua della parola, quando c'è), poi Wiktionary nella lingua della parola, poi
    // Wiktionary inglese. Tutto gratis, ognuna con "traduci" (Google). Le prime 3, le altre con "altre".
    if (p.gdDefs !== false) {
      const lname = (code) => { try { return new Intl.DisplayNames([dsUiLocale()], { type: "language" }).of(String(code || "").split("-")[0]) || ""; } catch { return ""; } };
      const isEn = /^en/.test(String(ctx.lang || ""));
      const groups = [];
      const seen = new Set();
      const push = (list, source, from, url) => {
        for (const g of list || []) {
          const items = (g.items || []).filter((it) => { const k = it.def.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim(); if (!k || seen.has(k)) return false; seen.add(k); return true; });
          if (items.length) groups.push({ pos: g.pos || "", items, source, from, url });
        }
      };
      if (gd && gd.defs) push(gd.defs, "Google", ctx.lang);
      const wd = st.wdefs;
      if (wd && wd.defs) push(wd.defs, "Wiktionary", ctx.lang, wd.url);
      const english = !groups.length || isEn;   // le definizioni inglesi: per l'inglese, o se mancano le altre
      if (english && w && w.defs) push(w.defs, "Wiktionary", "en", w.url);
      const waiting = (!w || (wd && wd.wait)) && !groups.length;
      if (groups.length || waiting) {
        const d = mk("div", "dsx-gd dsx-defs");
        const inEn = groups.length && groups.every((g) => g.from === "en") && !isEn;
        const ln = lname(inEn ? "en" : ctx.lang);
        const srcs = [...new Set(groups.map((g) => g.source))];
        d.append(mk("b", null, "Definizioni" + (ln ? " in " + ln : "") + ": "));
        if (srcs.length) d.append(mk("span", "dsx-muted", "(" + srcs.join(" e ") + ") "));
        if (waiting) d.append(mk("span", "dsx-muted", "…"));
        st.defTr = st.defTr || {};
        const all = [];
        for (const g of groups) for (const it of g.items) all.push({ g, it });
        const max = st.defsAll ? 10 : 3;
        let lastPos = null;
        for (const { g, it } of all.slice(0, max)) {
          const li = mk("div", "dsx-def");
          if (g.pos && g.pos !== lastPos) li.append(mk("span", "dsx-muted", g.pos + " · "));
          lastPos = g.pos;
          li.append(document.createTextNode(it.def + " "));
          // traduzione della definizione nella tua lingua (Google, gratis), solo se la chiedi
          const k = it.def;
          const tr = st.defTr[k];
          if (String(g.from).split("-")[0] !== String(ctx.target).split("-")[0]) {
            li.append(btn(tr === undefined ? "traduci" : tr === null ? "…" : "nascondi", "Traduci la definizione nella tua lingua (Google, gratis)", async () => {
              if (tr) { delete st.defTr[k]; ctx.rerender(); return; }
              if (tr === null) return;
              st.defTr[k] = null; ctx.rerender();
              st.defTr[k] = await quickTrans(it.def + (it.ex ? "\n" + it.ex : ""), g.from, ctx.target) || "";
              if (!ctx.stale()) ctx.rerender();
            }, "dsx-mini"));
          }
          if (it.ex) li.append(mk("div", "dsx-muted dsx-defex", "«" + it.ex + "»"));
          if (tr) li.append(mk("div", "dsx-deftr", tr.replace(/\n/g, " — ")));
          d.append(li);
        }
        if (all.length > 3) d.append(btn(st.defsAll ? "meno" : "altre " + (Math.min(all.length, 10) - 3) + " ›", st.defsAll ? "Mostra solo le prime" : "Mostra le altre definizioni",
          () => { st.defsAll = !st.defsAll; ctx.rerender(); }, "dsx-mini"));
        if (gd && gd.examples && gd.examples.length && !all.some((x) => x.it.ex)) d.append(mk("div", "dsx-muted dsx-defex", "«" + gd.examples[0] + "»"));
        box.append(d);
      }
    }

    // 2. scrittura corretta?
    if (p.learnSpell !== false) {
      const row = mk("div", "dsx-spell");
      const sp = llm && llm.spelling && isFinite(llm.spelling.score) ? llm.spelling : null;
      const lt = ltForWord(st.lt, ctx.sentence, ctx.word);
      const dym = p.gdSpell !== false && gd && gd.didYouMean && gd.didYouMean.toLowerCase() !== String(ctx.word).toLowerCase() ? gd.didYouMean : "";
      if (dym && !(sp && sp.score >= 90)) {
        row.classList.add("dsx-warn");
        row.textContent = "⚠ Forse cercavi: " + dym + " (Google)";
      } else if (sp) {
        const ok = sp.score >= 90;
        row.classList.add(ok ? "dsx-ok" : "dsx-warn");
        row.textContent = (ok ? "✓ Scritta correttamente" : "⚠ Scrittura") + ` (${Math.max(0, Math.min(100, Math.round(sp.score)))}/100)` +
          (sp.correct && sp.correct.toLowerCase() !== ctx.word.toLowerCase() ? ` → forma corretta: ${sp.correct}` : "") + (sp.note ? ". " + sp.note : "");
      } else if (lt && !lt.ok) {
        row.classList.add("dsx-warn");
        row.textContent = "⚠ Possibile errore: " + (lt.message || "") + (lt.repl && lt.repl.length ? " → " + lt.repl.join(", ") : "") + " (LanguageTool)";
      } else if (lt && lt.ok) {
        row.classList.add("dsx-ok");
        row.textContent = "✓ Nessun errore trovato (LanguageTool)";
      } else if (w && "exists" in w && (!st.lt || st.lt.unsupported || st.lt.error)) {
        row.classList.add(w.exists ? "dsx-ok" : "dsx-warn");
        row.textContent = w.exists ? "✓ Parola presente nel dizionario (Wiktionary)" : "? Non trovata nel dizionario: forse scritta male, rara o un nome";
      } else row.append(mk("span", "dsx-muted", "Controllo della scrittura …"));
      box.append(row);
    }

    // 3. etimologia, audio di madrelingua, tabella
    if (p.etym !== false || p.learnTable !== false) {
      const row = mk("div", "dsx-etym");
      if (!w) row.append(mk("span", "dsx-muted", "Wiktionary …"));
      else if (w.error) row.append(mk("span", "dsx-muted", "Wiktionary non disponibile: " + w.error));
      else {
        if (p.etym !== false) {
          // più spiegazioni (Wiktionary e quelle chieste al modello con «✨ Spiegala meglio»): ‹ › per passare dall'una all'altra
          const notes = w.trans && DS_ETYM.notesOf ? DS_ETYM.notesOf(ctx.word, ctx.lang, ctx.target) : [];
          const srcs = w.trans ? [{ text: w.trans, by: w.fixed && w.source === "corretta da te" ? "corretta da te" : (w.source || "Wiktionary"), main: true }, ...notes] : [];
          const si = Math.max(0, Math.min(srcs.length - 1, st.etymSrc || 0));
          const cur = srcs[si];
          if (srcs.length > 1) {
            const sw = mk("span", "dsx-etymsrc");
            sw.append(btn("‹", "Spiegazione precedente", () => { st.etymSrc = (si + srcs.length - 1) % srcs.length; ctx.rerender(); }),
              mk("span", "dsx-muted", ` ${cur.by} (${si + 1}/${srcs.length}) `),
              btn("›", "Spiegazione successiva", () => { st.etymSrc = (si + 1) % srcs.length; ctx.rerender(); }));
            row.append(sw, mk("br"));
          }
          if (cur && !cur.main) {
            row.append(mk("b", null, "Etimologia: "), document.createTextNode(cur.text + " "));
          } else if (w.trans) {
            row.append(mk("b", null, "Etimologia: "), document.createTextNode(w.trans + " "));
            // presa dal lemma: lo dico, e come l'ho trovata
            if (w.lemma && w.baseHow && !w.fixed) row.append(mk("span", "dsx-muted dsx-etymfrom", `(di «${w.lemma}», lemma` +
              ({ forma: ", da Wiktionary", tabella: ": «" + ctx.word + "» è nella sua tabella", modello: ", secondo il modello", tu: ", scelta da te" }[w.baseHow] || "") + ") "));
            if (w.fixed && w.source === "corretta da te") row.append(mk("span", "dsx-muted", "(✎ corretta da te) "));
            else if (w.source && w.source !== "Wiktionary") row.append(mk("span", "dsx-muted", "(" + w.source + ") "));
            if (st.etymOrig && w.text && w.text !== w.trans) row.append(mk("div", "dsx-muted dsx-orig", "Originale (" + (w.source || "Wiktionary") + "): " + w.text));
            // albero etimologico (dizionario di Google), quando c'è
            // albero etimologico: quello di Wiktionary (a rami, dalla radice più antica) o quello del dizionario di Google
            const tree = w.tree || (st.gweb && st.gweb.entries && (st.gweb.entries.find((e) => e.tree) || {}).tree) || "";
            if (w.wtree || tree) row.append(btn(st.treeOpen ? "nascondi l'albero" : "🌳 albero etimologico", "L'albero dell'origine della parola" + (w.wtree ? " (Wiktionary" + (w.wtreeTitle && w.wtreeTitle !== ctx.word ? ", di «" + w.wtreeTitle + "»" : "") + ")" : " (dizionario di Google)"), () => { st.treeOpen = !st.treeOpen; ctx.rerender(); }));
            if (st.treeOpen && w.wtree) row.append(wiktTree(w.wtree, w.wtreeTitle && w.wtreeTitle !== ctx.word ? w.wtreeTitle : "", w.wtreeFrom === "catena", ctx.target));
            else if (st.treeOpen && tree) row.append(gwTree(tree, st, ctx));
          } else {
            row.append(mk("span", "dsx-muted", "Etimologia: non trovata su Wiktionary. " + (ctx.etymHint || "")));
            row.append(btn("🔍 cerca radice", "Forma flessa (declinazione, tempo verbale…) non riconosciuta? Cerca su Wiktionary il suo lemma (la forma del dizionario)", async () => {
              st.etymBaseEdit = true; st.baseSearch = "…"; ctx.rerender();
              st.baseSearch = await DS_ETYM.searchBases(ctx.word, ctx.lang, baseHints(ctx));
              if (!ctx.stale()) ctx.rerender();
            }));
            row.append(btn(st.etymBaseEdit ? "chiudi" : "scrivilo tu…", "Scrivi la parola da cui deriva (infinito, nominativo…): l'etimologia si prende da lì", () => { st.etymBaseEdit = !st.etymBaseEdit; ctx.rerender(); }));
          }
          if (w.trans) st.etymText = w.trans;
        }
        const tools = mk("span", "dsx-tools");
        if (p.learnTable !== false && w.table) tools.append(btn(st.showTable ? "nascondi tabella" : "▦ tabella", "Coniugazione o declinazione (Wiktionary)" + (w.tableTitle && w.tableTitle !== ctx.word ? ` di «${w.tableTitle}»` : ""), () => { st.showTable = !st.showTable; ctx.rerender(); }));
        if (w.url) { const a = mk("a", "dsx-link", "Wiktionary"); a.href = w.url; a.target = "_blank"; a.rel = "noopener noreferrer"; tools.append(a); }
        // ✨ una spiegazione più completa dal modello, da leggere insieme a quella di Wiktionary (‹ › per passare)
        { const e = ctx.engine ? ctx.engine() : null;
          if (e && p.etym !== false && w.trans) tools.append(btn(st.etymDeep ? "Chiedo…" : "✨ Spiegala meglio" + (e.name ? " con " + e.name : ""), "Una richiesta al modello: spiega e completa l'etimologia di Wiktionary nella tua lingua. Resta salvata accanto a quella di Wiktionary: passi dall'una all'altra con ‹ ›", async () => {
            if (st.etymDeep) return;
            st.etymDeep = true; st.etymErr = ""; ctx.rerender();
            const r = await DS_ETYM.askDeeper(e, ctx.word, ctx.lang, ctx.target, ctx.sentence, w.text || w.trans);
            st.etymDeep = false;
            if (r && !r.error) st.etymSrc = DS_ETYM.notesOf(ctx.word, ctx.lang, ctx.target).findIndex((x) => x.by === r.by) + 1;
            else { st.etymErr = (r && r.error) || "nessuna risposta"; st.etymFix = true; }
            if (!ctx.stale()) ctx.rerender();
          })); }
        { const ee = etymExplorerUrl(ctx, w); if (ee) { const a = mk("a", "dsx-link", "Etymology Explorer"); a.href = ee; a.target = "_blank"; a.rel = "noopener noreferrer"; a.title = "La mappa delle origini della parola e delle parole parenti, su etymologyexplorer.com (si apre in un'altra scheda)"; tools.append(a); } }
        // il testo com'è scritto su Wiktionary (prima della traduzione automatica), sempre a portata di clic
        if (p.etym !== false && w.trans && w.text && w.text !== w.trans) tools.append(btn(st.etymOrig ? "nascondi originale" : "originale", "Mostra l'etimologia com'è scritta su Wiktionary (in inglese), senza traduzione automatica", () => { st.etymOrig = !st.etymOrig; ctx.rerender(); }));
        if (p.etym !== false && w.trans) tools.append(btn(st.etymFix ? "chiudi" : "⚑", "Etimologia sbagliata o tradotta male? Rifalla o correggila", () => { st.etymFix = !st.etymFix; st.etymEdit = false; ctx.rerender(); }));
        if (tools.childNodes.length) row.append(tools);
      }
      box.append(row);
      if (st.etymFix && w && w.trans) box.append(etymFixBox(ctx, st, w));
      if (st.etymBaseEdit && w && !w.error) box.append(etymBaseBox(ctx, st, w));
      if (st.showTable && w && w.table) {
        const t = mk("table", "dsx-table");
        for (const r of w.table) {
          const tr = mk("tr");
          for (const c of r) {
            const td = mk(c.h ? "th" : "td", null, c.t);
            if (c.tr && c.tr !== c.t) td.append(mk("span", "dsx-tr", c.tr));   // traslitterazione, sotto e separata
            if (c.cs > 1) td.colSpan = c.cs; if (c.rs > 1) td.rowSpan = c.rs; tr.append(td);
          }
          t.append(tr);
        }
        const wrap = mk("div", "dsx-tablewrap");
        if (w.tableTitle && w.tableTitle !== ctx.word) wrap.append(mk("div", "dsx-muted", "Forma base: " + w.tableTitle));
        wrap.append(t);
        box.append(wrap);
      }
    }

    // 3b. dizionario di Google (Oxford)
    const gb = GW_ON && p.learnGweb !== false && GW_LANGS.test(String(ctx.lang || "").split("-")[0]) ? gwBox(ctx) : null;
    if (gb) box.append(gb); else { const ng = ngramRow(ctx); if (ng) box.append(ng); }

    // 4. dal modello, nella stessa richiesta della spiegazione: falsi amici e parole parenti
    if (p.learnLlmExtra !== false && llm) {
      if (llm.falseFriend) box.append(mk("div", "dsx-false", "⚠ " + llm.falseFriend));
      if (llm.related) { const d = mk("div", "dsx-related"); d.append(mk("b", null, "Parole parenti: "), document.createTextNode(llm.related)); box.append(d); }
    }

    // 5. frasi d'esempio vere (Tatoeba)
    if (p.learnExamples !== false) {
      const ex = mk("div", "dsx-ex");
      const r = st.examples;
      if (!r) ex.append(mk("span", "dsx-muted", "Esempi …"));
      else if (r.error) ex.append(mk("span", "dsx-muted", "Esempi non disponibili (Tatoeba)"));
      else if (!r.items || !r.items.length) ex.append(mk("span", "dsx-muted", "Nessun esempio su Tatoeba"));
      else {
        ex.append(mk("div", "dsx-ex-title", "Esempi veri (Tatoeba)"));
        if (!r.items.some((x) => x.audio)) ex.append(mk("div", "dsx-muted", "Per questa parola Tatoeba non ha frasi registrate da un madrelingua: 🔈 = voce sintetica." + (r.err ? " (" + r.err + ")" : "")));
        for (const it of r.items) {
          const li = mk("div", "dsx-ex-item");
          const play = it.audio ? btn("🔊", "Registrata da un madrelingua (Tatoeba)", (el) => playUrl([it.audio, ...(it.audioAlt || [])], el)) :
            btn("🔈", "Questa frase non è registrata su Tatoeba: voce sintetica", () => ctx.speak && ctx.speak(it.text, ctx.lang));
          li.append(play, mk("span", "dsx-ex-text", it.text));
          if (it.trans) li.append(mk("div", "dsx-ex-trans", it.trans + (it.google ? " (Google)" : "")));
          ex.append(li);
        }
      }
      box.append(ex);
    }
    // 6. immagine per la carta di Anki (con l'opzione accesa nel popup → Anki)
    if (p.ankiImage && st.img) box.append(imagePicker(st.img, { word: ctx.lemma || ctx.word, lang: ctx.lang, rerender: ctx.rerender, onPick: ctx.onImage }));
    return box;
  }

  // ---------- Pulsante di ascolto della scheda: registrazione vera se c'è, altrimenti voce sintetica ----------
  // 🔊 = registrazione di una persona (Wiktionary), 🔈 = voce sintetica
  const ICON_REC = "🔊", ICON_TTS = "🔈";
  // la registrazione della parola: prima quella della parola esatta (Wiktionary inglese, poi le altre edizioni);
  // se c'è solo quella di un'altra forma (гордую → гордый), si usa lo stesso ma con form = quella forma (va segnalata)
  function recordingInfo(st, word, prefs) {
    if (!st || (prefs && prefs.learnAudio === false)) return null;
    const same = (a, b) => DS_ETYM.sameWord(a, b);
    const otherFile = (list) => { const f = DS_ETYM.fileWord(list[0]); return f && !same(f, word) ? f : ""; };
    const w = st.wikt, a2 = st.audio2;
    const enOk = w && w.audio && w.audio.length;
    if (enOk && same(w.audioTitle, word) && !otherFile(w.audio)) return { audio: w.audio, form: "" };
    if (a2 && a2.audio && a2.audio.length && !a2.form) return { audio: a2.audio, form: "" };
    if (a2 && a2.wait) return null;
    if (enOk) return { audio: w.audio, form: otherFile(w.audio) || w.audioTitle || "?" };
    if (a2 && a2.audio && a2.audio.length) return { audio: a2.audio, form: a2.form };
    // ultima possibilità: la pronuncia registrata del dizionario di Google (della parola o del suo lemma)
    const ge = st.gweb && st.gweb.entries && st.gweb.entries.find((e) => e.phonetics.some((p) => p.audio));
    if (ge) return { audio: [ge.phonetics.find((p) => p.audio).audio], form: same(ge.headword, word) ? "" : ge.headword, google: true };
    return null;
  }
  function recordingOf(st, word, prefs) { const r = recordingInfo(st, word, prefs); return r ? r.audio : null; }
  // titolo e classe del pulsante 🔊: un'altra forma della parola si vede (colore diverso) e si dice quale
  function recordingLabel(st, word, prefs) {
    const r = recordingInfo(st, word, prefs);
    if (!r) return null;
    const src = r.google ? "dizionario di Google" : "Wiktionary";
    return r.form ? { form: r.form, title: `Registrazione di «${r.form}», il lemma o un'altra forma della parola (non di «${word}» esatta): ${src}`, cls: "dsx-recform" }
      : { form: "", title: "Ascolta la registrazione di un madrelingua (" + src + ")", cls: "" };
  }
  // 1.6.2: registrazione per la carta di Anki: solo quella della parola esatta (di un madrelingua);
  // se non c'è, niente (la carta prende la voce sintetica). o: { word, lang, target, lemma, st }
  async function ankiRec(o) {
    const word = String(o.word || "").trim();
    if (!word || /\s/.test(word) || o.kind === "text") return [];
    const late = (p) => Promise.race([p, new Promise((r) => setTimeout(() => r(null), 6000))]);
    try {
      const i1 = o.st ? recordingInfo(o.st, word, {}) : null;
      if (i1 && !i1.form && i1.audio && i1.audio.length) return i1.audio;
      const w = await late(DS_ETYM.get(word, o.lang, o.target || "en", o.lemma));
      const i2 = w ? recordingInfo({ wikt: w }, word, {}) : null;
      if (i2 && !i2.form && i2.audio && i2.audio.length) return i2.audio;
      const a = await late(DS_ETYM.audioOther(word, o.lang, o.target || "en"));
      if (a && a.audio && a.audio.length && !a.form) return a.audio;
    } catch {}
    return [];
  }
  // o: { word, lang, target, lemma, st, prefs, tts: () => Promise }  → "rec" | "tts"
  async function playWord(o) {
    const p = o.prefs || {};
    if (p.learnAudio !== false && o.st && !o.st.wikt) {
      try { o.st.wikt = await Promise.race([DS_ETYM.get(o.word, o.lang, o.target, o.lemma), new Promise((r) => setTimeout(() => r(null), 4000))]) || undefined; } catch {}
    }
    const rec = recordingOf(o.st, o.word, p);
    if (rec) {
      const r = await playUrl(rec, null);
      if (r) { if (o.onRec) o.onRec(r); return "rec"; }
    }
    if (o.tts) await o.tts();
    return "tts";
  }

  // per il vocabolario e Anki
  function entryExtras(st, lang) {
    const w = st.wikt || {};
    const g = genderInfo(w.gender, lang || "");
    return { etym: st.etymText || "", gender: g ? g.text : "", freq: st.freq || 0 };
  }

  // ---------- Immagine per la carta di Anki: Wikipedia, Wikimedia Commons, Openverse (gratis) ----------
  // Si sceglie da dove nel popup → Anki; nella scheda e nel vocabolario si cambia con ‹ ›, si cerca altro, si
  // incolla un indirizzo o si toglie. im = { list, i, none, wait, q, error, open, loaded }
  let imgSrcPref = "auto";
  DS_EXT.storage.sync.get({ ankiImageSource: "auto" }).then((r) => { imgSrcPref = r.ankiImageSource || "auto"; }).catch(() => {});
  DS_EXT.storage.onChanged.addListener((ch, a) => { if (a === "sync" && ch.ankiImageSource) imgSrcPref = ch.ankiImageSource.newValue || "auto"; });
  const imgCache = new Map();
  async function searchImages(query, lang, source, raw) {
    const k = [source, lang, query, raw ? 1 : 0].join("|");
    if (imgCache.has(k)) return imgCache.get(k);
    let r;
    try { r = await DS_EXT.runtime.sendMessage({ type: "imageSearch", query, lang, source, raw, n: 8 }); } catch (e) { r = { error: String(e.message || e) }; }
    r = r || {};
    if (!Array.isArray(r.items)) r.items = [];
    if (r.items.length) imgCache.set(k, r);
    return r;
  }
  async function image(word, lang) {
    const r = await searchImages(word, lang, imgSrcPref);
    return (r.items[0] && r.items[0].url) || "";
  }
  // l'immagine scelta: un indirizzo, "" = nessuna, undefined = non ancora decisa (allora la cerca chi salva)
  function chosenImage(im) {
    if (!im || im.wait) return undefined;
    if (im.none) return "";
    const it = im.list && im.list[im.i || 0];
    return it ? it.url : undefined;
  }
  function loadImages(im, query, lang, source, raw, done, keep) {
    im.wait = true; im.error = "";
    searchImages(query, lang, source || imgSrcPref, raw).then((r) => {
      const list = (keep || []).concat(r.items.filter((x) => !(keep || []).some((k) => k.url === x.url)));
      Object.assign(im, { wait: false, loaded: true, list, i: 0, q: r.query || query, error: r.error || "", none: false });
      done();
    });
  }
  // o: { word, lang, rerender, onPick(url) }
  function imagePicker(im, o) {
    const row = mk("div", "dsx-img");
    const pick = () => { const u = chosenImage(im); if (o.onPick && u !== undefined) o.onPick(u); o.rerender(); };
    const ensure = (then) => {
      if (im.loaded || im.wait) return then();
      loadImages(im, o.word, o.lang, null, false, () => { im.i = 0; then(); o.rerender(); }, im.list && im.list.length ? im.list.slice(0, 1) : []);
      o.rerender();
    };
    if (o.autoload && !im.loaded && !im.wait) setTimeout(() => ensure(() => {}), 0);
    const head = mk("div", "dsx-imghead");
    head.append(mk("b", null, "Immagine per Anki: "));
    const cur = im.none ? null : im.list && im.list[im.i || 0];
    if (im.wait && !cur) head.append(mk("span", "dsx-muted", "cerco… "));
    else if (im.none) {
      head.append(mk("span", "dsx-muted", "nessuna "));
      head.append(btn("rimetti", "Rimetti un'immagine", () => { im.none = false; ensure(() => {}); pick(); }, "dsx-mini"));
    } else if (!cur) head.append(mk("span", "dsx-muted", (im.error ? "non trovata (" + im.error.slice(0, 60) + ") " : "non trovata ")));
    if (cur) {
      const n = im.list.length;
      head.append(btn("‹", "Immagine precedente", () => ensure(() => { im.i = ((im.i || 0) - 1 + im.list.length) % im.list.length; pick(); }), "dsx-mini"));
      head.append(mk("span", "dsx-muted", " " + ((im.i || 0) + 1) + "/" + (im.loaded ? n : n + "+") + " "));
      head.append(btn("›", "Immagine successiva", () => ensure(() => { im.i = ((im.i || 0) + 1) % im.list.length; pick(); }), "dsx-mini"));
      head.append(btn("✕", "Nessuna immagine per questa carta", () => { im.none = true; pick(); }, "dsx-mini"));
    }
    if (!im.none) head.append(btn(im.open ? "chiudi" : "altre…", "Tutte le immagini trovate, cerca con altre parole o incolla un indirizzo", () => { im.open = !im.open; if (im.open) ensure(() => {}); o.rerender(); }, "dsx-mini"));
    row.append(head);
    if (cur && !im.open) {
      const img = mk("img", "dsx-imgthumb"); img.src = cur.thumb || cur.url; img.alt = ""; img.loading = "lazy"; img.referrerPolicy = "no-referrer";
      img.title = (cur.source ? cur.source + ": " : "") + (cur.title || "") + " — clic per vederle tutte";
      img.addEventListener("click", (e) => { e.stopPropagation(); im.open = true; ensure(() => {}); o.rerender(); });
      img.addEventListener("error", () => { img.replaceWith(mk("span", "dsx-muted", "(l'immagine non si carica: prova ›)")); });
      row.append(img);
    }
    if (im.open) {
      const grid = mk("div", "dsx-imggrid");
      (im.list || []).slice(0, 16).forEach((it, k) => {
        const g = mk("img", "dsx-imgcell" + (k === (im.i || 0) && !im.none ? " dsx-on" : "")); g.src = it.thumb || it.url; g.alt = ""; g.loading = "lazy"; g.referrerPolicy = "no-referrer";
        g.title = (it.source ? it.source + ": " : "") + (it.title || "");
        g.addEventListener("click", (e) => { e.stopPropagation(); im.i = k; im.none = false; im.open = false; pick(); });
        g.addEventListener("error", () => g.remove());
        grid.append(g);
      });
      if (im.wait) grid.append(mk("span", "dsx-muted", "cerco…"));
      row.append(grid);
      const tools = mk("div", "dsx-imgtools");
      const q = mk("input", "dsx-input"); q.type = "text"; q.placeholder = "Cerca altro (" + (im.q || o.word) + ")…"; q.spellcheck = false;
      const src = mk("select", "dsx-input");
      [["auto", "Wikipedia e Commons"], ["wikipedia", "Wikipedia"], ["commons", "Wikimedia Commons"], ["openverse", "Openverse (foto)"], ["all", "Tutte"]].forEach(([v, l]) => src.append(new Option(l, v)));
      src.value = im.src || imgSrcPref;
      const go = () => {
        const text = q.value.trim();
        im.src = src.value;
        // scritto da te: si cerca così com'è (in inglese si trova di più)
        loadImages(im, text || o.word, o.lang, src.value, !!text, () => { pick(); });
        o.rerender();
      };
      q.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") go(); });
      src.addEventListener("change", (e) => { e.stopPropagation(); go(); });
      src.addEventListener("click", (e) => e.stopPropagation());
      q.addEventListener("click", (e) => e.stopPropagation());
      const url = mk("input", "dsx-input"); url.type = "url"; url.placeholder = "…oppure incolla l'indirizzo di un'immagine (https://…)"; url.spellcheck = false;
      url.addEventListener("click", (e) => e.stopPropagation());
      url.addEventListener("keydown", (e) => {
        e.stopPropagation();
        if (e.key !== "Enter") return;
        const u = url.value.trim();
        if (!/^https:\/\/\S+$/.test(u)) { url.value = ""; url.placeholder = "Serve un indirizzo che inizia con https://"; return; }
        im.list = [{ url: u, thumb: u, source: "indirizzo tuo", title: "" }].concat((im.list || []).filter((x) => x.url !== u));
        im.i = 0; im.none = false; im.open = false; pick();
      });
      tools.append(q, src, btn("Cerca", "Cerca le immagini", go, "dsx-mini"), url);
      row.append(tools);
    }
    return row;
  }

  return { render, hanChars, entryExtras, image, chosenImage, imagePicker, playUrl, genderInfo, recordingOf, recordingInfo, recordingLabel, playWord, ankiRec, ngramWidget, idiomPanel, idiomWords, lemmaPicker, baseHints, ICON_REC, ICON_TTS };
})();

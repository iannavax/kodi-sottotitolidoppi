#!/bin/sh
# Sottotitoli Doppi - installazione del programma per yt-dlp (Mac e Linux)
# Installa per il tuo utente: yt-dlp, Deno, il programma di appoggio, e lo registra nei browser.
set -e
EXT_ID='__EXTID__'
GECKO='sottotitoli-doppi@estensione.local'
GECKO2='sottotitoli-parole@estensione.local'
NAME='com.sottotitolidoppi.helper'
OS=$(uname -s)
ARCH=$(uname -m)
case "$ARCH" in arm64|aarch64) DENO_ARCH=aarch64; HOST_ARCH=arm64; YT_LINUX=yt-dlp_linux_aarch64 ;; *) DENO_ARCH=x86_64; HOST_ARCH=amd64; YT_LINUX=yt-dlp_linux ;; esac
if [ "$OS" = "Darwin" ]; then
  DIR="$HOME/Library/Application Support/SottotitoliDoppi"
  BASE="$HOME/Library/Application Support"
  CHROME_DIRS="$BASE/Microsoft Edge/NativeMessagingHosts:$BASE/Google/Chrome/NativeMessagingHosts:$BASE/BraveSoftware/Brave-Browser/NativeMessagingHosts:$BASE/Chromium/NativeMessagingHosts"
  FF_DIRS="$BASE/Mozilla/NativeMessagingHosts"
  YT_URL=${SD_YTDLP_URL:-https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos}
  DENO_TARGET=apple-darwin
else
  DIR="${XDG_DATA_HOME:-$HOME/.local/share}/sottotitoli-doppi"
  CHROME_DIRS="$HOME/.config/microsoft-edge/NativeMessagingHosts:$HOME/.config/google-chrome/NativeMessagingHosts:$HOME/.config/BraveSoftware/Brave-Browser/NativeMessagingHosts:$HOME/.config/chromium/NativeMessagingHosts"
  FF_DIRS="$HOME/.mozilla/native-messaging-hosts"
  YT_URL=${SD_YTDLP_URL:-https://github.com/yt-dlp/yt-dlp/releases/latest/download/$YT_LINUX}
  DENO_TARGET=unknown-linux-gnu
fi
[ -n "$SD_EXTRA_CHROME_DIRS" ] && CHROME_DIRS="$CHROME_DIRS:$SD_EXTRA_CHROME_DIRS"
DENO_URL=${SD_DENO_URL:-https://github.com/denoland/deno/releases/latest/download/deno-$DENO_ARCH-$DENO_TARGET.zip}

echo ""
echo "=== Sottotitoli Doppi: programma per yt-dlp ==="
echo "(non serve Python: il programma di appoggio e' un unico file)"
mkdir -p "$DIR"
echo "1/4  Scarico yt-dlp..."
curl -fsSL --retry 2 -o "$DIR/yt-dlp" "$YT_URL"
chmod +x "$DIR/yt-dlp"
echo "2/4  Scarico Deno..."
curl -fsSL --retry 2 -o "$DIR/deno.zip" "$DENO_URL"
if command -v unzip >/dev/null 2>&1; then unzip -o -q "$DIR/deno.zip" -d "$DIR"
elif command -v bsdtar >/dev/null 2>&1; then bsdtar -xf "$DIR/deno.zip" -C "$DIR"
elif command -v python3 >/dev/null 2>&1; then python3 -m zipfile -e "$DIR/deno.zip" "$DIR/"
else echo "Serve 'unzip' per aprire Deno: installalo (Linux: sudo apt install unzip) e rilancia."; exit 1; fi
rm -f "$DIR/deno.zip"
chmod +x "$DIR/deno"
echo "3/4  Installo il programma di appoggio e lo registro nei browser..."
# il programma di appoggio e' in fondo a questo file (compresso): lo tiro fuori per questo computer
awk -v m="##PAYLOAD $HOST_ARCH##" '$0==m{f=1;next} /^##END##$/{f=0} f' "$0" > "$DIR/host.b64"
if ! [ -s "$DIR/host.b64" ]; then echo "Il file dell'installatore e' incompleto: scaricalo di nuovo dall'estensione."; exit 1; fi
{ base64 -d < "$DIR/host.b64" 2>/dev/null || base64 -D < "$DIR/host.b64" 2>/dev/null || openssl base64 -d -A < "$DIR/host.b64"; } | gunzip > "$DIR/sd_host.new"
rm -f "$DIR/host.b64"
mv -f "$DIR/sd_host.new" "$DIR/sd_host"
chmod +x "$DIR/sd_host"
rm -f "$DIR/sd_host.sh" "$DIR/sd_host.py"
# vecchi identificativi dell'estensione gia' registrati (se l'installatore viene da Chrome/Edge e poi da un altro)
ORIGINS=""
if [ -f "$DIR/host-chrome.json" ]; then
  ORIGINS=$(grep -o 'chrome-extension://[a-p]*/' "$DIR/host-chrome.json" | sort -u)
fi
if [ -n "$EXT_ID" ]; then ORIGINS=$(printf '%s\nchrome-extension://%s/\n' "$ORIGINS" "$EXT_ID" | grep . | sort -u); fi
ORIG_JSON=""
for o in $ORIGINS; do ORIG_JSON="$ORIG_JSON${ORIG_JSON:+,}\"$o\""; done
CM=$(printf '{"name":"%s","description":"Sottotitoli Doppi: audio con yt-dlp","path":"%s","type":"stdio","allowed_origins":[%s]}' "$NAME" "$DIR/sd_host" "$ORIG_JSON")
FM=$(printf '{"name":"%s","description":"Sottotitoli Doppi: audio con yt-dlp","path":"%s","type":"stdio","allowed_extensions":["%s","%s"]}' "$NAME" "$DIR/sd_host" "$GECKO" "$GECKO2")
printf '%s\n' "$CM" > "$DIR/host-chrome.json"
N=0
OLDIFS=$IFS; IFS=:; set -f
for x in $CHROME_DIRS; do [ -n "$x" ] || continue; mkdir -p "$x"; printf '%s\n' "$CM" > "$x/$NAME.json"; N=$((N+1)); done
for x in $FF_DIRS; do [ -n "$x" ] || continue; mkdir -p "$x"; printf '%s\n' "$FM" > "$x/$NAME.json"; done
set +f; IFS=$OLDIFS
echo "     registrato per: $N browser Chromium e Firefox"
echo "4/4  Verifico..."
echo "     yt-dlp $("$DIR/yt-dlp" --version)"
echo "     $("$DIR/deno" --version | head -n 1)"
if command -v ffmpeg >/dev/null 2>&1; then
  echo "     ffmpeg: si'"
else
  echo "     ffmpeg: no. Serve solo per le dirette sincronizzate: installalo con 'brew install ffmpeg' (Mac) o 'sudo apt install ffmpeg' (Linux)."
fi
echo ""
echo "Fatto! Torna nel browser e premi \"Verifica di nuovo\". (Tutto e' in $DIR)"
exit 0
##PAYLOAD amd64##
__HOSTB64_AMD64__
##END##
##PAYLOAD arm64##
__HOSTB64_ARM64__
##END##

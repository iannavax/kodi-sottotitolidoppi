# 1.7.6: voce Piper greca: parola isolata → punto finale, accento primario al posto del solo secondario, tabella dei suoni della voce
import asyncio, os, sys, json, subprocess, shutil, http.server, threading, base64, struct
sys.path.insert(0, "/home/claude/e2e")
from charness import *
FIX = "/tmp/piperfix_el"; shutil.rmtree(FIX, ignore_errors=True)
d = f"{FIX}/el/el_GR/test/low"; os.makedirs(d)
shutil.copy("/home/claude/e2e/fixtures/fake-piper.onnx", f"{d}/el_GR-test-low.onnx")
# tabella della voce: ogni suono = 2 identificatori (così si vede che la tabella è usata davvero)
phs = "ˈ ˌ e n a l i k j s u r o . ,".split() + [" "]
pmap = {"_": [0], "^": [1], "$": [2]}
for p in phs: pmap[p] = [9, 9]
pmap["."] = [10]
json.dump({"audio": {"sample_rate": 22050}, "espeak": {"voice": "el"}, "inference": {"noise_scale": 0.667, "length_scale": 1, "noise_w": 0.8}, "phoneme_id_map": pmap}, open(f"{d}/el_GR-test-low.onnx.json", "w"))
json.dump({"el_GR-test-low": {"key": "el_GR-test-low", "num_speakers": 1, "files": {"el/el_GR/test/low/el_GR-test-low.onnx": {"size_bytes": 311}}}}, open(f"{FIX}/voices.json", "w"))
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=FIX, **k)
    def log_message(self, f, *a): pass
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 8791), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
def expected(text):
    js = "const c=require('/home/claude/vendor-piper/piper_phonemize.js');(async()=>{const L=[];const m=await c({print:l=>L.push(l),printErr:()=>{},locateFile:f=>'/home/claude/vendor-piper/'+f});m.callMain(['-l','el','--input',JSON.stringify([{text:process.argv[1]}]),'--espeak_data','/espeak-ng-data']);console.log(L[0])})()"
    j = json.loads(subprocess.run(["node", "-e", js, text], capture_output=True, text=True).stdout.strip().splitlines()[-1])
    ph = j["phonemes"]
    if "ˈ" not in ph and "ˌ" in ph: ph = ph[:]; ph[ph.index("ˌ")] = "ˈ"
    n = 2 + 1  # ^ _ ... $
    for p in ph:
        if p in pmap: n += len(pmap[p]) + 1
    return ph, n
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({piperBase:'http://127.0.0.1:8791/', piperPopUrl:'http://127.0.0.1:8791/none'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/popup.html"); await pg.wait_for_timeout(800)
        ok = True
        for word in ["ένα", "Ελληνικά"]:
            ph_exp, ids_exp = expected(word + ".")
            r = await pg.evaluate("(w) => chrome.runtime.sendMessage({type:'piper', op:'speak', key:'el_GR-test-low', text:w, rate:0.9})", word)
            if "error" in r: print(word, "ERRORE", r["error"]); ok = False; continue
            raw = base64.b64decode(r["audio"]); n = (len(raw) - 44) // 2
            print(f"«{word}»: suoni attesi {ph_exp} → identificatori {ids_exp} | campioni nel suono: {n} → {n // 200} identificatori")
            ok = ok and n == ids_exp * 200
        print("errori:", errs if ok else errs + ["voce greca non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, etym:false, learnExamples:false, learnSpell:false, learnFreq:false, learnAudio:false, learnTable:false, learnGender:false, learnKnown:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "en", "bread", 2500)
        print("1.", (await pg.evaluate("(document.querySelector('.pav-card .dsx')||{}).innerText")).replace("\n", " | "), "| vecchia lista:", await pg.evaluate("!!document.querySelector('.pav-card .pav-dict')"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

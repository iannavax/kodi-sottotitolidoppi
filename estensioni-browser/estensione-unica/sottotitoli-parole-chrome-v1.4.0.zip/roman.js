// Trascrizione in lettere latine sopra ogni lettera (o sillaba) degli alfabeti non latini, per imparare l'alfabeto.
// Tutto scritto qui, a tabelle: nessun servizio, nessun token, si accende e si spegne subito.
// Lettera per lettera: cirillico, greco, armeno, georgiano, ebraico, kana giapponesi (sillaba per sillaba),
// coreano (blocco per blocco). Parola per parola (le lettere sono legate tra loro e separarle le deformerebbe):
// arabo, persiano, urdu, devanagari (hindi…). I kanji e i caratteri cinesi hanno più letture che dipendono dalla
// parola: una tabella non basta, quindi qui non si scrivono (la riga intera può arrivare da Google, gratis).
// DS_ROMAN.units(parola, lingua) → [{ t: testo, r: trascrizione | "" }]
var DS_ROMAN = (() => {
  const map = (s) => { const o = {}; s.trim().split(/\s+/).forEach((p) => { const i = p.indexOf("="); o[p.slice(0, i)] = p.slice(i + 1); }); return o; };

  // ---------- Cirillico ----------
  const CYR = map("а=a б=b в=v г=g д=d е=e ё=yo ж=zh з=z и=i й=y к=k л=l м=m н=n о=o п=p р=r с=s т=t у=u ф=f х=kh ц=ts ч=ch ш=sh щ=shch ъ=ʺ ы=y ь=ʹ э=e ю=yu я=ya " +
    "і=i ї=yi є=ye ґ=g ў=w ђ=đ ј=j љ=lj њ=nj ћ=ć џ=dž ѓ=gj ќ=kj ѕ=dz ӏ=ʼ ә=ä ө=ö ү=ü ң=ng ғ=gh қ=q ҳ=h ҷ=j ҳ=h");
  const CYR_LANG = {
    uk: map("г=h и=y е=e х=kh щ=shch"),
    be: map("г=h х=kh е=ye"),
    bg: map("щ=sht ъ=ă х=h"),
    sr: map("ж=ž ч=č ш=š ц=c х=h"),
    mk: map("ж=ž ч=č ш=š ц=c х=h"),
    kk: map("х=kh")
  };
  // ---------- Greco ----------
  const GRE = map("α=a β=v γ=g δ=d ε=e ζ=z η=i θ=th ι=i κ=k λ=l μ=m ν=n ξ=x ο=o π=p ρ=r σ=s ς=s τ=t υ=y φ=f χ=ch ψ=ps ω=o");
  // ---------- Armeno, georgiano ----------
  const ARM = map("ա=a բ=b գ=g դ=d ե=e զ=z է=ē ը=ə թ=tʻ ժ=zh ի=i լ=l խ=kh ծ=ts կ=k հ=h ձ=dz ղ=gh ճ=ch մ=m յ=y ն=n շ=sh ո=o չ=chʻ պ=p ջ=j ռ=ṙ ս=s վ=v տ=t ր=r ց=tsʻ ւ=w փ=pʻ ք=kʻ օ=ō ֆ=f և=ev");
  const GEO = map("ა=a ბ=b გ=g დ=d ე=e ვ=v ზ=z თ=t ი=i კ=kʼ ლ=l მ=m ნ=n ო=o პ=pʼ ჟ=zh რ=r ს=s ტ=tʼ უ=u ფ=p ქ=k ღ=gh ყ=qʼ შ=sh ჩ=ch ც=ts ძ=dz წ=tsʼ ჭ=chʼ ხ=kh ჯ=j ჰ=h");
  // ---------- Ebraico (con i punti delle vocali, se ci sono) ----------
  const HEB = map("א=ʼ ב=v ג=g ד=d ה=h ו=v ז=z ח=ch ט=t י=y כ=kh ך=kh ל=l מ=m ם=m נ=n ן=n ס=s ע=ʻ פ=f ף=f צ=ts ץ=ts ק=k ר=r ש=sh ת=t");
  const HEB_DAGESH = map("ב=b כ=k ך=k פ=p ף=p");
  const HEB_VOW = { "ְ": "", "ֱ": "e", "ֲ": "a", "ֳ": "o", "ִ": "i", "ֵ": "e", "ֶ": "e", "ַ": "a", "ָ": "a", "ֹ": "o", "ֺ": "o", "ֻ": "u", "ׇ": "o" };
  // ---------- Arabo, persiano, urdu ----------
  const ARA = map("ب=b ت=t ث=th ج=j ح=ḥ خ=kh د=d ذ=dh ر=r ز=z س=s ش=sh ص=ṣ ض=ḍ ط=ṭ ظ=ẓ ع=ʻ غ=gh ف=f ق=q ك=k ل=l م=m ن=n ه=h ة=h ء=ʼ أ=a إ=i آ=ā ؤ=ʼ ئ=ʼ ٱ=a " +
    "پ=p چ=ch ژ=zh گ=g ک=k ٹ=ṭ ڈ=ḍ ڑ=ṛ ں=n ھ=h ڤ=v ۃ=h");
  const ARA_HARAKA = { "َ": "a", "ِ": "i", "ُ": "u", "ً": "an", "ٍ": "in", "ٌ": "un", "ْ": "", "ٰ": "ā" };
  // ---------- Devanagari ----------
  const DEV_C = map("क=k ख=kh ग=g घ=gh ङ=ṅ च=ch छ=chh ज=j झ=jh ञ=ñ ट=ṭ ठ=ṭh ड=ḍ ढ=ḍh ण=ṇ त=t थ=th द=d ध=dh न=n प=p फ=ph ब=b भ=bh म=m य=y र=r ल=l ळ=ḷ व=v श=sh ष=ṣh स=s ह=h");
  const DEV_NUKTA = map("क=q ख=kh ग=ġ ज=z ड=ṛ ढ=ṛh फ=f");
  const DEV_V = map("अ=a आ=ā इ=i ई=ī उ=u ऊ=ū ऋ=ṛ ए=e ऐ=ai ओ=o औ=au ऍ=ê ऑ=ô");
  const DEV_M = { "ा": "ā", "ि": "i", "ी": "ī", "ु": "u", "ू": "ū", "ृ": "ṛ", "े": "e", "ै": "ai", "ो": "o", "ौ": "au", "ॅ": "ê", "ॉ": "ô" };
  // ---------- Kana ----------
  const HIRA = map("あ=a い=i う=u え=e お=o か=ka き=ki く=ku け=ke こ=ko が=ga ぎ=gi ぐ=gu げ=ge ご=go さ=sa し=shi す=su せ=se そ=so ざ=za じ=ji ず=zu ぜ=ze ぞ=zo " +
    "た=ta ち=chi つ=tsu て=te と=to だ=da ぢ=ji づ=zu で=de ど=do な=na に=ni ぬ=nu ね=ne の=no は=ha ひ=hi ふ=fu へ=he ほ=ho ば=ba び=bi ぶ=bu べ=be ぼ=bo " +
    "ぱ=pa ぴ=pi ぷ=pu ぺ=pe ぽ=po ま=ma み=mi む=mu め=me も=mo や=ya ゆ=yu よ=yo ら=ra り=ri る=ru れ=re ろ=ro わ=wa ゐ=wi ゑ=we を=o ん=n ゔ=vu " +
    "ぁ=a ぃ=i ぅ=u ぇ=e ぉ=o ゃ=ya ゅ=yu ょ=yo ゎ=wa ゕ=ka ゖ=ke");
  const kanaToHira = (c) => { const n = c.codePointAt(0); return n >= 0x30A1 && n <= 0x30F6 ? String.fromCodePoint(n - 0x60) : c; };
  const SMALL_Y = new Set(["ゃ", "ゅ", "ょ"]), SMALL_V = new Set(["ぁ", "ぃ", "ぅ", "ぇ", "ぉ"]);
  // ---------- Coreano ----------
  const KO_L = ["g", "kk", "n", "d", "tt", "r", "m", "b", "pp", "s", "ss", "", "j", "jj", "ch", "k", "t", "p", "h"];
  const KO_V = ["a", "ae", "ya", "yae", "eo", "e", "yeo", "ye", "o", "wa", "wae", "oe", "yo", "u", "wo", "we", "wi", "yu", "eu", "ui", "i"];
  const KO_T = ["", "k", "k", "k", "n", "n", "n", "t", "l", "k", "m", "l", "l", "l", "p", "l", "m", "p", "p", "t", "t", "ng", "t", "t", "k", "t", "p", "t"];

  const RE = {
    cyr: /\p{Script=Cyrillic}/u, gre: /\p{Script=Greek}/u, arm: /\p{Script=Armenian}/u, geo: /\p{Script=Georgian}/u, heb: /\p{Script=Hebrew}/u,
    ara: /\p{Script=Arabic}/u, dev: /\p{Script=Devanagari}/u, kana: /[\p{Script=Hiragana}\p{Script=Katakana}ー]/u, han: /\p{Script=Han}/u, ko: /\p{Script=Hangul}/u
  };
  const scriptOf = (t) => { for (const [k, re] of Object.entries(RE)) if (re.test(t)) return k; return ""; };
  const base = (l) => String(l || "").split("-")[0].toLowerCase();
  const caps = (src, r) => (src !== src.toLowerCase() && r ? r[0].toUpperCase() + r.slice(1) : r);
  const graphemes = (t) => { try { return [...new Intl.Segmenter(undefined, { granularity: "grapheme" }).segment(t)].map((x) => x.segment); } catch { return [...t]; } };
  // c'è qualcosa da trascrivere in questo testo?
  const needs = (t) => /[^\p{Script=Latin}\p{Script=Common}\p{Script=Inherited}]/u.test(String(t || ""));
  const hasHan = (t) => RE.han.test(String(t || ""));

  function letters(word, table, extra) {
    return graphemes(word).map((g) => {
      // prima la lettera intera (й, ё, ї sono lettere a sé), poi senza accenti (ή → η)
      const whole = g.normalize("NFC").replace(/\u0301/g, "")[0] || g[0];
      const b = (extra && extra[whole.toLowerCase()] != null) || table[whole.toLowerCase()] != null ? whole : g.normalize("NFD")[0];
      const lo = b.toLowerCase();
      const r = (extra && extra[lo]) != null ? extra[lo] : table[lo];
      return { t: g, r: r == null ? "" : caps(b, r) };
    });
  }
  function hebrew(word) {
    return graphemes(word).map((g, k) => {
      const b = g[0], first = k === 0;
      let r = HEB[b];
      if (r == null) return { t: g, r: "" };
      if (g.includes("ּ") && HEB_DAGESH[b]) r = HEB_DAGESH[b];
      if (b === "ש" && g.includes("ׂ")) r = "s";
      if (b === "ו" && g.includes("ֹ")) return { t: g, r: "o" };
      if (b === "ו" && g.includes("ּ")) return { t: g, r: "u" };
      if (b === "ו" && g.length === 1 && !first) return { t: g, r: "o" };   // senza punti, in mezzo alla parola: di solito o/u
      for (const ch of g.slice(1)) if (HEB_VOW[ch] != null) r += HEB_VOW[ch];
      return { t: g, r };
    });
  }
  function arabic(word) {
    const cs = [...word];
    let out = "";
    const isHaraka = (c) => c in ARA_HARAKA || c === "ّ";
    for (let i = 0; i < cs.length; i++) {
      const c = cs[i], next = cs[i + 1], start = !out;
      if (c === "ـ") continue;                        // allungamento grafico
      if (c === "ّ") { const m = out.match(/(sh|th|kh|dh|gh|ch|zh|.)$/); if (m) out += m[1]; continue; }   // shadda: consonante doppia
      if (c in ARA_HARAKA) { out += ARA_HARAKA[c]; continue; }
      if (c === "ا") { out = start ? "a" : out.replace(/a$/, "") + "ā"; continue; }
      if (c === "ى") { out += "ā"; continue; }
      if (c === "و") { if (/u$/.test(out) && !(next && isHaraka(next))) { out = out.slice(0, -1) + "ū"; continue; } out += start || (next && isHaraka(next)) || /[aāiīuū]$/.test(out) ? "w" : "ū"; continue; }
      if (c === "ي" || c === "ی") { if (/i$/.test(out) && !(next && isHaraka(next))) { out = out.slice(0, -1) + "ī"; continue; } out += start || (next && isHaraka(next)) || /[aāiīuū]$/.test(out) ? "y" : "ī"; continue; }
      if (c === "ے") { out += "e"; continue; }
      out += ARA[c] != null ? ARA[c] : (/\p{L}/u.test(c) ? "" : c);
    }
    return [{ t: word, r: out }];
  }
  function devanagari(word, lang) {
    const cs = [...word];
    let out = "", pending = false;
    for (let i = 0; i < cs.length; i++) {
      const c = cs[i];
      if (c === "़") { const prev = cs[i - 1]; if (DEV_NUKTA[prev]) out = out.slice(0, -(DEV_C[prev] || "").length) + DEV_NUKTA[prev]; continue; }
      if (DEV_C[c] != null) { if (pending) out += "a"; out += DEV_C[c]; pending = true; continue; }
      if (DEV_M[c] != null) { out += DEV_M[c]; pending = false; continue; }
      if (c === "्") { pending = false; continue; }        // virama: niente vocale
      if (pending) { out += "a"; pending = false; }
      if (DEV_V[c] != null) out += DEV_V[c];
      else if (c === "ं") out += "ṃ";
      else if (c === "ँ") out += "̃";
      else if (c === "ः") out += "ḥ";
    }
    // in hindi (e marathi) la "a" finale di solito non si pronuncia
    if (pending && !(["hi", "mr", "ne"].includes(base(lang)) && cs.length > 1)) out += "a";
    return [{ t: word, r: out }];
  }
  function kana(word) {
    const cs = [...word];
    const units = [];
    for (let i = 0; i < cs.length; i++) {
      const c = cs[i], h = kanaToHira(c);
      if (RE.han.test(c)) { units.push({ t: c, r: "", han: true }); continue; }
      if (c === "ー" && units.length) { const u = units[units.length - 1]; const L = { a: "ā", e: "ē", i: "ī", o: "ō", u: "ū" }; u.t += c; u.r = u.r.replace(/[aeiou]$/, (v) => L[v]); continue; }
      if ((h === "っ") && i + 1 < cs.length && HIRA[kanaToHira(cs[i + 1])]) { units.push({ t: c, r: "", sokuon: true }); continue; }
      let r = HIRA[h];
      if (r == null) { units.push({ t: c, r: "" }); continue; }
      const nx = cs[i + 1] && kanaToHira(cs[i + 1]);
      if (nx && SMALL_Y.has(nx) && /i$/.test(r) && r !== "i") {
        const b = r.slice(0, -1), v = HIRA[nx].slice(1);
        r = /(sh|ch|j)$/.test(b) ? b + v : b + "y" + v;
        units.push({ t: c + cs[i + 1], r }); i++; continue;
      }
      if (nx && SMALL_V.has(nx)) {
        const v = HIRA[nx];
        if (/u$/.test(r)) r = (r === "u" ? "w" : r.slice(0, -1)) + v;
        else if (/e$/.test(r) && v === "i") r = r.slice(0, -1) + "i";
        else if (/i$/.test(r) && v === "e") r = r.slice(0, -1) + "e";
        else r += v;
        units.push({ t: c + cs[i + 1], r }); i++; continue;
      }
      units.push({ t: c, r });
    }
    // っ / ッ: raddoppia la consonante dopo (unita alla sillaba che segue)
    for (let i = 0; i < units.length; i++) {
      const u = units[i];
      if (!u.sokuon || !units[i + 1]) continue;
      const n = units[i + 1];
      n.t = u.t + n.t;
      n.r = (n.r.startsWith("ch") ? "t" : n.r[0] || "") + n.r;
      units.splice(i, 1); i--;
    }
    return units.map((u) => ({ t: u.t, r: u.r, han: !!u.han }));
  }
  function korean(word) {
    return [...word].map((c) => {
      const n = c.codePointAt(0) - 0xAC00;
      if (n < 0 || n > 11171) return { t: c, r: "" };
      return { t: c, r: KO_L[Math.floor(n / 588)] + KO_V[Math.floor((n % 588) / 28)] + KO_T[n % 28] };
    });
  }

  function units(word, lang) {
    word = String(word || "");
    const s = scriptOf(word);
    if (s === "cyr") return letters(word, CYR, CYR_LANG[base(lang)]);
    if (s === "gre") return letters(word, GRE);
    if (s === "arm") return letters(word.replace(/ու/g, "\u0000"), ARM).map((u) => (u.t === "\u0000" ? { t: "ու", r: "u" } : u));
    if (s === "geo") return letters(word, GEO);
    if (s === "heb") return hebrew(word);
    if (s === "ara") return arabic(word);
    if (s === "dev") return devanagari(word, lang);
    if (s === "kana" || s === "han") return kana(word);
    if (s === "ko") return korean(word);
    return [{ t: word, r: "" }];
  }
  // Parola con kanji/caratteri cinesi e la sua lettura (Jisho in kana, oppure Google in lettere latine): i kanji non
  // hanno una lettura fissa, ma con quella della parola intera si può scrivere sopra ogni gruppo di kanji.
  // Giapponese: la lettura in kana si allinea con le parti in kana della parola (食べる + たべる → 食 "ta", べ "be", る "ru").
  function withReading(w, lang, reading) {
    w = String(w || "");
    const us = units(w, lang), rd = String(reading || "").trim();
    if (!rd || !us.some((u) => u.han)) return us;
    const allHan = us.every((u) => u.han);
    if (!/[\p{Script=Hiragana}\p{Script=Katakana}]/u.test(rd)) return allHan ? [{ t: w, r: rd.toLowerCase(), han: false }] : us;
    const runs = [];
    for (const u of us) { const last = runs[runs.length - 1]; if (last && last.han === !!u.han) last.us.push(u); else runs.push({ han: !!u.han, us: [u] }); }
    const hira = (x) => [...x].map(kanaToHira).join("");
    const esc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const m = new RegExp("^" + runs.map((r) => (r.han ? "(.+?)" : esc(hira(r.us.map((u) => u.t).join(""))))).join("") + "$", "u").exec(hira(rd));
    if (!m) return allHan ? [{ t: w, r: kana(rd).map((u) => u.r).join(""), han: false }] : us;
    const out = [];
    let k = 1;
    for (const r of runs) {
      if (!r.han) { out.push(...r.us); continue; }
      out.push({ t: r.us.map((u) => u.t).join(""), r: kana(m[k++]).map((u) => u.r).join(""), han: false });
    }
    return out;
  }
  // tutta la parola in lettere latine (per i titoli e le prove)
  const word = (w, lang) => units(w, lang).map((u) => u.r || (u.han ? "" : u.t)).join("");
  const rtl = (t) => RE.heb.test(t) || RE.ara.test(t);
  // le lettere legate (arabo, devanagari): una sola trascrizione per tutta la parola
  const joined = (t) => RE.ara.test(t) || RE.dev.test(t);
  return { units, withReading, word, needs, hasHan, rtl, joined, scriptOf };
})();

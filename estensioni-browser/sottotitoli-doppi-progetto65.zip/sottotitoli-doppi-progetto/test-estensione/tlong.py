# 1.7.13: testo lungo letto per intero (a pezzi), limite dei modelli: il pulsante «Spiega» resta
import asyncio, sys, datetime
sys.path.insert(0, "/home/claude/e2e")
from charness import *
LONG = "Prima frase del testo evidenziato. " + "Seconda frase, un po' più lunga, con una virgola e altre parole per arrivare lontano. " * 2 + "Terza frase finale che non deve essere persa!"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'en', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1000)
        r = await pp.evaluate("(t) => DS_TTS.speak(t, 'it', {voice: 'google'}).then(async r => { await r.done; return r.how; })", LONG)
        qs = [q for _tl, q in log.get("tts", [])]
        print("1. richieste a Google:", len(qs), "| lunghezza massima:", max(map(len, qs)), "| testo coperto:", " ".join(qs).replace("  ", " ")[-40:], "|", r)
        ok1 = len(qs) >= 2 and max(map(len, qs)) <= 190 and qs[-1].endswith("persa!")
        # limite dei modelli: il pulsante resta
        print("   modelli gemini:", await sw.evaluate("JSON.stringify((typeof C !== 'undefined' ? C : DS_CONFIG).ENGINES.gemini).slice(0, 600)"))
        await sw.evaluate("""(async () => { const day = new Date().toLocaleDateString('en-CA', {timeZone: 'America/Los_Angeles'}); const o = {};
          for (const k of ['gemini', 'gemini|gemini-flash-lite-latest', 'gemini|gemini-flash-latest', 'gemini|gemini-2.5-flash', 'gemini|gemini-2.5-flash-lite', 'gemini|gemini-2.0-flash', 'gemini|gemini-3-flash-preview', 'gemini|gemini-2.5-pro']) o[k] = {day, at: Date.now()};
          await chrome.storage.local.set({dsBlocked: o}); })()""")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        btns = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-explainbtn')].map(b => b.textContent + ' | ' + b.className)")
        print("2. pulsante con i limiti finiti:", btns)
        await pg.locator(".dualsub-card .dualsub-explainbtn").click(); await pg.wait_for_timeout(3500)
        print("3. dopo «riprova»:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card button')].map(b => b.textContent).filter(t => /Spiega|Rifai/.test(t))"), "| fonte:", await pg.evaluate("(document.querySelector('.dualsub-card-source')||{}).textContent"))
        print("errori:", errs if ok1 and btns else errs + ["non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

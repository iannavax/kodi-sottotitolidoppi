# Sottotitoli Doppi 5.8.4 (Firefox)

## Aggiornare senza perdere chiavi e vocabolario
Apri `about:addons`, clicca l'ingranaggio, poi **Installa componente aggiuntivo da file…**, e scegli il nuovo file .xpi. **Non rimuovere prima la versione vecchia:** Firefox la aggiorna e mantiene chiavi, traduzioni salvate e vocabolario.

Questa versione funziona su tutti i siti, quindi chiede un permesso in più. Se nel popup compare **Concedi accesso**, cliccalo e accetta.

## Prima installazione (Firefox Nightly o Developer Edition)
1. In `about:config` cerca `xpinstall.signatures.required` e mettilo su **false**.
2. In `about:addons` clicca l'ingranaggio, poi **Installa componente aggiuntivo da file…**, e scegli `sottotitoli-doppi-firefox-v5.8.4.xpi`.
3. Fissa l'estensione nella barra (icona del puzzle). Se nel popup compare **Concedi accesso**, cliccalo.


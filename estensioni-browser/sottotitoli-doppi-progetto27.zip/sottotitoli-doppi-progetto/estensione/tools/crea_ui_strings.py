# Crea estensione/src/ui-strings.json: le scritte dell'interfaccia (in italiano) di Sottotitoli Doppi, Parole al Volo
# e dell'estensione unica, prese dal codice. Servono a ui-i18n.js per tradurre SOLO l'interfaccia nella lingua di
# «Traduci in» (le parole, le traduzioni e i testi dei siti non sono in questo elenco, quindi non si toccano).
# Uso: python3 estensione/tools/crea_ui_strings.py   (va rifatto quando cambiano le scritte; lo fa build.sh)
import json, os, re, html
from html.parser import HTMLParser
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DIRS = ["estensione/src", "parole-al-volo/src", "unica/src"]
SKIP = {"han-data.json", "pdf-enc.js", "ui-strings.json"}
exact, templates = set(), set()
CODE = re.compile(r"(\bthrow\b|\bif \(|===|!==|&&|\|\||\$\{|\bawait\b|\breturn\b|\bconst\b|\blet\b|\.then\(|=>|\bfunction\b|querySelector|getElementById|https?://|\bvar\(|^\.|^#|[{};]\s*$|^\s*[a-z-]+\s*:\s*[^ ]+;|\\[nt]|\.(js|css|html|json|png|mp3|wav)\b|^[a-z][a-zA-Z0-9]*$|^[a-z0-9_-]+$|^[A-Z_0-9]+$|^\W*$)")
ITALIAN = re.compile(r"[àèéìòù]|\b(sostantivo|verbo|aggettivo|avverbio|pronome|preposizione|congiunzione|interiezione|articolo|numerale|particella|maschile|femminile|neutro|comune|raro|plurale|singolare|meno|altre|livello|uso|salvat[ae]|spiegazion[ei]|albero|etimologico|radice|forme|esempi|sinonimi|contrari|il|la|lo|le|gli|un|una|di|da|del|della|che|non|per|con|su|nel|nella|è|questo|questa|tutte?|parol[ae]|frase|scheda|video|traduzion[ei]|lingua|salva|copia|chiave|apri|mostra|cerca|rifai|togli|spegni|accendi|pagina|sottotitoli|vocabolario|prova|richiest[ae]|servizio|modello|niente|nessun[ao]?|altre|altri|anche|solo|come|quando|dove|perché|ancora|adesso|sempre|oppure|sì|no)\b", re.I)
# parole sole in minuscolo dell'interfaccia (parti del discorso, genere, uso…): sembrerebbero nomi di variabili
UIWORDS = {"sostantivo", "verbo", "aggettivo", "avverbio", "pronome", "preposizione", "congiunzione", "interiezione", "articolo",
           "numerale", "particella", "maschile", "femminile", "neutro", "comune", "raro", "rara", "plurale", "singolare", "meno",
           "uso", "livello", "esempio", "traduci", "lenta", "lento", "ascolta", "copia", "salva", "cerca", "apri", "togli", "rifai", "esempi", "sinonimi", "contrari", "nome", "frase", "parola", "chiudi", "altro", "altre"}
def keep(s):
    t = s.strip()
    if t.lower() in UIWORDS: return True
    if len(t) < 2 or len(t) > 400 or not re.search(r"[A-Za-zÀ-ÿ]", t): return False
    if CODE.search(t): return False
    if re.search(r"[<>]", t) and not re.search(r"\s", t): return False
    # una parola sola: solo se ha la maiuscola o un accento o è una parola italiana dell'interfaccia
    first = next((c for c in t if c.isalpha()), "")
    if not re.search(r"\s", t) and not (first.isupper() or re.search(r"[àèéìòù]", t) or ITALIAN.search(t)): return False
    if bool(ITALIAN.search(t)) or (first.isupper() and re.search(r"\s", t)) or len(t.split()) == 1: return True
    # più parole in minuscolo («spiegazioni salvate», «in questa frase»): frase normale, non codice
    words = re.findall(r"[A-Za-zÀ-ÿ]{2,}", t)
    return len(words) >= 2 and sum(len(w) for w in words) >= 8 and not re.search(r"[=<>{}\[\]$]", t)
EDGE = re.compile(r"^[^A-Za-zÀ-ÿ]*(.*?)[^A-Za-zÀ-ÿ]*$", re.S)
def add(s):
    s = html.unescape(s).replace("\\'", "'").replace('\\"', '"')
    # pezzi separati da tag o da "\n" nelle stringhe con HTML: ognuno è un testo a sé nella pagina
    for part in re.split(r"<[^>]+>|\\n|\n", s):
        p = part.strip(" \t·|—–:,;").strip()
        if keep(p): exact.add(p)
        # anche senza simboli e numeri ai bordi («✓ Scritta correttamente (» → «Scritta correttamente»), e i pezzi
        # tra «·», «—», «(»… : ui-i18n.js li cerca così quando la scritta intera non c'è
        core = EDGE.match(p).group(1)
        if core != p and keep(core): exact.add(core)
        for q in re.split(r"\s*[·—–|•›‹▾▴()«»]\s*|:\s+", p):
            q = EDGE.match(q.strip()).group(1)
            if q != p and keep(q): exact.add(q)
        # spesso il testo nella pagina ha i due punti o uno spazio in fondo ("Modo di dire: ")
        if keep(part.strip()): exact.add(part.strip())
def add_tpl(s):
    parts = re.split(r"\$\{(?:[^{}]|\{[^{}]*\})*\}", s)
    if len(parts) == 1: return add(s)
    for p in parts: add(p)   # i pezzi fissi da soli (quando la variabile finisce in un nodo diverso)
    n = [0]
    def ph(m): n[0] += 1; return "{" + str(n[0] - 1) + "}"
    t = re.sub(r"\$\{(?:[^{}]|\{[^{}]*\})*\}", ph, s).strip()
    for piece in re.split(r"<[^>]+>|\\n", t):
        piece = piece.strip()
        if "{" in piece and keep(re.sub(r"\{\d+\}", "x", piece)) and len(re.sub(r"\{\d+\}|\W", "", piece)) >= 3: templates.add(piece)
STR = re.compile(r'"((?:[^"\\\n]|\\.)*)"|\'((?:[^\'\\\n]|\\.)*)\'|`((?:[^`\\]|\\.)*)`', re.S)
class H(HTMLParser):
    def __init__(self): super().__init__(); self.skip = 0
    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"): self.skip += 1
        for k, v in attrs:
            if k in ("title", "placeholder", "aria-label", "alt", "label") and v: add(v)
            if k == "value" and v and re.search(r"\s", v): add(v)
    def handle_endtag(self, tag):
        if tag in ("script", "style"): self.skip -= 1
    def handle_data(self, d):
        if not self.skip and d.strip(): add(d)
for d in DIRS:
    for f in sorted(os.listdir(os.path.join(ROOT, d))):
        p = os.path.join(ROOT, d, f)
        if f in SKIP or not os.path.isfile(p): continue
        src = open(p, encoding="utf-8").read()
        if f.endswith(".html"):
            H().feed(src)
            for m in re.finditer(r"<script>(.*?)</script>", src, re.S): src2 = m.group(1)
        elif f.endswith(".js"):
            # niente commenti (// … e /* … */), poi tutte le stringhe
            body = re.sub(r"/\*.*?\*/", "", src, flags=re.S)
            body = "\n".join(re.sub(r"(^|[^:\\\"'`])//.*$", r"\1", l) for l in body.split("\n"))
            # scritte fatte di pezzi: "Definizioni in " + nome + ": " → modello "Definizioni in {0}:"
            Q = r'"((?:[^"\\\n]|\\.)*)"'
            EXPR = r"[\w.$\[\]()]+(?:\([^()\n]*\))?"
            for m in re.finditer(Q + r"\s*\+\s*(" + EXPR + r")\s*\+\s*" + Q, body):
                if re.search(r"[A-Za-zÀ-ÿ]", m.group(1) + m.group(3)): add_tpl(m.group(1) + "${x}" + m.group(3))
            for m in re.finditer(Q + r"\s*\+\s*(" + EXPR + r")\s*[,;)]", body):
                if re.search(r"[A-Za-zÀ-ÿ]{3}", m.group(1)): add_tpl(m.group(1) + "${x}")
            for m in STR.finditer(body):
                if m.group(3) is not None: add_tpl(m.group(3))
                else: add(m.group(1) if m.group(1) is not None else m.group(2))
# scritte composte in modo che qui non si riconoscono (con ?: in mezzo)
for t in ["Definizioni in {0}:"]: templates.add(t)
out = {"exact": sorted(exact), "templates": sorted(templates)}
dst = os.path.join(ROOT, "estensione/src/ui-strings.json")
json.dump(out, open(dst, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
print(f"ui-strings.json: {len(exact)} scritte, {len(templates)} modelli, {os.path.getsize(dst) // 1024} KB")

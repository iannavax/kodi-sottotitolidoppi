# Popup unico dell'estensione unica: quello di Sottotitoli Doppi con dentro la sezione «Pagine e PDF» di Parole al Volo
# (id con «p-», codice di Parole al Volo chiuso in una funzione e con $ che cerca «p-…»: niente nomi in conflitto).
# Uso: python3 make-popup.py <cartella della build>
import re, sys
out = sys.argv[1]
sd = open("../estensione/src/popup.html", encoding="utf-8").read()
part = open("src/popup-pagine-part.html", encoding="utf-8").read()
pieces = dict(re.findall(r"<!--(SWITCH|PAGES|MORE)-->\n(.*?)(?=<!--(?:SWITCH|PAGES|MORE)-->|\Z)", part, re.S))
for k, tag in (("SWITCH", "<!--UNICA-SWITCH-->"), ("PAGES", "<!--UNICA-PAGES-->"), ("MORE", "<!--UNICA-MORE-->")):
    assert tag in sd, tag
    sd = sd.replace(tag, pieces[k].rstrip("\n"))
sd = sd.replace('<script src="voices-ui.js"></script>', '<script src="voices-ui.js"></script>\n  <script src="volo-config.js"></script>\n  <script src="unica-pav.js"></script>\n  <script src="popup-pagine.js"></script>')
sd = sd.replace("<head>", "<head>\n<title>Sottotitoli Doppi + Parole al Volo</title>", 1)
open(out + "/popup.html", "w", encoding="utf-8").write(sd)
js = open("../parole-al-volo/src/popup.js", encoding="utf-8").read()
js = js.replace("DS_EXT.storage.sync", "PAV_SYNC").replace("DS_EXT.storage.onChanged", "PAV_ONCHANGED")
js = js.replace('const $ = (id) => document.getElementById(id);',
  'const pavDummy = {};\n// gli elementi che nel popup unico non ci sono (lingua, voce, Anki, chiavi…: sono nelle sezioni in comune) restano finti\n'
  'const $ = (id) => document.getElementById("p-" + id) || (pavDummy[id] = pavDummy[id] || (() => { const sel = /Lang$|^mode$|^delay$|^ttsVoice$|^ankiImageSource$/.test(id); const d = document.createElement(sel ? "select" : "input"); if (!sel) d.type = "checkbox"; const w = document.createElement("label"); w.className = "row"; w.append(d); return d; })());')
js = js.replace('document.getElementById("ankiImageSource")', '$("ankiImageSource")')
js = js.replace('document.querySelectorAll("[data-show]")', 'document.querySelectorAll("#p-dPages [data-show]")')
open(out + "/popup-pagine.js", "w", encoding="utf-8").write("// Parole al Volo nel popup unico (generato da unica/make-popup.py)\n(() => {\n" + js + "\n})();\n")
print("popup unico:", out)

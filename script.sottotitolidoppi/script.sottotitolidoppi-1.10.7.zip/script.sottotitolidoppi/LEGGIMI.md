# Sottotitoli Doppi per Kodi

*English version → [GUIDE.en](GUIDE.en.md)*

**Impara le lingue guardando film e serie su Kodi.** L'add-on crea sottotitoli con **due righe**: sopra la frase originale, sotto la traduzione nella tua lingua, in un altro colore.

Prende i sottotitoli originali da dove li trova: dentro il film che stai guardando (anche in streaming, con The Crew e Real-Debrid), da un file accanto al video, da OpenSubtitles. Se non ce ne sono, ascolta l'audio e li scrive con Whisper. Poi li traduce con il servizio che scegli, e salva tutto: rivedere un film non costa niente.

Funziona su Kodi 19 e successivi (Windows, Mac, Linux, box Android, Fire TV).

---

## Indice

1. [Cosa fa, in breve](#1-cosa-fa-in-breve)
2. [Installazione e aggiornamenti](#2-installazione-e-aggiornamenti)
3. [Primi passi (5 minuti)](#3-primi-passi-5-minuti)
4. [Come si usa](#4-come-si-usa)
5. [Da dove prende i sottotitoli originali](#5-da-dove-prende-i-sottotitoli-originali)
6. [La traduzione](#6-la-traduzione)
7. [La trascrizione dell'audio (Whisper)](#7-la-trascrizione-dellaudio-whisper)
8. [Salvare e condividere i sottotitoli](#8-salvare-e-condividere-i-sottotitoli)
9. [Tradurre con una chat, senza quote](#9-tradurre-con-una-chat-senza-quote)
10. [Tutte le impostazioni](#10-tutte-le-impostazioni)
11. [Se qualcosa non va](#11-se-qualcosa-non-va)
12. [Limiti](#12-limiti)

---

## 1. Cosa fa, in breve

| Funzione | Cosa fa |
|---|---|
| 🎬 **Doppia riga** | Un file di sottotitoli con l'originale e la traduzione colorata (o solo la traduzione, o la traduzione sopra). |
| 📦 **Sottotitoli dentro il film in streaming** | Legge le tracce di sottotitoli dentro i .mkv di Real-Debrid & co. **senza scaricare il film**. |
| 🌐 **OpenSubtitles e servizi di Kodi** | Se il film non ha sottotitoli, li cerca online nella lingua del film. |
| 🎙️ **Trascrizione dell'audio** | Con Whisper (gratis con una chiave Groq), nella lingua giusta, ripresa da dove si era fermata. |
| 🧠 **Traduzione** | Google (gratis) o modelli che capiscono il discorso: Gemini, Groq, Mistral, OpenRouter, Claude, un modello sul computer; oppure Microsoft Translator e DeepL. |
| 🤝 **Traduzioni già fatte da persone** | Se esistono i sottotitoli del film nella tua lingua, li mette in fase con l'originale e li usa (gratis). |
| 💾 **Memoria** | Ogni frase tradotta viene salvata subito: niente si traduce due volte. |
| 🔁 **Servizi di riserva** | Se un servizio gratuito finisce le richieste del giorno, si passa da soli al successivo. |
| 🌍 **82 lingue** | Traduce in qualsiasi lingua, anche quella di Kodi. |
| 💬 **Con una chat** | Esporta il testo, fallo tradurre a ChatGPT/Claude/Gemini, importa la risposta. |

---

## 2. Installazione e aggiornamenti

L'add-on è fatto di due parti, entrambe nella confezione: **Sottotitoli Doppi** (l'add-on vero e proprio) e **Sottotitoli Doppi per il lettore** (la voce nel menu Sottotitoli, per sceglierli durante il film). Installale tutte e due.

### Installazione
1. In Kodi: **Impostazioni → Sistema → Add-on** e attiva **Sorgenti sconosciute** (conferma l'avviso). Serve per installare add-on da un file.
2. Copia i due file .zip su una chiavetta USB o in una cartella che Kodi vede.
3. **Impostazioni → Add-on → Installa da un file zip**: scegli prima `script.sottotitolidoppi-….zip`, poi `service.subtitles.sottotitolidoppi-….zip`.
4. Kodi conferma con un avviso in alto a destra. L'add-on si trova in **Add-on → Programmi → Sottotitoli Doppi**.

### Aggiornamenti
Installa lo zip della versione nuova **sopra** quello vecchio, nello stesso modo: impostazioni, traduzioni e trascrizioni salvate restano. Non disinstallare l'add-on per aggiornarlo.

### ffmpeg (solo per la trascrizione dell'audio)
Kodi non lascia agli add-on leggere l'audio, quindi per trascrivere serve **ffmpeg**:
- **Windows**: `winget install ffmpeg` (o da gyan.dev). Se l'add-on non lo trova, indica il percorso di `ffmpeg.exe` nelle impostazioni.
- **Mac**: `brew install ffmpeg`. **Linux**: dal gestore dei pacchetti.
- **Box Android / Fire TV**: di solito ffmpeg non c'è: lì usa i sottotitoli esistenti.

---

## 3. Primi passi (5 minuti)

1. Apri le impostazioni dell'add-on: **Add-on → Programmi → Sottotitoli Doppi** → tasto menu (o clic destro) → **Impostazioni**.
2. **Generale → Traduci in**: la tua lingua.
3. **Traduzione → Servizio**: lascia **google** per cominciare senza chiavi, oppure (consigliato, gratis):
   - crea una chiave su **aistudio.google.com/apikey**;
   - scegli **gemini** e incolla la chiave in **Chiave Gemini**.
4. Fai partire un film con i sottotitoli nella lingua originale. Dopo pochi secondi compaiono quelli doppi.

Mentre l'add-on lavora, **in alto a destra c'è una barra** che dice cosa sta facendo (per esempio "Leggo i sottotitoli dentro il video: 120 su 987", poi la traduzione). Finché c'è la barra non serve farlo ripartire.

**Per i film senza sottotitoli**: crea una chiave gratuita su **console.groq.com/keys**, incollala in **Traduzione → Chiave Groq**, installa ffmpeg e attiva **Trascrizione → In automatico, se mancano i sottotitoli, trascrivi l'audio**.

---

## 4. Come si usa

### In automatico
Con **Generale → Crea i sottotitoli doppi da solo quando parte un video** (attivo di serie), pochi secondi dopo l'inizio di un film l'add-on trova i sottotitoli originali, li traduce **a partire dal punto in cui sei** e li carica nel lettore. Il resto si completa mentre guardi.

### Dal menu dei sottotitoli del lettore
Durante il film: **Sottotitoli → Scarica → Sottotitoli Doppi**. L'elenco mostra tutti i sottotitoli originali trovati (per esempio "Doppi: danese → italiano · dentro il video: danese"), più la trascrizione dell'audio. Scegline uno: in pochi secondi è pronto (con Google subito; con Gemini prima una versione rapida, poi quella migliore da sola). La scelta viene ricordata per quel film.

### Dal menu dell'add-on
**Add-on → Programmi → Sottotitoli Doppi**, mentre il film è in riproduzione (puoi anche assegnarlo a un tasto del telecomando con "Keymap Editor"):

| Voce | Cosa fa |
|---|---|
| **Crea i sottotitoli doppi per il video in riproduzione** | Come in automatico, subito. |
| **Scegli originale e traduzione per questo video…** | Scegli a mano da dove prendere l'originale (automatico, trascrizione, un file preciso) e quale traduzione usare. Ricordato per il film. |
| **Scegli i sottotitoli originali da tradurre…** | L'elenco di tutti i sottotitoli originali trovati (dentro il video, scaricati, accanto al video, OpenSubtitles, trascrizione) più un file dal dispositivo: scegli e la traduzione parte subito da quelli. |
| **Controlla i sottotitoli dentro il video** | Mostra le tracce di sottotitoli del film e se si possono leggere. |
| **Rifai la trascrizione da capo** | Se una trascrizione è venuta male. |
| **Rifai la traduzione da capo** | Ignora quella salvata e la richiede tutta (consuma richieste). |
| **Salva i sottotitoli (.srt)…** | Originale, traduzione e doppio in una cartella ([sezione 8](#8-salvare-e-condividere-i-sottotitoli)). |
| **Esporta trascrizione / Importa traduzione (.txt)** | Traduzione con una chat ([sezione 9](#9-tradurre-con-una-chat-senza-quote)). |
| **Impostazioni** | |

---

## 5. Da dove prende i sottotitoli originali

In automatico, in quest'ordine (per i film in streaming .mkv si parte dal punto 2: le tracce dentro il video sono proprio quelle del file che stai guardando):
1. **Sottotitoli che ha già il film**: file accanto al video (`Film.en.srt`, anche nella cartella `Subs`), sottotitoli dati dall'add-on video, sottotitoli scaricati da poco con gli add-on di Kodi. Quelli già nella tua lingua vengono esclusi.
2. **Dentro il file video**:
   - film sul dispositivo: tracce di testo lette con ffmpeg;
   - **film in streaming .mkv** (The Crew, Real-Debrid…): l'add-on legge l'indice del file e poi solo i pezzetti con le frasi. Bastano pochi megabyte, senza scaricare il film e senza bisogno di nessun account. Sceglie la traccia nella lingua dei sottotitoli accesi nel lettore (poi dell'audio, poi del film) e salta quelle "forzate". La prima volta ci vuole un po' (una richiesta per frase: per un film intero di solito uno o due minuti, la barra in alto a destra mostra a che punto è); poi restano salvati e la volta dopo sono subito pronti.
3. **Real-Debrid** (streaming HLS): con il token di Real-Debrid (preso da solo da ResolveURL, o da inserire nelle impostazioni).
4. **OpenSubtitles**, nella lingua dell'audio del film (riconosciuto dal codice IMDb o dal nome del file), e poi gli altri servizi di sottotitoli installati in Kodi (per esempio OpenSubtitles.com).
5. **La trascrizione dell'audio**, se attiva.

**Scegliere a mano**: menu dell'add-on → **Scegli i sottotitoli originali da tradurre…**. Compare l'elenco di tutto quello che è stato trovato: per primi i sottotitoli **dentro il video** (anche quelli di Real-Debrid), poi quelli scaricati e OpenSubtitles, la trascrizione e in fondo **Scegli un file dal dispositivo…**. Quelli in uso adesso sono segnati con ►. Scegli e la traduzione parte subito da quelli; la scelta resta ricordata per quel film. Le frasi già tradotte vengono riusate, quindi cambiare originale non rifà tutto da capo. Lo stesso elenco compare anche in **Scegli originale e traduzione per questo video…** → *File di sottotitoli* e nel menu Sottotitoli del lettore.

**Impostazione "Testo originale da"** (sezione Trascrizione): *auto* (come sopra), *trascrizione* (sempre l'audio) o *file* (mai la trascrizione).

---

## 6. La traduzione

### I servizi
Si scelgono in **Traduzione → Servizio**; ognuno ha la sua chiave nella stessa sezione.

| Servizio | Costo | Note |
|---|---|---|
| google | gratis, senza chiave | discreto, riga per riga |
| **gemini** ⭐ | gratis con chiave (aistudio.google.com/apikey) | ottimo, capisce il discorso |
| groq | gratis con chiave (console.groq.com/keys) | buono e velocissimo; la stessa chiave serve per la trascrizione |
| mistral | gratis con chiave (console.mistral.ai) | buono, ottimo per le lingue europee |
| openrouter | gratis con chiave (modelli ":free") | qualità variabile |
| microsoft | gratis fino a 2 milioni di caratteri al mese | traduttore classico preciso; serve la chiave e l'area di una risorsa "Translator" F0 su Azure |
| deepl | gratis fino a un limite mensile | molto alto |
| claude | a pagamento | ottimo |
| local | gratis | Ollama o LM Studio sul computer |

Le frasi si traducono **a gruppi di 120** con le vicine come contesto (un film di due ore ≈ 12 richieste a Gemini), cominciando dal punto in cui sei. Le traduzioni ricopiate, spostate o nella lingua sbagliata vengono riconosciute e rifatte.

### Servizi di riserva
Con **Se finiscono le richieste gratuite, continua con un altro servizio di cui hai la chiave** (attivo di serie), quando un servizio esaurisce la quota del giorno si passa al primo altro di cui hai inserito la chiave: **Gemini → Groq → Mistral → OpenRouter → Microsoft → DeepL**, poi **Google**. Quello esaurito viene saltato fino al giorno dopo (le quote di Gemini si azzerano verso le 9 del mattino, ora italiana).

### La memoria delle traduzioni
Ogni frase tradotta viene salvata **subito**, gruppo per gruppo:
- se fermi il film a metà, la volta dopo si traducono solo le frasi mancanti;
- passando dalla trascrizione a un file di sottotitoli (o tornando indietro) le frasi uguali non si traducono di nuovo;
- ogni servizio ha la sua memoria: provando Google e tornando a Gemini, le frasi di Gemini ci sono ancora.

In **Scegli originale e traduzione** la voce *"Con Gemini: usa le frasi già tradotte…"* dice quante frasi sono già salvate; *"Rifai da capo"* le richiede tutte.

### Tipo di traduzione (impostazione "Traduzione")
- **auto**: traduzione già fatta da persone quando l'originale è un file di sottotitoli e le due versioni vanno in fase, altrimenti nuova;
- **nuova**: sempre con il servizio scelto (usando la memoria);
- **pronta**: sottotitoli tradotti da persone, se ci sono;
- **chat**: quella importata da una chat ([sezione 9](#9-tradurre-con-una-chat-senza-quote)).

### Traduzioni già fatte da persone
Se per il film esistono i sottotitoli nella tua lingua (un file `.it.srt` accanto al video, quelli scaricati, OpenSubtitles), l'add-on li **mette in fase** con l'originale: calcola da solo il ritardo e la velocità diversa (25 o 23,976 fotogrammi al secondo), e rifà la messa in fase se un'edizione ha scene in più. Sotto ogni frase originale mette quella tradotta corrispondente. Le frasi senza corrispondenza le traduce Google. Se le due versioni non vanno in fase, non le usa.

*Da sapere*: i sottotitoli fatti da persone sono naturali ma a volte liberi o accorciati; quelli dei modelli sono più letterali.

### Lingua di arrivo
**Generale → Traduci in**: 82 lingue, oppure **kodi** (la lingua di Kodi), oppure **altra** e scrivi la sigla o il nome in **Altra lingua** (per esempio `yue`, `ceco`, `Czech`).

---

## 7. La trascrizione dell'audio (Whisper)

Per i film senza sottotitoli, o quando vuoi il testo esatto di quello che si sente.

**Preparazione**: chiave Groq (gratis, console.groq.com/keys) in **Traduzione → Chiave Groq**, e ffmpeg installato ([sezione 2](#2-installazione-e-aggiornamenti)). In alternativa: **Trascrizione con → openai** (a pagamento) o **local** (un server Whisper sul computer).

**Come funziona**:
- l'audio viene trascritto a pezzi da 10 minuti (un film di due ore ≈ 12 richieste a Groq);
- **la lingua si fissa una volta sola** e poi viene imposta a Whisper per tutti i pezzi. Viene presa da *Lingua parlata* (se l'hai scelta), dalla traccia audio, dalla lingua originale del film (catalogo Cinemeta) o dal primo pezzo con abbastanza parlato. Così Whisper non cambia lingua e non scrive la traduzione in inglese al posto della trascrizione;
- i **tempi delle singole parole** fanno partire ogni sottotitolo quando parte la voce;
- le **parti con voce rimaste senza sottotitoli** vengono riascoltate da sole;
- le frasi inventate durante la musica vengono scartate;
- **trascrizione più precisa** (attiva di serie): con Groq si usa whisper-large-v3 invece della versione turbo.

**Salvataggio**: la trascrizione viene salvata con il nome del film (anche se Real-Debrid cambia il link) e **pezzo per pezzo**: fermando il film a metà, la volta dopo riprende da dove era. Rivedendo il film non si consuma niente. Se una trascrizione è venuta male: menu → **Rifai la trascrizione da capo**.

---

## 8. Salvare e condividere i sottotitoli

Menu dell'add-on → **Salva i sottotitoli (.srt) per riusarli o condividerli…** Salva l'ultimo film in tre file:
- `Titolo.en.srt`: l'originale (anche la trascrizione);
- `Titolo.it.srt`: solo la traduzione;
- `Titolo.doppi.it.srt`: originale e traduzione insieme.

Puoi salvarli **accanto al video** (stesso nome del video: Kodi li mostra da solo e l'add-on li riusa senza rifare niente), nella cartella delle impostazioni o in una cartella scelta ogni volta (anche USB o rete).

In **Generale** puoi scegliere la cartella e attivare **Salva sempre una copia dei sottotitoli**.

---

## 9. Tradurre con una chat, senza quote

1. Menu dell'add-on → **Esporta trascrizione (.txt)**: scrive uno o più file di testo con le frasi numerate e le istruzioni (a parti di 250 frasi).
2. Sul computer apri il file, copia tutto e incollalo in una chat (ChatGPT, Claude, Gemini…).
3. Salva la risposta della chat in un file `.txt`.
4. Menu dell'add-on → **Importa traduzione (.txt)**: scegli il file (anche più parti insieme). La traduzione viene usata subito e resta salvata per il film.

---

## 10. Tutte le impostazioni

### Generale
| Impostazione | A cosa serve |
|---|---|
| Crea i sottotitoli doppi da solo quando parte un video | Funzionamento automatico. |
| Traduci in / Altra lingua | Lingua di arrivo ([sezione 6](#lingua-di-arrivo)). |
| Disposizione | Originale sopra, traduzione sopra, solo traduzione. |
| Cartella dove salvare / Salva sempre una copia | [Sezione 8](#8-salvare-e-condividere-i-sottotitoli). |
| Colore della traduzione | In esadecimale, per esempio `FFFF00` giallo, `00FFFF` azzurro. |

### Traduzione
| Impostazione | A cosa serve |
|---|---|
| Traduzione | auto / nuova / pronta / chat ([sezione 6](#tipo-di-traduzione-impostazione-traduzione)). |
| Servizio | Il servizio di traduzione. |
| Token di Real-Debrid | Solo per lo streaming HLS di Real-Debrid; vuoto = quello di ResolveURL. Non serve per leggere i .mkv. |
| Se finiscono le richieste gratuite… | Servizi di riserva. |
| Chiavi e modelli | Una casella per servizio; per Microsoft anche l'**area**. |

### Trascrizione (Whisper)
| Impostazione | A cosa serve |
|---|---|
| Testo originale da | auto / trascrizione / file. |
| In automatico, se mancano i sottotitoli, trascrivi l'audio | Trascrive da solo i film senza sottotitoli. |
| Riascolta le parti con voce rimaste senza sottotitoli | Recupera le frasi saltate da Whisper. |
| Trascrizione più precisa | whisper-large-v3 invece della versione turbo. |
| Trascrizione con | groq / openai / local. |
| Lingua parlata | auto, oppure la lingua del film se Whisper la sbaglia. |
| Percorso di ffmpeg | Se l'add-on non lo trova da solo. |

---

## 11. Se qualcosa non va

| Cosa succede | Cosa fare |
|---|---|
| "Non trovo sottotitoli originali" | Menu → **Scegli i sottotitoli originali da tradurre…** e scegli dall'elenco o un file dal dispositivo; oppure attiva la trascrizione. **Controlla i sottotitoli dentro il video** mostra cosa c'è nel film. |
| Prende i sottotitoli di OpenSubtitles e non quelli del film | Menu → **Scegli i sottotitoli originali da tradurre…** → quelli "dentro il video". Se nell'elenco non ci sono, menu → **Controlla i sottotitoli dentro il video**: se sono "PGS" o immagini, non sono testo e non si possono leggere. |
| "Letti N sottotitoli su M" | Il server dello streaming (per esempio Real-Debrid) ha interrotto la lettura dei sottotitoli dentro il video. Aspetta un minuto e rifai **Crea i sottotitoli doppi**: legge di nuovo e completa; le frasi già tradotte non si ritraducono. |
| Sottotitoli fuori sincrono | Dal menu del lettore prova un'altra versione, oppure scegli quelli dentro il video. |
| La trascrizione è nella lingua sbagliata | Imposta **Lingua parlata**, poi menu → **Rifai la trascrizione da capo**. |
| "Limite di richieste" o traduzione con Google invece che Gemini | Hai finito la quota del giorno: aggiungi le chiavi di altri servizi gratuiti (riserva) o aspetta le 9 del mattino. |
| ffmpeg non trovato | Installalo e, se serve, indica il percorso nelle impostazioni. |

**Il registro di Kodi**: per ogni problema, il file `kodi.log` contiene le righe che iniziano con `[Sottotitoli Doppi]`, con quello che l'add-on ha fatto e perché. Si trova in `%APPDATA%\Kodi\kodi.log` su Windows, oppure si carica con l'add-on *Kodi Logfile Uploader*.

---

## 12. Limiti

- Kodi mostra un solo sottotitolo alla volta: per questo l'add-on crea un file che contiene già le due righe. Non si possono toccare le parole come nell'estensione per il browser.
- I sottotitoli a **immagini** (PGS, VobSub, tipici dei Blu-ray "Remux") non sono testo: per quei film si usano OpenSubtitles o la trascrizione.
- Un .mkv in streaming si legge se il suo indice contiene i sottotitoli (succede quasi sempre); altrimenti andrebbe scaricato tutto.
- Sui dispositivi senza ffmpeg (box Android, Fire TV) non si può trascrivere l'audio né leggere i sottotitoli dei file locali.


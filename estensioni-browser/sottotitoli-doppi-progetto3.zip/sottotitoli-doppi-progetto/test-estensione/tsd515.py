# 5.15: clic veloce (Google subito, poi il modello), frase tradotta meglio, modi di dire (frase intera scartata, ⚑),
# definizioni traducibili, "vedi anche" cliccabile, niente pulsante Anki, niente "⚠ false"
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
os.environ["ALIGN_WHOLE"] = "1"; os.environ["GEM_DELAY"] = "3"
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', ipa:true, hoverPause:true, idioms:true, learnExamples:false, learnSpell:false})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=sd515"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini'})"); await pg.wait_for_timeout(500)
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        W = lambda t: words.nth(texts.index(t))
        await W("bread").hover(); await pg.wait_for_timeout(2500)
        print("1. pulsanti in alto:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card-head button')].map(b=>b.textContent)"))
        print("   modi di dire sottolineati:", await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-idiom')].map(x=>x.textContent)"))
        # definizioni: traduci
        await pg.locator(".dualsub-card .dsx-def .dsx-btn", has_text="traduci").first.click(); await pg.wait_for_timeout(800)
        print("2. definizione tradotta:", await pg.evaluate("(document.querySelector('.dualsub-card .dsx-deftr')||{}).textContent"))
        await pg.locator(".dualsub-card .dsx-wordlink", has_text="breadstick").click(); await pg.wait_for_timeout(800)
        print("3. vedi anche cliccato:", await pg.evaluate("(document.querySelector('.dualsub-card .dsx-peek')||{}).innerText"))
        # ⚑ modo di dire: non è un modo di dire
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(900)
        await W("fresh").hover(); await pg.wait_for_timeout(6000)
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(900)
        print("3b. sottolineati (la frase intera no):", await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-idiom')].map(x=>x.textContent)"))
        await W("fresh").hover(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-card .dualsub-idiom-fix .dualsub-card-link").click(); await pg.wait_for_timeout(300)
        print("4. opzioni modo di dire:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-idiom-fixbox button')].map(b=>b.textContent)"))
        await pg.locator(".dualsub-card .dualsub-idiom-fixbox button", has_text="Non è un modo di dire").click(); await pg.wait_for_timeout(600)
        print("   dopo: sottolineati", await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-idiom')].map(x=>x.textContent)"), "| salvato:", await sw.evaluate("chrome.storage.local.get('idiomFlags').then(r=>Object.keys(r.idiomFlags||{}))"))
        # clic: Google subito, poi Gemini
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(900)
        await W("market").click(); await pg.wait_for_timeout(900)
        print("5. subito dopo il clic:", (await pg.evaluate("(document.querySelector('.dualsub-card')||{}).innerText")).replace("\n", " | ")[:160])
        await pg.wait_for_timeout(7000)
        t = await pg.evaluate("(document.querySelector('.dualsub-card')||{}).innerText")
        print("   dopo:", t.replace("\n", " | ")[:160])
        print("   frase rifatta:", await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-card-sentfix')||{}).innerText"), "| '⚠ false':", "⚠ false" in t)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

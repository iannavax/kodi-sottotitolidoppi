# Scambio Sottotitoli Doppi ↔ Parole al Volo: vocabolario e parole conosciute (file), pagina delle parole più usate
import asyncio, os, sys, json
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import charness
SD, PAV = sys.argv[1], sys.argv[2]
async def open_ext(p, ext):
    ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, accept_downloads=True, args=[f"--disable-extensions-except={ext}", f"--load-extension={ext}"])
    await ctx.route("**/*", charness.handle)
    sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
    return ctx, sw, sw.url.split("/")[2]
async def main():
    errs = []
    async with async_playwright() as p:
        # Sottotitoli Doppi: voci e parole conosciute
        ctx, sw, eid = await open_ext(p, SD)
        await sw.evaluate("""chrome.storage.local.set({knownWords:{en:'you\\nthe\\nhome', cs:'ahoj'}, vocab:{'en|bread':{id:'en|bread', word:'bread', lang:'en', meaning:'pane', status:'learning', added:1},
                            'en|walk':{id:'en|walk', word:'walk', lang:'en', meaning:'camminare', status:'known', added:2}}})""")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/vocab.html"); await pg.wait_for_timeout(800)
        async with pg.expect_download() as d: await pg.click("#swapExp")
        dl = await d.value; path = "/tmp/swap_sd.json"; await dl.save_as(path)
        data = json.load(open(path))
        print("1. file da SD:", dl.suggested_filename, "| from:", data["from"], "| voci:", list(data["vocab"]), "| conosciute:", data["knownWords"])
        print("   messaggio:", await pg.inner_text("#ankiMsg"))
        # pagina delle parole più usate di SD
        fp = await ctx.new_page(); fp.on("pageerror", lambda e: errs.append(str(e)))
        await fp.goto(f"chrome-extension://{eid}/freq.html?lang=en"); await fp.wait_for_timeout(1500)
        await fp.evaluate("document.getElementById('tools').open=true")
        print("2. lingue nel menu:", (await fp.evaluate("[...document.querySelectorAll('#langSel option')].filter(o=>/conosciute/.test(o.textContent)).map(o=>o.textContent)")))
        await fp.fill("#topN", "10"); fp.once("dialog", lambda dlg: asyncio.ensure_future(dlg.accept()))
        await fp.click("#markTop"); await fp.wait_for_timeout(800)
        print("3. segna le prime 10:", await fp.inner_text("#impMsg"), "|", await fp.inner_text("#stats"))
        open("/tmp/words.txt", "w").write("slowly\nmarket\n")
        await fp.set_input_files("#impFile", "/tmp/words.txt"); await fp.wait_for_timeout(800)
        print("4. import .txt:", await fp.inner_text("#impMsg"))
        await ctx.close()
        # Parole al Volo: importa il file di SD
        ctx, sw, eid = await open_ext(p, PAV)
        await sw.evaluate("chrome.storage.local.set({knownWords:{en:'bread'}, vocab:{'ru|кошка':{id:'ru|кошка', word:'кошка', lang:'ru', meaning:'gatta', status:'learning', kind:'word'}}})")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/vocab.html"); await pg.wait_for_timeout(800)
        await pg.set_input_files("#swapFile", path); await pg.wait_for_timeout(1000)
        print("5. import in PAV:", await pg.inner_text("#ankiMsg"))
        l = await sw.evaluate("chrome.storage.local.get(['vocab','knownWords'])")
        print("   voci:", sorted(l["vocab"]), "| conosciute en:", sorted(l["knownWords"]["en"].split("\n")), "| cs:", l["knownWords"].get("cs"))
        await pg.set_input_files("#swapFile", path); await pg.wait_for_timeout(1000)
        print("6. di nuovo:", await pg.inner_text("#ankiMsg"))
        async with pg.expect_download() as d: await pg.click("#swapExp")
        dl = await d.value
        print("7. file da PAV:", dl.suggested_filename)
        fp = await ctx.new_page(); fp.on("pageerror", lambda e: errs.append(str(e)))
        await fp.goto(f"chrome-extension://{eid}/freq.html?lang=en"); await fp.wait_for_timeout(1200)
        await fp.evaluate("document.getElementById('tools').open=true")
        async with fp.expect_download() as d: await fp.click("#exp")
        dl = await d.value; await dl.save_as("/tmp/k.json"); k = json.load(open("/tmp/k.json"))
        print("8. freq PAV esporta:", dl.suggested_filename, k["from"], "vocab" in k, k["knownWords"])
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(800)
        async with ctx.expect_page() as np: await pp.click("#freqBtn")
        n = await np.value; await n.wait_for_timeout(500)
        print("9. pulsante popup PAV →", n.url.split("/")[-1])
        await ctx.close()
        ctx, sw, eid = await open_ext(p, SD)
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(800)
        print("10. SD popup: evidenzia verde:", await pp.evaluate("document.getElementById('learnKnownPage').checked"))
        async with ctx.expect_page() as np: await pp.click("#freqBtn")
        n = await np.value
        print("    pulsante →", n.url.split("/")[-1])
        await ctx.close()
    print("errori:", errs, charness.log.get("errors"))
asyncio.run(main())

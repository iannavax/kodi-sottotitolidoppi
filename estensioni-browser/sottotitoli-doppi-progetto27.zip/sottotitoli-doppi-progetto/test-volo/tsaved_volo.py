# 1.4.13: spiegazioni salvate (🗂) sulle pagine: «Spiega con…» una volta, poi la stessa parola nella stessa frase si vede
# subito (anche dopo aver ricaricato), e 🗂 elenca le spiegazioni di quella parola.
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
CARD = "(document.querySelector('.pav-card')||{}).innerText||''"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "bread", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1200)
        print("1. prima:", "🗂" in await pg.evaluate(CARD))
        await pg.get_by_role("button", name="Spiega con Groq").click(); await pg.wait_for_timeout(4000)
        c1 = await pg.evaluate(CARD)
        print("2. dopo «Spiega»:", c1.replace("\n", " | ")[:200])
        n1 = len(tvolo.log.get("groq_llm", tvolo.log.get("llm", [])) or [])
        await pg.reload(); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "bread", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        c2 = await pg.evaluate(CARD)
        print("3. riaperta dopo aver ricaricato:", c2.replace("\n", " | ")[:300])
        await pg.evaluate("[...document.querySelectorAll('.pav-card .pav-savedbtn')][0].click()"); await pg.wait_for_timeout(300)
        items = await pg.evaluate("[...document.querySelectorAll('.pav-saved-item')].map(x=>x.innerText.replace(/\\n/g,' | '))")
        print("4. elenco:", items)
        ok = "salvata il" in c2 and "🗂 1" in c2 and len(items) == 1 and "in questa frase" in items[0] and "Spiega con Groq" in c2
        print("errori:", errs if ok else errs + ["spiegazioni salvate non vanno"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

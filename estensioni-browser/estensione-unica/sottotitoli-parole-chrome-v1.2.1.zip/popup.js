let compLang = "";   // lingua del video (dal calcolo delle parole conosciute)
const C = DS_CONFIG;
const $ = (id) => document.getElementById(id);
const DEMO = {
  it: "Quindi ci siamo andati ed era davvero buono", en: "So we went there and it was really good",
  es: "Así que fuimos allí y estaba muy bueno", fr: "Alors on y est allés et c'était vraiment bon",
  de: "Also sind wir hingegangen und es war echt gut", pt: "Então fomos lá e estava muito bom"
};

let s = { ...C.SYNC_DEFAULTS };
let keys = {};

for (const [id, E] of Object.entries(C.ENGINES)) {
  const o = document.createElement("option");
  o.value = id;
  o.textContent = E.label;
  $("engine").append(o);
}

function current() {
  const id = C.ENGINES[s.engine] ? s.engine : "google";
  return { id, E: C.ENGINES[id] };
}

function render() {
  const { id, E } = current();
  renderCleanInfo();
  $("engine").value = id;
  $("note").textContent = E.note;
  $("keyRow").hidden = !E.needsKey;
  $("keyLink").hidden = !E.needsKey;
  if (E.keyUrl) $("keyLink").href = E.keyUrl;
  $("key").value = keys[id] || "";
  $("urlRow").hidden = $("urlHint").hidden = !E.local;
  $("regionRow").hidden = E.kind !== "microsoft";
  $("msRegion").value = s.msRegion || "";
  renderFallback();
  DS_ENGINES_UI.banner($("blockedBox"), id, () => { renderFallback(); });
  $("localUrl").value = s.localUrl || C.SYNC_DEFAULTS.localUrl;
  const hasModel = E.kind === "openai" || E.kind === "claude";
  $("modelBox").hidden = !hasModel;
  $("model").value = s.models[id] || E.defaultModel || "";
  $("modelList").innerHTML = "";
  (E.staticModels || []).forEach(addOption);
  $("modelMsg").textContent = "";
}

function addOption(m) {
  const o = document.createElement("option");
  o.value = m;
  $("modelList").append(o);
}

function saveModel(m) {
  const { id } = current();
  s.models = { ...s.models, [id]: m };
  chrome.storage.sync.set({ models: s.models });
}

async function loadModels(auto = false) {
  const { id, E } = current();
  if (E.kind !== "openai") return;
  if (E.needsKey && !keys[id]) { if (!auto) $("modelMsg").textContent = "Inserisci prima la chiave."; return; }
  $("modelMsg").textContent = "Cerco i modelli disponibili…";
  let r;
  try {
    r = await DS_EXT.runtime.sendMessage({ type: "listModels", engine: id, key: keys[id] || "", localUrl: s.localUrl });
  } catch (e) {
    r = { error: String(e.message || e) };
  }
  if (current().id !== id) return;
  if (!r || r.error) { $("modelMsg").textContent = "Errore: " + ((r && r.error) || "nessuna risposta"); return; }
  $("modelList").innerHTML = "";
  r.models.forEach(addOption);
  $("modelMsg").textContent = r.models.length
    ? `${r.models.length} modelli trovati: clicca nel campo per sceglierne un altro.`
    : "Nessun modello trovato.";
  if (!$("model").value && r.suggested) {
    $("model").value = r.suggested;
    saveModel(r.suggested);
  }
}

// ---------- Trascrizione dell'audio ----------
function renderLiveSettings() {
  $("transcribeMode").value = s.autoTranscribe === false ? "off" : (s.transcribeMode || "live");
  $("fullMaxMin").value = s.fullMaxMin || 60;
  $("liveAhead").checked = !!s.liveAhead;
  $("liveAheadDelay").value = s.liveAheadDelay || 20;
  $("stt").value = s.stt;
  $("groqKeyRow").hidden = $("groqLink").hidden = s.stt !== "groq";
  $("sttUrlRow").hidden = s.stt !== "local";
  $("groqKey").value = keys.groq || "";
  $("sttUrl").value = s.sttUrl;
  $("sttModel").value = s.sttModel;
  fillSttLangs();
  $("sttModels").innerHTML = "";
  C.STT_MODELS.forEach((m) => { const o = document.createElement("option"); o.value = m; $("sttModels").append(o); });
}

const LEARN_KEYS = ["learnFreq", "learnKnown", "learnKnownPage", "learnExamples", "learnAudio", "learnTable", "learnGender", "learnSpell", "learnLlmExtra", "learnJisho", "learnHan", "gdAlt", "gdDefs", "gdSyn", "gdSpell", "ankiImage"];
function updateComp(c) {
  if (c && c.lang) compLang = c.lang;
  const el = $("compInfo");
  if (!c || !c.total || (s && s.learnKnown === false)) { el.hidden = true; return; }
  el.hidden = false;
  el.textContent = c.mine
    ? `Conosci il ${c.pct}% delle parole di questo video (${c.uniqueKnown} parole diverse su ${c.unique}).`
    : "Segna le parole che conosci («la conosco?» nella scheda): qui vedrai quante parole del video conosci.";
}
function updateLiveMode(st) {
  const box = $("liveModeBox");
  box.hidden = !(st && st.onVideo && st.live && st.yt);
  if (box.hidden) return;
  $("liveModeSel").value = s.liveAhead ? "ahead" : "normal";
  const a = st.ahead || {};
  $("liveModeInfo").textContent = !s.liveAhead
    ? "Le frasi si trascrivono mentre le senti: arrivano qualche secondo dopo il parlato."
    : !st.running ? "Parte insieme alla trascrizione: premi «Trascrivi l'audio di questo video» (sezione Video senza sottotitoli)."
    : a.state === "on" ? `Attiva: le frasi sono pronte ${a.lead} s prima che il video arrivi lì.`
    : a.state === "aligning" ? "Sto leggendo l'audio con yt-dlp e lo metto a tempo con il video (qualche secondo)…"
    : a.state === "failed" ? "Non disponibile per questa diretta (il motivo è nella riga di stato qui sopra): resta la trascrizione normale. Serve il programma per yt-dlp aggiornato, con ffmpeg."
    : "Sto avviando la lettura dell'audio con yt-dlp…";
}
$("liveModeSel").addEventListener("change", (e) => {
  s.liveAhead = e.target.value === "ahead";
  $("liveAhead").checked = s.liveAhead;
  chrome.storage.sync.set({ liveAhead: s.liveAhead });
  setTimeout(() => askTab({ type: "liveState" }), 400);
});
function updateLive(st) {
  updateComp(st && st.comp);
  updateLiveMode(st);
  // trascrizione in corso (o già fatta): la correzione con Gemini/Groq si accende e spegne da qui
  $("cleanQuick").hidden = !(st && st.onVideo && (st.running || st.full || st.fullBusy));
  if (!$("cleanQuick").hidden) renderCleanInfo();
  if (!st || !st.onVideo) {
    $("liveBtn").disabled = true;
    $("videoMode").disabled = true;
    $("liveInfo").textContent = "In questa pagina non c'è un video o un audio (o va ricaricata dopo l'installazione).";
    return;
  }
  $("liveBtn").disabled = false;
  $("videoMode").disabled = false;
  $("videoMode").value = st.mode || "";
  $("liveBtn").textContent = st.running || st.fullBusy ? "Ferma la trascrizione" : "Trascrivi l'audio di questo video";
  if (st.fullBusy) { $("liveInfo").textContent = "Trascrizione completa in corso: " + (st.fullText || "…"); return; }
  if (st.full) { $("liveInfo").textContent = "Questo video è già trascritto per intero."; return; }
  $("liveInfo").textContent = st.running
    ? "Trascrizione in corso: le frasi arrivano con qualche secondo di ritardo."
    : st.hasCaptions === false
      ? "Questo video non ha sottotitoli."
      : st.hasCaptions
        ? "Questo video ha già i sottotitoli: premi CC. Puoi comunque trascrivere l'audio."
        : "L'audio viene trascritto mentre guardi, con qualche secondo di ritardo.";
}

function withTab(fn) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => fn(tabs && tabs[0]));
}

let frameTarget = null;   // la parte della pagina (video) con cui sto parlando
function askTab(message) {
  withTab((tab) => {
    if (!tab) return updateLive(null);
    const msg = message.type === "liveState" || !frameTarget ? message : { ...message, target: frameTarget };
    chrome.tabs.sendMessage(tab.id, msg, (resp) => {
      if (chrome.runtime.lastError) return updateLive(null);
      if (resp && resp.frame) frameTarget = resp.frame;
      updateLive(resp);
    });
  });
}

function showStatus(st) {
  if (st && st.text) $("status").textContent = st.text;
}

function checkPerm() {
  chrome.permissions.contains({ origins: C.HOSTS }, (ok) => { $("perm").hidden = !!ok; });
}

chrome.storage.sync.get(C.SYNC_DEFAULTS, (stored) => {
  s = { ...stored, models: { ...(stored.models || {}) } };
  chrome.storage.local.get({ keys: {}, apiKey: "", status: null }, (l) => {
    keys = { ...(l.keys || {}) };
    if (!keys.claude && l.apiKey) keys.claude = l.apiKey;
    $("targetLang").value = s.targetLang;
    $("enabled").checked = s.enabled;
    $("hideNative").checked = s.hideNative;
    $("fontSize").value = s.fontSize;
    $("hoverPause").checked = s.hoverPause !== false;
    $("idioms").checked = s.idioms !== false;
    $("ipa").checked = s.ipa !== false;
    $("etym").checked = s.etym !== false;
    $("roman").checked = !!s.roman;
    $("romanHan").checked = s.romanHan !== false;
    $("ankiPerLang").checked = s.ankiPerLang !== false;
    $("ankiLangDeck").value = s.ankiLangDeck || "Lingue::{lingua}";
    $("ankiDeck").value = s.ankiDeck || "Sottotitoli Doppi";
    $("ankiAuto").checked = !!s.ankiAuto;
    ankiRows();
    for (const k of LEARN_KEYS) $(k).checked = k === "ankiImage" ? !!s[k] : s[k] !== false;
    $("cleanTranscript").checked = s.cleanTranscript !== false;
    renderCleanInfo();
    renderLook();
    ttsPicker.fill();
    fillVoices();
    $("demo").textContent = DEMO[s.targetLang] || DEMO.en;
    render();
    renderLiveSettings();
    showStatus(l.status);
    askTab({ type: "liveState" });
    if (!$("model").value) loadModels(true);
  });
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.status) {
    showStatus(changes.status.newValue);
    askTab({ type: "liveState" });
  }
});
checkPerm();

$("grant").addEventListener("click", () => chrome.permissions.request({ origins: C.HOSTS }, () => checkPerm()));
$("engine").addEventListener("change", (e) => {
  s.engine = e.target.value;
  chrome.storage.sync.set({ engine: s.engine });
  render();
  if (!$("model").value) loadModels(true);
});
$("key").addEventListener("change", (e) => {
  const { id } = current();
  keys = { ...keys, [id]: e.target.value.trim() };
  chrome.storage.local.set({ keys });
  if (id === "groq") $("groqKey").value = keys.groq;
  renderCleanInfo();
  renderFallback();
  if (!$("model").value) loadModels(true);
});
$("localUrl").addEventListener("change", (e) => {
  s.localUrl = e.target.value.trim() || C.SYNC_DEFAULTS.localUrl;
  chrome.storage.sync.set({ localUrl: s.localUrl });
  loadModels(true);
});
$("model").addEventListener("change", (e) => saveModel(e.target.value.trim()));
$("loadModels").addEventListener("click", () => loadModels(false));
$("targetLang").addEventListener("change", (e) => {
  s.targetLang = e.target.value;
  chrome.storage.sync.set({ targetLang: s.targetLang });
  $("demo").textContent = DEMO[s.targetLang] || DEMO.en;
});
$("enabled").addEventListener("change", (e) => chrome.storage.sync.set({ enabled: e.target.checked }));
$("hideNative").addEventListener("change", (e) => chrome.storage.sync.set({ hideNative: e.target.checked }));
$("fontSize").addEventListener("input", (e) => chrome.storage.sync.set({ fontSize: Number(e.target.value) }));

$("liveBtn").addEventListener("click", () => {
  const start = $("liveBtn").textContent.startsWith("Trascrivi");
  askTab({ type: "live", action: start ? "start" : "stop" });
});
$("transcribeMode").addEventListener("change", (e) => {
  s.transcribeMode = e.target.value;
  s.autoTranscribe = true;
  chrome.storage.sync.set({ transcribeMode: s.transcribeMode, autoTranscribe: true });
});
$("liveAhead").addEventListener("change", (e) => { s.liveAhead = e.target.checked; chrome.storage.sync.set({ liveAhead: s.liveAhead }); });
$("liveAheadDelay").addEventListener("change", (e) => {
  s.liveAheadDelay = Math.min(120, Math.max(10, Number(e.target.value) || 20));
  e.target.value = s.liveAheadDelay;
  chrome.storage.sync.set({ liveAheadDelay: s.liveAheadDelay });
});
$("fullMaxMin").addEventListener("change", (e) => {
  s.fullMaxMin = Math.max(1, Number(e.target.value) || 60);
  chrome.storage.sync.set({ fullMaxMin: s.fullMaxMin });
});
$("videoMode").addEventListener("change", (e) => askTab({ type: "setMode", mode: e.target.value }));
$("helperBtn").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("helper.html") }));
$("stt").addEventListener("change", (e) => {
  s.stt = e.target.value;
  chrome.storage.sync.set({ stt: s.stt });
  renderLiveSettings();
});
$("groqKey").addEventListener("change", (e) => {
  keys = { ...keys, groq: e.target.value.trim() };
  chrome.storage.local.set({ keys });
  if (current().id === "groq") $("key").value = keys.groq;
  renderCleanInfo();
});
$("sttUrl").addEventListener("change", (e) => {
  s.sttUrl = e.target.value.trim() || C.SYNC_DEFAULTS.sttUrl;
  chrome.storage.sync.set({ sttUrl: s.sttUrl });
});
$("sttModel").addEventListener("change", (e) => {
  s.sttModel = e.target.value.trim() || C.SYNC_DEFAULTS.sttModel;
  chrome.storage.sync.set({ sttModel: s.sttModel });
});
// ---------- Chiavi: mostra e copia ----------
// Le caselle delle chiavi sono nascoste (puntini): accanto c'è "Mostra" per vederle e "Copia" per copiarle,
// così una chiave non salvata altrove si può recuperare da qui.
function keyTools(id) {
  const input = $(id);
  if (!input || input.dataset.tools) return;
  input.dataset.tools = "1";
  const box = document.createElement("span");
  box.className = "keybox";
  input.replaceWith(box);
  box.append(input);
  const show = Object.assign(document.createElement("button"), { type: "button", className: "keybtn", textContent: "Mostra", title: "Mostra o nascondi la chiave" });
  const copy = Object.assign(document.createElement("button"), { type: "button", className: "keybtn", textContent: "Copia", title: "Copia la chiave negli appunti" });
  show.addEventListener("click", (e) => {
    e.preventDefault();
    const hidden = input.type === "password";
    input.type = hidden ? "text" : "password";
    show.textContent = hidden ? "Nascondi" : "Mostra";
  });
  copy.addEventListener("click", async (e) => {
    e.preventDefault();
    const v = input.value.trim();
    if (!v) { copy.textContent = "Vuota"; setTimeout(() => { copy.textContent = "Copia"; }, 1500); return; }
    let ok = false;
    try { await navigator.clipboard.writeText(v); ok = true; } catch {}
    if (!ok) {
      // ripiego per i browser che non permettono gli appunti dal popup
      const t = document.createElement("textarea");
      t.value = v; document.body.append(t); t.select();
      try { ok = document.execCommand("copy"); } catch {}
      t.remove();
    }
    copy.textContent = ok ? "Copiata ✓" : "Non riesco";
    if (!ok) { input.type = "text"; show.textContent = "Nascondi"; input.select(); }
    setTimeout(() => { copy.textContent = "Copia"; }, 1800);
  });
  box.append(show, copy);
}
keyTools("key");
keyTools("groqKey");

// ---------- Lingua parlata: tutte le lingue di Whisper, con ricerca ----------
const STT_NAMES = (() => {
  let it = null, own = null;
  try { it = new Intl.DisplayNames(["it"], { type: "language" }); } catch {}
  const fix = { jw: "jv" };   // codice di Whisper diverso da quello standard
  return Object.entries(C.STT_LANGS).map(([code, en]) => {
    const std = fix[code] || code;
    let name = "", native = "";
    try { name = it ? it.of(std) : ""; } catch {}
    try { own = new Intl.DisplayNames([std], { type: "language" }); native = own.of(std); } catch { native = ""; }
    if (!name || name === std) name = en.charAt(0).toUpperCase() + en.slice(1);
    name = name.charAt(0).toUpperCase() + name.slice(1);
    // senza i dati di quella lingua il browser restituisce il nome inglese: non lo mostro
    if (native && (native.toLowerCase() === name.toLowerCase() || native.toLowerCase() === en || native === std)) native = "";
    return { code, name, native, en, key: [name, native, en, code].join(" ").toLowerCase().normalize("NFD").replace(/\p{M}/gu, "") };
  }).sort((a, b) => a.name.localeCompare(b.name, "it"));
})();

// Menu di lingua con ricerca (usato per la lingua parlata e per quella della pronuncia)
function langPicker(o) {
  // o = { id, empty, emptyNow, key }: id = prefisso degli elementi (select #id, ricerca #idSearch, #idNow, #idHint)
  const sel = $(o.id), search = $(o.id + "Search");
  const norm = (x) => x.trim().toLowerCase().normalize("NFD").replace(/\p{M}/gu, "");
  const fill = (filter = "") => {
    const q = norm(filter), chosen = s[o.key] || "";
    const list = q ? STT_NAMES.filter((l) => l.key.includes(q)) : STT_NAMES;
    sel.textContent = "";
    if (!q || norm(o.empty + " automatica auto").includes(q)) sel.append(new Option(o.empty, ""));
    for (const l of list) sel.append(new Option(l.native ? `${l.name} · ${l.native}` : l.name, l.code));
    // la lingua scelta resta in cima anche se non è tra i risultati, così resta selezionata
    if (q && chosen && !list.some((l) => l.code === chosen)) {
      const cur = STT_NAMES.find((l) => l.code === chosen);
      if (cur) sel.prepend(new Option(cur.name + " (scelta ora)", cur.code));
    }
    sel.value = chosen;
    if (q) sel.size = Math.max(2, Math.min(7, sel.options.length)); else sel.removeAttribute("size");
    $(o.id + "Hint").hidden = !q || list.length > 0;
    const cur = STT_NAMES.find((l) => l.code === chosen);
    $(o.id + "Now").textContent = cur ? "· " + cur.name : "· " + o.emptyNow;
  };
  const choose = (code) => {
    s[o.key] = code || "";
    chrome.storage.sync.set({ [o.key]: s[o.key] });
    search.value = "";
    fill();
    if (o.onChange) o.onChange();
  };
  sel.addEventListener("change", () => choose(sel.value));
  sel.addEventListener("click", (e) => { if (sel.size > 1 && e.target.tagName === "OPTION") choose(e.target.value); });
  sel.addEventListener("keydown", (e) => { if (e.key === "Enter" && sel.size > 1) { e.preventDefault(); choose(sel.value); } });
  search.addEventListener("input", () => fill(search.value));
  search.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const first = [...sel.options].find((x) => !x.text.endsWith("(scelta ora)"));
      if (search.value.trim() && first) choose(first.value);
    } else if (e.key === "ArrowDown" && sel.size > 1) { e.preventDefault(); sel.focus(); sel.selectedIndex = 0; }
    else if (e.key === "Escape" && search.value) { e.preventDefault(); search.value = ""; fill(); }
  });
  return { fill: () => fill(search.value) };
}
const sttPicker = langPicker({ id: "sttLang", key: "sttLang", empty: "Rileva da sola", emptyNow: "rilevata da sola" });
const fillSttLangs = () => sttPicker.fill();

// ---------- Vocabolario ----------
function showVocabCount() {
  chrome.storage.local.get({ vocab: {} }, (r) => {
    const n = Object.keys(r.vocab || {}).length;
    $("vocabBtn").textContent = n ? `Il mio vocabolario (${n} ${n === 1 ? "parola" : "parole"})` : "Il mio vocabolario";
  });
}
showVocabCount();
// ---------- Anki ----------
function ankiRows() { const on = $("ankiPerLang").checked; $("ankiLangDeckRow").hidden = !on; $("ankiDeckRow").hidden = on; }
$("ankiPerLang").addEventListener("change", (e) => { s.ankiPerLang = e.target.checked; chrome.storage.sync.set({ ankiPerLang: e.target.checked }); ankiRows(); });
$("ankiLangDeck").addEventListener("change", (e) => chrome.storage.sync.set({ ankiLangDeck: e.target.value.trim() || "Lingue::{lingua}" }));
$("ankiDeck").addEventListener("change", (e) => chrome.storage.sync.set({ ankiDeck: e.target.value.trim() || "Sottotitoli Doppi" }));
$("ankiAuto").addEventListener("change", (e) => { s.ankiAuto = e.target.checked; chrome.storage.sync.set({ ankiAuto: e.target.checked }); });
$("ankiTest").addEventListener("click", () => {
  const st = $("ankiStatus");
  st.textContent = "Collego… (se Anki chiede il permesso, premi Yes)";
  chrome.runtime.sendMessage({ type: "ankiCheck" }, (r) => {
    if (chrome.runtime.lastError) r = { error: chrome.runtime.lastError.message };
    st.textContent = r && !r.error ? `Collegato ad Anki (AnkiConnect ${r.version}). Tipo di nota: ${r.model}. Per esempio le parole inglesi vanno nel mazzo «${r.example}».` : (r && r.error) || "Nessuna risposta.";
  });
});
$("vocabBtn").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("vocab.html") }));
// elenco delle parole più usate (con le parole che conosci) nella lingua del video, o in quella con più parole conosciute
$("freqBtn").addEventListener("click", async () => {
  let lang = compLang;
  if (!lang) {
    const kw = (await DS_EXT.storage.local.get({ knownWords: {} })).knownWords || {};
    lang = Object.keys(kw).sort((a, b) => String(kw[b]).split("\n").length - String(kw[a]).split("\n").length)[0] || "en";
  }
  chrome.tabs.create({ url: chrome.runtime.getURL("freq.html") + "?lang=" + encodeURIComponent(String(lang).split("-")[0]) + "&target=" + encodeURIComponent((s && s.targetLang) || "it") });
});
$("hoverPause").addEventListener("change", (e) => chrome.storage.sync.set({ hoverPause: e.target.checked }));
$("idioms").addEventListener("change", (e) => chrome.storage.sync.set({ idioms: e.target.checked }));
$("ipa").addEventListener("change", (e) => chrome.storage.sync.set({ ipa: e.target.checked }));
$("etym").addEventListener("change", (e) => chrome.storage.sync.set({ etym: e.target.checked }));
$("roman").addEventListener("change", (e) => chrome.storage.sync.set({ roman: e.target.checked }));
$("romanHan").addEventListener("change", (e) => chrome.storage.sync.set({ romanHan: e.target.checked }));
for (const k of LEARN_KEYS) $(k).addEventListener("change", (e) => { s[k] = e.target.checked; chrome.storage.sync.set({ [k]: e.target.checked }); if (k === "learnKnown") askTab({ type: "liveState" }); });
$("fallback").addEventListener("change", (e) => { s.fallback = e.target.checked; chrome.storage.sync.set({ fallback: e.target.checked }); renderFallback(); });
$("msRegion").addEventListener("change", (e) => { s.msRegion = e.target.value.trim(); chrome.storage.sync.set({ msRegion: s.msRegion }); });

// Quali servizi di riserva sono pronti (hanno la chiave) e quali hanno finito le richieste di oggi
function renderFallback() {
  $("fallback").checked = s.fallback !== false;
  chrome.storage.local.get({ dsBlocked: {} }, (r) => {
    const day = (() => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return ""; } })();
    const blocked = (id) => r.dsBlocked[id] && r.dsBlocked[id].day === day;
    const name = (id) => C.ENGINES[id].label.split(" (")[0].split(",")[0];
    const ready = C.FALLBACK.filter((id) => keys[id]);
    const parts = ready.map((id) => name(id) + (blocked(id) ? " (finite per oggi)" : ""));
    $("fallbackInfo").textContent = s.fallback === false ? "" : ready.length
      ? "Servizi con la chiave, in quest'ordine: " + parts.join(", ") + ". Poi Google Traduttore."
      : "Per avere servizi di riserva, scegli Groq, Mistral o OpenRouter qui sopra e inserisci la loro chiave gratuita (poi torna al servizio che preferisci).";
  });
}
for (const id of ["cleanTranscript", "cleanTranscript2"]) $(id).addEventListener("change", (e) => {
  s.cleanTranscript = e.target.checked;
  $("cleanTranscript").checked = $("cleanTranscript2").checked = e.target.checked;
  chrome.storage.sync.set({ cleanTranscript: e.target.checked });
  renderCleanInfo();
});

// Chi corregge la trascrizione (stessa scelta di cleanerEngine in content.js)
function renderCleanInfo() {
  const E = C.ENGINES[s.engine] || C.ENGINES.google;
  const name = E.label.split(" (")[0].split(",")[0];
  let t;
  if (s.cleanTranscript === false) t = "Spenta: le frasi restano come le ha capite Whisper.";
  else if (E.kind === "openai" || E.kind === "claude") t = `La fa ${name} nella stessa richiesta della traduzione: nessuna richiesta in più.`;
  else if (keys.gemini) t = "La fa Gemini con la tua chiave, a gruppi di frasi (una richiesta ogni 10-30 frasi). Intanto vedi la traduzione rapida; poi traduce " + name + " il testo corretto.";
  else if (keys.groq) t = "La fa Groq (stessa chiave della trascrizione), a gruppi di frasi (una richiesta ogni 10-30 frasi). Intanto vedi la traduzione rapida; poi traduce " + name + " il testo corretto.";
  else t = "Per correggerla serve una chiave Gemini o Groq (nella sezione Traduzione o qui sopra).";
  $("cleanInfo").textContent = t;
  $("cleanInfo2").textContent = t;
  $("cleanTranscript2").checked = s.cleanTranscript !== false;
}

// ---------- Pronuncia ----------
async function fillVoices() {
  const voices = await DS_TTS.voicesReady();
  const lang = s.ttsLang || "";
  const group = $("ttsVoices");
  group.textContent = "";
  const list = voices
    .filter((v) => !lang || DS_TTS.base(v.lang) === lang)
    .sort((a, b) => a.lang.localeCompare(b.lang) || a.name.localeCompare(b.name));
  for (const v of list) {
    const o = document.createElement("option");
    o.value = v.voiceURI;
    o.textContent = `${v.name} (${v.lang})`;
    group.append(o);
  }
  group.label = list.length ? "Voci installate sul computer" : "Nessuna voce installata per questa lingua";
  const saved = s.ttsVoice || "";
  $("ttsVoice").value = saved;
  if ($("ttsVoice").value !== saved) $("ttsVoice").value = ""; // la voce salvata non è di questa lingua
  if (lang && !list.length) {
    $("ttsInfo").textContent = C.GOOGLE_TTS.includes(lang)
      ? "Sul computer non c'è una voce per questa lingua: in automatico verrà usata quella di Google."
      : "Per questa lingua non c'è una voce né sul computer né su Google, quindi la pronuncia non è disponibile. " +
        "Puoi aggiungere una voce al computer (Windows: Impostazioni → Ora e lingua → Voce) e poi riaprire questo menu.";
  } else {
    $("ttsInfo").textContent = "";
  }
}

const ttsPicker = langPicker({ id: "ttsLang", key: "ttsLang", empty: "Automatica (quella del video)", emptyNow: "quella del video", onChange: () => fillVoices() });
$("ttsVoice").addEventListener("change", (e) => {
  s.ttsVoice = e.target.value;
  chrome.storage.sync.set({ ttsVoice: s.ttsVoice });
});
$("ttsTest").addEventListener("click", async () => {
  const lang = s.ttsLang || "en";
  // per le lingue senza frase di prova dico il nome della lingua nella lingua stessa
  const own = STT_NAMES.find((l) => l.code === lang);
  const text = C.TTS_SAMPLES[lang] || (own && (own.native || own.name)) || C.TTS_SAMPLES.en;
  $("ttsInfo").textContent = "…";
  let r;
  try { r = await DS_TTS.speak(text, lang, { lang: s.ttsLang || "", voice: $("ttsVoice").value }); }
  catch (e) { $("ttsInfo").textContent = "Pronuncia non disponibile: " + (e.message || e); return; }
  $("ttsInfo").textContent = "Usata: " + r.how + (s.ttsLang ? "" : ". In automatico la lingua è quella del video; per la prova uso l'inglese.");
});

// ---------- Aspetto dei sottotitoli ----------
const LOOK = ["subShow", "transFirst", "fontSize", "transScale", "origColor", "transColor", "bgOpacity", "subPos", "subFont", "romanSize", "romanLineSize"];
const romanSizeShow = () => { for (const k of ["romanSize", "romanLineSize"]) $(k + "Val").textContent = $(k).value + "%"; };
function renderLook() {
  for (const k of LOOK) {
    const el = $(k);
    if (el.type === "checkbox") el.checked = !!s[k];
    else el.value = s[k] != null ? s[k] : C.SYNC_DEFAULTS[k];
  }
  romanSizeShow();
}
for (const k of LOOK) {
  const el = $(k);
  el.addEventListener(el.type === "range" || el.type === "color" ? "input" : "change", () => {
    const v = el.type === "checkbox" ? el.checked : el.type === "range" ? Number(el.value) : el.value;
    s[k] = v;
    chrome.storage.sync.set({ [k]: v });
    if (k === "romanSize" || k === "romanLineSize") romanSizeShow();
  });
}
$("resetLook").addEventListener("click", () => {
  const d = {};
  for (const k of LOOK) d[k] = C.SYNC_DEFAULTS[k];
  Object.assign(s, d);
  chrome.storage.sync.set(d);
  renderLook();
});

// ---------- Pagina della trascrizione ----------
$("transcriptBtn").addEventListener("click", () => {
  withTab((tab) => {
    const q = tab && tab.id != null ? "?tab=" + tab.id : "";
    chrome.tabs.create({ url: chrome.runtime.getURL("transcript.html" + q) });
  });
});

// ---------- Attiva / disattiva su questo sito ----------
withTab((tab) => {
  let host = "";
  try { host = tab && tab.url ? new URL(tab.url).hostname : ""; } catch {}
  if (!host) return;
  $("siteRow").hidden = false;
  $("siteLabel").textContent = "Attiva su " + host;
  chrome.storage.sync.get({ disabledSites: [] }, (r) => {
    $("siteOn").checked = !(r.disabledSites || []).includes(host);
  });
  $("siteOn").addEventListener("change", (e) => {
    chrome.storage.sync.get({ disabledSites: [] }, (r) => {
      const list = new Set(r.disabledSites || []);
      if (e.target.checked) list.delete(host); else list.add(host);
      chrome.storage.sync.set({ disabledSites: [...list] });
    });
  });
});

// da dove prendere le immagini per le carte di Anki
(() => {
  const sel = document.getElementById("ankiImageSource");
  if (!sel) return;
  DS_EXT.storage.sync.get({ ankiImageSource: "auto" }).then((r) => { sel.value = r.ankiImageSource || "auto"; }).catch(() => {});
  sel.addEventListener("change", () => DS_EXT.storage.sync.set({ ankiImageSource: sel.value }));
})();

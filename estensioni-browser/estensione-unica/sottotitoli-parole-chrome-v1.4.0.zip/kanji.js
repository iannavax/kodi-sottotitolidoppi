// Pagina "Kanji e caratteri": i caratteri per livello (JLPT, classe giapponese, HSK, Cina, Corea, frequenza, tratti,
// radicale), dai dati dentro l'estensione (han-data.json). Si apre cliccando i distintivi nella scheda di un carattere.
const $ = (id) => document.getElementById(id);
const P = new URLSearchParams(location.search);
let sys = P.get("sys") || "jlpt", level = P.get("level") || "", me = P.get("ch") || "";
const lang = (P.get("lang") || "ja").split("-")[0], target = P.get("target") || "it";
let D = null, known = new Set(), sel = me;
const GR = { 1: "1ª elem.", 2: "2ª elem.", 3: "3ª elem.", 4: "4ª elem.", 5: "5ª elem.", 6: "6ª elem.", 8: "medie (jōyō)", 9: "nomi (jinmeiyō)", 10: "nomi (jinmeiyō)" };
const FREQ = [[1, 500], [501, 1000], [1001, 1500], [1501, 2000], [2001, 2501]];
// i sistemi: nome, livelli, a quale livello appartiene un carattere
const SYS = {
  jlpt: { name: "JLPT", tip: "Esame di giapponese: N5 il più facile, N1 il più difficile", levels: () => ["5", "4", "3", "2", "1"], label: (l) => "N" + l, of: (e) => (e.jlpt ? String(e.jlpt) : "") },
  grade: { name: "Classe in Giappone", tip: "Quando si studia nelle scuole giapponesi", levels: () => ["1", "2", "3", "4", "5", "6", "8", "9"], label: (l) => GR[l], of: (e) => (e.g ? String(e.g === 10 ? 9 : e.g) : "") },
  freq: { name: "Più usati (Giappone)", tip: "Posizione tra i kanji più usati nei giornali giapponesi", levels: () => FREQ.map((x) => String(x[0])), label: (l) => { const r = FREQ.find((x) => String(x[0]) === l); return r[0] + "–" + (r[1] - 1); }, of: (e) => { const r = e.f && FREQ.find((x) => e.f >= x[0] && e.f < x[1]); return r ? String(r[0]) : ""; }, order: (e) => e.f },
  hsk: { name: "HSK", tip: "Esame di cinese HSK 3.0: 1 il più facile, 7-9 il più difficile", levels: () => ["1", "2", "3", "4", "5", "6", "7"], label: (l) => (l === "7" ? "7-9" : l), of: (e) => (e.hsk ? String(e.hsk) : "") },
  tg: { name: "Comuni in Cina", tip: "Lista ufficiale cinese dei caratteri di uso comune (通用规范汉字表)", levels: () => ["1", "2", "3"], label: (l) => ({ 1: "comuni (3500)", 2: "meno comuni", 3: "rari" })[l], of: (e) => (e.tg ? String(e.tg) : "") },
  koe: { name: "Hanja (Corea)", tip: "I 1800 hanja che si studiano nelle scuole coreane", levels: () => ["1"], label: () => "hanja scolastici", of: (e) => (e.koe ? "1" : "") },
  strokes: { name: "Tratti", tip: "Numero di tratti", levels: () => Array.from({ length: 24 }, (_, i) => String(i + 1)), label: (l) => l, of: (e) => (e.s ? String(Math.min(24, e.s)) : "") },
  radical: { name: "Radicale", tip: "Il radicale (la parte con cui si cerca nei dizionari)", levels: () => Object.keys(D.rad).filter((k) => !/'/.test(k)).sort((a, b) => a - b), label: (l) => (D.rad[l] ? D.rad[l][0] : l), of: (e) => ((e.r || "").split(".")[0].replace(/'+/, "") || "") }
};
const readingOf = (e) => (lang === "zh" ? e.py : lang === "ko" ? e.ko : lang === "vi" ? e.vi : [...(e.on || []).slice(0, 1), ...(e.kun || []).slice(0, 1)].join(" · ")) || e.py || "";
const short = (t) => String(t || "").split(/[;,]/)[0].trim();

async function loadKnown() {
  const r = await DS_EXT.storage.local.get({ knownWords: {} });
  known = new Set(String((r.knownWords || {})[lang] || "").split("\n").filter(Boolean));
}
async function setKnown(chars, on) {
  const r = await DS_EXT.storage.local.get({ knownWords: {} });
  const kw = r.knownWords || {};
  const set = new Set(String(kw[lang] || "").split("\n").filter(Boolean));
  for (const c of chars) on ? set.add(c) : set.delete(c);
  kw[lang] = [...set].join("\n");
  await DS_EXT.storage.local.set({ knownWords: kw });
  known = set;
}
function go(s, l, ch) {
  sys = s; level = l || ""; if (ch !== undefined) sel = ch;
  history.replaceState(null, "", "?" + new URLSearchParams({ sys, level, ch: sel || "", lang, target }));
  render();
}
function chars() {
  const S = SYS[sys];
  let list = Object.entries(D.c).filter(([, e]) => S.of(e) === level);
  const q = $("q").value.trim().toLowerCase();
  if (q) list = Object.entries(D.c).filter(([c, e]) => c === q || (e.py || "").toLowerCase().includes(q) || (e.on || []).concat(e.kun || []).some((r) => r.includes(q)) ||
    (e.ko || "").includes(q) || (e.d || "").toLowerCase().includes(q) || (e.jm || "").toLowerCase().includes(q));
  const ord = S.order || ((e) => e.f || (e.hsk ? 3000 + e.hsk * 100 : 0) || 9000 + (e.s || 0));
  return list.sort((a, b) => ord(a[1]) - ord(b[1]) || (a[1].s || 0) - (b[1].s || 0)).slice(0, 3000);
}
function render() {
  const S = SYS[sys];
  $("tabs").textContent = "";
  for (const [k, x] of Object.entries(SYS)) {
    const a = document.createElement("a");
    a.href = "#"; a.textContent = x.name; a.title = x.tip; a.className = k === sys ? "on" : "";
    a.addEventListener("click", (ev) => { ev.preventDefault(); go(k, SYS[k].levels()[0]); });
    $("tabs").append(a);
  }
  if (!level) level = S.levels()[0];
  $("levels").textContent = "";
  for (const l of S.levels()) {
    const all = Object.entries(D.c).filter(([, e]) => S.of(e) === l);
    if (!all.length) continue;
    const kn = all.filter(([c]) => known.has(c)).length;
    const b = document.createElement("button");
    b.type = "button"; b.className = l === level ? "on" : "";
    b.append(S.label(l));
    const sm = document.createElement("small"); sm.textContent = kn ? `${kn}/${all.length}` : String(all.length); b.append(sm);
    b.title = `${S.name} ${S.label(l)}: ${all.length} caratteri, ne conosci ${kn}`;
    b.addEventListener("click", () => { $("q").value = ""; go(sys, l); });
    $("levels").append(b);
  }
  const list = chars();
  const kn = list.filter(([c]) => known.has(c)).length;
  $("stats").innerHTML = "";
  for (const t of [`${list.length} caratteri`, `ne conosci ${kn} (${list.length ? Math.round((kn * 100) / list.length) : 0}%)`]) { const s = document.createElement("span"); s.className = "stat"; s.textContent = t; $("stats").append(s); }
  $("title").textContent = "Kanji e caratteri — " + S.name + ($("q").value.trim() ? "" : " " + S.label(level));
  $("grid").textContent = "";
  for (const [c, e] of list) {
    const d = document.createElement("div");
    d.className = "ch" + (known.has(c) ? " known" : "") + (c === sel ? " me" : "");
    d.title = (e.d || "") + (e.s ? ` · ${e.s} tratti` : "");
    const b = document.createElement("b"); b.textContent = c;
    const r = document.createElement("span"); r.textContent = readingOf(e) || " ";
    const m = document.createElement("i"); m.textContent = short(lang === "ja" && e.jm ? e.jm : e.d) || " ";
    d.append(b, r, m);
    d.addEventListener("click", () => { sel = c; history.replaceState(null, "", "?" + new URLSearchParams({ sys, level, ch: sel, lang, target })); detail(); render(); });
    $("grid").append(d);
  }
  detail();
  const meEl = $("grid").querySelector(".ch.me");
  if (meEl && !render.scrolled) { render.scrolled = true; meEl.scrollIntoView({ block: "center" }); }
}
// scheda del carattere scelto, con tutto cliccabile
function detail() {
  const box = $("detail"), e = sel && D.c[sel];
  box.hidden = !e;
  if (!e) return;
  box.textContent = "";
  const mk = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const top = mk("div", "top"), info = mk("div");
  top.append(mk("div", "big", sel), info);
  const line = (label, ...content) => { if (!content.length || content.every((x) => !x)) return; const d = mk("div", "line"); d.append(mk("b", null, label + ": "), ...content.map((x) => (typeof x === "string" ? document.createTextNode(x) : x))); info.append(d); };
  const chip = (c, title) => { const b = mk("button", "chip", c); b.type = "button"; b.title = title || ""; b.addEventListener("click", () => { sel = c; render(); }); return b; };
  const badge = (text, title, fn) => { const b = mk("button", "badge", text); b.type = "button"; b.title = title; b.addEventListener("click", fn); return b; };
  line("Significato (inglese)", [e.d, e.jm && e.jm.toLowerCase() !== (e.d || "").toLowerCase() ? "giapponese: " + e.jm : ""].filter(Boolean).join(" — "));
  const tr = mk("span", "tr"); line("Nella tua lingua", tr);
  DS_EXT.runtime.sendMessage({ type: "translate", engine: "google", target, source: "en", texts: [e.jm && lang === "ja" ? e.jm : e.d || ""] })
    .then((r) => { tr.textContent = (r && r.translations && r.translations[0]) || "—"; }).catch(() => { tr.textContent = "—"; });
  if ((e.on || []).length || (e.kun || []).length) line("Giapponese", [e.on && e.on.length ? "on " + e.on.join("、") : "", e.kun && e.kun.length ? "kun " + e.kun.join("、") : ""].filter(Boolean).join(" · "));
  line("Cinese (pinyin)", e.py || ""); line("Cantonese", e.yue || ""); line("Coreano", e.ko || ""); line("Vietnamita", e.vi || "");
  const parts = Array.from(String(e.p || "").replace(/[⿰-⿿㇯]/g, "")).filter((x) => x !== sel && D.c[x] && D.c[x].d);
  if (parts.length) { const sp = mk("span"); parts.forEach((x, i) => { if (i) sp.append(" + "); sp.append(chip(x, D.c[x].d), " " + short(D.c[x].d)); }); line("Parti", sp); }
  const rn = (e.r || "").split(".")[0].replace(/'+/, ""), rd = D.rad[rn];
  if (rd) line("Radicale", chip(rd[0], rd[1]), ` ${rd[1]} (n. ${rn}) `, badge("tutti con questo radicale ›", "I caratteri con questo radicale", () => go("radical", rn)));
  const forms = mk("span");
  if (e.sv) forms.append("semplificato ", ...Array.from(e.sv).map((x) => chip(x, "forma semplificata")));
  if (e.tv) forms.append(" tradizionale ", ...Array.from(e.tv).map((x) => chip(x, "forma tradizionale")));
  if (forms.childNodes.length) line("Altre forme", forms);
  const lv = mk("div");
  if (e.s) lv.append(badge(e.s + " tratti ›", "Tutti i caratteri con questo numero di tratti", () => go("strokes", String(Math.min(24, e.s)))));
  if (e.jlpt) lv.append(badge("JLPT N" + e.jlpt + " ›", "Tutti i kanji di questo livello JLPT", () => go("jlpt", String(e.jlpt))));
  if (e.g && GR[e.g]) lv.append(badge(GR[e.g] + " ›", "Tutti i kanji di questa classe", () => go("grade", String(e.g === 10 ? 9 : e.g))));
  if (e.f) lv.append(badge("n. " + e.f + " in Giappone ›", "I kanji più usati, a partire da qui", () => go("freq", SYS.freq.of(e))));
  if (e.hsk) lv.append(badge("HSK " + (e.hsk >= 7 ? "7-9" : e.hsk) + " ›", "Tutti i caratteri di questo livello HSK", () => go("hsk", String(e.hsk))));
  if (e.tg) lv.append(badge(SYS.tg.label(String(e.tg)) + " in Cina ›", "Lista ufficiale cinese", () => go("tg", String(e.tg))));
  if (e.koe) lv.append(badge("hanja scolastico ›", "Gli hanja delle scuole coreane", () => go("koe", "1")));
  info.append(lv);
  box.append(top);
  const acts = mk("div", "acts");
  const kb = mk("button", known.has(sel) ? "known" : "", known.has(sel) ? "✓ lo conosco" : "lo conosco?");
  kb.type = "button";
  kb.addEventListener("click", async () => { await setKnown([sel], !known.has(sel)); render(); });
  acts.append(kb);
  const ob = mk("button", null, "✍ ordine dei tratti"); ob.type = "button";
  ob.addEventListener("click", () => strokeOrder(sel, box, ob));
  acts.append(ob);
  const q = encodeURIComponent(sel);
  for (const [t, u] of [["Jisho", "https://jisho.org/search/" + q + "%20%23kanji"], ["MDBG", "https://www.mdbg.net/chinese/dictionary?page=chardict&cdqchi=" + q], ["Wiktionary", "https://en.wiktionary.org/wiki/" + q]]) {
    const a = mk("a", null, t); a.href = u; a.target = "_blank"; a.rel = "noopener noreferrer"; acts.append(a);
  }
  box.append(acts);
}
// animazione dell'ordine dei tratti da Wikimedia Commons (c'è per molti caratteri comuni)
async function strokeOrder(c, box, btn) {
  btn.textContent = "…";
  for (const name of [c + "-order.gif", c + "-red.png", c + "-bw.png"]) {
    const r = await DS_EXT.runtime.sendMessage({ type: "fetchB64", url: "https://commons.wikimedia.org/wiki/Special:FilePath/" + encodeURIComponent(name) }).catch(() => null);
    if (r && r.b64) {
      const img = document.createElement("img");
      img.className = "order"; img.alt = "Ordine dei tratti di " + c;
      img.src = "data:" + (/\.gif$/.test(name) ? "image/gif" : "image/png") + ";base64," + r.b64;
      box.append(img); btn.remove(); return;
    }
  }
  btn.textContent = "ordine dei tratti non disponibile";
}

$("q").addEventListener("input", () => { clearTimeout(render.t); render.t = setTimeout(render, 200); });
$("allKnown").addEventListener("click", async () => {
  const list = chars().map(([c]) => c);
  if (!list.length || !confirm(`Segno come conosciuti ${list.length} caratteri?`)) return;
  await setKnown(list, true); render();
});
DS_EXT.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.knownWords) { known = new Set(String((ch.knownWords.newValue || {})[lang] || "").split("\n").filter(Boolean)); render(); } });
(async () => {
  D = await (await fetch(DS_EXT.runtime.getURL("han-data.json"))).json();
  await loadKnown();
  if (me && D.c[me] && !level) level = SYS[sys].of(D.c[me]);
  render();
})();

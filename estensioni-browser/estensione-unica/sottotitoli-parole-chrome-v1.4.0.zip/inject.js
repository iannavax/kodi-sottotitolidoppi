// Gira dentro la pagina di YouTube (world: MAIN).
// Intercetta i sottotitoli scaricati dal player quando premi CC e li passa all'estensione.
(() => {
  if (window.__dualSubsInstalled) return;
  window.__dualSubsInstalled = true;

  const nativeFetch = window.fetch.bind(window);
  // I messaggi viaggiano come stringhe JSON: più affidabile tra Chrome e Firefox
  const post = (msg) => window.postMessage(JSON.stringify({ __dualsub: "page", ...msg }), location.origin);
  const isTimedText = (u) => typeof u === "string" && u.includes("/api/timedtext");
  let lastKey = null;

  async function getJson3(url) {
    const r = await nativeFetch(url, { credentials: "include" });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const t = await r.text();
    if (!t) throw new Error("risposta vuota");
    return JSON.parse(t);
  }

  async function onCaptured(rawUrl, body) {
    let url;
    try { url = new URL(rawUrl, location.origin); } catch { return; }
    const hadTlang = url.searchParams.has("tlang");
    const fmt = url.searchParams.get("fmt");
    url.searchParams.delete("tlang");
    url.searchParams.set("fmt", "json3");

    const videoId = url.searchParams.get("v");
    const lang = url.searchParams.get("lang");
    const kind = url.searchParams.get("kind") || "";
    const key = `${videoId}|${lang}|${kind}`;
    if (key === lastKey) return;
    lastKey = key;

    let data = null;
    if (!hadTlang && fmt === "json3" && body) {
      try { data = typeof body === "string" ? JSON.parse(body) : body; } catch {}
    }
    try {
      if (!data) data = await getJson3(url.toString());
    } catch (e) {
      lastKey = null;
      post({ type: "error", text: "Non riesco a scaricare i sottotitoli da YouTube (" + e.message + ")." });
      return;
    }
    post({ type: "track", videoId, lang, kind, baseUrl: url.toString(), events: data.events || [] });
  }

  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    try {
      const u = String(url);
      if (isTimedText(u)) {
        this.addEventListener("load", () => {
          let body = null;
          try {
            if (this.responseType === "" || this.responseType === "text") body = this.responseText;
            else if (this.responseType === "json") body = this.response;
          } catch {}
          onCaptured(u, body);
        });
      }
    } catch {}
    return origOpen.call(this, method, url, ...rest);
  };

  window.fetch = function (input, init) {
    const p = nativeFetch(input, init);
    try {
      const u = input instanceof Request ? input.url : String(input);
      if (isTimedText(u)) {
        p.then((r) => r.clone().text()).then((t) => onCaptured(u, t)).catch(() => onCaptured(u, null));
      }
    } catch {}
    return p;
  };

  window.addEventListener("message", async (e) => {
    if (e.origin !== location.origin || typeof e.data !== "string" || !e.data.startsWith('{"__dualsub":"ext"')) return;
    let m;
    try { m = JSON.parse(e.data); } catch { return; }
    if (m.type === "reset") lastKey = null;
    // diretta sincronizzata: il video va indietro con i comandi del lettore di YouTube (lo spostamento diretto del
    // video a volte viene annullato dal lettore, che torna alla diretta)
    if (m.type === "seekTo") {
      try {
        const p = document.getElementById("movie_player");
        if (p && typeof p.seekTo === "function") p.seekTo(m.t, true);
        else { const v = document.querySelector("video"); if (v) v.currentTime = m.t; }
      } catch {}
    }
    if (m.type === "fetchYT") {
      try {
        const d = await getJson3(m.url);
        post({ type: "ytResult", id: m.id, events: d.events || [] });
      } catch (err) {
        post({ type: "ytResult", id: m.id, error: String(err.message || err) });
      }
    }
  });

  // Controlla se il video ha sottotitoli (anche automatici)
  let reportedId = null;
  setInterval(() => {
    try {
      const p = document.getElementById("movie_player");
      if (!p || !p.getVideoData || !p.getPlayerResponse) return;
      const vd = p.getVideoData() || {};
      const id = vd.video_id;
      const embedded = /^\/embed\//.test(location.pathname);
      const urlId = new URLSearchParams(location.search).get("v");
      if (!id || id === reportedId || (!embedded && id !== urlId)) return;
      const pr = p.getPlayerResponse();
      if (!pr || !pr.videoDetails || pr.videoDetails.videoId !== id) return;
      const tracks = (((pr.captions || {}).playerCaptionsTracklistRenderer || {}).captionTracks) || [];
      reportedId = id;
      post({ type: "captionsInfo", videoId: id, has: tracks.length > 0, live: !!(vd.isLive || pr.videoDetails.isLive), embedded });
    } catch {}
  }, 1000);

  post({ type: "ready" });
})();

# 5.9.3: "Completa" con yt-dlp bloccato: i sottotitoli non restano fermi (trascrizione mentre guardi nel frattempo),
# e dopo 90 s senza progressi lo scaricamento viene interrotto con un messaggio chiaro
import asyncio, json, sys, os, subprocess, shutil
from charness import *
PROFILE = "/tmp/pwprofile2"
async def main():
    shutil.rmtree(PROFILE, ignore_errors=True); shutil.rmtree("/tmp/sdhome2", ignore_errors=True); os.makedirs("/tmp/sdhome2")
    env = dict(os.environ, FAKE_AUDIO="/tmp/speech.wav", FAKE_LOG="/tmp/fake-ytdlp2.log")
    async with async_playwright() as p:
        ctx, sw = await launch(p, PROFILE, env)
        ext = sw.url.split("/")[2]
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', transcribeMode:'full', fullMaxMin:60, ipa:false})
          .then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))""")
        hp = await ctx.new_page()
        await hp.goto(f"chrome-extension://{ext}/helper.html"); await hp.wait_for_timeout(1000)
        await hp.select_option("#os", "linux")
        async with hp.expect_download() as d: await hp.click("#download")
        path = await (await d.value).path()
        r = subprocess.run(["sh", path], capture_output=True, text=True, env=dict(os.environ, HOME="/tmp/sdhome2",
            SD_YTDLP_URL="file:///home/claude/e2e/fake/yt-dlp", SD_DENO_URL="file:///tmp/fakedeno.zip", SD_EXTRA_CHROME_DIRS=PROFILE + "/NativeMessagingHosts"))
        print("installato:", r.returncode)
        await hp.close()
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsHang1"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        st = lambda: sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)")
        seen = []
        for k in range(60):   # 30 s
            await pg.wait_for_timeout(500)
            o = await pg.evaluate("(document.querySelector('.dualsub-overlay:not([hidden]) .dualsub-orig')||{}).textContent||''")
            t = await pg.evaluate("(document.querySelector('.dualsub-overlay:not([hidden]) .dualsub-trans')||{}).textContent||''")
            x = o or t
            if x and (not seen or seen[-1] != x): seen.append(x)
        print("1. nei primi 30 s sul video:", seen[:8])
        print("   stato:", await st())
        await pg.evaluate("document.querySelector('video').loop = true")
        await pg.wait_for_timeout(80000)
        print("2. dopo 110 s:", await st(), "| sul video:", await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

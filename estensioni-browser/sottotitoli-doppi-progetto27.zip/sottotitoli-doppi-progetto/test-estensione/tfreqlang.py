# 1.4.13: pagina «Parole più usate / che conosci»: il menu della lingua è sempre in alto (prima era nascosto in
# «Cambia lingua…», e la pagina restava sulla lingua del video, per esempio il russo) e c'è «Solo le parole che conosco».
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
ROWS = "[...document.querySelectorAll('#list tr')].map(r=>r.innerText.replace(/\\s+/g,' ').trim()).slice(0,8)"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({knownWords:{ru:'привет\\nмир', en:'bread\\nzzzqword\\nthe'}})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/freq.html?lang=ru&target=it"); await pg.wait_for_timeout(1500)
        vis = await pg.evaluate("!!document.getElementById('langSel').offsetParent")
        opts = await pg.evaluate("[...document.getElementById('langSel').options].filter(o=>/conosciute/.test(o.text)).map(o=>o.text)")
        print("1. russo: menu visibile", vis, "| lingue con parole:", opts, "|", await pg.inner_text("#title"))
        await pg.select_option("#langSel", "en"); await pg.wait_for_timeout(1500)
        print("2. inglese:", await pg.inner_text("#title"), "|", pg.url.split("?")[1])
        await pg.check("#onlyKnown"); await pg.wait_for_timeout(500)
        rows = await pg.evaluate(ROWS)
        print("3. solo conosciute:", rows)
        await pg.reload(); await pg.wait_for_timeout(1500)
        rows2 = await pg.evaluate(ROWS)
        print("4. dopo aver ricaricato:", await pg.is_checked("#onlyKnown"), rows2[:3])
        await pg.goto(f"chrome-extension://{eid}/freq.html"); await pg.wait_for_timeout(1500)
        print("5. senza lingua nell'indirizzo:", await pg.inner_text("#title"))
        ok = vis and "English" not in "" and any("bread" in r for r in rows) and any("zzzqword" in r for r in rows) and not any("market" in r for r in rows) and "inglese" in (await pg.inner_text("#title"))
        print("errori:", errs if ok else errs + ["pagina lingue non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

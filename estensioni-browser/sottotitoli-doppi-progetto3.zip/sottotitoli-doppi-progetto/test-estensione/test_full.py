import asyncio, json, sys, os, subprocess, shutil, glob
from charness import *
PROFILE = "/tmp/pwprofile"
async def main():
    shutil.rmtree(PROFILE, ignore_errors=True); shutil.rmtree("/tmp/sdhome", ignore_errors=True)
    os.makedirs("/tmp/sdhome", exist_ok=True)
    env = dict(os.environ, FAKE_AUDIO="/tmp/speech.wav", FAKE_LOG="/tmp/fake-ytdlp.log")
    open("/tmp/fake-ytdlp.log", "w").close()
    async with async_playwright() as p:
        ctx, sw = await launch(p, PROFILE, env)
        ext = sw.url.split("/")[2]
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', transcribeMode:'full', fullMaxMin:60})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}}))""")
        errs = []
        st = lambda: sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)")

        # --- A. programma NON installato: la modalità Completa ripiega su "mentre guardi"
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsA"); await pg.wait_for_timeout(1500)
        print("   indirizzo del video:", (await pg.evaluate("document.querySelector('video').src"))[:30])
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(3000)
        print("A. senza programma:", await st())
        await pg.wait_for_timeout(9000)
        print("   poi, sul video:", await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent"))
        await pg.close()

        # --- B. installatore scaricato dalla pagina del programma ed eseguito
        hp = await ctx.new_page(); hp.on("pageerror", lambda e: errs.append("helper: " + str(e)))
        await hp.goto(f"chrome-extension://{ext}/helper.html"); await hp.wait_for_timeout(1500)
        print("B. stato prima:", await hp.inner_text("#status"))
        await hp.select_option("#os", "linux")
        async with hp.expect_download() as d:
            await hp.click("#download")
        path = await (await d.value).path()
        sh = open(path).read()
        print("   installatore:", (await d.value).suggested_filename, "| contiene l'ID dell'estensione:", ext in sh, "| programma incluso:", "__HOSTB64__" not in sh)
        r = subprocess.run(["sh", path], capture_output=True, text=True, env=dict(os.environ, HOME="/tmp/sdhome",
            SD_YTDLP_URL="file:///home/claude/e2e/fake/yt-dlp", SD_DENO_URL="file:///tmp/fakedeno.zip",
            SD_EXTRA_CHROME_DIRS=PROFILE + "/NativeMessagingHosts"))
        print("   esecuzione:", r.returncode, "|", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-300:])
        await hp.click("#check"); await hp.wait_for_timeout(2500)
        print("   stato dopo:", await hp.inner_text("#status"), "|", await hp.inner_text("#details"))

        # --- C. modalità Completa su YouTube con il programma
        n0 = len(log["groq"])
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsFull"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        seen = []
        for _ in range(40):
            await pg.wait_for_timeout(500)
            t = await pg.evaluate("(document.querySelector('.dualsub-trans')||{}).textContent||''")
            if t and (not seen or seen[-1] != t): seen.append(t)
            if "GEM[" in t: break
        print("C. sul video durante l'attesa:", [x for x in seen if x.startswith("⏳")][:4])
        print("   yt-dlp ha ricevuto:", open("/tmp/fake-ytdlp.log").read().strip().split(" ")[-1])
        print("   richieste a Groq:", len(log["groq"]) - n0, "| file inviati:", log["groq_files"][-1])
        await pg.wait_for_timeout(15000)
        dbg = json.loads(await pg.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))
        print("   frasi:", len(dbg), "| tradotte da Gemini:", sum(1 for c in dbg if (c['trans'] or '').startswith('GEM[')))
        for sec in [5, 33, 60]:
            await pg.evaluate(f"const v=document.querySelector('video'); v.currentTime={sec}; v.pause()"); await pg.wait_for_timeout(400)
            print(f"   a {sec} s:", await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent"), "|", await pg.evaluate("(document.querySelector('.dualsub-trans')||{}).textContent"))
        tid = await sw.evaluate("chrome.tabs.query({}).then(t=>t.find(x=>(x.url||'').includes('noCapsFull')).id)")
        print("   stato per il popup:", await sw.evaluate(f"chrome.tabs.sendMessage({tid}, {{type:'liveState'}})"))
        await pg.close()

        # --- D. rivedere lo stesso video: nessuna richiesta
        n1 = len(log["groq"]); g1 = len(log.get("gcalls", []))
        pg = await ctx.new_page()
        await pg.goto("https://www.youtube.com/watch?v=noCapsFull"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(4000)
        print("D. rivisto: Groq +", len(log["groq"]) - n1, "Gemini +", len(log.get("gcalls", [])) - g1, "|", await st())
        await pg.close()

        # --- E. file grande (28 MB): diviso nel browser
        os.environ["FAKE_AUDIO"] = "/tmp/big.wav"
        await ctx.close()
    env["FAKE_AUDIO"] = "/tmp/big.wav"
    async with async_playwright() as p:
        ctx, sw = await launch(p, PROFILE, env)
        n2 = len(log["groq"])
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsBig"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        for _ in range(60):
            await pg.wait_for_timeout(500)
            s = await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)")
            if "Trascrizione completa" in (s or "") or "non riuscita" in (s or ""): break
        print("E. file grande:", s, "| richieste a Groq:", len(log["groq"]) - n2, "| file inviati:", log["groq_files"][n2:])
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

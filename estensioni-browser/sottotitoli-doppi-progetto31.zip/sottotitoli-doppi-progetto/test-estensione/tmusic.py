# 1.6.3: YouTube Music (music.youtube.com): il pulsante DS e i sottotitoli doppi compaiono come su YouTube; clic ripetuti su DS contano uno solo
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnNgram:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://music.youtube.com/watch?v=musicTest1"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/./.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        btn = pg.locator(".dualsub-toggle")
        print("1. DS su YouTube Music: pulsante", await btn.count(), "| riga:", (await pg.evaluate("document.querySelector('.dualsub-orig').textContent"))[:50], "| traduzione:", (await pg.evaluate("document.querySelector('.dualsub-trans').textContent"))[:50])
        # clic ripetuti: uno solo
        s0 = await sw.evaluate("chrome.storage.sync.get('enabled').then(r=>r.enabled)")
        for _ in range(4): await btn.first.click(force=True)
        await pg.wait_for_timeout(1500)
        s1 = await sw.evaluate("chrome.storage.sync.get('enabled').then(r=>r.enabled)")
        print("2. 4 clic di fila su DS: enabled", s0, "→", s1, "(un solo clic conta: da acceso a spento)")
        ok = (await btn.count()) == 1 and s0 is not False and s1 is False
        print("errori:", errs if ok else errs + ["YouTube Music / clic ripetuti non vanno"], log["errors"])
        await ctx.close()
asyncio.run(main())

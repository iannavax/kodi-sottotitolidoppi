# Etimologia che rimanda a un'altra parola della stessa lingua: embarazada → embarazado (forma) → "participio di
# embarazar" → embarazar ← portoghese embaraçar ← baraço. Si segue il rimando su Wiktionary, senza modello.
# Uso: python3 tetym_chain.py <estensione con pdf.html (Parole al Volo o unica)>
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it'})")
        eid = sw.url.split("/")[2]
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/pdf.html"); await pg.wait_for_timeout(800)
        r = await pg.evaluate("DS_ETYM.get('embarazada', 'es', 'it').then(r => ({text: r.text, trans: r.trans, lemma: r.lemma}))")
        print("1. embarazada:", r)
        print("   pagine chieste:", log.get("wikt"))
        r = await pg.evaluate("DS_ETYM.get('walked', 'en', 'it').then(r => r.text)")
        print("2. walked (non cambia):", r)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

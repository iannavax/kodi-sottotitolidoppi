## Trascrizione: Completa, Mentre guardo o Spenta

Per i video senza sottotitoli puoi scegliere come trascrivere (popup, sezione **Video senza sottotitoli**):
- **Completa:** appena apri il video, l'audio intero viene scaricato e trascritto in pochi secondi, poi tradotto a partire dal punto in cui sei. Pause, salti e velocità non contano più, e i sottotitoli escono in pari con il video. Su YouTube, Vimeo, VK e simili serve il **programma per yt-dlp** (vedi sotto). Sui file diretti (mp4, mp3…) non serve.
- **Mentre guardo:** come prima, trascrive quello che guardi.
- **Spenta:** non parte da sola.

Nel popup ci sono due scelte:
- **Modalità predefinita**, con un limite di durata ("Completa solo fino a… minuti", 60 di partenza): oltre quel limite, in automatico si usa "Mentre guardo", così un film di due ore aperto per sbaglio non consuma la quota di Groq.
- **Per questo video**, che vale solo per il video aperto e vince su quella predefinita. Scegliendo "Completa" lì, il limite di durata non vale.

Se la modalità Completa non riesce (programma non installato, YouTube che blocca, sito non supportato), l'estensione te lo dice e passa da sola a "Mentre guardo".

Un video trascritto per intero resta salvato: rivederlo non consuma nessuna richiesta.

## Il programma per yt-dlp

Il browser non permette alle estensioni di avviare programmi, quindi yt-dlp va installato una volta a parte:
1. Popup → **Video senza sottotitoli** → **Programma per yt-dlp**.
2. Premi **Scarica l'installatore** e lancialo (su Windows con un doppio clic; se Windows avvisa, scegli "Ulteriori informazioni" e poi "Esegui comunque").
3. Torna sulla pagina e premi **Verifica di nuovo**: deve comparire "Installato e funzionante".

L'installatore mette tutto in `%LOCALAPPDATA%\SottotitoliDoppi`, solo per il tuo utente e senza permessi di amministratore: yt-dlp, Deno (che serve a yt-dlp per YouTube) e il programma di appoggio. Se manca Python, lo installa con winget. yt-dlp si aggiorna da solo ogni pochi giorni. Se un giorno YouTube smette di funzionare, rilancia l'installatore.

L'installatore scaricato da Edge registra il programma per Edge (e Chrome) e per Firefox. Se usi l'estensione in più browser Chromium, scaricalo e lancialo da ognuno.

Tieni presente che i termini di servizio di YouTube non permettono di scaricare i video. L'audio viene usato solo per la trascrizione e cancellato subito.


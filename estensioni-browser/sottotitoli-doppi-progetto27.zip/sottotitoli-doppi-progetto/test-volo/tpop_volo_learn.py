import asyncio, sys, os
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
PX = "p-" if __import__("os").path.exists(EXT + "/popup-pagine.js") and not __import__("os").path.exists(EXT + "/popup-pagine.html") else ""   # popup unico (unica 1.5.0): id di Parole al Volo con «p-»
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        eid = sw.url.split("/")[2]
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/{'popup-pagine.html' if __import__('os').path.exists(EXT + '/popup-pagine.html') else 'popup.html'}"); await pg.wait_for_timeout(1000)
        print("checkbox:", await pg.evaluate("['learnFreq','" + PX + "learnKnownPage','ankiImage'].map(k=>document.getElementById(k).checked)"))
        await pg.evaluate("document.querySelectorAll('details').forEach(d=>d.open=true)"); await pg.check("#" + PX + "learnKnownPage"); await pg.wait_for_timeout(300)
        print("salvata:", await sw.evaluate("chrome.storage.sync.get('learnKnownPage')"))
        await sw.evaluate("chrome.storage.local.set({vocab:{'en|bread':{id:'en|bread',kind:'word',word:'bread',lang:'en',meaning:'pane',gender:'neutro',image:'https://upload.wikimedia.org/x.jpg',status:'learning',added:1}}})")
        pv = await ctx.new_page(); pv.on("pageerror", lambda e: errs.append(str(e))); await pv.goto(f"chrome-extension://{eid}/vocab.html"); await pv.wait_for_timeout(700)
        print("vocab:", await pv.evaluate("document.querySelector('.entry').innerText.replace(/\\n/g,' | ')"), "| img:", await pv.evaluate("!!document.querySelector('.entry img')"))
        await pv.get_by_role("button", name="Segna come imparata").click(); await pv.wait_for_timeout(600)
        print("known:", await sw.evaluate("chrome.storage.local.get('knownWords')"))
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

# 5.13: Anki diretto in Sottotitoli Doppi, un mazzo per lingua (Lingue::Inglese), file con il mazzo
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ankiTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        W = lambda t: words.nth(texts.index(t))
        await sw.evaluate("chrome.storage.sync.set({ankiAuto:true})"); await pg.wait_for_timeout(300)
        await W("market").click(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-card .dualsub-star").click(); await pg.wait_for_timeout(1500)
        add = [x[1]["note"] for x in log.get("anki", []) if x[0] == "addNote"]
        print("1. ☆ con invio ad Anki:", await pg.evaluate("(document.querySelector('.dualsub-anki-note')||{}).textContent"), "| pulsante Anki:", await pg.locator(".dualsub-card .dualsub-anki").count())
        print("   mazzo:", add[-1]["deckName"], "| tag:", add[-1]["tags"], "| fronte:", add[-1]["fields"]["Fronte"][:80], "| creati:", [x[1].get("deck") for x in log["anki"] if x[0] == "createDeck"])

        await pg.keyboard.press("Escape")
        # salvataggio con invio automatico
        await sw.evaluate("chrome.storage.sync.set({ankiAuto:true})"); await pg.wait_for_timeout(300)
        await W("bread").click(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-card .dualsub-star").click(); await pg.wait_for_timeout(1500)
        add = [x[1]["note"] for x in log.get("anki", []) if x[0] == "addNote"]
        print("3. ☆ con invio automatico:", add[-1]["fields"]["Fronte"][:30], add[-1]["deckName"], "| vocab anki:", await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab).map(e=>[e.word,e.anki]))"))
        await pg.keyboard.press("Escape")
        # mazzo unico
        await sw.evaluate("chrome.storage.sync.set({ankiPerLang:false, ankiDeck:'Mio mazzo'})"); await pg.wait_for_timeout(300)
        await W("home").click(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-card .dualsub-star").click(); await pg.wait_for_timeout(1500)
        add = [x[1]["note"] for x in log.get("anki", []) if x[0] == "addNote"]
        print("4. mazzo unico:", add[-1]["deckName"])
        await sw.evaluate("chrome.storage.sync.set({ankiPerLang:true, ankiLangDeck:'{lingua}'})")
        # vocabolario: manda ad Anki + file
        vp = await ctx.new_page(); vp.on("pageerror", lambda e: errs.append("vocab: " + str(e)))
        await sw.evaluate("chrome.storage.local.get('vocab').then(r=>{const v=r.vocab; v['cs|chleba']={id:'cs|chleba',word:'chleba',lang:'cs',meaning:'pane',status:'learning',added:2}; return chrome.storage.local.set({vocab:v})})")
        await vp.goto(f"chrome-extension://{eid}/vocab.html"); await vp.wait_for_timeout(800)
        await vp.select_option("#filter", "all"); await vp.wait_for_timeout(300)
        await vp.click("#send"); await vp.wait_for_timeout(1500)
        add = [x[1]["note"] for x in log.get("anki", []) if x[0] == "addNote"]
        print("5. vocabolario → Anki:", await vp.inner_text("#ankiMsg"), "| ultimo mazzo:", add[-1]["deckName"])
        async with vp.expect_download() as dl: await vp.click("#export")
        d = await dl.value; path = await d.path(); txt = open(path, encoding="utf-8").read().split("\n")
        print("6. file:", txt[:4], "| righe:", [l.split("\t")[3] for l in txt[4:] if l])
        # popup
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append("popup: " + str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1000)
        await pp.evaluate("document.getElementById('dAnki').open=true"); await pp.click("#ankiTest"); await pp.wait_for_timeout(1000)
        print("7. popup:", await pp.inner_text("#ankiStatus"), "| per lingua:", await pp.is_checked("#ankiPerLang"), await pp.input_value("#ankiLangDeck"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

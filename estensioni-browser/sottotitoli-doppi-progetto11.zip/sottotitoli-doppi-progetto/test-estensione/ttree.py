# Albero etimologico di Wiktionary nella scheda: «🌳 albero etimologico» mostra i rami (radice → parola); il testo
# dell'etimologia resta pulito. Uso: python3 ttree.py <estensione>
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
ETYM = "(document.querySelector('.dualsub-card .dsx-etym')||{}).innerText||'(nessuna)'"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnFreq:false, learnSpell:false, learnGweb:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(3000)
        print("1. riga:", (await pg.evaluate(ETYM)).replace("\n", " | ")[:200])
        await pg.locator(".dualsub-card .dsx-etym button", has_text="albero").click(); await pg.wait_for_timeout(500)
        print("2. albero (" + os.environ.get("WIKT_TREE", "1") + "):", await pg.evaluate("[(document.querySelector('.dualsub-card .dsx-wtree > div')||{}).textContent, ...[...document.querySelectorAll('.dualsub-card .dsx-wtree li')].map(li=>li.firstChild.textContent.trim())]"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

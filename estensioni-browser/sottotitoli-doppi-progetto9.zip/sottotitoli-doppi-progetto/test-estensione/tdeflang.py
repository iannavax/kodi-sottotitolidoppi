# Spiegazione del modello nella lingua di «Traduci in»: una spiegazione in inglese viene richiesta di nuovo (o tolta),
# il falso amico con una parola inglese o "non è un falso amico" non compare, quello vero sì.
import asyncio, os, sys, subprocess
sys.path.insert(0, "/home/claude/e2e")
CASES = [("en_always", "ff_en"), ("en_once", "ff_neg"), ("en_once", "ff_ok")]
if len(sys.argv) > 2 and sys.argv[2] == "--case":
    from charness import *
    EXPL = "(document.querySelector('.dualsub-card .dualsub-card-expl')||{}).textContent||'(nessuna)'"
    FF = "(document.querySelector('.dualsub-card .dsx-false')||{}).textContent||'(nessuno)'"
    async def main():
        async with async_playwright() as p:
            ctx, sw = await launch(p, "", None)
            await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', ipa:false, hoverPause:true, idioms:false, learnExamples:false, learnSpell:false, learnFreq:false, etym:false})
              .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
            pg = await ctx.new_page(); errs = []
            pg.on("pageerror", lambda e: errs.append(str(e)))
            await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
            await pg.evaluate("document.querySelector('video').play()")
            await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
            await pg.evaluate("document.querySelector('video').pause()")
            words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
            await words.nth(texts.index("bread")).click()
            for _ in range(40):
                await pg.wait_for_timeout(500)
                if not await pg.evaluate("/Chiedo a/.test((document.querySelector('.dualsub-card')||{}).innerText||'')"): break
            print(f"  {os.environ['DEF_BAD']}/{os.environ['DEF_FF']}: spiegazione:", await pg.evaluate(EXPL), "| falso amico:", await pg.evaluate(FF), "| seconda richiesta:", log.get("def_strict"))
            print("  errori:", errs, log["errors"])
            await ctx.close()
    asyncio.run(main())
else:
    for bad, ff in CASES:
        subprocess.run([sys.executable, __file__, sys.argv[1], "--case"], env={**os.environ, "DEF_BAD": bad, "DEF_FF": ff})

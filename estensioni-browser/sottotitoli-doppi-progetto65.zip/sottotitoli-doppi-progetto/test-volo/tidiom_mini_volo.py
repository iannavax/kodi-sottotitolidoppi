# 1.7.2: sulle pagine, un clic su una parola di un modo di dire apre la scheda piccola; la ricerca parte solo dal suo pulsante
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "market", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        await pg.get_by_role("button", name="Spiega con Groq").click(); await pg.wait_for_timeout(4000)
        n0 = len(tvolo.log.get("idiomsAbout", []))
        w = pg.locator(".pav-card .dsx-iditem .dsx-idw", has_text="flea").first
        print("1. parole cliccabili nei modi di dire:", await pg.locator(".pav-card .dsx-iditem .dsx-idw").count())
        await w.click(); await pg.wait_for_timeout(1500)
        mini = await pg.evaluate("(document.querySelector('.pav-card .dsx-idmini')||{}).innerText||''")
        print("2. scheda piccola:", mini.replace("\n", " | "), "| ricerche partite da sole:", len(tvolo.log.get("idiomsAbout", [])) - n0)
        print("   pulsanti nella scheda piccola:", await pg.evaluate("[...document.querySelectorAll('.pav-card .dsx-idmini button')].map(b=>b.textContent)"), "| ttutti i pulsanti 'Spiega':", await pg.evaluate("[...document.querySelectorAll('.pav-card button')].map(b=>b.textContent).filter(t=>/Spiega/.test(t))"))
        d0 = len(tvolo.log.get("define_user", []))
        await pg.locator(".pav-card .dsx-idmini .dsx-idmai").click(); await pg.wait_for_timeout(3500)
        mini2 = await pg.evaluate("(document.querySelector('.pav-card .dsx-idmini')||{}).innerText||''")
        print("2b. dopo «✨ Spiega»:", mini2.replace("\n", " | "), "| richieste di spiegazione:", len(tvolo.log.get("define_user", [])) - d0, tvolo.log.get("define_user", [])[d0:])
        assert len(tvolo.log.get("define_user", [])) - d0 == 1 and "Spiegazione finta" in mini2
        await pg.locator(".pav-card .dsx-idmini .dsx-idmgo").click(); await pg.wait_for_timeout(2500)
        head = await pg.evaluate("(document.querySelector('.pav-card .dsx-idhead')||{}).innerText||''")
        print("3. dopo il pulsante:", head, "| ricerche:", len(tvolo.log.get("idiomsAbout", [])) - n0)
        ok = mini and len(tvolo.log.get("idiomsAbout", [])) - n0 == 1 and "flea" in head
        print("errori:", errs if ok else errs + ["scheda piccola dei modi di dire non va"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

// ---------- Diretta in anticipo (yt-dlp) ----------
// Nelle dirette i sottotitoli trascritti arrivano qualche secondo dopo il parlato: per trascrivere bisogna prima
// sentire. Con questa modalità il video della diretta resta qualche secondo indietro, mentre il programma di appoggio
// legge con yt-dlp l'audio dal punto più recente della diretta: le frasi sono già trascritte (e tradotte) quando il
// video arriva lì, e si vedono in orario.
// L'audio di yt-dlp e il video non hanno un orologio in comune: li metto a tempo confrontando l'andamento del volume
// (parlato e pause) dei due audio. Quello del video lo cattura già la trascrizione normale (live.js), che resta
// attiva finché l'allineamento non è trovato e torna da sola se qualcosa non va.
const AHEAD_ENV = 50;           // ms per ogni valore dell'andamento del volume
const AHEAD_WIN = 200;          // valori confrontati (10 s)
const AHEAD_LEAD = 12000;       // anticipo minimo voluto: se è meno, porto il video ancora un po' indietro
const AHEAD_KEEP = 1200000;     // audio tenuto in attesa al massimo 20 min avanti (video in pausa a lungo): oltre si scarta
let ahead = null;

function aheadWanted(video) {
  return !!(settings && settings.liveAhead && DS_IS_YT && video && dsIsLiveStream(video));
}

function aheadHlsUrl() {
  return new Promise((res) => {
    if (!DS_IS_YT || typeof toPage !== "function" || typeof pending === "undefined") return res("");
    const id = "hls" + Date.now() + Math.random().toString(36).slice(2);
    pending.set(id, { resolve: res, reject: () => res("") });
    toPage({ type: "hlsUrl", id });
    setTimeout(() => { if (pending.has(id)) { pending.delete(id); res(""); } }, 1500);
  });
}
function aheadUrl() {
  const v = live.videoId || currentVideoId() || "";
  return /^[\w-]{11}$/.test(v) ? "https://www.youtube.com/watch?v=" + v : location.href;
}

function aheadStart() {
  if (ahead || !live.running || !aheadWanted(live.el)) return;
  if (live.aheadOff === live.videoId) return;   // già fallita per questa diretta: resta la trascrizione normale
  let port;
  try { port = DS_EXT.runtime.connect({ name: "sd-live" }); } catch { return; }
  ahead = {
    port, videoId: live.videoId, env: [], envBase: -1, frames: [], framesMs: 0, lastHs: 0,
    offset: null, hold: [], pEnv: [], pCarry: null, pCarryVt: 0, alignAt: 0, delayAt: 0, pcmCount: 0,
    startedAt: Date.now(), backSteps: 0
  };
  const me = ahead;
  // controllo ogni 5 s: se yt-dlp non manda audio (o l'audio non si mette a tempo) non resto per sempre «a metà»
  me.watch = setInterval(() => aheadWatch(me), 5000);
  port.onMessage.addListener((m) => { if (ahead === me) aheadOnMessage(m); });
  port.onDisconnect.addListener(() => { if (ahead === me) aheadFail("il collegamento con il programma di appoggio si è chiuso"); });
  // l'indirizzo HLS della diretta dal lettore di YouTube (se c'è): il programma la legge prima con ffmpeg, poi con yt-dlp
  aheadHlsUrl().then((hls) => {
    if (ahead !== me) return;
    try { port.postMessage({ url: aheadUrl(), hls }); } catch {}
    dsLiveLog("sincronizzata: avvio la lettura per " + aheadUrl() + (hls ? " (con l'indirizzo HLS del lettore)" : " (senza indirizzo HLS: solo yt-dlp)"));
  });
  live.aheadWhy = "";
  setStatus("Diretta sincronizzata: avvio la lettura dell'audio della diretta…");
  aheadToast("⏱ Diretta sincronizzata: porto il video qualche secondo indietro e leggo l'audio in anticipo…");
  aheadDelay(true);   // il video va indietro subito: si vede che la modalità è partita
}

// Porta il video indietro di `back` secondi con i comandi del lettore di YouTube (relativo: nelle dirette il punto
// preciso non si può calcolare dal video, perché video.seekable copre solo i pochi secondi già scaricati). Poi
// controllo che si sia spostato davvero; se no provo direttamente sul video; se ancora no, la diretta non si può
// riavvolgere (YouTube a volte lo vieta): lo dico invece di non fare niente in silenzio.
function aheadSeekBack(back) {
  const v = live.el, a = ahead;
  if (!v || !a || !(back > 0)) return;
  const before = v.currentTime, at = Date.now();
  a.seeking = true;
  live.seekAt = Date.now();
  dsLiveLog("indietro di " + back.toFixed(1) + " s (era a " + before.toFixed(1) + ")");
  if (DS_IS_YT && typeof toPage === "function") toPage({ type: "seekBy", s: -back });
  else v.currentTime = Math.max(0, before - back);
  // dove poteva arrivare: non prima dell'inizio della parte riavvolgibile (YouTube si ferma lì)
  const minT = (() => { try { return v.seekable && v.seekable.length ? v.seekable.start(0) : 0; } catch { return 0; } })();
  const target = Math.max(minT, before - back);
  // dov'è adesso rispetto a dove doveva essere (il video intanto va avanti)
  const off = () => v.currentTime - (target + (v.paused ? 0 : (Date.now() - at) / 1000));
  // spostato fin dove si poteva: il resto lo recupero con una pausa (prima: pausa di tutto il tempo, video troppo indietro)
  const done = () => {
    a.seeking = false;
    const missing = back - (before - target);
    if (missing > 2) aheadPauseBack(missing, a); else a.delayAt = Date.now();
  };
  setTimeout(() => {
    if (ahead !== a) return;
    if (off() < 5) { done(); return; }
    dsLiveLog("il lettore non si è spostato: provo direttamente sul video");
    live.seekAt = Date.now();
    try { v.currentTime = target + (Date.now() - at) / 1000; } catch {}
    setTimeout(() => {
      if (ahead !== a) return;
      if (off() < 5) { done(); return; }
      // il salto indietro non riesce (diretta senza riavvolgimento, o lettore che torna alla diretta): metto il video in
      // pausa per quei secondi. La diretta intanto va avanti, quindi quando riparte il video è indietro quanto serve.
      aheadPauseBack(back, a);
    }, 2500);
  }, 2500);
}
function aheadPauseBack(back, a) {
  const v = live.el;
  if (!v || ahead !== a) return;
  const secs = Math.max(3, Math.round(back));
  dsLiveLog("pausa di " + secs + " s (il salto indietro non è arrivato fin lì)");
  a.pausing = true;
  live.seekAt = Date.now();
  try { v.pause(); } catch {}
  const end = Date.now() + secs * 1000;
  const tick = () => {
    if (ahead !== a) { a.pausing = false; return; }
    const left = Math.ceil((end - Date.now()) / 1000);
    if (left > 0) {
      aheadToast(`⏱ Diretta sincronizzata: il video resta fermo ancora ${left} s, così poi resta indietro e i sottotitoli arrivano in tempo.`, 2500);
      // se lo fai ripartire tu, va bene lo stesso: resta indietro di quanto è stato fermo
      if (!v.paused) { a.pausing = false; a.seeking = false; a.delayAt = Date.now(); return; }
      setTimeout(tick, 1000);
      return;
    }
    a.pausing = false; a.seeking = false;
    live.seekAt = Date.now();
    a.delayAt = Date.now();   // i 30 s prima di un altro salto contano da adesso, non da quando è cominciata la pausa
    const p = v.play();
    if (p && p.catch) p.catch(() => aheadToast("⏱ Premi Play: il video riparte qualche secondo indietro rispetto alla diretta.", 10000));
  };
  tick();
}
// di nuovo al momento attuale della diretta
function aheadBackToLive() {
  const v = live.el;
  live.seekAt = Date.now();
  if (DS_IS_YT && typeof toPage === "function") toPage({ type: "seekLive" });
  else if (v && v.buffered && v.buffered.length) v.currentTime = v.buffered.end(v.buffered.length - 1) - 1;
}
// avviso sul video, accanto ai sottotitoli (il popup non sempre è aperto)
function aheadToast(text, ms = 8000) {
  if (typeof overlay === "undefined" || !overlay) return;
  let t = overlay.querySelector(".dualsub-toast");
  if (!t) { t = document.createElement("div"); t.className = "dualsub-toast"; overlay.append(t); }
  t.textContent = text; t.hidden = false;
  clearTimeout(aheadToast.timer);
  aheadToast.timer = setTimeout(() => { t.hidden = true; }, ms);
}

// Diretta sincronizzata ferma a metà: dal registro di un utente, yt-dlp partito ma nessun audio per 4 minuti (stato
// «aligning» per sempre, video tenuto indietro per niente, sottotitoli in ritardo come senza). Dopo 60 s senza audio, o
// 2 minuti di audio che non si riesce a mettere a tempo, lo dico e torno alla trascrizione normale (video alla diretta).
function aheadWatch(a) {
  if (ahead !== a) { clearInterval(a.watch); return; }
  const now = Date.now();
  if (!a.pcmCount) {
    const s = Math.round((now - a.startedAt) / 1000);
    if (s >= 20 && !a.warnedNoPcm) { a.warnedNoPcm = true; dsLiveLog("aspetto l'audio di yt-dlp da " + s + " s" + (a.lastHelper ? " (ultimo messaggio: " + a.lastHelper + ")" : "")); }
    // (il programma 1.5 prova tre strade: ffmpeg sull'indirizzo del lettore, yt-dlp, ffmpeg sull'indirizzo dato da yt-dlp)
    if (s >= 150) aheadFail("nessun audio della diretta in 150 s" + (a.lastHelper ? " (" + a.lastHelper + ")" : "") +
      ". Se il programma per yt-dlp è vecchio (sotto la 1.9) rilancia l'installatore: popup → 🎙 Trascrizione dell'audio → ⚙ Programma per yt-dlp");
    return;
  }
  if (a.offset == null) {
    if (!a.firstPcmAt) a.firstPcmAt = now;
    const s = Math.round((now - a.firstPcmAt) / 1000);
    if (s >= 120) aheadFail("non riesco a mettere a tempo l'audio letto da yt-dlp con quello del video (2 minuti)");
  }
}

function aheadStop() {
  if (!ahead) return;
  clearInterval(ahead.watch);
  const p = ahead.port;
  ahead = null;
  try { p.disconnect(); } catch {}
}

function aheadFail(why) {
  const vid = ahead && ahead.videoId, wasDelayed = ahead && ahead.delayed;
  aheadStop();
  live.aheadOff = vid;
  live.aheadWhy = why;
  if (!live.running) return;
  setStatus(`Diretta sincronizzata non disponibile: ${why}. Continuo con la trascrizione normale (frasi con qualche secondo di ritardo).`);
  aheadToast("⏱ Diretta sincronizzata non disponibile: " + why + ". Continuo con i sottotitoli normali.", 15000);
  dsLiveLog("sincronizzata fermata: " + why);
  // il video era stato portato indietro per niente: torna al momento attuale della diretta
  if (wasDelayed) aheadBackToLive();
}

function aheadOnMessage(m) {
  if (!m) return;
  if (m.type === "pcm") aheadOnPcm(m);
  else if (m.type === "status") { setStatus(m.text); if (ahead) ahead.lastHelper = String(m.text || "").slice(0, 200); }
  else if (m.type === "error") aheadFail(m.code === "nohelper" ? "manca il programma per yt-dlp (popup → 🎙 Trascrizione dell'audio → ⚙ Programma per yt-dlp)"
    : m.code === "unknown" ? "il programma per yt-dlp è di una versione vecchia: rilancia l'installatore dalla sua pagina (popup → 🎙 Trascrizione dell'audio)"
    : m.message || "errore");
  else if (m.type === "done") aheadFail("yt-dlp ha smesso di leggere la diretta");
  if (m.type === "status" || m.type === "error") dsLiveLog("programma per yt-dlp: " + (m.text || m.message || m.code || ""));
}

// ---------- audio letto da yt-dlp ----------
function aheadOnPcm(m) {
  const a = ahead;
  const bin = atob(m.data || "");
  const n = bin.length >> 1;
  if (!n) return;
  const pcm = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let v = bin.charCodeAt(2 * i) | (bin.charCodeAt(2 * i + 1) << 8);
    if (v >= 0x8000) v -= 0x10000;
    pcm[i] = v / 32768;
  }
  const hs0 = (m.pos || 0) / (LIVE_RATE / 1000);   // posizione nell'audio di yt-dlp, in ms
  // misure per il registro (ogni 15 s): quanto audio è arrivato e a che velocità. Se arriva solo «1 s al secondo» fin
  // dall'inizio, il programma legge la diretta in tempo reale e non ha audio «in anticipo» da mettere a tempo
  const tNow = Date.now();
  if (!a.rx) a.rx = { t0: tNow, s: 0, at: tNow };
  a.rx.s += n / LIVE_RATE;
  if (tNow - a.rx.at > 15000) {
    a.rx.at = tNow;
    const el = (tNow - a.rx.t0) / 1000;
    dsLiveLog(`misura: audio letto ${a.rx.s.toFixed(0)} s in ${el.toFixed(0)} s (${(a.rx.s / Math.max(1, el)).toFixed(2)} s al secondo)` +
      (a.bestScore != null ? `, somiglianza migliore con il video ${a.bestScore.toFixed(2)} (serve 0,75)` + (a.bestLag != null ? `, a ${(a.bestLag / 1000).toFixed(0)} s` : "") : "") +
      (a.offset != null ? `, a tempo: frasi pronte ${Math.round((a.lastHs + a.offset - (live.el ? live.el.currentTime * 1000 : 0)) / 1000)} s prima` : ", non ancora a tempo"));
  }
  // andamento del volume, un valore ogni 50 ms (indice assoluto = posizione / 50 ms)
  const per = (LIVE_RATE * AHEAD_ENV) / 1000;
  if (a.envBase < 0) a.envBase = Math.round(hs0 / AHEAD_ENV);
  for (let i = 0; i + per <= n; i += per) {
    let s = 0;
    for (let j = i; j < i + per; j++) s += pcm[j] * pcm[j];
    a.env.push(Math.sqrt(s / per));
  }
  if (a.env.length > 6000) { const cut = a.env.length - 6000; a.env.splice(0, cut); a.envBase += cut; }   // ultimi 5 minuti
  // pezzi da 100 ms per tagliare nelle pause, come la trascrizione normale
  const fl = LIVE_RATE / 10;
  for (let i = 0; i < n; i += fl) {
    const part = pcm.subarray(i, Math.min(n, i + fl));
    let s = 0;
    for (let j = 0; j < part.length; j++) s += part[j] * part[j];
    a.frames.push({ pcm: part, rms: Math.sqrt(s / Math.max(1, part.length)), hs: hs0 + (i * 1000) / LIVE_RATE, realMs: (part.length * 1000) / LIVE_RATE });
    a.framesMs += (part.length * 1000) / LIVE_RATE;
  }
  a.lastHs = hs0 + (n * 1000) / LIVE_RATE;
  a.pcmCount++;
  aheadDecideCut();
  if (a.pcmCount === 1) setStatus("Diretta sincronizzata: leggo l'audio della diretta. Metto a tempo i sottotitoli con il video (qualche secondo)…");
  aheadDelay();
}

function aheadDecideCut() {
  const a = ahead, fr = a.frames;
  // pezzi più lunghi quanto più il video è indietro (popup «Quanto indietro guardi la diretta»): meno richieste a Whisper
  const prof = dsAheadProfile(settings.liveAheadDelay);
  if (a.framesMs < prof.minMs) return;
  const mean = fr.reduce((x, f) => x + f.rms, 0) / fr.length;
  const thr = Math.max(0.0015, mean * 0.35);
  let quietMs = 0;
  for (let i = fr.length - 1; i >= 0 && fr[i].rms < thr; i--) quietMs += fr[i].realMs;
  if (quietMs >= LIVE_QUIET_MS) { aheadFlush(fr.length); return; }
  if (a.framesMs >= prof.maxMs) {
    let acc = 0, best = -1, bestRms = Infinity;
    for (let i = fr.length - 1; i > 0; i--) {
      acc += fr[i].realMs;
      if (acc < 300) continue;
      if (acc > 4000) break;
      if (fr[i].rms < bestRms) { bestRms = fr[i].rms; best = i; }
    }
    aheadFlush(best < 0 ? fr.length : best + 1);
  }
}

function aheadFlush(count) {
  const a = ahead;
  const out = a.frames.splice(0, count);
  a.framesMs = a.frames.reduce((x, f) => x + f.realMs, 0);
  if (!out.length) return;
  const realMs = out.reduce((x, f) => x + f.realMs, 0);
  const meanRms = out.reduce((x, f) => x + f.rms, 0) / out.length;
  if (realMs < 700 || meanRms < 0.002) return;   // troppo corto o solo silenzio
  const total = out.reduce((x, f) => x + f.pcm.length, 0);
  const pcm = new Float32Array(total);
  let off = 0;
  for (const f of out) { pcm.set(f.pcm, off); off += f.pcm.length; }
  const item = { pcm, s: out[0].hs, e: out[0].hs + realMs, rate: 1, gen: live.gen, ahead: true };
  if (a.offset == null) {
    a.hold.push(item);                                   // non so ancora dove cade nel video: aspetto
    while (a.hold.length && a.hold[0].e < item.e - 180000) a.hold.shift();
    return;
  }
  aheadQueue(item);
}

// pezzo con i tempi del video: in coda per Whisper (solo se il video non l'ha già passato)
function aheadQueue(item) {
  const a = ahead, v = live.el;
  item.s += a.offset; item.e += a.offset;
  item.gen = live.gen;
  if (v && item.e < v.currentTime * 1000 + 300) return false;
  // video in pausa a lungo: l'audio in attesa non cresce all'infinito (memoria)
  if (v && item.s > v.currentTime * 1000 + AHEAD_KEEP) return false;
  live.queue.push(item);
  liveProcessQueue();
  return true;
}

// ---------- audio del video (dalla trascrizione normale): serve per metterlo a tempo ----------
// Restituisce true quando l'anticipo funziona: allora la trascrizione normale non manda più niente a Whisper.
function aheadOnPlayerAudio(pcm, vtStart, realMs, rate) {
  const a = ahead;
  if (!a) return false;
  if (rate === 1 && pcm.length) {
    const per = (LIVE_RATE * AHEAD_ENV) / 1000;
    // continuo dell'audio di prima? altrimenti (salto, pausa) ricomincio l'andamento
    if (!a.pCarry || Math.abs(vtStart - a.pCarryVt) > 300) { a.pCarry = new Float32Array(0); a.pCarryVt = vtStart; if (a.pEnv.length) a.pEnv.push(null); }
    const buf = new Float32Array(a.pCarry.length + pcm.length);
    buf.set(a.pCarry); buf.set(pcm, a.pCarry.length);
    let i = 0;
    const vt0 = a.pCarryVt - (a.pCarry.length * 1000) / LIVE_RATE;
    for (; i + per <= buf.length; i += per) {
      let s = 0;
      for (let j = i; j < i + per; j++) s += buf[j] * buf[j];
      a.pEnv.push({ vt: vt0 + (i * 1000) / LIVE_RATE, v: Math.sqrt(s / per) });
    }
    a.pCarry = buf.slice(i);
    a.pCarryVt = vtStart + realMs;
    if (a.pEnv.length > 1200) a.pEnv.splice(0, a.pEnv.length - 1200);   // ultimo minuto
  }
  const now = Date.now();
  if (now - a.alignAt > (a.offset == null ? 2000 : 10000)) { a.alignAt = now; aheadAlign(); }
  return a.offset != null;
}

// Dove un tratto di volumi (win) cade dentro un altro più lungo (hay): correlazione in scala log.
// Restituisce l'indice migliore, solo se è chiaramente il migliore (altrimenti -1)
function aheadMatch(win, hay) {
  const n = win.length;
  if (hay.length < n + 10) return -1;
  const L = (x) => Math.log(x + 1e-4);
  const wv = win.map(L);
  const wm = wv.reduce((x, y) => x + y, 0) / n;
  const wd = wv.map((x) => x - wm);
  const wn = Math.sqrt(wd.reduce((x, y) => x + y * y, 0));
  if (wn < 2) return -1;   // quasi tutto silenzio: niente da confrontare
  const h = hay.map(L);
  const scores = new Float32Array(h.length - n + 1);
  let sum = 0;
  for (let k = 0; k < n; k++) sum += h[k];
  for (let j = 0; j < scores.length; j++) {
    if (j) sum += h[j + n - 1] - h[j - 1];
    const m = sum / n;
    let num = 0, den = 0;
    for (let k = 0; k < n; k++) { const d = h[j + k] - m; num += d * wd[k]; den += d * d; }
    scores[j] = den > 0 ? num / (Math.sqrt(den) * wn) : 0;
  }
  let best = 0;
  for (let j = 1; j < scores.length; j++) if (scores[j] > scores[best]) best = j;
  let second = -1;
  for (let j = 0; j < scores.length; j++) if (Math.abs(j - best) > 10 && scores[j] > second) second = scores[j];
  aheadMatch.last = { score: scores[best], j: best };   // per le misure del registro
  return scores[best] >= 0.75 && scores[best] - second >= 0.08 ? best : -1;
}

// Metto a tempo i due audio. Di solito yt-dlp è avanti: cerco l'ultimo tratto del video nell'audio di yt-dlp.
// Se invece yt-dlp è indietro, cerco il suo ultimo tratto in quello che il video ha già suonato.
function aheadAlign() {
  const a = ahead;
  if (!a) return;
  const run = [];   // ultimo tratto continuo dell'audio del video
  for (let i = a.pEnv.length - 1; i >= 0; i--) { if (!a.pEnv[i]) break; run.unshift(a.pEnv[i]); }
  if (run.length < AHEAD_WIN) return;
  let offset = null;
  const p = run.slice(-AHEAD_WIN);
  const j = aheadMatch(p.map((x) => x.v), a.env);
  // misura: la somiglianza migliore trovata e dove (anticipo dell'audio letto rispetto al video), anche se non basta
  if (aheadMatch.last && (a.bestScore == null || aheadMatch.last.score > a.bestScore)) {
    a.bestScore = aheadMatch.last.score;
    a.bestLag = Math.round((a.envBase + a.env.length) * AHEAD_ENV - (a.envBase + aheadMatch.last.j) * AHEAD_ENV);
  }
  if (j >= 0) offset = Math.round(p[0].vt - (a.envBase + j) * AHEAD_ENV);
  else if (a.env.length >= AHEAD_WIN) {
    const k = aheadMatch(a.env.slice(-AHEAD_WIN), run.map((x) => x.v));
    if (k >= 0) offset = Math.round(run[k].vt - (a.envBase + a.env.length - AHEAD_WIN) * AHEAD_ENV);
  }
  if (offset == null) return;
  if (a.offset == null) { a.offset = offset; aheadSwitch(); }
  else if (Math.abs(offset - a.offset) > 400) {
    // il flusso si è spostato (yt-dlp ha perso o ripetuto un pezzo): d'ora in poi uso il nuovo, e sposto anche le frasi
    // già pronte che il video non ha ancora raggiunto (prima restavano sfasate)
    const d = offset - a.offset, vNow = live.el ? live.el.currentTime * 1000 : 0;
    a.offset = offset;
    let moved = 0;
    for (const c of live.cues) if (c.item && c.item.ahead && c.start > vNow) { c.start += d; c.end += d; moved++; }
    for (const it of live.queue) if (it.ahead) { it.s += d; it.e += d; }
    live.cues.sort((x, y) => x.start - y.start);
    dsLiveLog("allineamento corretto di " + (d / 1000).toFixed(1) + " s (" + moved + " frasi spostate)");
  }
}

// Allineamento trovato: le frasi da qui in avanti vengono da yt-dlp (in anticipo), la trascrizione normale si ferma
function aheadSwitch() {
  const a = ahead, v = live.el;
  const vNow = v ? v.currentTime * 1000 : 0;
  live.frames = []; live.framesMs = 0;
  let from = Infinity;
  for (const item of a.hold.splice(0)) {
    const s = item.s + a.offset;
    if (aheadQueue(item) && s < from) from = s;
  }
  if (from === Infinity) from = a.lastHs + a.offset;
  from = Math.max(from, vNow);
  // quello che la trascrizione normale aveva già fatto dopo questo punto lo rifà yt-dlp (in orario)
  live.cues = live.cues.filter((c) => c.start < from);
  live.covered = live.covered.map(([x, y]) => [x, Math.min(y, from)]).filter(([x, y]) => y > x);
  live.queue = live.queue.filter((it) => it.ahead || it.s < from);
  const lead = Math.round((a.lastHs + a.offset - vNow) / 1000);
  dsLiveLog("audio di yt-dlp messo a tempo con il video: frasi pronte " + lead + " s prima");
  aheadToast(lead > 0 ? `⏱ Sottotitoli in orario: sono pronti ${lead} s prima che il video arrivi lì.` : "⏱ Audio messo a tempo: porto il video ancora un po' indietro…");
  setStatus(lead > 0 ? `Diretta sincronizzata attiva: i sottotitoli sono pronti ${lead} s prima che il video arrivi lì.`
    : "Diretta sincronizzata: audio messo a tempo, ma yt-dlp è indietro rispetto al video: porto il video più indietro.");
  aheadDelay(true);
}

// Il video resta indietro rispetto alla diretta quanto serve. All'inizio indietro di quanto chiesto nel popup; poi,
// quando l'audio di yt-dlp è messo a tempo, se l'anticipo è poco lo porto un po' più indietro.
function aheadDelay(force) {
  const a = ahead, v = live.el;
  if (!a || !v || v.paused || a.seeking || a.pausing) return;
  const now = Date.now();
  if (!force && now - a.delayAt < 20000) return;
  const want = dsAheadStep(settings.liveAheadDelay);
  let back = 0;
  if (a.offset == null) {
    if (!a.delayed) back = want;   // all'inizio: indietro quanto chiesto nel popup
    // dopo un po' ancora niente allineamento: forse yt-dlp legge la diretta più indietro del video. Porto il video
    // altri 15 s indietro (al massimo 3 volte), così l'audio di yt-dlp torna davanti
    // (30 s di video che va, dall'ultimo salto o pausa: l'allineamento ha bisogno di 10 s di audio continuo)
    // (1.5.3: tolto. Portava il video altri 15 s indietro, fino a 3 volte, pensando che yt-dlp leggesse più indietro del
    // video; nel registro di un utente era il contrario, e ogni salto allontanava il video dall'audio letto. Ora il
    // programma 1.9 legge anche i 2 minuti di diretta già passati, quindi il punto del video è sempre dentro)
  } else {
    const lead = a.lastHs + a.offset - v.currentTime * 1000;   // quanto audio c'è già oltre il punto del video
    if (lead < AHEAD_LEAD) back = (AHEAD_LEAD + 3000 - lead) / 1000;
  }
  if (!(back > 0)) return;
  a.delayAt = now;
  a.delayed = true;
  a.backTotal = (a.backTotal || 0) + back;
  aheadSeekBack(back);
  setStatus(`Diretta sincronizzata: porto il video ${Math.round(a.backTotal)} s indietro rispetto alla diretta, così i sottotitoli arrivano in tempo.`);
}

// ---------- Scelta della modalità (popup, pulsante ⏱ accanto ai sottotitoli) ----------
function aheadInfo() {
  if (!ahead) return live.aheadOff && live.aheadOff === live.videoId ? { state: "failed", why: live.aheadWhy || "" } : { state: "off" };
  const v = live.el;
  if (ahead.offset == null) return { state: "aligning" };
  return { state: "on", lead: v ? Math.round((ahead.lastHs + ahead.offset - v.currentTime * 1000) / 1000) : 0 };
}
// l'impostazione è cambiata (popup o ⏱): parte o si ferma subito
function aheadSettingChanged(on) {
  if (on) {
    live.aheadOff = null;
    if (live.running && aheadWanted(live.el)) aheadStart();
    else if (!live.running && live.el && dsIsLiveStream(live.el)) setStatus("Diretta sincronizzata scelta: parte con la trascrizione (popup → «Trascrivi l'audio di questo video»).");
  } else if (ahead) {
    aheadStop();
    live.frames = []; live.framesMs = 0;
    setStatus("Diretta: trascrizione normale passo passo (frasi con qualche secondo di ritardo). Il video resta dov'è: per tornare al momento attuale premi «DAL VIVO» su YouTube.");
  }
  aheadButtonUpdate();
}
function aheadButton() {
  const b = document.createElement("button");
  b.className = "dualsub-fixbtn dualsub-aheadbtn";
  b.textContent = "⏱";
  b.addEventListener("click", async (e) => {
    e.stopPropagation();
    settings.liveAhead = !settings.liveAhead;
    await DS_EXT.storage.sync.set({ liveAhead: settings.liveAhead });
    aheadSettingChanged(settings.liveAhead);
  });
  return b;
}
function aheadButtonUpdate() {
  const b = typeof overlay !== "undefined" && overlay && overlay.querySelector(".dualsub-aheadbtn");
  if (!b) return;
  const v = live.el || getVideo();
  b.hidden = !(DS_IS_YT && v && dsIsLiveStream(v) && (live.running || settings.liveAhead));
  const on = !!(settings && settings.liveAhead), info = aheadInfo();
  b.classList.toggle("on", on);
  b.title = on
    ? "Diretta sincronizzata: il video resta qualche secondo indietro e le frasi arrivano in orario" +
      (info.state === "aligning" ? " (sto mettendo a tempo l'audio…)" : info.state === "on" ? ` (pronte ${info.lead} s prima)` : info.state === "failed" ? " (non disponibile: vedi il popup)" : "") +
      ". Clic per la trascrizione normale passo passo."
    : "Diretta: trascrizione normale passo passo (frasi con qualche secondo di ritardo). Clic per la diretta sincronizzata (video qualche secondo indietro, serve il programma per yt-dlp).";
}

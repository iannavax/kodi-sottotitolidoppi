# 1.5.1: «✨ Spiegala meglio con …» nell'etimologia: il modello spiega e completa quella di Wiktionary, che resta;
# ‹ › passa dall'una all'altra; resta salvata (riaprendo la scheda c'è ancora, senza richieste)
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
ET = "(document.querySelector('.dualsub-card .dsx-etym')||{}).innerText||''"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', ipa:false, learnExamples:false}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        async def open_bread(first):
            if first:
                await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
                await pg.evaluate("document.querySelector('video').play()")
                await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
                await pg.evaluate("document.querySelector('video').pause()")
            words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
            await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(5000)
        await open_bread(True)
        a = await pg.evaluate(ET); print("1. prima:", a.replace("\n", " | ")[:160])
        await pg.locator(".dualsub-card .dsx-etym .dsx-btn", has_text="Spiegala meglio").click(); await pg.wait_for_timeout(3000)
        b = await pg.evaluate(ET); print("2. dopo «✨ Spiegala meglio»:", b.replace("\n", " | ")[:200])
        await pg.locator(".dualsub-card .dsx-etymsrc .dsx-btn", has_text="‹").click(); await pg.wait_for_timeout(300)
        c = await pg.evaluate(ET); print("3. ‹ :", c.replace("\n", " | ")[:160])
        n = len(log.get("etymdeep", []))
        await pg.reload(); await open_bread(True)
        d = await pg.evaluate(ET); print("4. riaperta:", d.replace("\n", " | ")[:160], "| richieste nuove:", len(log.get("etymdeep", [])) - n)
        ok = "ETIMMEGLIO[bread]" in b and "2/2" in b and "ETIMMEGLIO" not in c and "1/2" in c and "2" in d and len(log.get("etymdeep", [])) == n
        print("errori:", errs if ok else errs + ["etimologia dal modello non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

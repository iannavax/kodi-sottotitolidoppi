# Trascrizione chiesta su un video russo con i sottotitoli automatici di YouTube: resta sempre in russo
import asyncio, os, sys, json
os.environ["RU_TRANSLATE"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', hoverPause:false, cleanTranscript:false, sttLang:''})
          .then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ruTrans"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/Привет/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        tid = await sw.evaluate("chrome.tabs.query({}).then(t=>t.find(x=>(x.url||'').includes('ruTrans')).id)")
        send = lambda m: sw.evaluate(f"chrome.tabs.sendMessage({tid}, {json.dumps(m)})")
        await send({"type": "live", "action": "start"})
        await pg.wait_for_timeout(32000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(3000)
        print("1. richieste a Whisper (pezzo, lingua, modello, risultato, suggerimento):")
        for r in log.get("ru_req", []): print("  ", r)
        cues = await sw.evaluate(f"chrome.storage.local.get(null).then(a=>Object.entries(a).filter(([k])=>k.startsWith('livecues')||k.includes('ruTrans')).map(([k,v])=>[k, (v.cues||[]).map(c=>c.t), v.lang]))")
        print("2. salvato:", json.dumps(cues, ensure_ascii=False)[:600])
        print("3. stato:", await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

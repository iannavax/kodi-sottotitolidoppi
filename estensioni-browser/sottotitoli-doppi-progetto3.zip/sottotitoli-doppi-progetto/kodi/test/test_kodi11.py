# Prove della 1.10.8: quota di Whisper (Groq) finita → errore chiaro subito, niente caricamento infinito; poi riprende
import sys, os, json, time, shutil, re, urllib.parse
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
from resources.lib import core
calls = []
tr = lambda x: " ".join(w[::-1] for w in x.split())
DA = ["hvor skal du hen i aften", "jeg skal hjem til min mor", "det er langt herfra", "ja men toget kører snart",
      "vi ses i morgen tidlig", "husk at tage jakken med"]
EN = ["where are you going tonight", "I am going home to my mother", "that is far from here", "yes but the train leaves soon",
      "see you early tomorrow", "remember to take the jacket"]
MODE = {"whisper": "translate_when_free", "fail_tr": False}
QUOTA = {}
def field(data, name):
    m = re.search(rb'name="%s"\r\n\r\n([^\r]*)' % name.encode(), data or b"")
    return m.group(1).decode() if m else ""
def fake_http(url, data=None, headers=None, timeout=90):
    calls.append(url.split("?")[0])
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        if MODE["fail_tr"] and "\n" in q:   # Google salta qualche riga nei gruppi
            return 200, json.dumps([[["\n".join("" if i % 3 == 0 else "IT[" + tr(l) + "]" for i, l in enumerate(q.split("\n"))), q]], None, "da"]).encode(), {}
        return 200, json.dumps([[["\n".join("IT[" + tr(l) + "]" for l in q.split("\n")), q]], None, "da"]).encode(), {}
    if "audio/transcriptions" in url:
        lang = field(data, "language")
        piece = int(re.search(rb'filename="pezzo(\d+)', data).group(1))
        q = QUOTA.get("mode")
        if q and piece >= QUOTA.get("from", 0):
            calls.append("whisper-rifiutata:%d" % piece)
            if q == "credit":
                return 402, b'{"error":{"message":"Your organization has insufficient credit balance"}}', {}
            if q == "minute" and QUOTA.get("left", 0) > 0:
                QUOTA["left"] -= 1
                return 429, b'{"error":{"message":"Rate limit reached for model whisper-large-v3-turbo on requests per minute (RPM): Limit 20. Please try again in 2s."}}', {"retry-after": "2"}
            if q == "hour":
                return 429, b'{"error":{"message":"Rate limit reached for model `whisper-large-v3-turbo` in organization `org_x` service tier `on_demand` on seconds of audio per hour (ASPH): Limit 7200, Used 7185, Requested 600. Please try again in 22m45.5s."}}', {"retry-after": "1366"}
            if q == "day":
                return 429, b'{"error":{"message":"Rate limit reached for model `whisper-large-v3-turbo` on seconds of audio per day (ASPD): Limit 28800, Used 28700, Requested 600. Please try again in 3h12m5s."}}', {"retry-after": "11525"}
        calls.append("whisper:%d:%s:%s" % (piece, lang or "-", field(data, "model")))
        # senza lingua imposta Whisper "sbaglia": riconosce il danese ma scrive in inglese (= traduce)
        lines = DA if lang == "da" else EN
        det = "danish" if MODE["whisper"] == "translate_when_free" else "english"   # "english": la riconosce male
        segs = [{"start": k * 8 + 0.5, "end": k * 8 + 6, "text": " " + lines[(piece * 2 + k) % 6] + ".", "no_speech_prob": 0.02, "avg_logprob": -0.3}
                for k in range(6)]
        return 200, json.dumps({"language": lang and {"da": "danish"}.get(lang, lang) or det, "segments": segs}).encode(), {}
    if "cinemeta" in url and "/meta/" in url:
        return 200, json.dumps({"meta": {"country": "Denmark", "name": "Film danese"}}).encode(), {}
    if url.startswith("https://opensubtitles-v3.strem.io/") or "cinemeta" in url:
        return 200, json.dumps({"subtitles": [], "metas": []}).encode(), {}
    return 404, b"", {}
core.http = fake_http
# tre pezzi da 10 minuti finti (ffmpeg non serve)
def fake_pieces(ffmpeg, media, workdir, piece_sec=600, stream=0):
    out = []
    for i in range(3):
        p = os.path.join(workdir, "pezzo%03d.ogg" % i); open(p, "wb").write(b"OggS" + bytes(100)); out.append(p)
    return out
core.extract_audio_pieces = fake_pieces
core.find_ffmpeg = lambda c="": "/usr/bin/ffmpeg"
core.audio_streams = lambda ffmpeg, media: AUDIO_STREAMS.get("v", [])
AUDIO_STREAMS = {}
from resources.lib import runner
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra",
                           "trans_color": "FFFF00", "auto": "true", "groq_key": "gsk_test", "stt": "groq (gratis con chiave)",
                           "stt_lang": "auto", "source_mode": "trascrizione (sempre l'audio, salvata: si fa una volta sola)"})
def play(url):
    xbmc.Player.playing_file = url
    xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": url, "at": time.time() - 20})
    xbmc.Player.subs.clear(); xbmcgui.NOTES.clear(); calls.clear(); xbmc.LOG.clear()
def shown():
    return open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
W = lambda: [c for c in calls if c.startswith("whisper:")]

SLEEPS = []
real_sleep = time.sleep
core.time.sleep = lambda s: (SLEEPS.append(s), real_sleep(min(s, 0.01)))
URL = "https://22-4.download.real-debrid.com/d/AAAA/Festen.1998.Danish.1080p.mkv"
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.IMDBNumber": "tt0154420"})
xbmc.Player.playing = True
# 1. quota dell'ora finita al secondo pezzo: messaggio chiaro, subito, e la parte fatta resta salvata
play(URL); xbmcgui.OKS.clear(); SLEEPS.clear()
QUOTA.update(mode="hour", **{"from": 1})
t0 = time.time(); runner.run(xbmc.Player(), interactive=True); dt = time.time() - t0
parz = os.path.isfile(runner.transcript_paths(URL, runner.settings())[1])
print("1. limite orario: %.1f s | attese: %s | messaggio: %s" % (dt, SLEEPS, xbmcgui.OKS[-1:]))
print("   richieste:", W(), "| parte salvata:", parz)
ok1 = dt < 5 and all(x < 1 for x in SLEEPS) and xbmcgui.OKS and "un'ora" in xbmcgui.OKS[-1] and "23 minuti" in xbmcgui.OKS[-1] and parz \
    and len([c for c in calls if c.startswith("whisper-rifiutata")]) == 1
# 2. quota di nuovo libera: riprende dal secondo pezzo
QUOTA.clear(); play(URL); xbmcgui.OKS.clear()
runner.run(xbmc.Player(), interactive=True)
print("2. ripresa: pezzi chiesti", sorted(set(int(c.split(":")[1]) for c in W())), "| sottotitoli:", bool(shown()))
ok2 = sorted(set(int(c.split(":")[1]) for c in W())) == [1, 2] and bool(shown()) and not xbmcgui.OKS
# 3. quota del giorno finita (altro film), in automatico (non interattivo): avviso lungo
URL2 = URL.replace("Festen", "Idioterne"); xbmc.INFO.update({"VideoPlayer.IMDBNumber": "tt0154421"})
QUOTA.update(mode="day", **{"from": 0}); play(URL2); xbmcgui.OKS.clear(); SLEEPS.clear()
runner.run(xbmc.Player(), interactive=False)
n = [x for x in xbmcgui.NOTES if "oggi" in x]
print("3. limite del giorno (automatico):", n[-1:], "| attese:", SLEEPS)
ok3 = n and "3 ore e 13 minuti" in n[-1] and all(x < 1 for x in SLEEPS) and not xbmcgui.OKS
# 4. credito finito
QUOTA.update(mode="credit"); play(URL2); xbmcgui.OKS.clear()
runner.run(xbmc.Player(), interactive=True)
print("4. credito:", xbmcgui.OKS[-1:])
ok4 = xbmcgui.OKS and "credito" in xbmcgui.OKS[-1]
# 5. limite al minuto (breve): aspetta qualche secondo e continua da solo
QUOTA.clear(); QUOTA.update(mode="minute", left=2, **{"from": 0}); play(URL2); xbmcgui.OKS.clear(); SLEEPS.clear()
runner.run(xbmc.Player(), interactive=True)
print("5. limite al minuto: attese", SLEEPS, "| sottotitoli:", bool(shown()), "| messaggi:", xbmcgui.OKS)
ok5 = SLEEPS and max(SLEEPS) <= 10 and bool(shown()) and not xbmcgui.OKS
print("ESITO:", bool(ok1 and ok2 and ok3 and ok4 and ok5))

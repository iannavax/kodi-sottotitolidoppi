import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it'}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/track.html"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(3000)
        vis = lambda: pg.evaluate("(()=>{const o=document.querySelector('.dualsub-overlay'); return !!o && !o.hidden})()")
        b = pg.locator(".dualsub-toggle-float")
        print("1. pulsante sul video:", await b.count(), await b.get_attribute("aria-pressed"), "| visibili:", await vis())
        await b.click(); await pg.wait_for_timeout(500)
        print("2. spento:", await vis(), "| pulsante ancora lì:", await b.is_visible())
        await b.click(); await pg.wait_for_timeout(800)
        print("3. riacceso:", await vis(), "| errori:", errs)
        await ctx.close()
asyncio.run(main())

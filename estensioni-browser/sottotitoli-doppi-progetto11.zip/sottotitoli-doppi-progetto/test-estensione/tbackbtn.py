# 5.19: ↺ accanto ai sottotitoli: torna alla frase che stavi leggendo (scheda aperta o mouse sulle parole)
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
ST = "(()=>{const b=document.querySelector('.dualsub-backbtn'); if(!b) return 'nessuno'; const cs=getComputedStyle(b); return [cs.display, b.className.replace('dualsub-fixbtn ',''), b.title.slice(0,60)].join(' | ')})()"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=jaBack"); await pg.wait_for_timeout(1200)
        v = "document.querySelector('video')"
        await pg.evaluate(f"{v}.play()")
        await pg.wait_for_function("/毎日/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.locator(".dualsub-orig .dualsub-word").first.hover(); await pg.wait_for_timeout(300)
        print("1. sulla frase 2 (毎日…):", await pg.evaluate(ST))
        await pg.mouse.move(5, 5)
        await pg.wait_for_function("/今日/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=10000)
        t1 = await pg.evaluate(f"{v}.currentTime")
        print(f"2. il video è andato avanti ({t1:.1f} s, frase 3):", await pg.evaluate(ST))
        await pg.locator(".dualsub-backbtn").click(); await pg.wait_for_timeout(400)
        tt = await pg.evaluate(v + ".currentTime"); fr = await pg.evaluate("document.querySelector('.dualsub-orig').textContent"); pl = not await pg.evaluate(v + ".paused")
        print(f"3. dopo ↺: tempo {tt:.1f} s | frase: {fr} | in riproduzione: {pl}")
        await pg.wait_for_timeout(500)
        print("4. stessa frase:", await pg.evaluate(ST))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# Parole al Volo 1.4.5: giapponese con Jisho (lettura, JLPT) nella scheda
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
async def handle(route, request):
    if ".wiktionary.org/" in request.url or request.url.startswith("https://jisho.org/"): return await charness.handle(route, request)
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "ja", "勉強", 3500)
        print("1. 勉強:", (await pg.evaluate("(document.querySelector('.pav-card .dsx')||{}).innerText")).replace("\n", " | "), "| jisho:", charness.log.get("jisho"))
        await sw.evaluate("chrome.storage.sync.set({learnJisho:false})"); await pg.wait_for_timeout(300)
        await pg.keyboard.press("Escape"); n = len(charness.log.get("jisho", []))
        await tvolo.hover(pg, "ja", "日本語", 3000)
        print("2. spento: riga", await pg.evaluate("!!document.querySelector('.pav-card .dsx-jisho')"), "| richieste nuove", len(charness.log.get("jisho", [])) - n)
        print("errori:", errs, tvolo.log["errors"], charness.log["errors"])
        await ctx.close()
asyncio.run(main())

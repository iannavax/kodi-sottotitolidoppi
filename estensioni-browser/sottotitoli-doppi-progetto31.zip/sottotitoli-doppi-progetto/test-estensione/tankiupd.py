# 1.6.3: «🔄 Aggiorna le carte già in Anki»: impaginazione ordinata, pronuncia, dati mancanti, spiegazione nuova; annulla
import asyncio, sys, re, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ankiAudio:true})")
        await sw.evaluate("""chrome.storage.local.set({vocab:{
          'en|bread': {id:'en|bread', word:'bread', lang:'en', meaning:'pane', explanation:'Alimento di farina.', sentence:'so we bought some fresh bread', sentenceTrans:'', status:'learning', added:1, anki:1, videoId:'abc', time:12, title:'Video prova'}}})""")
        # le carte già in Anki, come le facevano le versioni prima (e una che non è nel vocabolario)
        log["anki_notes"] = {
          5001: {"Fronte": "<b>bread</b><br><br><i>so we bought some fresh <b>bread</b></i><img src=\"vecchia.jpg\">", "Retro": "<b>pane</b><br>Alimento di farina.<br><br><a href=\"https://www.youtube.com/watch?v=abc&t=10s\">Video prova (0:12)</a>", "tags": ["sottotitoli-doppi", "en"], "deck": "Lingue::Inglese"},
          5002: {"Fronte": "<b>market</b><br><br><i>I like the <b>market</b>.</i>", "Retro": "<b>mercato</b><br>sostantivo<br><small>Etimologia: dal latino</small><br>Luogo dove si vende.<br><br><i>Mi piace il mercato.</i>", "tags": ["parole-al-volo", "en"], "deck": "Lingue::Inglese"},
        }
        vp = await ctx.new_page(); errs = []
        vp.on("pageerror", lambda e: errs.append("vocab: " + str(e)))
        vp.on("dialog", lambda d: asyncio.ensure_future(d.accept()))
        await vp.goto(f"chrome-extension://{eid}/vocab.html"); await vp.wait_for_timeout(1000)
        await vp.evaluate("document.getElementById('ankiUpd').open = true")
        await vp.click("#updCheck"); await vp.wait_for_timeout(3000)
        print("1. controlla:", (await vp.inner_text("#updLog")).replace("\n", " | ")[:420])
        await vp.check("#updExpl"); await vp.check("#updIdioms")
        await vp.click("#updGo")
        for _ in range(120):
            if "Finito" in await vp.inner_text("#updLog"): break
            await vp.wait_for_timeout(500)
        print("2. registro:", (await vp.inner_text("#updLog")).replace("\n", " | ")[:900])
        n1, n2 = log["anki_notes"][5001], log["anki_notes"][5002]
        for k, n in ((5001, n1), (5002, n2)):
            print(f"   {k} FRONTE:", n["Fronte"]); print(f"   {k} RETRO :", n["Retro"])
        ok = ("[sound:" in n1["Fronte"] and "[sound:" in n2["Fronte"] and "/bɹɛd/" in n1["Retro"] and "NUOVA[bread]" in n1["Retro"] and "Alimento di farina." in n1["Retro"] and "Video prova" in n1["Retro"]
              and "vecchia.jpg" in n1["Fronte"] and "Etimologia: dal latino" in n2["Retro"] and "Luogo dove si vende." in n2["Retro"] and "Mi piace il mercato." in n2["Retro"] and "Modi di dire" in n1["Retro"] + n2["Retro"])
        sv = await sw.evaluate("chrome.storage.local.get('vocab').then(r=>r.vocab['en|bread'])")
        print("3. vocabolario:", {k: sv.get(k) for k in ("ipa", "etym", "sentenceTrans", "expls")})
        # annulla
        await vp.wait_for_selector("#updUndo:not([hidden])", timeout=5000)
        await vp.click("#updUndo"); await vp.wait_for_timeout(2000)
        ok2 = "<img src=\"vecchia.jpg\">" in log["anki_notes"][5001]["Fronte"] and "[sound:" not in log["anki_notes"][5001]["Fronte"] and "NUOVA" not in log["anki_notes"][5001]["Retro"]
        print("4. dopo annulla:", ok2, "|", log["anki_notes"][5001]["Fronte"][:90])
        print("OK" if ok and ok2 else "NO", ok, ok2)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

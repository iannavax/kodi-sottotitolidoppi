// 1.7.28: barra di ricerca nelle opzioni del popup. Cerca nei nomi e nelle descrizioni (anche delle voci dei menu) di tutte le
// opzioni, comprese quelle dentro le sezioni chiuse; un clic sul risultato apre la sezione, porta all'opzione e la illumina.
(() => {
  const box = document.getElementById("optSearch"), res = document.getElementById("optSearchRes");
  if (!box || !res) return;
  const norm = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const own = (el) => [...el.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join(" ").replace(/\s+/g, " ").trim();
  const sectionOf = (el) => { const d = el.closest("details:not(.sub):not(.ds-sub)") || el.closest("details"); const top = d && (d.parentElement.closest("details") || d); const s = top && top.querySelector(":scope > summary"); return s ? s.childNodes[0].textContent.trim() : "Generale"; };
  function items() {
    const out = [];
    for (const el of document.querySelectorAll("form label, form summary, form button, form .small, form h3, form h4, body > label, body > details summary")) {
      if (res.contains(el) || el === box || el.closest("[hidden]")) continue;
      const name = (el.tagName === "SUMMARY" || el.tagName === "BUTTON" ? el.childNodes[0] && el.childNodes[0].textContent : own(el)) || "";
      const label = (name.trim() || (el.title || "")).replace(/\s+/g, " ").slice(0, 70);
      if (!label) continue;
      const groups = [...el.querySelectorAll("optgroup")].map((g) => g.label).join(" ");
      const section = sectionOf(el);
      out.push({ el, label, hay: norm(el.textContent + " " + (el.title || "") + " " + groups + " " + section), section });
    }
    return out;
  }
  function show(el) {
    for (let d = el.closest("details"); d; d = d.parentElement && d.parentElement.closest("details")) d.open = true;
    el.scrollIntoView({ block: "center", behavior: "smooth" });
    el.style.transition = "outline-color .3s"; el.style.outline = "2px solid #f5c84b"; el.style.outlineOffset = "3px";
    setTimeout(() => { el.style.outline = ""; el.style.outlineOffset = ""; }, 2200);
    const f = el.querySelector("input,select,button,textarea");
    if (f && !el.matches("summary")) setTimeout(() => { try { f.focus({ preventScroll: true }); } catch {} }, 400);
  }
  let timer = 0;
  function run() {
    res.textContent = "";
    const q = norm(box.value).trim();
    if (!q) { res.hidden = true; return; }
    const words = q.split(/\s+/);
    // (una parola lunga trova anche il singolare/plurale: «immagini» trova «immagine»)
    const has = (hay, w) => hay.includes(w) || (w.length > 4 && hay.includes(w.slice(0, -1)));
    const hits = items().filter((it) => words.every((w) => has(it.hay, w)));
    // le voci il cui nome (non solo la descrizione) contiene la ricerca prima
    hits.sort((a, b) => (norm(b.label).includes(q) - norm(a.label).includes(q)));
    res.hidden = false;
    if (!hits.length) { const n = document.createElement("div"); n.className = "small"; n.textContent = "Nessuna opzione trovata."; res.append(n); return; }
    const seen = new Set();
    for (const it of hits) {
      const k = it.section + "|" + it.label;
      if (seen.has(k) || seen.size >= 14) continue;
      seen.add(k);
      const b = document.createElement("button");
      b.type = "button"; b.className = "ghost optsearch-hit";
      b.textContent = it.section + " › " + it.label;
      b.addEventListener("click", () => show(it.el));
      res.append(b);
    }
  }
  box.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(run, 120); });
  box.addEventListener("keydown", (e) => { if (e.key === "Escape") { box.value = ""; run(); } if (e.key === "Enter") { const b = res.querySelector("button"); if (b) b.click(); } });
})();


// 1.7.30: le sezioni aperte o chiuse del popup si ricordano per la volta dopo (storage.local popupOpen)
(async () => {
  const dets = [...document.querySelectorAll("form details")];
  const keyOf = (d) => d.id || ((d.querySelector(":scope > summary") || {}).textContent || "").trim().slice(0, 40);
  let saved = {};
  try { saved = (await chrome.storage.local.get({ popupOpen: {} })).popupOpen || {}; } catch {}
  for (const d of dets) {
    const k = keyOf(d);
    if (!k) continue;
    if (k in saved) d.open = !!saved[k];
    d.addEventListener("toggle", () => { saved[k] = d.open; try { chrome.storage.local.set({ popupOpen: saved }); } catch {} });
  }
})();

//go:build windows

package main

import (
	"os/exec"
	"strconv"
	"syscall"
)

// niente finestra nera quando il browser avvia il programma e questo avvia gli altri
func setupProc(c *exec.Cmd) {
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
}

// chiude il programma e quelli che ha avviato (yt-dlp avvia Deno)
func killTree(c *exec.Cmd) {
	if c == nil || c.Process == nil {
		return
	}
	k := exec.Command("taskkill", "/F", "/T", "/PID", strconv.Itoa(c.Process.Pid))
	setupProc(k)
	_ = k.Run()
	_ = c.Process.Kill()
}

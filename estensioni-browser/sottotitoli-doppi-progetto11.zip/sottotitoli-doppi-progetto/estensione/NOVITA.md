# Sottotitoli Doppi — novità delle versioni

## Novità della 5.22.0
- **Traduzione nella lingua o nell'alfabeto sbagliato** (per esempio la trascrizione araba al posto della traduzione italiana, che restava anche cambiando lingua): ora ogni «traduzione» scritta in un alfabeto diverso da quello della lingua scelta viene scartata e rifatta con Google, e quelle sbagliate già salvate vengono buttate quando riapri il video. Se il traduttore è YouTube e la sua traduzione è nell'alfabeto sbagliato, per quel video si passa da soli a Google.
- **⚑ → «Tutta la traduzione di questo video è sbagliata?»**: «↻ Rifalla tutta» (cancella quella salvata e la rifà) e «↻ Rifalla con Google Traduttore» (per questo video traduce sempre Google; «Torna al servizio scelto nel popup» per annullare).
- **Diretta sincronizzata più robusta**: il video va indietro subito quando la modalità parte (con i comandi del lettore di YouTube, che prima a volte annullava lo spostamento); sul video compaiono gli avvisi («sto mettendo a tempo», «sottotitoli in orario», oppure perché non funziona); se non funziona il video torna al momento attuale della diretta. Il programma per yt-dlp 1.2 dice a yt-dlp dove si trova ffmpeg: **rilancia l'installatore** (popup → Video senza sottotitoli → Programma per yt-dlp).

## Novità della 5.21.0
- **⇄ Sincronizza porta anche le chiavi e le impostazioni.** Oltre a parole conosciute e vocabolario, passano le chiavi dei servizi (Gemini, Groq…) e le impostazioni che nell'altra estensione non sono ancora state scelte (le tue restano): così l'estensione unica appena installata ha subito «Spiega con Gemini», le immagini di Anki e il resto, come prima. Le chiavi vanno solo a estensioni sorelle verificate; se l'altra non può verificare chi le chiede, il messaggio dice di premere ⇄ anche lì.
- **Dirette: scelta chiara tra sottotitoli normali e sincronizzati.** Nel popup, quando guardi una diretta, in alto c'è il riquadro «🔴 Questo video è una diretta» con la scelta «Normali, passo passo» o «Sincronizzati (video qualche secondo indietro)», e lo stato. Sul video, accanto ai sottotitoli, il pulsante **⏱** passa dall'una all'altra con un clic. Vale subito.
- **Lingua della trascrizione sempre a portata**: il pulsante con la sigla della lingua accanto ai sottotitoli ora c'è anche quando non compare nessuna frase (proprio quando Whisper sente la lingua sbagliata e i pezzi vengono scartati).
- **Kanji: tutto cliccabile.** Nel riquadro di un kanji i distintivi si aprono: «N tratti ✍» mostra l'animazione dell'ordine dei tratti (Wikimedia Commons); JLPT, classe, frequenza, HSK, «comune in Cina», «hanja scolastico» e il radicale aprono la nuova pagina **Kanji e caratteri** a quel livello (tutti i caratteri del livello, quelli che conosci in verde, «lo conosco?», «Li conosco tutti», ricerca per lettura o significato). Funziona senza internet.
- **Correzione della trascrizione con Gemini/Groq più facile da trovare**: quando la trascrizione è attiva, in cima al popup c'è la casella «✎ Correggi la trascrizione con Gemini/Groq» (accesa: corregge le parole capite male e toglie le frasi inventate, usando un po' di quota; spenta: le frasi restano come le ha capite Whisper).
- **Modi di dire nella scheda**: cliccando una parola che fa parte di un modo di dire (per esempio «сожалению» in «к сожалению»), la scheda lo segnala come prima e le altre parole dell'espressione (la «к») si vedono nel sottotitolo con un leggero tratteggio arancione, diverso dalla parola cliccata. La selezione dell'espressione resta manuale (trascinando con il mouse, anche partendo da una parola di una lettera).
- **Pulsanti in fondo alla scheda più ordinati**: ⧉ Parola, ⧉ Frase, ↺ Riascolta, 🐢 Lenta, 🔁 ×3 piccoli, su due righe.

## Novità della 5.20.1
- **⇄ Sincronizza** ora funziona con tutte le estensioni sorelle installate: Sottotitoli Doppi, Parole al Volo e l'estensione unica «Sottotitoli Doppi + Parole al Volo» (prima solo tra le prime due). Le parole conosciute di tutte le lingue (e, dal vocabolario, anche le voci) passano da una all'altra; alla fine hanno tutte le stesse. Resta anche il file: «Esporta in un file» contiene tutte le lingue.

## Novità della 5.20.0
- **Dirette: sottotitoli in anticipo, quindi in orario** (popup → Video senza sottotitoli → «Dirette: sottotitoli in anticipo (yt-dlp)», spenta all'inizio). Solo YouTube; serve il programma per yt-dlp aggiornato (rilancia l'installatore: ora scarica anche **ffmpeg**). Il video della diretta resta qualche secondo indietro (20 s all'inizio, si regola da solo), mentre yt-dlp legge l'audio dal punto più recente: le frasi sono già trascritte e tradotte quando il video arriva lì. L'audio di yt-dlp e il video vengono messi a tempo confrontando il parlato e le pause dei due audio. Nelle prove le frasi comparivano 0,1–0,3 s dall'inizio del parlato, contro gli 8–9 s della trascrizione normale. Nessuna quota in più: Whisper riceve lo stesso audio. Se qualcosa non va (programma mancante o vecchio, ffmpeg mancante, YouTube che blocca), si torna da soli alla trascrizione normale e il popup dice perché.

## Novità della 5.19.0
- **Kanji e caratteri cinesi uno per uno.** Nei sottotitoli in giapponese o cinese (e negli hanja coreani) si clicca prima la parola intera, come sempre; nella scheda ora c'è la riga «Kanji uno per uno» con ogni carattere della parola. Un clic su un kanji mostra solo lui, con **le stesse informazioni in tutte le lingue**: significato, lettura nella lingua del testo per prima (on/kun, pinyin, cantonese, coreano, vietnamita) e poi nelle altre, **parti** di cui è composto e **radicale** (cliccabili, con «‹» per tornare), forma semplificata/tradizionale, numero di tratti e livelli: JLPT N5–N1 e classe in Giappone, HSK 1–9 e «comune in Cina», hanja scolastico in Corea. I dati sono dentro l'estensione (Unicode Unihan, KANJIDIC, HSK 3.0, lista ufficiale cinese): funzionano anche senza internet. Da lì: 🔈, «lo conosco?», collegamenti a Jisho (ordine dei tratti, parole con quel kanji) e Wiktionary, e **«scheda del carattere ›»**, che apre il kanji come una parola vera (esempi, etimologia, ☆ vocabolario e Anki), con «‹ Torna alla parola» per tornare indietro (la scheda si apre subito). **☆ salva il kanji** nel riquadro e **☆ salva tutti i kanji** accanto alla riga mettono nel vocabolario i singoli caratteri della parola (con significato, letture, tratti e parti; ★ per toglierli). Tutto gratis (dati interni + Google per tradurre): nessuna richiesta a Gemini o Groq. Si spegne nel popup → Strumenti per imparare → «Kanji e caratteri cinesi uno per uno».

- **↺ Torna alla frase che stavi leggendo**: nuovo pulsante a sinistra dei sottotitoli. Se ti fermi a leggere una parola (scheda aperta o mouse sulle parole) e intanto il video va avanti, ↺ diventa giallo e con un clic torni all'inizio di quella frase e la riascolti; altrimenti riascolta la frase sotto il video.
- **Dirette: i sottotitoli trascritti non spariscono più.** Quando YouTube ricarica il flusso della diretta (rete, buffering, qualità) l'orologio del video può ripartire da un altro punto: prima l'audio nuovo veniva scartato come "già trascritto" e i sottotitoli non tornavano più, neanche spegnendo e riaccendendo (solo ricaricando la pagina). Ora la trascrizione riparte da lì.
- **Trascrizione mai più bloccata**: una richiesta a Whisper senza risposta (rete cambiata, scheda in sottofondo) bloccava tutto per sempre; ora dopo 60 s si passa al pezzo dopo. Nelle dirette i pezzi rimasti indietro di oltre un minuto (per esempio mentre guardavi un'altra scheda) si saltano, così al ritorno i sottotitoli riprendono da dove sei. Un controllo continuo riaggancia l'audio se smette di arrivare; spegnere e riaccendere ora riparte davvero da capo.
- Il ritardo con cui si mostrano le frasi arrivate tardi non supera più 12 secondi (prima con il parlato fitto poteva crescere senza limite).
## Novità della 5.18.5
- **Due grandezze separate** nel popup → Aspetto: «Lettere sopra i caratteri» (la trascrizione di ogni carattere o sillaba) e «Lettura della riga (romaji)» (la lettura di tutta la riga sopra il sottotitolo, per kanji e cinese). Si regolano ognuna per conto suo e cambiano subito.

## Novità della 5.18.4
- **Giapponese**: alcune sillabe (per esempio は "wa", い "i") non si potevano evidenziare né cliccare, perché in Firefox lo spezzatore di parole non le considera "parole". Ora ogni pezzo con una lettera è una parola cliccabile. Lo stesso in Parole al Volo (1.11.2).

## Novità della 5.18.3
- **Modi di dire e parola singola**: cliccando una parola sottolineata si apre tutto il modo di dire; cliccandola di nuovo si apre la parola da sola, e al clic dopo di nuovo l'espressione. Nella scheda ci sono anche «Solo la parola «…»» e «Tutto il modo di dire «…» ›». Prima, dopo l'analisi, non si riusciva più a guardare la parola da sola.

## Novità della 5.18.2
- **La trascrizione resta nella lingua del video**: se il video ha i sottotitoli automatici di YouTube, la loro lingua viene imposta a Whisper fin dall'inizio, e quei sottotitoli gli vengono dati come suggerimento (parole più giuste). Prima, con la lingua "automatica", Whisper poteva cominciare a scrivere la traduzione inglese invece della trascrizione e poi restarci.
- **Controllo di ogni pezzo**: se un pezzo arriva in inglese o in un altro alfabeto (per esempio lettere latine in un video russo), si rifà senza suggerimento, poi con il modello più preciso; se è ancora sbagliato si salta. Anche senza sottotitoli di YouTube, l'inglese che compare insieme a un'altra lingua non fa più diventare "inglese" il video.
- Una trascrizione salvata in una lingua diversa da quella del video viene buttata e rifatta.
- La correzione automatica della trascrizione (con Gemini/Groq) ora accetta solo piccole correzioni nella stessa lingua: niente frasi riscritte "con lo stesso senso".
- **Pulsante DS**: se YouTube non manda il testo dei sottotitoli, i CC si spengono e riaccendono una volta sola (prima lampeggiavano a ogni clic); poi il messaggio dice di ricaricare la pagina.

## Novità della 5.18.1
- **⇄ Sincronizza adesso** nella pagina delle parole più usate: le parole che conosci passano da Sottotitoli Doppi a Parole al Volo e viceversa con un clic, senza file (si uniscono, non si cancella niente). Nel vocabolario **⇄ Sincronizza con Parole al Volo** fa lo stesso anche con le voci del vocabolario. Serve l'altra estensione installata, accesa e aggiornata; su Edge/Chrome la prima volta il browser chiede il permesso di vedere le estensioni installate (per trovarla). Restano anche **Esporta in un file** e **Importa da un file…**, ora sempre in vista.

## Novità della 5.18
- **JLPT cliccabile**: nella scheda di una parola giapponese il segno «JLPT N5 ›» (N4, N3…) apre la nuova pagina **Parole del JLPT**: tutte le parole di quel livello (dal dizionario Jisho, gratis), con lettura, significato, la parola da cui arrivi evidenziata, «la conosco?» e quante ne conosci. Si passa da un livello all'altro con le schede N5…N1.
- **Livelli per tutte le lingue**: accanto alla frequenza c'è «livello ≈ B1 ›» (da A1 a C2), che apre l'elenco delle parole più usate proprio a quel livello. È indicativo: viene solo dalla posizione nell'elenco (A1 = le prime 500 parole, A2 fino a 1000, B1 fino a 2000, B2 fino a 4000, C1 fino a 8000, C2 fino a 16.000), non da un elenco ufficiale.
- Nella pagina delle parole più usate: barra dei livelli A1…C2 (passando il mouse, quante ne conosci per ognuno) e, per il giapponese, i collegamenti ai livelli JLPT.

## Novità della 5.17.1
- **Grandezza delle lettere latine** sopra le lettere (romaji del giapponese, cirillico…): nuova opzione nel popup → Aspetto, «Grandezza delle lettere latine», dal 30% al 120% del testo dei sottotitoli (prima era fissa e piccola; ora parte dal 65%). Cambia subito, anche la lettura della riga con i kanji.

## Novità della 5.17
- **Lettere latine sopra le lettere** (per imparare l'alfabeto): nei sottotitoli in cirillico, greco, armeno, georgiano, ebraico, giapponese (kana, sillaba per sillaba) e coreano compare sopra ogni lettera la sua trascrizione; in arabo, persiano, urdu e hindi sopra ogni parola (lì le lettere sono legate). Sono tabelle scritte nell'estensione: nessun servizio, nessun token. Si accende e si spegne subito con **Aa** accanto ai sottotitoli, o nel popup. I kanji e i caratteri cinesi hanno più letture: sopra la riga compare la sua lettura intera (Google, gratis; si può spegnere).
- **Definizioni nella lingua della parola anche quando Google non le ha**: dal Wiktionary di quella lingua (ru.wiktionary per il russo…), poi da quello inglese. Ognuna con **traduci**; le altre con **altre ›**.
- **⚑ Traduzione sbagliata?** anche per la parola: rifai con Google, rifai con il modello, o correggi a mano (resta salvata).
- **Immagini di Anki che arrivano davvero**: l'immagine la scarica l'estensione e la passa ad Anki (prima Anki la scaricava da solo e Wikipedia/Wikimedia la rifiutavano, quindi le carte restavano senza). Nella scheda la vedi prima di salvare: **‹ ›** per cambiarla, **altre…** per vederle tutte, cercare con altre parole, scegliere la fonte o incollare un indirizzo, **✕** per nessuna. Nel vocabolario: **🖼 Cambia immagine**. Fonti nel popup → Anki: Wikipedia, Wikimedia Commons, Openverse.
- **Parole che conosco**: pulsante nel popup che apre l'elenco delle parole più usate della lingua; lì scegli la lingua, segni le prime N come conosciute, **esporti** e **importi** (anche un .txt con una parola per riga). Nel vocabolario: **⇄ Esporta per l'altra estensione** / **⇄ Importa…**, per tenere uguali vocabolario e parole conosciute con Parole al Volo (si unisce, non si cancella niente).
- **Evidenzia in verde le parole che conosco** (come in Parole al Volo), opzione nel popup.
- **Pronuncia della parola esatta**: la pronuncia IPA è sempre quella della parola com'è scritta (prima a volte arrivava quella di un'altra forma, per esempio гордую → гордый). Se c'è solo la registrazione di un'altra forma, il pulsante è arancione, **🔊\***, e dice di quale forma è. Le pronunce salvate prima si ricalcolano una volta.

## Novità della 5.16.1
- **Spiegazioni del modello controllate**: se il "significato" è la parola stessa non tradotta o la spiegazione è in un'altra lingua (per esempio in arabo per una parola russa), si riprova una volta con istruzioni più rigide; se è ancora sbagliata, quella parte si toglie e il significato lo dà Google (la scheda lo scrive accanto alla fonte). Nel prompt ora c'è anche il nome della lingua della parola.
- **Immagine nelle carte di Anki**: l'opzione ora è nel popup → **Anki** ("Metti un'immagine nelle carte di Anki"), insieme all'invio automatico con ☆.

## Novità della 5.16
- **Quando Gemini (o il servizio scelto) finisce le richieste gratuite di oggi**, il popup lo dice chiaramente sotto "Come tradurre": a che ora tornano (verso le 9), quale servizio di riserva si usa intanto, e il pulsante **"Riprova Gemini adesso"**. Premendolo la traduzione del video riprende subito con Gemini.
- **Stessi servizi e stessa sezione in Parole al Volo**: Google, Gemini, Groq, OpenRouter, Mistral, Microsoft, DeepL, un modello sul tuo computer e Claude, con chiave, modello, "Carica modelli" e servizi di riserva, come qui.
- Nella scheda della parola, mentre si aspetta la spiegazione del modello, non compare più due volte l'elenco delle traduzioni.
## Novità della 5.15
- **Pronuncia IPA da Wiktionary sempre, gratis**: compare anche con l'opzione del modello spenta. L'opzione (ora "IPA anche dal modello, se manca su Wiktionary") decide solo se, quando Wiktionary non l'ha, la chiede il modello: e la chiede **dentro la stessa richiesta** della spiegazione (clic sulla parola), mai con una richiesta a parte.
- **Trascrizione in caratteri latini** sotto la parola per gli alfabeti diversi (кошка → koshka), gratis.
- **Clic sulla parola più veloce**: il significato di Google compare subito e la spiegazione del modello lo sostituisce appena arriva; la richiesta passa davanti alle traduzioni in coda.
- **Frase tradotta meglio**: se i sottotitoli sono tradotti con Google o DeepL, la stessa richiesta della spiegazione porta anche una traduzione corretta della frase intera (nella scheda, "Frase: …").
- **Definizioni nella lingua originale**: pulsante "traduci" accanto a ognuna. **Sinonimi e "vedi anche" cliccabili**: compare la traduzione della parola, con 🔈 e Wiktionary.
- **La scheda non si chiude più** passando col mouse sulla sua parte alta (finiva sotto i comandi di YouTube).
- **Modi di dire**: non si sottolinea più una frase intera (errore del modello); ⚑ "modo di dire sbagliato?" per segnalarlo ("Non è un modo di dire", resta salvato), ricontrollarlo con il modello o correggerne il significato.
- Tolto il pulsante Anki dalla scheda: resta la ☆; con "Manda ad Anki anche quando salvi con ☆" (popup → Anki) la stella fa anche quello.
- Corretto il "⚠ false" che compariva a volte nella scheda (il modello scriveva "false" invece di lasciare vuoto).
- **Vocabolario nuovo, uguale in Sottotitoli Doppi e Parole al Volo**: 🔈 voce sintetica e 🔊 registrazione vera, 🔈/🐢 per la frase, esempi veri da Tatoeba, filtro per lingua, ordinamento, "✎ Modifica", "Manda ad Anki" per una parola sola o per tutte, "▶ Ascolta l'elenco", e "Cosa mostrare" per scegliere i dettagli (IPA, etimologia, genere, frequenza, immagine…).
## Novità della 5.14.1
- **Registrazioni di Wiktionary trovate meglio** (per esempio *примечание*): oltre al lettore audio, anche quando la pagina ha solo il nome del file o un collegamento al file; e se il Wiktionary inglese non ha la registrazione di quella parola, si cerca in quello della lingua della parola (russo, ceco…) e negli altri grandi. Così compare 🔊 al posto della sola voce sintetica.

## Novità della 5.14
- **Dizionario di Google nella scheda della parola** (gratis, nella stessa richiesta della traduzione, nessuna richiesta in più):
  - **traduzioni con il loro peso**: la più usata in evidenza, una barretta per quanto è comune ciascuna; passando il mouse, le traduzioni al contrario (le parole originali a cui corrisponde);
  - **definizioni nella lingua della parola**, con un esempio;
  - **sinonimi** e **"vedi anche"**;
  - **"Forse cercavi…"** nel controllo della scrittura, quando la parola sembra scritta male.
  Ognuno si spegne nel popup → Strumenti per imparare. Google a volte non dà alcune parti per certe parole o lingue: in quel caso semplicemente non compaiono.
## Novità della 5.13
- **Anki direttamente da Sottotitoli Doppi (AnkiConnect)**, come in Parole al Volo: pulsante **Anki** nella scheda della parola, "Manda ad Anki" nel vocabolario, e se vuoi l'invio automatico quando salvi con ☆ (popup → Anki).
- **Un mazzo per ogni lingua**: le carte vanno in "Lingue::Inglese", "Lingue::Ceco"… (il nome si cambia nel popup; {lingua} diventa il nome della lingua). Sono **gli stessi mazzi di Parole al Volo**: le carte delle due estensioni si ritrovano insieme, distinte dalle etichette. Anche il file per Anki contiene il mazzo di ogni carta.
- **Etimologia tradotta meglio**: le parole straniere citate nell'etimologia non vengono più tradotte (in ceco *tento* = *ten* + *-to* restava "dieci + to"; ora resta *ten*).
- **Etimologia: pulsante "originale"** per leggerla com'è scritta su Wiktionary, e **⚑** per segnalare un errore: ritraduci (Google), rifai con Gemini/Groq, correggi a mano (resta salvata, segnata "✎ corretta da te"), togli la correzione.
- **Elenco delle parole più usate**: il badge della frequenza nella scheda è un pulsante; apre la pagina con le parole più comuni di quella lingua, la posizione della parola guardata evidenziata, la ricerca e "la conosco?" per segnare quelle che sai (con le percentuali delle prime 100, 1000 e 5000 che conosci).
## Novità della 5.12
- **Voce per ogni lingua**: nella scheda della parola, ⚙ accanto a 🔈 apre le voci disponibili per quella lingua; quella che scegli resta salvata e si usa sempre per quella lingua. Le stesse scelte sono nel popup → Pronuncia delle parole → "Voce per ogni lingua". Senza scelta l'estensione prende da sola la migliore: prima le voci "Natural", poi quelle online, poi le altre del computer, poi Google. Passando il mouse su 🔈 dopo averlo premuto leggi quale voce ha parlato.
- **Voci naturali di Microsoft anche in Firefox (Azure Speech)**: con una chiave gratuita di Azure Speech (500.000 caratteri al mese gratis) le parole si leggono con le stesse voci "Natural" di Edge, in quasi tutte le lingue. Popup → Pronuncia delle parole → chiave, regione e "Prova la chiave".
- La voce scelta nel popup per una lingua non legge più le parole delle altre lingue.
- Tolta la dicitura "prova": gli strumenti per imparare sono nella versione normale.
## Novità della 5.11.6
- **Tabelle di Wiktionary leggibili**: nelle tabelle di declinazione e coniugazione (per esempio *источник*) la traslitterazione in alfabeto latino non è più attaccata alla parola: sta sotto, più piccola e separata.

## Novità della 5.11.5
- **Pronuncia IPA da tutte le edizioni di Wiktionary**: se il Wiktionary inglese non ha la pronuncia della parola (succede spesso con le forme flesse), si cerca nel Wiktionary della lingua della parola (russo, ceco, tedesco, francese, polacco… qualsiasi lingua che ne abbia uno), poi in quello della tua lingua e nei più grandi (francese, tedesco, russo). Gemini o Groq solo se non c'è da nessuna parte. Passando il mouse sulla pronuncia leggi da quale edizione viene.
- **Giapponese: dizionario Jisho** (gratis): nella scheda lettura in kana, livello JLPT, "parola comune" e significato in inglese. Si spegne nel popup → Strumenti per imparare → "Dizionario Jisho".

## Novità della 5.11.4
- **Pronuncia IPA da Wiktionary, gratis**: la pronuncia della parola si prende prima da Wiktionary (la stessa pagina già usata per etimologia, genere, tabelle e registrazione: nessuna richiesta in più). Gemini o Groq si usano solo se lì manca, e anche cliccando la parola la spiegazione non la richiede più se c'è già. Funziona anche senza chiavi.

## Novità della 5.11.3
- **Ascolto della parola**: in alto nella scheda c'è sempre 🔈 (voce sintetica) e, quando Wiktionary ha la registrazione di una persona, accanto 🔊. Tolto il pulsante "🔊 madrelingua". Icone uguali ovunque: 🔊 = registrazione vera, 🔈 = voce sintetica.
- **Corretto "Spiega con Groq"** (cliccando la parola): non arrivava niente ("Groq non ha risposto") perché la richiesta chiedeva una risposta troppo lunga e superava il limite al minuto di Groq. Ora è più corta e, se serve, si riprova da sola; in caso di errore la scheda dice il motivo.

## Novità della 5.11.2
- **Esempi di Tatoeba con la voce vera, davvero**: ora si usa l'API ufficiale di Tatoeba (v1), che dà le registrazioni dei madrelingua; prima si chiedono le frasi registrate (🔊), poi le altre. Se una registrazione non si può scaricare si prova l'altro indirizzo di Tatoeba. Quando per una parola non esistono frasi registrate, la scheda lo dice ("🔈 = voce sintetica").

## Novità della 5.11.1
- **Esempi di Tatoeba con la voce vera**: si chiedono prima le frasi registrate da un madrelingua (🔊), e solo se non bastano le altre (🔈 = voce sintetica). Vanno bene anche le forme flesse della parola (*кошка* → *кошку*).

## Novità della 5.11
- **Strumenti per imparare nella scheda della parola**, tutti gratis e senza chiavi, ognuno si accende e spegne nel popup → **Strumenti per imparare**:
  - **frequenza** della parola (molto comune, comune, rara…), dagli elenchi FrequencyWords;
  - **«la conosco?»**: le parole che conosci si colorano di verde nei sottotitoli e il popup dice **quanta parte del video conosci** (in percentuale). Anche "Segna come imparata" nel vocabolario la aggiunge;
  - **frasi d'esempio vere** da Tatoeba, con la traduzione e spesso con la **registrazione di un madrelingua** (🔊; 🔈 = voce sintetica);
  - **pronuncia di madrelingua** della parola (Wiktionary), **tabella di coniugazione o declinazione** (▦), **genere** dei nomi (in tedesco con der/die/das);
  - **controllo della scrittura**: se la parola è scritta bene (LanguageTool e dizionario); cliccando la parola anche un **voto da 0 a 100** del modello, con la forma corretta.
- **Una sola richiesta al modello, sempre**: cliccando la parola, la spiegazione porta nella stessa richiesta anche etimologia (se manca), IPA (se accesa), **falsi amici**, **parole parenti** e voto alla scrittura.
- **Riascolta più lenta o più volte**: nella scheda, accanto a "↺ Riascolta la frase", **🐢 lenta** (a 0,75) e **🔁 ×3**.
- **Immagine nelle carte di Anki** (spenta di serie): quando salvi una parola cerca un'immagine su Wikimedia Commons e la mette sul fronte della carta.
- Corretto: le parole russe con l'accento tonico (*Дорефо́рменная*) o con trattini invisibili ora aprono la scheda della parola.
## Novità della 5.10.1
- **Una sola richiesta al modello per tutto.** Cliccando una parola, la spiegazione nel contesto di Gemini (o del servizio scelto) porta con sé anche l'etimologia, se Wiktionary non l'aveva, e la pronuncia IPA, solo se è accesa: una richiesta invece di due. Tolto il pulsante separato "Chiedila a Gemini" per l'etimologia.

## Novità della 5.10
- **Etimologia nella scheda della parola.** Sotto il significato compare da dove viene la parola (per esempio *bread* → dall'inglese antico *brēad*), presa da Wiktionary (gratis, senza chiave) e tradotta nella tua lingua, con il collegamento alla pagina. Per le forme flesse (*walked*) cerca la forma base (*walk*). Si chiede solo se la scheda resta aperta un attimo, e resta salvata; finisce anche nel vocabolario e nelle carte per Anki. Se Wiktionary non la ha, il pulsante "Chiedila a Gemini" la chiede al modello (una richiesta). Si accende e spegne nel popup → Aspetto → "Etimologia nella scheda della parola".
- **Pronuncia IPA: spenta = zero token.** Con "Pronuncia IPA nella scheda della parola" spenta la pronuncia non si vede e non si chiede mai (prima restava il pulsante per chiederla). Nella scheda c'è anche "spegni IPA" per spegnerla al volo.

## Novità della 5.9.4
- **Tolta la riga IPA sotto i sottotitoli** (e il suo pulsante): consumava molti token per pronunciare intere frasi e film. Ora la pronuncia IPA c'è solo nella **scheda della parola**, per la parola che stai guardando, chiesta solo se la scheda resta aperta almeno 0,8 secondi; poi resta salvata. Nel popup la casella si chiama "Pronuncia IPA nella scheda della parola".

## Novità della 5.9.3
- **Trascrizione nella lingua sbagliata (per esempio una canzone ceca trascritta in inglese): ora si cambia.** Accanto ai sottotitoli trascritti c'è un nuovo pulsante con la sigla della lingua (per esempio **EN**): cliccalo, cerca la lingua giusta ("ceco") e la trascrizione di quel video viene rifatta in quella lingua. La scelta resta per quel video (anche riaprendolo) e vince su quella del popup. La stessa cosa si trova nella scheda ⚑ → "🌐 Lingua sbagliata?".
- **"Completa" (tutto subito) che sembrava bloccata.** Se scaricare l'audio va per le lunghe o yt-dlp si blocca (succede con alcuni video di YouTube), dopo 12 secondi parte intanto la trascrizione mentre guardi, così i sottotitoli non restano fermi; quando arrivano le parti della trascrizione completa prendono il loro posto. Se lo scaricamento non va avanti per un minuto e mezzo viene interrotto con un messaggio chiaro (prima si poteva aspettare all'infinito).
- Corretto: "Rifai la trascrizione" a volte ricaricava la trascrizione vecchia appena cancellata (il salvataggio automatico la riscriveva subito dopo).

## Novità della 5.9.2
- **Pronuncia IPA bloccata da Groq ("token esauriti").** Le parole venivano chieste 300 alla volta, prenotando una risposta lunghissima: per Groq (che ha un limite di token al minuto) la richiesta era troppo grande e veniva rifiutata ogni volta, anche se la quota non era finita. Ora le parole vanno a gruppi più piccoli (80 per Groq, 200 per Gemini), con una risposta prenotata su misura; se è ancora troppo grande il gruppo viene diviso da solo.
- La pronuncia ora si chiede **prima a Gemini** (ha molti più token al giorno) e poi a Groq. Se un servizio dice che il limite è raggiunto, si passa subito all'altro, senza aspettare.

## Novità della 5.9.1
- **Pronuncia IPA che non compariva.** Con il giapponese (e a volte con altre lingue) il modello riscriveva le parole in un'altra forma (per esempio in kana) e l'estensione non riusciva ad abbinare le pronunce alle parole: la riga restava vuota e la richiesta veniva ripetuta ogni minuto. Ora le risposte vengono lette anche in quei casi (anche quando arrivano come elenco), e per giapponese, cinese e coreano al modello viene mandata anche la frase, così sceglie la lettura giusta dei caratteri.
- La riga IPA non aspetta più la fine della traduzione di tutto il film (con un film lungo ci volevano minuti): parte dopo pochi secondi.
- Se la pronuncia non può comparire, il motivo si legge passando il mouse sui sottotitoli (per esempio "serve la chiave di Groq o di Gemini", o l'errore del servizio) e nella riga di stato del popup.
- Nella scheda della parola il pulsante "Mostra la pronuncia IPA" richiede davvero la parola anche se la volta prima il modello l'aveva saltata.

## Novità della 5.9
- **Pronuncia IPA sotto la frase originale.** Sotto i sottotitoli originali compare una riga verde con la pronuncia di ogni parola in alfabeto fonetico internazionale (per esempio *hello* → həˈloʊ). Passando il mouse su una parola si illumina la sua pronuncia, e viceversa. La pronuncia compare anche nella scheda della parola, nel vocabolario e nelle schede esportate per Anki.
- Google non dà la pronuncia IPA, quindi la scrive **Groq o Gemini** (serve una delle due chiavi). Per consumare poco viene chiesta **una volta per parola**, insieme per le parole nuove della frase che vedi e delle prossime (fino a 300 parole per richiesta), e poi resta salvata: per un film intero bastano poche richieste, e le parole già viste non costano più niente, anche negli altri video. Se traduci con Gemini, la pronuncia la chiede a Groq (così non rallenta la traduzione).
- **Pulsante IPA** accanto ai sottotitoli (sopra ⧉ e ⚑, compare passando il mouse) per accenderla e spegnerla al volo; la stessa scelta è nel popup → Aspetto ("Pronuncia IPA sotto l'originale"). Con la riga spenta non parte nessuna richiesta; nella scheda di una parola resta il pulsante "Mostra la pronuncia IPA" per chiederla solo quando serve.

- **Trascrizione "mentre guardo": niente più frase bloccata e poi frasi che scappano via.** L'audio veniva mandato a Whisper a pezzi fino a 14 secondi: un pezzo conteneva 4-5 frasi che arrivavano tutte insieme quando il video le aveva già superate. La riga restava ferma sull'ultima frase del pezzo prima, poi saltava avanti di 4-5 frasi, o le mostrava di corsa. Ora i pezzi sono al massimo di 9 secondi (sempre tagliati nelle pause), e le frasi arrivate in ritardo vengono mostrate **tutte e in ordine**, ognuna almeno il tempo per leggerla; il ritardo si recupera piano piano accorciando un po' le frasi solo quando dietro ce ne sono altre già pronte, e sparisce nelle pause del parlato.

## Novità della 5.8.4
- **I sottotitoli non spariscono più a metà frase.** Spesso il tempo di fine di una frase (soprattutto nella trascrizione con Whisper e nei sottotitoli automatici) arriva prima che la frase sia finita di dire, e la riga spariva dopo un paio di secondi. Ora ogni frase resta visibile fino all'arrivo della successiva (se arriva entro 4 secondi), e comunque almeno il tempo per leggerla.

## Novità della 5.8.3
- **Quota di Whisper (Groq) finita: messaggio chiaro, subito.** Nella trascrizione di tutto il video l'estensione riprovava per minuti: ora dice se è finito il limite dell'ora o del giorno e tra quanto si libera, e si ferma (senza ripartire con la trascrizione mentre guardi, che finirebbe sulla stessa quota). Nella trascrizione mentre guardi l'attesa per il limite dell'ora mostra il tempo vero (prima al massimo 15 minuti). Se il credito dell'account è finito si ferma subito con un messaggio.

## Novità della 5.8.2
- **Le frasi brevi (una o due parole) ora vengono tradotte.** Gemini e gli altri modelli a volte ricopiavano uguali le frasi corte ("Ja." → "Ja.") e l'estensione non se ne accorgeva, perché controllava le copie solo dalle tre parole in su. Ora una frase ricopiata viene chiesta anche a Google: se Google la traduce si usa quella, se la lascia uguale anche lui è un nome o una parola internazionale ("Karen", "Okay") e resta così, senza richiederla più. Ai modelli viene anche detto esplicitamente di tradurre le risposte brevi e le esclamazioni.
- Le traduzioni di questo tipo già salvate vengono rifatte da sole la prima volta che riapri il video (solo quelle poche frasi), nei sottotitoli, nella trascrizione dal vivo e nella pagina "Trascrizione e traduzione".

## Novità della 5.8.1
- Guida completa riscritta (LEGGIMI): tutte le funzioni spiegate dall'inizio, con le istruzioni passo per passo.

## Novità della 5.8: meno richieste, servizi di riserva, traduzione con una chat, trascrizione che resta nella lingua giusta
**Meno richieste a Gemini (la quota dura molto di più).**
- La traduzione si chiede a gruppi di **120 frasi** invece di 40: un film di 2 ore costa circa 12 richieste invece di 38.
- Il collegamento parola tradotta ↔ originale e i modi di dire si chiedono **per 8 frasi alla volta**: passando sulle frasi seguenti sono già pronti, senza nuove richieste.
- Le **spiegazioni delle parole restano salvate** anche chiudendo il browser (le ultime 1500): la stessa parola nella stessa frase non si richiede più.

**Servizi di riserva.** Quando un servizio finisce le richieste gratuite di oggi, l'estensione continua da sola con il primo altro servizio di cui hai inserito la chiave, in quest'ordine: Gemini, Groq, Mistral, OpenRouter, Microsoft Translator, DeepL; alla fine Google Traduttore. Il servizio esaurito viene saltato fino al giorno dopo (anche negli altri video), così non si sprecano richieste. Nel popup, sotto la scelta del servizio, c'è l'elenco dei servizi di riserva pronti e di quelli finiti per oggi. Si può spegnere con la casella "Se finiscono le richieste gratuite, continua con un altro servizio".

**Servizi nuovi.**
- **Mistral** (gratis con chiave, console.mistral.ai): buona qualità nelle lingue europee.
- **Microsoft Translator** (gratis con chiave, 2 milioni di caratteri al mese, circa 40 film): traduttore classico, più preciso di Google, senza limiti al minuto. Serve un account Azure: crea una risorsa "Translator" con il piano gratuito F0, poi incolla nel popup la chiave e l'area (per esempio westeurope).

**Traduzione con una chat, senza quote.** Nella pagina "Trascrizione e traduzione":
- **Copia trascrizione** copia le frasi numerate con le istruzioni (a parti di 250 frasi se il video è lungo: il pulsante dice quale parte copierà).
- Incollale in una chat (ChatGPT, Claude, Gemini…), copia la risposta e premi **Incolla traduzione**: l'estensione legge le righe numerate, controlla che sia davvero una traduzione e la usa sul video. Resta salvata con il video, come le correzioni.

**La trascrizione non diventa più inglese.** Whisper, quando non gli si dice la lingua, a volte scrive in inglese quello che sente in un'altra lingua (cioè traduce invece di trascrivere). Ora:
- nei primi pezzi la lingua si decide "a voti" (contano solo i pezzi con abbastanza parlato); con 3 voti si fissa e da lì viene **imposta a Whisper** per tutto il video;
- i primi pezzi venuti in un'altra lingua vengono rifatti nella lingua giusta;
- se un pezzo esce comunque in inglese in un video non inglese, viene rifatto;
- un vero cambio di lingua (per esempio un video che passa dall'inglese all'italiano) viene ancora seguito, ma solo se Whisper è chiaramente più sicuro della lingua nuova per due pezzi di fila (e mai verso l'inglese, che è proprio l'errore da evitare). Se serve, la lingua si può sempre imporre nel popup con "Lingua parlata".

## Novità della 5.7.5
- **Reverso c'è sempre.** Nella 5.7.4 il collegamento a Reverso compariva solo per le lingue che Reverso apre già pronte da un indirizzo (inglese, italiano, spagnolo, francese, tedesco, russo, ecc.), quindi con il ceco non c'era. Ora c'è sempre: con queste lingue si apre già con la parola o la frase; con le altre, come il ceco, si apre Reverso e il testo viene copiato da solo: basta incollarlo (Ctrl+V) nella casella e scegliere le lingue.

## Novità della 5.7.4: copiare il testo e consultare i servizi di traduzione
- **Sul video**, accanto al pulsante ⚑ c'è il pulsante **⧉** (compare passando il mouse sui sottotitoli). Apre una scheda con la frase: il video si ferma, e il testo si può selezionare con il mouse. Ci sono i pulsanti **Copia originale**, **Copia traduzione** e **Copia tutte e due**; se selezioni solo una parte, copiano quella parte.
- **Apri in: Google Traduttore · DeepL · Reverso**: la frase (o la parte selezionata) si apre in un'altra scheda, già con le due lingue giuste. Reverso mostra la parola o l'espressione dentro tante frasi vere, utile per capire come si usa.
- **Nella scheda di una parola** (o di un'espressione) ci sono anche **Copia la parola** e **Copia la frase**, più i collegamenti a Google Traduttore, DeepL, Reverso, **WordReference** (tra inglese e italiano, spagnolo, francese, tedesco, portoghese) e **Wiktionary** (che spiega quasi ogni parola di quasi ogni lingua, anche il ceco).
- **Trascinando sulla traduzione** (confronto con l'originale), nell'etichetta ci sono anche **Copia** e i collegamenti.
- **Pagina "Trascrizione e traduzione" sistemata per copiare:**
  - prima la pagina si ridisegnava da sola ogni 3 secondi, anche mentre selezionavi: la selezione si perdeva o si allargava a tutta la pagina. Ora si ridisegna solo quando arriva testo nuovo, e mai mentre selezioni;
  - nella vista "Frase per frase" la selezione prende solo il testo: l'ora e i pulsanti non entrano più;
  - il "Testo unico" è diviso in paragrafi veri, più facili da selezionare;
  - selezionando una parte compare una barra con **Copia** e i collegamenti ai servizi di traduzione (se selezioni nella traduzione, il verso è al contrario);
  - ogni frase ha il pulsante **⧉** per copiarla con la sua traduzione.

## Novità della 5.7.3: parola giusta e particelle segnalate
- **Ogni parola tradotta rimanda alla parola che traduce davvero, non a quella vicina.** Prima, se il modello non collegava bene una parola (per esempio "angoli"), l'estensione prendeva la parte della parola accanto, e così si illuminava la parola dopo ("narozi" no, la seguente sì). Ora in quel caso cerca la traduzione vera: traduce con Google parola per parola la frase originale (una sola richiesta per frase, gratis) e collega "angoli" alla parola dell'originale che significa "angolo". Lo stesso vale per chi traduce con Google.
- Al modello (Gemini, Groq, Claude) si chiedono coppie più piccole possibile: una parola con la sua corrispondente quando la traduzione è letterale.
- **Particelle della traduzione segnalate.** Articoli, preposizioni e ausiliari che l'originale non ha (per esempio "i" in "i gatti" per l'inglese "cats", o "gli" per il ceco, che non ha articoli) non sono la traduzione di una parola:
  - passando il mouse compare l'etichetta **particella** e la spiegazione: «i» non traduce una parola dell'originale: la aggiunge la grammatica della traduzione in «i gatti», che traduce **cats**. Nell'originale la parte collegata è contornata a tratteggio, e si illumina anche il resto del gruppo nella traduzione;
  - dopo che il modello ha allineato la frase, le particelle restano **sottolineate a puntini** nella traduzione, così si riconoscono a colpo d'occhio;
  - passando sull'originale, si illumina la sua traduzione e, più tenui, le particelle che la accompagnano.
- Se una parola non ha una traduzione diretta (traduzione libera, o particella riconosciuta solo con Google), l'etichetta lo dice chiaramente e indica la zona della frase, con la scritta "circa", invece di fingere una corrispondenza precisa.

## Novità della 5.7.2: ogni parola della traduzione rimanda sempre all'originale
- **Non compare più "Nessuna parola corrispondente nell'originale".** Passando il mouse su una parola della traduzione si illumina sempre la parte dell'originale da cui viene.
- **Parole che la traduzione aggiunge** (articoli, preposizioni, verbi ausiliari: per esempio "del" in "una fetta del pane"): l'etichetta mostra la parte dell'originale a cui sono legate e spiega che nell'originale non hanno una parola propria. Così si capisce anche come cambia la grammatica tra le due lingue.
- Al modello (Gemini, Groq, Claude) si chiede di collegare ogni parola a una parte dell'originale, senza lasciarne nessuna vuota.
- Funziona meglio con apostrofi diversi ("l’acqua" e "l'acqua"), parole con il trattino e lingue scritte senza spazi (cinese, giapponese, thailandese).
- Se il modello non risponde (quota finita, errore), l'etichetta non resta più ferma su "Cerco…": passa a Google. Se anche Google non trova la parola, la cerca insieme alle parole vicine e, come ultima risorsa, indica la zona della frase con la scritta "posizione stimata".
- Cliccando una parola della traduzione si apre la scheda della parola principale della parte corrispondente (per esempio "bread" e non "the").
- Lo stesso vale per il confronto trascinando sulla traduzione: con Google la parte si cerca solo nella zona giusta della frase (prima parole comuni come "the" potevano illuminare quasi tutta la riga).
- I modi di dire vengono riconosciuti anche quando il modello scrive l'apostrofo in modo diverso.

## Novità della 5.7.1
- **"↻ Ritraduci" aggiorna subito anche i sottotitoli sul video.** Prima la nuova traduzione compariva solo nella scheda, e sul video restava quella vecchia finché non chiudevi la scheda. Ora cambia subito anche sotto l'originale. Lo stesso vale per "Ritrascrivi" e "Correggi a mano".

## Novità della 5.7: pulsante DS nel lettore e confronto delle frasi

### Pulsante DS per accendere e spegnere i sottotitoli doppi
- **Su YouTube** c'è un pulsante **DS** nella barra dei comandi del video, accanto al pulsante dei sottotitoli. **Sugli altri siti** è un piccolo pulsante "DS" in alto a destra del video: è semitrasparente e diventa pieno quando ci passi sopra.
- **Acceso** (bordo giallo): si vedono i sottotitoli doppi. **Spento**: spariscono, e la trascrizione dell'audio si ferma, così non consuma la quota di Groq e Gemini. Sono spenti finché non lo riaccendi, anche negli altri video, come il pulsante dei sottotitoli di YouTube.
- Se i sottotitoli doppi sono spariti per qualsiasi motivo (per esempio i sottotitoli di YouTube si sono spenti, o il testo si è perso), **premendo DS tornano**: l'estensione riaccende i sottotitoli di YouTube e, se serve, li richiede di nuovo. Nei video senza sottotitoli fa ripartire la trascrizione.
- La casella "Sottotitoli doppi attivi" del popup (sezione Altro) fa la stessa cosa.

### Confronto di una parte della traduzione con l'originale
- **Tieni premuto sulla prima parola della traduzione e trascina fino all'ultima**: le parole scelte si colorano di azzurro, e nella riga originale si illumina la parte corrispondente. Sopra compare un'etichetta con quel pezzo di originale e il pulsante **Spiega**, che apre la scheda con il suo significato nel contesto.
- Con Gemini, Groq o Claude la corrispondenza è precisa. Con Google è approssimata (nell'etichetta c'è scritto "circa").
- Il confronto resta visibile anche spostando il mouse. Si chiude con **Esc** o cliccando altrove nei sottotitoli.
- Trascinando sui sottotitoli il browser non seleziona più il testo, e i sottotitoli non spariscono.

## Novità della 5.6.5: vedere e copiare le chiavi

Accanto alle caselle delle chiavi nel popup (quella del servizio di traduzione e la **Chiave Groq** in "Video senza sottotitoli") ci sono due pulsanti:
- **Mostra** fa vedere la chiave al posto dei puntini (premi **Nascondi** per coprirla di nuovo);
- **Copia** la copia negli appunti, così puoi incollarla altrove (per esempio nella configurazione dell'add-on per Stremio o in Kodi).

Attenzione: chi vede la chiave la può usare a tuo nome, quindi non mostrarla in video o in foto.

## Novità della 5.6.4: "Ritrascrivi" si ferma quando ha finito

- **🎙 Ritrascrivi** su una frase già salvata (quando il suo audio non è più in memoria) fa tornare il video all'inizio della frase e la riascolta. Prima, dopo averla rifatta, la trascrizione restava accesa e continuava a ritrascrivere con il modello più lento. Ora, appena la frase è rifatta, **si ferma e torni alla trascrizione già fatta** (il popup scrive "Frase ritrascritta"). Se nel frattempo sposti il video altrove, la richiesta viene annullata.
- Corretto un errore della 5.6.3: in alcuni casi l'estensione ricollegava l'audio di continuo, e questo poteva spezzare la trascrizione in pezzi più corti del dovuto.

## Novità della 5.6.3: la trascrizione non si ferma più da sola

- **Trascrizione che si fermava dopo qualche minuto.** YouTube a volte cambia la "sorgente" del video mentre guardi (quando cambia la qualità, dopo una pubblicità…). L'audio che l'estensione ascoltava si interrompeva e la trascrizione restava muta, senza avvisare. Ora se ne accorge e riprende ad ascoltare da sola.
- **Video con sottotitoli sbagliati** (per esempio i sottotitoli automatici in portoghese su un video in ceco): se avvii tu la trascrizione dal popup, la scelta viene **ricordata per quel video**. Riaprendolo, la trascrizione riparte da sola e non tornano i sottotitoli sbagliati. Premendo "Ferma la trascrizione" tornano quelli di YouTube.
- **"Rifai la trascrizione"** (pagina Trascrizione e traduzione) ora riparte subito, anche se la trascrizione era ferma. Prima cancellava la vecchia trascrizione e poi non ripartiva.
- **Limiti di Groq spiegati meglio.** Groq gratis permette un certo numero di ore di audio all'ora e al giorno (il numero esatto lo dice Groq nel messaggio). Se finisce la quota **dell'ora**, il popup dice tra quanto riprende e la trascrizione riparte da sola. Se finisce quella **del giorno**, la trascrizione si ferma con un messaggio chiaro, invece di riprovare all'infinito.

Nota: il pulsante **🎙 Ritrascrivi** nella scheda di una frase rifà **solo quella frase** (per questo vengono poche parole). Per rifare tutto il video usa "Rifai la trascrizione" nella pagina Trascrizione e traduzione.

## Novità della 5.6.2: tutte le lingue anche per la pronuncia

Anche **Pronuncia delle parole → Lingua** ora ha tutte le 98 lingue, con la stessa casella di ricerca della lingua parlata.

- Se il computer ha una voce per quella lingua viene usata quella; altrimenti la voce online di Google. Sotto il menu compare un avviso se una lingua non ha voce né sul computer né su Google (per esempio alcune lingue rare): in quel caso puoi aggiungere una voce in Windows (**Impostazioni → Ora e lingua → Voce**).
- "Prova la voce" funziona con ogni lingua: per quelle senza una frase di prova pronuncia il nome della lingua.
- Ora vengono riconosciute anche le voci di Windows con codici diversi per la stessa lingua (per esempio il norvegese "nb-NO").

## Novità della 5.6.1: tutte le lingue per la trascrizione

In **Video senza sottotitoli → Lingua parlata** ora ci sono **tutte le 98 lingue** che Whisper sa trascrivere (prima erano 17), con i nomi in italiano e nella lingua originale (per esempio "Norvegese · norsk").

- Sopra l'elenco c'è una **casella di ricerca**: scrivi una parte del nome (in italiano, in inglese o nella lingua stessa, oppure il codice come "cs") e l'elenco mostra solo le lingue che corrispondono. Premi **Invio** per scegliere la prima, oppure clicca quella che vuoi.
- Accanto a "Lingua parlata" vedi sempre quella scelta. "Rileva da sola" resta la scelta predefinita e va bene nella maggior parte dei casi: conviene indicare la lingua solo se Whisper la sbaglia.

## Novità della 5.6: modi di dire e trascrizione più corretta

### Modi di dire ed espressioni di più parole
Alcune espressioni non si traducono parola per parola ("break the ice", "give up", "tomar el pelo"). Ora l'estensione le tratta come un blocco unico.

- **Sottolineate da sole** (con Gemini, Groq, Claude o un modello locale): quando ti fermi con il mouse sulle parole della riga originale, dopo un attimo l'estensione chiede al modello i modi di dire di quella frase. Le espressioni trovate vengono **sottolineate con un'onda arancione**. Passandoci sopra **si illumina tutta l'espressione** e la scheda mostra il suo significato vero, senza altre richieste. **Cliccando** arriva la spiegazione completa nel contesto. Nella scheda c'è anche "Solo la parola …", se ti serve il significato della singola parola.
- La richiesta è **una sola per frase** ed è la stessa che allinea la traduzione con l'originale (quella della 5.5): se poi passi sulle parole tradotte, non ne parte un'altra. Parte solo se ti fermi sulle parole: se passi sopra per andare al pulsante delle correzioni, non consuma niente.
- **Selezione a mano** (funziona anche con Google, gratis): **tieni premuto sulla prima parola e trascina fino all'ultima**. Le parole diventano verdi e si apre la scheda con la traduzione dell'**espressione intera**. Con un modello, la spiegazione è nel contesto della frase.
- Anche cliccando una singola parola, se il modello si accorge che fa parte di un modo di dire, la scheda lo dice ("Modo di dire: «…» = …") e l'espressione viene sottolineata nella frase.
- Le espressioni si possono salvare nel **vocabolario** con la stellina, come le parole.
- Si può spegnere in **Altro → Evidenzia i modi di dire**. La selezione a mano resta sempre disponibile.

### Trascrizione corretta da Gemini
Whisper a volte capisce male le parole, sbaglia le desinenze o salta articoli e preposizioni. Ora le frasi trascritte vengono **corrette** (parole capite male, grammatica, punteggiatura, nomi) prima di essere tradotte, senza riscrivere il senso.

- **Se traduci con Gemini, Groq, Claude o un modello locale**: la correzione si fa già nella stessa richiesta della traduzione (nessuna richiesta in più). Le regole di correzione ora sono più decise: prima correggeva quasi solo la punteggiatura.
- **Se traduci con Google o DeepL**: la correzione la fa **Gemini** se hai inserito la chiave Gemini, altrimenti **Groq** (la stessa chiave della trascrizione). Le frasi vengono corrette **a gruppi** (una richiesta ogni 10-30 frasi, non una per frase): intanto vedi subito la traduzione rapida, che dopo pochi secondi viene rifatta sul testo corretto.
- Una correzione viene accettata solo se la frase resta riconoscibile: il modello non può inventare frasi diverse.
- Se Gemini (o Groq) finisce le richieste gratuite del giorno, la correzione si sospende da sola e la traduzione continua normalmente.
- Si può spegnere in **Video senza sottotitoli → Correggi la grammatica della trascrizione**; sotto la casella c'è scritto chi la fa e quante richieste usa.

## Dalla parola tradotta alla parola originale (5.5)

Passa il mouse su una parola della **traduzione**: la parola corrispondente si illumina nella riga originale, così la vedi nel suo contesto, e sotto compare una piccola etichetta con l'originale. **Cliccando** la parola tradotta si apre la scheda con il significato della parola originale in quella frase.

- **Con Google (gratis)** la corrispondenza è approssimata (nell'etichetta compare "circa"): l'estensione traduce al contrario la parola e la cerca nell'originale. Funziona bene per nomi, verbi e aggettivi, meno per le parole grammaticali o quando la traduzione è molto libera.
- **Con Gemini, Groq, Claude o un modello locale**, alla prima parola su cui passi il modello "allinea" tutta la frase con una sola richiesta, e da lì la corrispondenza è precisa anche per le espressioni di più parole. Intanto vedi quella approssimata, che viene sostituita da sola dopo pochi secondi. Quando una frase è allineata funziona anche al contrario: passando su una parola originale si illumina la sua traduzione.

## Correggere le singole frasi (5.4)

Quando una frase è trascritta o tradotta male, puoi segnalarla e far rifare solo quella.

**Sul video:** passa il mouse sui sottotitoli e clicca la bandierina **⚑** che compare a destra. Si apre una scheda con:
- **↻ Ritraduci:** chiede di nuovo la traduzione di quella frase, con le frasi vicine come contesto. Passa davanti alle altre traduzioni in corso, quindi arriva subito. Se il servizio scelto non dà una traduzione valida, la chiede a Google.
- **🎙 Ritrascrivi** (solo per le frasi trascritte dall'audio, non per i sottotitoli di YouTube): fa riascoltare la frase a Whisper con il modello più preciso (`whisper-large-v3` invece della versione turbo). Se l'audio di quella frase è ancora in memoria (gli ultimi minuti), è immediato. Altrimenti il video torna all'inizio della frase e la riascolta, e la nuova versione compare dopo pochi secondi. La traduzione della nuova frase viene rifatta da sola.
- **✎ Correggi a mano:** scrivi tu l'originale e/o la traduzione giusta. Se correggi solo l'originale, la traduzione viene rifatta da sola.
- **✕ Togli questa frase:** per le frasi inventate, per esempio durante la musica.

**Nella pagina "Trascrizione e traduzione"**, scheda **Frase per frase (e correzioni)**: ogni riga ha gli stessi pulsanti (↻ 🎙 ✎ ✕). Funzionano anche per i file trascritti direttamente dalla pagina, senza video aperto; lì però si può ritradurre, correggere e togliere, non ritrascrivere. Le frasi corrette hanno il segno ✎.

Le correzioni restano salvate con il video, valgono anche nell'esportazione (.txt, .srt) e non vengono sovrascritte nemmeno da "Rifai la traduzione".

Inoltre: la trascrizione dal vivo teneva in memoria l'audio di tutte le frasi, quindi nelle sessioni lunghe il consumo di memoria cresceva senza limite. Ora tiene solo quello degli ultimi minuti.

## Novità e correzioni della 5.3

- **Frasi inventate durante la musica** ("I'm sorry", "It's over", "Thank you"…): i filtri ora usano tutti gli indicatori di Whisper (quanto è sicuro che ci sia parlato, quanto è sicuro del testo, quanto è ripetitivo), più un elenco di frasi tipiche scartate quando Whisper è poco sicuro. Con Gemini, Groq, Claude o un modello locale, poi, il testo viene anche ripulito (vedi sotto).
- **Pulizia della trascrizione, senza richieste in più:** nella stessa richiesta con cui traduce, il modello restituisce anche il testo originale corretto (parole capite male, punteggiatura) e segnala i pezzi che non sono parlato, che vengono tolti. Vale per la trascrizione di Whisper, non per i sottotitoli di YouTube.
- **Video che cambiano lingua:** prima, dopo i primi pezzi, la lingua veniva bloccata, e quando il video cambiava lingua Whisper traduceva in quella bloccata. Ora, se un pezzo sembra in un'altra lingua, viene trascritto in tutte e due e si tiene la versione di cui Whisper è più sicuro. Costa una richiesta in più solo in quei casi. Dopo due pezzi di fila nella lingua nuova, quella diventa la lingua del video. Le frasi già nella tua lingua non vengono tradotte.
- **Traduzione che in realtà è una trascrizione:** oltre alle copie dell'originale, ora viene riconosciuta anche una "traduzione" scritta in una lingua diversa da quella scelta. Viene sostituita da Google e non viene salvata.
- **Modalità Completa a pezzi:** i video oltre i 2 minuti e mezzo vengono trascritti in pezzi da circa 3 minuti, tagliati nei silenzi, cominciando dal punto in cui sei e poi andando avanti e indietro. I sottotitoli compaiono man mano, ogni pezzo riconosce la sua lingua, e Whisper non salta più interi minuti dopo una musica. Per un video di 30 minuti sono circa 10 richieste invece di una, ma restano molte meno di quelle della trascrizione mentre guardi.
- **Sottotitoli che sparivano a un certo punto in un video già visto:** le parti della trascrizione completa rimaste senza frasi (buchi di oltre 25 secondi) vengono riascoltate quando ci passi. Le parti già coperte non costano niente.
- **La modalità predefinita cambiata dal popup vale subito** per il video aperto, senza ricaricare. Anche "Come quella predefinita" per questo video si applica subito.
- **Popup che non si apriva al primo clic su Firefox:** corretto (era una regola di stile che lo faceva partire largo zero).

## Correzioni della 5.2.3

- **Trascrizione che compare e scompare nella pagina "Trascrizione e traduzione"** (e popup che a volte non vede la trascrizione attiva): succedeva sui siti con più video nella stessa scheda, per esempio un sito IPTV con il suo lettore e un canale di YouTube incorporato. Rispondevano entrambi e vinceva il primo, a volte quello senza testo. Ora risponde sempre il video con la trascrizione o in riproduzione, e i comandi (Trascrivi, Ferma, Rifai, Carica sottotitoli…) vanno solo a quello.
- **Pronuncia che abbassa l'audio del video senza rialzarlo:** durante la pronuncia l'estensione abbassa lei il video e, quando la voce ha finito, lo riporta esattamente al volume di prima. Se nel frattempo hai cambiato tu il volume, non lo tocca. Inoltre la voce viene "liberata" subito dopo l'uso. Se l'audio restasse comunque basso, può dipendere da un'impostazione di Windows: Pannello di controllo → Audio → scheda **Comunicazioni** → scegli **Non fare nulla**.
- **Dirette nella pagina della trascrizione:** al posto di una percentuale senza senso, compare la nota che il testo cresce mentre guardi. Il pulsante per scaricare tutto il file non compare, perché una diretta non si può scaricare intera.

## Novità della 5.22.0
- **Traduzione nella lingua o nell'alfabeto sbagliato** (per esempio la trascrizione araba al posto della traduzione italiana, che restava anche cambiando lingua): ora ogni «traduzione» scritta in un alfabeto diverso da quello della lingua scelta viene scartata e rifatta con Google, e quelle sbagliate già salvate vengono buttate quando riapri il video. Se il traduttore è YouTube e la sua traduzione è nell'alfabeto sbagliato, per quel video si passa da soli a Google.
- **⚑ → «Tutta la traduzione di questo video è sbagliata?»**: «↻ Rifalla tutta» (cancella quella salvata e la rifà) e «↻ Rifalla con Google Traduttore» (per questo video traduce sempre Google; «Torna al servizio scelto nel popup» per annullare).
- **Diretta sincronizzata più robusta**: il video va indietro subito quando la modalità parte (con i comandi del lettore di YouTube, che prima a volte annullava lo spostamento); sul video compaiono gli avvisi («sto mettendo a tempo», «sottotitoli in orario», oppure perché non funziona); se non funziona il video torna al momento attuale della diretta. Il programma per yt-dlp 1.2 dice a yt-dlp dove si trova ffmpeg: **rilancia l'installatore** (popup → Video senza sottotitoli → Programma per yt-dlp).

## Correzioni della 5.2

- **Sottotitoli a blocchi enormi e traduzione sfasata.** Whisper restituiva pezzi di lunghezza molto variabile, da una parola a 30 secondi, e il modello a volte metteva la traduzione di una frase sotto il pezzo accanto. Ora l'estensione chiede a Whisper i tempi delle singole parole e ritaglia lei le frasi: divise ai punti (e alle virgole se troppo lunghe), con i frammenti di una o due parole uniti a quelli vicini. Ogni traduzione viene poi controllata. Se è vuota o sproporzionata rispetto alla sua frase, il blocco viene ritradotto in pezzi più piccoli invece di essere accettato sfasato. Intanto sotto ogni frase resta la traduzione rapida, al posto giusto.
- **Traduzione quasi uguale all'originale** (con una virgola o una parola in più): ora viene riconosciuta per somiglianza, non solo quando è identica. Viene sostituita da Google e non viene salvata.
- **Traduzioni sbagliate salvate dalle versioni precedenti:** quelle vuote, sproporzionate o ricopiate vengono scartate da sole quando riapri il video, e richieste di nuovo. Per i video già trascritti in pezzi enormi, usa **Rifai la trascrizione** nella pagina "Trascrizione e traduzione".
- **Popup su Firefox:** non esce più dai bordi. Anche i menu con opzioni lunghe restano dentro la finestra. Inoltre il campo "Indirizzo del server" ora compare solo quando serve.

## Trascrizione: Completa, Mentre guardo o Spenta

Per i video senza sottotitoli puoi scegliere come trascrivere (popup, sezione **Video senza sottotitoli**):
- **Completa:** appena apri il video, l'audio intero viene scaricato e trascritto in pochi secondi, poi tradotto a partire dal punto in cui sei. Pause, salti e velocità non contano più, e i sottotitoli escono in pari con il video. Su YouTube, Vimeo, VK e simili serve il **programma per yt-dlp** (vedi sotto). Sui file diretti (mp4, mp3…) non serve.
- **Mentre guardo:** come prima, trascrive quello che guardi.
- **Spenta:** non parte da sola.

Nel popup ci sono due scelte:
- **Modalità predefinita**, con un limite di durata ("Completa solo fino a… minuti", 60 di partenza): oltre quel limite, in automatico si usa "Mentre guardo", così un film di due ore aperto per sbaglio non consuma la quota di Groq.
- **Per questo video**, che vale solo per il video aperto e vince su quella predefinita. Scegliendo "Completa" lì, il limite di durata non vale.

Se la modalità Completa non riesce (programma non installato, YouTube che blocca, sito non supportato), l'estensione te lo dice e passa da sola a "Mentre guardo".

Un video trascritto per intero resta salvato: rivederlo non consuma nessuna richiesta.

## Il programma per yt-dlp

Il browser non permette alle estensioni di avviare programmi, quindi yt-dlp va installato una volta a parte:
1. Popup → **Video senza sottotitoli** → **Programma per yt-dlp**.
2. Premi **Scarica l'installatore** e lancialo (su Windows con un doppio clic; se Windows avvisa, scegli "Ulteriori informazioni" e poi "Esegui comunque").
3. Torna sulla pagina e premi **Verifica di nuovo**: deve comparire "Installato e funzionante".

L'installatore mette tutto in `%LOCALAPPDATA%\SottotitoliDoppi`, solo per il tuo utente e senza permessi di amministratore: yt-dlp, Deno (che serve a yt-dlp per YouTube) e il programma di appoggio. Se manca Python, lo installa con winget. yt-dlp si aggiorna da solo ogni pochi giorni. Se un giorno YouTube smette di funzionare, rilancia l'installatore.

L'installatore scaricato da Edge registra il programma per Edge (e Chrome) e per Firefox. Se usi l'estensione in più browser Chromium, scaricalo e lancialo da ognuno.

Tieni presente che i termini di servizio di YouTube non permettono di scaricare i video. L'audio viene usato solo per la trascrizione e cancellato subito.


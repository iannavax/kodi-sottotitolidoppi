# Parole al Volo 1.4.4: IPA prima da Wiktionary, il modello solo se manca
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
async def handle(route, request):
    if request.url.startswith("https://en.wiktionary.org/"): return await charness.handle(route, request)
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:true, engine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "en", "bread", 3500)
        print("1. bread:", await pg.evaluate("(document.querySelector('.pav-ipa')||{}).textContent"), "|", await pg.evaluate("(document.querySelector('.pav-ipa')||{}).title"), "| IPA al modello:", tvolo.log["ipa"])
        await tvolo.hover(pg, "en", "market", 4000)
        print("2. market:", await pg.evaluate("(document.querySelector('.pav-ipa')||{}).textContent"), "| IPA al modello:", tvolo.log["ipa"])
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

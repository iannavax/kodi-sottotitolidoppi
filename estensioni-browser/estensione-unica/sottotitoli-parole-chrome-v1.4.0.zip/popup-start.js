// Apre il popup dell'ultima scheda usata: "Video" (Sottotitoli Doppi) o "Pagine" (Parole al Volo)
let tab = "video";
try { tab = localStorage.getItem("unicaTab") || "video"; } catch {}
location.replace(tab === "pagine" ? "popup-pagine.html" : "popup-video.html");

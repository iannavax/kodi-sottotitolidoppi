# 1.7.0: voci Piper gratuite (sul computer) e del server Speaches nel menù «🔈 Voce» — modello finto, rete simulata
import asyncio, os, sys, json
os.environ["PIPER_SPEACHES"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from charness import *
import http.server, threading, shutil
FIX = "/tmp/piperfix"; shutil.rmtree(FIX, ignore_errors=True)
for k, n, q, fam, cod in (("it_IT-riccardo-x_low", "riccardo", "x_low", "it", "it_IT"), ("en_US-amy-low", "amy", "low", "en", "en_US")):
    d = f"{FIX}/{fam}/{cod}/{n}/{q}"; os.makedirs(d)
    shutil.copy("/home/claude/e2e/fixtures/fake-piper.onnx", f"{d}/{k}.onnx")
    json.dump({"audio": {"sample_rate": 22050}, "espeak": {"voice": "it" if fam == "it" else "en-us"}, "inference": {"noise_scale": 0.667, "length_scale": 1, "noise_w": 0.8}, "num_speakers": 1}, open(f"{d}/{k}.onnx.json", "w"))
json.dump({"it_IT-riccardo-x_low": {"key": "it_IT-riccardo-x_low", "num_speakers": 1, "files": {"it/it_IT/riccardo/x_low/it_IT-riccardo-x_low.onnx": {"size_bytes": 311}}}, "it_IT-paola-medium": {"key": "it_IT-paola-medium", "files": {}}, "en_US-amy-low": {"key": "en_US-amy-low", "files": {"en/en_US/amy/low/en_US-amy-low.onnx": {"size_bytes": 311}}}}, open(f"{FIX}/voices.json", "w"))
os.makedirs(f"{FIX}/api", exist_ok=True)
json.dump([{"id": "speaches-ai/piper-it_IT-riccardo-x_low", "downloads": 5400}, {"id": "speaches-ai/piper-it_IT-paola-medium", "downloads": 123000}, {"id": "speaches-ai/piper-en_US-amy-low", "downloads": 900}], open(f"{FIX}/api/models", "w"))
hits = []
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=FIX, **k)
    def log_message(self, f, *a): hits.append(self.path)
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 8791), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({piperBase:'http://127.0.0.1:8791/', piperPopUrl:'http://127.0.0.1:8791/api/models'})")
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'en', ttsLang:'it', ipa:false})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append("popup: " + str(e)))
        pp.on("console", lambda m: errs.append("console: " + m.text) if m.type == "error" else None)
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1500)
        await pp.evaluate("document.getElementById('dTts').open=true"); await pp.wait_for_timeout(2500)
        await ctx.route("**/translate_tts*", lambda r: r.fulfill(status=400, body="no"))   # Google non legge la lingua
        
        log["anki_notes"] = {8001: {"Fronte": "<b>ciao</b>", "Retro": "<b>hello</b>"}}
        await sw.evaluate("chrome.storage.sync.set({ttsVoices:{it:\"Microsoft Elsa - Italian\"}})")
        r = await pp.evaluate("""chrome.runtime.sendMessage({type:'ankiUpdate', id:8001, cards:[], names:['Fronte','Retro'], model:'Base',
            entry:{word:'ciao a tutti', lang:'it', kind:'text', meaning:'hello'}, audio:true, keep:[]})""")
        print("risposta:", {k: v for k, v in (r or {}).items() if k in ("how", "audioNote", "error")}, "| file:", [m for m in log.get("anki_media", []) if m.endswith(".wav")])
        ok = r and r.get("how") != "tts" and "voce del computer" in (r.get("audioNote") or "") and "nessuna voce Piper" in (r.get("audioNote") or "")
        print("errori:", errs if ok else errs + ["Piper non usato quando Google non c'è"], log["errors"])
        await ctx.close()
asyncio.run(main())

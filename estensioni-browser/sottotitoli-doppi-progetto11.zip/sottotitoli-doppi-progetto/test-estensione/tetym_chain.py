# Etimologia che rimanda a un'altra parola della stessa lingua: embarazada → embarazado (forma) → "participio di
# embarazar" → embarazar ← portoghese embaraçar ← baraço. Si segue il rimando su Wiktionary, senza modello.
# Uso: python3 tetym_chain.py <estensione con pdf.html (Parole al Volo o unica)>
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it'})")
        eid = sw.url.split("/")[2]
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/pdf.html"); await pg.wait_for_timeout(800)
        r = await pg.evaluate("DS_ETYM.get('embarazada', 'es', 'it').then(r => ({text: r.text, trans: r.trans, lemma: r.lemma}))")
        print("1. embarazada:", r)
        print("   pagine chieste:", log.get("wikt"))
        r = await pg.evaluate("DS_ETYM.get('walked', 'en', 'it').then(r => r.text)")
        print("2. walked (non cambia):", r)
        # forma senza pagina sua: la parola madre si cerca e si prende solo se la forma è nella sua tabella
        r = await pg.evaluate("DS_ETYM.get('подошве', 'ru', 'it').then(r => ({text: r.text, lemma: r.lemma, how: r.baseHow, audio: r.audioTitle}))")
        print("3. подошве:", r, "| ricerche:", log.get("wiktsearch"))
        r = await pg.evaluate("DS_ETYM.setBase('подошве', 'ru', 'it', 'подошел').then(r => ({text: r.text, lemma: r.lemma, how: r.baseHow}))")
        print("4. parola madre scelta a mano:", r)
        r = await pg.evaluate("DS_ETYM.setBase('подошве', 'ru', 'it', '-').then(r => ({text: r.text, none: r.none}))")
        print("5. nessuna parola madre:", r)
        r = await pg.evaluate("DS_ETYM.setBase('подошве', 'ru', 'it', '').then(r => ({lemma: r.lemma, how: r.baseHow}))")
        print("6. di nuovo automatica:", r, "| salvate:", await pg.evaluate("chrome.storage.local.get('etymBase').then(r=>JSON.stringify(r.etymBase))"))
        r = await pg.evaluate("DS_ETYM.searchBases('подошве', 'ru').then(r => r.list.map(c => (c.sure ? '✓ ' : '') + c.title + (c.etym ? '' : ' (senza etimologia)')))")
        print("7. 🔍 ricerca a mano:", r)
        r = await pg.evaluate("DS_ETYM.searchBases('сожалению', 'ru', ['к сожалению']).then(r => r.list.map(c => (c.sure ? '✓ ' : '') + c.title + ' ' + c.near.toFixed(2) + (c.etym ? '' : ' (senza etimologia)')))")
        print("8. 🔍 per radice (сожалению):", r, "| radici cercate:", log.get("wiktprefix"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

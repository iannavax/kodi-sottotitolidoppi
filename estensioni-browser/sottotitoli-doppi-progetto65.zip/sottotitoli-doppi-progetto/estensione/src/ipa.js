// Pronuncia in alfabeto fonetico internazionale (IPA) delle parole, per la scheda.
// Prima Wiktionary (gratis); se manca, la scrive il modello nella stessa richiesta di «✨ Spiega con…» e resta
// salvata qui (anche per gli altri video). 1.6.0: tolta la vecchia riga IPA sotto i sottotitoli (non si vedeva
// più, e chiedeva al modello la pronuncia di tutte le parole delle frasi).
const ipaCache = dsShardMap("ipa", 3000, (k) => String(k).split("|")[0]);   // "lingua|parola" → IPA ("" = il modello non l'ha data); un pezzo per lingua (1.7.3)
const ipaPending = new Set();
const ipaSkip = {};   // servizio → fino a quando non usarlo per la pronuncia (limite raggiunto)
const ipaSave = () => {};   // (la cache a pezzi si salva da sola, a gruppi: nome tenuto per chi lo chiama)

const ipaOn = () => !!settings && settings.ipa !== false;
const ipaLang = (lang, text) => String(lang || DualSubs.guessLang(text || "") || "auto").split("-")[0].toLowerCase();
const ipaK = (lang, w) => lang + "|" + String(w || "").toLowerCase();
function ipaOf(word, lang) {
  const v = ipaCache.get(ipaK(ipaLang(lang, word), word));
  return v || "";
}
function ipaWordsOf(text, lang) {
  return wordsTokenize(text || "", lang).filter((p) => p.word).map((p) => p.text);
}

// Chi scrive la pronuncia: preferisco un servizio diverso da quello che traduce (così non rallento la traduzione)
function ipaEngine() {
  if (!settings) return null;
  // prima Gemini (molti token al giorno e al minuto), poi Groq (i suoi token servono anche alla correzione della
  // trascrizione e finiscono presto). Solo questi due: gli altri servizi restano di riserva per la traduzione.
  // Un servizio che ha appena detto "limite raggiunto" viene saltato per un po' (ipaSkip).
  const own = typeof dsTaskEngine === "function" ? dsTaskEngine("ipaEngine") : null;
  if (own && own.E.kind === "openai" && !((ipaSkip[own.id] || 0) > Date.now())) return own;
  for (const id of C.engineOrder(settings)) {
    if (!C.ENGINES[id] || C.ENGINES[id].kind !== "openai" || dsIsBlocked(id) || (ipaSkip[id] || 0) > Date.now()) continue;
    const e = engineById(id);
    if (dsReady(e)) return e;
  }
  return null;
}

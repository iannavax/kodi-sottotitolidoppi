# Parole al Volo 1.2: lingua riconosciuta male → si cambia dalla scheda (anche per tutto il sito) e dal popup
import asyncio, os, sys, json, re, urllib.parse
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
G = []
orig = tvolo.handle
async def handle(route, request):
    url = request.url
    if url.startswith("https://example.test/"):
        body = "<!doctype html><html><head><meta charset='utf-8'></head><body style='margin:40px;font:20px/2 sans-serif'><p id='cz'>Dnes jsme koupili chleba na trhu.</p><p id='sel'>Ahoj, jak se mas? Mam se dobre.</p></body></html>"
        return await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=body)
    if url.startswith("https://translate.googleapis.com/translate_a/single"):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query); text = q.get("q", [""])[0]; sl = q.get("sl", ["auto"])[0]
        G.append((text, sl))
        det = sl if sl != "auto" else "pl"     # riconosciuto (male) come polacco
        body = [[[f"IT-{det}[" + text + "]", text]], [["nome", ["x"]]] if "bd" in q.get("dt", []) else None, det]
        return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
    return await orig(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/pagina.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "cz", "chleba", 1800)
        print("1. riconosciuta:", await pg.evaluate("(document.querySelector('.pav-langrow')||{}).innerText"), "|", await pg.evaluate("(document.querySelector('.pav-meaning')||{}).textContent"))
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.get_by_text("sbagliata? cambia").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-search").fill("ceco"); await pg.wait_for_timeout(200)
        print("2. cerco 'ceco':", await pg.locator(".pav-langlist button").all_inner_texts())
        await pg.keyboard.press("Enter"); await pg.wait_for_timeout(1200)
        print("3. dopo la scelta:", await pg.evaluate("(document.querySelector('.pav-langrow')||{}).innerText"), "|", await pg.evaluate("(document.querySelector('.pav-meaning')||{}).textContent"),
              "| frase:", await pg.evaluate("(document.querySelector('.pav-sentrans')||{}).textContent"), "| sito ricordato:", await sw.evaluate("chrome.storage.sync.get('siteLang').then(r=>JSON.stringify(r.siteLang))"))
        # 4. con "Ricorda per il sito"
        await pg.get_by_text("sbagliata? cambia").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-remember input").check(); await pg.locator(".pav-search").fill("ceco"); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(1200)
        print("4. ricordata:", await sw.evaluate("chrome.storage.sync.get('siteLang').then(r=>JSON.stringify(r.siteLang))"), "|", await pg.evaluate("(document.querySelector('.pav-langrow')||{}).innerText"))
        await pg.keyboard.press("Escape"); await pg.mouse.click(5, 5)
        G.clear()
        await tvolo.hover(pg, "cz", "trhu", 1800)
        print("5. altra parola: lingua mandata a Google:", sorted(set(sl for _, sl in G)), "|", await pg.evaluate("(document.querySelector('.pav-langrow')||{}).innerText"))
        await pg.keyboard.press("Escape"); await pg.mouse.click(5, 5)
        # 6. selezione: stessa lingua
        G.clear()
        b1 = await tvolo.word_box(pg, "sel", "Ahoj"); b2 = await tvolo.word_box(pg, "sel", "dobre")
        await pg.mouse.move(b1["l"] + 1, b1["y"]); await pg.mouse.down(); await pg.mouse.move(b2["r"], b2["y"], steps=6); await pg.mouse.up(); await pg.wait_for_timeout(1500)
        print("6. selezione:", await pg.evaluate("(document.querySelector('.pav-textcard .pav-title')||{}).textContent"), "| lingua mandata:", sorted(set(sl for _, sl in G)))
        # 7. popup
        ext = sw.url.split("/")[2]
        pp = await ctx.new_page(); await pp.goto(f"chrome-extension://{ext}/{'popup-pagine.html' if __import__('os').path.exists(EXT + '/popup-pagine.html') else 'popup.html'}"); await pp.wait_for_timeout(800)
        print("7. popup: lingua del testo", await pp.input_value("#sourceLang"), "| opzioni", await pp.locator("#sourceLang option").count())
        await pp.select_option("#sourceLang", "sk"); await pp.wait_for_timeout(300)
        print("   impostata:", await sw.evaluate("chrome.storage.sync.get('sourceLang').then(r=>r.sourceLang)"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

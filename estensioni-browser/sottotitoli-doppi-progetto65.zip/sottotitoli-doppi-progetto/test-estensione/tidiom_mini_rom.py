# 1.7.2: scheda piccola di una parola di un modo di dire in un altro alfabeto: lettere latine subito, traduzione gratis, spiegazione solo col pulsante
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/vocab.html"); await pg.wait_for_timeout(1200)
        await pg.add_script_tag(url=f"chrome-extension://{eid}/roman.js"); await pg.wait_for_timeout(300)
        has = await pg.evaluate("typeof DS_LEARN !== 'undefined' && typeof DS_ROMAN !== 'undefined'")
        print("0. DS_LEARN e DS_ROMAN nella pagina:", has)
        r = await pg.evaluate("""async () => {
          const o = { target: 'it', lang: 'ru', searchWord: (w) => { window.__searched = w; }, llm: () => null };
          const box = DS_LEARN.idiomPanel({ word: 'баклуши', idioms: [{ text: 'бить баклуши', meaning: 'poltrire' }], dict: [], source: '' }, o);
          document.body.append(box);
          const w = [...box.querySelectorAll('.dsx-idw')].find(b => b.textContent.includes('баклуши'));
          w.click(); await new Promise(r => setTimeout(r, 800));
          const mini = box.querySelector('.dsx-idmini');
          return { mini: mini ? mini.innerText : '', searched: window.__searched || null };
        }""")
        print("1. scheda piccola:", r["mini"].replace("\n", " | "), "| ricerca partita da sola:", r["searched"])
        ok = "[baklushi]" in r["mini"].lower() or "baklu" in r["mini"].lower()
        print("errori:", errs if ok and not r["searched"] else errs + ["traslitterazione o ricerca automatica non vanno"])
        await ctx.close()
asyncio.run(main())

import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("new Promise(r=>setTimeout(r,1500))")   # lascio finire la sistemazione iniziale
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', models:{gemini:'gemini-flash-latest', groq:'x'}})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}, migrated:{}})).then(()=>dsMigrate())""")
        print("aggiornamento con chiave Gemini già presente:", await sw.evaluate("chrome.storage.sync.get(['engine','models'])"))
        await ctx.close()
asyncio.run(main())

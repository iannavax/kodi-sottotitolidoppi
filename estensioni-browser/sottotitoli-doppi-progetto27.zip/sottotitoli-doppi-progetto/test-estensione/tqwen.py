# 1.4.6: traduzione con il modello sul computer quando nel popup c'è un modello che Ollama non ha più (gemma4 cancellato,
# ora qwen3): prima «model not found» e nessuna traduzione; ora sceglie da solo un modello installato e lo ricorda
import asyncio, os, sys
os.environ["FAKE_OLLAMA_MODELS"] = "qwen3:8b"
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'local', models:{local:'gemma4:e4b'}, targetLang:'it', ipa:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        try: await pg.wait_for_function("/GEM\\[/.test((document.querySelector('.dualsub-trans')||{}).textContent||'')", timeout=40000)
        except Exception: print("   (traduzione del modello non arrivata)")
        print("1. traduzione:", await pg.evaluate("(document.querySelector('.dualsub-trans')||{}).textContent"))
        print("   rifiuti 404:", log.get("ollama_404", []), "| modello salvato:", await sw.evaluate("chrome.storage.sync.get('models').then(r=>r.models.local)"), "| con /no_think:", len(log.get("ollama_nothink", [])))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

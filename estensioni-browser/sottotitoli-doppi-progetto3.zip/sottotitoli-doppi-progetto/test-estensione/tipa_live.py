import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it'}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsIpa"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("document.querySelectorAll('.dualsub-ipa .dualsub-ipaw').length>0", timeout=90000)
        print("trascrizione:", await pg.inner_text(".dualsub-orig"), "→", await pg.inner_text(".dualsub-ipa"))
        print("richieste IPA:", [(w, len(x)) for w, x in log.get("ipa", [])], "errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

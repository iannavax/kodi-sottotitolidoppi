# 5.9.2: limiti di Groq (richiesta troppo grande per i token al minuto) e di Gemini (quota del giorno) per la riga IPA
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def run(keys, env, note):
    log["ipa"] = []; log.pop("ipa413", None); log.pop("gem_ipa_daily", None)
    for k in ("GROQ_TPM", "GEM_IPA_DAILY"): os.environ.pop(k, None)
    os.environ.update(env)
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("(k) => chrome.storage.sync.set({engine:'google', targetLang:'it'}).then(()=>chrome.storage.local.set({keys:k}))", keys)
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=longIpa"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        ok = True
        try: await pg.wait_for_function("document.querySelectorAll('.dualsub-ipa .dualsub-ipaw:not(.dualsub-ipa-none)').length>2", timeout=40000)
        except Exception: ok = False
        print(note, "| IPA:", (await pg.inner_text(".dualsub-ipa"))[:80], "| richieste (servizio, parole):", [(w, len(x)) for w, x in log["ipa"]],
              "| 413 di Groq:", log.get("ipa413"), "| Gemini quota finita:", log.get("gem_ipa_daily"), "| ok:", ok, "| errori:", errs, log["errors"])
        await ctx.close()
async def main():
    await run({"groq": "gsk-test"}, {"GROQ_TPM": "1"}, "1. solo Groq, limite al minuto")
    await run({"gemini": "AIza", "groq": "gsk-test"}, {"GEM_IPA_DAILY": "1"}, "2. Gemini senza quota → Groq")
    await run({"gemini": "AIza", "groq": "gsk-test"}, {}, "3. normale (prima Gemini)")
asyncio.run(main())

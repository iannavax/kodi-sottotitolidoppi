// Lettore PDF di Parole al Volo: il lettore del browser non lascia entrare le estensioni, quindi i PDF si aprono qui
// (pdf.js di Mozilla). Ogni pagina è disegnata con sopra il suo testo vero (trasparente): la scheda passando il
// mouse, la selezione e la traduzione funzionano come sulle pagine web (volo.js è caricato in questa pagina).
// 1.17.0: un lettore completo, come quelli dei programmi per PDF: pagina n/N, zoom vero (anche con il pizzico del trackpad
// e Ctrl+rotella: il PDF si ridisegna nitido, non si ingrandisce la pagina del browser), adatta larghezza/pagina, ruota,
// cerca, miniature e indice, link interni, evidenziatore con note, stampa, salva, schermo intero, lettura notturna,
// scorciatoie da tastiera; pagina e zoom si ricordano per ogni PDF. I PDF del computer aperti dal gestore dei file
// (indirizzi file://) li legge il programma di appoggio, perché Firefox non lascia leggere i file alle estensioni.
import * as pdfjsLib from "./pdfjs/pdf.min.mjs";
import { PDF_ENC } from "./pdf-enc.js";
pdfjsLib.GlobalWorkerOptions.workerSrc = "./pdfjs/pdf.worker.min.mjs";

const $ = (id) => document.getElementById(id);
const viewer = $("viewer"), pagesEl = $("pages");
const params = new URLSearchParams(location.search);
const EXT = globalThis.DS_EXT || (globalThis.browser && browser.runtime ? browser : chrome);
const HELPER = "com.sottotitolidoppi.helper";
const isFirefox = /\bFirefox\//.test(navigator.userAgent);   // (anche Chrome ormai ha «browser»: conta il programma vero)
const ls = { get: (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : v; } catch { return d; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch {} } };

let doc = null, gen = 0, raw = null, docName = "", docKey = "";
let sizes = [];            // per pagina, a zoom 1 e rotazione del PDF: { w, h, rot }
let scale = 1, zoomMode = "width", rotation = 0;
let pageDivs = [], obs = null, curPage = 1;
const tcCache = new Map();  // pagina → testo già corretto (codifica e accenti)
// codifica del testo: "auto" (decido io guardando le prime pagine), "none" o una codifica di pdf-enc.js ("cp1250"…)
let encPref = ls.get("pavPdfEnc", "auto");

function message(html) { pagesEl.style.transform = ""; pagesEl.innerHTML = `<div class="msg">${html}</div>`; }
function toast(t, ms = 2600) { const el = $("toast"); el.textContent = t; el.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => { el.hidden = true; }, ms); }
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));

// ---------- Aprire ----------
async function openData(data, name) {
  const my = ++gen;
  raw = data.slice();   // (pdf.js si prende i dati: la copia serve per «Salva»)
  docName = name || "documento.pdf";
  $("name").textContent = docName; $("name").title = docName;
  document.title = docName + " — Parole al Volo";
  tcCache.clear(); findState.matches = []; findState.query = ""; $("findCount").textContent = "";
  message("Apro il PDF…");
  try {
    // tabelle dei caratteri e caratteri standard: senza, in alcuni PDF il testo esce con caratteri sbagliati
    doc = await pdfjsLib.getDocument({ data, isEvalSupported: false,
      cMapUrl: new URL("pdfjs/cmaps/", location.href).href, cMapPacked: true,
      standardFontDataUrl: new URL("pdfjs/standard_fonts/", location.href).href,
      // decodificatori delle immagini JBIG2 e JPEG 2000 (i libri scansionati, es. archive.org) e dei colori ICC:
      // senza, pdf.js lascia quelle pagine bianche
      wasmUrl: new URL("pdfjs/wasm/", location.href).href,
      iccUrl: new URL("pdfjs/iccs/", location.href).href }).promise;
  } catch (e) {
    if (my === gen) message(`<b>Non riesco ad aprire questo PDF.</b><br>${esc(e && e.message || e)}`);
    return;
  }
  if (my !== gen) return;
  docKey = (doc.fingerprints && doc.fingerprints[0]) || (docName + ":" + raw.length);
  sizes = [];
  for (let n = 1; n <= doc.numPages; n++) {
    const p = await doc.getPage(n);
    if (my !== gen) return;
    const vp = p.getViewport({ scale: 1 });
    sizes.push({ w: vp.width, h: vp.height, rot: p.rotate || 0 });
    if (n % 50 === 0) message(`Apro il PDF… ${n}/${doc.numPages} pagine`);
  }
  // dov'eri rimasto in questo PDF: pagina, zoom, rotazione
  let pos = {};
  try { pos = JSON.parse(ls.get("pavPdfPos:" + docKey, "{}")) || {}; } catch {}
  rotation = [0, 90, 180, 270].includes(pos.rot) ? pos.rot : 0;
  zoomMode = ["width", "page", "custom"].includes(pos.mode) ? pos.mode : ls.get("pavPdfMode", "width");
  scale = Number(pos.scale) || Number(ls.get("pavPdfScale", "1")) || 1;
  for (const id of ["saveBtn", "printBtn", "prevBtn", "nextBtn", "pageNum", "zoomOut", "zoomIn", "zoomSel", "rotateBtn", "find", "findPrev", "findNext", "hlBtn"]) $(id).disabled = false;
  $("pageCount").textContent = "/ " + doc.numPages;
  await chooseEncoding(my);
  if (my !== gen) return;
  hlLoad();
  layout();
  goTo(clamp(Number(pos.page) || 1, 1, doc.numPages), false);
  buildThumbs(); buildOutline(); renderHlList();
}

// ---------- Pagine e zoom ----------
// misure della pagina n con lo zoom e la rotazione di adesso
function pageSize(n, s = scale) {
  const z = sizes[n - 1]; if (!z) return { w: 0, h: 0 };
  return rotation % 180 ? { w: z.h * s, h: z.w * s } : { w: z.w * s, h: z.h * s };
}
function fitScale(mode) {
  const n = clamp(curPage, 1, sizes.length), one = pageSize(n, 1);
  const W = viewer.clientWidth - 48, H = viewer.clientHeight - 32;
  if (!one.w) return 1;
  return clamp(mode === "page" ? Math.min(W / one.w, H / one.h) : W / one.w, 0.1, 8);
}
// le pagine si preparano tutte con le misure giuste (si scorre bene), ma si disegnano solo quando arrivano sullo schermo
function layout() {
  if (!doc) return;
  if (zoomMode !== "custom") scale = fitScale(zoomMode);
  pagesEl.style.transform = "";
  pagesEl.textContent = "";
  if (obs) obs.disconnect();
  obs = new IntersectionObserver((entries) => {
    for (const en of entries) if (en.isIntersecting) drawPage(en.target).catch((e) => console.error("Parole al Volo, pagina del PDF:", e));
  }, { root: viewer, rootMargin: "700px 0px" });
  pageDivs = [];
  const lg = ++layoutGen;
  for (let n = 1; n <= doc.numPages; n++) {
    const { w, h } = pageSize(n);
    const div = document.createElement("div");
    div.className = "page";
    div.dataset.n = n; div.dataset.lg = lg;
    div.style.width = Math.floor(w) + "px";
    div.style.height = Math.floor(h) + "px";
    div.style.setProperty("--scale-factor", String(scale));
    div.style.setProperty("--total-scale-factor", String(scale));
    div.style.setProperty("--user-unit", "1");
    const num = document.createElement("span"); num.className = "num"; num.textContent = n;
    div.append(num);
    drawHls(div, n);
    pagesEl.append(div);
    pageDivs.push(div);
    obs.observe(div);
  }
  showZoom();
}
let layoutGen = 0;

async function drawPage(div) {
  if (div.dataset.drawn) return;
  div.dataset.drawn = "1";
  const n = Number(div.dataset.n), lg = div.dataset.lg;
  const page = await doc.getPage(n);
  const vp = page.getViewport({ scale, rotation: ((page.rotate || 0) + rotation) % 360 });
  // nitido sugli schermi ad alta densità, ma senza tele enormi (a zoom molto alti la memoria finisce)
  let ratio = window.devicePixelRatio || 1;
  const MAX = 24e6;
  if (vp.width * vp.height * ratio * ratio > MAX) ratio = Math.sqrt(MAX / (vp.width * vp.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.floor(vp.width * ratio);
  canvas.height = Math.floor(vp.height * ratio);
  div.prepend(canvas);
  await page.render({ canvas, canvasContext: canvas.getContext("2d"), viewport: vp, transform: ratio !== 1 ? [ratio, 0, 0, ratio, 0, 0] : null }).promise;
  if (div.dataset.lg !== lg || !div.isConnected) return;
  const tl = document.createElement("div");
  tl.className = "textLayer";
  div.append(tl);
  const tc = await textContent(n);
  if (!div.isConnected) return;
  await new pdfjsLib.TextLayer({ textContentSource: tc, container: tl, viewport: vp }).render();
  drawLinks(div, page, vp).catch((e) => console.error("Parole al Volo, link del PDF:", e));
  if (findState.cur >= 0 && findState.matches[findState.cur] && findState.matches[findState.cur].n === n) markFound(false);
}
async function textContent(n) {
  if (tcCache.has(n)) return tcCache.get(n);
  const tc = await (await doc.getPage(n)).getTextContent();
  fixAccents(tc.items);
  tcCache.set(n, tc);
  return tc;
}

// link del PDF: indirizzi (si aprono in una scheda nuova) e rimandi interni (indice, note, «vedi pagina…»)
async function drawLinks(div, page, vp) {
  const anns = await page.getAnnotations({ intent: "display" });
  const box = document.createElement("div"); box.className = "links";
  for (const a of anns) {
    if (a.subtype !== "Link" || !a.rect) continue;
    // (i due angoli del rettangolo, dalle coordinate del PDF a quelle della pagina disegnata, con lo zoom e la rotazione)
    const [x1, y1] = vp.convertToViewportPoint(a.rect[0], a.rect[1]), [x2, y2] = vp.convertToViewportPoint(a.rect[2], a.rect[3]);
    const el = document.createElement("a");
    el.style.cssText = `left:${Math.min(x1, x2)}px;top:${Math.min(y1, y2)}px;width:${Math.abs(x2 - x1)}px;height:${Math.abs(y2 - y1)}px`;
    if (a.url) { el.href = a.url; el.target = "_blank"; el.rel = "noopener noreferrer"; el.title = a.url; }
    else if (a.dest) { el.href = "#"; el.addEventListener("click", async (e) => { e.preventDefault(); const p = await destPage(a.dest); if (p) goTo(p); }); }
    else continue;
    box.append(el);
  }
  if (box.childElementCount) div.append(box);
}
async function destPage(dest) {
  try {
    if (typeof dest === "string") dest = await doc.getDestination(dest);
    if (!Array.isArray(dest)) return 0;
    const ref = dest[0];
    return (typeof ref === "object" && ref ? await doc.getPageIndex(ref) : Number(ref)) + 1;
  } catch { return 0; }
}

function showZoom() {
  const sel = $("zoomSel"), pct = Math.round(scale * 100) + "%";
  const fixed = [...sel.options].find((o) => zoomMode === "custom" && Number(o.value) && Math.abs(Number(o.value) - scale) < 0.005);
  const custom = sel.querySelector('option[value="custom"]');
  if (zoomMode !== "custom") { sel.value = zoomMode; custom.hidden = true; sel.options[sel.selectedIndex].textContent = (zoomMode === "width" ? "Adatta larghezza" : "Adatta pagina") + " · " + pct; }
  else if (fixed) { sel.value = fixed.value; custom.hidden = true; }
  else { custom.textContent = pct; custom.hidden = false; sel.value = "custom"; }
  for (const o of sel.options) if (o.value === "width" && zoomMode !== "width") o.textContent = "Adatta larghezza"; else if (o.value === "page" && zoomMode !== "page") o.textContent = "Adatta pagina";
}

// punto sotto (ax, ay) nel visore: pagina e posizione in proporzione, per tenerlo fermo mentre lo zoom cambia
function anchorAt(ax, ay) {
  const vr = viewer.getBoundingClientRect();
  for (const d of pageDivs) {
    const r = d.getBoundingClientRect();
    if (vr.top + ay < r.bottom + 7) return { n: Number(d.dataset.n), fx: (vr.left + ax - r.left) / r.width, fy: (vr.top + ay - r.top) / r.height, ax, ay };
  }
  return null;
}
function restoreAnchor(a) {
  if (!a) return;
  const d = pageDivs[a.n - 1]; if (!d) return;
  const vr = viewer.getBoundingClientRect(), r = d.getBoundingClientRect();
  viewer.scrollTop += (r.top + a.fy * r.height) - (vr.top + a.ay);
  viewer.scrollLeft += (r.left + a.fx * r.width) - (vr.left + a.ax);
}
function setZoom(newScale, mode, ax = viewer.clientWidth / 2, ay = viewer.clientHeight / 3) {
  if (!doc) return;
  const a = anchorAt(ax, ay);
  zoomMode = mode || "custom";
  if (zoomMode === "custom") scale = clamp(Math.round(newScale * 1000) / 1000, 0.1, 8);
  layout();
  restoreAnchor(a);
  if (zoomMode === "custom") ls.set("pavPdfScale", String(scale));
  ls.set("pavPdfMode", zoomMode);
  savePos();
}
const STEPS = [0.25, 0.33, 0.5, 0.67, 0.75, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5, 6, 8];
function zoomStep(dir) {
  const next = dir > 0 ? STEPS.find((s) => s > scale + 0.001) : [...STEPS].reverse().find((s) => s < scale - 0.001);
  setZoom(next || scale, "custom");
}

// pizzico sul trackpad e Ctrl+rotella: arrivano come rotella con Ctrl. Il browser ingrandirebbe tutta la pagina (sgranata):
// lo blocco, ingrandisco subito l'immagine che c'è (anteprima) e appena ti fermi ridisegno il PDF a quello zoom, nitido
let pinch = null;
viewer.addEventListener("wheel", (e) => {
  if (!e.ctrlKey || !doc) return;
  e.preventDefault();
  const vr = viewer.getBoundingClientRect();
  const ax = e.clientX - vr.left, ay = e.clientY - vr.top;
  if (!pinch) {
    const pr = pagesEl.getBoundingClientRect();
    pinch = { f: 1, ax, ay, ox: e.clientX - pr.left, oy: e.clientY - pr.top };
    pagesEl.style.transformOrigin = `${pinch.ox}px ${pinch.oy}px`;
  }
  const dy = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
  pinch.f = clamp(pinch.f * Math.exp(-clamp(dy, -40, 40) / 200), 0.1 / scale, 8 / scale);
  pagesEl.style.transform = `scale(${pinch.f})`;
  clearTimeout(pinch.t);
  pinch.t = setTimeout(() => {
    const p = pinch; pinch = null;
    pagesEl.style.transform = ""; pagesEl.style.transformOrigin = "0 0";
    setZoom(scale * p.f, "custom", p.ax, p.ay);
  }, 220);
}, { passive: false });
// (Safari: i gesti di pizzico hanno eventi a parte, che ingrandirebbero la pagina)
for (const t of ["gesturestart", "gesturechange"]) document.addEventListener(t, (e) => e.preventDefault(), { passive: false });

// ---------- Navigazione ----------
function goTo(n, smooth = true) {
  n = clamp(Math.round(n) || 1, 1, pageDivs.length || 1);
  const d = pageDivs[n - 1]; if (!d) return;
  const vr = viewer.getBoundingClientRect(), r = d.getBoundingClientRect();
  viewer.scrollTo({ top: viewer.scrollTop + r.top - vr.top - 8, behavior: smooth ? "smooth" : "auto" });
  setCur(n);
}
function setCur(n) {
  if (n === curPage && $("pageNum").value === String(n)) return;
  curPage = n;
  if (document.activeElement !== $("pageNum")) $("pageNum").value = n;
  $("prevBtn").disabled = n <= 1; $("nextBtn").disabled = n >= pageDivs.length;
  for (const t of document.querySelectorAll(".thumb.cur")) t.classList.remove("cur");
  const t = document.querySelector(`.thumb[data-n="${n}"]`);
  if (t) { t.classList.add("cur"); if ($("thumbs").classList.contains("on") && document.body.classList.contains("side-open")) t.scrollIntoView({ block: "nearest" }); }
  savePos();
}
let scrollRaf = 0;
viewer.addEventListener("scroll", () => {
  if (scrollRaf) return;
  scrollRaf = requestAnimationFrame(() => {
    scrollRaf = 0;
    const vr = viewer.getBoundingClientRect(), mid = vr.top + vr.height * 0.35;
    for (const d of pageDivs) { const r = d.getBoundingClientRect(); if (r.bottom >= mid) { setCur(Number(d.dataset.n)); break; } }
  });
}, { passive: true });
let posTimer = 0;
function savePos() {
  if (!docKey) return;
  clearTimeout(posTimer);
  posTimer = setTimeout(() => ls.set("pavPdfPos:" + docKey, JSON.stringify({ page: curPage, mode: zoomMode, scale, rot: rotation })), 400);
}
window.addEventListener("resize", () => { if (doc && zoomMode !== "custom") { clearTimeout(window.__rz); window.__rz = setTimeout(() => setZoom(scale, zoomMode), 150); } });

// ---------- Pannello: miniature, indice, evidenziazioni ----------
function sideOpen(on) {
  document.body.classList.toggle("side-open", on);
  $("sideBtn").classList.toggle("on", on);
  ls.set("pavPdfSide", on ? "1" : "0");
  if (doc && zoomMode !== "custom") setTimeout(() => setZoom(scale, zoomMode), 170);
}
for (const b of document.querySelectorAll("#side .tabs button")) b.addEventListener("click", () => {
  for (const x of document.querySelectorAll("#side .tabs button")) x.classList.toggle("on", x === b);
  for (const p of document.querySelectorAll("#side .pane")) p.classList.toggle("on", p.id === b.dataset.pane);
});
let thumbObs = null;
function buildThumbs() {
  const box = $("thumbs"); box.textContent = "";
  if (thumbObs) thumbObs.disconnect();
  const my = gen;
  thumbObs = new IntersectionObserver((entries) => {
    for (const en of entries) if (en.isIntersecting) { thumbObs.unobserve(en.target); drawThumb(en.target, my).catch(() => {}); }
  }, { root: box, rootMargin: "300px 0px" });
  for (let n = 1; n <= doc.numPages; n++) {
    const { w, h } = pageSize(n, 1), W = 150, H = Math.round(W * h / w);
    const t = document.createElement("div"); t.className = "thumb" + (n === curPage ? " cur" : ""); t.dataset.n = n;
    const b = document.createElement("div"); b.className = "box"; b.style.width = W + "px"; b.style.height = H + "px";
    t.append(b, document.createTextNode(String(n)));
    t.addEventListener("click", () => goTo(n));
    box.append(t);
    thumbObs.observe(t);
  }
}
async function drawThumb(t, my) {
  const n = Number(t.dataset.n), page = await doc.getPage(n);
  if (my !== gen) return;
  const base = page.getViewport({ scale: 1, rotation: ((page.rotate || 0) + rotation) % 360 });
  const vp = page.getViewport({ scale: 150 / base.width * (window.devicePixelRatio || 1), rotation: ((page.rotate || 0) + rotation) % 360 });
  const c = document.createElement("canvas"); c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
  await page.render({ canvas: c, canvasContext: c.getContext("2d"), viewport: vp }).promise;
  if (my === gen) t.querySelector(".box").replaceChildren(c);
}
async function buildOutline() {
  const box = $("outline");
  let ol = null;
  try { ol = await doc.getOutline(); } catch {}
  if (!ol || !ol.length) { box.innerHTML = '<div class="empty">Questo PDF non ha un indice.</div>'; return; }
  const mk = (items) => {
    const ul = document.createElement("ul");
    for (const it of items) {
      const li = document.createElement("li"), sp = document.createElement("span");
      sp.textContent = it.title || "(senza titolo)";
      if (it.bold) sp.style.fontWeight = "700";
      if (it.italic) sp.style.fontStyle = "italic";
      sp.addEventListener("click", async () => {
        if (it.url) { window.open(it.url, "_blank", "noopener"); return; }
        const p = await destPage(it.dest);
        if (p) goTo(p);
      });
      li.append(sp);
      if (it.items && it.items.length) li.append(mk(it.items));
      ul.append(li);
    }
    return ul;
  };
  const root = mk(ol); root.className = "outline";
  box.replaceChildren(root);
}

// ---------- Cerca ----------
// senza maiuscole né accenti, lettera per lettera (stessa lunghezza del testo: le posizioni restano giuste)
function fold(s) {
  let o = "";
  for (let i = 0; i < s.length; i++) {
    const c = s[i], code = c.charCodeAt(0);
    if (code >= 0xD800 && code <= 0xDFFF) { o += c; continue; }
    if (/\s/.test(c)) { o += " "; continue; }
    const d = c.normalize("NFD")[0] || c;
    const l = d.toLowerCase();
    o += l.length === 1 ? l : d;
  }
  return o;
}
const findState = { query: "", matches: [], cur: -1, job: 0 };
async function findRun(dir) {
  const q = fold($("find").value.trim().replace(/\s+/g, " "));
  if (!doc || !q) { findState.matches = []; findState.cur = -1; $("findCount").textContent = ""; clearFound(); return; }
  if (q !== findState.query) {
    const my = ++findState.job;
    findState.query = q; findState.matches = []; findState.cur = -1;
    for (let n = 1; n <= doc.numPages; n++) {
      if (n % 20 === 0) $("findCount").textContent = `cerco… ${n}/${doc.numPages}`;
      const tc = await textContent(n);
      if (my !== findState.job) return;
      const t = fold(tc.items.map((it) => (it.str || "") + (it.hasEOL ? "\n" : "")).join(""));
      let k = 0;
      for (let i = t.indexOf(q); i >= 0; i = t.indexOf(q, i + 1)) findState.matches.push({ n, k: k++ });
    }
    // dal primo risultato da qui in poi
    const from = findState.matches.findIndex((m) => m.n >= curPage);
    findState.cur = from >= 0 ? from : 0;
  } else if (findState.matches.length) {
    findState.cur = (findState.cur + dir + findState.matches.length) % findState.matches.length;
  }
  if (!findState.matches.length) { $("findCount").textContent = "nessun risultato"; clearFound(); return; }
  $("findCount").textContent = `${findState.cur + 1} di ${findState.matches.length}`;
  const m = findState.matches[findState.cur];
  goTo(m.n, false);
  markFound(true);
}
function clearFound() { for (const f of document.querySelectorAll(".found")) f.remove(); }
// il risultato di adesso, segnato sul testo della pagina (quando la pagina è disegnata)
function markFound(scroll) {
  clearFound();
  const m = findState.matches[findState.cur]; if (!m) return;
  const div = pageDivs[m.n - 1], tl = div && div.querySelector(".textLayer");
  if (!tl) { if (div) drawPage(div); return; }   // (drawPage la segna quando ha finito)
  const nodes = [];
  let text = "";
  const walk = document.createTreeWalker(tl, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
  for (let x = walk.nextNode(); x; x = walk.nextNode()) {
    if (x.nodeType === 3) { nodes.push({ node: x, start: text.length }); text += x.nodeValue; }
    else if (x.nodeName === "BR") text += "\n";
  }
  const f = fold(text), q = findState.query;
  let at = -1;
  for (let i = f.indexOf(q), k = 0; i >= 0; i = f.indexOf(q, i + 1), k++) if (k === m.k) { at = i; break; }
  if (at < 0) return;
  const locate = (pos) => { for (let j = nodes.length - 1; j >= 0; j--) if (nodes[j].start <= pos) return [nodes[j].node, Math.min(pos - nodes[j].start, nodes[j].node.nodeValue.length)]; return null; };
  const s = locate(at), e = locate(at + q.length);
  if (!s || !e) return;
  const range = document.createRange();
  range.setStart(s[0], s[1]); range.setEnd(e[0], e[1]);
  const pr = div.getBoundingClientRect();
  let first = null;
  for (const r of range.getClientRects()) {
    if (r.width < 1 || r.height < 1) continue;
    const box = document.createElement("div"); box.className = "found";
    box.style.cssText = `left:${(r.left - pr.left) / pr.width * 100}%;top:${(r.top - pr.top) / pr.height * 100}%;width:${r.width / pr.width * 100}%;height:${r.height / pr.height * 100}%`;
    div.append(box);
    if (!first) first = r;
  }
  if (scroll && first) {
    const vr = viewer.getBoundingClientRect();
    if (first.top < vr.top + 20 || first.bottom > vr.bottom - 20) viewer.scrollTop += first.top - vr.top - vr.height / 3;
  }
}

// ---------- Evidenziatore ----------
// ogni evidenziazione: pagina, rettangoli in proporzione alla pagina (valgono a ogni zoom), testo, colore, nota
const HL_COLORS = ["#ffe066", "#a6f0a6", "#9fd3ff", "#ffb3d1", "#ffb870"];
let hls = [];
function hlLoad() { try { hls = JSON.parse(ls.get("pavPdfHl:" + docKey, "[]")) || []; } catch { hls = []; } }
function hlSave() { ls.set("pavPdfHl:" + docKey, JSON.stringify(hls)); renderHlList(); }
function drawHls(div, n) {
  for (const x of div.querySelectorAll(".hl")) x.remove();
  for (const h of hls) {
    if (h.n !== n) continue;
    for (const [x, y, w, hh] of h.rects) {
      const el = document.createElement("div");
      el.className = "hl" + (h.note ? " note" : "");
      el.dataset.id = h.id;
      el.title = h.note ? "Nota: " + h.note : "Clic: nota, colore o togli";
      el.style.cssText = `left:${x * 100}%;top:${y * 100}%;width:${w * 100}%;height:${hh * 100}%;background:${h.color}`;
      el.addEventListener("click", (e) => { e.stopPropagation(); hlMenu(h.id, e.clientX, e.clientY); });
      div.append(el);
    }
  }
}
function hlAdd() {
  const sel = window.getSelection();
  if (!doc || !sel || !sel.rangeCount || sel.isCollapsed) { toast("Seleziona prima il testo da evidenziare, poi premi 🖍 (o H)."); return; }
  const range = sel.getRangeAt(0), text = sel.toString().trim();
  const rects = [...range.getClientRects()].filter((r) => r.width >= 1 && r.height >= 1);
  const group = Date.now().toString(36);
  let added = 0;
  for (const div of pageDivs) {
    if (!range.intersectsNode(div)) continue;
    const pr = div.getBoundingClientRect(), mine = [];
    for (const r of rects) {
      if (r.bottom <= pr.top || r.top >= pr.bottom || r.right <= pr.left || r.left >= pr.right) continue;
      const box = [(r.left - pr.left) / pr.width, (r.top - pr.top) / pr.height, r.width / pr.width, r.height / pr.height].map((v) => Math.round(v * 10000) / 10000);
      if (!mine.some((m) => Math.abs(m[0] - box[0]) < 0.002 && Math.abs(m[1] - box[1]) < 0.002)) mine.push(box);
    }
    if (!mine.length) continue;
    const n = Number(div.dataset.n);
    hls.push({ id: group + "-" + n, n, rects: mine, text: text.slice(0, 1000), color: HL_COLORS[0], note: "", rot: rotation, at: Date.now() });
    drawHls(div, n);
    added++;
  }
  if (!added) { toast("Seleziona il testo dentro le pagine del PDF."); return; }
  sel.removeAllRanges();
  hlSave();
  toast("Evidenziato. Clic sull'evidenziazione per aggiungere una nota o cambiare colore.");
}
function hlMenu(id, x, y) {
  const h = hls.find((v) => v.id === id); if (!h) return;
  const m = $("hlMenu"); m.textContent = "";
  for (const c of HL_COLORS) {
    const b = document.createElement("button"); b.className = "sw"; b.style.background = c; b.title = "Colore";
    b.addEventListener("click", () => { h.color = c; hlSave(); drawHls(pageDivs[h.n - 1], h.n); m.hidden = true; });
    m.append(b);
  }
  const note = document.createElement("button"); note.className = "tb"; note.textContent = h.note ? "🗒 Modifica nota" : "🗒 Nota";
  note.addEventListener("click", () => {
    const t = prompt("Nota per questa evidenziazione:", h.note || "");
    if (t !== null) { h.note = t.trim(); hlSave(); drawHls(pageDivs[h.n - 1], h.n); }
    m.hidden = true;
  });
  const del = document.createElement("button"); del.className = "tb"; del.textContent = "🗑"; del.title = "Togli l'evidenziazione";
  del.addEventListener("click", () => { hls = hls.filter((v) => v.id !== id); hlSave(); drawHls(pageDivs[h.n - 1], h.n); m.hidden = true; });
  m.append(note, del);
  m.hidden = false;
  m.style.left = Math.min(x, window.innerWidth - 300) + "px";
  m.style.top = Math.min(y + 12, window.innerHeight - 60) + "px";
}
document.addEventListener("click", (e) => { if (!$("hlMenu").hidden && !e.target.closest("#hlMenu")) $("hlMenu").hidden = true; });
function renderHlList() {
  const box = $("hls");
  if (!hls.length) { box.innerHTML = '<div class="empty">Nessuna evidenziazione. Seleziona del testo e premi 🖍 (o H). Restano salvate in questo browser per questo PDF.</div>'; return; }
  box.textContent = "";
  for (const h of [...hls].sort((a, b) => a.n - b.n || a.rects[0][1] - b.rects[0][1])) {
    const it = document.createElement("div"); it.className = "hlitem"; it.style.setProperty("--hl", h.color);
    it.innerHTML = `<div class="p">Pagina ${h.n}</div><div class="t"></div>` + (h.note ? '<div class="n"></div>' : "");
    it.querySelector(".t").textContent = h.text || "(senza testo)";
    if (h.note) it.querySelector(".n").textContent = h.note;
    it.addEventListener("click", () => goTo(h.n));
    box.append(it);
  }
}
$("hlBtn").addEventListener("mousedown", (e) => e.preventDefault());   // (il clic non deve togliere la selezione)
$("hlBtn").addEventListener("click", hlAdd);

// ---------- Stampa e salva ----------
async function printDoc() {
  if (!doc) return;
  const area = $("printArea"); area.textContent = "";
  const urls = [];
  for (let n = 1; n <= doc.numPages; n++) {
    toast(`Preparo la stampa… ${n}/${doc.numPages}`, 60000);
    const page = await doc.getPage(n);
    const vp = page.getViewport({ scale: 2, rotation: ((page.rotate || 0) + rotation) % 360 });
    const c = document.createElement("canvas"); c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
    await page.render({ canvas: c, canvasContext: c.getContext("2d"), viewport: vp }).promise;
    const blob = await new Promise((ok) => c.toBlob(ok, "image/jpeg", 0.92));
    const u = URL.createObjectURL(blob); urls.push(u);
    const img = document.createElement("img"); img.src = u; area.append(img);
  }
  await Promise.all([...area.querySelectorAll("img")].map((i) => i.decode().catch(() => {})));
  $("toast").hidden = true;
  const done = () => { area.textContent = ""; for (const u of urls) URL.revokeObjectURL(u); window.removeEventListener("afterprint", done); };
  window.addEventListener("afterprint", done);
  window.print();
}
function saveDoc() {
  if (!raw) return;
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([raw], { type: "application/pdf" }));
  a.download = /\.pdf$/i.test(docName) ? docName : docName + ".pdf";
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 10000);
}

// ---------- Comandi della barra e tastiera ----------
$("sideBtn").addEventListener("click", () => sideOpen(!document.body.classList.contains("side-open")));
$("saveBtn").addEventListener("click", saveDoc);
$("printBtn").addEventListener("click", printDoc);
$("prevBtn").addEventListener("click", () => goTo(curPage - 1));
$("nextBtn").addEventListener("click", () => goTo(curPage + 1));
$("pageNum").addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") { goTo(Number($("pageNum").value)); $("pageNum").blur(); } });
$("pageNum").addEventListener("blur", () => { $("pageNum").value = curPage; });
$("zoomIn").addEventListener("click", () => zoomStep(1));
$("zoomOut").addEventListener("click", () => zoomStep(-1));
$("zoomSel").addEventListener("change", () => {
  const v = $("zoomSel").value;
  if (v === "width" || v === "page") setZoom(scale, v);
  else if (v !== "custom") setZoom(Number(v), "custom");
});
$("rotateBtn").addEventListener("click", () => {
  const a = anchorAt(viewer.clientWidth / 2, viewer.clientHeight / 3);
  rotation = (rotation + 90) % 360;
  layout(); buildThumbs();
  if (a) goTo(a.n, false);
  savePos();
});
let findTimer = 0;
$("find").addEventListener("input", () => { clearTimeout(findTimer); findTimer = setTimeout(() => findRun(1), 350); });
$("find").addEventListener("keydown", (e) => {
  e.stopPropagation();
  if (e.key === "Enter") { e.preventDefault(); clearTimeout(findTimer); findRun(e.shiftKey ? -1 : 1); }
  if (e.key === "Escape") { $("find").value = ""; findRun(1); $("find").blur(); }
});
$("findNext").addEventListener("click", () => findRun(1));
$("findPrev").addEventListener("click", () => findRun(-1));
$("nightBtn").addEventListener("click", () => { const on = !document.body.classList.contains("night"); document.body.classList.toggle("night", on); $("nightBtn").classList.toggle("on", on); ls.set("pavPdfNight", on ? "1" : "0"); });
$("fullBtn").addEventListener("click", () => { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen().catch(() => {}); });
document.addEventListener("fullscreenchange", () => { $("fullBtn").classList.toggle("on", !!document.fullscreenElement); if (doc && zoomMode !== "custom") setTimeout(() => setZoom(scale, zoomMode), 120); });
document.addEventListener("keydown", (e) => {
  const inField = e.target.closest && e.target.closest("input, select, textarea, [contenteditable]");
  const mod = e.ctrlKey || e.metaKey;
  if (mod && !e.altKey) {
    const k = e.key.toLowerCase();
    if (k === "f") { e.preventDefault(); $("find").focus(); $("find").select(); return; }
    if (k === "o") { e.preventDefault(); $("file").click(); return; }
    if (!doc) return;
    if (k === "p") { e.preventDefault(); printDoc(); return; }
    if (k === "s") { e.preventDefault(); saveDoc(); return; }
    if (k === "+" || k === "=") { e.preventDefault(); zoomStep(1); return; }
    if (k === "-") { e.preventDefault(); zoomStep(-1); return; }
    if (k === "0") { e.preventDefault(); setZoom(scale, "width"); return; }
    return;
  }
  if (inField || e.altKey || !doc) return;
  if (e.key === "ArrowLeft") { e.preventDefault(); goTo(curPage - 1); }
  else if (e.key === "ArrowRight") { e.preventDefault(); goTo(curPage + 1); }
  else if (e.key === "Home") { e.preventDefault(); goTo(1); }
  else if (e.key === "End") { e.preventDefault(); goTo(doc.numPages); }
  else if (e.key === "F4") { e.preventDefault(); sideOpen(!document.body.classList.contains("side-open")); }
  else if (e.key === "h" || e.key === "H") { if (window.getSelection() && !window.getSelection().isCollapsed) { e.preventDefault(); hlAdd(); } }
  else if (e.key === "r" || e.key === "R") { e.preventDefault(); $("rotateBtn").click(); }
  else if (e.key === "Escape") $("hlMenu").hidden = true;
});
if (ls.get("pavPdfNight", "0") === "1") { document.body.classList.add("night"); $("nightBtn").classList.add("on"); }
sideOpen(ls.get("pavPdfSide", window.innerWidth > 1000 ? "1" : "0") === "1");

// ---------- Codifica del testo e accenti staccati (come prima) ----------
// Accenti staccati. Molti PDF (soprattutto quelli fatti con LaTeX) scrivono "č" come due caratteri: "ˇ" e "c"
// (spesso l'accento prima della lettera, a volte perfino in un pezzo di testo diverso). A vedersi è giusto, ma il
// testo è "ˇcesk´y" e la traduzione non lo capisce. Riunisco l'accento alla lettera, solo quando insieme formano
// davvero una lettera accentata (č, ý, ů, ž, ő, ç…), così il testo normale non cambia.
const MARKS = { "\u02C7": "\u030C", "\u00B4": "\u0301", "\u02DA": "\u030A", "\u00A8": "\u0308", "\u02DD": "\u030B", "\u02D8": "\u0306",
  "\u00B8": "\u0327", "\u02DB": "\u0328", "\u02D9": "\u0307", "\u0060": "\u0300", "\u02C6": "\u0302", "\u02DC": "\u0303" };
const MARK_RE = new RegExp("[" + Object.keys(MARKS).join("") + "]");
const isLetter = (c) => !!c && /\p{L}/u.test(c);
const compose = (letter, mark) => { const x = (letter + MARKS[mark]).normalize("NFC"); return x.length === 1 ? x : null; };
function fixString(str) {
  if (!MARK_RE.test(str)) return str.normalize("NFC");
  const a = Array.from(str);
  const out = [];
  for (let i = 0; i < a.length; i++) {
    const c = a[i];
    if (MARKS[c]) {
      // prima la lettera dopo (ordine di LaTeX), poi quella prima se la parola finisce qui
      const n = a[i + 1], prev = out[out.length - 1];
      if (isLetter(n) && compose(n, c)) { out.push(compose(n, c)); i++; continue; }
      if (isLetter(prev) && !isLetter(n) && compose(prev, c)) { out[out.length - 1] = compose(prev, c); continue; }
    }
    out.push(c);
  }
  return out.join("").normalize("NFC");
}
// ---------- Testo dei PDF in una codifica letta con un'altra ----------
// Molti PDF un po' vecchi hanno il testo in una codifica (ceco in Windows-1250, russo in Windows-1251 o KOI8,
// greco, turco…) ma il carattere dice un'altra cosa (WinAnsi, MacRoman, la codifica standard di Adobe): pdf.js
// allora mostra "Pøíliš" o "P¯ÌliöÌ" invece di "Příliš", "Ïðèâåò" invece di "Привет", "Ã©" invece di "é" (UTF-8).
// Riporto ogni carattere al suo byte e lo rileggo con la codifica giusta. Quale? Provo tutte le coppie
// (lettura sbagliata → codifica giusta), tengo quelle che rendono il testo più "da parola vera" e chiedo al
// riconoscimento della lingua del browser se ne esce davvero una lingua che usa quella codifica. Si decide carattere
// per carattere (font): lo stesso PDF può avere i titoli giusti e il testo sbagliato.
const SRC = {};
for (const [k, t] of Object.entries(PDF_ENC.sources)) {
  const m = new Map();
  Array.from(t).forEach((c, i) => { if (c !== "�" && !m.has(c)) m.set(c, 0x80 + i); });
  SRC[k] = m;
}
const TGT = {};
for (const [k, v] of Object.entries(PDF_ENC.targets)) TGT[k] = { ...v, chars: Array.from(v.table) };
for (const [k, v] of Object.entries(PDF_ENC.multi)) {
  try { TGT[k] = { ...v, dec: new TextDecoder(k) }; } catch { /* codifica che questo browser non conosce */ }
}
const MODES = [];
for (const src of Object.keys(SRC)) for (const tgt of Object.keys(TGT)) if (src !== tgt) MODES.push(src + ":" + tgt);
// i vecchi nomi della scelta a mano
const OLD_PREF = { "1250": "cp1250", "88592": "iso8859_2", "mac1250": "cp1250" };
// byte che pdf.js non sa mostrare e cambia: quelli che WinAnsi non usa diventano "•", il trattino morbido (0xAD) "-".
// Vicino a una lettera sono quasi sempre una lettera della codifica vera: provo i byte possibili e tengo il migliore.
const AMBIG = { "•": [0x95, 0x9D, 0x81, 0x8D, 0x8F, 0x90], "-": [0x2D, 0xAD] };
function decodeBytes(bytes, orig, tgt) {
  const t = TGT[tgt];
  const one = (bs) => {
    if (t.dec) return t.dec.decode(Uint8Array.from(bs));   // i byte sbagliati diventano "�" (plaus li punisce)
    let out = "";
    for (let i = 0; i < bs.length; i++) { const b = bs[i]; const c = b < 0x80 ? String.fromCharCode(b) : t.chars[b - 0x80]; out += c === "�" ? orig[i] : c; }
    return out;
  };
  const pick = bytes.map((b) => (Array.isArray(b) ? b[0] : b));
  for (let i = 0; i < bytes.length; i++) {
    if (!Array.isArray(bytes[i])) continue;
    let best = null, bestScore = -Infinity;
    for (const x of bytes[i]) {
      pick[i] = x;
      const d = one(pick);
      const sc = plaus(d) + 1.5 * count(d, /\p{L}/gu);   // a parità, meglio una lettera che un simbolo
      if (sc > bestScore) { best = x; bestScore = sc; }
    }
    pick[i] = best;
  }
  const d = one(pick);
  return t.dec && d.includes("�") ? orig.join("") : d;
}
function recode(str, mode) {
  if (!mode || mode === "none") return str;
  const [src, tgt] = mode.split(":");
  const map = SRC[src];
  if (!map || !TGT[tgt]) return str;
  const chars = Array.from(str);
  let out = "", bytes = [], orig = [];
  const flush = () => { if (bytes.length) out += decodeBytes(bytes, orig, tgt); bytes = []; orig = []; };
  const isL = (c) => !!c && /\p{L}/u.test(c);
  for (let i = 0; i < chars.length; i++) {
    const c = chars[i], code = c.codePointAt(0);
    let b = code < 0x80 ? code : map.get(c);
    if (b == null && code >= 0x80 && code < 0xA0) b = code;   // caratteri di controllo: il byte è quello
    const prev = chars[i - 1], next = chars[i + 1];
    if (AMBIG[c] && (c === "-" ? isL(prev) && (isL(next) || prev > "\u007F") : isL(prev) || isL(next))) b = AMBIG[c];
    // parola per parola: un pezzo che non si decodifica resta com'era senza rovinare il resto
    if (b == null || /\s/.test(c)) { flush(); out += c; continue; }
    bytes.push(b); orig.push(c);
  }
  flush();
  return out;
}
const count = (t, re) => (t.match(re) || []).length;
const CE_LETTERS = /[čřěůňďťľĺŕąęłńśźżőűăşţČŘĚŮŇĎŤĽĹŔĄĘŁŃŚŹŻŐŰĂŞŢ]/gu;
const SCRIPTS = [["L", /\p{Script=Latin}/u], ["C", /\p{Script=Cyrillic}/u], ["G", /\p{Script=Greek}/u], ["H", /\p{Script=Hebrew}/u],
  ["A", /\p{Script=Arabic}/u], ["T", /\p{Script=Thai}/u], ["J", /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u], ["K", /\p{Script=Hangul}/u]];
const scriptOf = (c) => { for (const [k, re] of SCRIPTS) if (re.test(c)) return k; return "O"; };
// quanto sembra testo vero: parole di un solo alfabeto, poche lettere strane, niente maiuscole o simboli in mezzo
function plaus(t) {
  let s = 0;
  for (const w of t.match(/[\p{L}\p{M}]+/gu) || []) {
    const letters = Array.from(w).filter((c) => /\p{L}/u.test(c));
    if (!letters.length) continue;
    const scripts = new Set(letters.map(scriptOf));
    if (scripts.size > 1) { s -= 3; continue; }
    const sc = scripts.values().next().value;
    if (sc === "L") {
      const non = letters.filter((c) => c > "\u007F").length;
      if (letters.length >= 4 && non / letters.length > 0.6) s -= 2;
      else s += non ? 1 : 0;
      s += 0.5 * count(w, CE_LETTERS);
    } else s += sc === "O" ? -1 : 1;
    // maiuscole e minuscole mescolate a caso ("íÏÒÏÚ", "ŪŌŕ"): una parola vera è tutta minuscola, tutta maiuscola
    // o con la prima maiuscola
    if (/\p{Ll}\p{Lu}/u.test(w) || (letters.length > 2 && /\p{Lu}/u.test(letters.slice(1).join("")) && /\p{Ll}/u.test(letters.slice(1).join("")))) s -= 2;
  }
  s -= 2 * count(t, /\p{L}[^\p{L}\p{M}\s\d'’.,;:!?()"«»„“”\-–—/]\p{L}/gu);
  s -= 3 * count(t, /[�-]/gu);
  return s;
}
// il testo così com'è, anche con gli accenti staccati già riuniti (LaTeX: "ˇcesk´y" è giusto, non va ricodificato)
const baseScore = (t) => Math.max(plaus(t), MARK_RE.test(t) ? plaus(fixString(t)) : -Infinity);
const nonAscii = (t) => count(t, /[^\x00-\x7F]/gu);
async function detect(text) {
  try {
    const api = (globalThis.browser && browser.i18n && browser.i18n.detectLanguage) ? browser.i18n : chrome.i18n;
    const r = await new Promise((ok) => { const p = api.detectLanguage(text.slice(0, 3000), ok); if (p && p.then) p.then(ok, () => ok(null)); });
    const top = r && r.languages && r.languages[0];
    return top ? { lang: top.language.split("-")[0], pct: top.percentage, sure: !!r.isReliable } : null;
  } catch { return null; }
}
const langOk = (mode, d) => { const t = TGT[mode.split(":")[1]]; return !!d && d.pct >= 50 && (!t.langs || t.langs.some((l) => l.split("-")[0] === d.lang)); };
// automatico, per il testo di un carattere: il modo giusto, "none" se è già giusto, null se c'è troppo poco testo
async function judgeAuto(text) {
  if (nonAscii(text) < 3) return null;
  const base = baseScore(text);
  const cands = MODES.map((m) => ({ m, sc: plaus(recode(text, m)) })).filter((x) => x.sc >= base + 2).sort((x, y) => y.sc - x.sc).slice(0, 12);
  if (!cands.length) return "none";
  const orig = await detect(text);
  for (const c of cands) {
    const d = await detect(recode(text, c.m));
    if (!d) { if (c.sc >= base + 4) return c.m; continue; }
    if (!langOk(c.m, d)) continue;
    // testo che sembra già vero e che il browser riconosce con sicurezza in una lingua che con questa codifica non
    // c'entra (francese con è, ù, ò…): è giusto così. Il testo rovinato spesso sembra vietnamita: lì non conta.
    if (base > 0 && base >= c.sc - 4 && orig && orig.sure && orig.pct >= 80 && !langOk(c.m, orig) && orig.lang !== d.lang) continue;
    return c.m;
  }
  return "none";
}
// scelta a mano di una codifica giusta: la lettura sbagliata che le va meglio, solo dove migliora il testo
function judgeManual(text, tgt) {
  const base = baseScore(text);
  let best = "none", bestScore = base;
  for (const src of Object.keys(SRC)) { const m = src + ":" + tgt; if (src === tgt) continue; const sc = plaus(recode(text, m)); if (sc > bestScore) { best = m; bestScore = sc; } }
  return best;
}
// per le prove (test-volo/tpdf_enc.py)
globalThis.pavPdfEnc = { plaus, recode, judgeAuto, detect, MODES };
let fontMode = new Map(), docMode = "none";
async function chooseEncoding(my) {
  fontMode = new Map(); docMode = "none";
  if (OLD_PREF[encPref]) encPref = OLD_PREF[encPref];
  if (encPref !== "auto" && encPref !== "none" && !TGT[encPref]) encPref = "auto";
  let note = "";
  if (encPref !== "none") {
    const byFont = new Map();
    for (let n = 1; n <= Math.min(doc.numPages, 5); n++) {
      const tc = await (await doc.getPage(n)).getTextContent();
      for (const it of tc.items) if (it.str) byFont.set(it.fontName, (byFont.get(it.fontName) || "") + it.str + " ");
    }
    if (my !== gen) return;
    const weight = {};
    for (const [f, t] of byFont) {
      const j = encPref === "auto" ? await judgeAuto(t) : judgeManual(t, encPref);
      if (my !== gen) return;
      if (j) { fontMode.set(f, j); weight[j] = (weight[j] || 0) + t.length; }
    }
    docMode = Object.keys(weight).filter((k) => k !== "none").sort((x, y) => weight[y] - weight[x])[0] || "none";
    const all = [...byFont.values()].join("");
    if (docMode !== "none") note = "(corretti: " + TGT[docMode.split(":")[1]].name + ")";
    else if (all.length > 50 && count(all, /[�-]/gu) > all.replace(/\s/g, "").length * 0.2)
      note = "(questo PDF non contiene il testo vero: si vede ma non si può leggere)";
  }
  fillEncSelect();
  $("encNote").textContent = note;
}
function fillEncSelect() {
  const sel = $("enc");
  if (!sel.dataset.filled) {
    sel.dataset.filled = "1";
    const groups = new Map();
    for (const [k, t] of Object.entries(TGT)) { if (!groups.has(t.group)) groups.set(t.group, []); groups.get(t.group).push([k, t.name]); }
    for (const [g, list] of groups) {
      const og = document.createElement("optgroup"); og.label = g;
      for (const [k, name] of list) { const o = document.createElement("option"); o.value = k; o.textContent = name; og.append(o); }
      sel.append(og);
    }
  }
  sel.value = encPref;
}
function recodeItems(items) {
  if (encPref === "none" || (docMode === "none" && ![...fontMode.values()].some((m) => m !== "none"))) return;
  const texts = new Map();
  for (const it of items) if (it.str) texts.set(it.fontName, (texts.get(it.fontName) || "") + it.str + " ");
  // caratteri che nelle prime pagine non c'erano: il modo del documento, se migliora il loro testo
  for (const [f, t] of texts) if (!fontMode.has(f) && nonAscii(t) >= 3) {
    if (encPref === "auto") fontMode.set(f, plaus(recode(t, docMode)) >= baseScore(t) + 2 ? docMode : "none");
    else fontMode.set(f, judgeManual(t, encPref));
  }
  for (const it of items) {
    if (typeof it.str !== "string" || !it.str) continue;
    let m = fontMode.get(it.fontName);
    if (m == null) m = docMode !== "none" && plaus(recode(it.str, docMode)) > baseScore(it.str) ? docMode : "none";
    if (m !== "none") it.str = recode(it.str, m);
  }
}
function fixAccents(items) {
  recodeItems(items);
  const list = items.filter((it) => typeof it.str === "string");
  // accento alla fine di un pezzo e lettera all'inizio del pezzo dopo: lo sposto lì
  for (let i = 0; i + 1 < list.length; i++) {
    const s = list[i].str, m = s.slice(-1), next = list[i + 1].str;
    if (MARKS[m] && isLetter(next.charAt(0)) && compose(next.charAt(0), m) && !list[i].hasEOL) {
      list[i].str = s.slice(0, -1);
      list[i + 1].str = m + next;
    }
  }
  for (const it of list) it.str = fixString(it.str);
}


// ---------- Aprire un indirizzo o un file del computer ----------
async function openUrl(url) {
  $("orig").href = url; $("orig").hidden = false;
  let name = "documento.pdf";
  try { name = decodeURIComponent(url.split(/[?#]/)[0].split("/").pop() || name); } catch {}
  if (/^file:/i.test(url)) return openLocal(url, name);
  message("Scarico il PDF…");
  try {
    const r = await fetch(url, { credentials: "include" });
    if (!r.ok) throw new Error("il sito ha risposto " + r.status);
    await openData(new Uint8Array(await r.arrayBuffer()), name);
  } catch (e) {
    message(`<b>Non riesco a scaricare questo PDF da qui</b> (${esc(e && e.message || e)}).<br><br>` +
      `Scaricalo e aprilo con <b>📂</b> qui sopra, oppure trascinalo in questa finestra.<br><button type="button" class="big" data-pick>📂 Apri un PDF dal computer</button>`);
  }
}
// PDF del computer (aperto con un doppio clic o dal gestore dei file): Firefox non lascia leggere i file alle estensioni,
// quindi lo legge il programma di appoggio (lo stesso di yt-dlp, dalla versione 2.1). In Chrome/Edge basta il permesso
// «Consenti l'accesso agli URL dei file».
async function openLocal(url, name) {
  if (!isFirefox) {
    try { const r = await fetch(url); if (r.ok) return openData(new Uint8Array(await r.arrayBuffer()), name); } catch {}
  }
  message(`Apro «${esc(name)}» dal computer…`);
  try {
    const data = await readViaHelper(url, (done, size) => { if (size > 3e6) message(`Apro «${esc(name)}» dal computer… ${Math.round(done / size * 100)}%`); });
    await openData(data, name);
  } catch (e) {
    const code = e && e.code;
    const why = code === "nohelper" ? "il programma di appoggio non è installato"
      : code === "unknown" ? "il programma di appoggio è di una versione vecchia (serve la 2.1)"
      : code === "missing" ? "il file non c'è più in quella cartella" : (e && e.message) || String(e);
    message(`<b>Per aprire «${esc(name)}» premi il pulsante qui sotto e sceglilo</b> (oppure trascinalo in questa finestra).<br>` +
      `<button type="button" class="big" data-pick>📂 Scegli «${esc(name)}»</button><br><br>` +
      `<span class="muted">Perché: ${isFirefox ? "Firefox non lascia leggere alle estensioni i file del computer" : "il browser non lascia leggere all'estensione i file del computer"}, e ${esc(why)}. ` +
      `Per aprire i PDF del computer direttamente, con un doppio clic, ${code === "unknown" ? "aggiorna" : "installa"} il programma di appoggio: ` +
      `<a href="helper.html" target="_blank">⚙ installa il programma di appoggio</a> (è lo stesso delle trascrizioni con yt-dlp)` +
      (isFirefox ? "." : ", oppure, nella pagina delle estensioni, attiva «Consenti l'accesso agli URL dei file» per questa estensione.") + `</span>`);
  }
}
function readViaHelper(url, progress) {
  return new Promise((resolve, reject) => {
    let port, buf = null, off = 0, size = 0, finished = false;
    const fail = (code, message) => { if (finished) return; finished = true; try { port && port.disconnect(); } catch {} reject(Object.assign(new Error(message), { code })); };
    try { port = EXT.runtime.connectNative(HELPER); } catch (e) { fail("nohelper", String(e && e.message || e)); return; }
    port.onMessage.addListener((m) => {
      if (finished || !m) return;
      if (m.type === "meta") { size = Number(m.size) || 0; buf = new Uint8Array(size); }
      else if (m.type === "chunk" && buf) {
        const b = typeof Uint8Array.fromBase64 === "function" ? Uint8Array.fromBase64(m.data) : Uint8Array.from(atob(m.data), (c) => c.charCodeAt(0));
        buf.set(b, off); off += b.length; progress(off, size);
      } else if (m.type === "done") { finished = true; try { port.disconnect(); } catch {} resolve(buf ? buf.subarray(0, off) : new Uint8Array()); }
      else if (m.type === "error") fail(m.code || "failed", m.message || "errore");
    });
    port.onDisconnect.addListener(() => {
      const err = (EXT.runtime.lastError && EXT.runtime.lastError.message) || "";
      fail(/not found|not exist|No such native|non trovat|isn't registered|not registered/i.test(err) || !err ? "nohelper" : "crash", err || "il programma di appoggio non risponde");
    });
    port.postMessage({ cmd: "readfile", url });
  });
}

async function openFile(f) {
  if (!f) return;
  $("orig").hidden = true;
  history.replaceState(null, "", location.pathname);
  await openData(new Uint8Array(await f.arrayBuffer()), f.name);
}
$("file").addEventListener("change", () => { openFile($("file").files[0]); $("file").value = ""; });
pagesEl.addEventListener("click", (e) => { if (e.target.closest("[data-pick]")) $("file").click(); });
// trascinare un PDF nella finestra
let dragN = 0;
const hasFiles = (e) => e.dataTransfer && [...(e.dataTransfer.types || [])].includes("Files");
window.addEventListener("dragenter", (e) => { if (!hasFiles(e)) return; e.preventDefault(); dragN++; document.body.classList.add("drag"); });
window.addEventListener("dragover", (e) => { if (hasFiles(e)) e.preventDefault(); });
window.addEventListener("dragleave", () => { if (--dragN <= 0) { dragN = 0; document.body.classList.remove("drag"); } });
window.addEventListener("drop", (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault(); dragN = 0; document.body.classList.remove("drag");
  const f = [...e.dataTransfer.files].find((x) => /pdf$/i.test(x.type) || /\.pdf$/i.test(x.name));
  if (f) openFile(f); else toast("Trascina un file PDF.");
});

$("enc").addEventListener("change", async () => {
  encPref = $("enc").value;
  ls.set("pavPdfEnc", encPref);
  if (!doc) return;
  const my = gen;
  await chooseEncoding(my);
  if (my !== gen) return;
  tcCache.clear(); findState.query = "";
  const a = anchorAt(viewer.clientWidth / 2, viewer.clientHeight / 3);
  layout(); restoreAnchor(a);
});

const file = params.get("file");
if (file) openUrl(file);
else message("Premi <b>📂</b> qui sopra (o trascina un PDF in questa finestra) per leggere un PDF del computer con Parole al Volo: passa il mouse sulle parole per la loro scheda, evidenzia un pezzo per tradurlo.<br><br>" +
  "I PDF aperti nel browser si aprono qui anche dal popup («📄 Apri questo PDF con Parole al Volo») o da soli, se lo scegli nel popup.<br>" +
  '<button type="button" class="big" data-pick>📂 Apri un PDF</button>');

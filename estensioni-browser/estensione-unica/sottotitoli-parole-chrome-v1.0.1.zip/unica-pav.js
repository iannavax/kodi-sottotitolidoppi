// Estensione unica (Sottotitoli Doppi + Parole al Volo): un archivio delle impostazioni tutto per Parole al Volo.
// Alcune impostazioni hanno lo stesso nome nelle due estensioni ma un altro significato: per esempio "engine" in
// Sottotitoli Doppi è chi traduce i sottotitoli, in Parole al Volo chi spiega le parole. Qui Parole al Volo le salva
// con un nome suo. Le altre (lingua di arrivo, voci, IPA, modelli…) restano in comune, come le chiavi, il
// vocabolario e le parole che conosci (in storage.local).
var PAV_KEYMAP = { engine: "pavEngine", disabledSites: "pavDisabledSites", ankiDeck: "pavAnkiDeck", learnKnownPage: "pavKnownPage", roman: "pavRoman" };
var PAV_SYNC = (() => {
  const M = PAV_KEYMAP, R = {};
  for (const k in M) R[M[k]] = k;
  const out = (k) => M[k] || k;
  const toStore = (keys) => {
    if (keys == null) return keys;
    if (typeof keys === "string") return out(keys);
    if (Array.isArray(keys)) return keys.map(out);
    const o = {};
    for (const k in keys) o[out(k)] = keys[k];
    return o;
  };
  const fromStore = (r) => {
    const o = {};
    for (const k in r || {}) { if (M[k]) continue; o[R[k] || k] = r[k]; }   // "engine" di Sottotitoli Doppi non è suo
    return o;
  };
  return {
    get: (keys) => DS_EXT.storage.sync.get(toStore(keys)).then(fromStore),
    set: (o) => DS_EXT.storage.sync.set(toStore(o)),
    remove: (keys) => DS_EXT.storage.sync.remove(toStore(keys)),
    fromStore
  };
})();
var PAV_ONCHANGED = {
  addListener(fn) {
    DS_EXT.storage.onChanged.addListener((ch, area) => {
      if (area !== "sync") return fn(ch, area);
      const o = PAV_SYNC.fromStore(ch);
      if (Object.keys(o).length) fn(o, area);
    });
  }
};

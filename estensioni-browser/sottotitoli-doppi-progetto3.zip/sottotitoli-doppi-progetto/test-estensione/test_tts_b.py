import asyncio, json
from bharness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p)
        ext = sw.url.split("/")[2]
        # --- passaggio automatico a Flash-Lite per chi aveva già una chiave Gemini ---
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', models:{gemini:'gemini-flash-latest', groq:'x'}})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}, migrated:{}})).then(()=>dsMigrate())""")
        s = await sw.evaluate("chrome.storage.sync.get(['engine','models'])")
        print("1. dopo l'aggiornamento: servizio =", s["engine"], "| modelli =", s["models"])
        await sw.evaluate("chrome.storage.sync.set({engine:'google'})")

        page = await ctx.new_page(); errs=[]
        page.on("pageerror", lambda e: errs.append(str(e)))
        await page.goto("https://www.youtube.com/watch?v=esVideo"); await page.wait_for_timeout(1200)
        await page.evaluate("document.querySelector('video').play()")
        await page.wait_for_selector(".dualsub-orig .dualsub-word", timeout=15000)
        print("   voci installate nel browser di prova:", await page.evaluate("speechSynthesis.getVoices().length"))
        w = page.locator(".dualsub-orig .dualsub-word").nth(2)
        await w.hover(); await page.wait_for_selector(".dualsub-card-meaning", timeout=10000)
        print("2. video spagnolo, etichetta sul pulsante:", await page.inner_text(".dualsub-speak"))
        await page.click(".dualsub-speak"); await page.wait_for_timeout(1200)
        print("   richiesta di pronuncia:", log.get("tts"), "|", await page.get_attribute(".dualsub-speak", "title"))

        # --- lingua scelta a mano ---
        await sw.evaluate("chrome.storage.sync.set({ttsLang:'fr'})"); await page.wait_for_timeout(500)
        await page.click(".dualsub-card-btn[title='Chiudi']"); await page.mouse.move(500, 50); await page.wait_for_timeout(800)
        w = page.locator(".dualsub-orig .dualsub-word").nth(1)
        await w.click(); await page.wait_for_selector(".dualsub-card-meaning", timeout=10000)
        print("3. lingua impostata a mano (francese), etichetta:", await page.inner_text(".dualsub-speak"))
        await page.click(".dualsub-speak"); await page.wait_for_timeout(1200)
        print("   richiesta di pronuncia:", log["tts"][-1])
        await sw.evaluate("chrome.storage.sync.set({ttsLang:'', ttsVoice:'google'})"); await page.wait_for_timeout(500)
        await page.click(".dualsub-speak"); await page.wait_for_timeout(1200)
        print("4. voce 'sempre Google', lingua automatica:", log["tts"][-1])

        # --- popup ---
        pp = await ctx.new_page(); perr=[]
        pp.on("pageerror", lambda e: perr.append(str(e)))
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', ttsVoice:''})")
        await pp.goto(f"chrome-extension://{ext}/popup.html"); await pp.wait_for_timeout(2000)
        print("5. popup: modello Gemini =", await pp.input_value("#model"), "| opzioni voce:", await pp.locator("#ttsVoice option").count())
        await pp.click("#dTts summary"); await pp.select_option("#ttsLang", "ja"); await pp.wait_for_timeout(300)
        await pp.click("#ttsTest"); await pp.wait_for_timeout(1500)
        print("   prova voce in giapponese:", log["tts"][-1], "|", await pp.inner_text("#ttsInfo"))
        print("   impostazione salvata:", await sw.evaluate("chrome.storage.sync.get('ttsLang').then(r=>r.ttsLang)"))
        print("errori:", errs, perr, log["errors"])
        await ctx.close()
asyncio.run(main())

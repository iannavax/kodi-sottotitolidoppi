# гордую: IPA solo della parola esatta (non della forma base), registrazione della forma base segnalata (🔊*)
import asyncio, os, sys, re
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
PAGE = '<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>t</title></head><body style="margin:40px;font:18px Georgia"><p id="ru" lang="ru">Я вижу гордую птицу.</p></body></html>'
OTHER = ("https://tatoeba.org/", "https://api.tatoeba.org/", "https://api.languagetool.org/", "https://raw.githubusercontent.com/", "https://commons.wikimedia.org/", "https://upload.wikimedia.org/")
async def handle(route, request):
    u = request.url
    if u.startswith("https://example.test/"): return await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=PAGE)
    if u.startswith(OTHER) or re.match(r"https://[a-z-]+\.wiktionary\.org/", u): return await charness.handle(route, request)
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({ipaCache:{'ru|гордую':'ˈgordɨj'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/g.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "ru", "гордую", 6000)
        print("1. IPA:", await pg.evaluate("(document.querySelector('.pav-card .pav-pron')||{}).innerText||'(nessuna)'"))
        print("2. pulsanti:", await pg.evaluate("[...document.querySelectorAll('.pav-card .pav-tools .pav-btn')].map(b=>[b.textContent, b.className.includes('recform'), b.title.slice(0,70)])"))
        print("   cache IPA:", await sw.evaluate("chrome.storage.local.get('ipaCache').then(r=>r.ipaCache)"))
        print("errori:", errs, tvolo.log["errors"], charness.log.get("errors"))
        await ctx.close()
asyncio.run(main())

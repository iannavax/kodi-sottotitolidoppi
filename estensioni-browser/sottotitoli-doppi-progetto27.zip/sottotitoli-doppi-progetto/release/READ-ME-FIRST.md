# Sottotitoli Doppi (Dual Subtitles)

*[Versione italiana → LEGGIMI-PRIMA](LEGGIMI-PRIMA.html)*

**Learn languages by watching videos, films and series with the original subtitles and the translation together.**

Under every line in the original language you see the translation in your own language, in another colour. You hear the real language, read what is being said and understand what it means, all at the same time.

Sottotitoli Doppi works in three places. Pick the one you use to watch:

| | 🌐 **Browser** | 📺 **Kodi** | 🎬 **Stremio** |
|---|---|---|---|
| **To watch** | YouTube and almost any site with video or audio; plus any web page and PDFs | Films and series in Kodi: local files or streaming | Films and series in Stremio |
| **Runs on** | Edge, Chrome, Brave, Firefox (computer) | Kodi 19 or newer (PC, TV box, Fire TV…) | Stremio for desktop |
| **Original subtitles** | The site's own, or a transcription of the audio | Inside the film, next to the video, from the Internet, or a transcription of the audio | From OpenSubtitles |
| **Clickable words, vocabulary, Anki** | ✅ (also on web pages and PDFs) | — | — |
| **Save subtitles (.srt)** | ✅ | ✅ | — |
| **Guide** | [browser/GUIDE](browser/GUIDE.en.html) | [kodi/GUIDE](kodi/GUIDE.en.html) | [stremio/GUIDE](stremio/GUIDE.en.html) |

The browser extension does two things in one: **Sottotitoli Doppi** in videos and **Parole al Volo** (*words on the fly*) on web pages and PDFs — hover a word to see its translation, pronunciation and explanation; select some text to translate it all at once. Vocabulary, known words, keys and Anki are shared.

All of them translate for free with **Google Translate**, or much better with **Gemini** (free with a key) and other services. Everything translated or transcribed is saved: watching a video again costs nothing.

**Note:** the menus and settings are in Italian. In the browser extension, open the popup, choose **Traduci in** (*translate into*) → English and tick **Interfaccia in questa lingua** (*interface in this language*): the whole extension switches to English. The English guides give every Italian label in **bold** with its meaning in *italics*, so you always know what to press.

---

## What's in the box

```
LEGGIMI-PRIMA.html        → this page, in Italian
READ-ME-FIRST.html        → this page

browser/
  sottotitoli-parole-chrome-vX.Y.Z.zip     → for Edge, Chrome, Brave
  sottotitoli-parole-firefox-vX.Y.Z.xpi    → for Firefox
  GUIDE.en.html  /  LEGGIMI.html          → full guide (English / Italian)

kodi/
  script.sottotitolidoppi-1.12.0.zip            → the add-on
  service.subtitles.sottotitolidoppi-1.0.0.zip  → the player's Subtitles menu entry
  service.subtitles.subdl-1.0.0.zip             → subtitles from subdl.com (optional)
  GUIDE.en.html  /  LEGGIMI.html                → full guide (English / Italian)

stremio/
  sottotitoli-doppi-stremio-1.3.0.zip     → the Stremio add-on
  GUIDE.en.html  /  LEGGIMI.html          → guide (English / Italian)
```

Open the guides by double-clicking the **.html** files: they open in your browser, with a clickable table of contents. The same guides are also included as .md (plain text).

---

## Up and running in 5 minutes

### Browser (Edge, Chrome, Brave)
1. Unzip `sottotitoli-parole-chrome-vX.Y.Z.zip` into a folder you won't delete (for example in Documents).
2. Open the extensions page (`edge://extensions` or `chrome://extensions`), turn on **Developer mode**, press **Load unpacked** and choose that folder.
3. Click the extension's icon → **Traduci in** (*translate into*): your language.
4. Open a YouTube video and turn on subtitles (CC): the dual line appears. Hover over a word to see what it means.

**Firefox**: open `about:addons` → ⚙ → **Install Add-on From File…** → choose the `.xpi` file.

### Kodi
1. Kodi → **Settings → System → Add-ons**: turn on **Unknown sources**.
2. **Settings → Add-ons → Install from zip file**: first `script.sottotitolidoppi-1.12.0.zip`, then `service.subtitles.sottotitolidoppi-1.0.0.zip` (and, if you like, `service.subtitles.subdl-1.0.0.zip`).
3. In the add-on's settings choose **Traduci in** (*translate into*) and the translation **Servizio** (*service*).
4. Start a film: after a few seconds the add-on asks whether you want dual subtitles (yes, no, always or never for the series). Change it in **Generale → Quando parte un video** (ask, always, never).

### Stremio
1. Install **Node.js** (LTS version) from nodejs.org.
2. Unzip `sottotitoli-doppi-stremio-1.3.0.zip` and run `avvia-windows.bat` (Windows) or `avvia-mac-linux.sh` (Mac/Linux).
3. On the page that opens choose your language and press **Installa in Stremio** (*install in Stremio*).

### The free Gemini key (recommended)
Google Translate works right away, but it translates line by line. **Gemini** understands the context and translates much better, and it's free:
1. Go to **aistudio.google.com/apikey** and sign in with a Google account.
2. Press *Create API key* (no credit card needed) and copy the key.
3. Paste it into the extension (icon → 🌐 Traduzione e modelli → Traduci i sottotitoli con (*translate the subtitles with*) → Gemini), into the Kodi add-on's settings (Servizio → gemini) or into the Stremio page.

For **videos without subtitles** (browser and Kodi) you also need a free **Groq** key to transcribe the audio: **console.groq.com/keys**.

---

## Updating without losing anything

When you get a new version:

- **Edge / Chrome / Brave**: unzip the new version **into the same folder** as before (overwriting the files) and press ↻ on the extension in the extensions page.
- **Firefox**: install the new `.xpi` over the old one.
- **Kodi**: install the new zip over the old one (Install from zip file).
- **Stremio**: close the black window, replace the files in the same folder and start it again.

**Never uninstall** the extension or the add-on to update it: that also deletes your keys, saved translations and vocabulary.

---

## Privacy

Sottotitoli Doppi has no servers of its own and collects no data. Keys, translations and vocabulary stay on your computer, in your browser or in your Kodi. Text to translate (and audio to transcribe, if you ask for it) is sent only to the services you choose — Google, Gemini, Groq and so on — under their own terms.

---

## Need help?

Each guide ends with a **troubleshooting** section listing the most common problems and how to fix them.

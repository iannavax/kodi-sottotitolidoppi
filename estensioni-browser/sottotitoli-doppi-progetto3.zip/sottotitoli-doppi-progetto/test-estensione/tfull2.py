import asyncio, json, os, subprocess, shutil, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
PROFILE = "/tmp/pwprofile14"
async def main():
    shutil.rmtree(PROFILE, ignore_errors=True)
    env = dict(os.environ, FAKE_AUDIO="/tmp/big.wav", FAKE_LOG="/tmp/fake-ytdlp.log")
    async with async_playwright() as p:
        ctx, sw = await launch(p, PROFILE, env)
        ext = sw.url.split("/")[2]
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', transcribeMode:'live'})
          .then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))""")
        # programma per yt-dlp installato come farebbe l'utente
        hp = await ctx.new_page(); await hp.goto(f"chrome-extension://{ext}/helper.html"); await hp.wait_for_timeout(800)
        await hp.select_option("#os", "linux")
        async with hp.expect_download() as d: await hp.click("#download")
        subprocess.run(["sh", await (await d.value).path()], capture_output=True, env=dict(os.environ, HOME="/tmp/sdhome",
            SD_YTDLP_URL="file:///home/claude/e2e/fake/yt-dlp", SD_DENO_URL="file:///tmp/fakedeno.zip", SD_EXTRA_CHROME_DIRS=PROFILE + "/NativeMessagingHosts"))
        await hp.close()
        st = lambda: sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)")

        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsBigA"); await pg.wait_for_timeout(1500)
        await pg.evaluate("const v=document.querySelector('video'); v.currentTime=200; v.play()"); await pg.wait_for_timeout(3000)
        print("1. modalità 'Mentre guardo':", await st())
        n0 = len(log["groq"])
        # cambio la modalità predefinita dal popup: deve valere subito
        await sw.evaluate("chrome.storage.sync.set({transcribeMode:'full'})")
        seen = []
        for _ in range(60):
            await pg.wait_for_timeout(500)
            s = await st()
            if s and (not seen or seen[-1] != s): seen.append(s)
            if "Trascrizione completa:" in (s or "") or "non riuscita" in (s or ""): break
        print("2. dopo il cambio a 'Completa', senza ricaricare:", seen[:3], "...", seen[-1:])
        files = log["groq_files"][n0:]
        print("   pezzi inviati a Groq (in ordine):", [(f, round(sz/32000)) for f, sz in files if f.startswith("parte")])
        await pg.wait_for_timeout(3000)
        dbg = json.loads(await pg.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))
        cov = json.loads(await pg.evaluate("document.documentElement.dataset.dualsubCovered || '[]'"))
        before = [c for c in dbg if c["start"] < 180000]
        print(f"3. frasi totali {len(dbg)}; prima del punto di partenza (3:00): {len(before)}; prima frase a {dbg[0]['start']/1000:.0f}s, ultima a {dbg[-1]['start']/1000:.0f}s")
        print("   parti coperte (s):", [(round(a/1000), round(b/1000)) for a, b in cov])
        await pg.close()

        # rivedo: solo il buco deve essere riascoltato
        n1 = len(log["groq"])
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsBigA"); await pg.wait_for_timeout(1500)
        await pg.evaluate("const v=document.querySelector('video'); v.currentTime=20; v.play()"); await pg.wait_for_timeout(12000)
        a = len(log["groq"]) - n1
        await pg.evaluate("const v=document.querySelector('video'); v.currentTime=250; v.play()"); await pg.wait_for_timeout(16000)
        b = len(log["groq"]) - n1 - a
        print("4. rivisto:", await st())
        print(f"   richieste a Groq guardando una parte già trascritta: {a}; guardando il buco (250 s): {b}")
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

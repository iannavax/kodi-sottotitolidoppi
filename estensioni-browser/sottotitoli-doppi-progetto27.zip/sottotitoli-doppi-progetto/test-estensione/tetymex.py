# 1.5.1: nell'etimologia della scheda il collegamento a Etymology Explorer (etymologyexplorer.com/word/<lingua>/<parola>)
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, learnExamples:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(5000)
        href = await pg.evaluate("([...document.querySelectorAll('.dualsub-card a.dsx-link')].find(a=>a.textContent==='Etymology Explorer')||{}).href||''")
        print("collegamento:", href)
        ok = href == "https://etymologyexplorer.com/word/English/bread"
        print("errori:", errs if ok else errs + ["collegamento sbagliato"], log["errors"])
        await ctx.close()
asyncio.run(main())

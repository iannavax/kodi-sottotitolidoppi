# -*- coding: utf-8 -*-
# SubDL - servizio per il menu dei sottotitoli del lettore (Sottotitoli → Scarica → SubDL).
# Cerca su subdl.com con la chiave gratuita; il codice di ricerca e di scaricamento è quello di Sottotitoli Doppi.
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
sys.path.insert(0, xbmcvfs.translatePath(xbmcaddon.Addon("script.sottotitolidoppi").getAddonInfo("path")))
from resources.lib import core  # noqa: E402  (dall'add-on principale)

NAME = "SubDL"


def notify(msg, ms=7000):
    xbmcgui.Dialog().notification(NAME, msg, xbmcgui.NOTIFICATION_INFO, ms)


def api_key():
    k = ADDON.getSetting("api_key").strip()
    if not k:
        try:
            k = xbmcaddon.Addon("script.sottotitolidoppi").getSetting("subdl_key").strip()
        except Exception:
            k = ""
    return k


def lang_codes(names):
    """«English,Italian» (come le passa Kodi) → ["en", "it"]"""
    out = []
    for n in (names or "").split(","):
        n = n.strip()
        if not n:
            continue
        c = ""
        try:
            c = xbmc.convertLanguage(n, xbmc.ISO_639_1)
        except Exception:
            pass
        if not c:
            c = next((k for k, v in core.LANG_EN.items() if v.lower() == n.lower()), "")
        if c and c not in out:
            out.append(c)
    return out


def lang_name(code):
    try:
        return xbmc.convertLanguage(code, xbmc.ENGLISH_NAME) or core.LANG_EN.get(code, code)
    except Exception:
        return core.LANG_EN.get(code, code)


def search(handle, q, manual=False):
    key = api_key()
    if not key:
        notify("Scrivi la chiave gratuita di SubDL (subdl.com → API) nelle impostazioni dell'add-on SubDL.", 10000)
        return
    langs = lang_codes(q.get("languages", "")) or ["en"]
    info = xbmc.getInfoLabel
    imdb = "" if manual else info("VideoPlayer.IMDBNumber")
    title = q.get("searchstring") if manual else (info("VideoPlayer.OriginalTitle") or info("VideoPlayer.TVShowTitle") or info("VideoPlayer.Title"))
    season, episode = info("VideoPlayer.Season"), info("VideoPlayer.Episode")
    if not imdb and not title:
        title = os.path.splitext(os.path.basename(urllib.parse.unquote(xbmc.Player().getPlayingFile().split("?")[0])))[0]
    try:
        found = core.subdl_search(key, langs, imdb, title, info("VideoPlayer.Year"), int(season or 0), int(episode or 0))
    except Exception as e:
        notify("SubDL: %s" % e, 9000)
        return
    show_hi = ADDON.getSetting("hi") != "false"
    found = [f for f in found if f["lang"] in langs and (show_hi or not f["hi"])]
    found.sort(key=lambda f: langs.index(f["lang"]))
    for f in found[:60]:
        li = xbmcgui.ListItem(label=lang_name(f["lang"]), label2=f["release"] or "SubDL")
        li.setArt({"icon": "0", "thumb": f["lang"]})
        li.setProperty("sync", "false")
        li.setProperty("hearing_imp", "true" if f["hi"] else "false")
        url = "plugin://service.subtitles.subdl/?" + urllib.parse.urlencode(
            {"action": "download", "url": f["url"], "lang": f["lang"], "se": season or "0", "ep": episode or "0"})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    if not found:
        notify("SubDL non ha sottotitoli in %s per questo video." % ", ".join(lang_name(l) for l in langs), 7000)


def download(handle, q):
    try:
        body, ext = core.subdl_download(q["url"], int(q.get("se") or 0), int(q.get("ep") or 0))
    except Exception as e:
        notify("SubDL: %s" % e, 9000)
        return
    folder = xbmcvfs.translatePath("special://temp/subdl/")
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "subdl-%s.%s%s" % (core.cache_key(q["url"]), q.get("lang") or "orig", ext))
    open(path, "wb").write(body)
    xbmcplugin.addDirectoryItem(handle=handle, url=path, listitem=xbmcgui.ListItem(label=path), isFolder=False)


def main(argv):
    handle = int(argv[1])
    q = dict(urllib.parse.parse_qsl(argv[2].lstrip("?")))
    try:
        if q.get("action") == "search":
            search(handle, q)
        elif q.get("action") == "manualsearch":
            search(handle, q, manual=True)
        elif q.get("action") == "download" and q.get("url"):
            download(handle, q)
    except Exception as e:
        xbmc.log("SubDL: %r" % e, xbmc.LOGERROR)
        notify("Errore: %s" % e, 8000)
    xbmcplugin.endOfDirectory(handle)


main(sys.argv)

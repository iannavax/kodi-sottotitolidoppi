# Sottotitoli Doppi — istruzioni per Claude Code

Leggi prima **RIPRESA.md** (stato del progetto, architettura, decisioni già prese, bug da non reintrodurre, storia delle versioni). Questo file riassume solo come lavorare.

## L'utente
- Parla italiano e non è un programmatore: rispondi in **italiano semplice**, senza gergo.
- Usa **Firefox (Nightly)** ed Edge su Windows.
- Vuole consumare **pochi token** di Groq e Gemini: prima i servizi gratuiti senza chiave (Google, Wiktionary, Tatoeba, LanguageTool…), il modello solo quando serve e nella stessa richiesta.
- **Non rompere la build**: dopo ogni modifica rifai il build e le prove.
- Alla fine consegna **solo l'estensione unica** (zip per Chrome/Edge, .xpi per Firefox, con dentro LEGGIMI/GUIDE in .md e .html), la guida unica, RIPRESA.md e l'archivio del progetto. Sottotitoli Doppi e Parole al Volo separate **non si consegnano più** (decisione dell'utente, ottobre 2026): si costruiscono solo per le prove.
- Vuole l'interfaccia, le spiegazioni e tutto il resto nella lingua di «Traduci in» (casella «Interfaccia in questa lingua»).

## Struttura
- `estensione/` — Sottotitoli Doppi (codice in `src/`, `build.sh <versione>`, manifest chrome/firefox, guide `GUIDA.md` e `GUIDE.en.md`, novità `novitaXXX.md`).
- `parole-al-volo/` — estensione sorella per le pagine web; **usa molti file di `estensione/src`** (config.js, background.js, tts.js, etym.js, learn.js, roman.js, vocab.js, freq.js, engines-ui.js, voices-ui.js): una modifica lì vale per tutte e due. `build.sh <versione>`.
- `unica/` — estensione unica «Sottotitoli Doppi + Parole al Volo» (gecko id `sottotitoli-parole@estensione.local`), **l'unica che si consegna**: **nessun codice proprio** oltre a `src/` (adattatore `unica-pav.js`, popup unico generato da `make-popup.py`: `popup.html` di Sottotitoli Doppi + `src/popup-pagine-part.html` (id «p-»)) e la guida unica `GUIDA.md` + `GUIDE.en.md` (con la sezione «Novità» in fondo: lì vanno le novità di ogni versione); `build.sh <versione>` prende i file dalle due estensioni, genera i manifest e trasforma il codice di Parole al Volo (`DS_EXT.storage.sync` → `PAV_SYNC`). Va rifatta (e provata) dopo ogni modifica alle due estensioni.
- `kodi/`, `stremio/` — add-on (non toccati di recente).
- `test-estensione/`, `test-volo/` — banco di prova Playwright con servizi simulati (nessuna rete vera).
- `release/` — testi per la confezione per l'utente finale (`LEGGIMI-PRIMA.md`, `READ-ME-FIRST.md`, `md2html.py`).

## Build
```bash
cd estensione && ./build.sh 5.22.1        # solo per le prove (crea build/chrome e build/firefox e controlla la sintassi)
cd ../parole-al-volo && ./build.sh 1.16.1  # solo per le prove
cd ../unica && ./build.sh 1.5.3            # quella da consegnare: zip, xpi, LEGGIMI/GUIDE .md e .html dentro
```
I build rifanno anche `estensione/src/ui-strings.json` (scritte dell'interfaccia prese dal codice, per la traduzione dell'interfaccia: `estensione/tools/crea_ui_strings.py`). Le tabelle delle codifiche dei PDF (`parole-al-volo/src/pdf-enc.js`) si rifanno con `python3 parole-al-volo/tools/crea_pdf_enc.py`.
Per una versione nuova: `cd unica && ./build.sh <versione>` (la versione va solo lì: il manifest si genera), novità in fondo a `unica/GUIDA.md` e `unica/GUIDE.en.md`, aggiorna `RIPRESA.md` ("Ultimo lavoro").

## Prove
Servono Python 3, `pip install playwright` e Chromium (`python -m playwright install chromium`).
Gli script si aspettano le cartelle `/home/claude/e2e` (copia di `test-estensione`) e `/home/claude/e2e-volo` (copia di `test-volo`): su un altro computer cambia quei percorsi in testa agli script (`sys.path.insert`) o crea le cartelle. Prima volta: `python3 crea_audio.py` in `e2e`.
Esempi: `python3 tlearn.py ../estensione/build/chrome`, `python3 tvolo.py ../parole-al-volo/build/chrome`, `python3 tswap.py <build SD> <build PAV>`.
Ogni prova stampa `errori: [] []` quando va tutto bene.

## Da sapere
- I servizi veri (Wiktionary, Tatoeba, Google, Groq, Gemini, Anki, Azure, Openverse) sono stati provati **solo con simulatori**: quando l'utente segnala un problema reale, cerca la causa nel formato vero delle risposte.
- Le preferenze stanno in `storage.sync` (`SYNC_DEFAULTS` in config.js per SD, `PAV_DEFAULTS` in volo-config.js per PAV); cache e vocabolario in `storage.local`.
- Non cambiare i nomi delle chiavi di storage già usate: l'utente aggiorna sopra la versione vecchia e non deve perdere chiavi, vocabolario e parole conosciute.

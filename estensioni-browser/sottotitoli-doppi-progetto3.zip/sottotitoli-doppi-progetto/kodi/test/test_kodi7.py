# Prove della 1.10.3: scelta a mano dei sottotitoli originali (dentro il video / scaricati) e partenza della traduzione
import sys, os, json, time, shutil, threading, http.server, socketserver, re, urllib.parse
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
FILM = "/tmp/mkvt/film.mkv"
STATS = {"req": 0, "bytes": 0}
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        if not self.path.startswith("/d/XYZ/"):
            self.send_response(404); self.end_headers(); return
        size = os.path.getsize(FILM)
        m = re.match(r"bytes=(\d+)-(\d*)", self.headers.get("Range", ""))
        a = int(m.group(1)) if m else 0
        b = min(int(m.group(2)) if m and m.group(2) else size - 1, size - 1)
        with open(FILM, "rb") as f:
            f.seek(a); data = f.read(b - a + 1)
        STATS["req"] += 1; STATS["bytes"] += len(data)
        self.send_response(206 if m else 200)
        self.send_header("Content-Length", str(len(data))); self.send_header("Content-Range", "bytes %d-%d/%d" % (a, b, size))
        self.end_headers(); self.wfile.write(data)
srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), H); srv.daemon_threads = True
threading.Thread(target=srv.serve_forever, daemon=True).start()
URL = "http://127.0.0.1:%d/d/XYZ/Festen.1998.Danish.1080p.mkv" % srv.server_address[1]
from resources.lib import core
tr = lambda x: " ".join(w[::-1] for w in x.split())
real_http = core.http
def fake_http(url, data=None, headers=None, timeout=90):
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + tr(l) + "]" for l in q.split("\n")), q]], None, "da"]).encode(), {}
    if "opensubtitles" in url or "cinemeta" in url:
        return 200, b'{"subtitles": [{"id": "1", "url": "https://dl.os.example/1.srt", "lang": "dan"}], "metas": []}', {}
    return 404, b"", {}
core.http = fake_http
from resources.lib import runner, subtitles
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra",
                           "trans_color": "FFFF00", "auto": "true", "source_mode": "auto (file)", "trans_mode": "nuova (x)"})
xbmc.Player.playing = True; xbmc.Player.playing_file = URL; xbmc.Player.subs.clear(); xbmc.Player.sub_lang = "dan"
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": URL, "at": time.time() - 20})
# un file scaricato con OpenSubtitles nel frattempo (altra edizione, testo diverso)
open("/tmp/kodi-temp/subtitles/Festen.1998.da.srt", "w").write("1\n00:00:01,000 --> 00:00:03,000\nOPENSUBS riga uno\n\n2\n00:00:04,000 --> 00:00:06,000\nOPENSUBS riga due\n")
P = xbmc.Player()
first = lambda: (open(xbmc.Player.subs[-1], encoding="utf-8").read().split("\n")[2] if xbmc.Player.subs else None)
# 1. in automatico, con un .mkv in streaming, prima le tracce dentro il video
runner.run(P, interactive=True)
print("1. automatico:", first(), "| mkv:", "OPENSUBS" not in (first() or ""))
# 2. menu del lettore: dentro il video per primo, poi il file scaricato
xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "1", "?action=search"])
labs = [li.label2 for u, li in xbmcplugin.ITEMS]
print("2. menu del lettore:", labs)
ok2 = "dentro il video" in labs[0] and any("Festen.1998.da.srt" in l for l in labs)
# 3. menu dell'add-on: "Scegli i sottotitoli originali da tradurre" → il file scaricato
xbmcgui.SELECTS.clear(); xbmc.Player.subs.clear()
opts = subtitles.options(P)
ifile = next(i for i, o in enumerate(opts) if o.get("p", "").endswith("Festen.1998.da.srt"))
xbmcgui.SELECT_ANSWER[0] = ifile
runner.pick_menu(P)
print("3. elenco:", xbmcgui.SELECTS[-1])
print("   scelto il file scaricato:", first())
ok3 = "OPENSUBS" in (first() or "") and xbmcgui.SELECTS[-1][-1].startswith("Scegli un file dal dispositivo")
# 4. ricordato: in automatico riparte dal file scelto
xbmc.Player.subs.clear(); runner.run(P, interactive=True)
ok4 = "OPENSUBS" in (first() or "")
print("4. ricordato:", first())
# 5. di nuovo il menu: la scelta attuale è segnata con ►, si torna alla traccia dentro il video
xbmcgui.SELECTS.clear(); xbmc.Player.subs.clear()
imkv = next(i for i, o in enumerate(subtitles.options(P)) if o["k"] == "mkv")
xbmcgui.SELECT_ANSWER[0] = imkv
runner.pick_menu(P)
marked = [l for l in xbmcgui.SELECTS[-1] if l.startswith("►")]
print("5. segnata:", marked, "| ora:", first())
ok5 = len(marked) == 1 and "Festen.1998.da.srt" in marked[0] and "OPENSUBS" not in (first() or "")
# 6. "Scegli originale e traduzione": il terzo elenco è lo stesso (senza trascrizione)
xbmcgui.SELECTS.clear(); xbmcgui.SELECT_ANSWER[0] = 2
class Seq:
    seq = [2, 1, 0]
xbmcgui.Dialog.select = lambda self, h, o: (xbmcgui.SELECTS.append(o), Seq.seq.pop(0))[1]
runner.choose_menu(P)
print("6. terzo elenco:", xbmcgui.SELECTS[-1][:2])
ok6 = len(xbmcgui.SELECTS) == 3 and "dentro il video" in xbmcgui.SELECTS[-1][0]
print("ESITO:", all([ok2, ok3, ok4, ok5, ok6]))
srv.shutdown()

# 1.11: quando parte un video, i sottotitoli doppi si fanno solo se servono (chiedi / sempre / mai, video e serie)
import sys, os, json, time, shutil, urllib.parse
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui
from resources.lib import core
calls = []
tr = lambda x: " ".join(w[::-1] for w in x.split())
LANG = {"tt1": "Germany", "tt2": "Italy"}
def fake_http(url, data=None, headers=None, timeout=90):
    calls.append(url.split("?")[0])
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + tr(l) + "]" for l in q.split("\n")), q]], None, "de"]).encode(), {}
    if "cinemeta" in url and "/meta/" in url:
        tt = url.split("/")[-1].replace(".json", "")
        return 200, json.dumps({"meta": {"country": LANG.get(tt, "Germany"), "name": "Film"}}).encode(), {}
    if url.startswith("https://opensubtitles-v3.strem.io/") or "cinemeta" in url:
        return 200, json.dumps({"subtitles": [], "metas": []}).encode(), {}
    return 404, b"", {}
core.http = fake_http
from resources.lib import runner
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/k14"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles"); os.makedirs("/tmp/k14")
DE = ["wo gehst du heute abend hin", "ich gehe nach hause zu meiner mutter", "das ist weit von hier", "ja aber der zug fährt bald"]
def film(name, tt, show="", total=5400, audio="ger"):
    p = "/tmp/k14/%s.mkv" % name
    open(p, "w").write("x")
    open(p[:-4] + ".de.srt", "w", encoding="utf-8").write("\n".join("%d\n00:00:%02d,000 --> 00:00:%02d,500\n%s\n" % (i + 1, i * 4 + 1, i * 4 + 3, l) for i, l in enumerate(DE)))
    xbmc.Player.playing_file = p; xbmc.Player.total = total
    xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.IMDBNumber": tt, "VideoPlayer.AudioLanguage": audio, "VideoPlayer.Title": name})
    if show: xbmc.INFO["VideoPlayer.TVShowTitle"] = show
    xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": p, "at": time.time() - 20})
    return p
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra", "trans_color": "FFFF00",
                           "sync_audio": "false"})
player = xbmc.Player()
def start(answers=None):
    del calls[:]; del xbmcgui.SELECTS[:]; xbmc.Player.subs = []
    xbmcgui.SELECT_ANSWER[:] = answers if answers is not None else [-1]
    runner.auto_start(player)
    tr_calls = len([c for c in calls if "translate" in c])
    return {"domanda": bool(xbmcgui.SELECTS), "opzioni": xbmcgui.SELECTS[0] if xbmcgui.SELECTS else None, "doppi": bool(xbmc.Player.subs),
            "richieste": len(calls), "traduzioni": tr_calls}
last_log = lambda: [l for l in xbmc.LOG if "avvio automatico" in l][-1].split("] ", 1)[1]

# 1. predefinito "chiedi": domanda; senza risposta (20 s) niente, nessuna traduzione
film("Lola rennt", "tt1")
r = start([-1]); print("1. chiedi, nessuna risposta:", r["domanda"], r["doppi"], "| traduzioni:", r["traduzioni"], "|", last_log())
print("   opzioni:", r["opzioni"])
# 2. risposta Sì → creati; rivedendolo: nessuna domanda, caricati senza richieste di traduzione
r = start([0]); print("2. sì:", r["doppi"], "| traduzioni:", r["traduzioni"], "|", last_log())
r = start([-1]); print("   rivisto: domanda", r["domanda"], "| doppi", r["doppi"], "| traduzioni:", r["traduzioni"], "|", last_log())
# 3. altro film, risposta No → la volta dopo nessuna domanda
film("Der Himmel", "tt3")
r = start([1]); print("3. no:", r["doppi"], "|", last_log())
r = start([0]); print("   rivisto: domanda", r["domanda"], "| doppi", r["doppi"], "| richieste", r["richieste"], "|", last_log())
# 4. film italiano (dal catalogo) e audio italiano: niente, senza domanda
film("La vita", "tt2", audio="")
r = start([0]); print("4. film italiano: domanda", r["domanda"], "| doppi", r["doppi"], "| richieste", r["richieste"], "|", last_log())
film("Doppiato", "tt1", audio="ita")
r = start([0]); print("   audio italiano: domanda", r["domanda"], "| richieste", r["richieste"], "|", last_log())
# 5. video breve (trailer)
film("Trailer", "tt1", total=120)
r = start([0]); print("5. breve: domanda", r["domanda"], "| richieste", r["richieste"], "|", last_log())
# 6. serie: "Mai per la serie" → l'episodio dopo niente; poi dal menu torna come l'impostazione
film("Dark S01E01", "tt1", show="Dark")
r = start([3]); print("6. serie, mai:", r["opzioni"][3], "|", last_log())
film("Dark S01E02", "tt1", show="Dark")
r = start([0]); print("   episodio 2: domanda", r["domanda"], "| richieste", r["richieste"], "|", last_log())
xbmcgui.SELECT_ANSWER[:] = [-1]; del xbmcgui.SELECTS[:]
xbmcgui.SELECT_ANSWER[:] = [5, -1]   # menu: "Serie Dark: torna a come l'impostazione"
runner.auto_menu(player)
print("   menu:", xbmcgui.SELECTS[0])
r = start([2]); print("   dopo il menu: domanda", r["domanda"], "| scelto 'Sempre per la serie' → doppi", r["doppi"], "|", last_log())
film("Dark S01E03", "tt1", show="Dark")
r = start([-1]); print("   episodio 3: domanda", r["domanda"], "| doppi", r["doppi"], "|", last_log())
# 7. "Non chiedere più" → impostazione mai
film("Altro", "tt5")
r = start([2]); print("7. non chiedere più:", xbmcaddon.SETTINGS.get("auto_mode"), "|", runner.settings()["auto_mode"])
r = start([0]); print("   poi: domanda", r["domanda"], "| richieste", r["richieste"], "|", last_log())
# 8. "sempre": niente domanda
xbmcaddon.SETTINGS["auto_mode"] = "sempre (crea i sottotitoli doppi da solo)"
film("Ancora", "tt6")
r = start([-1]); print("8. sempre: domanda", r["domanda"], "| doppi", r["doppi"], "|", last_log())
# 9. vecchia impostazione "auto" spenta = mai
xbmcaddon.SETTINGS.pop("auto_mode"); xbmcaddon.SETTINGS["auto"] = "false"
print("9. vecchia auto=false →", runner.settings()["auto_mode"])

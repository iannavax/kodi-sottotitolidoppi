# 1.4.5: «Modello per ogni compito» nel popup (sottotitoli, pagine, trascrizione, spiegazioni, correzione, pronuncia,
# collegamento parole); la pronuncia con Ollama è in test-volo/tipa_task_volo.py
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'google', models:{local:'gemma4:e4b'}, targetLang:'it', ipa:true, learnExamples:false, learnSpell:false, learnFreq:false, learnLlmExtra:false})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1500); await pp.evaluate("document.querySelectorAll('details').forEach(d=>d.open=true)"); await pp.wait_for_timeout(400)
        rows = await pp.evaluate("[...document.querySelectorAll('.ds-tasks')].map(w => [...w.querySelectorAll('label')].map(l => l.firstChild.textContent.trim()))")
        print("1. pannelli:", len(rows), "| righe del primo:", rows[0] if rows else None)
        await pp.select_option(".ds-tasks .ds-task-ipa >> nth=0", "local"); await pp.wait_for_timeout(300)
        await pp.select_option(".ds-tasks .ds-task-clean >> nth=0", "gemini"); await pp.wait_for_timeout(300)
        await pp.select_option(".ds-tasks .ds-task-video >> nth=0", "gemini"); await pp.wait_for_timeout(600)
        print("2. salvato:", await sw.evaluate("chrome.storage.sync.get(['ipaEngine','cleanEngine','engine','alignEngine']).then(r=>JSON.stringify(r))"))
        print("   tendina «Come tradurre»:", await pp.evaluate("(document.getElementById('engine')||{}).value"),
              "| altro pannello segue:", await pp.evaluate("[...document.querySelectorAll('.ds-tasks .ds-task-video')].map(s=>s.value)"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# Prove della 1.7: lingua della trascrizione fissata, trascrizione salvata e ripresa, scelte originale/traduzione
import sys, os, json, time, shutil, re, urllib.parse
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
from resources.lib import core
calls = []
tr = lambda x: " ".join(w[::-1] for w in x.split())
DA = ["hvor skal du hen i aften", "jeg skal hjem til min mor", "det er langt herfra", "ja men toget kører snart",
      "vi ses i morgen tidlig", "husk at tage jakken med"]
EN = ["where are you going tonight", "I am going home to my mother", "that is far from here", "yes but the train leaves soon",
      "see you early tomorrow", "remember to take the jacket"]
MODE = {"whisper": "translate_when_free", "fail_tr": False}
def field(data, name):
    m = re.search(rb'name="%s"\r\n\r\n([^\r]*)' % name.encode(), data or b"")
    return m.group(1).decode() if m else ""
def fake_http(url, data=None, headers=None, timeout=90):
    calls.append(url.split("?")[0])
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        if MODE["fail_tr"] and "\n" in q:   # Google salta qualche riga nei gruppi
            return 200, json.dumps([[["\n".join("" if i % 3 == 0 else "IT[" + tr(l) + "]" for i, l in enumerate(q.split("\n"))), q]], None, "da"]).encode(), {}
        return 200, json.dumps([[["\n".join("IT[" + tr(l) + "]" for l in q.split("\n")), q]], None, "da"]).encode(), {}
    if "audio/transcriptions" in url:
        lang = field(data, "language")
        piece = int(re.search(rb'filename="pezzo(\d+)', data).group(1))
        calls.append("whisper:%d:%s:%s" % (piece, lang or "-", field(data, "model")))
        # senza lingua imposta Whisper "sbaglia": riconosce il danese ma scrive in inglese (= traduce)
        lines = DA if lang == "da" else EN
        det = "danish" if MODE["whisper"] == "translate_when_free" else "english"   # "english": la riconosce male
        segs = [{"start": k * 8 + 0.5, "end": k * 8 + 6, "text": " " + lines[(piece * 2 + k) % 6] + ".", "no_speech_prob": 0.02, "avg_logprob": -0.3}
                for k in range(6)]
        return 200, json.dumps({"language": lang and {"da": "danish"}.get(lang, lang) or det, "segments": segs}).encode(), {}
    if "cinemeta" in url and "/meta/" in url:
        return 200, json.dumps({"meta": {"country": "Denmark", "name": "Film danese"}}).encode(), {}
    if url.startswith("https://opensubtitles-v3.strem.io/") or "cinemeta" in url:
        return 200, json.dumps({"subtitles": [], "metas": []}).encode(), {}
    return 404, b"", {}
core.http = fake_http
# tre pezzi da 10 minuti finti (ffmpeg non serve)
def fake_pieces(ffmpeg, media, workdir, piece_sec=600, stream=0):
    out = []
    for i in range(3):
        p = os.path.join(workdir, "pezzo%03d.ogg" % i); open(p, "wb").write(b"OggS" + bytes(100)); out.append(p)
    return out
core.extract_audio_pieces = fake_pieces
core.find_ffmpeg = lambda c="": "/usr/bin/ffmpeg"
core.audio_streams = lambda ffmpeg, media: AUDIO_STREAMS.get("v", [])
AUDIO_STREAMS = {}
from resources.lib import runner
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra",
                           "trans_color": "FFFF00", "auto": "true", "groq_key": "gsk_test", "stt": "groq (gratis con chiave)",
                           "stt_lang": "auto", "source_mode": "trascrizione (sempre l'audio, salvata: si fa una volta sola)"})
def play(url):
    xbmc.Player.playing_file = url
    xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": url, "at": time.time() - 20})
    xbmc.Player.subs.clear(); xbmcgui.NOTES.clear(); calls.clear(); xbmc.LOG.clear()
def shown():
    return open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
W = lambda: [c for c in calls if c.startswith("whisper:")]

# 1. film danese, Kodi non conosce la lingua dell'audio: il primo pezzo lo riconosce come danese ma lo scrive in inglese
play("https://22-4.download.real-debrid.com/d/AAAA/Festen.1998.Danish.1080p.mkv")
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.IMDBNumber": "tt0154420"})
runner.run(xbmc.Player(), interactive=True)
t = shown()
print("1. senza lingua nota: richieste", W())
print("   trascritto in danese:", sum(t.count(x) for x in DA), "frasi | in inglese:", sum(t.count(x) for x in EN), "| avviso:", xbmcgui.NOTES[-1:])
# 2. stesso film, nuovo indirizzo di Real-Debrid: trascrizione già salvata
play("https://45-1.download.real-debrid.com/d/ZZZZ/Festen.1998.Danish.1080p.mkv")
runner.run(xbmc.Player(), interactive=True)
print("2. rivisto con un altro indirizzo: richieste a Whisper", len(W()), "| sottotitoli:", bool(shown()))
# 3. traccia audio indicata da Kodi ("dan"): la lingua è imposta fin dal primo pezzo; modello preciso
play("https://22-4.download.real-debrid.com/d/BBBB/Jagten.2012.mkv")
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.AudioLanguage": "dan"})
runner.run(xbmc.Player(), interactive=True)
print("3. con la lingua della traccia audio:", W())
# 4. trascrizione interrotta dopo il primo pezzo: la volta dopo riprende dal secondo
play("https://22-4.download.real-debrid.com/d/CCCC/Druk.2020.mkv")
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.AudioLanguage": "dan"})
orig_req = core.whisper_request
def stop_after_one(path, settings, language="", prompt=""):
    r = orig_req(path, settings, language, prompt)
    if len(W()) >= 1: xbmc.Player.playing = False
    return r
core.whisper_request = stop_after_one
runner.run(xbmc.Player(), interactive=True)
core.whisper_request = orig_req; xbmc.Player.playing = True
first = W()
calls.clear()
runner.run(xbmc.Player(), interactive=True)
print("4. interrotta:", first, "→ ripresa:", W(), "| frasi:", shown().count("-->"))
# 5. "Rifai la trascrizione da capo"
runner.forget_transcript(xbmc.Player.playing_file, runner.settings()); calls.clear()
runner.run(xbmc.Player(), interactive=True)
print("5. rifatta da capo: richieste", len(W()))
# 6. la traduzione c'è sempre: Google lascia vuote alcune frasi → riprovo quelle
for f in os.listdir(runner.CACHE):
    if not f.startswith(core.cache_key("trascrizione")[:0] or "x") and f.endswith(".json") and "trascr" not in f: pass
MODE["fail_tr"] = True
play("https://22-4.download.real-debrid.com/d/DDDD/Festen.1998.Danish.1080p.mkv")
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.IMDBNumber": "tt0154420"})
xbmcaddon.SETTINGS.update({"engine": "gemini (gratis con chiave, consigliato)", "gemini_key": ""})   # servizio che non funziona
runner.run(xbmc.Player(), interactive=True)
blocks = [b for b in shown().split("\n\n") if b.strip()]
MODE["fail_tr"] = False
print("6. frasi senza traduzione:", sum(1 for b in blocks if "<font" not in b), "su", len(blocks))
xbmcaddon.SETTINGS.update({"engine": "google (gratis, senza chiave)"})
# 7. scelta per questo video dal menu: originale da file + traduzione già pronta; poi di nuovo trascrizione senza rifarla
os.makedirs("/tmp/kodi-film7", exist_ok=True)
def srt(lines, off=0):
    return "\n".join("%d\n00:00:%02d,500 --> 00:00:%02d,000\n%s\n" % (i + 1, off + i * 8, off + i * 8 + 6, l) for i, l in enumerate(lines))
open("/tmp/kodi-film7/Film.da.srt", "w").write(srt(DA))
open("/tmp/kodi-film7/Film.it.srt", "w").write(srt(["dove vai stasera", "vado a casa da mia madre", "è lontano da qui",
                                                  "sì ma il treno parte presto", "ci vediamo domattina presto", "ricordati la giacca"]))
open("/tmp/kodi-film7/Film.mkv", "w").write("x")
play("/tmp/kodi-film7/Film.mkv"); xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.AudioLanguage": "dan"})
xbmcgui.SELECT_SEQ = [2, 2, 0]
orig_select = xbmcgui.Dialog.select
def seq_select(self, h, opts):
    xbmcgui.SELECTS.append((h, opts)); return xbmcgui.SELECT_SEQ.pop(0)
xbmcgui.Dialog.select = seq_select
runner.choose_menu(xbmc.Player())
t = shown()
print("7. menu → titoli:", [h for h, _ in xbmcgui.SELECTS[-2:]])
print("   file + traduzione già pronta:", "vado a casa da mia madre" in t, "| Whisper:", len(W()))
xbmcgui.SELECT_SEQ = [1, 1]; calls.clear(); xbmc.Player.subs.clear()
runner.choose_menu(xbmc.Player())
t = shown()
print("   trascrizione + traduzione nuova:", "IT[" in t, "| Whisper:", len(W()), "| voce del menu:", xbmcgui.SELECTS[-2][1][1])
# la scelta resta per questo video: avvio automatico → trascrizione
calls.clear(); xbmc.Player.subs.clear()
runner.run(xbmc.Player())
print("   avvio automatico ricorda la scelta (trascrizione):", "IT[" in shown() and "<font" in shown(), "| Whisper:", len(W()))
xbmcgui.Dialog.select = orig_select

# 8. Whisper riconosce (male) l'inglese e scrive in inglese; Kodi non conosce la lingua dell'audio, ma il catalogo dice
#    che il film è danese: confronto le due versioni e tengo il danese per tutto il film
MODE["whisper"] = "english"
xbmcgui.Dialog.select = orig_select
xbmcaddon.SETTINGS.update({"source_mode": "trascrizione (sempre l'audio, salvata: si fa una volta sola)"})
play("https://22-4.download.real-debrid.com/d/EEEE/Druk.Another.Round.2020.mkv")
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.IMDBNumber": "tt10288566"})
runner.run(xbmc.Player(), interactive=True)
t = shown()
print("8. riconosciuto come inglese, film danese per il catalogo:", W())
print("   trascritto in danese:", sum(t.count(x) for x in DA), "| in inglese:", sum(t.count(x) for x in EN))

# PDF ceco con gli accenti scritti come caratteri a parte, prima della lettera (come fa LaTeX): ˇc = č, ´y = ý, ˚u = ů
def pdf(path):
    # codici 128-130 = accenti (caron, acute, ring) con /Differences
    line1 = b"(\\200cesk\\201y jazyk m\\202u\\200ze b\\201yt t\\200e\\200zk\\201y) Tj"
    line2 = b"[(Dobr\\201y) -250 (den,) -250 (\\200) 300 (c) (lov\\200eku.)] TJ"   # accento in un pezzo a parte
    stream = b"BT /F1 18 Tf 72 720 Td " + line1 + b" 0 -30 Td " + line2 + b" ET"
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
            b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding << /Type /Encoding /BaseEncoding /WinAnsiEncoding /Differences [128 /caron /acute /ring] >> >>"]
    out = b"%PDF-1.4\n"; offs = []
    for i, o in enumerate(objs, 1):
        offs.append(len(out)); out += str(i).encode() + b" 0 obj\n" + o + b"\nendobj\n"
    x = len(out)
    out += b"xref\n0 " + str(len(objs) + 1).encode() + b"\n0000000000 65535 f \n" + b"".join(b"%010d 00000 n \n" % o for o in offs)
    out += b"trailer\n<< /Size " + str(len(objs) + 1).encode() + b" /Root 1 0 R >>\nstartxref\n" + str(x).encode() + b"\n%%EOF\n"
    open(path, "wb").write(out)
pdf("/tmp/doc_cs.pdf"); print("creato /tmp/doc_cs.pdf")

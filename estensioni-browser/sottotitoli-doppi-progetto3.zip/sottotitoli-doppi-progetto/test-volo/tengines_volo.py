# Parole al Volo 1.9: stessi servizi di Sottotitoli Doppi nel popup; Gemini finito → Groq con avviso e "Riprova"; DeepL per le frasi
import asyncio, os, sys, json
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
os.environ["GEM_DAILY_429"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false, learnFreq:false}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza', groq:'gsk'}}))")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append("popup: " + str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(900)
        await pp.evaluate("document.getElementById('dAi').open=true")
        opts = await pp.evaluate("[...document.querySelectorAll('#enginesBox select option')].map(o=>o.value)")
        print("1. servizi nel popup:", opts)
        await pp.select_option("#enginesBox select", "gemini"); await pp.wait_for_timeout(500)
        print("   gemini: modello", await pp.input_value("#enginesBox input[list]"), "| chiave:", await pp.input_value("#enginesBox input[type=password]"), "| riserva:", await pp.inner_text("#enginesBox p.small >> nth=3"))
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "en", "bread", 2000)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.get_by_role("button", name="Spiega con Gemini").click(); await pg.wait_for_timeout(4000)
        t = await tvolo.card_text(pg)
        print("2. Gemini finito: richieste Gemini", len(tvolo.log.get("gem429", [])), "| spiegazione arrivata:", "pane (nel contesto)" in t, "| avviso:", [l for l in t.split("\n") if "finito" in l])
        await pp.reload(); await pp.wait_for_timeout(900); await pp.evaluate("document.getElementById('dAi').open=true")
        print("3. popup:", await pp.inner_text("#enginesBox .ds-blocked"))
        await pp.locator("#enginesBox .ds-blocked button").click(); await pp.wait_for_timeout(400)
        print("   dopo Riprova:", await sw.evaluate("chrome.storage.local.get('dsBlocked')"))
        # DeepL
        await sw.evaluate("chrome.storage.sync.set({engine:'deepl'}).then(()=>chrome.storage.local.get('keys')).then(r=>chrome.storage.local.set({keys:{...r.keys, deepl:'k:fx'}}))"); await pg.wait_for_timeout(400)
        await pg.keyboard.press("Escape")
        await tvolo.hover(pg, "long", "weather", 2500)
        print("4. DeepL frase:", await pg.evaluate("(document.querySelector('.pav-sentrans')||{}).textContent"), "| richieste DeepL:", tvolo.log.get("deepl"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

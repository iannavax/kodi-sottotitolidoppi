// Configurazione condivisa da pagina, popup e background.

// Interfaccia dell'estensione che restituisce promesse: "browser" in Firefox, "chrome" in Chrome ed Edge
var DS_EXT = typeof browser !== "undefined" && browser.runtime ? browser : chrome;
// Richiesta lunga al background (spiegazioni dei modelli, che sul computer possono metterci minuti): su una porta,
// con un segnale ogni 15 secondi perché il background non si spenga. Stessa risposta di runtime.sendMessage.
// spiegazione chiesta dalla scheda in corso (id del servizio e ora): la diretta aspetta a mandare altre frasi da
// tradurre allo stesso servizio, così un modello sul computer (Ollama, una richiesta alla volta) risponde prima a te
var dsUserLlm = { id: "", at: 0 };
// Correzione della trascrizione: "all" tutte le frasi, "uncertain" solo quelle di cui Whisper non è sicuro, "off" spenta
// (cleanTranscript: false delle versioni prima = spenta)
// «Quanto indietro guardi la diretta» (diretta sincronizzata): 20 / 45 / 90 / 120 s. Più indietro = pezzi d'audio più
// lunghi per Whisper e frasi tradotte a gruppi più grandi (aspettano fino a trBeforeS secondi prima di comparire).
function dsAheadStep(v) {
  const n = Number(v) || 20;
  return n >= 105 ? 120 : n >= 68 ? 90 : n >= 33 ? 45 : 20;
}
function dsAheadProfile(v) {
  return ({
    20: { minMs: 3500, maxMs: 9000, pieceS: "5-10", trBeforeS: 20, group: 12 },
    45: { minMs: 8000, maxMs: 16000, pieceS: "10-15", trBeforeS: 15, group: 14 },
    90: { minMs: 15000, maxMs: 25000, pieceS: "15-25", trBeforeS: 10, group: 18 },
    120: { minMs: 20000, maxMs: 29000, pieceS: "20-30", trBeforeS: 10, group: 24 }
  })[dsAheadStep(v)];
}
// Modelli per un compito («Modello per ogni compito»): taskModels["compito|servizio"] = un modello o un elenco in ordine.
// Vale per quel servizio quando fa quel compito (anche se ci arriva come automatico o di riserva). 1.6.1: quando un
// modello finisce le richieste di oggi si blocca solo quel modello (dsBlocked["servizio|modello"]) e si passa al
// successivo dell'elenco: prima quelli scelti da te, poi quello del servizio, poi i suggeriti per quel tipo di compito
// (DS_MODEL_CHAINS). Solo quando sono finiti tutti si passa a un altro servizio.
// Compiti: engine (sottotitoli dei video), pavEngine (pagine), explainEngine (spiegazioni ed etimologie),
// cleanEngine (correzione della trascrizione), alignEngine (collegamento parole e modi di dire), ipaEngine (pronuncia).
var DS_MODEL_CHAINS = {
  gemini: { bulk: ["gemini-flash-lite-latest", "gemini-flash-latest"], quality: ["gemini-flash-latest", "gemini-flash-lite-latest"] },
  mistral: { bulk: ["mistral-small-latest", "mistral-medium-latest"], quality: ["mistral-medium-latest", "mistral-large-latest", "mistral-small-latest"] }
};
var DS_QUALITY_TASKS = ["explainEngine", "ipaEngine"];
const dsIsLlmE = (E) => !!E && (E.kind === "openai" || E.kind === "claude");
// i modelli che hai scelto per un compito (anche quelli vecchi, salvati come un modello solo)
function dsTaskList(s, task, id) {
  const v = ((s && s.taskModels) || {})[task + "|" + id];
  return (Array.isArray(v) ? v : v ? [v] : []).map((m) => String(m || "").trim()).filter(Boolean);
}
// tutti i modelli da provare in ordine, per quel compito e quel servizio
function dsModelChain(s, task, id) {
  const E = DS_CONFIG.ENGINES[id];
  if (!E) return [];
  const base = ((s && s.models) || {})[id] || E.defaultModel || "";
  const hints = (DS_MODEL_CHAINS[id] || {})[DS_QUALITY_TASKS.includes(task) ? "quality" : "bulk"] || [];
  return [...new Set([...dsTaskList(s, task, id), base, ...hints].filter(Boolean))];
}
// il motore con il primo modello non finito per quel compito; exhausted: tutti i modelli del servizio sono finiti oggi
// (blocked(servizio, modello): true se quel modello ha finito le richieste di oggi)
function dsTaskModel(s, task, e, blocked) {
  if (!e || !e.E || !dsIsLlmE(e.E)) return e;
  const chain = dsModelChain(s, task, e.id);
  const ok = chain.find((m) => !(blocked && blocked(e.id, m)));
  if (!ok) return { ...e, exhausted: true, model: e.model || chain[0] || "" };
  return ok === e.model && !e.exhausted ? e : { ...e, model: ok, exhausted: false };
}
// Stato di oggi di un servizio (map = dsBlocked, day = giorno delle quote): models = i suoi modelli finiti oggi,
// all = finito tutto (il servizio intero, o tutti i modelli che si possono provare)
function dsBlockState(map, id, s, day) {
  const on = (k) => !!(map && map[k] && map[k].day === day && (!map[k].ttl || Date.now() - map[k].at < map[k].ttl));
  const E = DS_CONFIG.ENGINES[id];
  if (!E) return { all: false, models: [] };
  const llm = dsIsLlmE(E) && !E.local;
  if (!llm) return { all: on(id), models: [] };
  const models = Object.keys(map || {}).filter((k) => k.startsWith(id + "|") && on(k)).map((k) => k.slice(id.length + 1));
  const chain = [...new Set([...dsModelChain(s, "engine", id), ...dsModelChain(s, "explainEngine", id)])];
  return { all: chain.length > 0 && chain.every((m) => models.includes(m)), models };
}
// «Riprova adesso»: toglie i blocchi di oggi del servizio e di tutti i suoi modelli
function dsUnblock(map, id) {
  const m = { ...(map || {}) };
  for (const k of Object.keys(m)) if (k === id || k.startsWith(id + "|")) delete m[k];
  return m;
}

// 1.7.14: le varianti (dialetti, accenti riconosciuti) di cui Wiktionary dà la pronuncia IPA, per lingua: [id, nome, riconoscimento
// dell'etichetta di Wiktionary]. Le etichette che non riconosco si mostrano comunque, con il nome scritto da Wiktionary.
// Servono alla scheda (learn.js) e al menu «Pronuncia IPA nelle varianti» del popup (si sceglie quali vedere per ogni lingua: sync ipaVar).
var DS_DIALECTS = {
  en: [["us", "🇺🇸 americano", /\b(US|U\.S\.|General American|GenAm|GA|American|California|New York|Midwest|Southern US|Boston|Inland North|African.American)\b/i],
    ["uk", "🇬🇧 britannico (Inghilterra)", /\b(UK|RP|Received Pronunciation|British|England|Southern England|Standard Southern|Cockney|Estuary|Northern England|Yorkshire|Geordie|Scouse|GB)\b/i],
    ["ie", "🇮🇪 irlandese", /Ireland|Irish|Hiberno|Dublin|Ulster/i], ["sc", "🏴 scozzese", /Scot/i], ["wa", "🏴 gallese", /Wales|Welsh/i],
    ["au", "🇦🇺 australiano", /Australia|\bAU\b/i], ["nz", "🇳🇿 neozelandese", /New Zealand|\bNZ\b/i], ["ca", "🇨🇦 canadese", /Canad/i],
    ["za", "🇿🇦 sudafricano", /South Africa|\bSAE\b/i], ["in", "🇮🇳 indiano", /\bIndia|Indian English/i], ["sg", "🇸🇬 singaporiano", /Singapore/i],
    ["ng", "🇳🇬 nigeriano", /Nigeria/i], ["jm", "🇯🇲 giamaicano", /Jamaica/i]],
  pt: [["br", "🇧🇷 brasiliano", /Brazil|\bBR\b|São Paulo|Rio de Janeiro|Carioca|Paulista|Caipira|Gaúcho|Nordeste/i], ["pt", "🇵🇹 europeo (Portogallo)", /Portugal|\bPT\b|Lisbon|Lisboa|European|Europe|Porto\b|Alentejo|Madeira|Azores/i],
    ["ao", "🇦🇴 angolano", /Angola/i], ["mz", "🇲🇿 mozambicano", /Mozambique|Moçambique/i], ["cv", "🇨🇻 capoverdiano", /Cape Verde|Cabo Verde/i],
    ["gw", "🇬🇼 guineano (Guinea-Bissau)", /Guinea/i], ["st", "🇸🇹 di São Tomé", /São Tomé/i], ["tl", "🇹🇱 timorese", /Timor/i], ["af", "🌍 africano (altro)", /Africa/i]],
  fr: [["fr", "🇫🇷 europeo (Francia)", /France|Paris|Europe|Metropolitan|Standard French|Hexagon/i], ["be", "🇧🇪 belga", /Belgi|Wallon/i], ["ch", "🇨🇭 svizzero", /Switzerland|Swiss|Suisse|Romandy/i],
    ["ca", "🇨🇦 canadese (Québec)", /Canad|Qu[eé]bec|Acadian/i], ["af", "🌍 africano", /Africa|Senegal|Côte|Cameroon|Congo|Maghreb|Algeria|Morocco|Tunisia/i]],
  es: [["es", "🇪🇸 spagnolo (Spagna)", /Spain|Castil|Peninsular|Madrid|Andalus|Seville|Canar/i], ["mx", "🇲🇽 messicano", /Mexic/i], ["ar", "🇦🇷 argentino / rioplatense", /Argentin|Rioplatense|Uruguay|Buenos Aires/i],
    ["co", "🇨🇴 colombiano", /Colombia/i], ["cl", "🇨🇱 cileno", /Chile/i], ["pe", "🇵🇪 peruviano", /Peru/i], ["ve", "🇻🇪 venezuelano", /Venezuela/i], ["cu", "🇨🇺 caraibico", /Caribbean|Cuba|Puerto Rico|Dominican/i],
    ["us", "🇺🇸 ispano-americano (USA)", /United States|\bUS\b/i], ["la", "🌎 America Latina (in generale)", /Latin America|American Spanish|Central America/i]],
  de: [["de", "🇩🇪 Germania", /Germany|Standard German|Hochdeutsch|Northern|Bühnen/i], ["at", "🇦🇹 Austria", /Austria/i], ["ch", "🇨🇭 Svizzera", /Switzerland|Swiss/i]],
  nl: [["nl", "🇳🇱 Paesi Bassi", /Netherlands|Dutch|Standard Dutch/i], ["be", "🇧🇪 Belgio (Fiandre)", /Belgi|Flanders|Flemish/i], ["sr", "🇸🇷 Suriname", /Surinam/i]],
  it: [["it", "🇮🇹 standard", /Standard|Italy|Tuscan|Florence/i], ["ch", "🇨🇭 svizzero", /Switzerland|Swiss/i]],
  ca: [["cen", "Catalano centrale", /Central|Barcelona/i], ["val", "Valenzano", /Valencia/i], ["bal", "Balearico", /Balear|Mallorc|Menorc/i], ["nw", "Nord-occidentale", /North.?West|Western/i]],
  ro: [["ro", "🇷🇴 Romania", /Romania/i], ["md", "🇲🇩 Moldavia", /Moldova/i]],
  sr: [["ek", "Ekaviano", /Ekavian/i], ["ij", "Ijekaviano", /Ijekavian/i]],
  ru: [["ru", "🇷🇺 standard (Mosca)", /Moscow|Standard|Saint Petersburg/i]],
  ar: [["msa", "Standard moderno", /Modern Standard|MSA|Standard/i], ["eg", "🇪🇬 egiziano", /Egypt|Cairo/i], ["lev", "Levantino", /Levant|Syria|Lebanon|Palestin|Jordan|Damascus/i], ["gulf", "Del Golfo", /Gulf|Kuwait|Emirat|Qatar|Bahrain|Saudi|Najd|Hij/i], ["mag", "Maghrebino", /Morocc|Alger|Tunis|Libya|Maghreb/i], ["iq", "Iracheno", /Iraq/i]],
  zh: [["cmn", "Mandarino (Pechino)", /Mandarin|Standard Chinese|Pinyin|Beijing|Putonghua/i], ["tw", "Mandarino di Taiwan", /Taiwan/i], ["yue", "Cantonese", /Cantonese|Yue|Hong Kong|Guangzhou/i], ["nan", "Hokkien / Min Nan", /Min Nan|Hokkien|Teochew|Taiwanese/i], ["hak", "Hakka", /Hakka/i], ["wuu", "Wu (Shanghai)", /\bWu\b|Shanghai/i]],
  ko: [["seoul", "🇰🇷 Seoul (standard)", /Seoul|Standard/i], ["north", "🇰🇵 Nord", /North Korea|Pyongyang/i]],
  ja: [["tokyo", "Tokyo (standard)", /Tokyo|Standard/i], ["kansai", "Kansai", /Kansai|Osaka|Kyoto/i]],
  sv: [["sv", "🇸🇪 Svezia", /Sweden|Standard/i], ["fi", "🇫🇮 Finlandia", /Finland/i]],
  no: [["no", "🇳🇴 orientale (standard)", /Eastern|Oslo|Urban|Standard/i]],
  da: [["da", "🇩🇰 Danimarca", /Denmark|Standard|Copenhagen/i]],
  ms: [["my", "🇲🇾 Malesia", /Malaysia/i], ["id", "🇮🇩 Indonesia", /Indonesia/i]],
  hi: [["hi", "Standard", /Standard|Delhi/i]],
  el: [["el", "🇬🇷 Grecia", /Greece|Standard/i], ["cy", "🇨🇾 Cipro", /Cyprus/i]]
};
// la variante riconosciuta per un'etichetta di Wiktionary: { id, name } o null
function dsDialectOf(lang, label) {
  const hit = (DS_DIALECTS[String(lang || "").split("-")[0].toLowerCase()] || []).find(([, , re]) => label && re.test(label));
  return hit ? { id: hit[0], name: hit[1] } : null;
}
// modelli suggeriti nelle tendine di «Modello per ogni compito» (oltre a quelli trovati con «Carica modelli»)
var DS_MODEL_HINTS = {
  gemini: ["gemini-flash-lite-latest", "gemini-flash-latest", "gemini-pro-latest"],
  mistral: ["mistral-small-latest", "mistral-medium-latest", "mistral-large-latest"]
};
// ---------- «Consumo» (popup): quattro modalità, dalla migliore alla più economica ----------
// Ogni modalità imposta questi valori; se poi ne cambi uno a mano, il menu mostra «Personalizzato».
// consumo "free" in più: niente modelli né trascrizione automatica (solo Google Traduttore; i pulsanti funzionano).
var DS_CONSUMO = {
  quality: { liveAheadDelay: 20, cleanMode: "all", idioms: true, idiomAuto: true,
    tm: { "engine|gemini": "gemini-flash-latest", "cleanEngine|gemini": "gemini-flash-latest", "explainEngine|gemini": "gemini-flash-latest" } },
  balanced: { liveAheadDelay: 45, cleanMode: "uncertain", idioms: false, idiomAuto: false,
    tm: { "engine|gemini": "gemini-flash-lite-latest", "cleanEngine|gemini": "gemini-flash-lite-latest", "explainEngine|gemini": "gemini-flash-latest" } },
  saving: { liveAheadDelay: 90, cleanMode: "off", idioms: false, idiomAuto: false,
    tm: { "engine|gemini": "gemini-flash-lite-latest", "cleanEngine|gemini": "gemini-flash-lite-latest", "explainEngine|gemini": "gemini-flash-latest" } },
  free: { liveAheadDelay: 120, cleanMode: "off", idioms: false, idiomAuto: false,
    tm: { "engine|gemini": "gemini-flash-lite-latest", "cleanEngine|gemini": "gemini-flash-lite-latest", "explainEngine|gemini": "gemini-flash-latest" } }
};
// i valori da salvare per una modalità (taskModels: tengo le scelte per gli altri servizi)
function dsConsumoValues(mode, taskModels) {
  const m = DS_CONSUMO[mode];
  if (!m) return null;
  return { consumo: mode, liveAheadDelay: m.liveAheadDelay, cleanMode: m.cleanMode, cleanTranscript: m.cleanMode !== "off",
    idioms: m.idioms, idiomAuto: m.idiomAuto, taskModels: { ...(taskModels || {}), ...m.tm } };
}
// la modalità che corrisponde alle impostazioni di adesso ("custom" se qualcosa è stato cambiato a mano)
function dsConsumoOf(s) {
  const mode = s && DS_CONSUMO[s.consumo] ? s.consumo : "";
  const m = DS_CONSUMO[mode];
  if (!m) return "custom";
  const tm = s.taskModels || {};
  const same = dsAheadStep(s.liveAheadDelay) === m.liveAheadDelay && dsCleanMode(s) === m.cleanMode && (s.idioms === true) === m.idioms &&
    (s.idiomAuto === true) === m.idiomAuto && Object.entries(m.tm).every(([k, v]) => (tm[k] || "") === v);
  return same ? mode : "custom";
}
const dsFreeOnly = (s) => !!s && s.consumo === "free";
function dsCleanMode(s) {
  if (!s || s.cleanTranscript === false || dsFreeOnly(s)) return "off";
  return s.cleanMode === "all" || s.cleanMode === "off" ? s.cleanMode : "uncertain";
}
function dsUserLlmBusy(id) { return !!id && dsUserLlm.id === id && Date.now() - dsUserLlm.at < 180000; }
// 1.6.6: scheda spostabile col mouse. La maniglia ⠿ in cima alla scheda si trascina; doppio clic = torna al posto di prima.
// La posizione scelta si ricorda (storage.local cardUser = { video: {fx, fy}, page: {x, y} }) e vale per le schede dopo.
// o: { start() → stato, move(stato, dx, dy), end(stato), reset() }
var dsCardUser = {};
try {
  DS_EXT.storage.local.get({ cardUser: {} }).then((r) => { dsCardUser = r.cardUser || {}; }).catch(() => {});
  DS_EXT.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.cardUser) dsCardUser = ch.cardUser.newValue || {}; });
} catch {}
function dsCardUserSet(key, val) {
  dsCardUser = { ...dsCardUser };
  if (val) dsCardUser[key] = val; else delete dsCardUser[key];
  try { DS_EXT.storage.local.set({ cardUser: dsCardUser }).catch(() => {}); } catch {}
}
function dsCardGrip(cls, o) {
  const g = document.createElement("div");
  g.className = cls;
  g.textContent = "⠿⠿⠿";
  g.title = "Trascina per spostare la scheda dove vuoi (la posizione resta per le prossime). Doppio clic: torna al posto di prima";
  g.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    e.preventDefault(); e.stopPropagation();
    const x0 = e.clientX, y0 = e.clientY, s = o.start();
    let raf = 0, lx = x0, ly = y0;
    try { g.setPointerCapture(e.pointerId); } catch {}
    const mv = (ev) => { lx = ev.clientX; ly = ev.clientY; if (!raf) raf = requestAnimationFrame(() => { raf = 0; o.move(s, lx - x0, ly - y0); }); };
    const up = (ev) => {
      g.removeEventListener("pointermove", mv); g.removeEventListener("pointerup", up); g.removeEventListener("pointercancel", up);
      try { g.releasePointerCapture(ev.pointerId); } catch {}
      if (raf) { cancelAnimationFrame(raf); raf = 0; o.move(s, lx - x0, ly - y0); }
      if (o.end) o.end(s);
    };
    g.addEventListener("pointermove", mv); g.addEventListener("pointerup", up); g.addEventListener("pointercancel", up);
  });
  g.addEventListener("dblclick", (e) => { e.preventDefault(); e.stopPropagation(); if (o.reset) o.reset(); });
  for (const t of ["mousedown", "click"]) g.addEventListener(t, (e) => e.stopPropagation());
  return g;
}
function dsSendLong(msg) {
  return new Promise((resolve, reject) => {
    let port, done = false, ping = 0;
    const end = (fn, v) => { if (done) return; done = true; clearInterval(ping); try { port && port.disconnect(); } catch {} fn(v); };
    try { port = DS_EXT.runtime.connect({ name: "ds-long" }); } catch { DS_EXT.runtime.sendMessage(msg).then(resolve, reject); return; }
    port.onMessage.addListener((m) => { if (m && "res" in m) end(resolve, m.res); });
    port.onDisconnect.addListener(() => end(reject, new Error("l'estensione ha smesso di aspettare la risposta del modello: riprova")));
    try { port.postMessage(msg); } catch (e) { end(reject, e); return; }
    ping = setInterval(() => { try { port.postMessage({ ping: 1 }); } catch {} }, 15000);
  });
}

// 1.7.5: ridimensionare la scheda col mouse dai bordi e dagli angoli, come una finestra. Otto maniglie invisibili (fuori dalla scheda,
// perché la scheda scorre e le maniglie dentro scorrerebbero con il testo) che seguono il rettangolo della scheda.
//   o.start() → stato; o.apply(g, stato) con g = { l, t, w, h, dl, dt, r0 } (l,t = angolo in alto a sinistra sullo schermo;
//   dl,dt = quanto si è spostato rispetto all'inizio); o.end(g, stato); o.hold() quando il mouse arriva sul bordo; o.minW/minH/z
function dsCardResizer(card, o) {
  const parent = card.parentElement;
  if (!parent || card._rz) return card._rz || null;
  const wrap = document.createElement("div");
  wrap.className = "dsx-rz";
  const important = (css) => css.replace(/;/g, " !important;");
  wrap.style.cssText = important("position:absolute;left:0;top:0;width:0;height:0;margin:0;padding:0;border:0;pointer-events:none;z-index:" + (o.z || 2147483000) + ";");
  const DIRS = {   // nome → [posizione, cursore]
    n: ["left:16px;right:16px;top:-6px;height:12px;", "ns-resize"], s: ["left:16px;right:16px;bottom:-6px;height:12px;", "ns-resize"],
    e: ["top:16px;bottom:16px;right:-6px;width:12px;", "ew-resize"], w: ["top:16px;bottom:16px;left:-6px;width:12px;", "ew-resize"],
    nw: ["left:-7px;top:-7px;width:22px;height:22px;", "nwse-resize"], ne: ["right:-7px;top:-7px;width:22px;height:22px;", "nesw-resize"],
    sw: ["left:-7px;bottom:-7px;width:22px;height:22px;", "nesw-resize"], se: ["right:-7px;bottom:-7px;width:22px;height:22px;", "nwse-resize"]
  };
  const minW = o.minW || 200, minH = o.minH || 100;
  for (const [dir, [pos, cur]] of Object.entries(DIRS)) {
    const h = document.createElement("div");
    h.className = "dsx-rzh";
    h.style.cssText = important("position:absolute;" + pos + "cursor:" + cur + ";pointer-events:auto;touch-action:none;background:transparent;");
    h.title = "Trascina per ridimensionare la scheda (doppio clic sulla maniglia ⠿ in cima: torna alla grandezza di prima)";
    if (dir === "se") h.style.setProperty("background", "linear-gradient(135deg, transparent 0 55%, rgba(245,200,75,.85) 55% 62%, transparent 62% 72%, rgba(245,200,75,.85) 72% 79%, transparent 79%)", "important");
    h.addEventListener("pointerenter", () => { if (dir !== "se") h.style.setProperty("background", "rgba(245,200,75,.35)", "important"); });
    h.addEventListener("pointerleave", () => { if (dir !== "se") h.style.setProperty("background", "transparent", "important"); });
    h.addEventListener("pointerenter", () => { if (o.hold) o.hold(); });
    for (const t of ["mousedown", "click", "dblclick"]) h.addEventListener(t, (e) => e.stopPropagation());
    h.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      e.preventDefault(); e.stopPropagation();
      const r0 = card.getBoundingClientRect(), x0 = e.clientX, y0 = e.clientY, st = o.start ? o.start() : {};
      const maxW = Math.max(minW, (o.maxW ? o.maxW() : window.innerWidth) - 8), maxH = Math.max(minH, (o.maxH ? o.maxH() : window.innerHeight) - 8);
      let raf = 0, last = null, hTouched = false;
      try { h.setPointerCapture(e.pointerId); } catch {}
      const calc = (ev) => {
        const dx = ev.clientX - x0, dy = ev.clientY - y0;
        let w = r0.width, hh = r0.height;
        if (dir.includes("e")) w = r0.width + dx;
        if (dir.includes("w")) w = r0.width - dx;
        if (dir.includes("s")) hh = r0.height + dy;
        if (dir.includes("n")) hh = r0.height - dy;
        // non oltre i bordi dello schermo (4 px di margine): dal lato che si trascina la scheda può crescere solo fin lì
        const roomW = dir.includes("w") ? r0.right - 4 : dir.includes("e") ? window.innerWidth - r0.left - 4 : maxW;
        const roomH = dir.includes("n") ? r0.bottom - 4 : dir.includes("s") ? window.innerHeight - r0.top - 4 : maxH;
        w = Math.round(Math.max(minW, Math.min(maxW, roomW, w))); hh = Math.round(Math.max(minH, Math.min(maxH, roomH, hh)));
        if (dir.includes("n") || dir.includes("s")) hTouched = true;
        const dl = dir.includes("w") ? r0.width - w : 0, dt = dir.includes("n") ? r0.height - hh : 0;
        return { l: r0.left + dl, t: r0.top + dt, w, h: hh, dl, dt, r0, hTouched };
      };
      const frame = () => { raf = 0; if (last) { o.apply(last, st); wrap._sync(); } };
      const mv = (ev) => { last = calc(ev); if (!raf) raf = requestAnimationFrame(frame); };
      const up = (ev) => {
        h.removeEventListener("pointermove", mv); h.removeEventListener("pointerup", up); h.removeEventListener("pointercancel", up);
        try { h.releasePointerCapture(ev.pointerId); } catch {}
        if (raf) { cancelAnimationFrame(raf); raf = 0; }
        if (last) { o.apply(last, st); wrap._sync(); }
        if (o.end) o.end(last || calc(ev), st);
      };
      h.addEventListener("pointermove", mv); h.addEventListener("pointerup", up); h.addEventListener("pointercancel", up);
    });
    wrap.append(h);
  }
  // la maniglia segue la scheda (che si sposta, cresce, scorre la pagina…)
  wrap._sync = () => {
    if (!card.isConnected) return wrap._gone();
    const r = card.getBoundingClientRect();
    wrap.style.setProperty("left", "0px", "important"); wrap.style.setProperty("top", "0px", "important");
    const org = wrap.getBoundingClientRect();
    wrap.style.setProperty("left", Math.round(r.left - org.left) + "px", "important");
    wrap.style.setProperty("top", Math.round(r.top - org.top) + "px", "important");
    wrap.style.setProperty("width", Math.round(r.width) + "px", "important");
    wrap.style.setProperty("height", Math.round(r.height) + "px", "important");
  };
  let ro = null, mo = null;
  wrap._gone = () => { if (ro) ro.disconnect(); if (mo) mo.disconnect(); wrap.remove(); card._rz = null; };
  parent.append(wrap);
  if (typeof ResizeObserver === "function") { ro = new ResizeObserver(() => wrap._sync()); ro.observe(card); }
  mo = new MutationObserver(() => { if (!card.isConnected) wrap._gone(); });   // scheda chiusa: le maniglie spariscono con lei
  mo.observe(parent, { childList: true });
  wrap._sync();
  card._rz = wrap;
  return wrap;
}

// il pezzo di una voce della cache dell'etimologia: la lingua ("it|casa|en" → "it"; "defs1|it|casa" → "defs1.it")
const dsEtymShard = (k) => { const p = String(k).split("|"); return /^[a-z]+\d$/.test(p[0]) ? p[0] + "." + (p[1] || "?") : (p[0] || "?"); };
// 1.7.3: cache "a pezzi". Prima la pronuncia (30.000 parole) e l'etimologia (3.000 voci) stavano in UN solo oggetto che ogni scheda
// aperta riscriveva intero (megabyte) e che ogni pagina leggeva intero al caricamento, in ogni scheda del browser. Ora c'è un pezzo
// per lingua (chiave «prefisso:lingua»), letto solo quando serve e riscritto da solo se cambia. Stesse funzioni di una Map.
//   shardOf(chiave) → nome del pezzo; cap → voci massime per pezzo (le più vecchie, non «fixed», vanno via per prime)
function dsShardMap(prefix, cap, shardOf) {
  const maps = new Map(), loading = new Map(), dirty = new Set(), loadedSet = new Set();
  let timer = 0;
  const name = (sh) => prefix + ":" + sh;
  const mapOf = (sh) => { let m = maps.get(sh); if (!m) { m = new Map(); maps.set(sh, m); } return m; };
  function load(sh) {
    if (loading.has(sh)) return loading.get(sh);
    const p = DS_EXT.storage.local.get(name(sh)).then((r) => {
      const m = mapOf(sh);
      for (const [k, v] of Object.entries(r[name(sh)] || {})) if (!m.has(k)) m.set(k, v);   // quello già scritto in questa pagina vince
    }).catch(() => {}).then(() => { loadedSet.add(sh); });
    loading.set(sh, p);
    return p;
  }
  function trim(m) {
    if (m.size <= cap) return;
    for (const k of [...m.keys()]) { if (m.size <= cap) break; const v = m.get(k); if (!(v && v.fixed)) m.delete(k); }
  }
  async function flush() {
    clearTimeout(timer); timer = 0;
    const out = {};
    for (const sh of [...dirty]) { await load(sh); const m = mapOf(sh); trim(m); out[name(sh)] = Object.fromEntries(m); }
    dirty.clear();
    if (Object.keys(out).length) await DS_EXT.storage.local.set(out).catch(() => {});
  }
  const soon = (ms) => { clearTimeout(timer); timer = setTimeout(flush, ms); };
  const api = {
    get: (k) => { const sh = shardOf(k); if (!loading.has(sh)) load(sh); return mapOf(sh).get(k); },
    has: (k) => { const sh = shardOf(k); if (!loading.has(sh)) load(sh); return mapOf(sh).has(k); },
    set(k, v, ms) { const sh = shardOf(k); if (!loading.has(sh)) load(sh); mapOf(sh).set(k, v); dirty.add(sh); soon(ms == null ? 1500 : ms); return api; },
    delete(k) { const sh = shardOf(k); if (!loading.has(sh)) load(sh); mapOf(sh).delete(k); dirty.add(sh); soon(1500); },
    load: (k) => load(shardOf(k)),   // aspettare che il pezzo di questa chiave sia letto
    loadShard: load,                 // ... o di questo nome (la lingua)
    loaded: (k) => loadedSet.has(shardOf(k)),
    loadedShard: (sh) => loadedSet.has(sh),
    flush
  };
  return api;
}
// da chiamare dal sottofondo all'avvio: sposta le vecchie cache (un oggetto solo) nei pezzi per lingua e toglie la vecchia chiave.
// La pronuncia è solo una cache (si rifà gratis da Wiktionary): la butto. L'etimologia ha anche le TUE correzioni: la sposto.
async function dsMigrateShards() {
  try {
    const old = await DS_EXT.storage.local.get({ etymCache: null, ipaCache: null, explSaved: null });
    if (old.explSaved && typeof old.explSaved === "object") {   // le spiegazioni salvate sono tue: le sposto nei pezzi per lingua
      const by = {};
      for (const [k, arr] of Object.entries(old.explSaved)) { const sh = k.split("|")[0] || "?"; (by[sh] = by[sh] || {})[k] = arr; }
      const out = {};
      for (const [sh, obj] of Object.entries(by)) {
        const cur = (await DS_EXT.storage.local.get("expl:" + sh))["expl:" + sh] || {};
        out["expl:" + sh] = { ...obj, ...cur };
      }
      if (Object.keys(out).length) await DS_EXT.storage.local.set(out);
      await DS_EXT.storage.local.remove("explSaved");
    }
    if (old.ipaCache) await DS_EXT.storage.local.remove("ipaCache");
    if (old.etymCache && typeof old.etymCache === "object") {
      const by = {};
      for (const [k, v] of Object.entries(old.etymCache)) { const sh = dsEtymShard(k); (by[sh] = by[sh] || {})[k] = v; }
      const out = {};
      for (const [sh, obj] of Object.entries(by)) {
        const cur = (await DS_EXT.storage.local.get("etym:" + sh))["etym:" + sh] || {};
        const keys = Object.keys(obj);
        // al massimo 400 per lingua: le tue correzioni (fixed) prima di tutto
        const keep = [...keys.filter((k) => obj[k] && obj[k].fixed), ...keys.filter((k) => !(obj[k] && obj[k].fixed)).slice(-400)];
        out["etym:" + sh] = { ...Object.fromEntries(keep.map((k) => [k, obj[k]])), ...cur };
      }
      if (Object.keys(out).length) await DS_EXT.storage.local.set(out);
      await DS_EXT.storage.local.remove("etymCache");
    }
  } catch {}
}

var DS_CONFIG = {
  // nome inglese di una lingua (per i prompt). 1.6.2: per tutte le lingue di «Traduci in» (le altre da Intl)
  LANG_EN: new Proxy({
    it: "Italian", en: "English", es: "Spanish", fr: "French", de: "German", pt: "Portuguese",
    nl: "Dutch", pl: "Polish", ro: "Romanian", ru: "Russian", uk: "Ukrainian", tr: "Turkish",
    ar: "Arabic", hi: "Hindi", ja: "Japanese", ko: "Korean", "zh-Hans": "Simplified Chinese", "zh-Hant": "Traditional Chinese"
  }, {
    get(t, k) {
      if (k in t || typeof k !== "string" || !/^[a-z]{2,3}(-[A-Za-z]{2,4})?$/.test(k)) return t[k];
      try { const n = new Intl.DisplayNames(["en"], { type: "language" }).of(k); if (n && n !== k) return n; } catch {}
      return undefined;
    }
  }),
  // 1.6.2: tutte le lingue di Google Traduttore per «Traduci in» (codici di Google; zh-Hans/zh-Hant per il cinese)
  TARGET_LANGS: ["af", "sq", "am", "ar", "hy", "as", "ay", "az", "bm", "eu", "be", "bn", "bho", "bs", "bg", "ca", "ceb", "ny", "zh-Hans", "zh-Hant",
    "co", "hr", "cs", "da", "dv", "doi", "nl", "en", "eo", "et", "ee", "tl", "fi", "fr", "fy", "gl", "ka", "de", "el", "gn", "gu", "ht", "ha", "haw",
    "he", "hi", "hmn", "hu", "is", "ig", "ilo", "id", "ga", "it", "ja", "jv", "kn", "kk", "km", "rw", "gom", "ko", "kri", "ku", "ckb", "ky", "lo",
    "la", "lv", "ln", "lt", "lg", "lb", "mk", "mai", "mg", "ms", "ml", "mt", "mi", "mr", "mni-Mtei", "lus", "mn", "my", "ne", "no", "or", "om",
    "ps", "fa", "pl", "pt", "pa", "qu", "ro", "ru", "sm", "sa", "gd", "nso", "sr", "st", "sn", "sd", "si", "sk", "sl", "so", "es", "su", "sw",
    "sv", "tg", "ta", "tt", "te", "th", "ti", "ts", "tr", "tk", "ak", "uk", "ur", "ug", "uz", "vi", "cy", "xh", "yi", "yo", "zu"],

  SYNC_DEFAULTS: {
    enabled: true, targetLang: "it", hideNative: true, fontSize: 22,
    engine: "google", models: {}, localUrl: "http://localhost:11434/v1",
    autoTranscribe: true, transcribeMode: "live", fullMaxMin: 60, liveAhead: false, liveAheadDelay: 45, liveAheadMax: 90, hoverPause: true, ttsLang: "", ttsVoice: "", ttsSpeaches: false, ankiCharDeck: true,
    cardScale: 100, cardWidth: 100, cardBg: "#1d2430", cardText: "#eef1f5", cardAccent: "#f5c84b", cardOpacity: 1, cardPosVideo: "word", cardPosPage: "word",
    origColor: "#ffffff", transColor: "#f5c84b", bgOpacity: 0.75, subPos: 0, subFont: "default",
    subShow: "both", transFirst: false, transScale: 90, disabledSites: [], stt: "groq", sttModel: "whisper-large-v3-turbo",
    sttUrl: "http://localhost:8000/v1", sttLang: "", cleanTranscript: true, cleanMode: "uncertain", idioms: false, idiomsUnderline: true, idiomAuto: false,
    fallback: true, engineOrder: [], engineOff: [], consumo: "balanced", taskModels: { "engine|gemini": "gemini-flash-lite-latest", "cleanEngine|gemini": "gemini-flash-lite-latest", "explainEngine|gemini": "gemini-flash-latest" }, dailyCap: {}, explainEngine: "", cleanEngine: "", ipaEngine: "", alignEngine: "", msRegion: "", ipa: true, etym: true,
    // strumenti per imparare (versione di prova)
    vodBack: 20, learnFreq: true, learnNgram: true, learnKnown: true, learnExamples: true, learnAudio: true, learnTable: true, learnGender: true, learnDialects: true, ipaVar: {}, cleanAsr: false, useSavedTranscript: true, videoModeSticky: "",
    learnSpell: true, learnLlmExtra: true, learnJisho: true, learnGweb: true, learnHan: true, uiLang: false, ankiImage: false, ankiImageSource: "auto", ankiImageLang: "word", learnKnownPage: true, roman: false, romanHan: true, romanSize: 65, romanLineSize: 80,
    gdAlt: true, gdDefs: true, gdSyn: true, gdSpell: true,   // dizionario di Google
    // Anki con AnkiConnect: un mazzo per lingua (stessi mazzi di Parole al Volo: "Lingue::Inglese"…)
    ankiDeck: "Sottotitoli Doppi", ankiPerLang: true, ankiLangDeck: "Lingue::{lingua}", ankiAuto: false, ankiModel: "", ankiAudio: true
  },

  // sigle ISO 639-3 (Tatoeba)
  LANG3: { en: "eng", it: "ita", cs: "ces", sk: "slk", de: "deu", fr: "fra", es: "spa", pt: "por", ru: "rus", uk: "ukr", pl: "pol",
    nl: "nld", da: "dan", sv: "swe", no: "nob", nb: "nob", fi: "fin", hu: "hun", ro: "ron", el: "ell", tr: "tur", ja: "jpn", zh: "cmn",
    ko: "kor", ar: "ara", he: "heb", hi: "hin", bg: "bul", hr: "hrv", sr: "srp", sl: "slv", lt: "lit", lv: "lvs", et: "est", ca: "cat",
    eo: "epo", la: "lat", fa: "pes", vi: "vie", id: "ind", th: "tha", is: "isl", ga: "gle", be: "bel", ka: "kat", hy: "hye" },
  // lingue controllate da LanguageTool
  LT_LANGS: { en: "en-US", de: "de-DE", fr: "fr", es: "es", it: "it", pt: "pt-PT", nl: "nl", pl: "pl-PL", ru: "ru-RU", uk: "uk-UA",
    sk: "sk-SK", sl: "sl-SI", ca: "ca-ES", da: "da-DK", sv: "sv", el: "el-GR", ro: "ro-RO", ja: "ja-JP", zh: "zh-CN", fa: "fa",
    ar: "ar", ga: "ga-IE", gl: "gl-ES", eo: "eo", be: "be-BY", br: "br-FR", ta: "ta-IN", tl: "tl-PH", km: "km-KH", no: "nb", nb: "nb" },

  STT_MODELS: ["whisper-large-v3-turbo", "whisper-large-v3"],

  HOSTS: [
    "<all_urls>",
    "https://www.youtube.com/*",
    "https://translate.googleapis.com/*",
    "https://translate.google.com/*",
    "https://generativelanguage.googleapis.com/*",
    "https://api.groq.com/*",
    "https://openrouter.ai/*",
    "https://api-free.deepl.com/*",
    "https://api.deepl.com/*",
    "https://api.anthropic.com/*",
    "https://api.mistral.ai/*",
    "https://api.cognitive.microsofttranslator.com/*",
    "http://localhost/*",
    "http://127.0.0.1/*"
  ],

  // kind: google | openai (qualsiasi servizio compatibile OpenAI) | deepl | claude | youtube
  ENGINES: {
    google: {
      label: "Google Traduttore, frasi intere (gratis)",
      note: "Nessuna chiave da configurare. Traduce ogni frase da sola, senza guardare il discorso.",
      kind: "google", chunk: { count: 12, chars: 1200 }
    },
    gemini: {
      label: "Gemini, contestuale (gratis con chiave)",
      note: "La chiave si crea gratis su Google AI Studio, senza carta. Consigliato: capisce il discorso. Flash-Lite è il modello con più richieste gratuite al giorno.",
      kind: "openai", base: "https://generativelanguage.googleapis.com/v1beta/openai",
      needsKey: true, keyUrl: "https://aistudio.google.com/apikey",
      defaultModel: "gemini-flash-lite-latest", modelMatch: "gemini.*flash",
      prefer: ["flash-lite-latest", "flash-lite", "flash-latest", "flash"],
      // 1.6.2: senza ragionamento (prima "low"): con Gemini Flash il ragionamento consumava i token della risposta e la
      // spiegazione arrivava tagliata. Se un modello non lo accetta, llmText riprova senza
      extra: { reasoning_effort: "none" },
      chunk: { count: 120, chars: 14000 }, maxTokens: 16384, minIntervalMs: 6500, cache: true
    },
    groq: {
      label: "Groq, contestuale (gratis con chiave)",
      note: "La chiave si crea gratis su console.groq.com, senza carta. Molto veloce.",
      kind: "openai", base: "https://api.groq.com/openai/v1",
      needsKey: true, keyUrl: "https://console.groq.com/keys",
      defaultModel: "llama-3.3-70b-versatile", modelExclude: "whisper|tts|guard|playai|orpheus|prompt",
      prefer: ["llama-3.3-70b", "gpt-oss-120b", "qwen"],
      chunk: { count: 35, chars: 5000 }, minIntervalMs: 2200, cache: true
    },
    openrouter: {
      label: "OpenRouter, modelli gratuiti (con chiave)",
      note: "La chiave si crea gratis su openrouter.ai. Usa solo i modelli che finiscono in :free. Ci sono poche decine di richieste al giorno.",
      kind: "openai", base: "https://openrouter.ai/api/v1",
      needsKey: true, keyUrl: "https://openrouter.ai/keys",
      defaultModel: "", modelMatch: ":free$",
      prefer: ["deepseek", "llama-3.3-70b", "gemma-3-27b", "qwen", "mistral"],
      chunk: { count: 80, chars: 10000 }, minIntervalMs: 3500, cache: true
    },
    mistral: {
      label: "Mistral, contestuale (gratis con chiave)",
      note: "La chiave si crea gratis su console.mistral.ai (piano Experiment, serve solo un numero di telefono). Buona qualità in molte lingue europee.",
      kind: "openai", base: "https://api.mistral.ai/v1",
      needsKey: true, keyUrl: "https://console.mistral.ai/api-keys",
      defaultModel: "mistral-small-latest", modelExclude: "embed|moderation|ocr|codestral|devstral|voxtral|pixtral",
      prefer: ["mistral-small-latest", "mistral-medium-latest", "mistral-large-latest"],
      chunk: { count: 80, chars: 10000 }, minIntervalMs: 1500, cache: true
    },
    microsoft: {
      label: "Microsoft Translator (gratis con chiave, 2 milioni di caratteri al mese)",
      note: "Traduttore classico, più preciso di Google, senza limiti al minuto. Serve un account Azure gratuito: crea una risorsa \"Translator\" con il piano F0 e copia qui la chiave e l'area (per esempio westeurope).",
      kind: "microsoft", needsKey: true, keyUrl: "https://portal.azure.com/#create/Microsoft.CognitiveServicesTextTranslation",
      chunk: { count: 100, chars: 9000 }, minIntervalMs: 300, cache: true
    },
    deepl: {
      label: "DeepL (piano gratuito con chiave)",
      note: "Qualità molto alta. Il piano API Free ha un limite mensile di caratteri e alla registrazione chiede una carta per la verifica.",
      kind: "deepl", needsKey: true, keyUrl: "https://www.deepl.com/pro-api",
      chunk: { count: 25, chars: 5000 }, minIntervalMs: 500, cache: true
    },
    local: {
      label: "Modello sul tuo computer (Ollama o LM Studio)",
      note: "Gratis, senza limiti e privato. Il programma deve essere avviato e configurato come spiegato nel file LEGGIMI.",
      kind: "openai", local: true, defaultModel: "",
      // niente «Thinking…» (Gemma 4, Qwen 3, DeepSeek…): per tradurre e spiegare il ragionamento è solo tempo perso.
      // Se il programma non accetta questi parametri si riprova senza (llmText)
      extra: { reasoning_effort: "none", think: false },
      prefer: ["gemma4", "gemma3:12b", "gemma3", "qwen3", "qwen2.5", "qwen", "mistral", "llama3"], modelExclude: "embed|whisper|tts|rerank",
      chunk: { count: 15, chars: 2500 }, cache: true
    },
    claude: {
      label: "Claude, contestuale (a pagamento)",
      note: "La chiave si crea su console.anthropic.com. Costa pochi centesimi a video.",
      kind: "claude", needsKey: true, keyUrl: "https://console.anthropic.com",
      defaultModel: "claude-haiku-4-5-20251001", staticModels: ["claude-haiku-4-5-20251001", "claude-sonnet-5"],
      chunk: { count: 100, chars: 12000 }, cache: true
    },
    youtube: {
      label: "YouTube, riga per riga",
      note: "La modalità della prima versione: veloce ma poco precisa.",
      kind: "youtube"
    }
  },

  // Quando un servizio finisce le richieste gratuite si continua con il primo di questi di cui hai la chiave
  FALLBACK: ["gemini", "groq", "mistral", "openrouter", "microsoft", "deepl"],
  // Tutti i servizi che si possono mettere in fila (popup → «Ordine dei servizi»): l'ordine scelto vale per i servizi
  // di riserva, per «✨ Spiega con…», per la pronuncia e per la correzione della trascrizione
  ORDERABLE: ["gemini", "groq", "mistral", "openrouter", "local", "claude", "microsoft", "deepl"],
  // la fila nell'ordine scelto, senza quelli spenti (s = impostazioni con engineOrder ed engineOff)
  engineOrder(s, all) {
    const o = ((s && s.engineOrder) || []).filter((id) => DS_CONFIG.ORDERABLE.includes(id));
    const off = new Set((s && s.engineOff) || []);
    const list = [...o, ...DS_CONFIG.ORDERABLE.filter((id) => !o.includes(id))];
    return all ? list : list.filter((id) => !off.has(id));
  },

  // Tutte le lingue che Whisper sa trascrivere (codice → nome inglese, come lo restituisce Whisper)
  STT_LANGS: {
    en: "english", zh: "chinese", de: "german", es: "spanish", ru: "russian", ko: "korean",
    fr: "french", ja: "japanese", pt: "portuguese", tr: "turkish", pl: "polish", ca: "catalan",
    nl: "dutch", ar: "arabic", sv: "swedish", it: "italian", id: "indonesian", hi: "hindi",
    fi: "finnish", vi: "vietnamese", he: "hebrew", uk: "ukrainian", el: "greek", ms: "malay",
    cs: "czech", ro: "romanian", da: "danish", hu: "hungarian", ta: "tamil", no: "norwegian",
    th: "thai", ur: "urdu", hr: "croatian", bg: "bulgarian", lt: "lithuanian", la: "latin",
    mi: "maori", ml: "malayalam", cy: "welsh", sk: "slovak", te: "telugu", fa: "persian",
    lv: "latvian", bn: "bengali", sr: "serbian", az: "azerbaijani", sl: "slovenian", kn: "kannada",
    et: "estonian", mk: "macedonian", br: "breton", eu: "basque", is: "icelandic", hy: "armenian",
    ne: "nepali", mn: "mongolian", bs: "bosnian", kk: "kazakh", sq: "albanian", sw: "swahili",
    gl: "galician", mr: "marathi", pa: "punjabi", si: "sinhala", km: "khmer", sn: "shona",
    yo: "yoruba", so: "somali", af: "afrikaans", oc: "occitan", ka: "georgian", be: "belarusian",
    tg: "tajik", sd: "sindhi", gu: "gujarati", am: "amharic", yi: "yiddish", lo: "lao",
    uz: "uzbek", fo: "faroese", ht: "haitian creole", ps: "pashto", tk: "turkmen", nn: "nynorsk",
    mt: "maltese", sa: "sanskrit", lb: "luxembourgish", my: "myanmar", bo: "tibetan", tl: "tagalog",
    mg: "malagasy", as: "assamese", tt: "tatar", ln: "lingala", ha: "hausa", ba: "bashkir",
    jw: "javanese", su: "sundanese"
  },

  // Lingue per cui la voce online di Google esiste (le altre si pronunciano solo con una voce del computer)
  GOOGLE_TTS: ["af", "am", "ar", "bg", "bn", "bs", "ca", "cs", "cy", "da", "de", "el", "en", "es", "et", "eu", "fi", "fr", "gl",
    "gu", "ha", "he", "hi", "hr", "hu", "id", "is", "it", "ja", "jw", "km", "kn", "ko", "la", "lt", "lv", "ml", "mr", "ms", "my",
    "ne", "nl", "no", "pa", "pl", "pt", "ro", "ru", "si", "sk", "sq", "sr", "su", "sv", "sw", "ta", "te", "th", "tl", "tr", "uk",
    "ur", "vi", "zh"],

  // Nomi delle lingue come li restituisce Whisper → codici
  WHISPER_LANGS: {
    english: "en", italian: "it", spanish: "es", french: "fr", german: "de", portuguese: "pt",
    dutch: "nl", polish: "pl", romanian: "ro", russian: "ru", ukrainian: "uk", turkish: "tr",
    arabic: "ar", hindi: "hi", japanese: "ja", korean: "ko", chinese: "zh",
    greek: "el", czech: "cs", swedish: "sv", danish: "da", norwegian: "no", finnish: "fi",
    hungarian: "hu", hebrew: "he", indonesian: "id", malay: "ms", vietnamese: "vi", thai: "th",
    catalan: "ca", croatian: "hr", serbian: "sr", slovak: "sk", slovenian: "sl", bulgarian: "bg",
    persian: "fa", urdu: "ur", bengali: "bn", tamil: "ta", tagalog: "tl", swahili: "sw",
    castilian: "es", flemish: "nl", valencian: "ca", moldavian: "ro", sinhalese: "si", pushto: "ps", burmese: "my",
    "haitian creole": "ht", haitian: "ht", nynorsk: "nn", luxembourgish: "lb", letzeburgesch: "lb", panjabi: "pa", mandarin: "zh"
  },

  // Frasi per provare la voce dal popup
  TTS_SAMPLES: {
    en: "Hello, how are you today?", it: "Ciao, come stai oggi?", es: "Hola, ¿cómo estás hoy?",
    fr: "Bonjour, comment ça va aujourd'hui ?", de: "Hallo, wie geht es dir heute?", pt: "Olá, como você está hoje?",
    nl: "Hallo, hoe gaat het vandaag?", pl: "Cześć, jak się dziś masz?", ro: "Salut, ce mai faci azi?",
    ru: "Привет, как дела сегодня?", uk: "Привіт, як справи сьогодні?", tr: "Merhaba, bugün nasılsın?",
    ar: "مرحبا، كيف حالك اليوم؟", hi: "नमस्ते, आज आप कैसे हैं?", ja: "こんにちは、今日は元気ですか？",
    ko: "안녕하세요, 오늘 어떻게 지내세요?", zh: "你好，你今天好吗？"
  },

  // opts.etym: aggiungere l'etimologia (solo se Wiktionary non la ha); opts.ipa: false = senza pronuncia (pronuncia spenta)
  definePrompt(target, lang, opts = {}) {
    const t = this.LANG_EN[target] || target;
    return (
      `You are a friendly language tutor. The learner's native language is ${t}. ` +
      `They clicked a word, or selected a group of words, in a subtitle or text${lang ? ` (language: ${(() => { try { return new Intl.DisplayNames(["en"], { type: "language" }).of(String(lang).split("-")[0]) + ", code " + lang; } catch { return "code " + lang; } })()})` : ""}. ` +
      `Write every explanatory field (meaning, pos, explanation, translations, false_friend, etymology, notes) in ${t}, never in English or another language` +
      ` (even if you are asked again with another model); the meaning must be a ${t} translation, not the original word. ` +
      `Explain it AS USED IN THAT SENTENCE; if it is a group of words, explain the whole expression, not word by word. ` +
      `Reply only with JSON, no other text, in this form: ` +
      `{"lemma": "dictionary form in the original language", "pos": "part of speech, in ${t}", ` +
      `"meaning": "meaning in this sentence, in ${t}, 1-6 words", ` +
      `"explanation": "one or two short sentences in ${t} on nuance, idiom or grammar, only if useful, else empty", ` +
      `"example": "a new short example sentence in the original language", ` +
      `"example_translation": "its translation in ${t}", "lang": "ISO 639-1 code of the word's language", ` +
      `"expression": "if a single word was clicked and in this sentence it is part of an idiom, phrasal verb or fixed expression, ` +
      `that whole expression copied exactly from the sentence, character by character, in the language and script of the sentence (never translated), else empty", ` +
      `"expression_meaning": "meaning of that whole expression in ${t}, 1-6 words, else empty"` +
      (opts.ipa === false ? "" : `, "ipa": "pronunciation of the clicked word or words in the International Phonetic Alphabet, broad transcription with stress marks, without slashes"`) +
      (opts.extra ? `, "false_friend": "ONLY if the word looks or sounds like a word of ${t} (a ${t} word, not English or another language) with a different meaning, ` +
        `a short warning in ${t} naming that ${t} word (for example: careful, it does not mean ...); if there is no such ${t} word, exactly an empty string: ` +
        `never write that it is not a false friend or explain why", "related": "words with the same origin in ${t} or in other well known languages, ` +
        `useful to remember it, short, else exactly an empty string (never write that there are none)", "spelling": {"score": "0-100: how correctly the clicked word is written and used ` +
        `in this sentence (spelling and grammar; 100 = perfect)", "correct": "the correct form if it is wrong, else empty", "note": "short note in ${t} if not perfect, else empty"}` : "") +
      (opts.idioms ? `, "idioms": [{"text": "a common idiom, figurative expression, phrasal verb or fixed phrase of 2 to 7 words that CONTAINS the clicked word (in any form), in general use and NOT only in this sentence, ` +
        `in the language of the sentence", "meaning": "what it means, in ${t}, short", "example": "one short natural example sentence in the original language"}] (at most 6, most common first; ` +
        `ordinary word combinations are not idioms; if there are none, an empty list)` : "") +
      (opts.sentence ? `, "sentence_translation": "a correct, natural translation in ${t} of the WHOLE sentence (the given sentence translation may be wrong)"` : "") +
      (opts.etym ? `, "etymology": "origin of the word (of its dictionary form) in ${t}, 1-3 short sentences: do not stop at the word it is derived from in the same language, ` +
        `trace it back through every language to the oldest known root and its original meaning, as a good etymological dictionary does; if you are not sure, say so briefly"` : "") +
      `}`
    );
  },

  // Pronuncia in alfabeto fonetico internazionale (IPA) di un elenco di parole, chiesta una volta per parola
  ipaPrompt(lang) {
    const name = this.LANG_EN[lang] || lang;
    return (
      `You are an expert phonetician. You get a JSON list of words` + (name ? ` in ${name}` : ` (detect their language from the sentence given)`) + `. ` +
      `For each word give its standard pronunciation in the International Phonetic Alphabet (IPA): broad phonemic transcription ` +
      `as in a good dictionary, with primary stress marks (ˈ) for languages that have word stress, length marks where relevant, ` +
      `no slashes or brackets. For Chinese use IPA with tone letters, for Japanese IPA of the reading. Names and numbers too ` +
      `(numbers as spoken). Reply only with JSON in this form: {"ipa": {"word": "ipa", ...}}, with every word as a key, ` +
      `copied exactly as given (same characters and script: never convert keys to kana, pinyin or Latin letters), in the same order.`
    );
  },

  prompt(target, n, clean, idioms) {
    const lang = this.LANG_EN[target] || target;
    if (clean) return this.promptClean(target, n) + (idioms ? this.idiomsAsk(lang) : "");
    return (
      `You translate video subtitles into ${lang}. You receive a JSON object whose "segments" array holds ` +
      `consecutive pieces of a transcript, often auto-generated: punctuation may be missing and some words may be ` +
      `misrecognized. "context_before" and "context_after" are only there to help you understand; do not translate them. ` +
      `Use the whole context to understand what is really being said and write natural, fluent ${lang} ` +
      `the way a professional subtitler would, silently fixing obvious recognition errors. ` +
      `Each segment is a separate subtitle shown at a different time: keep every translation aligned with its own segment. ` +
      `Never move words from one segment into another, never merge segments, never leave a segment empty; ` +
      `if a sentence continues in the next segment, translate only the words of this segment. ` +
      `Always translate into ${lang}, even when a segment seems to be in another language; never copy the original text. ` +
      `Short segments of one or two words (answers, interjections, greetings, exclamations) must be translated too; ` +
      `only names of people and places stay as they are. ` +
      `Do not add numbers, quotes or notes. Return exactly ${n} strings, one per segment, in the same order, ` +
      `as JSON in this form: {"t": ["...", "..."]} and nothing else.`
    ) + (idioms ? this.idiomsAsk(lang) : "");
  },

  // 1.6.0: nella stessa richiesta della traduzione anche i modi di dire (nessuna richiesta in più)
  idiomsAsk(lang) {
    return ` Also add to the same JSON object an "idioms" array with the idiomatic expressions that appear in the segments ` +
      `(fixed phrases whose meaning is not literal, idiomatic phrasal verbs, proverbs; not ordinary word combinations): ` +
      `each as {"i": index of the segment (from 0), "text": the expression exactly as written in that segment, "m": its meaning in ${lang}, short}. ` +
      `Use [] when there are none.`;
  },

  // Traduzione e, nella stessa richiesta, pulizia della trascrizione di Whisper
  promptClean(target, n) {
    const lang = this.LANG_EN[target] || target;
    return (
      `You receive a JSON object whose "segments" array holds consecutive pieces of an automatic speech transcript ` +
      `of a video (speech recognition: words may be misheard, punctuation may be missing). "context_before" and ` +
      `"context_after" are only there to help you understand. For every segment return two things:\n` +
      `1. "src": the same segment in its ORIGINAL language, corrected. ${this.CLEAN_RULES}\n` +
      `2. "t": its translation into ${lang}, natural and fluent like a professional subtitler would write it.\n` +
      `If a segment is clearly not real speech (text invented by the speech recognizer during music, noise or silence, ` +
      `such as "thanks for watching", "I'm sorry", "it's over" out of context, subtitle credits, "[music]"), ` +
      `return an empty string for it in both arrays. ` +
      `Keep every item aligned with its own segment: never move words between segments, never merge segments. ` +
      `If a segment is already in ${lang}, "t" is simply the corrected segment. Do not add numbers, quotes or notes. ` +
      `Return exactly ${n} items in each array, as JSON in this form: {"src": ["..."], "t": ["..."]} and nothing else.`
    );
  },

  // Cosa si può correggere nella trascrizione (uguale per la correzione da sola e per quella insieme alla traduzione)
  CLEAN_RULES:
    `Fix what the speech recognizer got wrong: misheard or invented words (use the context and the meaning of the ` +
    `conversation), wrong word forms, endings and agreements, missing small words (articles, prepositions, pronouns), ` +
    `punctuation, capitalization and the spelling of names. The result must read as correct, natural written language ` +
    `in that same language. Keep the speaker's words and meaning: do not rephrase freely, summarize, shorten or translate.`,

  // Solo correzione della trascrizione (quando si traduce con Google o DeepL)
  promptCleanOnly(n) {
    return (
      `You receive a JSON object whose "segments" array holds consecutive pieces of an automatic speech transcript ` +
      `of a video. "context_before" and "context_after" are only there to help you understand. ` +
      `For every segment return the same segment in its ORIGINAL language, corrected. ${this.CLEAN_RULES} ` +
      `If a segment is clearly not real speech (text invented by the speech recognizer during music, noise or silence, ` +
      `such as "thanks for watching" out of context, subtitle credits, "[music]"), return an empty string for it. ` +
      `Keep every item aligned with its own segment: never move words between segments, never merge segments. ` +
      `Return exactly ${n} strings, as JSON in this form: {"src": ["..."]} and nothing else.`
    );
  },

  userMessage(texts, before, after) {
    return JSON.stringify({
      context_before: before || [],
      segments: texts,
      context_after: after || []
    });
  }
};

// Servizi per consultare un testo in un'altra scheda (parola o frase, dalla lingua `from` alla lingua `to`).
// Usati dai sottotitoli sul video e dalla pagina della trascrizione.
const DS_REVERSO = { ar: "arabic", de: "german", en: "english", es: "spanish", fr: "french", he: "hebrew", it: "italian", ja: "japanese",
  nl: "dutch", pl: "polish", pt: "portuguese", ro: "romanian", ru: "russian", sv: "swedish", tr: "turkish", uk: "ukrainian", zh: "chinese" };
const DS_WORDREF = new Set(["enit", "iten", "enes", "esen", "enfr", "fren", "ende", "deen", "enpt", "pten"]);
function dsServiceLinks(text, from, to, isWord, lemma) {
  text = String(text || "").replace(/\s+/g, " ").trim();
  if (!text) return [];
  const fix = { iw: "he", nb: "no", jw: "jv", in: "id", fil: "tl" };
  const base = (l) => { const b = String(l || "").split("-")[0].toLowerCase(); return fix[b] || b; };
  const f = base(from), t = base(to || "it");
  const q = encodeURIComponent(text);
  const out = [
    { label: "Google Traduttore", url: `https://translate.google.com/?sl=${f || "auto"}&tl=${to === "zh-Hans" ? "zh-CN" : t}&text=${q}&op=translate` },
    { label: "DeepL", url: `https://www.deepl.com/translator#${f || "auto"}/${t}/${q}` }
  ];
  // Reverso Context: collegamento diretto solo per le coppie di lingue che si possono aprire da un indirizzo.
  // Per le altre (per esempio il ceco) le pagine dirette rimandano alla pagina iniziale: apro quella e copio il testo,
  // così basta incollarlo e scegliere le lingue.
  if (DS_REVERSO[f] && DS_REVERSO[t] && f !== t && text.length <= 80)
    out.push({ label: "Reverso (esempi)", url: `https://context.reverso.net/translation/${DS_REVERSO[f]}-${DS_REVERSO[t]}/${q}` });
  else
    out.push({ label: "Reverso (esempi)", url: "https://context.reverso.net/translation/", copy: true,
      title: "Reverso non si apre già pronto con queste lingue: il testo viene copiato, incollalo nella casella e scegli le lingue" });
  if (isWord) {
    const w = encodeURIComponent(String(lemma || text).trim());
    if (DS_WORDREF.has(f + t)) out.push({ label: "WordReference", url: `https://www.wordreference.com/${f + t}/${w}` });
    let name = "";
    try { name = f ? new Intl.DisplayNames(["en"], { type: "language" }).of(f) : ""; } catch {}
    out.push({ label: "Wiktionary", url: `https://en.wiktionary.org/wiki/${w}` + (name && name !== f ? "#" + encodeURIComponent(name.replace(/ /g, "_")) : "") });
  }
  return out;
}


// ---------- Frasi brevi ricopiate ("Ja." → "Ja.") ----------
// Una "traduzione" con le stesse parole dell'originale non è una traduzione, anche se la frase è di una o due parole.
// Se però anche Google la lascia uguale è un nome o una parola internazionale ("Karen", "Okay"): la ricordo come
// controllata (copieOk, per lingua di arrivo) così non si richiede più.
function dsWords(t) { return String(t || "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean); }
function dsIsCopy(orig, trans) {
  const a = dsWords(orig), b = dsWords(trans);
  return a.length > 0 && a.join(" ") === b.join(" ") && !a.every((w) => /^\d+$/.test(w));
}
var dsCopyOkSet = new Set();
var dsCopyOkReady = (async () => {
  try { ((await DS_EXT.storage.local.get({ copieOk: [] })).copieOk || []).forEach((x) => dsCopyOkSet.add(x)); } catch {}
})();
function dsCopyKey(text, target) { return (target || "") + "|" + dsWords(text).join(" "); }
function dsCopyOk(text, target) { return dsCopyOkSet.has(dsCopyKey(text, target)); }
function dsMarkCopyOk(text, target) {
  const k = dsCopyKey(text, target);
  if (dsCopyOkSet.has(k)) return;
  dsCopyOkSet.add(k);
  try { DS_EXT.storage.local.set({ copieOk: [...dsCopyOkSet].slice(-3000) }); } catch {}
}
// Da rifare: copia non ancora controllata
function dsUncheckedCopy(orig, trans, target) { return !!trans && dsIsCopy(orig, trans) && !dsCopyOk(orig, target); }

// Parola "pulita" per dizionari e traduzioni: senza trattini morbidi e caratteri invisibili, e (nelle lingue
// in cirillico) senza gli accenti che indicano solo dove cade l'accento (Дорефо́рменная → Дореформенная).
// Con quegli accenti Google e Wiktionary non riconoscevano la parola e la traducevano come due pezzi.
function dsCleanWord(w) {
  let s = String(w || "").replace(/[\u00AD\u200B-\u200D\u2060\uFEFF]/g, "");
  if (/[\u0400-\u04FF]/.test(s)) s = s.normalize("NFD").replace(/[\u0300\u0301]/g, "").normalize("NFC");
  return s;
}


// ---------- Carte per Anki di Sottotitoli Doppi (file e invio diretto) ----------
function dsAnkiEsc(s) { return String(s || "").replace(/[\t\r\n]+/g, " ").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function dsAnkiMark(sentence, word) {
  const s = dsAnkiEsc(sentence), w = dsAnkiEsc(word);
  const i = s.toLowerCase().indexOf(w.toLowerCase());
  return !w || i < 0 ? s : s.slice(0, i) + "<b>" + s.slice(i, i + w.length) + "</b>" + s.slice(i + w.length);
}
function dsAnkiTime(s) {
  s = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(sec).padStart(2, "0");
}
function dsAnkiLink(e) {
  return e.videoId ? `https://www.youtube.com/watch?v=${encodeURIComponent(e.videoId)}&t=${Math.max(0, (e.time || 0) - 2)}s` : (e.url || "");
}
// 1.6.2: che pronuncia è finita sulle carte (risposta di ankiAddNotes)
function dsAnkiAudioNote(r) {
  if (!r) return "";
  const n = (r.rec || 0) + (r.synth || 0), tot = (r.ids || []).filter((x) => x != null && x !== "dup").length;
  if (!n) return "";
  if (tot <= 1) return r.rec ? ", con la registrazione di un madrelingua" : ", con la voce sintetica";
  const a = r.rec || 0, b = r.synth || 0;
  return `, pronuncia: ${a} ${a === 1 ? "registrata" : "registrate"} da madrelingua, ${b} con la voce sintetica`;
}
// 1.6.3: l'impaginazione della carta, una sola per tutte (invio diretto, file, aggiornamento delle carte già in Anki).
// Blocchi <div> con lo stile dentro (così non dipende dal tipo di nota di Anki), tutto centrato, chiaro e scuro:
//   fronte: parola grande in grassetto [pronuncia] · frase in corsivo con la parola in grassetto · immagine
//   retro:  significato grande e colorato · riga piccola con forma base, tipo e genere · /IPA/ · riga · spiegazione(i) ·
//           etimologia · modi di dire · traduzione della frase in corsivo · pulsante-collegamento al video o alla pagina
// Ogni blocco porta data-f="campo": dsAnkiParse lo rilegge senza indovinare.
// m = { snd: nome del file audio già in Anki, img: nome del file o indirizzo dell'immagine, keep: file già sulla carta }
const DS_ANKI_FONT = "font-family:'Segoe UI',system-ui,-apple-system,Roboto,Arial,sans-serif;";
function dsAnkiFields(e, m, tag) {
  m = m || {};
  const E = dsAnkiEsc, text = e.kind === "text";
  const blk = (f, style, html) => `<div data-f="${f}" style="${style}">${html}</div>`;
  const muted = "opacity:.68;";
  const keepSnd = (m.keep || []).filter((x) => /^\[sound:/.test(x)), keepImg = (m.keep || []).filter((x) => !/^\[sound:/.test(x));
  let front = "";
  if (text) front = blk("word", `${DS_ANKI_FONT}font-size:19px;line-height:1.45;text-align:left;`, E(e.word));
  else {
    front += blk("word", `${DS_ANKI_FONT}font-size:34px;font-weight:700;line-height:1.2;text-align:center;margin:6px 0 2px;`,
      E(e.word));
    const snds = [m.snd ? `[sound:${m.snd}]` : "", ...keepSnd].filter(Boolean);
    if (snds.length) front += blk("snd", "text-align:center;font-size:16px;margin:0 0 2px;", snds.join(" "));
    if (e.sentence) front += blk("sentence", `${DS_ANKI_FONT}font-size:18px;font-style:italic;line-height:1.45;text-align:center;margin:14px 8px 4px;${muted.replace(".68", ".85")}`, dsAnkiMark(e.sentence, e.word));
  }
  const imgs = [m.img ? `<img src="${String(m.img).replace(/"/g, "%22")}" style="max-width:92%;max-height:280px;border-radius:8px;">` : "", ...keepImg].filter(Boolean);
  if (imgs.length) front += blk("img", "text-align:center;margin:12px 0 4px;", imgs.join(""));
  let back = "";
  if (e.meaning) back += blk("meaning", `${DS_ANKI_FONT}font-size:28px;font-weight:700;line-height:1.25;text-align:center;color:#2f7de1;margin:6px 8px 4px;`, E(e.meaning));
  const info = [e.lemma && e.lemma.toLowerCase() !== (e.word || "").toLowerCase() ? "→ " + E(e.lemma) : "", E(e.pos), E(e.gender)].filter(Boolean).join(" · ");
  if (info) back += blk("info", `${DS_ANKI_FONT}font-size:14px;text-align:center;letter-spacing:.3px;${muted}`, info);
  if (e.ipa) back += blk("ipa", `${DS_ANKI_FONT}font-size:15px;text-align:center;margin-top:3px;${muted}`, `/${E(e.ipa)}/`);
  if (e.translit) back += blk("translit", `${DS_ANKI_FONT}font-size:14px;text-align:center;${muted}`, E(e.translit));
  const sep = `<hr style="border:0;border-top:1px solid rgba(128,128,128,.35);margin:12px 18px;">`;
  const expls = [...new Set([e.explanation, ...(Array.isArray(e.expls) ? e.expls : [])].map((x) => String(x || "").trim()).filter(Boolean))].slice(0, 4);
  const ids = (Array.isArray(e.idioms) ? e.idioms : []).filter((x) => x && x.text).slice(0, 5);
  if (expls.length || e.etym || ids.length) back += sep;
  expls.forEach((x, i) => { back += blk(i ? "expl2" : "expl", `${DS_ANKI_FONT}font-size:17px;line-height:1.5;text-align:center;margin:6px 10px;`, E(x)); });
  if (e.etym) back += blk("etym", `${DS_ANKI_FONT}font-size:14px;line-height:1.45;text-align:center;margin:10px 12px 4px;${muted}`, `<b>Etimologia</b> · ${E(e.etym)}`);
  if (ids.length) back += blk("idioms", `${DS_ANKI_FONT}font-size:14px;line-height:1.5;text-align:center;margin:8px 12px 4px;`,
    `<b>Modi di dire</b><br>` + ids.map((x) => `«${E(x.text)}»` + (x.meaning ? ` = ${E(x.meaning)}` : "")).join("<br>"));
  if (!text && e.sentenceTrans) back += sep + blk("strans", `${DS_ANKI_FONT}font-size:16px;font-style:italic;line-height:1.45;text-align:center;margin:6px 12px;${muted.replace(".68", ".85")}`, E(e.sentenceTrans));
  const link = e.linkHtml ? "" : dsAnkiLink(e);
  const linkBtn = (href, label) => `<a href="${String(href).replace(/"/g, "%22")}" style="display:inline-block;padding:5px 14px;border:1px solid #2f7de1;border-radius:16px;color:#2f7de1;text-decoration:none;font-size:14px;font-family:'Segoe UI',system-ui,Arial,sans-serif;">${label}</a>`;
  if (e.linkHtml) back += blk("link", "text-align:center;margin:14px 0 4px;", e.linkHtml);
  else if (link) back += blk("link", "text-align:center;margin:14px 0 4px;", linkBtn(link, (e.videoId ? "▶ " : "🔗 ") + E(e.title || (e.videoId ? "Video" : e.url)) + (e.videoId ? " (" + dsAnkiTime(e.time) + ")" : "")));
  const tags = [tag || (!e.videoId && e.url ? "parole-al-volo" : "sottotitoli-doppi"), String(e.lang || "").split("-")[0]].filter(Boolean);
  return { front, back: `<div style="text-align:center;">${back}</div>`, tags };
}
// 1.6.3: dalla carta già in Anki ai dati: per rifarla, completarla o aggiornarla. Legge i blocchi data-f (impaginazione nuova);
// per le carte di prima (<br>, <b>, <i>) riconosce lo schema vecchio. Quello che non riconosce resta nella spiegazione.
function dsAnkiParse(front, back, tags) {
  const strip = (h) => String(h || "").replace(/<br\s*\/?>/gi, " ").replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
  const f = String(front || "");
  const keep = [...(f.match(/\[sound:[^\]]+\]/g) || []), ...(f.match(/<img[^>]*>/gi) || [])];
  const blocks = (h) => { const o = {}; String(h || "").replace(/<div data-f="(\w+)"[^>]*>([\s\S]*?)<\/div>/g, (_, k, v) => { if (!(k in o)) o[k] = v; return ""; }); return o; };
  const fb = blocks(f);
  const e = { word: "", sentence: "", lang: ((tags || []).filter((t) => !/^(sottotitoli-doppi|parole-al-volo)$/.test(t))[0] || "").toLowerCase(), meaning: "", lemma: "", pos: "", ipa: "", gender: "", etym: "", explanation: "", expls: [], idioms: [], sentenceTrans: "", linkHtml: "", translit: "", keep };
  if (fb.word != null) {
    e.word = strip(String(fb.word).replace(/\[sound:[^\]]+\]/g, ""));
    e.sentence = strip(fb.sentence || "");
  } else {
    e.word = strip((f.match(/<b>([\s\S]*?)<\/b>/i) || [])[1] || f.split(/<br/i)[0].replace(/\[sound:[^\]]+\]/g, ""));
    e.sentence = strip((f.match(/<i>([\s\S]*?)<\/i>/i) || [])[1] || "");
  }
  const bb = blocks(back);
  if (bb.meaning != null || bb.info != null || bb.expl != null || bb.link != null) {
    e.meaning = strip(bb.meaning || "");
    const info = strip(bb.info || "").split(" · ").filter(Boolean);
    for (const x of info) { if (x.startsWith("→ ")) e.lemma = x.slice(2); else if (!e.pos) e.pos = x; else e.gender = x; }
    e.ipa = strip(bb.ipa || "").replace(/^\/|\/$/g, "");
    e.translit = strip(bb.translit || "");
    e.explanation = strip(bb.expl || "");
    if (bb.expl2) e.expls.push(strip(bb.expl2));
    e.etym = strip(bb.etym || "").replace(/^Etimologia\s*·\s*/i, "");
    strip(String(bb.idioms || "").replace(/<br\s*\/?>/gi, "|")).replace(/^Modi di dire\s*/i, "").split("|").forEach((x) => { const m = x.trim().match(/^«(.+?)»(?:\s*=\s*(.*))?$/); if (m) e.idioms.push({ text: m[1], meaning: m[2] || "" }); });
    e.sentenceTrans = strip(bb.strans || "");
    e.linkHtml = bb.link || "";
    return e;
  }
  String(back || "").split(/<br\s*\/?>/i).forEach((raw, i) => {
    const t = strip(raw);
    if (!t) return;
    if (i === 0) { e.meaning = t; return; }
    if (/^<a\b/i.test(raw.trim())) { e.linkHtml = raw.trim(); return; }
    if (/^\/.+\/$/.test(t)) { e.ipa = t.slice(1, -1); return; }
    if (/^<small>\s*Etimologia:/i.test(raw.trim())) { e.etym = t.replace(/^Etimologia:\s*/i, ""); return; }
    if (/^<small>\s*Modi di dire:/i.test(raw.trim())) {
      t.replace(/^Modi di dire:\s*/i, "").split(/;\s*/).forEach((x) => { const m = x.match(/^«(.+?)»(?:\s*=\s*(.*))?$/); if (m) e.idioms.push({ text: m[1], meaning: m[2] || "" }); });
      return;
    }
    if (/^<small>/i.test(raw.trim())) { e.gender = t; return; }
    if (/^<i>/i.test(raw.trim())) { e.sentenceTrans = t; return; }
    if (i === 1 && t.length <= 60 && !/[.!?]$/.test(t) && !e.lemma && !e.pos) { const [a, b] = t.split(" · "); if (b) { e.lemma = a; e.pos = b; } else if (t.split(" ").length <= 2) e.pos = t; else e.explanation = t; return; }
    if (!e.explanation) e.explanation = t; else e.expls.push(t);
  });
  return e;
}
// Aspetto delle schede (popup → 🗒 Aspetto delle schede): variabili CSS sul contenitore delle schede, in comune tra
// video (overlay.css) e pagine (volo.css): grandezza (--dsc-k scala tutte le scritte), larghezza, sfondo, testo, significato
function dsCardVars(el, s) {
  if (!el || !s) return;
  const num = (v, d, lo, hi) => { const n = Number(v); return Math.max(lo, Math.min(hi, isFinite(n) && n ? n : d)); };
  const hex = (v, d) => (/^#[0-9a-f]{6}$/i.test(String(v || "")) ? v : d);
  const bg = hex(s.cardBg, "#1d2430"), op = num(s.cardOpacity, 1, 0.5, 1);
  const rgb = [1, 3, 5].map((i) => parseInt(bg.slice(i, i + 2), 16)).join(", ");
  el.style.setProperty("--dsc-k", num(s.cardScale, 100, 70, 170) / 100);
  el.style.setProperty("--dsc-wk", 1);   // 1.7.6: la larghezza non si sceglie più nel popup (si trascinano i bordi della scheda)
  el.style.setProperty("--dsc-bg", op < 1 ? `rgba(${rgb}, ${op})` : bg);
  el.style.setProperty("--dsc-fg", hex(s.cardText, "#eef1f5"));
  el.style.setProperty("--dsc-accent", hex(s.cardAccent, "#f5c84b"));
}
// Lingua dei nomi delle lingue nell'interfaccia: quella di «Traduci in» se l'interfaccia è tradotta, altrimenti italiano
// (i nomi dei mazzi di Anki restano in italiano: cambiandoli si creerebbero mazzi nuovi)
function dsUiLocale() {
  try { if (typeof DS_UI !== "undefined" && DS_UI.lang) return DS_UI.lang; } catch {}
  return "it";
}
// Nome del mazzo: un mazzo per lingua ("Lingue::Inglese") oppure uno solo
function dsAnkiLangName(lang) {
  const b = String(lang || "").split("-")[0].toLowerCase();
  if (!b || b === "?" || b === "auto") return "Altre lingue";
  try { const n = new Intl.DisplayNames(["it"], { type: "language" }).of(b); if (n && n.toLowerCase() !== b) return n.charAt(0).toUpperCase() + n.slice(1); } catch {}
  return b.toUpperCase();
}
// 1.7.7: i caratteri ideografici (kanji, hanzi, hanja) hanno un sottomazzo a parte: «Lingue::Giapponese::Kanji», «Lingue::Cinese::Hanzi»,
// «Lingue::Coreano::Hanja». Vale per le voci che sono UN SOLO carattere cinese (le parole di più caratteri restano nel mazzo della lingua).
const dsIsHanChar = (w) => { const a = Array.from(String(w || "").trim()); return a.length === 1 && /\p{Script=Han}/u.test(a[0]); };
function dsAnkiCharDeck(lang, o) {
  const b = String(lang || "").split("-")[0].toLowerCase();
  return dsAnkiDeckFor(lang, o) + "::" + ({ ja: "Kanji", zh: "Hanzi", ko: "Hanja" }[b] || "Caratteri");
}
function dsAnkiDeckOf(e, o) { return o && o.charDeck !== false && dsIsHanChar(e && e.word) ? dsAnkiCharDeck(e.lang, o) : dsAnkiDeckFor(e && e.lang, o); }
function dsAnkiDeckFor(lang, o) {
  if (o && o.perLang !== false) {
    const tpl = String((o && o.tpl) || "Lingue::{lingua}").trim() || "Lingue::{lingua}";
    return /\{lingua\}/i.test(tpl) ? tpl.replace(/\{lingua\}/gi, dsAnkiLangName(lang)) : tpl + "::" + dsAnkiLangName(lang);
  }
  return String((o && o.deck) || "Sottotitoli Doppi").trim() || "Sottotitoli Doppi";
}

// ---------- Scambio tra Sottotitoli Doppi e Parole al Volo: vocabolario e parole che conosci ----------
// Le due estensioni hanno memorie separate: si passa da una all'altra con un file (Esporta qui, Importa là).
// Si unisce, non si sostituisce: niente si perde, e importare due volte lo stesso file non crea doppioni.
const DS_SWAP_FORMAT = "parole-sottotitoli-1";
async function dsExportData(what) {
  const l = await DS_EXT.storage.local.get({ vocab: {}, knownWords: {} });
  const out = { format: DS_SWAP_FORMAT, from: typeof PAV_DEFAULTS !== "undefined" ? "Parole al Volo" : "Sottotitoli Doppi", date: new Date().toISOString() };
  if (what.known !== false) {
    out.knownWords = {};
    for (const [lg, s] of Object.entries(l.knownWords || {})) { const w = String(s || "").split("\n").filter(Boolean); if (w.length) out.knownWords[lg] = w; }
  }
  if (what.vocab !== false) out.vocab = l.vocab || {};
  const name = (what.vocab === false ? "parole-che-conosco" : "vocabolario-e-parole-che-conosco") + "-" + (typeof PAV_DEFAULTS !== "undefined" ? "parole-al-volo" : "sottotitoli-doppi") + "-" + out.date.slice(0, 10) + ".json";
  const blob = new Blob([JSON.stringify(out, null, 1)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  return { known: Object.values(out.knownWords || {}).reduce((n, x) => n + x.length, 0), vocab: Object.keys(out.vocab || {}).length, name };
}
// text: il contenuto del file. Un file .json di una delle due estensioni, oppure un elenco di parole (una per riga)
// che diventano "parole che conosco" nella lingua txtLang.
async function dsImportData(text, txtLang) {
  let data = null;
  try { data = JSON.parse(text); } catch {}
  const l = await DS_EXT.storage.local.get({ vocab: {}, knownWords: {} });
  const kw = { ...(l.knownWords || {}) };
  const vocab = { ...(l.vocab || {}) };
  let addedKnown = 0, addedVocab = 0, updatedVocab = 0;
  const addKnown = (lg, words) => {
    lg = String(lg || "").split("-")[0].toLowerCase();
    if (!lg) return;
    const set = new Set(String(kw[lg] || "").split("\n").filter(Boolean));
    for (const w0 of words) { const w = String(w0 || "").toLowerCase().trim(); if (w && !set.has(w)) { set.add(w); addedKnown++; } }
    kw[lg] = [...set].join("\n");
  };
  if (data && typeof data === "object" && !Array.isArray(data)) {
    const known = data.knownWords || (data.format ? null : data.known);
    if (known) for (const [lg, ws] of Object.entries(known)) addKnown(lg, Array.isArray(ws) ? ws : String(ws || "").split("\n"));
    const v = data.vocab || (!data.format && !data.knownWords && Object.values(data).every((x) => x && typeof x === "object" && x.word) ? data : null);
    if (v) for (const e0 of Object.values(v)) {
      if (!e0 || typeof e0 !== "object" || !e0.word) continue;
      const id = e0.id || [String(e0.lang || "?").split("-")[0].toLowerCase(), String(e0.lemma || e0.word).toLowerCase().trim()].join("|");
      const cur = vocab[id];
      if (!cur) { vocab[id] = { ...e0, id }; addedVocab++; continue; }
      // c'è già: tengo la mia, ma prendo quello che manca e "imparata" se l'altra lo dice
      let ch = false;
      for (const [k, val] of Object.entries(e0)) if ((cur[k] == null || cur[k] === "") && val != null && val !== "") { cur[k] = val; ch = true; }
      if (e0.status === "known" && cur.status !== "known") { cur.status = "known"; ch = true; }
      if (ch) updatedVocab++;
    }
    if (!known && !v) throw new Error("questo file non contiene né parole né vocabolario");
  } else {
    if (!txtLang) throw new Error("scegli prima la lingua delle parole");
    const words = String(text || "").split(/[\r\n,;\t]+/).map((x) => x.trim().split(/\s+/)[0]).filter((x) => x && /\p{L}/u.test(x));
    if (!words.length) throw new Error("nel file non ci sono parole");
    addKnown(txtLang, words);
  }
  // le parole del vocabolario segnate come imparate diventano anche "parole che conosco"
  for (const e of Object.values(vocab)) if (e.status === "known" && e.kind !== "text" && e.word && !/\s/.test(String(e.word).trim())) addKnown(e.lang, [e.word]);
  await DS_EXT.storage.local.set({ knownWords: kw, vocab });
  return { addedKnown, addedVocab, updatedVocab };
}
// riga di testo per dire com'è andata
function dsImportReport(r) {
  return `Fatto: ${r.addedKnown} parole conosciute nuove` + (r.addedVocab || r.updatedVocab ? `, ${r.addedVocab} voci nuove nel vocabolario` + (r.updatedVocab ? ` (${r.updatedVocab} completate)` : "") : "") + ".";
}

// ---------- Livelli delle parole ----------
// Per tutte le lingue: un livello indicativo (come A1…C2 del QCER) ricavato solo dalla posizione nell'elenco delle
// parole più usate. Non è un elenco ufficiale: serve per orientarsi e per aprire le parole "dello stesso livello".
const DS_LEVELS = [
  { id: "A1", from: 1, to: 500 }, { id: "A2", from: 501, to: 1000 }, { id: "B1", from: 1001, to: 2000 },
  { id: "B2", from: 2001, to: 4000 }, { id: "C1", from: 4001, to: 8000 }, { id: "C2", from: 8001, to: 16000 }
];
function dsLevelOf(rank) { return rank ? DS_LEVELS.find((l) => rank >= l.from && rank <= l.to) || null : null; }
// Giapponese: i livelli ufficiali JLPT (N5 il più facile … N1), elenchi da Jisho
const DS_JLPT = ["N5", "N4", "N3", "N2", "N1"];

// ---------- Sincronizzazione diretta con le altre estensioni (senza file) ----------
// Le estensioni sorelle: Sottotitoli Doppi, Parole al Volo e l'estensione unica che le contiene tutte e due.
// Ognuna si sincronizza con le altre installate. Firefox: gli indirizzi sono fissi. Edge/Chrome: cambiano da computer
// a computer, quindi si cercano per nome (permesso "gestione estensioni", chiesto solo la prima volta).
const DS_UNI_NAME = "Sottotitoli Doppi + Parole al Volo";
const DS_SIBLINGS = { "Sottotitoli Doppi": "sottotitoli-doppi@estensione.local", "Parole al Volo": "parole-al-volo@estensione.local",
  [DS_UNI_NAME]: "sottotitoli-parole@estensione.local" };
const dsSelfName = () => { try { return DS_EXT.runtime.getManifest().name; } catch { return ""; } };
const dsSiblingNames = () => Object.keys(DS_SIBLINGS).filter((n) => n !== dsSelfName());
const dsOtherName = () => dsSiblingNames().join(" / ");
const dsIsGecko = () => { try { return DS_EXT.runtime.getURL("").startsWith("moz-extension:"); } catch { return false; } };
// Impostazioni e chiavi passano anche loro (solo dove nell'altra non sono ancora state scelte: niente si sovrascrive).
// Alcune impostazioni hanno lo stesso nome ma un altro significato in Sottotitoli Doppi e in Parole al Volo: viaggiano
// separate ("sd" e "pav"); nell'estensione unica quelle di Parole al Volo hanno il prefisso (unica-pav.js).
const DS_SET_CONFLICT = { engine: "pavEngine", disabledSites: "pavDisabledSites", ankiDeck: "pavAnkiDeck", learnKnownPage: "pavKnownPage", roman: "pavRoman" };
const dsRole = () => (dsSelfName() === DS_UNI_NAME ? "uni" : dsSelfName() === "Parole al Volo" ? "pav" : "sd");
async function dsSettingsOut() {
  const all = await DS_EXT.storage.sync.get(null), role = dsRole();
  const out = { shared: {}, sd: {}, pav: {} };
  const pavNames = {};
  for (const k in DS_SET_CONFLICT) pavNames[DS_SET_CONFLICT[k]] = k;
  for (const [k, v] of Object.entries(all)) {
    if (k in DS_SET_CONFLICT) out[role === "pav" ? "pav" : "sd"][k] = v;
    else if (role === "uni" && pavNames[k]) out.pav[pavNames[k]] = v;
    else out.shared[k] = v;
  }
  return out;
}
// riempie solo le impostazioni che qui non sono mai state scelte; restituisce quante
async function dsSettingsIn(inc) {
  if (!inc || typeof inc !== "object") return 0;
  const role = dsRole(), have = await DS_EXT.storage.sync.get(null), put = {};
  const add = (k, v) => { if (v !== undefined && !(k in have) && !(k in put)) put[k] = v; };
  for (const [k, v] of Object.entries(inc.shared || {})) if (!(k in DS_SET_CONFLICT) && !Object.values(DS_SET_CONFLICT).includes(k)) add(k, v);
  if (role !== "pav") for (const [k, v] of Object.entries(inc.sd || {})) if (k in DS_SET_CONFLICT) add(k, v);
  for (const [k, v] of Object.entries(inc.pav || {})) if (k in DS_SET_CONFLICT) { if (role === "pav") add(k, v); else if (role === "uni") add(DS_SET_CONFLICT[k], v); }
  // i modelli scelti per ogni servizio: aggiungo quelli che mancano
  if (inc.shared && inc.shared.models && typeof inc.shared.models === "object" && have.models) {
    const m = { ...have.models };
    let ch = false;
    for (const [e, v] of Object.entries(inc.shared.models)) if (v && !m[e]) { m[e] = v; ch = true; }
    if (ch) put.models = m;
  }
  if (Object.keys(put).length) await DS_EXT.storage.sync.set(put);
  return Object.keys(put).length;
}
// chiavi dei servizi: aggiungo quelle che qui mancano (le mie restano)
async function dsKeysIn(inc) {
  if (!inc || typeof inc !== "object") return 0;
  const l = await DS_EXT.storage.local.get({ keys: {} }), keys = { ...(l.keys || {}) };
  let n = 0;
  for (const [k, v] of Object.entries(inc)) if (typeof v === "string" && v.trim() && !String(keys[k] || "").trim()) { keys[k] = v; n++; }
  if (n) await DS_EXT.storage.local.set({ keys });
  return n;
}
// chi chiede è davvero una sorella? Firefox: indirizzo fisso. Edge/Chrome: nome nell'elenco delle estensioni installate
// (solo se questa estensione ha già il permesso di vederlo); altrimenti le chiavi non le mando indietro.
async function dsTrusted(sender, from) {
  if (!sender || !sender.id) return false;
  if (dsIsGecko()) return sender.id === DS_SIBLINGS[from];
  try {
    if (!DS_EXT.management || !(await DS_EXT.permissions.contains({ permissions: ["management"] }))) return false;
    const x = await DS_EXT.management.get(sender.id);
    return !!(x && x.name === from && x.enabled);
  } catch { return false; }
}

// le sorelle installate: [{ name, id }] (in Firefox tutte quelle possibili: quelle che mancano non rispondono)
async function dsSiblingIds() {
  const names = dsSiblingNames();
  if (dsIsGecko()) return names.map((name) => ({ name, id: DS_SIBLINGS[name] }));
  let ok = false;
  try { ok = await DS_EXT.permissions.request({ permissions: ["management"] }); } catch {}
  if (!ok || !DS_EXT.management) throw new Error("per trovare le altre estensioni serve il permesso di vedere le estensioni installate (puoi usare invece Esporta/Importa)");
  const all = await DS_EXT.management.getAll();
  const found = [];
  for (const name of names) {
    const x = all.find((e) => e.name === name && e.type === "extension");
    if (x && x.enabled) found.push({ name, id: x.id });
  }
  if (!found.length) {
    const off = all.filter((e) => names.includes(e.name) && !e.enabled).map((e) => e.name);
    throw new Error(off.length ? `${off.join(" e ")}: è spenta, accendila e riprova` : `nessuna delle altre estensioni (${names.join(", ")}) è installata`);
  }
  return found;
}
// what: { known: true, vocab: false } — manda le mie a ogni sorella, riceve le sue, unisce tutto da tutte le parti
async function dsSyncWithSibling(what = { known: true, vocab: false }) {
  const sibs = await dsSiblingIds();
  const here = { addedKnown: 0, addedVocab: 0, updatedVocab: 0 }, there = [], missing = [];
  // con più sorelle, un secondo giro: le prime ricevono anche quello che è arrivato dalle ultime
  const rounds = sibs.length > 1 ? [...sibs, ...sibs.slice(0, -1).map((x) => ({ ...x, again: true }))] : sibs;
  for (const sib of rounds) {
    if (sib.again && !there.some((x) => x.name === sib.name)) continue;
    const l = await DS_EXT.storage.local.get({ knownWords: {}, vocab: {} });
    const mine = { format: DS_SWAP_FORMAT, from: dsSelfName(), knownWords: {} };
    for (const [lg, s] of Object.entries(l.knownWords || {})) mine.knownWords[lg] = String(s || "").split("\n").filter(Boolean);
    if (what.vocab) mine.vocab = l.vocab || {};
    if (what.keys !== false) {
      mine.keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
      mine.settings = await dsSettingsOut();
    }
    let r;
    try { r = await DS_EXT.runtime.sendMessage(sib.id, { type: "dsSync", data: mine, vocab: !!what.vocab, keys: what.keys !== false }); }
    catch { missing.push(sib.name); continue; }
    if (!r || r.error || !r.data) { missing.push(sib.name + ((r && r.error) ? " (" + r.error + ")" : "")); continue; }
    const got = await dsImportData(JSON.stringify(r.data), "");
    here.addedKnown += got.addedKnown; here.addedVocab += got.addedVocab; here.updatedVocab += got.updatedVocab;
    here.keys = (here.keys || 0) + await dsKeysIn(r.data.keys);
    here.settings = (here.settings || 0) + await dsSettingsIn(r.data.settings);
    if (r.keysWithheld && !sib.again) (here.withheld = here.withheld || []).push(sib.name);
    if (sib.again) {   // stesso giro di prima: sommo quello che ha ricevuto in più
      const t = there.find((x) => x.name === sib.name), res = r.result || {};
      t.addedKnown = (t.addedKnown || 0) + (res.addedKnown || 0); t.addedVocab = (t.addedVocab || 0) + (res.addedVocab || 0);
    } else there.push({ name: sib.name, ...(r.result || {}) });
  }
  if (!there.length) {
    throw new Error(dsIsGecko() ? `nessuna delle altre estensioni ha risposto (${dsSiblingNames().join(", ")}): sono installate, accese e aggiornate?`
      : `${missing.join(", ")} non risponde: aggiornala all'ultima versione e controlla che sia accesa`);
  }
  return { here, there, missing: dsIsGecko() ? [] : missing, other: there.map((x) => x.name).join(" e ") };
}
// dal lato che riceve (background): unisce quello che arriva e risponde con quello che ha
async function dsSyncReceive(msg, sender) {
  const from = msg && msg.data && msg.data.from;
  if (!from || !dsSiblingNames().includes(from)) throw new Error("estensione non riconosciuta");
  if (dsIsGecko() && sender && sender.id !== DS_SIBLINGS[from]) throw new Error("estensione non riconosciuta");
  const result = await dsImportData(JSON.stringify(msg.data), "");
  result.keys = await dsKeysIn(msg.data.keys);
  result.settings = await dsSettingsIn(msg.data.settings);
  const l = await DS_EXT.storage.local.get({ knownWords: {}, vocab: {} });
  const data = { format: DS_SWAP_FORMAT, from: dsSelfName(), knownWords: {} };
  for (const [lg, s] of Object.entries(l.knownWords || {})) data.knownWords[lg] = String(s || "").split("\n").filter(Boolean);
  if (msg.vocab) data.vocab = l.vocab || {};
  let keysWithheld = false;
  if (msg.keys) {
    data.settings = await dsSettingsOut();
    if (await dsTrusted(sender, from)) data.keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
    else keysWithheld = true;
  }
  return { data, result, keysWithheld };
}
function dsSyncReport(r) {
  const there = Array.isArray(r.there) ? r.there : [{ name: r.other, ...(r.there || {}) }];
  return `Fatto: qui ${r.here.addedKnown} parole conosciute nuove` + (r.here.addedVocab ? ` e ${r.here.addedVocab} voci` : "") + "; " +
    there.map((x) => `in ${x.name} ${x.addedKnown || 0}` + (x.addedVocab ? ` e ${x.addedVocab} voci` : "")).join(", ") +
    ". Ora hanno le stesse." +
    (r.here.keys || r.here.settings || there.some((x) => x.keys || x.settings)
      ? ` Chiavi copiate: qui ${r.here.keys || 0}` + there.map((x) => `, in ${x.name} ${x.keys || 0}`).join("") +
        `; impostazioni prese: qui ${r.here.settings || 0}` + there.map((x) => `, in ${x.name} ${x.settings || 0}`).join("") + "." : "") +
    (r.here.withheld && r.here.withheld.length ? ` Le chiavi di ${r.here.withheld.join(" e ")} non sono arrivate (per sicurezza): premi ⇄ anche dentro ${r.here.withheld.length > 1 ? "quelle" : "quella"}.` : "") +
    (r.missing && r.missing.length ? ` (Non ha risposto: ${r.missing.join(", ")}.)` : "");
}

// Una parte di testo è una parola? In Firefox lo spezzatore di parole a volte non considera "parola" alcune
// sillabe giapponesi (は, い, わ…): basta che contenga una lettera o una cifra.
function dsIsWord(sg) { return !!(sg && (sg.isWordLike || /[\p{L}\p{N}]/u.test(sg.segment || ""))); }

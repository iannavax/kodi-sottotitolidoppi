# Parole al Volo 1.15: lettore PDF (pdf.js) con la scheda delle parole e la traduzione del testo evidenziato
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def handle(route, request):
    if request.url.startswith("https://example.test/") and request.url.split("?")[0].endswith(".pdf"):
        return await route.fulfill(status=200, content_type="application/pdf", body=open("/tmp/doc.pdf", "rb").read())
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console: " + m.text) if m.type == "error" else None)
        await pg.goto(f"chrome-extension://{eid}/pdf.html?file=" + "https%3A%2F%2Fexample.test%2Fdoc.pdf"); await pg.wait_for_timeout(2500)
        print("1. pagine:", await pg.evaluate("document.querySelectorAll('.page').length"), "| disegnate:", await pg.evaluate("document.querySelectorAll('.page canvas').length"),
              "| testo:", (await pg.evaluate("(document.querySelector('.textLayer')||{}).textContent||''"))[:70], "| nome:", await pg.inner_text("#name"))
        # la parola "bread" nello strato di testo
        box = await pg.evaluate("""(()=>{const t=document.querySelector('.textLayer'); const w=document.createTreeWalker(t, NodeFilter.SHOW_TEXT); let n;
          while((n=w.nextNode())){const i=n.nodeValue.indexOf('bread'); if(i>=0){const r=document.createRange(); r.setStart(n,i); r.setEnd(n,i+5); const b=r.getBoundingClientRect(); return {x:b.x+b.width/2, y:b.y+b.height/2};}} return null})()""")
        print("   'bread' sullo schermo:", box)
        await pg.mouse.move(box["x"], box["y"], steps=4); await pg.wait_for_timeout(2500)
        print("2. scheda:", (await pg.evaluate("(document.querySelector('.pav-card')||{}).innerText||''")).replace("\n", " | ")[:160])
        await pg.keyboard.press("Escape"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(300)
        await pg.evaluate("""(()=>{const t=document.querySelector('.textLayer'); const sp=[...t.querySelectorAll('span')].find(s=>/walked/.test(s.textContent)); const r=document.createRange(); r.selectNodeContents(sp); const s=getSelection(); s.removeAllRanges(); s.addRange(r); document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));})()""")
        await pg.wait_for_timeout(2500)
        print("3. testo evidenziato:", (await pg.evaluate("(document.querySelector('.pav-textcard')||document.querySelector('.pav-card')||{}).innerText||''")).replace("\n", " | ")[:160])
        # apertura automatica
        await sw.evaluate("chrome.storage.sync.set({pdfAuto:true})"); await asyncio.sleep(0.5)
        p2 = await ctx.new_page(); p2.on("pageerror", lambda e: errs.append(str(e)))
        try: await p2.goto("https://example.test/altro.pdf")
        except Exception: pass
        await p2.wait_for_timeout(2500)
        print("4. apertura automatica:", p2.url.split("/")[-1][:70], "| pagine:", await p2.evaluate("document.querySelectorAll('.page').length"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

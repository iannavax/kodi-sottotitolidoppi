# Sottotitoli Doppi 5.8.4 (Chrome, Edge, Brave)

## Aggiornare senza perdere chiavi e vocabolario
1. Estrai lo zip e copia i file nuovi **nella stessa cartella** dell'estensione, sostituendo quelli vecchi.
2. In `edge://extensions` (o `chrome://extensions`) premi il pulsante di ricarica ↻ sulla scheda dell'estensione.
3. Ricarica le pagine aperte.

Non rimuovere l'estensione: rimuovendola si cancellano anche le chiavi, le traduzioni salvate e il vocabolario.

**Per i file sul tuo computer** (video aperti con doppio clic nel browser, indirizzi che iniziano con `file:///`): in `edge://extensions` apri **Dettagli** dell'estensione e attiva **Consenti l'accesso agli URL dei file**.

## Prima installazione
Estrai lo zip in una cartella che non cancellerai. Attiva **Modalità sviluppatore**, clicca **Carica estensione non pacchettizzata** e scegli la cartella.


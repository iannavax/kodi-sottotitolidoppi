// Lettore PDF di Parole al Volo: il lettore del browser non lascia entrare le estensioni, quindi i PDF si aprono qui
// (pdf.js di Mozilla). Ogni pagina è disegnata con sopra il suo testo vero (trasparente): la scheda passando il
// mouse, la selezione e la traduzione funzionano come sulle pagine web (volo.js è caricato in questa pagina).
import * as pdfjsLib from "./pdfjs/pdf.min.mjs";
pdfjsLib.GlobalWorkerOptions.workerSrc = "./pdfjs/pdf.worker.min.mjs";

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
let scale = 1.4, doc = null, gen = 0;
// codifica del testo: "auto" (decido io guardando le prime pagine), "none", "1250", "88592"
let encPref = "auto", encMode = "none";
try { encPref = localStorage.getItem("pavPdfEnc") || "auto"; } catch {}
try { scale = Number(localStorage.getItem("pavPdfScale")) || 1.4; } catch {}

function message(html) { $("pages").innerHTML = `<div class="msg">${html}</div>`; }

async function openData(data, name) {
  const my = ++gen;
  $("name").textContent = name || "PDF";
  document.title = (name || "PDF") + " — Parole al Volo";
  $("pages").textContent = "";
  message("Apro il PDF…");
  try {
    // tabelle dei caratteri e caratteri standard: senza, in alcuni PDF il testo esce con caratteri sbagliati
    doc = await pdfjsLib.getDocument({ data, isEvalSupported: false,
      cMapUrl: new URL("pdfjs/cmaps/", location.href).href, cMapPacked: true,
      standardFontDataUrl: new URL("pdfjs/standard_fonts/", location.href).href }).promise;
  } catch (e) {
    if (my === gen) message(`<b>Non riesco ad aprire questo PDF.</b><br>${String(e && e.message || e).replace(/</g, "&lt;")}`);
    return;
  }
  if (my !== gen) return;
  $("count").textContent = doc.numPages + (doc.numPages === 1 ? " pagina" : " pagine");
  await chooseEncoding(my);
  await layout(my);
}

// Le pagine si preparano tutte (misure giuste per scorrere), ma si disegnano solo quando arrivano sullo schermo
async function layout(my) {
  $("pages").textContent = "";
  $("zoom").textContent = Math.round(scale * 100) + "%";
  const obs = new IntersectionObserver((entries) => {
    for (const en of entries) if (en.isIntersecting) { obs.unobserve(en.target); drawPage(en.target, my).catch((e) => console.error("Parole al Volo, pagina del PDF:", e)); }
  }, { rootMargin: "800px 0px" });
  for (let n = 1; n <= doc.numPages; n++) {
    const page = await doc.getPage(n);
    if (my !== gen) return;
    const vp = page.getViewport({ scale });
    const div = document.createElement("div");
    div.className = "page";
    div.dataset.n = n;
    div.style.width = Math.floor(vp.width) + "px";
    div.style.height = Math.floor(vp.height) + "px";
    div.style.setProperty("--scale-factor", String(scale));
    div.style.setProperty("--total-scale-factor", String(scale));
    div.style.setProperty("--user-unit", "1");
    const num = document.createElement("span"); num.className = "num"; num.textContent = n;
    div.append(num);
    $("pages").append(div);
    obs.observe(div);
  }
}

async function drawPage(div, my) {
  const page = await doc.getPage(Number(div.dataset.n));
  if (my !== gen) return;
  const vp = page.getViewport({ scale });
  const ratio = window.devicePixelRatio || 1;
  const canvas = document.createElement("canvas");
  canvas.width = Math.floor(vp.width * ratio);
  canvas.height = Math.floor(vp.height * ratio);
  div.prepend(canvas);
  await page.render({ canvas, canvasContext: canvas.getContext("2d"), viewport: vp, transform: ratio !== 1 ? [ratio, 0, 0, ratio, 0, 0] : null }).promise;
  if (my !== gen) return;
  const tl = document.createElement("div");
  tl.className = "textLayer";
  div.append(tl);
  const tc = await page.getTextContent();
  fixAccents(tc.items);
  await new pdfjsLib.TextLayer({ textContentSource: tc, container: tl, viewport: vp }).render();
}

// Accenti staccati. Molti PDF (soprattutto quelli fatti con LaTeX) scrivono "č" come due caratteri: "ˇ" e "c"
// (spesso l'accento prima della lettera, a volte perfino in un pezzo di testo diverso). A vedersi è giusto, ma il
// testo è "ˇcesk´y" e la traduzione non lo capisce. Riunisco l'accento alla lettera, solo quando insieme formano
// davvero una lettera accentata (č, ý, ů, ž, ő, ç…), così il testo normale non cambia.
const MARKS = { "\u02C7": "\u030C", "\u00B4": "\u0301", "\u02DA": "\u030A", "\u00A8": "\u0308", "\u02DD": "\u030B", "\u02D8": "\u0306",
  "\u00B8": "\u0327", "\u02DB": "\u0328", "\u02D9": "\u0307", "\u0060": "\u0300", "\u02C6": "\u0302", "\u02DC": "\u0303" };
const MARK_RE = new RegExp("[" + Object.keys(MARKS).join("") + "]");
const isLetter = (c) => !!c && /\p{L}/u.test(c);
const compose = (letter, mark) => { const x = (letter + MARKS[mark]).normalize("NFC"); return x.length === 1 ? x : null; };
function fixString(str) {
  if (!MARK_RE.test(str)) return str.normalize("NFC");
  const a = Array.from(str);
  const out = [];
  for (let i = 0; i < a.length; i++) {
    const c = a[i];
    if (MARKS[c]) {
      // prima la lettera dopo (ordine di LaTeX), poi quella prima se la parola finisce qui
      const n = a[i + 1], prev = out[out.length - 1];
      if (isLetter(n) && compose(n, c)) { out.push(compose(n, c)); i++; continue; }
      if (isLetter(prev) && !isLetter(n) && compose(prev, c)) { out[out.length - 1] = compose(prev, c); continue; }
    }
    out.push(c);
  }
  return out.join("").normalize("NFC");
}
// ---------- PDF scritti nella codifica dell'Europa centrale ma dichiarati dell'Europa occidentale ----------
// Difetto frequente nei PDF cechi (e slovacchi, polacchi…) un po' vecchi: "Hrabě" esce "Hrabì", "Příliš" "Pøíliš",
// "ť" diventa "•". Riporto ogni carattere al suo byte (Windows-1252) e lo rileggo come Windows-1250 o ISO-8859-2.
const B1252 = (() => { const m = new Map(), d = new TextDecoder("windows-1252"); for (let b = 0x80; b < 0x100; b++) m.set(d.decode(Uint8Array.of(b)), b); return m; })();
const DEC = { "1250": new TextDecoder("windows-1250"), "88592": new TextDecoder("iso-8859-2") };
function recode(str, mode) {
  const d = DEC[mode];
  if (!d) return str;
  // i byte che Windows-1252 non usa (per esempio 0x9D = ť in Windows-1250) pdf.js li mostra come "•"
  str = str.replace(/(\p{L})\u2022(\p{L})/gu, "$1\u009D$2");
  let out = "";
  for (const c of str) { const b = B1252.get(c); out += b ? d.decode(Uint8Array.of(b)) : c; }
  return out;
}
const CE_LETTERS = /[čřěůňďťČŘĚŮŇĎŤľĺŕĽĹŔąęłńśźżĄĘŁŃŚŹŻőűŐŰăşţĂŞŢ]/gu;
const MOJI = /[øìèùòïðñÈØÌÙÒÏ¹¾»]/gu;
const ceScore = (t) => (t.match(CE_LETTERS) || []).length;
async function chooseEncoding(my) {
  encMode = encPref === "auto" ? "none" : encPref;
  if (encPref === "auto") {
    let text = "";
    for (let n = 1; n <= Math.min(doc.numPages, 4) && text.length < 6000; n++) {
      const tc = await (await doc.getPage(n)).getTextContent();
      text += tc.items.map((it) => it.str || "").join(" ") + " ";
    }
    if (my !== gen) return;
    const moji = (text.match(MOJI) || []).length, base = ceScore(text);
    let best = "none", bestScore = base;
    for (const m of ["1250", "88592"]) { const sc = ceScore(recode(text, m)); if (sc > bestScore) { best = m; bestScore = sc; } }
    // solo se il testo ha i segni tipici del difetto e la conversione porta davvero lettere dell'Europa centrale
    if (best !== "none" && moji >= 3 && bestScore >= 3 && bestScore >= base * 2 + 3) encMode = best;
  }
  $("enc").value = encPref;
  $("encNote").textContent = encPref === "auto" && encMode !== "none" ? "(corretti)" : "";
}
function fixAccents(items) {
  if (encMode !== "none") for (const it of items) if (typeof it.str === "string") it.str = recode(it.str, encMode);
  const list = items.filter((it) => typeof it.str === "string");
  // accento alla fine di un pezzo e lettera all'inizio del pezzo dopo: lo sposto lì
  for (let i = 0; i + 1 < list.length; i++) {
    const s = list[i].str, m = s.slice(-1), next = list[i + 1].str;
    if (MARKS[m] && isLetter(next.charAt(0)) && compose(next.charAt(0), m) && !list[i].hasEOL) {
      list[i].str = s.slice(0, -1);
      list[i + 1].str = m + next;
    }
  }
  for (const it of list) it.str = fixString(it.str);
}

async function openUrl(url) {
  $("orig").href = url; $("orig").hidden = false;
  const name = decodeURIComponent((url.split("?")[0].split("/").pop() || "PDF"));
  message("Scarico il PDF…");
  try {
    const r = await fetch(url, { credentials: "include" });
    if (!r.ok) throw new Error("il sito ha risposto " + r.status);
    await openData(new Uint8Array(await r.arrayBuffer()), name);
  } catch (e) {
    const local = /^file:/i.test(url);
    message(`<b>Non riesco a leggere questo PDF da qui</b> (${String(e && e.message || e).replace(/</g, "&lt;")}).<br><br>` +
      (local ? "È un file del computer: premi <b>📂 Apri un PDF…</b> qui sopra e sceglilo (oppure, in Edge/Chrome, nella pagina delle estensioni attiva «Consenti l'accesso agli URL dei file» per Parole al Volo)."
        : "Scaricalo e aprilo con <b>📂 Apri un PDF…</b> qui sopra."));
  }
}

$("file").addEventListener("change", async () => {
  const f = $("file").files[0];
  if (!f) return;
  $("orig").hidden = true;
  history.replaceState(null, "", location.pathname);
  await openData(new Uint8Array(await f.arrayBuffer()), f.name);
});
const rezoom = (k) => {
  if (!doc) return;
  scale = Math.min(4, Math.max(0.5, Math.round(scale * k * 10) / 10));
  try { localStorage.setItem("pavPdfScale", String(scale)); } catch {}
  const top = window.scrollY / Math.max(1, document.body.scrollHeight);
  layout(++gen).then(() => window.scrollTo(0, top * document.body.scrollHeight));
};
$("zoomIn").addEventListener("click", () => rezoom(1.15));
$("enc").addEventListener("change", async () => {
  encPref = $("enc").value;
  try { localStorage.setItem("pavPdfEnc", encPref); } catch {}
  if (!doc) return;
  const my = ++gen;
  await chooseEncoding(my);
  if (my === gen) layout(my);
});
$("zoomOut").addEventListener("click", () => rezoom(1 / 1.15));

const file = params.get("file");
if (file) openUrl(file);
else message("Premi <b>📂 Apri un PDF…</b> qui sopra per leggere un PDF del computer con Parole al Volo: passa il mouse sulle parole per la loro scheda, evidenzia un pezzo per tradurlo.<br><br>" +
  "I PDF aperti nel browser si aprono qui anche dal popup («📄 Apri questo PDF con Parole al Volo») o da soli, se lo scegli nel popup.");

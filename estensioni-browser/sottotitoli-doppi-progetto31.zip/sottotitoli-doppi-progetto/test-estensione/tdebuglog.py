# 1.4.12: «📋 Copia il registro per il debug» nel popup: eventi della pagina (clic su DS, sottotitoli presi dal lettore,
# traduzione, errori), stato di adesso e richieste fallite nel sottofondo. E DS spento e riacceso: i sottotitoli tornano.
import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
SHOWN = "(document.querySelector('.dualsub-overlay:not([hidden]) .dualsub-orig')||{}).textContent||''"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function(SHOWN, timeout=40000)
        print("1. sottotitoli:", (await pg.evaluate(SHOWN))[:40])
        await pg.evaluate("document.querySelector('.dualsub-toggle').click()"); await pg.wait_for_timeout(1800)
        off = await pg.evaluate(SHOWN)
        await pg.evaluate("document.querySelector('.dualsub-toggle').click()"); await pg.wait_for_timeout(2500)
        on = await pg.evaluate(SHOWN)
        print("2. DS spento:", repr(off[:20]), "| riacceso:", repr(on[:30]))
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(500)
        # il popup chiede alla scheda attiva: porto davanti il video
        await pg.bring_to_front(); await pp.evaluate("withTab = (fn) => chrome.tabs.query({url:'https://www.youtube.com/*'}, (t) => fn(t[0])); navigator.clipboard.writeText = async (t) => { window.__copied = t; }")
        await pp.evaluate("document.querySelectorAll('details').forEach(d=>d.open=true)"); await pp.click("#debugLogCopy"); await pp.wait_for_timeout(1200)
        txt = await pp.evaluate("window.__copied || ''")
        print("3. registro copiato:", len(txt), "caratteri | pulsante:", await pp.inner_text("#debugLogCopy"))
        print("\n".join("   | " + l for l in txt.splitlines()[:45]))
        need = ["STATO ADESSO", "clic su DS", "accensione: video gdTest", "sottotitoli richiesti dal lettore", "Sottotitoli trovati", "EVENTI DELLA PAGINA", "RICHIESTE FALLITE"]
        miss = [n for n in need if n not in txt]
        ok = not miss and off == "" and on
        print("errori:", errs if ok else errs + ["manca: " + str(miss)], log["errors"])
        await ctx.close()
asyncio.run(main())

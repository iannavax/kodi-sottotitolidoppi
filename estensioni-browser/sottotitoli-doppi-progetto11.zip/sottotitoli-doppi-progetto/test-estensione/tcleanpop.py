# 5.21: correzione della trascrizione con Gemini/Groq, accendibile dal riquadro in cima al popup
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk'}})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(900)
        print("1. senza trascrizione:", await pp.evaluate("document.getElementById('cleanQuick').hidden"))
        await pp.evaluate("updateLive({onVideo:true, running:true})"); await pp.wait_for_timeout(200)
        print("2. trascrizione in corso:", await pp.evaluate("[document.getElementById('cleanQuick').hidden, document.getElementById('cleanTranscript2').checked]"), "|", await pp.inner_text("#cleanInfo2"))
        await pp.click("#cleanTranscript2"); await pp.wait_for_timeout(300)
        print("3. spenta:", await sw.evaluate("chrome.storage.sync.get('cleanTranscript').then(r=>r.cleanTranscript)"), "| casella nella sezione:", await pp.is_checked("#cleanTranscript"), "|", await pp.inner_text("#cleanInfo2"))
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

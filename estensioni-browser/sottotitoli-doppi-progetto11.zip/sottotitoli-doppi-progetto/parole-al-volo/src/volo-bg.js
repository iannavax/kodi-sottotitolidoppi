// Parole al Volo — background. Usa i servizi di Sottotitoli Doppi (background.js: Google, Gemini, Groq, voce,
// spiegazioni "define", pronuncia IPA "ipa") e aggiunge: parola e testo con lingua rilevata e trascrizione in
// caratteri latini, e l'invio diretto ad Anki con AnkiConnect.
if (typeof importScripts === "function" && typeof DS_CONFIG === "undefined") importScripts("config.js", "volo-config.js", "background.js");

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  let run;
  if (msg.type === "pavWord") run = pavWord(msg);
  else if (msg.type === "pavText") run = pavText(msg);
  else if (msg.type === "pavAnki") run = pavAnki(msg);
  else if (msg.type === "pavAnkiCheck") run = pavAnkiCheck(msg);
  else return false;
  run.then((r) => sendResponse(r), (e) => sendResponse({ error: String((e && e.message) || e) }));
  return true;
});

// Pezzi della risposta di Google: traduzione, trascrizione in caratteri latini dell'originale, lingua rilevata
function pavGoogleParts(data) {
  let translit = "";
  for (const p of data[0] || []) if (p && p[0] == null && p[1] == null && typeof p[3] === "string") translit += p[3];
  return { text: googleText(data), translit: translit.trim(), lang: typeof data[2] === "string" ? data[2] : "" };
}

// Una parola: significato dal dizionario di Google (gratis), lingua, trascrizione
async function pavWord(msg) {
  const tl = googleLang(msg.target);
  const sl = msg.lang ? googleSource(msg.lang, msg.target) : "";
  const data = await googleRequest(msg.word, tl, GOOGLE_DICT_DT + "&dt=rm&hl=" + encodeURIComponent(tl) + sl);
  const g = pavGoogleParts(data);
  const entries = Array.isArray(data[1]) ? data[1] : [];
  const same = g.text.trim().toLowerCase() === String(msg.word).trim().toLowerCase();
  return {
    meaning: same && !entries.length ? "" : g.text,
    untranslated: same && !entries.length,
    pos: entries[0] ? String(entries[0][0] || "") : "",
    dict: entries.slice(0, 4).map((e) => ({ pos: String(e[0] || ""), words: (e[1] || []).slice(0, 6).map(String) })),
    translit: g.translit && g.translit.toLowerCase() !== String(msg.word).toLowerCase() ? g.translit : "",
    lang: msg.lang || g.lang, detected: g.lang, source: "Google Traduttore",
    gdict: googleDict(data)
  };
}

// Un testo (una frase o una selezione lunga): a pezzi di frasi intere, per stare nei limiti dell'indirizzo
async function pavText(msg) {
  const text = String(msg.text || "").slice(0, 5000);
  const tl = googleLang(msg.target);
  const sl = msg.lang ? googleSource(msg.lang, msg.target) : "";
  const parts = [];
  let cur = "";
  for (const piece of text.split(/(?<=[.!?。！？…\n])/u)) {
    if ((cur + piece).length > 1400 && cur) { parts.push(cur); cur = ""; }
    cur += piece;
    while (cur.length > 1400) { parts.push(cur.slice(0, 1400)); cur = cur.slice(1400); }
  }
  if (cur.trim()) parts.push(cur);
  let out = "", translit = "", lang = "";
  for (const p of parts) {
    const g = pavGoogleParts(await googleRequest(p, tl, "&dt=rm" + sl));
    out += g.text; translit += (translit ? " " : "") + g.translit; lang = lang || g.lang;
  }
  let translation = out.trim(), by = "";
  // DeepL o Microsoft scelti nel popup: la traduzione è la loro (Google resta per la lingua e la trascrizione)
  const E = msg.engine && C.ENGINES[msg.engine];
  if (E && (E.kind === "deepl" || E.kind === "microsoft") && msg.key) {
    try {
      const r = await translate({ engine: msg.engine, key: msg.key, texts: [text], target: msg.target, source: msg.lang || lang });
      if (r && r.translations && r.translations[0]) { translation = String(r.translations[0]).trim(); by = E.label.split(" (")[0].split(",")[0]; }
    } catch (e) { by = "Google (" + E.label.split(" (")[0].split(",")[0] + ": " + String(e.message || e).slice(0, 80) + ")"; }
  }
  return { translation, translit: translit.trim(), lang: msg.lang || lang, detected: lang, cut: String(msg.text || "").length > 5000, by };
}

// ---------- Anki: invio diretto con AnkiConnect (funzioni comuni in background.js: ankiAddNotes, ankiCheck) ----------
// Un mazzo per ogni lingua ("Lingue::Inglese"…), gli stessi di Sottotitoli Doppi, oppure il mazzo unico del popup.
async function pavAnkiCheck(msg) {
  return ankiCheck({ ...msg, defDeck: PAV_DEFAULTS.ankiDeck });
}
async function pavAnki(msg) {
  const notes = (msg.entries || []).map((e) => ({ ...pavAnkiFields(e), lang: e.lang, image: e.image, word: e.word }));
  return ankiAddNotes(notes, PAV_DEFAULTS.ankiDeck, "pav");
}

// ---------- Scorciatoia da tastiera: accende e spegne ----------
if (chrome.commands && chrome.commands.onCommand) {
  chrome.commands.onCommand.addListener(async (cmd) => {
    const key = { "toggle-volo": "on", "toggle-hover": "hover", "toggle-select": "selection" }[cmd];
    if (!key) return;
    const s = await DS_EXT.storage.sync.get({ on: true, hover: true, selection: true, mode: "hover" });
    let now = s[key] !== false;
    if (key === "hover" && s.mode === "off") { await DS_EXT.storage.sync.set({ mode: "hover" }); now = false; }
    await DS_EXT.storage.sync.set({ [key]: !now });
  });
}

// PDF aperti nel browser → lettore di Parole al Volo (solo con "Apri sempre i PDF con Parole al Volo")
let pavPdfAuto = false;
DS_EXT.storage.sync.get({ pdfAuto: false }).then((r) => { pavPdfAuto = !!r.pdfAuto; }).catch(() => {});
DS_EXT.storage.onChanged.addListener((ch, area) => { if (area === "sync" && ch.pdfAuto) pavPdfAuto = !!ch.pdfAuto.newValue; });
DS_EXT.tabs.onUpdated.addListener((tabId, info) => {
  if (!pavPdfAuto || !info.url) return;
  let u;
  try { u = new URL(info.url); } catch { return; }
  if (!/^(https?|file):$/.test(u.protocol) || !/\.pdf$/i.test(u.pathname)) return;
  DS_EXT.tabs.update(tabId, { url: DS_EXT.runtime.getURL("pdf.html") + "?file=" + encodeURIComponent(info.url) }).catch(() => {});
});

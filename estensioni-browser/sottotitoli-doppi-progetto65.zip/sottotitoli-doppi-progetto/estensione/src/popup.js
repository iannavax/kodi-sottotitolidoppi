let compLang = "";   // lingua del video (dal calcolo delle parole conosciute)
const C = DS_CONFIG;
const $ = (id) => document.getElementById(id);
const DEMO = {
  it: "Quindi ci siamo andati ed era davvero buono", en: "So we went there and it was really good",
  es: "Así que fuimos allí y estaba muy bueno", fr: "Alors on y est allés et c'était vraiment bon",
  de: "Also sind wir hingegangen und es war echt gut", pt: "Então fomos lá e estava muito bom"
};

// 1.6.2: «Traduci in» con tutte le lingue di Google Traduttore, con il nome nella lingua dell'interfaccia e nella lingua stessa
(() => {
  const sel = $("targetLang");
  let ui = null; try { ui = new Intl.DisplayNames([dsUiLocale()], { type: "language" }); } catch {}
  const own = (c) => { try { return new Intl.DisplayNames([c], { type: "language" }).of(c) || ""; } catch { return ""; } };
  const items = C.TARGET_LANGS.map((c) => {
    const n = (ui && ui.of(c)) || c, o = own(c);
    const cap = (x) => x.charAt(0).toUpperCase() + x.slice(1);
    return [c, cap(n) + (o && o.toLowerCase() !== n.toLowerCase() ? " · " + o : "")];
  }).sort((a, b) => a[1].localeCompare(b[1]));
  sel.textContent = "";
  for (const [c, t] of items) sel.append(new Option(t, c));
})();

let s = { ...C.SYNC_DEFAULTS };
let keys = {};

function current() {
  const id = C.ENGINES[s.engine] ? s.engine : "google";
  return { id, E: C.ENGINES[id] };
}

function render() {
  const { id } = current();
  renderCleanInfo();
  renderFallback();
  DS_ENGINES_UI.banner($("blockedBox"), id, () => { renderFallback(); });
}

// ---------- Trascrizione dell'audio ----------
function renderLiveSettings() {
  $("transcribeMode").value = s.autoTranscribe === false ? "off" : (s.transcribeMode || "live");
  $("fullMaxMin").value = s.fullMaxMin || 60;
  $("liveAhead").checked = !!s.liveAhead;
  $("liveAheadDelay").value = String(dsAheadStep(s.liveAheadDelay));
  $("vodBack").value = String([0, 10, 20, 30, 60].includes(Number(s.vodBack)) ? Number(s.vodBack) : 20);
  renderAheadInfo();
  // chi trascrive e con quale modello si sceglie in «📊 Consumo e modelli» (1.6.2): qui solo il promemoria
  $("sttWho").textContent = "Trascrive " + (s.stt === "local" ? "il server Whisper sul tuo computer" : "Groq Whisper") + " con il modello «" + s.sttModel + "». Si cambia in 📊 Consumo e modelli → Trascrizione dell'audio; la chiave di Groq e l'indirizzo del server sono in 🔑 Servizi.";
  fillSttLangs();
}

const LEARN_KEYS = ["learnFreq", "learnNgram", "learnKnown", "learnKnownPage", "learnExamples", "learnAudio", "learnTable", "learnGender", "learnDialects", "learnSpell", "learnLlmExtra", "learnJisho", "learnGweb", "learnHan", "gdAlt", "gdDefs", "gdSyn", "gdSpell", "ankiImage"];
function updateComp(c) {
  if (c && c.lang) compLang = c.lang;
  const el = $("compInfo");
  if (!c || !c.total || (s && s.learnKnown === false)) { el.hidden = true; return; }
  el.hidden = false;
  el.textContent = c.mine
    ? `Conosci il ${c.pct}% delle parole di questo video (${c.uniqueKnown} parole diverse su ${c.unique}).`
    : "Segna le parole che conosci («la conosco?» nella scheda): qui vedrai quante parole del video conosci.";
}
function updateLiveMode(st) {
  const box = $("liveModeBox");
  box.hidden = !(st && st.onVideo && st.live && st.yt);
  if (box.hidden) return;
  $("liveModeSel").value = s.liveAhead ? "ahead" : "normal";
  const a = st.ahead || {};
  $("liveModeInfo").textContent = !s.liveAhead
    ? "Le frasi si trascrivono mentre le senti: arrivano qualche secondo dopo il parlato."
    : !st.running ? "Parte insieme alla trascrizione: premi «Trascrivi l'audio di questo video» (sezione 🎙 Trascrizione dell'audio)."
    : a.state === "on" ? `Attiva: le frasi sono pronte ${a.lead} s prima che il video arrivi lì.`
    : a.state === "aligning" ? "Sto leggendo l'audio della diretta e lo metto a tempo con il video (qualche secondo)…"
    : a.state === "failed" ? `Non disponibile per questa diretta${a.why ? ": " + a.why : ""}. Resta la trascrizione normale. Serve il programma per yt-dlp aggiornato (rilancia l'installatore dalla sezione 🎙 Trascrizione dell'audio), con ffmpeg.`
    : "Sto avviando la lettura dell'audio della diretta…";
}
// registro della diretta (per segnalare un problema): lo chiedo alla parte della pagina con il video e lo copio
// registro per il debug: quello della pagina (eventi + stato di adesso) e quello del sottofondo (richieste fallite)
// controlli rapidi (permessi, memoria, risposta della scheda) per capire perché l'estensione non parte
async function dsDiagnose(tab) {
  const out = [], to = (p, ms) => Promise.race([p, new Promise((r) => setTimeout(() => r("TIMEOUT"), ms))]);
  const step = async (name, fn) => { try { out.push("  " + name + ": " + JSON.stringify(await fn())); } catch (e) { out.push("  " + name + ": ERRORE " + (e && e.message || e)); } };
  try { const o = new URL(tab.url).origin; await step("permesso sul sito " + o, () => to(chrome.permissions.contains({ origins: [o + "/*"] }), 3000)); } catch {}
  await step("memoria sync", async () => { const r = await to(chrome.storage.sync.get(null), 4000); return r === "TIMEOUT" ? r : { chiavi: Object.keys(r).length, enabled: r.enabled, siti_spenti: r.disabledSites }; });
  await step("scrittura sync", async () => { const r = await to(chrome.storage.sync.set({ __prova: 1 }).then(() => chrome.storage.sync.remove("__prova")), 4000); return r === "TIMEOUT" ? r : "ok"; });
  await step("memoria local (chiavi note)", async () => { const r = await to(chrome.storage.local.get({ keys: {} }), 4000); return r === "TIMEOUT" ? r : "risponde"; });
  await step("memoria local (tutto)", async () => { const r = await to(chrome.storage.local.get(null), 5000); return r === "TIMEOUT" ? r : Object.keys(r).length + " chiavi"; });
  if (tab) await step("risposta della scheda", () => to(new Promise((r) => chrome.tabs.sendMessage(tab.id, { type: "getLiveLog" }, (x) => r(chrome.runtime.lastError ? "nessuna: " + chrome.runtime.lastError.message : "ok"))), 3000));
  return out;
}
function copyDebugLog(b, title, label) {
  // il testo si prepara in più secondi: la copia parte subito con una "promessa" (se il browser la accetta), così non
  // scade il permesso del clic; se non si riesce a copiare, il registro compare in una casella da copiare a mano
  const textP = new Promise((resolve) => withTab((tab) => {
    const done = async (resp) => {
      let bg = "";
      try { bg = ((await chrome.runtime.sendMessage({ type: "getBgLog" })) || {}).log || ""; } catch {}
      let ver = "";
      try { const m = chrome.runtime.getManifest(); ver = m.name + " " + m.version; } catch {}
      const lines = [title + " — " + new Date().toLocaleString(), ver, (resp && resp.url) || (tab && tab.url) || ""];
      if (!resp) lines.push("", "LA PAGINA NON RISPONDE: l'estensione non è attiva in questa scheda (ricarica la pagina con F5; se non basta, il sito potrebbe essere spento nel popup).");
      else {
        if (resp.ahead) lines.push("Sincronizzata: " + JSON.stringify(resp.ahead));
        if (resp.snap) lines.push("", "STATO ADESSO", ...Object.entries(resp.snap).map(([k, v]) => "  " + k + ": " + (typeof v === "object" ? JSON.stringify(v) : v)));
        lines.push("", "EVENTI DELLA PAGINA", resp.log || "(vuoto)");
      }
      lines.push("", "RICHIESTE FALLITE NEL SOTTOFONDO", bg || "(nessuna)");
      lines.push("", "DIAGNOSI", ...(await dsDiagnose(tab)));
      resolve(lines.join("\n"));
    };
    if (!tab) return done(null);
    chrome.tabs.sendMessage(tab.id, frameTarget ? { type: "getLiveLog", target: frameTarget } : { type: "getLiveLog" }, (resp) => done(chrome.runtime.lastError ? null : resp));
  }));
  b.textContent = "… preparo il registro";
  (async () => {
    let ok = false;
    try {
      if (window.ClipboardItem && navigator.clipboard.write) {
        await navigator.clipboard.write([new ClipboardItem({ "text/plain": textP.then((t) => new Blob([t], { type: "text/plain" })) })]);
        ok = true;
      }
    } catch {}
    const text = await textP;
    if (!ok) { try { await navigator.clipboard.writeText(text); ok = true; } catch {} }
    if (ok) b.textContent = "✓ Registro copiato: incollalo nella segnalazione";
    else {
      b.textContent = "Copia a mano il testo qui sotto (Ctrl+A, Ctrl+C)";
      let ta = document.getElementById("debugLogBox");
      if (!ta) { ta = document.createElement("textarea"); ta.id = "debugLogBox"; ta.readOnly = true; ta.style.cssText = "width:100%;height:160px;margin-top:6px;font:11px monospace"; b.insertAdjacentElement("afterend", ta); }
      ta.value = text; ta.focus(); ta.select();
    }
    setTimeout(() => { b.textContent = label; }, 6000);
  })();
}
$("liveLogCopy").addEventListener("click", (e) => copyDebugLog(e.currentTarget, "Registro della diretta", "📋 Copia il registro della diretta"));
$("debugLogCopy").addEventListener("click", (e) => copyDebugLog(e.currentTarget, "Registro per il debug", "📋 Copia il registro per il debug"));
$("liveModeSel").addEventListener("change", (e) => {
  s.liveAhead = e.target.value === "ahead";
  $("liveAhead").checked = s.liveAhead;
  chrome.storage.sync.set({ liveAhead: s.liveAhead });
  setTimeout(() => askTab({ type: "liveState" }), 400);
});
function updateLive(st) {
  updateComp(st && st.comp);
  updateLiveMode(st);
  // trascrizione in corso (o già fatta): la correzione con Gemini/Groq si accende e spegne da qui
  $("cleanQuick").hidden = !(st && st.onVideo && (st.running || st.full || st.fullBusy));
  if (!$("cleanQuick").hidden) renderCleanInfo();
  if (!st || !st.onVideo) {
    $("liveBtn").disabled = true;
    $("redoBox").hidden = true; $("redoTrBox").hidden = true;
    $("videoMode").disabled = true;
    $("liveInfo").textContent = "In questa pagina non c'è un video o un audio (o va ricaricata dopo l'installazione).";
    return;
  }
  $("liveBtn").disabled = false;
  $("videoMode").disabled = false;
  // trascrizione già fatta (anche solo in parte): si può rifare da capo
  $("redoBox").hidden = !(st.cues > 0 || st.full) || !!st.fullBusy;
  $("redoTrBox").hidden = !(st.cues > 0 || st.full || st.hasTrack) || !!st.fullBusy;
  $("redoSttBetter").hidden = !st.better;
  $("videoMode").value = st.mode || "";
  $("liveBtn").textContent = st.running || st.fullBusy ? "Ferma la trascrizione" : "Trascrivi l'audio di questo video";
  if (st.fullBusy) { $("liveInfo").textContent = "Trascrizione completa in corso: " + (st.fullText || "…"); return; }
  if (st.full) { $("liveInfo").textContent = "Questo video è già trascritto per intero."; return; }
  $("liveInfo").textContent = st.running
    ? "Trascrizione in corso: le frasi arrivano con qualche secondo di ritardo."
    : st.hasCaptions === false
      ? "Questo video non ha sottotitoli."
      : st.hasCaptions
        ? "Questo video ha già i sottotitoli: premi CC. Puoi comunque trascrivere l'audio."
        : "L'audio viene trascritto mentre guardi, con qualche secondo di ritardo.";
}

function withTab(fn) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => fn(tabs && tabs[0]));
}

let frameTarget = null;   // la parte della pagina (video) con cui sto parlando
function askTab(message) {
  withTab((tab) => {
    if (!tab) return updateLive(null);
    const msg = message.type === "liveState" || !frameTarget ? message : { ...message, target: frameTarget };
    chrome.tabs.sendMessage(tab.id, msg, (resp) => {
      if (chrome.runtime.lastError) return updateLive(null);
      if (resp && resp.frame) frameTarget = resp.frame;
      updateLive(resp);
    });
  });
}

function showStatus(st) {
  if (st && st.text) $("status").textContent = st.text;
}

function checkPerm() {
  chrome.permissions.contains({ origins: C.HOSTS }, (ok) => { $("perm").hidden = !!ok; });
}

chrome.storage.sync.get(C.SYNC_DEFAULTS, (stored) => {
  s = { ...stored, models: { ...(stored.models || {}) } };
  dsLocalGet({ keys: {}, apiKey: "", status: null }, (l) => {
    keys = { ...(l.keys || {}) };
    if (!keys.claude && l.apiKey) keys.claude = l.apiKey;
    $("targetLang").value = s.targetLang;
    $("uiLang").checked = !!s.uiLang;
    $("enabled").checked = s.enabled;
    $("hideNative").checked = s.hideNative;
    $("fontSize").value = s.fontSize;
    $("hoverPause").checked = s.hoverPause !== false;
    $("holdOnHover").checked = s.holdOnHover === true;
    $("showStatusTrans").checked = s.showStatusTrans !== false;
    $("knownBtn").checked = s.knownBtn !== false;
    $("knownKey").checked = s.knownKey !== false;
    $("showUsageBadge").checked = s.showUsageBadge !== false;
    $("showStatusTl").checked = s.showStatusTl !== false;
    $("localFull").checked = s.localFull !== false;
    $("idioms").checked = s.idioms === true;
    $("idiomsUnderline").checked = s.idiomsUnderline !== false;
    $("ipa").checked = s.ipa !== false;
    $("etym").checked = s.etym !== false;
    $("roman").checked = !!s.roman;
    $("romanHan").checked = s.romanHan !== false;
    $("ankiPerLang").checked = s.ankiPerLang !== false;
    $("ankiCharDeck").checked = s.ankiCharDeck !== false;
    chrome.storage.local.get({ ankiMoveUndo: [] }, (r) => { $("ankiMoveUndo").hidden = !(r.ankiMoveUndo || []).length; });
    $("ankiLangDeck").value = s.ankiLangDeck || "Lingue::{lingua}";
    $("ankiDeck").value = s.ankiDeck || "Sottotitoli Doppi";
    $("ankiAuto").checked = !!s.ankiAuto;
    $("ankiAudio").checked = s.ankiAudio !== false;
    ankiRows();
    for (const k of LEARN_KEYS) $(k).checked = k === "ankiImage" ? !!s[k] : s[k] !== false;
    $("cleanMode").value = dsCleanMode(s);
    renderCleanInfo();
    renderLook(); renderCardLook();
    ttsPicker.fill();
    fillVoices();
    $("demo").textContent = DEMO[s.targetLang] || DEMO.en;
    render();
    DS_ENGINES_UI.order($("orderBox"), { onUse: (id) => { s.engine = id; render(); } });
    DS_ENGINES_UI.services($("servicesBox"), { onKey: (id, k, prev) => {
      // la prima chiave incollata mentre i sottotitoli usano ancora Google: i sottotitoli passano a quel servizio
      const first = k[id] && s.engine === "google" && C.ENGINES[id] && C.ENGINES[id].needsKey && !Object.keys(prev || {}).some((x) => prev[x]);
      keys = { ...k };
      if (first) { s.engine = id; chrome.storage.sync.set({ engine: id }); }
      renderCleanInfo(); renderFallback(); renderUse();
    } });
    renderLiveSettings();
    renderConsumo();
    renderUse();
    // Whisper sul computer con il nome di modello di Groq (predefinito): provo subito a prendere quello giusto dal server
    if (s.stt === "local" && (C.STT_MODELS || []).includes(s.sttModel)) chrome.runtime.sendMessage({ type: "sttModels", url: s.sttUrl }).then((r) => { if (r && r.suggested) chrome.storage.sync.set({ sttModel: r.suggested }); }).catch(() => {});
    showStatus(l.status);
    askTab({ type: "liveState" });
  });
});
chrome.storage.onChanged.addListener((changes, area) => {
  // «Modello per ogni compito» (engines-ui.js) cambia anche servizio e trascrizione: aggiorno le sezioni del popup
  if (area === "sync" && s && ((changes.stt && changes.stt.newValue !== s.stt) || changes.sttModel)) {
    if (changes.stt) s.stt = changes.stt.newValue;
    if (changes.sttModel) s.sttModel = changes.sttModel.newValue;
    renderLiveSettings();
  }
  if (area === "local" && changes.keys) { keys = { ...(changes.keys.newValue || {}) }; renderCleanInfo(); renderFallback(); renderUse(); }
  if (area === "local" && changes.dsBlocked && s) render();
  if (area === "sync" && s && changes.engine && changes.engine.newValue && changes.engine.newValue !== s.engine) { s.engine = changes.engine.newValue; render(); }
  if (area === "sync" && s && (changes.engineOrder || changes.engineOff)) {
    if (changes.engineOrder) s.engineOrder = changes.engineOrder.newValue || [];
    if (changes.engineOff) s.engineOff = changes.engineOff.newValue || [];
    renderFallback();
  }
  // «Consumo»: una scelta cambiata (qui o in un'altra parte del popup) può farlo diventare «Personalizzato»
  if (area === "sync" && s) {
    let touched = false;
    for (const k of CONSUMO_KEYS) if (changes[k]) { s[k] = changes[k].newValue; touched = true; }
    if (touched) { renderConsumo(); renderLiveSettings(); $("cleanMode").value = dsCleanMode(s); renderCleanInfo(); $("idioms").checked = s.idioms === true; }
    if (changes.dailyCap) { s.dailyCap = changes.dailyCap.newValue || {}; renderUse(); }
  }
  // 1.7.19: la scelta «Per questo video» è la stessa in tutte le finestre
  if (area === "sync" && s && changes.videoModeSticky) { s.videoModeSticky = changes.videoModeSticky.newValue || ""; setTimeout(() => askTab({ type: "liveState" }), 300); }
  if (area === "local" && changes.dsUsage) renderUse();
  if (area === "local" && changes.status) {
    showStatus(changes.status.newValue);
    askTab({ type: "liveState" });
  }
});
checkPerm();

$("grant").addEventListener("click", () => chrome.permissions.request({ origins: C.HOSTS }, () => checkPerm()));
$("targetLang").addEventListener("change", (e) => {
  s.targetLang = e.target.value;
  chrome.storage.sync.set({ targetLang: s.targetLang });
  $("demo").textContent = DEMO[s.targetLang] || DEMO.en;
});
$("enabled").addEventListener("change", (e) => chrome.storage.sync.set({ enabled: e.target.checked }));
// interfaccia nella lingua di «Traduci in»: le pagine aperte si aggiornano da sole, il popup si riapre già tradotto
$("uiLang").addEventListener("change", (e) => chrome.storage.sync.set({ uiLang: e.target.checked }, () => setTimeout(() => location.reload(), 150)));
$("hideNative").addEventListener("change", (e) => chrome.storage.sync.set({ hideNative: e.target.checked }));

$("liveBtn").addEventListener("click", () => {
  const start = $("liveBtn").textContent.startsWith("Trascrivi");
  askTab({ type: "live", action: start ? "start" : "stop" });
});
$("transcribeMode").addEventListener("change", (e) => {
  s.transcribeMode = e.target.value;
  s.autoTranscribe = true;
  chrome.storage.sync.set({ transcribeMode: s.transcribeMode, autoTranscribe: true });
});
$("liveAhead").addEventListener("change", (e) => { s.liveAhead = e.target.checked; chrome.storage.sync.set({ liveAhead: s.liveAhead }); });
$("vodBack").addEventListener("change", (e) => { s.vodBack = Number(e.target.value); chrome.storage.sync.set({ vodBack: s.vodBack }); });
$("liveAheadDelay").addEventListener("change", (e) => {
  s.liveAheadDelay = dsAheadStep(e.target.value);
  chrome.storage.sync.set({ liveAheadDelay: s.liveAheadDelay });
  renderAheadInfo();
});
// la spiegazione breve sotto «Quanto indietro guardi la diretta» (i numeri vengono da dsAheadProfile, config.js)
function renderAheadInfo() {
  const p = dsAheadProfile(s.liveAheadDelay);
  $("liveAheadInfo").textContent = `Più indietro guardi, meno richieste: l'audio va a Whisper a pezzi di circa ${p.pieceS} s, e le frasi già pronte ` +
    `aspettano e si traducono insieme (fino a ${p.group}) quando la prima sta per comparire, ${p.trBeforeS} s prima. ` +
    "In cambio vedi la diretta più in ritardo (la chat va avanti rispetto a te).";
}
$("fullMaxMin").addEventListener("change", (e) => {
  s.fullMaxMin = Math.max(1, Number(e.target.value) || 60);
  chrome.storage.sync.set({ fullMaxMin: s.fullMaxMin });
});
function redoStt(precise) {
  if (!confirm("Cancellare la trascrizione di questo video e rifarla da capo?")) return;
  askTab({ type: "redo", what: "transcription", precise });
  $("redoBox").hidden = true;
  setTimeout(() => askTab({ type: "liveState" }), 800);
}
$("redoStt").addEventListener("click", () => redoStt(false));
$("redoTr").addEventListener("click", () => { askTab({ type: "redo", what: "translation" }); $("redoTrBox").hidden = true; setTimeout(() => askTab({ type: "liveState" }), 1500); });
$("redoSttBetter").addEventListener("click", () => redoStt(true));
// 1.7.30: vale solo per il video aperto e riparte da «Come quella predefinita» a ogni video (il menu serve per un video specifico;
// per tutti gli altri c'è «Per tutti i video senza sottotitoli»)
$("videoMode").addEventListener("change", (e) => {
  askTab({ type: "setMode", mode: e.target.value });
});
$("helperBtn").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("helper.html") }));
// ---------- Lingua parlata: tutte le lingue di Whisper, con ricerca ----------
const STT_NAMES = (() => {
  let it = null, own = null;
  try { it = new Intl.DisplayNames([dsUiLocale()], { type: "language" }); } catch {}
  const fix = { jw: "jv" };   // codice di Whisper diverso da quello standard
  return Object.entries(C.STT_LANGS).map(([code, en]) => {
    const std = fix[code] || code;
    let name = "", native = "";
    try { name = it ? it.of(std) : ""; } catch {}
    try { own = new Intl.DisplayNames([std], { type: "language" }); native = own.of(std); } catch { native = ""; }
    if (!name || name === std) name = en.charAt(0).toUpperCase() + en.slice(1);
    name = name.charAt(0).toUpperCase() + name.slice(1);
    // senza i dati di quella lingua il browser restituisce il nome inglese: non lo mostro
    if (native && (native.toLowerCase() === name.toLowerCase() || native.toLowerCase() === en || native === std)) native = "";
    return { code, name, native, en, key: [name, native, en, code].join(" ").toLowerCase().normalize("NFD").replace(/\p{M}/gu, "") };
  }).sort((a, b) => a.name.localeCompare(b.name, "it"));
})();

// Menu di lingua con ricerca (usato per la lingua parlata e per quella della pronuncia)
function langPicker(o) {
  // o = { id, empty, emptyNow, key }: id = prefisso degli elementi (select #id, ricerca #idSearch, #idNow, #idHint)
  const sel = $(o.id), search = $(o.id + "Search");
  const norm = (x) => x.trim().toLowerCase().normalize("NFD").replace(/\p{M}/gu, "");
  const fill = (filter = "") => {
    const q = norm(filter), chosen = s[o.key] || "";
    const list = q ? STT_NAMES.filter((l) => l.key.includes(q)) : STT_NAMES;
    sel.textContent = "";
    if (!q || norm(o.empty + " automatica auto").includes(q)) sel.append(new Option(o.empty, ""));
    for (const l of list) sel.append(new Option(l.native ? `${l.name} · ${l.native}` : l.name, l.code));
    // la lingua scelta resta in cima anche se non è tra i risultati, così resta selezionata
    if (q && chosen && !list.some((l) => l.code === chosen)) {
      const cur = STT_NAMES.find((l) => l.code === chosen);
      if (cur) sel.prepend(new Option(cur.name + " (scelta ora)", cur.code));
    }
    sel.value = chosen;
    if (q) sel.size = Math.max(2, Math.min(7, sel.options.length)); else sel.removeAttribute("size");
    $(o.id + "Hint").hidden = !q || list.length > 0;
    const cur = STT_NAMES.find((l) => l.code === chosen);
    $(o.id + "Now").textContent = cur ? "· " + cur.name : "· " + o.emptyNow;
  };
  const choose = (code) => {
    s[o.key] = code || "";
    chrome.storage.sync.set({ [o.key]: s[o.key] });
    search.value = "";
    fill();
    if (o.onChange) o.onChange();
  };
  sel.addEventListener("change", () => choose(sel.value));
  sel.addEventListener("click", (e) => { if (sel.size > 1 && e.target.tagName === "OPTION") choose(e.target.value); });
  sel.addEventListener("keydown", (e) => { if (e.key === "Enter" && sel.size > 1) { e.preventDefault(); choose(sel.value); } });
  search.addEventListener("input", () => fill(search.value));
  search.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const first = [...sel.options].find((x) => !x.text.endsWith("(scelta ora)"));
      if (search.value.trim() && first) choose(first.value);
    } else if (e.key === "ArrowDown" && sel.size > 1) { e.preventDefault(); sel.focus(); sel.selectedIndex = 0; }
    else if (e.key === "Escape" && search.value) { e.preventDefault(); search.value = ""; fill(); }
  });
  return { fill: () => fill(search.value) };
}
const sttPicker = langPicker({ id: "sttLang", key: "sttLang", empty: "Rileva da sola", emptyNow: "rilevata da sola" });
const fillSttLangs = () => sttPicker.fill();

// ---------- Vocabolario ----------
function showVocabCount() {
  chrome.storage.local.get({ vocab: {} }, (r) => {
    const n = Object.keys(r.vocab || {}).length;
    $("vocabBtn").textContent = n ? `📒 Vocabolario (${n})` : "📒 Vocabolario";
    $("vocabBtn").title = n ? `Le ${n} parole e frasi salvate con ☆` : "Le parole e le frasi salvate con ☆";
  });
}
showVocabCount();
// ---------- Anki ----------
function ankiRows() { const on = $("ankiPerLang").checked; $("ankiLangDeckRow").hidden = !on; $("ankiDeckRow").hidden = on; }
$("ankiPerLang").addEventListener("change", (e) => { s.ankiPerLang = e.target.checked; chrome.storage.sync.set({ ankiPerLang: e.target.checked }); ankiRows(); });
$("ankiCharDeck").addEventListener("change", (e) => { s.ankiCharDeck = e.target.checked; chrome.storage.sync.set({ ankiCharDeck: e.target.checked }); });
// 1.7.7: sposta i caratteri (kanji, hanzi, hanja) già in Anki nel sottomazzo dei caratteri; prima conta, poi chiede conferma
$("ankiMoveChars").addEventListener("click", async () => {
  const info = $("ankiMoveInfo"), btn = $("ankiMoveChars");
  btn.disabled = true; info.textContent = "Cerco i caratteri nelle tue carte…";
  try {
    const d = await chrome.runtime.sendMessage({ type: "ankiMoveChars", dry: true });
    if (d && d.error) throw new Error(d.error);
    if (!d.found) { info.textContent = "Non ci sono carte di un solo carattere (kanji, hanzi, hanja) da spostare."; btn.disabled = false; return; }
    if (!confirm(`Trovate ${d.found} carte di un solo carattere (kanji, hanzi, hanja).\nLe sposto in: ${d.decks.join(", ")}\n\nPuoi annullare dopo con «Annulla lo spostamento». Procedo?`)) { info.textContent = ""; btn.disabled = false; return; }
    info.textContent = "Sposto…";
    const r = await chrome.runtime.sendMessage({ type: "ankiMoveChars" });
    if (r && r.error) throw new Error(r.error);
    info.textContent = `Spostate ${r.moved} carte nel sottomazzo (${r.already} erano già a posto).` + (r.moved ? " Il contenuto delle carte lo rifai da 🔄 «Aggiorna le carte già in Anki…»." : "");
    $("ankiMoveUndo").hidden = !r.moved;
  } catch (e) { info.textContent = "Non riuscito: " + (e.message || e) + (/connessione|fetch|Failed/i.test(String(e.message || e)) ? " (Anki è aperto, con AnkiConnect?)" : ""); }
  btn.disabled = false;
});
$("ankiMoveUndo").addEventListener("click", async () => {
  const info = $("ankiMoveInfo");
  try { const r = await chrome.runtime.sendMessage({ type: "ankiMoveUndo" }); if (r && r.error) throw new Error(r.error); info.textContent = `Rimesse a posto ${r.restored} carte.`; $("ankiMoveUndo").hidden = true; }
  catch (e) { info.textContent = "Non riuscito: " + (e.message || e); }
});
$("ankiLangDeck").addEventListener("change", (e) => chrome.storage.sync.set({ ankiLangDeck: e.target.value.trim() || "Lingue::{lingua}" }));
$("ankiDeck").addEventListener("change", (e) => chrome.storage.sync.set({ ankiDeck: e.target.value.trim() || "Sottotitoli Doppi" }));
$("ankiAuto").addEventListener("change", (e) => { s.ankiAuto = e.target.checked; chrome.storage.sync.set({ ankiAuto: e.target.checked }); });
$("ankiAudio").addEventListener("change", (e) => { s.ankiAudio = e.target.checked; chrome.storage.sync.set({ ankiAudio: e.target.checked }); });
$("ankiTest").addEventListener("click", () => {
  const st = $("ankiStatus");
  st.textContent = "Collego… (se Anki chiede il permesso, premi Yes)";
  chrome.runtime.sendMessage({ type: "ankiCheck" }, (r) => {
    if (chrome.runtime.lastError) r = { error: chrome.runtime.lastError.message };
    st.textContent = r && !r.error ? `Collegato ad Anki (AnkiConnect ${r.version}). Tipo di nota: ${r.model}. Per esempio le parole inglesi vanno nel mazzo «${r.example}».` : (r && r.error) || "Nessuna risposta.";
  });
});
$("vocabBtn").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("vocab.html") }));
$("ankiUpdOpen").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("vocab.html") + "?upd=1" }));
// elenco delle parole più usate (con le parole che conosci) nella lingua del video, o in quella con più parole conosciute
$("freqBtn").addEventListener("click", async () => {
  let lang = compLang;
  if (!lang) {
    const kw = (await DS_EXT.storage.local.get({ knownWords: {} })).knownWords || {};
    lang = Object.keys(kw).sort((a, b) => String(kw[b]).split("\n").length - String(kw[a]).split("\n").length)[0] || "en";
  }
  chrome.tabs.create({ url: chrome.runtime.getURL("freq.html") + "?lang=" + encodeURIComponent(String(lang).split("-")[0]) + "&target=" + encodeURIComponent((s && s.targetLang) || "it") });
});
$("hoverPause").addEventListener("change", (e) => chrome.storage.sync.set({ hoverPause: e.target.checked }));
$("holdOnHover").addEventListener("change", (e) => chrome.storage.sync.set({ holdOnHover: e.target.checked }));
$("showUsageBadge").addEventListener("change", (e) => { s.showUsageBadge = e.target.checked; chrome.storage.sync.set({ showUsageBadge: e.target.checked }); renderBadge(); });
$("knownBtn").addEventListener("change", (e) => chrome.storage.sync.set({ knownBtn: e.target.checked }));
$("knownKey").addEventListener("change", (e) => chrome.storage.sync.set({ knownKey: e.target.checked }));
$("showStatusTrans").addEventListener("change", (e) => chrome.storage.sync.set({ showStatusTrans: e.target.checked }));
$("showStatusTl").addEventListener("change", (e) => chrome.storage.sync.set({ showStatusTl: e.target.checked }));
$("localFull").addEventListener("change", (e) => chrome.storage.sync.set({ localFull: e.target.checked }));
$("idioms").addEventListener("change", (e) => chrome.storage.sync.set({ idioms: e.target.checked }));
$("idiomsUnderline").addEventListener("change", (e) => chrome.storage.sync.set({ idiomsUnderline: e.target.checked }));
$("ipa").addEventListener("change", (e) => chrome.storage.sync.set({ ipa: e.target.checked }));
$("etym").addEventListener("change", (e) => chrome.storage.sync.set({ etym: e.target.checked }));
$("roman").addEventListener("change", (e) => chrome.storage.sync.set({ roman: e.target.checked }));
$("romanHan").addEventListener("change", (e) => chrome.storage.sync.set({ romanHan: e.target.checked }));
for (const k of LEARN_KEYS) $(k).addEventListener("change", (e) => { s[k] = e.target.checked; chrome.storage.sync.set({ [k]: e.target.checked }); if (k === "learnKnown") askTab({ type: "liveState" }); });
$("fallback").addEventListener("change", (e) => { s.fallback = e.target.checked; chrome.storage.sync.set({ fallback: e.target.checked }); renderFallback(); });

// Quali servizi di riserva sono pronti (hanno la chiave) e quali hanno finito le richieste di oggi
function renderFallback() {
  $("fallback").checked = s.fallback !== false;
  chrome.storage.local.get({ dsBlocked: {} }, (r) => {
    const day = (() => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return ""; } })();
    const name = (id) => C.ENGINES[id].label.split(" (")[0].split(",")[0];
    const ready = C.engineOrder(s).filter((id) => keys[id] || (C.ENGINES[id].local && (s.models || {})[id]));
    const parts = ready.map((id) => { const b = dsBlockState(r.dsBlocked, id, s, day); return name(id) + (b.all ? " (finite per oggi)" : b.models.length ? " (finito oggi: " + b.models.join(", ") + ")" : ""); });
    $("fallbackInfo").textContent = s.fallback === false ? "" : ready.length
      ? "Servizi con la chiave, in quest'ordine: " + parts.join(", ") + ". Poi Google Traduttore."
      : "Per avere servizi di riserva, scegli Groq, Mistral o OpenRouter qui sopra e inserisci la loro chiave gratuita (poi torna al servizio che preferisci).";
  });
}
for (const id of ["cleanMode", "cleanMode2"]) $(id).addEventListener("change", (e) => {
  s.cleanMode = e.target.value;
  s.cleanTranscript = e.target.value !== "off";
  $("cleanMode").value = $("cleanMode2").value = e.target.value;
  chrome.storage.sync.set({ cleanMode: s.cleanMode, cleanTranscript: s.cleanTranscript });
  renderCleanInfo();
});

// Chi corregge la trascrizione (stessa scelta di cleanerEngine in content.js)
function renderCleanInfo() {
  const E = C.ENGINES[s.engine] || C.ENGINES.google;
  const name = E.label.split(" (")[0].split(",")[0];
  let t;
  const mode = dsCleanMode(s);
  if (mode === "off") t = "Spenta: le frasi restano come le ha capite Whisper.";
  else if (E.kind === "openai" || E.kind === "claude") t = `La fa ${name} nella stessa richiesta della traduzione: nessuna richiesta in più.`;
  else if (keys.gemini) t = "La fa Gemini con la tua chiave, a gruppi di frasi (una richiesta ogni 10-30 frasi). Intanto vedi la traduzione rapida; poi traduce " + name + " il testo corretto.";
  else if (keys.groq) t = "La fa Groq (stessa chiave della trascrizione), a gruppi di frasi (una richiesta ogni 10-30 frasi). Intanto vedi la traduzione rapida; poi traduce " + name + " il testo corretto.";
  else t = "Per correggerla serve una chiave Gemini o Groq (nella sezione Traduzione o qui sopra).";
  // solo frasi incerte: si correggono quelle di cui Whisper non è sicuro (con un modello che traduce non cambia niente)
  if (mode === "uncertain" && !(E.kind === "openai" || E.kind === "claude") && (keys.gemini || keys.groq)) t += " Solo le frasi di cui Whisper non è sicuro: circa metà delle richieste.";
  $("cleanInfo").textContent = t;
  $("cleanInfo2").textContent = t;
  $("cleanMode2").value = mode;
}

// ---------- Pronuncia ----------
async function fillVoices() {
  const voices = await DS_TTS.voicesReady();
  const lang = s.ttsLang || "";
  const group = $("ttsVoices");
  group.textContent = "";
  const list = voices
    .filter((v) => !lang || DS_TTS.base(v.lang) === lang)
    .sort((a, b) => a.lang.localeCompare(b.lang) || a.name.localeCompare(b.name));
  for (const v of list) {
    const o = document.createElement("option");
    o.value = v.voiceURI;
    o.textContent = `${v.name} (${v.lang})`;
    group.append(o);
  }
  group.label = list.length ? "Voci installate sul computer" : "Nessuna voce installata per questa lingua";
  const saved = s.ttsVoice || "";
  $("ttsVoice").value = saved;
  if ($("ttsVoice").value !== saved) $("ttsVoice").value = ""; // la voce salvata non è di questa lingua
  if (lang && !list.length) {
    $("ttsInfo").textContent = C.GOOGLE_TTS.includes(lang)
      ? "Sul computer non c'è una voce per questa lingua: in automatico verrà usata quella di Google."
      : "Per questa lingua non c'è una voce né sul computer né su Google, quindi la pronuncia non è disponibile. " +
        "Puoi aggiungere una voce al computer (Windows: Impostazioni → Ora e lingua → Voce) e poi riaprire questo menu.";
  } else {
    $("ttsInfo").textContent = "";
  }
  fillPiper();
}

// ---------- 1.7.0: voci Piper ----------
// Piper: voci neurali gratuite che girano sul computer (si scarica la voce una volta, 20-110 MB); Speaches: le stesse sul tuo server
async function fillPiper() {
  const lang = s.ttsLang || "";
  const gp = $("ttsPiper"), gs = $("ttsSpeachesG");
  const gk = $("ttsKokoroG");
  gp.textContent = ""; gs.textContent = ""; gk.textContent = ""; gp.hidden = gs.hidden = gk.hidden = true;
  $("ttsSpeaches").checked = !!s.ttsSpeaches;
  if (!lang) {   // senza una lingua scelta le voci Piper non si possono elencare: lo dico invece di nasconderle
    gp.hidden = false; gp.label = "Voci Piper gratuite (sul computer)";
    const o = document.createElement("option"); o.disabled = true; o.textContent = "Scegli prima una lingua qui sopra per vedere le voci Piper";
    gp.append(o);
    if (s.ttsSpeaches) { gs.hidden = false; const o2 = o.cloneNode(true); gs.append(o2); const gk0 = $("ttsKokoroG"); gk0.hidden = false; gk0.append(o.cloneNode(true)); }
    piperBoxShow(); return;
  }
  let list = [];
  try { list = await DS_TTS.piperVoices(lang); } catch {}
  const perr = DS_TTS.piperError();
  if (!list.length) {
    gp.hidden = false;
    const o = document.createElement("option"); o.disabled = true;
    o.textContent = perr ? "Voci Piper non disponibili: " + perr : "Nessuna voce Piper per questa lingua";
    gp.append(o); gp.label = "Voci Piper gratuite (sul computer)";
    if (perr) $("ttsInfo").textContent = "Voci Piper non disponibili: " + perr + ". Se usi Firefox dimmelo: è la parte che non ho potuto provare.";
  }
  const fill = (grp, prefix, mark) => {
    if (!list.length) return;
    for (const v of list) {
      const o = document.createElement("option");
      o.value = prefix + v.key;
      o.textContent = v.label + mark(v);
      grp.append(o);
    }
    grp.hidden = !list.length;
  };
  fill(gp, "piper:", (v) => (v.have ? " ✓" : " — da scaricare"));
  if (s.ttsSpeaches) {
    const inst = await DS_TTS.speachesInstalled();
    window.__speachesInst = inst;
    const all = list; try { list = await DS_TTS.speachesVoices(lang); } catch { list = []; }   // solo le voci che Speaches ha come pacchetto
    fill(gs, "speaches:", (v) => (inst && inst.includes(v.key) ? " ✓" : inst ? " — da installare sul server" : ""));
    list = all;
    if (!inst) gs.label = "Voci Piper del server Speaches (server non raggiungibile)";
    // 1.7.26: voci Kokoro (un solo pacchetto sul server per tutte)
    const kk = dsKokoroVoices(lang);
    if (kk.length) {
      const haveK = !!(await chrome.runtime.sendMessage({ type: "speachesTts", op: "list", url: s.sttUrl || undefined }).then((r) => r && r.kokoro).catch(() => false));
      window.__kokoroHave = haveK;
      for (const v of kk) { const o = document.createElement("option"); o.value = "kokoro:" + v.key; o.textContent = v.label + (haveK ? " ✓" : " — da installare sul server"); gk.append(o); }
      gk.hidden = false;
    } else {
      // nessuna voce Kokoro per questa lingua: lo dico invece di nascondere il gruppo
      const o = document.createElement("option"); o.disabled = true; o.textContent = "Kokoro non ha voci per questa lingua (ha: inglese, italiano, francese, spagnolo, portoghese, hindi, giapponese, cinese)";
      gk.append(o); gk.hidden = false;
    }
  }
  const saved = s.ttsVoice || "";
  $("ttsVoice").value = saved;
  if ($("ttsVoice").value !== saved) $("ttsVoice").value = "";
  piperBoxShow();
  piperHaveRender();
}
// 1.7.8: «Voci Piper scaricate»: l'elenco di tutte, con la dimensione e 🗑 per toglierne una
async function piperHaveRender() {
  const box = $("piperHave");
  if (!box) return;
  let list = [];
  try { const r = await dsSendLong({ type: "piper", op: "list" }); list = (r && r.have) || []; } catch {}
  box.textContent = "";
  const det = $("piperHaveBox");
  if (det) det.hidden = !list.length;
  const total = list.reduce((a, x) => a + x.size, 0);
  $("piperHaveTotal").textContent = list.length ? ` · ${list.length} voci${total ? ", " + DS_TTS.mb(total) : ""}` : "";
  for (const x of list) {
    const row = document.createElement("div"); row.className = "row";
    const nm = document.createElement("span"); nm.textContent = x.key + (x.size ? " · " + DS_TTS.mb(x.size) : "");
    const del = document.createElement("button"); del.type = "button"; del.className = "ghost"; del.textContent = "🗑"; del.title = "Elimina questa voce dal computer (si può riscaricare)";
    del.addEventListener("click", async () => {
      del.disabled = true;
      try { await dsSendLong({ type: "piper", op: "remove", key: x.key }); } catch {}
      for (const [lg, v] of Object.entries(s.ttsVoices || {})) if (v === "piper:" + x.key) { const m = { ...s.ttsVoices }; delete m[lg]; s.ttsVoices = m; chrome.storage.sync.set({ ttsVoices: m }); }
      if (s.ttsVoice === "piper:" + x.key) { s.ttsVoice = ""; chrome.storage.sync.set({ ttsVoice: "" }); }
      DS_TTS.piperInvalidate(); fillPiper();
    });
    row.append(nm, del); box.append(row);
  }
}
function piperSel() {
  const v = $("ttsVoice").value;
  const m = /^(piper|speaches|kokoro):(.+)$/.exec(v);
  return m ? { kind: m[1], key: m[2] } : null;
}
async function piperBoxShow() {
  const sel = piperSel(), box = $("piperBox");
  box.hidden = !sel;
  if (!sel) return;
  const lang = s.ttsLang || "";
  const v = (await DS_TTS.piperVoices(lang)).find((x) => x.key === sel.key);
  if (sel.kind === "kokoro") {
    const has = !!window.__kokoroHave;
    $("piperInfo").textContent = has ? "Kokoro è installato sul tuo server Speaches: tutte le sue voci funzionano." : "Kokoro non è ancora sul tuo server Speaches: si installa con un clic (circa 330 MB, un solo pacchetto per tutte le voci).";
    $("piperGet").hidden = has; $("piperGet").textContent = "⬇ Installa Kokoro sul server";
    $("piperDel").hidden = true;
  } else if (sel.kind === "piper") {
    $("piperInfo").textContent = v && v.have
      ? "Voce scaricata: funziona anche senza internet."
      : `Questa voce va scaricata una volta${v && v.size ? " (" + DS_TTS.mb(v.size) + ")" : ""} da HuggingFace; poi resta nel browser. Si scarica anche da sola alla prima volta che la usi.`;
    $("piperGet").hidden = !!(v && v.have); $("piperGet").textContent = "⬇ Scarica la voce";
    $("piperDel").hidden = !(v && v.have);
  } else {
    const inst = window.__speachesInst;
    const has = !!(inst && inst.includes(sel.key));
    $("piperInfo").textContent = has ? "Voce già installata sul tuo server Speaches."
      : inst ? "Sul tuo server Speaches questa voce non c'è ancora: si installa con un clic (poi resta sul server)." : "Il server Speaches non risponde: è avviato? (l'indirizzo è quello della trascrizione sul computer)";
    $("piperGet").hidden = has || !inst; $("piperGet").textContent = "⬇ Installa sul server";
    $("piperDel").hidden = true;
  }
}
$("piperRefresh").addEventListener("click", async () => {
  const btn = $("piperRefresh"), info = $("piperImportInfo");
  btn.disabled = true; info.textContent = "Aggiorno l'elenco…";
  try {
    const r = await dsSendLong({ type: "piper", op: "refresh" });
    if (r && r.error && !r.count) throw new Error(r.error);
    info.textContent = `Elenco aggiornato: ${r.count} voci.` + (r.error ? " (Non ho potuto raggiungere l'archivio: uso quello già salvato — " + r.error + ")" : "");
  } catch (e) { info.textContent = "Non riesco ad aggiornare l'elenco: " + (e.message || e); }
  DS_TTS.piperInvalidate(); await fillPiper();
  btn.disabled = false;
});
$("ttsSpeaches").addEventListener("change", (e) => { s.ttsSpeaches = e.target.checked; chrome.storage.sync.set({ ttsSpeaches: s.ttsSpeaches }); fillPiper(); });
$("piperGet").addEventListener("click", async () => {
  const sel = piperSel(); if (!sel) return;
  const btn = $("piperGet"); btn.disabled = true;
  try {
    if (sel.kind === "piper") { $("piperInfo").textContent = "Scarico la voce…"; const r = await dsSendLong({ type: "piper", op: "download", key: sel.key }); if (r && r.error) throw new Error(r.error); }
    else if (sel.kind === "kokoro") { $("piperInfo").textContent = "Installo Kokoro sul server (può volerci un po')…"; const r = await chrome.runtime.sendMessage({ type: "speachesTts", op: "installKokoro", url: s.sttUrl || undefined }); if (r && r.error) throw new Error(r.error); }
    else { $("piperInfo").textContent = "Installo la voce sul server…"; const r = await chrome.runtime.sendMessage({ type: "speachesTts", op: "install", key: sel.key, url: s.sttUrl || undefined }); if (r && r.error) throw new Error(r.error); }
    DS_TTS.piperInvalidate(); await fillPiper();
  } catch (e) { $("piperInfo").textContent = "Non riuscito: " + (e.message || e); }
  btn.disabled = false;
});
$("piperDel").addEventListener("click", async () => {
  const sel = piperSel(); if (!sel) return;
  try { await dsSendLong({ type: "piper", op: "remove", key: sel.key }); } catch {}
  DS_TTS.piperInvalidate(); await fillPiper();
});
// Le voci scaricate da un'altra estensione non si possono leggere (ogni estensione ha il suo spazio chiuso): se i file della voce
// ci sono sul computer, si importano da qui; la Cache dell'estensione è la stessa della pagina nascosta che parla.
$("piperImport").addEventListener("click", () => $("piperFiles").click());
$("piperFiles").addEventListener("change", async (e) => {
  const files = [...e.target.files]; e.target.value = "";
  const info = $("piperImportInfo");
  const by = {};
  for (const f of files) { const m = /^(.+?)\.onnx(\.json)?$/.exec(f.name); if (m) (by[m[1]] = by[m[1]] || {})[m[2] ? "cfg" : "onnx"] = f; }
  const done = [], bad = [];
  for (const [key, f] of Object.entries(by)) {
    const m = /^([a-z]{2,3})_([A-Za-z]+)-(.+)-(x_low|low|medium|high)$/.exec(key);
    if (!m || !f.onnx || !f.cfg) { bad.push(key); continue; }
    try {
      const url = "https://huggingface.co/rhasspy/piper-voices/resolve/main/" + [m[1], m[1] + "_" + m[2], m[3], m[4], key].map(encodeURIComponent).join("/");
      JSON.parse(await f.cfg.text());
      const c = await caches.open("piper-voices-v1");
      await c.put(url + ".onnx", new Response(f.onnx, { headers: { "content-type": "application/octet-stream", "x-size": String(f.onnx.size) } }));
      await c.put(url + ".onnx.json", new Response(f.cfg, { headers: { "content-type": "application/json" } }));
      done.push(key);
    } catch { bad.push(key); }
  }
  info.textContent = (done.length ? "Importate: " + done.join(", ") + ". " : "") + (bad.length ? "Non importate (servono tutti e due i file, .onnx e .onnx.json, con il nome originale tipo it_IT-riccardo-x_low): " + bad.join(", ") : "") || "Nessun file .onnx scelto.";
  DS_TTS.piperInvalidate(); await fillPiper();
});
chrome.runtime.onMessage.addListener((m) => {
  if (m && m.type === "piperProgress" && m.total) $("piperInfo").textContent = `Scarico la voce… ${Math.round(m.loaded / 1048576)} / ${Math.round(m.total / 1048576)} MB`;
});

const ttsPicker = langPicker({ id: "ttsLang", key: "ttsLang", empty: "Automatica (quella del video)", emptyNow: "quella del video", onChange: () => fillVoices() });
$("ttsVoice").addEventListener("change", (e) => {
  s.ttsVoice = e.target.value;
  chrome.storage.sync.set({ ttsVoice: s.ttsVoice });
  piperBoxShow();
});
$("ttsTest").addEventListener("click", async () => {
  const lang = s.ttsLang || "en";
  // per le lingue senza frase di prova dico il nome della lingua nella lingua stessa
  const own = STT_NAMES.find((l) => l.code === lang);
  const text = C.TTS_SAMPLES[lang] || (own && (own.native || own.name)) || C.TTS_SAMPLES.en;
  $("ttsInfo").textContent = "…";
  let r;
  try { r = await DS_TTS.speak(text, lang, { lang: s.ttsLang || "", voice: $("ttsVoice").value }); }
  catch (e) { $("ttsInfo").textContent = "Pronuncia non disponibile: " + (e.message || e); return; }
  $("ttsInfo").textContent = "Usata: " + r.how + (s.ttsLang ? "" : ". In automatico la lingua è quella del video; per la prova uso l'inglese.");
});

// ---------- Aspetto dei sottotitoli ----------
const LOOK = ["subShow", "transFirst", "hideLine", "levelColors", "fontSize", "transScale", "origColor", "transColor", "bgOpacity", "subPos", "subFont", "romanSize", "romanLineSize"];
// 1.7.30: grandezza del testo, della traduzione e altezza ricordate per sito (siteStyle[host]); l'interruttore siteMemory le tiene per sito
const SITE_KEYS = ["fontSize", "transScale", "subPos"];
let siteHost = "";
const siteOn = () => !!siteHost && s.siteMemory !== false;
const siteVal = (k) => { const v = siteOn() && s.siteStyle && s.siteStyle[siteHost]; return v && v[k] != null ? v[k] : null; };
const romanSizeShow = () => { for (const k of ["romanSize", "romanLineSize"]) $(k + "Val").textContent = $(k).value + "%"; };
function renderLook() {
  for (const k of LOOK) {
    const el = $(k);
    if (el.type === "checkbox") el.checked = !!s[k];
    else el.value = SITE_KEYS.includes(k) && siteVal(k) != null ? siteVal(k) : s[k] != null ? s[k] : C.SYNC_DEFAULTS[k];
  }
  $("siteMemory").checked = s.siteMemory !== false;
  romanSizeShow();
}
for (const k of LOOK) {
  const el = $(k);
  el.addEventListener(el.type === "range" || el.type === "color" ? "input" : "change", () => {
    const v = el.type === "checkbox" ? el.checked : el.type === "range" ? Number(el.value) : el.value;
    if (SITE_KEYS.includes(k) && siteOn()) {
      const m = { ...(s.siteStyle || {}) };
      m[siteHost] = { ...(m[siteHost] || {}), [k]: v };
      s.siteStyle = m;
      chrome.storage.sync.set({ siteStyle: m });
      return;
    }
    s[k] = v;
    chrome.storage.sync.set({ [k]: v });
    if (k === "romanSize" || k === "romanLineSize") romanSizeShow();
  });
}
$("siteMemory").addEventListener("change", (e) => { s.siteMemory = e.target.checked; chrome.storage.sync.set({ siteMemory: s.siteMemory }); renderLook(); });
$("resetLook").addEventListener("click", () => {
  const d = {};
  for (const k of LOOK) d[k] = C.SYNC_DEFAULTS[k];
  Object.assign(s, d);
  if (siteHost && s.siteStyle && s.siteStyle[siteHost]) { const m = { ...s.siteStyle }; delete m[siteHost]; s.siteStyle = m; d.siteStyle = m; }
  chrome.storage.sync.set(d);
  renderLook(); renderCardLook();
});

// ---------- Aspetto delle schede (video e pagine) ----------
const CARDLOOK = ["cardScale", "cardBg", "cardOpacity", "cardText", "cardAccent", "cardPosVideo", "cardPosPage"];
const cardShow = () => { $("cardScaleVal").textContent = $("cardScale").value + "%"; };
function renderCardLook() {
  for (const k of CARDLOOK) $(k).value = s[k] != null ? s[k] : C.SYNC_DEFAULTS[k];
  cardShow();
  // la posizione sulle pagine c'è solo nell'estensione unica (Parole al Volo)
  $("cardPosPageRow").hidden = !document.getElementById("p-dPages");
}
for (const k of CARDLOOK) {
  const el = $(k);
  el.addEventListener(el.type === "range" || el.type === "color" ? "input" : "change", () => {
    const v = el.type === "range" ? Number(el.value) : el.value;
    s[k] = v;
    chrome.storage.sync.set({ [k]: v });
    cardShow();
  });
}
$("resetCardLook").addEventListener("click", () => {
  const d = {};
  for (const k of CARDLOOK) d[k] = C.SYNC_DEFAULTS[k];
  Object.assign(s, d);
  chrome.storage.sync.set(d);
  renderCardLook();
});

// ---------- Pagina della trascrizione ----------
$("transcriptBtn").addEventListener("click", () => {
  withTab((tab) => {
    const q = tab && tab.id != null ? "?tab=" + tab.id : "";
    chrome.tabs.create({ url: chrome.runtime.getURL("transcript.html" + q) });
  });
});

// ---------- Attiva / disattiva su questo sito ----------
withTab((tab) => {
  let host = "";
  try { host = tab && tab.url ? new URL(tab.url).hostname : ""; } catch {}
  if (!host) return;
  siteHost = host;
  $("siteMemRow").hidden = false;
  $("siteMemLabel").textContent = "Ricorda grandezza e altezza per " + host;
  renderLook();
  $("siteRow").hidden = false;
  $("siteLabel").textContent = "Attiva su " + host;
  chrome.storage.sync.get({ disabledSites: [] }, (r) => {
    $("siteOn").checked = !(r.disabledSites || []).includes(host);
  });
  $("siteOn").addEventListener("change", (e) => {
    chrome.storage.sync.get({ disabledSites: [] }, (r) => {
      const list = new Set(r.disabledSites || []);
      if (e.target.checked) list.delete(host); else list.add(host);
      chrome.storage.sync.set({ disabledSites: [...list] });
    });
  });
});

// da dove prendere le immagini per le carte di Anki
(() => {
  const sel = document.getElementById("ankiImageSource");
  if (!sel) return;
  DS_EXT.storage.sync.get({ ankiImageSource: "google" }).then((r) => { sel.value = r.ankiImageSource || "google"; }).catch(() => {});
  sel.addEventListener("change", () => DS_EXT.storage.sync.set({ ankiImageSource: sel.value }));
  const ql = document.getElementById("ankiImageLang");
  if (ql) {
    DS_EXT.storage.sync.get({ ankiImageLang: "word" }).then((r) => { ql.value = r.ankiImageLang || "word"; }).catch(() => {});
    ql.addEventListener("change", () => DS_EXT.storage.sync.set({ ankiImageLang: ql.value }));
  }
})();

// ---------- «Consumo delle richieste» e «📊 Consumo e modelli» ----------
const CONSUMO_KEYS = ["consumo", "liveAheadDelay", "cleanMode", "cleanTranscript", "idioms", "idiomAuto", "taskModels", "liveAheadMax"];
const CONSUMO_INFO = {
  quality: "Diretta 20 s indietro, correzione di tutte le frasi trascritte, modi di dire e collegamento tra le parole trovati dal modello, Gemini Flash per tutto. Più richieste: circa 150-250 a Gemini per ogni ora di diretta.",
  balanced: "Diretta 45 s indietro, correzione solo delle frasi incerte, Gemini Flash-Lite per tradurre e Flash per le spiegazioni (i limiti gratuiti di Gemini sono per modello: così si dividono). Circa 60-90 richieste per ora di diretta; un video con i sottotitoli circa 10.",
  saving: "Diretta 90 s indietro (gruppi di frasi più grandi), niente correzione della trascrizione, Flash-Lite per tradurre. Circa 30-60 richieste per ora di diretta; un video con i sottotitoli circa 10.",
  free: "Traduce Google Traduttore; la trascrizione dei video senza sottotitoli parte solo se la avvii tu. I modelli lavorano solo quando premi un pulsante (per esempio «✨ Spiega con…»). Il servizio scelto per tradurre resta salvato.",
  custom: "Hai cambiato a mano una delle scelte (diretta, correzione, modi di dire o modelli). Scegli una modalità per tornare ai suoi valori."
};
function renderConsumo() {
  const m = dsConsumoOf(s);
  $("consumo").value = m;
  $("consumoInfo").textContent = CONSUMO_INFO[m] || "";
}
$("consumo").addEventListener("change", async (e) => {
  const v = dsConsumoValues(e.target.value, s.taskModels);
  if (!v) return;
  Object.assign(s, v);
  await chrome.storage.sync.set(v);
  renderConsumo();
});
$("liveAheadMax").addEventListener("change", (e) => { s.liveAheadMax = Number(e.target.value) || 90; chrome.storage.sync.set({ liveAheadMax: s.liveAheadMax }); });
// richieste di oggi per servizio (le conta il sottofondo) e limite al giorno scelto da te
async function renderUse() {
  $("liveAheadMax").value = String([60, 90, 150, 240].includes(Number(s.liveAheadMax)) ? Number(s.liveAheadMax) : 90);
  const l = await chrome.storage.local.get({ dsUsage: null });
  const u = l.dsUsage;
  const day = (() => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return ""; } })();
  const n = u && u.day === day ? u.n || {} : {};
  const name = (id) => (id === "whisper" ? "Groq Whisper" : C.ENGINES[id] ? (C.ENGINES[id].local ? "Modello sul computer" : C.ENGINES[id].label.split(" (")[0].split(",")[0]) : id);
  const cap = s.dailyCap || {};
  const parts = Object.entries(n).filter(([, v]) => v > 0).map(([id, v]) => name(id) + " " + v + (cap[id] ? "/" + cap[id] : ""));
  $("usageBox").textContent = "Richieste di oggi: " + (parts.length ? parts.join(" · ") : "nessuna") + ". (Il giorno delle quote finisce a mezzanotte in California, verso le 9 in Italia.)";
  // limiti: per i servizi con la chiave (o il modello sul computer) e per Groq Whisper
  const ids = Object.keys(C.ENGINES).filter((id) => id !== "google" && id !== "youtube" && (keys[id] || (C.ENGINES[id].local && (s.models || {})[id])));
  if (keys.groq) ids.push("whisper");
  const box = $("capRows");
  box.textContent = "";
  if (!ids.length) { box.append(Object.assign(document.createElement("p"), { className: "small", textContent: "Nessun servizio con la chiave." })); return; }
  for (const id of ids) {
    const lab = document.createElement("label"); lab.className = "row"; lab.textContent = name(id) + " ";
    const inp = document.createElement("input"); inp.type = "number"; inp.min = "0"; inp.step = "10"; inp.placeholder = "nessuno";
    inp.style.cssText = "width:80px;background:var(--panel);color:var(--paper);border:1px solid var(--line);border-radius:6px;padding:4px 6px";
    inp.value = cap[id] ? String(cap[id]) : "";
    inp.addEventListener("change", () => {
      const c = { ...(s.dailyCap || {}) };
      const v = Math.max(0, Math.round(Number(inp.value) || 0));
      if (v) c[id] = v; else delete c[id];
      s.dailyCap = c;
      chrome.storage.sync.set({ dailyCap: c });
    });
    lab.append(inp);
    box.append(lab);
  }
}


// 1.7.14: menu «Quali varianti mostrare, per lingua» (pronuncia IPA nelle varianti): sync ipaVar = { lingua: { off: [id…], other: false } }
(async function ipaVarMenu() {
  const sel = $("ipaVarLang"), list = $("ipaVarList");
  if (!sel || !list || typeof DS_DIALECTS === "undefined") return;
  const name = (c) => { try { return new Intl.DisplayNames([dsUiLocale()], { type: "language" }).of(c) || c; } catch { return c; } };
  const codes = Object.keys(DS_DIALECTS).sort((a, b) => name(a).localeCompare(name(b)));
  for (const c of codes) sel.append(new Option(name(c), c));
  let pv = (await DS_EXT.storage.sync.get({ ipaVar: {} })).ipaVar || {};
  const save = () => DS_EXT.storage.sync.set({ ipaVar: pv });
  function draw() {
    const lg = sel.value, cur = pv[lg] || {};
    list.textContent = "";
    const add = (label, on, change) => {
      const row = document.createElement("label"); row.className = "row";
      const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = on;
      cb.addEventListener("change", () => change(cb.checked));
      row.append(label + " ", cb);
      list.append(row);
    };
    for (const [id, nm] of DS_DIALECTS[lg]) {
      add(nm, !(cur.off || []).includes(id), (on) => {
        const o = new Set((pv[lg] || {}).off || []);
        if (on) o.delete(id); else o.add(id);
        pv = { ...pv, [lg]: { ...(pv[lg] || {}), off: [...o] } }; save();
      });
    }
    add("Altre varianti trovate su Wiktionary (con la loro etichetta)", cur.other !== false, (on) => { pv = { ...pv, [lg]: { ...(pv[lg] || {}), other: on } }; save(); });
  }
  sel.addEventListener("change", draw);
  sel.value = codes.includes("en") ? "en" : codes[0];
  draw();
})();


// 1.7.15: correzione dei sottotitoli automatici di YouTube con il modello (sync cleanAsr)
(async function cleanAsrBox() {
  const cb = $("cleanAsr");
  if (!cb) return;
  cb.checked = !!(await DS_EXT.storage.sync.get({ cleanAsr: false })).cleanAsr;
  cb.addEventListener("change", () => DS_EXT.storage.sync.set({ cleanAsr: cb.checked }));
})();


// 1.8.0: traduzione già presente nel video (traccia nella tua lingua): unirla invece di tradurre (sync useBuiltinTrans, di serie acceso)
(async function builtinTransBox() {
  const cb = $("useBuiltinTrans");
  if (!cb) return;
  cb.checked = (await DS_EXT.storage.sync.get({ useBuiltinTrans: true })).useBuiltinTrans !== false;
  cb.addEventListener("change", () => DS_EXT.storage.sync.set({ useBuiltinTrans: cb.checked }));
})();
// 1.7.17: usare la trascrizione salvata al posto dei sottotitoli automatici (sync useSavedTranscript, di serie acceso)
(async function savedTranscriptBox() {
  const cb = $("useSavedTranscript");
  if (!cb) return;
  cb.checked = (await DS_EXT.storage.sync.get({ useSavedTranscript: true })).useSavedTranscript !== false;
  cb.addEventListener("change", () => DS_EXT.storage.sync.set({ useSavedTranscript: cb.checked }));
})();


// ---------- 1.7.30: contatore delle richieste di oggi, sempre in alto nel popup ----------
async function renderBadge() {
  const b = $("usageBadge");
  if (!b) return;
  if (s.showUsageBadge === false) { b.hidden = true; return; }
  const l = await chrome.storage.local.get({ dsUsage: null, dsBlocked: {}, keys: {} });
  const day = (() => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return ""; } })();
  const n = l.dsUsage && l.dsUsage.day === day ? l.dsUsage.n || {} : {};
  const cap = s.dailyCap || {};
  const short = (id) => (id === "whisper" ? "Whisper" : C.ENGINES[id] ? (C.ENGINES[id].local ? "Locale" : C.ENGINES[id].label.split(/[ ,(]/)[0]) : id);
  const used = Object.entries(n).filter(([, v]) => v > 0);
  const parts = used.map(([id, v]) => short(id) + " " + (cap[id] ? Math.max(0, cap[id] - v) + " restano" : v));
  const done = Object.keys(C.ENGINES).filter((id) => (l.keys || {})[id] && dsBlockState(l.dsBlocked, id, s, day).all).map(short);
  const bits = [...parts.slice(0, 3), ...(done.length ? ["⚠ finite: " + done.join(", ")] : [])];
  if (!bits.length) { b.hidden = true; return; }
  b.hidden = false;
  b.classList.toggle("warn", done.length > 0);
  b.textContent = "📊 " + bits.join(" · ");
  b.title = "Richieste di oggi (il giorno delle quote finisce a mezzanotte in California): " + (used.map(([id, v]) => short(id) + " " + v + (cap[id] ? " su " + cap[id] : "")).join(", ") || "nessuna") +
    (done.length ? ". Finite le richieste gratuite di: " + done.join(", ") : "") + ". Per vedere quante ne restano, metti un limite in 📊 Consumo e modelli → Limite di richieste al giorno. Clic per aprire.";
}
$("usageBadge").addEventListener("click", () => { const d = $("dUse"); if (d) { d.open = true; d.scrollIntoView({ block: "center", behavior: "smooth" }); } });
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && (ch.dsUsage || ch.dsBlocked || ch.keys)) renderBadge(); if (area === "sync" && (ch.dailyCap || ch.showUsageBadge)) { if (ch.dailyCap) s.dailyCap = ch.dailyCap.newValue || {}; renderBadge(); } });
setTimeout(renderBadge, 400);

// ---------- 1.7.30: esporta e importa tutte le impostazioni ----------
$("expSettings").addEventListener("click", async () => {
  const m = $("settingsMsg");
  try { const r = await dsExportSettings($("expKeys").checked); m.textContent = `Salvato «${r.name}» (${r.n} impostazioni${r.keys ? ", con le chiavi: tienilo al sicuro" : ", senza le chiavi"}).`; }
  catch (e) { m.textContent = "Non riesco: " + (e.message || e); }
});
$("impSettings").addEventListener("click", () => $("impSettingsFile").click());
$("impSettingsFile").addEventListener("change", async () => {
  const f = $("impSettingsFile").files[0]; $("impSettingsFile").value = "";
  if (!f) return;
  const m = $("settingsMsg");
  try { const r = await dsImportSettings(await f.text()); m.textContent = `Importate ${r.n} impostazioni${r.keys ? " (con le chiavi)" : ""}. Riapro il popup…`; setTimeout(() => location.reload(), 900); }
  catch (e) { m.textContent = "Non riesco a importare: " + (e.message || e); }
});

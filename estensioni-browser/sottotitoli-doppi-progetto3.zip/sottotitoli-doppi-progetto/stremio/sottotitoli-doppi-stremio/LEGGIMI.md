# Sottotitoli Doppi per Stremio

*English version → [GUIDE.en](GUIDE.en.md)*

Add-on di sottotitoli per Stremio: per film e serie propone i sottotitoli nella lingua originale con la **traduzione sotto ogni riga** (in giallo).

## Come funziona
Un add-on di Stremio non si installa dentro l'app: è un piccolo servizio che gira sul tuo computer e che Stremio interroga quando apri un film o una puntata.
1. L'add-on prende i sottotitoli dal servizio OpenSubtitles che Stremio usa già, in **tutte le lingue disponibili** per quel film (tranne quella in cui traduci).
2. Nell'elenco dei sottotitoli di Stremio trovi una versione doppia per ogni lingua, per esempio **"Doppi: Francese → Italiano"**, **"Doppi: Inglese → Italiano"**: scegli quella della lingua in cui è parlato il film. Funziona con qualsiasi lingua.
3. Il file doppio ha l'originale sopra e la traduzione sotto. Se è fuori sincrono, nella configurazione puoi chiedere 2 o 3 versioni per ogni lingua e provare la successiva.

La lingua del film viene riconosciuta dal paese di produzione e messa per prima ("lingua del film"). Se non si riesce a riconoscerla (paese sconosciuto o coproduzioni), viene messa per prima la lingua con più sottotitoli. Se vuoi sempre e solo una lingua, puoi sceglierla in "Lingue originali da proporre".

**Quando si traduce (impostazione "Quando tradurre", dalla 1.3).** Stremio chiede l'elenco dei sottotitoli a ogni film che apri, anche quelli per cui non userai i doppi. Di serie l'add-on, aprendo un film, scarica soltanto il file originale della prima lingua (gratis) e **traduce solo quando scegli una versione "Doppi"**: nessuna quota di Gemini sprecata. Se preferisci la massima velocità la prima volta, scegli "In anticipo": la prima lingua viene tradotta appena apri il film (consuma quota anche per i film in cui non li usi). I film già tradotti una volta sono salvati e si caricano subito in tutti e due i casi.

Stremio aspetta il file solo pochi secondi: con Gemini, le righe che non ha ancora tradotto vengono completate subito con Google, così il sottotitolo si carica sempre. Gemini intanto continua, e la sua versione viene salvata: dalla volta dopo che apri quel film (o se lo riselezioni dopo qualche minuto) vedi tutta la traduzione di Gemini.

## Installazione (Stremio per computer)
1. Installa **Node.js** (versione LTS) da nodejs.org, se non ce l'hai.
2. Estrai lo zip in una cartella.
3. Avvia l'add-on:
   - **Windows**: doppio clic su `avvia-windows.bat`.
   - **Mac / Linux**: `sh avvia-mac-linux.sh` dal Terminale.

   Si apre la pagina di configurazione e resta aperta una finestra nera: **lasciala aperta** finché usi Stremio.
4. Nella pagina scegli la lingua in cui tradurre e il servizio. Per Gemini, Groq e gli altri incolla la chiave: sono le stesse dell'estensione per il browser.
5. Premi **Installa in Stremio**. Se non si apre Stremio, premi **Copia l'indirizzo** e incollalo in Stremio nella barra di ricerca della sezione Add-on.

Per cambiare impostazioni: in Stremio, Add-on → Sottotitoli Doppi → Configura, poi reinstalla.

## Telefono, tablet, TV
Le app di Stremio su questi dispositivi accettano solo add-on raggiungibili via Internet con un indirizzo **https**. L'add-on va quindi messo online: per esempio su un servizio di hosting per Node.js, oppure sul tuo computer dietro un tunnel https come Cloudflare Tunnel. Va avviato con queste impostazioni:
- `HOST=0.0.0.0` per accettare collegamenti dall'esterno;
- `PUBLIC_URL=https://indirizzo-pubblico` perché i link ai sottotitoli puntino all'indirizzo giusto.

Attenzione: la chiave del servizio di traduzione è contenuta nell'indirizzo dell'add-on, quindi non condividerlo.

## Impostazioni avanzate (variabili d'ambiente)
- `PORT`: porta (predefinita 7000).
- `SD_WAIT_MS`: quanti millisecondi aspettare la traduzione del servizio scelto prima di completare con Google (predefinito 3000).
- `SD_FILL_MS`: tempo massimo per completare con Google prima di rispondere comunque (predefinito 6000).

Le traduzioni vengono salvate nella cartella `cache`. Puoi cancellarla quando vuoi.

## Aggiornare
Chiudi la finestra nera, sostituisci i file nella stessa cartella (la cartella `cache` puoi lasciarla) e riavvia. Non serve reinstallare l'add-on in Stremio.

## Se qualcosa non va
La finestra nera scrive ogni richiesta di Stremio, con l'ora e quanto ci ha messo il file ad arrivare: se un sottotitolo non compare, lì c'è il motivo.

## Limiti
- Servono sottotitoli originali su OpenSubtitles: per i contenuti che non li hanno, l'add-on non propone niente. La trascrizione dell'audio non è possibile, perché gli add-on di Stremio non hanno accesso al video (per i film sul computer la fa l'add-on per Kodi).
- L'add-on legge solo OpenSubtitles. Se nell'elenco di Stremio vedi sottotitoli in una lingua che non ha la versione "Doppi", potrebbero venire da un altro add-on di sottotitoli che hai installato.
- Il colore della traduzione funziona in Stremio per computer. Se su un dispositivo vedi dei codici come `<font…>`, nella configurazione attiva **"Traduzione senza colore"**.
- Non si possono cliccare le parole come nell'estensione.

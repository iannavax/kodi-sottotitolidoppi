// Logica principale: riceve i sottotitoli (o li crea dall'audio), li fa tradurre e li mostra sul video.
const C = DS_CONFIG;

let settings = null;
let track = null;       // sottotitoli di YouTube: { videoId, lang, kind, baseUrl, cues, segments }
let transCues = [];     // modalità YouTube riga per riga
let segTrans = [];      // una traduzione per frase
let translating = false;
let job = 0, reqId = 0;
let lastSignature = "";
const pending = new Map();
const hasCaptions = {};
const dsAvailTracks = {};   // video → tracce di sottotitoli che YouTube offre ({ lang, kind, name, url }), per «Unisci sottotitoli»
const dsAsrInfo = {};      // video → { lang, segments } dei sottotitoli automatici di YouTube (lingua dell'audio)
let dsCcRetryAt = 0;
let overlay = null, lineOrig = null, lineTrans = null;

const baseLang = (l) => (l || "").split("-")[0].toLowerCase();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const toPage = (msg) => window.postMessage(JSON.stringify({ __dualsub: "ext", ...msg }), location.origin);
// getVideo(), currentVideoId(), dsPlayerBox() arrivano da media.js

// "Traduzione" identica all'originale (il modello o Google l'hanno solo ricopiata)
function dsNorm(t) { return String(t || "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ""); }
function dsIsEcho(orig, trans) {
  // Traduzione identica o quasi (una virgola, una parola in più o in meno) all'originale
  const words = (t) => String(t || "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  const a = words(orig), b = words(trans);
  if (a.length >= 3 && b.length) {
    if (a.join(" ") === b.join(" ")) return true;
    const set = new Set(a);
    const ratio = b.length / a.length;
    if (ratio > 0.7 && ratio < 1.45 && b.filter((x) => set.has(x)).length / Math.max(a.length, b.length) >= 0.8) return true;
  }
  // …oppure scritta in una lingua diversa da quella in cui traduci (per esempio l'originale ripulito)
  const g = DualSubs.guessLang(trans);
  const target = String((settings && settings.targetLang) || "").split("-")[0];
  if (g && target && g !== target) return true;
  // …o in un altro alfabeto (per esempio la trascrizione araba al posto della traduzione italiana): prima passava,
  // veniva salvata e ricompariva sempre, anche cambiando lingua
  return !!(target && DualSubs.wrongLang(trans, target));
}
// Traduzione salvata che non può essere quella della sua frase (vuota o di lunghezza molto diversa)
function dsBadSaved(src, t) {
  if (dsIsEcho(src, t) || dsUncheckedCopy(src, t, settings && settings.targetLang)) return true;
  if (String(src).trim().split(/\s+/).length < 3) return false;
  return !String(t).trim() || t.length > src.length * 2.6 + 25 || t.length < src.length * 0.3;
}
const dsSiteDisabled = () => !!(settings && (settings.disabledSites || []).includes(location.hostname));

// Registro per il debug (popup → «📋 Copia il registro per il debug»): lo stato di adesso, in una riga per voce
function dsDebugSnap() {
  const out = {};
  const put = (k, f) => { try { out[k] = f(); } catch (e) { out[k] = "errore: " + e.message; } };
  put("versione", () => DS_EXT.runtime.getManifest().version + " · " + dsSelfName());
  put("browser", () => navigator.userAgent.replace(/^Mozilla\/5\.0 /, ""));
  put("impostazioni", () => settings ? { acceso: settings.enabled !== false, traduttore: settings.engine, lingua: settings.targetLang,
    trascrizione: settings.stt + (settings.sttModel ? " / " + settings.sttModel : ""), diretteSincronizzate: !!settings.liveAhead,
    chiavi: Object.keys(settings.keys || {}).filter((k) => settings.keys[k]) } : "non ancora caricate");
  put("video", () => { const m = getVideo(); return m ? { id: currentVideoId(), pronto: m.readyState, fermo: m.paused, tempo: Math.round(m.currentTime), durata: isFinite(m.duration) ? Math.round(m.duration) : "diretta", src: String(m.currentSrc || "").slice(0, 30) } : "nessun video trovato"; });
  put("sottotitoliYouTube", () => { const v = currentVideoId(); return v ? (hasCaptions[v] === undefined ? "non so" : hasCaptions[v]) : "-"; });
  put("testo", () => track ? { video: track.videoId, lingua: track.lang, tipo: track.kind, frasi: track.segments.length } : "nessuno");
  put("traduzione", () => ({ inCorso: translating, pronte: segTrans.filter((x) => x != null).length, su: segTrans.length }));
  put("riquadro", () => overlay ? (overlay.hidden ? "nascosto" : "visibile") + (overlay.isConnected ? "" : " (staccato dalla pagina)") : "non creato");
  put("pulsanteDS", () => dsToggleBtn ? (dsToggleBtn.hidden ? "nascosto" : dsToggleBtn.classList.contains("on") ? "acceso" : "spento") + (dsToggleBtn.isConnected ? "" : " (staccato)") : "non creato");
  put("trascrizione", () => ({ inCorso: live.running, completa: live.fullBusy ? "in corso" : !!live.full, frasi: live.cues.length, modo: live.modes[currentVideoId()] || "predefinito" }));
  put("sitoSpento", () => dsSiteDisabled());
  put("cornice", () => window === window.top ? "pagina principale" : "dentro una cornice: " + location.hostname);
  return out;
}
// errori del codice dell'estensione in questa pagina: nel registro
window.addEventListener("error", (e) => { try { const base = DS_EXT.runtime.getURL(""); if (/ResizeObserver loop/.test(e.message || "")) return; if (!e.filename || e.filename.startsWith(base)) dsLiveLog("ERRORE: " + e.message + (e.filename ? " (" + e.filename.replace(base, "") + ":" + e.lineno + ")" : "")); } catch {} });
window.addEventListener("unhandledrejection", (e) => { try { const r = e.reason; if (r && /Extension context invalidated/i.test(String(r.message || r))) dsLiveLog("ERRORE: l'estensione è stata aggiornata o ricaricata: ricarica la pagina (F5)"); } catch {} });

// 1.7.30: la scelta «Per questo video» (modo di trascrizione) vale solo finché resti su quel video: cambiando video riparte da «Come quella
// predefinita». Le scelte rimaste salvate da prima si cancellano all'avvio.
let dsModeVideo = null;
function dsModeReset(v) {
  if (dsModeVideo === v) return;
  const prev = dsModeVideo;
  dsModeVideo = v;
  if (prev === null) { DS_EXT.storage.local.set({ modes: {} }).catch(() => {}); live.modes = {}; if (v && typeof liveApplyDefault === "function" && hasCaptions[v] === false) { /* la trascrizione parte come sempre */ } return; }
  if (prev && live.modes[prev]) { const m = { ...live.modes }; delete m[prev]; live.modes = m; DS_EXT.storage.local.set({ modes: m }).catch(() => {}); }
}
let dsLastStatus = { text: "", at: 0 };
function setStatus(text) {
  dsLiveLog("stato: " + text);
  dsLastStatus = { text: String(text || ""), at: Date.now() };
  try { chrome.storage.local.set({ status: { text, at: Date.now() } }); } catch {}
}

function loadSettings() {
  return new Promise((res) =>
    chrome.storage.sync.get(C.SYNC_DEFAULTS, (s) =>
      chrome.storage.local.get({ keys: {}, apiKey: "" }, (l) => {
        const keys = { ...(l.keys || {}) };
        if (!keys.claude && l.apiKey) keys.claude = l.apiKey; // chiave salvata dalla versione 2
        res({ ...s, models: { ...(s.models || {}) }, keys });
      })));
}

// traduttore scelto per un singolo video (⚑ → "Tutta la traduzione è sbagliata" → "Rifalla con Google"), o Google
// quando la traduzione di YouTube di questo video è nell'alfabeto sbagliato
let dsVideoEngine = {};
DS_EXT.storage.local.get({ videoEngine: {} }).then((r) => { dsVideoEngine = r.videoEngine || {}; }).catch(() => {});
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.videoEngine) dsVideoEngine = ch.videoEngine.newValue || {}; });
function engine(s = settings) {
  const over = dsVideoEngine[currentVideoId()];
  // «Consumo: solo gratis»: si traduce con Google Traduttore, senza toccare il servizio scelto
  const id = dsFreeOnly(s) ? "google" : over && C.ENGINES[over] ? over : C.ENGINES[s.engine] ? s.engine : "google";
  const E = C.ENGINES[id];
  return { id, E, key: s.keys[id] || "", model: s.models[id] || E.defaultModel || "", localUrl: s.localUrl };
}

// ---------- Servizi di riserva quando uno finisce le richieste gratuite ----------
// Un servizio che ha esaurito la quota di oggi viene saltato (anche negli altri video) fino al giorno dopo
// (le quote di Gemini si azzerano a mezzanotte di Los Angeles, verso le 9 in Italia); intanto si usa il primo
// servizio di riserva di cui hai la chiave (Groq, Mistral, OpenRouter…), e solo alla fine Google Traduttore.
let dsBlocked = {};
const dsPacificDay = () => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return new Date().toISOString().slice(0, 10); } };
chrome.storage.local.get({ dsBlocked: {} }, (r) => { dsBlocked = r.dsBlocked || {}; });
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== "local" || !ch.dsBlocked) return;
  const before = dsBlocked;
  dsBlocked = ch.dsBlocked.newValue || {};
  // "Riprova …" nel popup: il servizio scelto non è più bloccato → riprendo la traduzione con quello
  try {
    const id = settings && engine().id;
    const had = (m) => Object.keys(m || {}).some((k) => k === id || k.startsWith(id + "|"));
    if (id && had(before) && !had(dsBlocked) && track && !liveActive()) { setStatus(`Riprovo con ${engine().E.label.split(" (")[0]}…`); startTranslation(); }
  } catch {}
});
// (ttl: blocco breve, per un modello che non ha risposto bene: si riprova dopo un po')
const dsBlockedOn = (k) => { const b = dsBlocked[k]; return !!b && b.day === dsPacificDay() && Date.now() - b.at < (b.ttl || 20 * 3600 * 1000); };
// 1.6.1: un modello che ha finito le richieste di oggi (Gemini, Groq, Mistral: i limiti sono per modello)
// (un blocco di tutto il servizio scritto dalle versioni prima vale solo per i servizi che non sono modelli)
const dsLlmSvc = (id) => { const E = C.ENGINES[id]; return dsIsLlmE(E) && !E.local; };
const dsModelBlocked = (id, model) => (!dsLlmSvc(id) && dsBlockedOn(id)) || (!!model && dsBlockedOn(id + "|" + model));
// il servizio non si può usare oggi: bloccato tutto (per esempio i caratteri del mese di DeepL) o finiti tutti i suoi modelli
function dsIsBlocked(id) {
  if (!dsLlmSvc(id) && dsBlockedOn(id)) return true;
  const E = C.ENGINES[id];
  if (!settings || !dsIsLlmE(E) || E.local) return false;
  return !dsModelChain(settings, "engine", id).some((m) => !dsModelBlocked(id, m)) && !dsModelChain(settings, "explainEngine", id).some((m) => !dsModelBlocked(id, m));
}
// finite le richieste di oggi: con un modello si blocca solo quel modello, altrimenti tutto il servizio
function dsMarkBlocked(id, model, ttl) {
  if (!id || id === "google") return;
  const E = C.ENGINES[id];
  const k = model && dsIsLlmE(E) && !E.local ? id + "|" + model : id;
  dsBlocked = { ...dsBlocked, [k]: { day: dsPacificDay(), at: Date.now(), ...(ttl ? { ttl } : {}) } };
  DS_EXT.storage.local.set({ dsBlocked }).catch(() => {});
}
// il modello giusto per un compito, saltando quelli finiti oggi
const dsTM = (task, e) => dsTaskModel(settings, task, e, dsModelBlocked);
// nome da mostrare: servizio, e il modello se è un modello linguistico
const dsEngName = (e) => (e && e.E ? e.E.label.split(" (")[0].split(",")[0] + (dsIsLlmE(e.E) && !e.E.local && e.model ? " · " + e.model : "") : "");
// finite le richieste di oggi con e: il prossimo da usare per quel compito (altro modello dello stesso servizio, poi altri servizi)
function dsAfterDaily(e, task = "engine") {
  dsMarkBlocked(e.id, e.model);
  const same = dsTM(task, engineById(e.id));
  if (same && !same.exhausted && dsReady(same)) return same;
  const next = dsNextEngine(e.id);
  return next ? dsTM(task, next) : null;
}
function engineById(id) {
  const E = C.ENGINES[id];
  return dsTM("engine", { id, E, key: settings.keys[id] || "", model: settings.models[id] || E.defaultModel || "", localUrl: settings.localUrl });
}
const dsReady = (e) => !(e.E.needsKey && !e.key) && !(e.E.kind === "openai" && !e.model) && e.E.kind !== "youtube" && !e.exhausted;
// Il modello scelto per un compito nel popup («Modello per ogni compito»: cleanEngine, ipaEngine, alignEngine,
// explainEngine), se è pronto e ha ancora richieste oggi; altrimenti null (si usa la fila)
function dsTaskEngine(key) {
  const id = settings && settings[key];
  if (!id || !C.ENGINES[id] || dsIsBlocked(id)) return null;
  const e = engineById(id);
  return dsReady(e) && (e.E.kind === "openai" || e.E.kind === "claude") ? dsTM(key, e) : null;
}
// Il servizio da usare adesso: quello scelto, oppure (se ha finito la quota di oggi) il primo di riserva disponibile
function dsUsable(e, task = "engine") {
  if (!e || e.id === "google") return e;
  if (!e.exhausted && !dsIsBlocked(e.id)) return e;
  return dsTM(task, dsNextEngine(e.id)) || GOOGLE_ENGINE;
}
function dsNextEngine(fromId) {
  if (!settings || settings.fallback === false) return null;
  for (const id of C.engineOrder(settings)) {
    if (id === fromId || !C.ENGINES[id] || dsIsBlocked(id)) continue;
    const e = engineById(id);
    if (dsReady(e)) return e;
  }
  return null;
}

// Quante parole del video conosci (prova): sulle frasi dei sottotitoli o della trascrizione
function dsComprehension() {
  try {
    if (!settings || settings.learnKnown === false || typeof DS_KNOWN === "undefined") return null;
    let lang = "", texts = [];
    if (liveActive() || (!track && live.cues.length)) { lang = liveSourceLang(); texts = live.cues.filter((c) => !c.removed).map((c) => c.text); }
    else if (track && track.segments) { lang = track.lang; texts = track.segments.map((s) => s.text); }
    if (!texts.length) return null;
    let seg;
    try { seg = new Intl.Segmenter(lang || undefined, { granularity: "word" }); } catch { seg = new Intl.Segmenter(undefined, { granularity: "word" }); }
    const words = [];
    for (const t of texts) for (const x of seg.segment(String(t || ""))) if (dsIsWord(x)) words.push(dsCleanWord(x.segment));
    const st = DS_KNOWN.stats(words, lang);
    return { ...st, lang, mine: DS_KNOWN.count(lang) };
  } catch { return null; }
}

// Le prossime frasi già tradotte dopo quella mostrata (per allineare più frasi in una sola richiesta)
function dsUpcomingLines(cur, n) {
  const out = [];
  if (!cur) return out;
  if (cur.live && live && live.cues) {
    for (const c of live.cues) {
      if (out.length >= n) break;
      if (c.start > cur.start && !c.removed && c.trans && c.trans !== "…" && !c.quick) out.push({ text: c.text, trans: c.trans, lang: liveSourceLang() });
    }
  } else if (track && track.segments) {
    track.segments.forEach((sg, i) => {
      if (out.length < n && sg.start > cur.start && segTrans[i]) out.push({ text: sg.text, trans: segTrans[i], lang: track.lang });
    });
  }
  return out;
}

// Per i sottotitoli creati dall'audio la modalità riga per riga di YouTube non esiste: uso Google
function liveEngine() {
  const e = engine();
  return e.E.kind === "youtube" ? { id: "google", E: C.ENGINES.google, key: "", model: "", localUrl: "" } : dsTM("engine", e);
}

// Chi corregge la trascrizione quando si traduce con Google o DeepL: Gemini se hai la chiave,
// altrimenti Groq (la chiave è la stessa della trascrizione). Con un modello per tradurre, la correzione
// si fa già nella stessa richiesta della traduzione e questo non serve.
function cleanerEngine() {
  if (!settings || dsCleanMode(settings) === "off") return null;
  const e = liveEngine();
  if (e.E.kind === "openai" || e.E.kind === "claude") return null;
  const own = dsTaskEngine("cleanEngine");
  if (own) return own;
  // nell'ordine scelto nel popup («Ordine dei servizi»): il primo modello pronto
  for (const id of C.engineOrder(settings)) {
    const E = C.ENGINES[id];
    if (!E || (E.kind !== "openai" && E.kind !== "claude") || dsIsBlocked(id)) continue;
    const x = engineById(id);
    if (dsReady(x)) return dsTM("cleanEngine", x);
  }
  return null;
}


// 1.7.15: sottotitoli automatici di YouTube (kind «asr»): se l'opzione «Correggi anche i sottotitoli automatici» è accesa, il modello
// corregge parole e punteggiatura prima di tradurre. A gruppi di 30 frasi (prima quelle vicino a dove sei), salvato per video e lingua.
function asrCleanEngine(force) {
  if (!settings || (!settings.cleanAsr && !force)) return null;
  const own = dsTaskEngine("cleanEngine");
  if (own) return own;
  for (const id of C.engineOrder(settings)) {
    const E = C.ENGINES[id];
    if (!E || (E.kind !== "openai" && E.kind !== "claude") || dsIsBlocked(id)) continue;
    const x = engineById(id);
    if (dsReady(x)) return dsTM("cleanEngine", x);
  }
  return null;
}
async function asrClean(t, videoId, valid, force) {
  const ce = asrCleanEngine(force);
  if (!ce || !t.segments.length) {
    if (force) setStatus("Per correggere i sottotitoli automatici serve un modello (Gemini, Groq, Claude o locale) con la chiave inserita: popup → 🔑 Servizi.");
    return;
  }
  const MAX = 600, BATCH = 30;
  const key = `asrfix:${videoId}:${baseLang(t.lang)}`;
  const saved = (await DS_EXT.storage.local.get(key))[key];
  const fix = saved && saved.n === t.segments.length ? { ...saved.fix } : {};
  const apply = (i, txt) => { const sg = t.segments[i]; if (txt && sg && txt !== sg.text) { if (sg.raw == null) sg.raw = sg.text; sg.text = txt; } };
  for (const k of Object.keys(fix)) apply(+k, fix[k]);
  const total = Math.min(MAX, t.segments.length);
  const todo = [];
  const v = getVideo();
  const from = Math.max(0, t.segments.findIndex((s) => v && s.end >= v.currentTime * 1000));
  for (let j = 0; j < total; j++) { const i = (from + j) % total; if (fix[i] == null) todo.push(i); }
  if (!todo.length) return;
  const name = ce.E.label.split(" (")[0].split(",")[0];
  let n = total - todo.length, changed = 0, same = 0, far = 0, empty = 0;
  for (let b = 0; b < todo.length; b += BATCH) {
    if (!valid()) return;
    const idx = todo.slice(b, b + BATCH).sort((a, c) => a - c);
    const texts = idx.map((i) => t.segments[i].text);
    setStatus(`Correggo i sottotitoli automatici con ${name}… ${n}/${total}`);
    let r = null;
    for (let waits = 0; waits < 4; waits++) {
      try {
        // un modello sul computer bloccato (scheda video occupata, server fermo) non deve tenere ferma anche la traduzione:
        // dopo 3 minuti senza risposta la correzione si ferma e si passa a tradurre i sottotitoli come sono
        r = await Promise.race([
          DS_EXT.runtime.sendMessage({ type: "cleanText", engine: ce.id, key: ce.key, model: ce.model, localUrl: ce.localUrl,
            texts, asr: true, before: idx[0] > 0 ? t.segments.slice(Math.max(0, idx[0] - 3), idx[0]).map((s) => s.text) : [], after: [] }),
          new Promise((ok) => setTimeout(() => ok({ error: `${name} non risponde da 3 minuti` }), 180000))
        ]);
      } catch (err) { r = { error: String(err.message || err) }; }
      if (!valid()) return;
      if (r && r.rateLimited && !r.daily) { await new Promise((ok) => setTimeout(ok, Math.min(60, Math.max(r.retryAfter || 0, 8 * (waits + 1))) * 1000)); continue; }
      break;
    }
    if (!r || r.error || !Array.isArray(r.sources)) { setStatus(`Non riesco a correggere tutti i sottotitoli automatici (${(r && r.error) || "nessuna risposta"}): il resto resta come l'ha fatto YouTube.`); break; }
    idx.forEach((i, k) => {
      const src = r.sources[k];
      const orig = t.segments[i].text;
      // solo correzioni piccole (parole capite male, punteggiatura), nella stessa lingua: niente frasi riscritte
      const sim = src ? DualSubs.charSimilarity(orig, src) : 0;
      const ok = src && src !== orig && sim >= 0.6 && !DualSubs.wrongLang(src, t.lang);
      fix[i] = ok ? src : orig;
      if (ok) { apply(i, src); changed++; }
      else if (!src) empty++;
      else if (src === orig) same++;
      else { far++; if (far <= 3) dsLiveLog(`correzione scartata (somiglianza ${sim.toFixed(2)}): «${orig.slice(0, 60)}» → «${String(src).slice(0, 60)}»`); }
    });
    n += idx.length;
    DS_EXT.storage.local.set({ [key]: { n: t.segments.length, fix, at: Date.now() } }).catch(() => {});
  }
  t.fixedAsr = true;
  const det = [same && `${same} già uguali`, far && `${far} scartate perché troppo diverse dall'originale`, empty && `${empty} senza risposta`].filter(Boolean).join(", ");
  if (valid()) setStatus(changed ? `Sottotitoli automatici corretti con ${name}: ${changed} frasi cambiate${det ? " (" + det + ")" : ""}.` : `${name} non ha cambiato nessuna frase dei sottotitoli automatici${det ? " (" + det + ")" : ""}.`);
}
// rifà la correzione dei sottotitoli automatici di YouTube del video aperto (force = anche con l'opzione spenta, senza la memoria di prima)
async function asrRun(force) {
  if (!track || track.kind !== "asr" || !track.videoId) return false;
  const my = ++asrJob, vid = track.videoId;
  const valid = () => my === asrJob && track && track.videoId === vid;
  if (force) await DS_EXT.storage.local.remove(`asrfix:${vid}:${baseLang(track.lang)}`).catch(() => {});
  try { await asrClean(track, vid, valid, force); } catch {}
  if (!valid()) return true;
  segTrans = new Array(track.segments.length).fill(null);
  transCues = [];
  startTranslation();
  return true;
}
// opzione spenta: i sottotitoli tornano come li ha fatti YouTube
function asrUndo() {
  if (!track || track.kind !== "asr") return;
  ++asrJob;
  for (const sg of track.segments) if (sg.raw != null) { sg.text = sg.raw; delete sg.raw; }
  track.fixedAsr = false;
  segTrans = new Array(track.segments.length).fill(null);
  transCues = [];
  startTranslation();
}

function signature(s) {
  const e = engine(s);
  return JSON.stringify([e.id, e.key, e.model, e.E.local ? e.localUrl : "", s.targetLang]);
}

(async () => {
  settings = await loadSettings();
  lastSignature = signature(settings);
  applyStyle();
})();
if (DS_IS_YT && window === window.top) setStatus("Attiva su YouTube: apri un video e premi CC.");

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area === "local" && !("keys" in changes)) return; // stato e cache: ignora
  const prev = settings;
  settings = await loadSettings();
  applyStyle();
  if (prev && prev.enabled !== false && settings.enabled === false) dsOnDisable();
  if (prev && prev.enabled === false && settings.enabled !== false) dsOnEnable();
  // 1.7.28: «Correggi anche i sottotitoli automatici» acceso o spento a video aperto: vale subito
  if (prev && !!prev.cleanAsr !== !!settings.cleanAsr && track && track.kind === "asr") { if (settings.cleanAsr) asrRun(false); else asrUndo(); }
  if (prev && !!prev.liveAhead !== !!settings.liveAhead && typeof aheadSettingChanged === "function") aheadSettingChanged(!!settings.liveAhead);
  if (prev && (prev.transcribeMode !== settings.transcribeMode || prev.fullMaxMin !== settings.fullMaxMin || prev.videoModeSticky !== settings.videoModeSticky)) {
    const v = currentVideoId();
    if (v && getVideo() && !live.modes[v] && hasCaptions[v] === false) liveApplyDefault(v);
  }
  const sig = signature(settings);
  if (sig !== lastSignature) {
    lastSignature = sig;
    if (track) startTranslation();
    liveRetranslate();
  }
});

// ---------- Messaggi dalla pagina ----------
window.addEventListener("message", (e) => {
  if (e.origin !== location.origin || typeof e.data !== "string" || !e.data.startsWith('{"__dualsub":"page"')) return;
  let m;
  try { m = JSON.parse(e.data); } catch { return; }
  if (m.type === "log") { dsLiveLog("pagina: " + m.text); return; }
  if (m.type === "track") onTrack(m);
  else if (m.type === "captionsInfo") { dsLiveLog(`YouTube: video ${m.videoId}, sottotitoli ${m.has ? "sì" : "no"}${m.live ? ", diretta" : ""}`); onCaptionsInfo(m); }
  else if (m.type === "error") setStatus(m.text);
  else if (m.type === "hlsResult") {
    const p = pending.get(m.id);
    if (p) { pending.delete(m.id); p.resolve(m.url || ""); }
  }
  else if (m.type === "ytResult") {
    const p = pending.get(m.id);
    if (!p) return;
    pending.delete(m.id);
    m.error ? p.reject(new Error(m.error)) : p.resolve(m.events);
  }
});

// ---------- Messaggi dal popup e dalla pagina "Trascrizione e traduzione" ----------
// In una scheda possono esserci più video (per esempio il lettore del sito e un riquadro di YouTube).
// Ogni parte della pagina con un video ha un suo contrassegno: alle domande risponde per prima quella
// con la trascrizione o con il video in riproduzione, e i comandi arrivano solo a quella.
const DS_FRAME = Math.random().toString(36).slice(2) + Date.now().toString(36);

function dsRelevance() {
  const v = getVideo();
  if (!v) return -1;
  if (live.running || live.fullBusy || (live.cues.length && live.videoId === currentVideoId()) || track) return 0;
  if (!v.paused) return 1;
  return 2;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !settings) return false;
  const rel = dsRelevance();
  if (rel < 0) return false;
  // comando indirizzato a un'altra parte della pagina
  if (msg.target && msg.target !== DS_FRAME) return false;
  // comando senza destinatario: lo esegue solo un video attivo, non quelli fermi
  const isQuery = msg.type === "liveState" || msg.type === "getTranscript" || msg.type === "getLiveLog";
  if (!isQuery && !msg.target && rel > 1) return false;

  const reply = (r) => { try { sendResponse(r && typeof r === "object" ? { ...r, frame: DS_FRAME } : r); } catch {} };
  const answer = (fn) => { setTimeout(() => reply(fn()), [0, 150, 450][rel]); return true; };

  if (msg.type === "liveState") return answer(() => ({ ...liveState(), disabled: dsSiteDisabled(), host: location.hostname, comp: dsComprehension() }));
  if (msg.type === "getTranscript") return answer(() => dsTranscript());
  if (msg.type === "getLiveLog") return answer(() => ({ log: dsLiveLogBuf.join("\n"), url: location.href, ahead: typeof aheadInfo === "function" ? aheadInfo() : null, snap: dsDebugSnap() }));
  if (msg.type === "live") {
    const v = currentVideoId();
    if (msg.action !== "stop") dsChipPing();
    if (msg.action === "start") liveManualStart(v);
    else if (msg.action === "full") liveFull();
    else {
      live.fullGen++; live.fullBusy = false; liveStop("Trascrizione fermata.");
      // video con i suoi sottotitoli: fermandola tornano quelli del sito, anche le volte dopo
      if (v && hasCaptions[v] && live.modes[v] === "live") liveSetMode(v, "").catch(() => {});
    }
    setTimeout(() => reply(liveState()), 50);
    return true;
  }
  if (msg.type === "setMode") {
    const v = currentVideoId();
    if (msg.mode === "full" || msg.mode === "live") dsChipPing();
    liveSetMode(v, msg.mode).then(() => {
      if (msg.mode === "full") liveFull();
      else if (msg.mode === "live") { if (!live.running) liveStart(true); }
      else if (msg.mode === "off") { live.fullGen++; live.fullBusy = false; liveStop("Trascrizione spenta per questo video."); }
      else if (!msg.mode && hasCaptions[v] !== true) liveApplyDefault(v);
      reply(liveState());
    });
    return true;
  }
  if (msg.type === "setTranscript") { reply({ ok: liveSetTranscript(msg) }); return false; }
  if (msg.type === "fixCue") { fixDo(msg.action, msg.start, msg.text, msg.trans).then(reply); return true; }
  if (msg.type === "manualTrans") {
    fixSaveMany(currentVideoId(), msg.items || []).then((n) => { setStatus(`Traduzione incollata: ${n} frasi.`); reply({ ok: true, n }); })
      .catch((e) => reply({ ok: false, error: String(e.message || e) }));
    return true;
  }
  if (msg.type === "loadSubs") {
    const events = dsParseSubs(msg.text);
    if (!events.length) { reply({ ok: false, error: "nel file non ho trovato sottotitoli validi (.srt o .vtt)" }); return false; }
    onTrack({ videoId: currentVideoId(), lang: msg.lang || "", kind: "file", baseUrl: null, events });
    reply({ ok: true, count: events.length });
    return false;
  }
  if (msg.type === "redo") {
    if (msg.what === "translation" && track && !liveActive()) dsRedoWholeTranslation();   // 1.6.3: anche il testo già tradotto in memoria si azzera
    else liveRedo(msg.what, !!msg.precise);
    reply({ ok: true });
    return false;
  }
  return false;
});

async function dsSetVideoEngine(v, id) {
  if (!v) return;
  const r = await DS_EXT.storage.local.get({ videoEngine: {} });
  const m = r.videoEngine || {};
  if (id) m[v] = id; else delete m[v];
  const ks = Object.keys(m);
  for (const k of ks.slice(0, Math.max(0, ks.length - 300))) delete m[k];
  dsVideoEngine = m;
  await DS_EXT.storage.local.set({ videoEngine: m });
}
// ⚑ → "Tutta la traduzione di questo video è sbagliata": cancella quella salvata e la rifà (con Google, se chiesto)
async function dsRedoWholeTranslation(engineId) {
  const v = currentVideoId();
  try { await fixClearChat(v); } catch {}   // 1.8.0: anche le traduzioni unite o spostate (non quelle corrette a mano)
  if (track && !liveActive()) {
    const before = cacheKey(track, trackEngine());
    if (engineId !== undefined) await dsSetVideoEngine(v, engineId);
    await DS_EXT.storage.local.remove([before, cacheKey(track, trackEngine())]);
    segTrans = new Array(track.segments.length).fill(null);
    transCues = [];
    startTranslation();
  } else {
    if (engineId !== undefined) await dsSetVideoEngine(v, engineId);
    await liveRedo("translation");
  }
  const name = engine().E.label.split(" (")[0];
  setStatus(`Rifaccio tutta la traduzione di questo video con ${name}.`);
}

// Trascrizione completa (con traduzioni) di quello che si sta guardando
function liveActive() {
  const v = currentVideoId();
  return live.videoId === v && live.cues.length > 0 && (live.running || live.full || !track || liveChosen(v));
}

function dsTranscript() {
  const r = dsTranscriptRaw();
  const v = currentVideoId();
  r.cues = (r.cues || []).map((c) => { const f = fixApply(v, c.start, c.text, c.trans); return f.gone ? null : { ...c, text: f.text, trans: f.trans, fixed: !!f.fixed }; }).filter(Boolean);
  return r;
}

function dsTranscriptRaw() {
  const m = getVideo();
  const base = {
    ok: true, title: document.title.replace(/\s*-\s*YouTube\s*$/, ""), url: location.href, mediaId: currentVideoId(),
    src: dsMediaSrc(), direct: dsIsDirectMedia(), duration: m && isFinite(m.duration) ? m.duration * 1000 : 0,
    live: dsIsLiveStream(m),
    target: settings.targetLang, running: live.running
  };
  if (liveActive() || (!track && live.cues.length)) {
    return { ...base, source: "whisper", lang: liveSourceLang(), full: live.full,
      cues: live.cues.filter((c) => !c.removed).map((c) => ({ start: c.start, end: c.end, text: c.text, trans: c.trans || "" })) };
  }
  if (track) {
    const lineMode = trackEngine().E.kind === "youtube";
    const cues = lineMode
      ? track.cues.map((c, i) => ({ start: c.start, end: c.end, text: c.text, trans: transCues.length === track.cues.length ? transCues[i].text : "" }))
      : track.segments.map((sg, i) => ({ start: sg.start, end: sg.end, text: sg.text, trans: segTrans[i] || "" }));
    return { ...base, source: track.kind === "file" ? "file" : DS_IS_YT ? "youtube" : "track", lang: track.lang, full: true, cues };
  }
  return { ...base, source: "", lang: "", full: false, cues: [] };
}

function fetchYT(url) {
  return new Promise((resolve, reject) => {
    const id = ++reqId;
    pending.set(id, { resolve, reject });
    toPage({ type: "fetchYT", id, url });
    setTimeout(() => {
      if (pending.has(id)) { pending.delete(id); reject(new Error("tempo scaduto")); }
    }, 20000);
  });
}

function trackEngine() {
  const e = engine();
  return e.E.kind === "youtube" && !(track && track.baseUrl) ? GOOGLE_ENGINE : dsTM("engine", e);
}


// 1.7.17: trascrizione già fatta e salvata per questo video (storage.local «live:<video>») → passo subito a quella, senza i sottotitoli
// automatici di YouTube e senza nuove richieste per le parti già coperte. Vero se ho cambiato.
async function dsUseSavedTranscript(v) {
  if (live.videoId === v && live.cues.length && liveChosen(v)) { track = null; return true; }   // già passato alla trascrizione (YouTube rimanda la traccia a ogni CC)
  if (live.running || live.fullBusy || dsIsLiveStream(getVideo())) return false;
  const key = liveCuesKey(v);
  const saved = (await DS_EXT.storage.local.get(key))[key];
  if (!saved || !Array.isArray(saved.cues) || saved.cues.filter((c) => !c.x).length < 5) return false;
  if (currentVideoId() !== v) return false;
  if (live.videoId !== v) liveReset();
  live.videoId = v;
  live.loadedFor = v;
  await liveLoadCache(v);
  if (!live.cues.length) return false;   // (per esempio: salvata in un'altra lingua, già buttata)
  track = null;
  const mode = saved.full ? "full" : "live";
  live.savedUse = v;   // (in memoria: il menu «Per questo video» non cambia da solo)
  setStatus("Questo video ha già una trascrizione salvata: la uso al posto dei sottotitoli automatici di YouTube" + (saved.full ? " (nessuna richiesta necessaria)." : " (le parti non ancora trascritte arrivano mentre guardi)."));
  if (!(settings.stt === "groq" && !settings.keys.groq)) { if (mode === "full") liveFull(); else liveStart(true, { quiet: true }); }   // (senza chiave la trascrizione salvata si vede lo stesso)
  return true;
}

async function onTrack(m) {
  if (!settings) settings = await loadSettings();
  const isAsr = m.kind === "asr";
  // 1.7.17: il video ha già una trascrizione salvata (fatta dall'audio): la uso subito al posto dei sottotitoli automatici di YouTube
  if (isAsr && m.videoId && settings.useSavedTranscript !== false && await dsUseSavedTranscript(m.videoId)) return;
  const cues = DualSubs.parseCues(m.events);
  const segments = DualSubs.segment(DualSubs.buildUnits(m.events, isAsr), m.lang);
  if (!cues.length) { setStatus("Questa traccia di sottotitoli è vuota."); return; }
  track = { videoId: m.videoId, lang: m.lang, kind: m.kind, baseUrl: m.baseUrl, cues, segments, avail: Array.isArray(m.avail) ? m.avail : (dsAvailTracks[m.videoId] || []) };
  if (m.videoId && Array.isArray(m.avail) && m.avail.length) dsAvailTracks[m.videoId] = m.avail;
  // i sottotitoli automatici di YouTube sono nella lingua dell'audio: la trascrizione (se la chiedi) resta in quella lingua
  if (isAsr && m.lang && m.videoId) dsAsrInfo[m.videoId] = { lang: String(m.lang).split("-")[0].toLowerCase(), segments };
  const what = m.kind === "file" ? "Sottotitoli caricati dal file" : DS_IS_YT ? "Sottotitoli trovati" : "Sottotitoli del video trovati";
  setStatus(`${what}${m.lang ? ` (${m.lang}${isAsr ? ", automatici" : ""})` : ""}: ${segments.length} frasi.`);
  // 1.8.0: il video ha già la traduzione (una traccia nella tua lingua): si uniscono, senza tradurre né correggere
  if (await dsTryBuiltinTrans(track)) return;
  if (isAsr && settings.cleanAsr && m.videoId) { const my = ++asrJob; try { await asrClean(track, m.videoId, () => my === asrJob && track && track.videoId === m.videoId); } catch {} if (my !== asrJob) return; }
  startTranslation();
}
let asrJob = 0;

async function onCaptionsInfo(m) {
  if (m.embedded) {
    const before = currentVideoId();
    dsYtReportedId = m.videoId;
    if (before && before !== m.videoId && /^live_stream/.test(before)) {
      if (live.videoId === before) { live.videoId = m.videoId; live.loadedFor = m.videoId; }
      if (live.autoTried === before) live.autoTried = m.videoId;
    }
  }
  if (m.live) dsYtLive[m.videoId] = true;
  hasCaptions[m.videoId] = m.has;
  if (Array.isArray(m.avail) && m.avail.length) { dsAvailTracks[m.videoId] = m.avail; if (track && track.videoId === m.videoId && !track.avail.length) track.avail = m.avail; }
  if (m.videoId !== currentVideoId()) return;
  if (!settings) settings = await loadSettings();
  if (live.running || live.fullBusy) return;
  // video con sottotitoli: si trascrive solo se l'hai scelto tu per questo video
  if (m.has && !liveChosen(m.videoId)) return;
  liveAutoStart(m.videoId);
}

function reset() {
  job++;
  track = null;
  transCues = [];
  segTrans = [];
  translating = false;
  toPage({ type: "reset" });
  liveReset();
}
document.addEventListener("yt-navigate-start", reset);

// ---------- Richiesta di traduzione con attesa sui limiti dei servizi gratuiti ----------
async function askTranslate(e, texts, before, after, stillValid, progress = "", source = "", clean = false, priority = false) {
  const name = e.E.label.split(" (")[0];
  for (let waits = 0; ; waits++) {
    let resp;
    try {
      // con un modello: anche i modi di dire delle frasi, nella stessa richiesta (sottolineati nei sottotitoli)
      const idioms = settings.idiomsUnderline !== false && (e.E.kind === "openai" || e.E.kind === "claude");
      resp = await DS_EXT.runtime.sendMessage({
        type: "translate", engine: e.id, target: settings.targetLang, source, clean, priority, idioms,
        texts, before, after, key: e.key, model: e.model, localUrl: e.localUrl
      });
      if (resp && resp.idioms && resp.idioms.length && typeof wordsTrIdioms === "function") wordsTrIdioms(texts, resp.idioms);
    } catch (err) {
      resp = { error: String(err.message || err) };
    }
    if (!stillValid()) return null;
    if (resp && resp.rateLimited && !resp.daily && waits >= 6) resp.daily = true;   // non si sblocca: passo a un altro servizio
    if (resp && resp.rateLimited && !resp.daily && waits < 6) {
      const secs = Math.min(Math.max(resp.retryAfter || 0, 10 * (waits + 1)), 90);
      for (let s = secs; s > 0; s--) {
        if (!stillValid()) return null;
        setStatus(`${/\b503\b|high demand|overload/i.test(String(resp.error || "")) ? name + ": servizio sovraccarico in questo momento (non è un limite tuo)" : name + ": limite di richieste raggiunto"}, riprovo tra ${s} s…${progress}`);
        await sleep(1000);
      }
      continue;
    }
    return resp || { error: "nessuna risposta" };
  }
}

// ---------- Traduzione dei sottotitoli di YouTube ----------
function makeChunks(segments, E) {
  const { count, chars: maxChars } = E.chunk;
  const chunks = [];
  let cur = [], chars = 0;
  segments.forEach((s, i) => {
    if (cur.length && (cur.length >= count || chars + s.text.length > maxChars)) {
      chunks.push(cur); cur = []; chars = 0;
    }
    cur.push(i);
    chars += s.text.length + 1;
  });
  if (cur.length) chunks.push(cur);
  return chunks;
}

// Prima il pezzo che stai guardando, poi il seguito, poi quello già passato
function orderFromNow(chunks, segments) {
  const video = getVideo();
  const t = video ? video.currentTime * 1000 : 0;
  let k = chunks.findIndex((ch) => segments[ch[ch.length - 1]].showEnd > t);
  if (k < 0) k = 0;
  return [...chunks.slice(k), ...chunks.slice(0, k)];
}

const cacheKey = (t, e) => `cache:${t.videoId}|${t.lang}|${t.kind}|${settings.targetLang}|${e.id}|${e.model}`;

async function saveCache(key, value) {
  const { cacheIndex = [] } = await DS_EXT.storage.local.get({ cacheIndex: [] });
  const index = cacheIndex.filter((k) => k !== key);
  index.push(key);
  const drop = index.length > 80 ? index.splice(0, index.length - 80) : [];
  if (drop.length) await DS_EXT.storage.local.remove(drop);
  await DS_EXT.storage.local.set({ [key]: value, cacheIndex: index });
}

const GOOGLE_ENGINE = { id: "google", E: C.ENGINES.google, key: "", model: "", localUrl: "" };
const DAILY_MSG = (name) =>
  `${name} ha esaurito le richieste gratuite di oggi (si azzerano verso le 9 del mattino, ora italiana). ` +
  `Intanto traduco con Google Traduttore. Consiglio: nel popup (📊 Consumo e modelli → Modello per ogni compito) metti primo un modello Flash-Lite, che ne ha molte di più.`;

async function startTranslation() {
  const my = ++job;
  if (settings && settings.enabled === false) { transCues = []; segTrans = track ? new Array(track.segments.length).fill(null) : []; translating = false; return; }
  const t = track;
  const chosen = trackEngine();
  const e = dsUsable(chosen);
  const { E } = e;
  const name = E.label.split(" (")[0];
  if (e !== chosen) setStatus(`${chosen.E.label.split(" (")[0]} ha finito le richieste gratuite di oggi: traduco con ${name}.`);
  const valid = () => my === job;
  transCues = [];
  segTrans = new Array(t.segments.length).fill(null);
  translating = false;

  if (baseLang(t.lang) === baseLang(settings.targetLang)) {
    setStatus("Il video è già nella lingua scelta: mostro solo l'originale.");
    return;
  }

  if (E.kind === "youtube" && t.baseUrl) {
    try {
      const u = new URL(t.baseUrl);
      u.searchParams.set("tlang", settings.targetLang);
      translating = true;
      const ev = await fetchYT(u.toString());
      if (!valid()) return;
      transCues = DualSubs.parseCues(ev);
      const tgt = String(settings.targetLang || "").split("-")[0];
      const bad = transCues.filter((c) => DualSubs.wrongLang(c.text, tgt)).length;
      if (transCues.length && bad > transCues.length * 0.4) {
        // YouTube ha dato la traduzione in un'altra lingua o alfabeto: per questo video traduco con Google
        transCues = [];
        await dsSetVideoEngine(currentVideoId(), "google");
        setStatus("La traduzione di YouTube di questo video era nella lingua sbagliata: traduco con Google Traduttore.");
        translating = false;
        if (valid()) startTranslation();
        return;
      }
      setStatus(transCues.length ? "Traduzione pronta (YouTube, riga per riga)." : "YouTube non offre la traduzione per questa traccia.");
    } catch (err) {
      if (valid()) setStatus("Errore dalla traduzione di YouTube: " + err.message);
    } finally {
      if (valid()) translating = false;
    }
    return;
  }

  if (E.needsKey && !e.key) { setStatus(`Per usare ${name} inserisci la chiave nel popup, in 🔑 Servizi.`); return; }
  if (E.kind === "openai" && !e.model) { setStatus(`Per usare ${name} scegli un modello nel popup ("Carica modelli").`); return; }

  // La traduzione di questo video è salvata pezzo per pezzo: se l'avevi già guardato (anche solo in parte)
  // riparto da lì e chiedo al servizio solo le frasi che mancano
  const ck = cacheKey(t, e);
  const done = new Array(t.segments.length).fill(null); // solo le traduzioni fatte dal servizio scelto
  if (E.cache) {
    await dsCopyOkReady;      // frasi brevi già controllate (nomi): servono per decidere quali traduzioni salvate rifare
    const saved = (await DS_EXT.storage.local.get(ck))[ck];
    if (!valid()) return;
    if (Array.isArray(saved) && saved.length === done.length) {
      saved.forEach((x, i) => {
        if (typeof x === "string" && !dsBadSaved(t.segments[i].text, x)) { done[i] = x; segTrans[i] = x; }
      });
    }
  }
  const missing = () => done.map((x, i) => (x == null ? i : -1)).filter((i) => i >= 0);
  if (!missing().length) {
    setStatus(`Traduzione già salvata per questo video (${name}): nessuna richiesta necessaria.`);
    return;
  }
  const reused = done.length - missing().length;

  translating = true;
  let cur = e, fallback = false;
  let queue = orderFromNow(makeChunks(t.segments, E).map((ch) => ch.filter((i) => done[i] == null)).filter((ch) => ch.length), t.segments);
  let count = reused;
  const total = segTrans.length;
  const prefix = reused ? `${reused} frasi già salvate. ` : "";

  while (queue.length) {
    // 1.7.37: se ti sei spostato nel video, si traduce prima da dove sei adesso (non da dove eri quando è partita la traduzione)
    if (queue.length > 1) queue = orderFromNow(queue, t.segments);
    const ch = queue.shift();
    const first = ch[0], last = ch[ch.length - 1];
    const curName = cur.E.label.split(" (")[0];
    // modello sul computer lento (per esempio la scheda video è occupata dalla trascrizione): lo dico invece di restare in silenzio
    const slowMsg = cur.E.local ? setTimeout(() => { if (valid()) setStatus(`${curName} sta ancora lavorando alla traduzione (${count}/${total} frasi): se il computer è occupato con altro, come la trascrizione, può essere lento.`); }, 60000) : 0;
    const resp = await askTranslate(
      cur,
      ch.map((i) => t.segments[i].text),
      t.segments.slice(Math.max(0, first - 4), first).map((s) => s.text),
      t.segments.slice(last + 1, last + 3).map((s) => s.text),
      valid,
      ` (${count}/${total} frasi)`,
      t.lang
    );
    clearTimeout(slowMsg);
    if (!resp) return;
    if (resp.daily && !fallback) {
      // 1.6.1: un altro modello dello stesso servizio, se ne ha ancora; poi un altro servizio con la chiave
      const next = dsAfterDaily(cur, "engine");
      const left = [ch, ...queue].flat();
      if (next) {
        // (le sue traduzioni vengono salvate come le altre)
        setStatus(`${dsEngName(cur)} ha finito le richieste gratuite di oggi: continuo con ${dsEngName(next)}.`);
        cur = next;
        queue = makeChunks(left.map((i) => t.segments[i]), next.E).map((c) => c.map((k) => left[k]));
        continue;
      }
      // Nessun servizio di riserva: continuo con Google per le frasi che mancano, senza salvarle come "fatte da Gemini"
      fallback = true;
      cur = GOOGLE_ENGINE;
      setStatus(DAILY_MSG(curName));
      queue = makeChunks(left.map((i) => t.segments[i]), C.ENGINES.google).map((c) => c.map((k) => left[k]));
      continue;
    }
    if (resp.error && (resp.fatal || cur.id === "google")) {
      // chiave sbagliata, modello inesistente, o anche Google non risponde: inutile continuare
      translating = false;
      setStatus("Errore di traduzione: " + resp.error);
      return;
    }
    // Risposta incompleta o illeggibile: divido il blocco e riprovo; se è già piccolo, quel pezzo lo fa Google
    if ((resp.error && ch.length > 3) || (resp.misaligned && ch.length > 1)) {
      const mid = Math.ceil(ch.length / 2);
      queue.unshift(ch.slice(0, mid), ch.slice(mid));
      continue;
    }
    let result = resp;
    let byGoogle = false;
    if (resp.error) {
      setStatus(`${curName}: ${resp.error}. Questo pezzo lo traduco con Google e vado avanti.`);
      result = await askTranslate(GOOGLE_ENGINE, ch.map((i) => t.segments[i].text), [], [], valid, "", t.lang);
      if (!result) return;
      if (result.error) { translating = false; setStatus("Errore di traduzione: " + result.error); return; }
      byGoogle = true;
    }
    const echoed = [];
    const tgt = settings.targetLang;
    ch.forEach((i, k) => {
      const src = t.segments[i].text, tr = result.translations[k] || "";
      if (!byGoogle && !fallback && cur.id !== "google" && (dsIsEcho(src, tr) || dsUncheckedCopy(src, tr, tgt))) { echoed.push(i); return; }
      segTrans[i] = dsIsEcho(src, tr) ? "" : tr;
      if (tr && dsIsCopy(src, tr) && (byGoogle || cur.id === "google")) dsMarkCopyOk(src, tgt);
      if (!fallback && !byGoogle) done[i] = segTrans[i];
    });
    // Frasi che il modello ha solo ricopiato (anche quelle di una o due parole): le traduce Google.
    // Se anche Google la lascia uguale è un nome ("Karen", "Okay"): resta così, segnata come controllata e salvata.
    if (echoed.length) {
      const g = await askTranslate(GOOGLE_ENGINE, echoed.map((i) => t.segments[i].text), [], [], valid, "", t.lang);
      if (!g) return;
      echoed.forEach((i, k) => {
        const src = t.segments[i].text, tr = (g.translations || [])[k] || "";
        segTrans[i] = dsIsEcho(src, tr) ? "" : tr;
        if (!tr || dsIsEcho(src, tr)) return;
        if (dsIsCopy(src, tr)) dsMarkCopyOk(src, tgt);
        // frase breve ricopiata dal modello: la traduzione di Google si salva, così non si richiede di nuovo
        if (!fallback && dsWords(src).length <= 2) done[i] = tr;
      });
    }
    count += ch.length;
    if (!fallback) {
      setStatus(`${prefix}Traduzione (${cur.E.label.split(" (")[0]}): ${count}/${total} frasi.`);
      if (E.cache) saveCache(ck, done).catch(() => {});
    }
  }

  translating = false;
  if (!fallback) setStatus(`Traduzione completata (${cur && (cur.id !== e.id || cur.model !== e.model) ? dsEngName(cur) : name}).${reused ? ` ${reused} frasi erano già salvate.` : ""}`);
  else setStatus(DAILY_MSG(name).replace("Intanto traduco", "Il resto è stato tradotto"));
}

// ---------- Pulsante per accendere/spegnere i sottotitoli doppi, dentro il lettore ----------
// YouTube: nella barra dei comandi, accanto al pulsante dei sottotitoli. Altri siti: piccolo pulsante in alto a destra del video.
let dsToggleBtn = null, dsToggleAt = 0;
// 1.7.8: altri siti (Wikipedia, Commons, siti di corsi…): il pulsante DS c'è anche prima che ci siano sottotitoli o una trascrizione,
// basta un video visibile abbastanza grande (prima compariva solo dopo, e così non c'era modo di cominciare da lì)
function dsBigVideo() {
  const m = getVideo();
  if (!m || m.tagName !== "VIDEO") return false;
  const r = m.getBoundingClientRect();
  return r.width >= 200 && r.height >= 110 && r.bottom > 0 && r.top < innerHeight && getComputedStyle(m).visibility !== "hidden";
}
function dsToggleUpdate(player, show, v) {
  if (!player) return;
  const now = Date.now();
  const want = DS_IS_YT || track || live.cues.length || live.running || live.fullBusy || settings.enabled === false || dsBigVideo();
  if (!want) { if (dsToggleBtn) dsToggleBtn.hidden = true; return; }
  if (!dsToggleBtn || !dsToggleBtn.isConnected || now - dsToggleAt > 1000) {
    dsToggleAt = now;
    // YouTube Music: se non ci sono i comandi del lettore di YouTube (modalità audio) il pulsante resta in alto a destra del riquadro
    const ytHome = DS_IS_YT ? player.querySelector(".ytp-right-controls") : null;
    const home = ytHome || (!DS_IS_YT || DS_IS_YTMUSIC ? player : null);
    if (!home) return;
    if (!dsToggleBtn) {
      dsToggleBtn = document.createElement("button");
      dsToggleBtn.type = "button";
      dsToggleBtn.append(Object.assign(document.createElement("span"), { className: "dualsub-toggle-label", textContent: "DS" }));
      dsToggleBtn.addEventListener("click", (e) => { e.stopPropagation(); e.preventDefault(); dsToggleClick(); });
      for (const t of ["mousedown", "mouseup", "dblclick"]) dsToggleBtn.addEventListener(t, (e) => e.stopPropagation());
    }
    dsToggleBtn.className = "dualsub-toggle" + (ytHome ? " ytp-button" : " dualsub-toggle-float");
    if (dsToggleBtn.parentNode !== home) home.prepend(dsToggleBtn);
  }
  dsToggleBtn.hidden = false;
  const on = settings.enabled !== false && show;
  if (dsToggleBtn.classList.contains("on") !== on) {
    dsToggleBtn.classList.toggle("on", on);
    dsToggleBtn.setAttribute("aria-pressed", String(on));
    dsToggleBtn.title = on ? "Sottotitoli Doppi: spegni" : "Sottotitoli Doppi: accendi";
  }
}

// Spento: nascondo e fermo la trascrizione (così non consuma la quota). Acceso: faccio ripartire quello che serve.
let dsToggleClickAt = 0, dsToggleBusy = false;
async function dsToggleClick() {
  // 1.6.3: clic ripetuti (o doppio clic) su DS: uno solo alla volta, e non prima che quello di prima abbia finito (prima
  // accendeva e spegnava di continuo, e con i sottotitoli di YouTube che lampeggiavano)
  if (dsToggleBusy || Date.now() - dsToggleClickAt < 900) { dsLiveLog("clic su DS ignorato: ce n'è già uno in corso"); return; }
  dsToggleBusy = true; dsToggleClickAt = Date.now();
  try { await dsToggleClick0(); } finally { setTimeout(() => { dsToggleBusy = false; }, 600); }
}
async function dsToggleClick0() {
  const v = currentVideoId();
  const showing = !!(overlay && !overlay.hidden);
  dsLiveLog(`clic su DS: sottotitoli ${showing ? "visibili → li spengo" : "nascosti → li accendo"} (acceso nelle impostazioni: ${settings.enabled !== false})`);
  if (showing) {
    await DS_EXT.storage.sync.set({ enabled: false });
    return;
  }
  if (settings.enabled === false) await DS_EXT.storage.sync.set({ enabled: true });   // il resto lo fa dsOnEnable
  else dsOnEnable(v);
}

function dsOnEnable(v = currentVideoId()) {
  if (!v) { dsLiveLog("accensione: nessun video riconosciuto in questa pagina"); return; }
  { const cc = DS_IS_YT && document.querySelector("#movie_player .ytp-subtitles-button");
    dsLiveLog(`accensione: video ${v}, sottotitoli YouTube ${hasCaptions[v] === undefined ? "non so" : hasCaptions[v] ? "sì" : "no"}, testo ricevuto ${track ? "sì (" + track.segments.length + " frasi, " + track.lang + ")" : "no"}, traduzione ${translating ? "in corso" : segTrans.filter((x) => x != null).length + " frasi pronte"}, pulsante CC ${cc ? (cc.getAttribute("aria-pressed") === "true" ? "acceso" : "spento") : "assente"}, trascrizione ${live.running ? "in corso" : live.fullBusy ? "completa in corso" : "ferma"}${liveChosen(v) ? " (scelta per questo video)" : ""}`); }
  setStatus("Sottotitoli doppi accesi.");
  if (DS_IS_YT && hasCaptions[v] !== false && !liveChosen(v)) {
    // i sottotitoli di YouTube: li accendo (servono per avere il testo); se il testo si era perso, li faccio richiedere di nuovo
    const cc = document.querySelector("#movie_player .ytp-subtitles-button");
    if (cc && cc.getAttribute("aria-pressed") !== "true") { cc.click(); dsCcWatch(v); }
    else if (cc && !track) {
      // il testo dei sottotitoli non è arrivato: una volta sola spengo e riaccendo i CC per farlo richiedere,
      // poi basta (prima ogni clic su DS li faceva lampeggiare senza risultato)
      if (Date.now() - dsCcRetryAt < 20000) { setStatus("YouTube non manda il testo dei sottotitoli a Sottotitoli Doppi: ricarica la pagina (F5). Succede di solito dopo aver aggiornato l'estensione."); return; }
      dsCcRetryAt = Date.now();
      cc.click(); setTimeout(() => cc.click(), 400);
      setTimeout(() => { if (!track && currentVideoId() === v) setStatus("YouTube non manda il testo dei sottotitoli: ricarica la pagina (F5), oppure chiedi la trascrizione dal popup."); }, 5000);
    }
    else if (track && !translating && segTrans.every((x) => x == null)) startTranslation();
    return;
  }
  if (track && !liveChosen(v)) { if (!translating && segTrans.every((x) => x == null)) startTranslation(); return; }
  if (!live.running && !live.fullBusy) liveManualStart(v);
}

// 1.6.3: i CC di YouTube accesi ma il testo non arriva (la richiesta del lettore è partita prima che l'estensione fosse pronta,
// o è stata annullata): dopo 6 secondi li spengo e riaccendo una volta sola per quel video, senza che tu debba fare niente
const dsCcWatched = new Set();
function dsCcWatch(v) {
  if (!DS_IS_YT || dsCcWatched.has(v)) return;
  dsCcWatched.add(v);
  setTimeout(() => {
    if (currentVideoId() !== v || track || settings.enabled === false || hasCaptions[v] === false || liveChosen(v)) return;
    const cc = document.querySelector("#movie_player .ytp-subtitles-button");
    if (!cc || cc.getAttribute("aria-pressed") !== "true") return;
    dsLiveLog("i CC sono accesi ma il testo non è arrivato: li spengo e riaccendo una volta");
    cc.click(); setTimeout(() => cc.click(), 500);
  }, 6000);
}

function dsOnDisable() {
  if (live.running) liveStop("Sottotitoli doppi spenti: la trascrizione è in pausa. Per riaccenderli usa il pulsante DS nel lettore.");
  else setStatus("Sottotitoli doppi spenti. Per riaccenderli usa il pulsante DS nel lettore.");
}

// ---------- Overlay sul video ----------
const DS_FONTS = {
  default: '"YouTube Noto", Roboto, Arial, sans-serif',
  sans: 'system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif',
  serif: 'Georgia, "Times New Roman", serif',
  mono: 'ui-monospace, "Cascadia Mono", Consolas, monospace',
  rounded: '"Trebuchet MS", "Comic Sans MS", Verdana, sans-serif'
};

function applyStyle() {
  if (!overlay || !settings) return;
  const st = overlay.style;
  // 1.7.30: dimensione, traduzione e altezza ricordate per sito (popup → Aspetto dei sottotitoli → «Ricorda per questo sito»)
  const ss = settings.siteMemory !== false && settings.siteStyle && settings.siteStyle[location.hostname] || {};
  const pick = (k) => (ss[k] != null ? ss[k] : settings[k]);
  st.setProperty("--dualsub-size", pick("fontSize") + "px");
  st.setProperty("--dualsub-trans-scale", (pick("transScale") || 90) / 100);
  st.setProperty("--dualsub-orig-color", settings.origColor || "#ffffff");
  st.setProperty("--dualsub-trans-color", settings.transColor || "#f5c84b");
  st.setProperty("--dualsub-bg", `rgba(8, 8, 8, ${Math.max(0, Math.min(1, Number(settings.bgOpacity)))})`);
  st.setProperty("--dualsub-lift", (Number(pick("subPos")) || 0) + "px");
  st.setProperty("--dualsub-font", DS_FONTS[settings.subFont] || DS_FONTS.default);
  st.setProperty("--dualsub-roman", Math.max(0.3, Math.min(1.2, (Number(settings.romanSize) || 65) / 100)) + "em");
  dsCardVars(overlay, settings);   // aspetto delle schede (sono dentro il riquadro dei sottotitoli)
  if (typeof wordsReplace === "function") wordsReplace();   // la scheda aperta si rimette a posto con la nuova larghezza
  st.setProperty("--dualsub-romanline", Math.max(0.3, Math.min(1.5, (Number(settings.romanLineSize) || 80) / 100)));
  overlay.dataset.show = settings.subShow || "both";
  overlay.dataset.hide = settings.hideLine || "";   // «Nascondi finché non passi il mouse»: orig | trans
  overlay.classList.toggle("dualsub-trans-first", !!settings.transFirst);
}

function ensureOverlay() {
  const player = dsPlayerBox();
  if (!player) return null;
  if (overlay && player.contains(overlay)) return player;
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.className = "dualsub-overlay";
    lineOrig = document.createElement("div");
    lineOrig.className = "dualsub-line dualsub-orig";
    lineTrans = document.createElement("div");
    lineTrans.className = "dualsub-line dualsub-trans";
    const fixBtn = document.createElement("button");
    fixBtn.className = "dualsub-fixbtn dualsub-flagbtn";
    fixBtn.textContent = "⚑";
    fixBtn.title = "Frase sbagliata? Ritraduci, ritrascrivi o correggi a mano";
    fixBtn.addEventListener("click", () => fixOpenCard(fixBtn));
    const copyBtn = document.createElement("button");
    copyBtn.className = "dualsub-fixbtn dualsub-copybtn";
    copyBtn.textContent = "⧉";
    copyBtn.title = "Copia la frase o aprila in Google Traduttore, DeepL, Reverso";
    copyBtn.addEventListener("click", () => wordsOpenLineCard(copyBtn));
    const langBtn = document.createElement("button");
    langBtn.className = "dualsub-fixbtn dualsub-langbtn";
    langBtn.addEventListener("click", (e) => { e.stopPropagation(); fixLangOpen(langBtn); });
    overlay.append(lineOrig, lineTrans, fixBtn, copyBtn, langBtn, wordsRomanButton(), wordsBackButton(), aheadButton());
    wordsSetup();
    dsFlagZoneSetup();
    if (typeof DS_UI !== "undefined") DS_UI.watch(overlay);   // interfaccia nella lingua di «Traduci in», se scelta
  }
  player.appendChild(overlay);
  if (!dsChip) {
    dsChip = document.createElement("div"); dsChip.className = "dualsub-statuschip"; dsChip.hidden = true;
    dsChipTxt = document.createElement("span");
    // 1.7.37: ✕ per togliere i messaggi (finché il lavoro in corso non finisce)
    const x = document.createElement("button"); x.type = "button"; x.className = "dualsub-chipx"; x.textContent = "✕"; x.title = "Nascondi questi messaggi finché il lavoro in corso non finisce (si spengono del tutto nel popup)";
    x.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); dsChipMuted = currentVideoId() || "-"; dsChip.hidden = true; });
    x.addEventListener("mousedown", (e) => { e.preventDefault(); e.stopPropagation(); });
    dsChip.append(dsChipTxt, x);
  }
  if (dsChip.parentElement !== player) player.appendChild(dsChip);
  wordsOrigKey = "";
  wordsTransKey = "";
  applyStyle();
  return player;
}

// 1.7.28: senza nessuna frase sullo schermo il riquadro resta vuoto; il pulsante ⚑ (e quello della lingua) spuntano solo quando il mouse
// passa nella parte bassa del video, dove di solito stanno i sottotitoli
// 1.7.28: messaggi sul video sullo stato della trascrizione e della traduzione (si accendono e spengono nel popup: showStatusTrans,
// showStatusTl). Stanno in alto a sinistra; sparisce da sola quando il lavoro è finito e non cambia niente da qualche secondo.
let dsChip = null, dsChipTxt = null, dsChipMuted = "", dsChipText = "", dsChipAt = 0, dsChipForceUntil = 0;
// 1.7.32: quando parte una trascrizione (pulsante, tendina «Per questo video», modalità automatica) il messaggio sul video compare
// sempre, per qualche secondo, qualunque strada abbia preso l'avvio
function dsChipPing(ms = 9000) { dsChipForceUntil = Date.now() + ms; }
function dsChipUpdate(v, active) {
  if (!dsChip) return;
  const s = settings || {};
  const forced = Date.now() < dsChipForceUntil;
  const wantT = forced || s.showStatusTrans !== false, wantL = s.showStatusTl !== false;
  const lines = [];
  let busy = false;
  const clock = (ms) => { const x = Math.round(ms / 1000); return Math.floor(x / 60) + ":" + String(x % 60).padStart(2, "0"); };
  const liveHere = live.videoId === v && live.cues.length > 0;
  if (wantT && v) {
    if (live.fullBusy && live.videoId === v) { lines.push("🎙 " + (live.fullText || "Trascrizione completa in corso…")); busy = true; }
    else if (live.running && live.videoId === v) { const last = live.cues.length ? live.cues[live.cues.length - 1].end : 0; lines.push(`🎙 Trascrizione dell'audio in corso: ${live.cues.length} frasi${last ? ", fino a " + clock(last) : ""}`); busy = true; }
    else if (liveHere && live.full) lines.push(`🎙 Trascrizione completa: ${live.cues.length} frasi`);
    else if (liveHere) lines.push(`🎙 Trascrizione salvata: ${live.cues.length} frasi`);
    else if (track && track.videoId === v) lines.push(`🎙 Sottotitoli ${track.kind === "asr" ? "automatici di YouTube" + (track.fixedAsr ? " corretti dal modello" : "") : "del video"}: ${track.segments.length} frasi`);
  }
  if (wantL && v) {
    const arr = liveActive() ? live.cues.filter((c) => !c.removed) : track && track.videoId === v ? track.segments : null;
    if (arr && arr.length && baseLang(liveActive() ? liveSourceLang() || "" : track.lang) !== baseLang(s.targetLang)) {
      const done = liveActive() ? arr.filter((c) => c.trans != null && c.trans !== "…").length : (typeof segTrans !== "undefined" ? segTrans.filter((x) => x != null).length : 0);
      const tl = (typeof translating !== "undefined" && translating) || done < arr.length;
      if (done < arr.length && (tl || liveActive())) { lines.push(`🌐 Traduzione: ${done}/${arr.length} frasi`); busy = busy || !!(typeof translating !== "undefined" && translating) || liveActive(); }
      else if (done) lines.push(`🌐 Traduzione completa: ${arr.length} frasi`);
    }
  }
  // l'ultimo messaggio dell'estensione (errori, quote, cambi di servizio) per qualche secondo, nella categoria giusta
  if (dsLastStatus.text && Date.now() - dsLastStatus.at < 8000) {
    const t = dsLastStatus.text, isTr = /trascri|whisper|groq|audio|yt-dlp|sottotitoli/i.test(t), isTl = /tradu|gemini|google|deepl|microsoft|claude|ollama|quota|richieste/i.test(t);
    if ((isTr && wantT) || (isTl && wantL) || (!isTr && !isTl && (wantT || wantL))) lines.push("ℹ " + (t.length > 140 ? t.slice(0, 140) + "…" : t));
  }
  const text = lines.join("\n");
  if (text !== dsChipText) { dsChipText = text; dsChipAt = Date.now(); if (dsChipTxt) dsChipTxt.textContent = text; }
  // tolto con la ✕: resta nascosto finché c'è lavoro in corso su questo video; quando finisce (o cambi video) i messaggi tornano normali
  if (dsChipMuted) { if (dsChipMuted !== (v || "-") || (!busy && !forced)) dsChipMuted = ""; else { dsChip.hidden = true; return; } }
  dsChip.hidden = !text || !(busy || forced || Date.now() - dsChipAt < 6000);
}

let dsFlagZoneOn = false;
function dsFlagZoneSetup() {
  if (dsFlagZoneOn) return;
  dsFlagZoneOn = true;
  let ticking = false, last = null;
  document.addEventListener("mousemove", (e) => {
    last = e;
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      ticking = false;
      if (!overlay || overlay.hidden || !last) return;
      if (overlay.classList.contains("dualsub-has-line")) { overlay.classList.remove("dualsub-flagzone"); return; }
      const host = overlay.parentElement;
      const r = host && host.getBoundingClientRect();
      const inZone = !!r && last.clientX >= r.left && last.clientX <= r.right && last.clientY >= r.top + r.height * 0.62 && last.clientY <= r.bottom;
      overlay.classList.toggle("dualsub-flagzone", inZone);
    });
  }, { passive: true });
  document.addEventListener("mouseleave", () => { if (overlay) overlay.classList.remove("dualsub-flagzone"); });
}

function setText(el, text) {
  if (el.textContent !== text) el.textContent = text;
}

// Fuori da YouTube: sottotitoli già presenti nel video, e trascrizione automatica dei file aperti direttamente
let dsTrackRead = { id: null, count: 0, at: 0 };
function genericTick(video, v) {
  if (!v) return;
  if (hasCaptions[v] === undefined && video.readyState >= 1) hasCaptions[v] = dsTextTracks(video).length > 0;
  if (hasCaptions[v] && (!track || track.kind !== "file") && Date.now() - dsTrackRead.at > 3000) {
    dsTrackRead.at = Date.now();
    const got = dsReadTextTrack(video);
    if (got && (dsTrackRead.id !== v || got.count > dsTrackRead.count * 1.2)) {
      dsTrackRead = { id: v, count: got.count, at: Date.now() };
      onTrack({ videoId: v, lang: got.lang, kind: "track", baseUrl: null, events: got.events });
    }
  }
  // Parto da solo solo per il video "vero" della pagina: file diretto, oppure un video che suona,
  // non muto, grande e lungo almeno 30 secondi (così non spreco quote su anteprime e pubblicità)
  if (hasCaptions[v] === false && !video.paused && !live.running && !live.fullBusy && live.autoTried !== v) {
    const mainVideo = dsIsDirectMedia() || (!video.muted && video.volume > 0 &&
      (video.duration === Infinity || video.duration >= 30) && (video.tagName === "AUDIO" || dsArea(video) >= 400 * 225));
    if (mainVideo) { live.autoTried = v; liveAutoStart(v); }
  }
}

let dsYtPlayMs = 0, dsYtPlayLast = 0, dsYtPlayId = null;
function ytFallbackTick(video, v) {
  if (dsYtPlayId !== v) { dsYtPlayId = v; dsYtPlayMs = 0; }
  const now = Date.now();
  if (!video.paused && dsYtPlayLast) dsYtPlayMs += Math.min(1000, now - dsYtPlayLast);
  dsYtPlayLast = now;
  if (hasCaptions[v] !== undefined || track || live.running || live.fullBusy || live.autoTried === v) return;
  if (dsYtPlayMs > 12000 && !video.muted) {
    live.autoTried = v;
    hasCaptions[v] = false;
    liveAutoStart(v);
  }
}

function tick() {
  if (!settings) return;
  if (!DS_IS_YT && !dsAnyMedia()) { if (overlay) overlay.hidden = true; return; }
  if (dsSiteDisabled()) { if (overlay) overlay.hidden = true; document.documentElement.classList.remove("dualsub-hide-native"); return; }
  const player = ensureOverlay();
  const video = getVideo();

  const currentV = currentVideoId();
  dsModeReset(currentV);
  if (currentV && dsFixVid !== currentV) fixLoad(currentV);
  if (track && currentV && currentV !== track.videoId) reset();
  if (live.videoId && currentV !== live.videoId) liveReset();
  if (!DS_IS_YT && video) genericTick(video, currentV);
  if (DS_IS_YT && video && currentV) ytFallbackTick(video, currentV);

  const liveOn = liveActive();
  if (liveOn) liveWatchdog();
  const fullWait = live.fullBusy && live.videoId === currentV;
  // trascrizione partita ma ancora nessuna frase (per esempio lingua sbagliata): il riquadro c'è, vuoto, con il
  // pulsante della lingua per correggerla
  const liveWaiting = live.running && live.videoId === currentV && !live.cues.length;
  const show = !!(settings.enabled && video && player && (liveOn || fullWait || liveWaiting || (track && dsCaptionsOn())));
  dsToggleUpdate(player, show, currentV);

  document.documentElement.classList.toggle("dualsub-hide-native", show && settings.hideNative);
  if (show && settings.hideNative && !DS_IS_YT) dsHideNativeTracks(video);
  if (!overlay) return;
  try { dsChipUpdate(currentV, show); } catch (e) { console.debug("chip:", e); }
  // 1.7.26: il pulsante ⚑ c'è sempre su YouTube, anche quando non compare niente (nessuna trascrizione o traduzione): serve proprio
  // per farle rifare. Senza sottotitoli il riquadro mostra solo lui.
  const flagOnly = !show && !!(settings.enabled && video && player && DS_IS_YT && currentV);
  overlay.hidden = !(show || flagOnly);
  overlay.classList.toggle("dualsub-flagonly", flagOnly);
  if (!show) { wordsCurrent = null; if (flagOnly) { setText(lineOrig, ""); setText(lineTrans, ""); overlay.classList.remove("dualsub-has-line"); } return; }

  const t = video.currentTime * 1000;
  wordsTick(t, video);
  try { livePauseFull(video, currentV); } catch {}

  // Se la scheda di una parola è aperta, la frase resta ferma finché non la chiudi
  if (wordsCardState) {
    if (wordsCurrent) wordsRenderOriginal(wordsCurrent.text, wordsCurrent.lang); // aggiorna i colori delle parole salvate
    return;
  }

  let cur = null;
  if (liveOn) {
    const c = liveFind(t);
    if (c) cur = { text: c.text, raw: c.rawText, trans: c.trans != null ? c.trans : "…", quick: c.quick, start: c.start, end: c.end, lang: liveSourceLang(), live: true };
  } else if (track && trackEngine().E.kind === "youtube") {
    let text = DualSubs.activeText(track.cues, t);
    // sottotitoli automatici corretti dal modello: si mostra la frase corretta, non la riga originale di YouTube
    if (text && track.fixedAsr) { const si = DualSubs.findSegment(track.segments, t); if (si >= 0 && track.segments[si].raw != null) text = track.segments[si].text; }
    if (text) {
      const c = track.cues.find((x) => x.start <= t && t < x.end) || { start: t, end: t + 3000 };
      cur = { text, trans: DualSubs.activeText(transCues, t), start: c.start, end: c.end, lang: track.lang };
    }
  } else if (track) {
    const i = DualSubs.findSegment(track.segments, t);
    if (i >= 0) {
      const sg = track.segments[i];
      const tr = segTrans[i];
      cur = { text: sg.text, raw: sg.raw, trans: tr != null ? tr : (translating ? "…" : ""), start: sg.start, end: sg.end, lang: track.lang };
    }
  }

  if (cur) {
    const f = fixApply(currentV, cur.start, cur.text, cur.trans);
    if (f.gone) cur = null;
    else if (f.fixed || f.chat) { cur.text = f.text; cur.trans = f.trans; cur.quick = false; cur.fixedByUser = true; }
  }
  // 1.7.18: sotto ci va SEMPRE la traduzione. Se per un attimo la «traduzione» è il testo originale (o quello prima della correzione del
  // modello, o quello corretto), non la mostro: resta «…» finché non arriva quella vera
  if (cur && cur.trans && cur.trans !== "…" && !cur.fixedByUser) {
    const tg = settings.targetLang;
    if ([cur.text, cur.raw].some((s) => s && s !== cur.trans && (dsIsEcho(s, cur.trans) || dsUncheckedCopy(s, cur.trans, tg)) )) cur = { ...cur, trans: "…" };
  }
  // 1.7.26: «Tieni fermo il testo» (spento di serie): col mouse sopra i sottotitoli la frase resta quella che stai leggendo,
  // anche se il video va avanti (se la traduzione sta ancora arrivando, quella si aggiorna)
  if (settings.holdOnHover === true && wordsCurrent && wordsCurrent.text && overlay.matches(":hover") && (!cur || cur.text !== wordsCurrent.text)) return;
  wordsCurrent = cur;
  overlay.classList.toggle("dualsub-has-line", !!cur);
  wordsRenderOriginal(cur ? cur.text : "", cur ? cur.lang : "");
  wordsRomanButtonUpdate();
  wordsBackButtonUpdate();
  aheadButtonUpdate();
  const lb = overlay.querySelector(".dualsub-langbtn");
  if (lb) {
    // anche senza frasi sullo schermo, mentre si trascrive: se Whisper sente la lingua sbagliata i pezzi vengono
    // scartati e non compare niente, e proprio allora serve poter scegliere la lingua giusta
    const transcribing = live.running && live.videoId === currentV;
    lb.hidden = !((cur && cur.live) || transcribing);
    lb.classList.toggle("dualsub-show", !cur && transcribing);
    const code = (liveSourceLang() || "?").split("-")[0].toUpperCase();
    if (lb.textContent !== code) { lb.textContent = code; lb.title = `Lingua della trascrizione: ${dsLangName(liveSourceLang() || "") || "automatica"}. Clic per cambiarla se è sbagliata`; }
  }
  if (cur && cur.trans && cur.trans !== "…") wordsRenderTrans(cur.trans);
  else { wordsTransKey = ""; setText(lineTrans, cur ? cur.trans : fullWait ? "⏳ " + live.fullText : ""); }
  lineTrans.classList.toggle("dualsub-quick", !!(cur && cur.quick));
}

// 1.6.3: il controllo ogni 100 ms serve solo quando c'è un video: senza video nella pagina (quasi tutte, e quasi tutti i
// riquadri di una pagina) o con la scheda nascosta bastano due controlli al secondo; un video che compare o parte
// (play, loadedmetadata) lo fa controllare subito
function dsTickLoop() {
  try { tick(); } catch (e) { console.debug("tick:", e); }
  setTimeout(dsTickLoop, document.hidden || (!DS_IS_YT && !dsAnyMedia()) ? 500 : 100);
}
dsTickLoop();
for (const ev of ["play", "loadedmetadata", "playing"]) document.addEventListener(ev, () => { try { tick(); } catch {} }, true);
document.addEventListener("visibilitychange", () => { if (!document.hidden) { try { tick(); } catch {} } });

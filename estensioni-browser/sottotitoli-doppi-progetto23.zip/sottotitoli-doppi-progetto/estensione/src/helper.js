const $ = (id) => document.getElementById(id);
const IS_FIREFOX = typeof browser !== "undefined" && !!browser.runtime && /Firefox/.test(navigator.userAgent);

function detectOS() {
  const p = (navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || navigator.userAgent;
  if (/win/i.test(p)) return "win";
  if (/mac/i.test(p)) return "mac";
  return "linux";
}

function showSteps() {
  const win = $("os").value === "win";
  $("stepsWin").hidden = !win;
  $("stepsUnix").hidden = win;
}

async function check() {
  $("status").textContent = "Controllo…";
  $("status").className = "status";
  $("details").textContent = "";
  let r;
  try { r = await DS_EXT.runtime.sendMessage({ type: "helperPing" }); } catch (e) { r = { installed: false, error: String(e.message || e) }; }
  if (r && r.installed) {
    $("status").textContent = "Installato e funzionante ✓";
    $("status").className = "status ok";
    $("details").textContent = `yt-dlp ${r.ytdlp || "?"} · Deno ${r.deno ? "presente" : "MANCANTE (rilancia l'installatore)"} · ` +
      (r.ffmpeg === undefined ? "" : `ffmpeg ${r.ffmpeg ? "presente" : "mancante (serve solo per le dirette sincronizzate: rilancia l'installatore)"} · `) +
      `programma di appoggio ${r.version}` + (r.version && r.version < "1.6" ? " (vecchio: rilancia l'installatore, serve per le dirette sincronizzate)" : "");
  } else {
    $("status").textContent = "Non installato";
    $("status").className = "status no";
    $("details").textContent = r && r.error && !/not found|non trovato|Specified native messaging host/i.test(r.error)
      ? "Dettaglio: " + r.error : "Scarica l'installatore qui sotto e lancialo.";
  }
}

function b64(text) {
  const bytes = new TextEncoder().encode(text);
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

async function buildInstaller(os) {
  const host = await (await fetch(chrome.runtime.getURL("helper/sd_host.py"))).text();
  const extId = IS_FIREFOX ? "" : chrome.runtime.id;
  if (os === "win") {
    const ps = (await (await fetch(chrome.runtime.getURL("helper/install-windows.ps1"))).text())
      .replace("__EXTID__", extId).replace("__HOSTB64__", b64(host));
    const head = [
      "@echo off",
      "setlocal",
      "title Sottotitoli Doppi - installazione",
      'set "SD_SELF=%~f0"',
      "powershell -NoProfile -ExecutionPolicy Bypass -Command \"$s = [IO.File]::ReadAllText($env:SD_SELF); $i = $s.LastIndexOf('#==INIZIO==#'); Invoke-Expression $s.Substring($i)\"",
      "echo.",
      "pause",
      "exit /b",
      "#==INIZIO==#"
    ].join("\r\n");
    return { name: "installa-sottotitoli-doppi.bat", text: head + "\r\n" + ps.replace(/\r?\n/g, "\r\n") };
  }
  const sh = (await (await fetch(chrome.runtime.getURL("helper/install-unix.sh"))).text())
    .replace("__EXTID__", extId).replace("__HOSTB64__", b64(host));
  return { name: "installa-sottotitoli-doppi.sh", text: sh };
}

$("download").addEventListener("click", async () => {
  const f = await buildInstaller($("os").value);
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([f.text], { type: "application/octet-stream" }));
  a.download = f.name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
});
$("os").addEventListener("change", showSteps);
$("check").addEventListener("click", check);

$("os").value = detectOS();
showSteps();
$("multiNote").textContent = IS_FIREFOX
  ? "Stai usando Firefox: l'installatore registra il programma per Firefox. Se usi l'estensione anche in Edge o Chrome, scarica e lancia l'installatore anche da lì."
  : "L'installatore registra il programma per questo browser e anche per Firefox.";
check();

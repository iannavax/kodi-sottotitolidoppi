#!/usr/bin/env python3
# Sottotitoli Doppi - programma di appoggio per yt-dlp.
# Il browser lo avvia da solo (messaggistica nativa) quando l'estensione chiede
# di trascrivere un video intero: scarica solo l'audio con yt-dlp e lo passa
# all'estensione a pezzi. Non tiene niente: il file scaricato viene cancellato subito.
import base64, json, os, re, shutil, struct, subprocess, sys, tempfile, threading, time

VERSION = "1.1"
HERE = os.path.dirname(os.path.abspath(__file__))
WIN = sys.platform.startswith("win")
CHUNK = 600 * 1024          # il browser accetta messaggi fino a 1 MB: 600 KB diventano ~800 KB in base64
UPDATE_EVERY = 3 * 86400    # yt-dlp si aggiorna da solo al massimo ogni 3 giorni

if WIN:
    import msvcrt
    msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
    msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)
NO_WINDOW = 0x08000000 if WIN else 0


# ---------- Messaggi con il browser ----------
def read_msg():
    raw = sys.stdin.buffer.read(4)
    if len(raw) < 4:
        return None
    n = struct.unpack("<I", raw)[0]
    return json.loads(sys.stdin.buffer.read(n).decode("utf-8"))


SEND_LOCK = threading.Lock()


def send(obj):
    data = json.dumps(obj).encode("utf-8")
    with SEND_LOCK:   # la diretta manda l'audio da un altro filo: un messaggio alla volta
        sys.stdout.buffer.write(struct.pack("<I", len(data)))
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()


# ---------- Strumenti ----------
def find_tool(names):
    for n in names:
        p = os.path.join(HERE, n)
        if os.path.isfile(p):
            return p
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return None


def ytdlp_path():
    return os.environ.get("SD_YTDLP") or find_tool(
        ["yt-dlp.exe"] if WIN else ["yt-dlp_macos", "yt-dlp"])


def deno_path():
    return os.environ.get("SD_DENO") or find_tool(["deno.exe"] if WIN else ["deno"]) or \
        (os.path.expanduser("~/.deno/bin/deno") if os.path.isfile(os.path.expanduser("~/.deno/bin/deno")) else None)


def ffmpeg_path():
    return os.environ.get("SD_FFMPEG") or find_tool(["ffmpeg.exe"] if WIN else ["ffmpeg"])


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, creationflags=NO_WINDOW, **kw)


def ytdlp_version(y):
    try:
        return run([y, "--version"], timeout=30).stdout.strip()
    except Exception:
        return ""


def maybe_update(y):
    stamp = os.path.join(HERE, ".last-update")
    try:
        if time.time() - os.path.getmtime(stamp) < UPDATE_EVERY:
            return
    except OSError:
        pass
    try:
        open(stamp, "w").close()
        send({"type": "status", "text": "Aggiorno yt-dlp…"})
        run([y, "-U"], timeout=120)
    except Exception:
        pass


def firefox_profile_exists():
    if WIN:
        base = os.path.join(os.environ.get("APPDATA", ""), "Mozilla", "Firefox", "Profiles")
    elif sys.platform == "darwin":
        base = os.path.expanduser("~/Library/Application Support/Firefox/Profiles")
    else:
        base = os.path.expanduser("~/.mozilla/firefox")
    return os.path.isdir(base)


# ---------- Download dell'audio ----------
# Prima l'audio più leggero adatto al parlato (opus), così il file resta piccolo;
# se il sito non separa l'audio, il video più piccolo disponibile.
FORMAT = "ba[acodec^=opus][abr<=90]/ba[acodec^=opus]/ba[ext=m4a]/ba/wv*+wa/w"


def download(url, cookies=False):
    y = ytdlp_path()
    tmp = tempfile.mkdtemp(prefix="sd-")
    cmd = [y, "--no-playlist", "--no-part", "--no-mtime", "--newline", "--no-simulate",
           "-f", FORMAT, "--max-filesize", "600M",
           "-o", os.path.join(tmp, "audio.%(ext)s"),
           "--progress-template", "download:SDPROG %(progress._percent_str)s",
           "--print", "before_dl:SDMETA %(duration)s|%(ext)s|%(title)s",
           "--print", "after_move:SDFILE %(filepath)s"]
    d = deno_path()
    if d:
        cmd += ["--js-runtimes", "deno:" + d]
    if cookies:
        cmd += ["--cookies-from-browser", "firefox"]
    cmd.append(url)

    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                         encoding="utf-8", errors="replace", creationflags=NO_WINDOW,
                         env=dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1"))
    meta, filepath, last_pct = {}, None, -1
    for line in p.stdout:
        line = line.strip()
        if line.startswith("SDPROG"):
            m = re.search(r"([\d.]+)%", line)
            if m:
                pct = int(float(m.group(1)))
                if pct != last_pct:
                    last_pct = pct
                    send({"type": "progress", "pct": pct})
        elif line.startswith("SDMETA"):
            dur, ext, title = (line[7:].split("|", 2) + ["", "", ""])[:3]
            try:
                meta["duration"] = float(dur)
            except ValueError:
                meta["duration"] = 0
            meta["ext"], meta["title"] = ext, title
            send({"type": "status", "text": "Scarico l'audio…"})
        elif line.startswith("SDFILE"):
            filepath = line[7:].strip()
    err = p.stderr.read()
    p.wait()
    if not filepath or not os.path.isfile(filepath):
        # yt-dlp a volte non stampa il percorso: lo cerco nella cartella temporanea
        files = [os.path.join(tmp, f) for f in os.listdir(tmp)]
        filepath = files[0] if files else None
    return p.returncode, filepath, meta, err, tmp


def friendly_error(err):
    e = err or ""
    if re.search(r"Sign in to confirm|not a bot", e, re.I):
        return "bot", "YouTube chiede di confermare che non sei un robot: apri il video da Firefox con l'account YouTube, oppure riprova più tardi."
    if re.search(r"Private video|members-only|This video is private", e, re.I):
        return "private", "Il video è privato o riservato agli abbonati del canale."
    if re.search(r"Unsupported URL", e, re.I):
        return "unsupported", "yt-dlp non sa scaricare da questo sito."
    if re.search(r"max-filesize|larger than max", e, re.I):
        return "toobig", "Il file è troppo grande (oltre 600 MB)."
    if re.search(r"JavaScript runtime|jsc|challenge", e, re.I):
        return "js", "yt-dlp non riesce a risolvere i controlli di YouTube: serve Deno aggiornato (rilancia l'installatore)."
    lines = [l for l in e.strip().splitlines() if "ERROR" in l] or e.strip().splitlines()[-1:]
    return "failed", (lines[-1] if lines else "yt-dlp non è riuscito a scaricare l'audio.")[:300]


def cmd_audio(msg):
    y = ytdlp_path()
    if not y:
        send({"type": "error", "code": "noytdlp", "message": "yt-dlp non è installato: rilancia l'installatore."})
        return
    maybe_update(y)
    send({"type": "status", "text": "Cerco l'audio del video…"})
    code, path, meta, err, tmp = download(msg["url"])
    if (not path) and re.search(r"Sign in to confirm|not a bot", err or "", re.I) and firefox_profile_exists():
        send({"type": "status", "text": "YouTube chiede una conferma: riprovo con i cookie di Firefox…"})
        shutil.rmtree(tmp, ignore_errors=True)
        code, path, meta, err, tmp = download(msg["url"], cookies=True)
    try:
        if not path:
            c, m = friendly_error(err)
            send({"type": "error", "code": c, "message": m})
            return
        size = os.path.getsize(path)
        ext = os.path.splitext(path)[1].lstrip(".") or meta.get("ext", "")
        send({"type": "meta", "size": size, "ext": ext, "title": meta.get("title", ""),
              "duration": meta.get("duration", 0)})
        with open(path, "rb") as f:
            seq = 0
            while True:
                block = f.read(CHUNK)
                if not block:
                    break
                send({"type": "chunk", "seq": seq, "data": base64.b64encode(block).decode("ascii")})
                seq += 1
        send({"type": "done", "chunks": seq})
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------- Diretta in anticipo ----------
# yt-dlp legge la diretta dal punto più recente e ffmpeg la trasforma in audio semplice (16 kHz, mono): l'estensione
# riceve un secondo alla volta, lo trascrive e mostra i sottotitoli quando il video (tenuto qualche secondo indietro)
# arriva lì. Niente viene salvato su disco. Si ferma quando l'estensione chiude il collegamento o manda "stop".
LIVE_FORMAT = "ba/91/92/93/w"
LIVE = {"stop": None, "procs": []}


def live_stop():
    if LIVE["stop"]:
        LIVE["stop"].set()
    for p in LIVE["procs"]:
        try:
            p.kill()
        except Exception:
            pass
    LIVE["procs"] = []


def live_run(url, cookies, stop):
    y, f = ytdlp_path(), ffmpeg_path()
    err_y = tempfile.TemporaryFile()
    cmd = [y, "--no-playlist", "--no-part", "--quiet", "--no-warnings", "-f", LIVE_FORMAT, "-o", "-"]
    d = deno_path()
    if d:
        cmd += ["--js-runtimes", "deno:" + d]
    if cookies:
        cmd += ["--cookies-from-browser", "firefox"]
    cmd.append(url)
    yt = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=err_y, creationflags=NO_WINDOW)
    ff = subprocess.Popen([f, "-hide_banner", "-loglevel", "error", "-i", "pipe:0", "-vn", "-ac", "1", "-ar", "16000",
                           "-f", "s16le", "pipe:1"], stdin=yt.stdout, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          creationflags=NO_WINDOW)
    yt.stdout.close()
    LIVE["procs"] = [yt, ff]
    pos, sent = 0, 0
    while not stop.is_set():
        block = ff.stdout.read(32000)          # un secondo di audio
        if not block:
            break
        if sent == 0:
            send({"type": "status", "text": "Diretta: leggo l'audio in anticipo."})
        send({"type": "pcm", "pos": pos, "rate": 16000, "data": base64.b64encode(block).decode("ascii")})
        pos += len(block) // 2
        sent += 1
    for p in (yt, ff):
        try:
            p.kill()
        except Exception:
            pass
    err_y.seek(0)
    return sent, err_y.read().decode("utf-8", "replace")


def cmd_live(msg):
    y, f = ytdlp_path(), ffmpeg_path()
    if not y:
        send({"type": "error", "code": "noytdlp", "message": "yt-dlp non è installato: rilancia l'installatore."})
        return
    if not f:
        send({"type": "error", "code": "noffmpeg", "message": "manca ffmpeg (serve per le dirette in anticipo): rilancia l'installatore."})
        return
    stop = threading.Event()
    LIVE["stop"] = stop

    def work():
        try:
            sent, err = live_run(msg["url"], False, stop)
            if not sent and not stop.is_set() and re.search(r"Sign in to confirm|not a bot", err, re.I) and firefox_profile_exists():
                send({"type": "status", "text": "YouTube chiede una conferma: riprovo con i cookie di Firefox…"})
                sent, err = live_run(msg["url"], True, stop)
            if stop.is_set():
                return
            if not sent:
                c, m = friendly_error(err)
                send({"type": "error", "code": c, "message": m})
            else:
                send({"type": "done"})
        except Exception as e:
            send({"type": "error", "code": "crash", "message": f"errore nella lettura della diretta: {e}"})
    threading.Thread(target=work, daemon=True).start()


def main():
    while True:
        msg = read_msg()
        if msg is None:
            live_stop()   # l'estensione ha chiuso il collegamento: fermo yt-dlp e ffmpeg
            return
        try:
            if msg.get("cmd") == "ping":
                y = ytdlp_path()
                send({"type": "pong", "version": VERSION, "ytdlp": ytdlp_version(y) if y else "",
                      "deno": bool(deno_path()), "ffmpeg": bool(ffmpeg_path()), "platform": sys.platform})
            elif msg.get("cmd") == "audio":
                cmd_audio(msg)
            elif msg.get("cmd") == "live":
                live_stop()
                cmd_live(msg)
            elif msg.get("cmd") == "stop":
                live_stop()
            else:
                send({"type": "error", "code": "unknown", "message": "comando sconosciuto"})
        except Exception as e:
            send({"type": "error", "code": "crash", "message": f"errore del programma di appoggio: {e}"})


if __name__ == "__main__":
    main()

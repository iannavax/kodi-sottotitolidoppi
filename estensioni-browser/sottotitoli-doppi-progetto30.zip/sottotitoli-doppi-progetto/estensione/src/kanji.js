// Pagina "Kanji e caratteri": i caratteri per livello (JLPT, classe giapponese, HSK, Cina, Corea, frequenza, tratti,
// radicale), dai dati dentro l'estensione (han-data.json). Si apre cliccando i distintivi nella scheda di un carattere.
const $ = (id) => document.getElementById(id);
const P = new URLSearchParams(location.search);
let sys = P.get("sys") || "jlpt", level = P.get("level") || "", me = P.get("ch") || "";
const lang = (P.get("lang") || "ja").split("-")[0], target = P.get("target") || "it";
let D = null, known = new Set(), sel = me, vocab = {};
const llmCache = {};   // carattere → spiegazione del modello (1.6.2)
const GR = { 1: "1ª elem.", 2: "2ª elem.", 3: "3ª elem.", 4: "4ª elem.", 5: "5ª elem.", 6: "6ª elem.", 8: "medie (jōyō)", 9: "nomi (jinmeiyō)", 10: "nomi (jinmeiyō)" };
const FREQ = [[1, 500], [501, 1000], [1001, 1500], [1501, 2000], [2001, 2501]];
// i sistemi: nome, livelli, a quale livello appartiene un carattere
const SYS = {
  jlpt: { name: "JLPT", tip: "Esame di giapponese: N5 il più facile, N1 il più difficile", levels: () => ["5", "4", "3", "2", "1"], label: (l) => "N" + l, of: (e) => (e.jlpt ? String(e.jlpt) : "") },
  grade: { name: "Classe in Giappone", tip: "Quando si studia nelle scuole giapponesi", levels: () => ["1", "2", "3", "4", "5", "6", "8", "9"], label: (l) => GR[l], of: (e) => (e.g ? String(e.g === 10 ? 9 : e.g) : "") },
  freq: { name: "Più usati (Giappone)", tip: "Posizione tra i kanji più usati nei giornali giapponesi", levels: () => FREQ.map((x) => String(x[0])), label: (l) => { const r = FREQ.find((x) => String(x[0]) === l); return r[0] + "–" + (r[1] - 1); }, of: (e) => { const r = e.f && FREQ.find((x) => e.f >= x[0] && e.f < x[1]); return r ? String(r[0]) : ""; }, order: (e) => e.f },
  hsk: { name: "HSK", tip: "Esame di cinese HSK 3.0: 1 il più facile, 7-9 il più difficile", levels: () => ["1", "2", "3", "4", "5", "6", "7"], label: (l) => (l === "7" ? "7-9" : l), of: (e) => (e.hsk ? String(e.hsk) : "") },
  tg: { name: "Comuni in Cina", tip: "Lista ufficiale cinese dei caratteri di uso comune (通用规范汉字表)", levels: () => ["1", "2", "3"], label: (l) => ({ 1: "comuni (3500)", 2: "meno comuni", 3: "rari" })[l], of: (e) => (e.tg ? String(e.tg) : "") },
  koe: { name: "Hanja (Corea)", tip: "I 1800 hanja che si studiano nelle scuole coreane", levels: () => ["1"], label: () => "hanja scolastici", of: (e) => (e.koe ? "1" : "") },
  strokes: { name: "Tratti", tip: "Numero di tratti", levels: () => Array.from({ length: 24 }, (_, i) => String(i + 1)), label: (l) => l, of: (e) => (e.s ? String(Math.min(24, e.s)) : "") },
  radical: { name: "Radicale", tip: "Il radicale (la parte con cui si cerca nei dizionari)", levels: () => Object.keys(D.rad).filter((k) => !/'/.test(k)).sort((a, b) => a - b), label: (l) => (D.rad[l] ? D.rad[l][0] : l), of: (e) => ((e.r || "").split(".")[0].replace(/'+/, "") || "") }
};
const readingOf = (e) => (lang === "zh" ? e.py : lang === "ko" ? e.ko : lang === "vi" ? e.vi : [...(e.on || []).slice(0, 1), ...(e.kun || []).slice(0, 1)].join(" · ")) || e.py || "";
const short = (t) => String(t || "").split(/[;,]/)[0].trim();

async function loadKnown() {
  const r = await DS_EXT.storage.local.get({ knownWords: {} });
  known = new Set(String((r.knownWords || {})[lang] || "").split("\n").filter(Boolean));
}
async function setKnown(chars, on) {
  const r = await DS_EXT.storage.local.get({ knownWords: {} });
  const kw = r.knownWords || {};
  const set = new Set(String(kw[lang] || "").split("\n").filter(Boolean));
  for (const c of chars) on ? set.add(c) : set.delete(c);
  kw[lang] = [...set].join("\n");
  await DS_EXT.storage.local.set({ knownWords: kw });
  known = set;
}
// 1.6.2: il vocabolario (stesso della scheda delle parole): un carattere come voce a sé
const vid = (c) => lang + "|" + c.toLowerCase();
async function loadVocab() { vocab = (await DS_EXT.storage.local.get({ vocab: {} })).vocab || {}; }
async function toggleSave(c) {
  const cur = (await DS_EXT.storage.local.get({ vocab: {} })).vocab || {};
  const id = vid(c);
  if (cur[id]) delete cur[id];
  else {
    const e = D.c[c] || {};
    let h = null;
    try { h = await DS_EXT.runtime.sendMessage({ type: "hanChar", ch: c, lang, target }); } catch {}
    const rd = [e.on && e.on.length ? "on " + e.on.join("、") : "", e.kun && e.kun.length ? "kun " + e.kun.join("、") : "", lang === "zh" && e.py ? e.py : "", lang === "ko" && e.ko ? e.ko : ""].filter(Boolean).join(" · ");
    const meaning = h && !h.error ? [h.meaning, lang === "ja" && h.jm ? (h.jmTr || h.jm) : (h.defTr || h.def)].filter(Boolean).filter((x, i, a) => a.findIndex((y) => y.toLowerCase() === x.toLowerCase()) === i).join("; ") : (e.jm || e.d || "");
    const lv = [e.s ? e.s + " tratti" : "", e.jlpt ? "JLPT N" + e.jlpt : "", e.hsk ? "HSK " + (e.hsk >= 7 ? "7-9" : e.hsk) : ""].filter(Boolean).join(", ");
    cur[id] = { id, word: c, lemma: "", lang, pos: lang === "ja" ? "kanji" : lang === "ko" ? "hanja" : "carattere", meaning, translit: lang === "zh" ? e.py || "" : "",
      explanation: [rd, lv].filter(Boolean).join(" — "), ipa: "", etym: "", sentence: "", sentenceTrans: "", added: Date.now(), status: "learning", from: "kanji" };
  }
  await DS_EXT.storage.local.set({ vocab: cur });
  vocab = cur;
}
// il modello per «✨ Spiega»: quello delle spiegazioni (o dei sottotitoli, o il primo pronto della fila), con il primo
// modello non finito oggi (come nelle schede)
async function pageEngine() {
  const s = await DS_EXT.storage.sync.get(DS_CONFIG.SYNC_DEFAULTS);
  const l = await DS_EXT.storage.local.get({ keys: {}, dsBlocked: {} });
  const day = (() => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return ""; } })();
  const on = (k) => { const b = l.dsBlocked[k]; return !!b && b.day === day && (!b.ttl || Date.now() - b.at < b.ttl); };
  const blocked = (id, m) => !!m && on(id + "|" + m);
  for (const id of [s.explainEngine, s.engine, ...DS_CONFIG.engineOrder(s)]) {
    const E = DS_CONFIG.ENGINES[id];
    if (!E || !(E.kind === "openai" || E.kind === "claude") || (E.needsKey && !l.keys[id])) continue;
    const e = dsTaskModel(s, "explainEngine", { id, E, key: l.keys[id] || "", model: (s.models || {})[id] || E.defaultModel || "", localUrl: s.localUrl }, blocked);
    if (e && !e.exhausted && e.model) return { ...e, name: E.label.split(" (")[0].split(",")[0] };
  }
  return null;
}
async function explainChar(c, tries = 0) {
  const e = await pageEngine();
  if (!e) { llmCache[c] = { error: "serve la chiave di un modello (popup → 🔑 Servizi)" }; detail(); return; }
  llmCache[c] = { wait: true }; detail();
  let r;
  try { r = await dsSendLong({ type: "hanExplain", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, ch: c, lang, target }); }
  catch (err) { r = { error: String(err.message || err) }; }
  if (r && r.error && r.daily && tries < 4) {
    // finito quel modello oggi: lo segno (come nelle schede) e riprovo con il prossimo
    const l = await DS_EXT.storage.local.get({ dsBlocked: {} });
    const day = (() => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return ""; } })();
    await DS_EXT.storage.local.set({ dsBlocked: { ...l.dsBlocked, [e.id + "|" + e.model]: { day, at: Date.now() } } });
    return explainChar(c, tries + 1);
  }
  llmCache[c] = r && !r.error ? r : { error: (r && r.error) || "nessuna risposta" };
  if (sel === c) detail();
}
function go(s, l, ch) {
  sys = s; level = l || ""; if (ch !== undefined) sel = ch;
  history.replaceState(null, "", "?" + new URLSearchParams({ sys, level, ch: sel || "", lang, target }));
  render();
}
function chars() {
  const S = SYS[sys];
  let list = Object.entries(D.c).filter(([, e]) => S.of(e) === level);
  const q = $("q").value.trim().toLowerCase();
  if (q) list = Object.entries(D.c).filter(([c, e]) => c === q || (e.py || "").toLowerCase().includes(q) || (e.on || []).concat(e.kun || []).some((r) => r.includes(q)) ||
    (e.ko || "").includes(q) || (e.d || "").toLowerCase().includes(q) || (e.jm || "").toLowerCase().includes(q));
  const ord = S.order || ((e) => e.f || (e.hsk ? 3000 + e.hsk * 100 : 0) || 9000 + (e.s || 0));
  const show = $("show").value;
  if (show === "todo") list = list.filter(([c]) => !known.has(c));
  else if (show === "known") list = list.filter(([c]) => known.has(c));
  else if (show === "saved") list = list.filter(([c]) => vocab[vid(c)]);
  return list.sort((a, b) => ord(a[1]) - ord(b[1]) || (a[1].s || 0) - (b[1].s || 0)).slice(0, 3000);
}
function render() {
  const S = SYS[sys];
  $("tabs").textContent = "";
  for (const [k, x] of Object.entries(SYS)) {
    const a = document.createElement("a");
    a.href = "#"; a.textContent = x.name; a.title = x.tip; a.className = k === sys ? "on" : "";
    a.addEventListener("click", (ev) => { ev.preventDefault(); go(k, SYS[k].levels()[0]); });
    $("tabs").append(a);
  }
  if (!level) level = S.levels()[0];
  $("levels").textContent = "";
  for (const l of S.levels()) {
    const all = Object.entries(D.c).filter(([, e]) => S.of(e) === l);
    if (!all.length) continue;
    const kn = all.filter(([c]) => known.has(c)).length;
    const b = document.createElement("button");
    b.type = "button"; b.className = l === level ? "on" : "";
    b.append(S.label(l));
    const sm = document.createElement("small"); sm.textContent = kn ? `${kn}/${all.length}` : String(all.length); b.append(sm);
    b.title = `${S.name} ${S.label(l)}: ${all.length} caratteri, ne conosci ${kn}`;
    b.addEventListener("click", () => { $("q").value = ""; go(sys, l); });
    $("levels").append(b);
  }
  const list = chars();
  const kn = list.filter(([c]) => known.has(c)).length;
  $("stats").innerHTML = "";
  for (const t of [`${list.length} caratteri`, `ne conosci ${kn} (${list.length ? Math.round((kn * 100) / list.length) : 0}%)`]) { const s = document.createElement("span"); s.className = "stat"; s.textContent = t; $("stats").append(s); }
  $("title").textContent = "Kanji e caratteri — " + S.name + ($("q").value.trim() ? "" : " " + S.label(level));
  $("grid").textContent = "";
  for (const [c, e] of list) {
    const d = document.createElement("div");
    d.className = "ch" + (known.has(c) ? " known" : "") + (c === sel ? " me" : "");
    d.title = (e.d || "") + (e.s ? ` · ${e.s} tratti` : "");
    const b = document.createElement("b"); b.textContent = c;
    const r = document.createElement("span"); r.textContent = readingOf(e) || " ";
    const m = document.createElement("i"); m.textContent = short(lang === "ja" && e.jm ? e.jm : e.d) || " ";
    d.append(b, r, m);
    // ✓ e ☆ direttamente sul riquadro (1.6.2): niente andare su e giù nella pagina
    const qa = document.createElement("span"); qa.className = "qa";
    const qb = (t, title, on, fn) => { const x = document.createElement("button"); x.type = "button"; x.textContent = t; x.title = title; if (on) x.className = "on"; x.addEventListener("click", async (ev) => { ev.stopPropagation(); await fn(); render(); }); return x; };
    qa.append(qb("✓", known.has(c) ? "Lo conosci: clicca per togliere" : "Segna come conosciuto", known.has(c), () => setKnown([c], !known.has(c))),
      qb(vocab[vid(c)] ? "★" : "☆", vocab[vid(c)] ? "Nel vocabolario: clicca per togliere" : "Salva nel vocabolario", !!vocab[vid(c)], () => toggleSave(c)));
    d.append(qa);
    if (vocab[vid(c)]) { const mk2 = document.createElement("span"); mk2.className = "mark"; mk2.textContent = "★"; d.append(mk2); }
    d.tabIndex = 0;
    const open = () => { sel = c; $("side").classList.remove("closed"); history.replaceState(null, "", "?" + new URLSearchParams({ sys, level, ch: sel, lang, target })); render(); };
    d.addEventListener("click", open);
    d.addEventListener("keydown", (ev) => { if (ev.key === "Enter") open(); });
    $("grid").append(d);
  }
  detail();
  const meEl = $("grid").querySelector(".ch.me");
  if (meEl && !render.scrolled) { render.scrolled = true; meEl.scrollIntoView({ block: "center" }); }
}
// scheda del carattere scelto, con tutto cliccabile
function detail() {
  const box = $("detail"), e = sel && D.c[sel];
  box.hidden = !e;
  $("empty").hidden = !!e;
  if (!e) return;
  box.textContent = "";
  const cl = document.createElement("button"); cl.type = "button"; cl.className = "close"; cl.textContent = "✕"; cl.title = "Chiudi";
  cl.addEventListener("click", () => { sel = ""; $("side").classList.add("closed"); history.replaceState(null, "", "?" + new URLSearchParams({ sys, level, lang, target })); render(); });
  box.append(cl);
  const mk = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  const top = mk("div", "top"), info = mk("div");
  top.append(mk("div", "big", sel), info);
  const line = (label, ...content) => { if (!content.length || content.every((x) => !x)) return; const d = mk("div", "line"); d.append(mk("b", null, label + ": "), ...content.map((x) => (typeof x === "string" ? document.createTextNode(x) : x))); info.append(d); };
  const chip = (c, title) => { const b = mk("button", "chip", c); b.type = "button"; b.title = title || ""; b.addEventListener("click", () => { sel = c; render(); }); return b; };
  const badge = (text, title, fn) => { const b = mk("button", "badge", text); b.type = "button"; b.title = title; b.addEventListener("click", fn); return b; };
  line("Significato (inglese)", [e.d, e.jm && e.jm.toLowerCase() !== (e.d || "").toLowerCase() ? "giapponese: " + e.jm : ""].filter(Boolean).join(" — "));
  const tr = mk("span", "tr"); line("Nella tua lingua", tr);
  DS_EXT.runtime.sendMessage({ type: "translate", engine: "google", target, source: "en", texts: [e.jm && lang === "ja" ? e.jm : e.d || ""] })
    .then((r) => { tr.textContent = (r && r.translations && r.translations[0]) || "—"; }).catch(() => { tr.textContent = "—"; });
  if ((e.on || []).length || (e.kun || []).length) line("Giapponese", [e.on && e.on.length ? "on " + e.on.join("、") : "", e.kun && e.kun.length ? "kun " + e.kun.join("、") : ""].filter(Boolean).join(" · "));
  line("Cinese (pinyin)", e.py || ""); line("Cantonese", e.yue || ""); line("Coreano", e.ko || ""); line("Vietnamita", e.vi || "");
  const parts = Array.from(String(e.p || "").replace(/[⿰-⿿㇯]/g, "")).filter((x) => x !== sel && D.c[x] && D.c[x].d);
  if (parts.length) { const sp = mk("span"); parts.forEach((x, i) => { if (i) sp.append(" + "); sp.append(chip(x, D.c[x].d), " " + short(D.c[x].d)); }); line("Parti", sp); }
  const rn = (e.r || "").split(".")[0].replace(/'+/, ""), rd = D.rad[rn];
  if (rd) line("Radicale", chip(rd[0], rd[1]), ` ${rd[1]} (n. ${rn}) `, badge("tutti con questo radicale ›", "I caratteri con questo radicale", () => go("radical", rn)));
  const forms = mk("span");
  if (e.sv) forms.append("semplificato ", ...Array.from(e.sv).map((x) => chip(x, "forma semplificata")));
  if (e.tv) forms.append(" tradizionale ", ...Array.from(e.tv).map((x) => chip(x, "forma tradizionale")));
  if (forms.childNodes.length) line("Altre forme", forms);
  const lv = mk("div");
  if (e.s) lv.append(badge(e.s + " tratti ›", "Tutti i caratteri con questo numero di tratti", () => go("strokes", String(Math.min(24, e.s)))));
  if (e.jlpt) lv.append(badge("JLPT N" + e.jlpt + " ›", "Tutti i kanji di questo livello JLPT", () => go("jlpt", String(e.jlpt))));
  if (e.g && GR[e.g]) lv.append(badge(GR[e.g] + " ›", "Tutti i kanji di questa classe", () => go("grade", String(e.g === 10 ? 9 : e.g))));
  if (e.f) lv.append(badge("n. " + e.f + " in Giappone ›", "I kanji più usati, a partire da qui", () => go("freq", SYS.freq.of(e))));
  if (e.hsk) lv.append(badge("HSK " + (e.hsk >= 7 ? "7-9" : e.hsk) + " ›", "Tutti i caratteri di questo livello HSK", () => go("hsk", String(e.hsk))));
  if (e.tg) lv.append(badge(SYS.tg.label(String(e.tg)) + " in Cina ›", "Lista ufficiale cinese", () => go("tg", String(e.tg))));
  if (e.koe) lv.append(badge("hanja scolastico ›", "Gli hanja delle scuole coreane", () => go("koe", "1")));
  info.append(lv);
  box.append(top);
  const acts = mk("div", "acts");
  const kb = mk("button", known.has(sel) ? "known" : "", known.has(sel) ? "✓ lo conosco" : "lo conosco?");
  kb.type = "button";
  kb.addEventListener("click", async () => { await setKnown([sel], !known.has(sel)); render(); });
  acts.append(kb);
  const sv = mk("button", vocab[vid(sel)] ? "known" : "", vocab[vid(sel)] ? "★ salvato" : "☆ salva nel vocabolario"); sv.type = "button";
  sv.title = vocab[vid(sel)] ? "Togli dal vocabolario" : "Salva questo carattere nel vocabolario (significato, letture, livelli)";
  sv.addEventListener("click", async () => { sv.textContent = "…"; await toggleSave(sel); render(); });
  acts.append(sv);
  const lc = llmCache[sel];
  if (!lc) {
    const xb = mk("button", null, "✨ Spiega con il modello"); xb.type = "button";
    xb.title = "Una richiesta al modello: significati, letture, parole comuni, come è fatto, un aiuto per ricordarlo, origine del segno. Resta salvata";
    pageEngine().then((en) => { if (en) xb.textContent = "✨ Spiega con " + en.name + " · " + en.model; else xb.title = "Serve la chiave di un modello (popup → 🔑 Servizi)"; });
    const c0 = sel;
    xb.addEventListener("click", () => explainChar(c0));
    acts.append(xb);
  }
  const ob = mk("button", null, "✍ ordine dei tratti"); ob.type = "button";
  ob.addEventListener("click", () => strokeOrder(sel, box, ob));
  acts.append(ob);
  const q = encodeURIComponent(sel);
  for (const [t, u] of [["Jisho", "https://jisho.org/search/" + q + "%20%23kanji"], ["MDBG", "https://www.mdbg.net/chinese/dictionary?page=chardict&cdqchi=" + q], ["Wiktionary", "https://en.wiktionary.org/wiki/" + q]]) {
    const a = mk("a", null, t); a.href = u; a.target = "_blank"; a.rel = "noopener noreferrer"; acts.append(a);
  }
  box.append(acts);
  if (lc && lc.wait) box.append(mk("div", "llm", "Chiedo al modello…"));
  else if (lc && lc.error) box.append(mk("div", "llm", "Spiegazione non disponibile: " + lc.error));
  else if (lc) {
    const x = mk("div", "llm");
    const ln = (label, text) => { if (!text) return; const d = mk("div", "line"); d.append(mk("b", null, label + ": "), document.createTextNode(text)); x.append(d); };
    ln("Significato", lc.meaning); ln("Letture", lc.readings);
    if (lc.words && lc.words.length) ln("Parole comuni", lc.words.map((w) => w.w + (w.r ? " (" + w.r + ")" : "") + (w.t ? " " + w.t : "")).join(" · "));
    ln("Come è fatto", lc.parts); ln("Per ricordarlo", lc.mnemonic); ln("Origine", lc.origin); ln("Attenzione", lc.note);
    x.append(mk("div", "src", "Fonte: " + lc.source));
    box.append(x);
  }
}
// animazione dell'ordine dei tratti da Wikimedia Commons (c'è per molti caratteri comuni)
async function strokeOrder(c, box, btn) {
  btn.textContent = "…";
  for (const name of [c + "-order.gif", c + "-red.png", c + "-bw.png"]) {
    const r = await DS_EXT.runtime.sendMessage({ type: "fetchB64", url: "https://commons.wikimedia.org/wiki/Special:FilePath/" + encodeURIComponent(name) }).catch(() => null);
    if (r && r.b64) {
      const img = document.createElement("img");
      img.className = "order"; img.alt = "Ordine dei tratti di " + c;
      img.src = "data:" + (/\.gif$/.test(name) ? "image/gif" : "image/png") + ";base64," + r.b64;
      box.append(img); btn.remove(); return;
    }
  }
  btn.textContent = "ordine dei tratti non disponibile";
}

$("q").addEventListener("input", () => { clearTimeout(render.t); render.t = setTimeout(render, 200); });
$("show").addEventListener("change", () => { try { localStorage.setItem("kanjiShow", $("show").value); } catch {} render(); });
try { const v = localStorage.getItem("kanjiShow"); if (v) $("show").value = v; } catch {}
$("allKnown").addEventListener("click", async () => {
  const list = chars().map(([c]) => c);
  if (!list.length || !confirm(`Segno come conosciuti ${list.length} caratteri?`)) return;
  await setKnown(list, true); render();
});
DS_EXT.storage.onChanged.addListener((ch, area) => {
  if (area === "local" && ch.knownWords) { known = new Set(String((ch.knownWords.newValue || {})[lang] || "").split("\n").filter(Boolean)); render(); }
  if (area === "local" && ch.vocab) { vocab = ch.vocab.newValue || {}; render(); }
});
(async () => {
  D = await (await fetch(DS_EXT.runtime.getURL("han-data.json"))).json();
  await loadKnown();
  await loadVocab();
  // spiegazioni già chieste (hanExplain le salva): si vedono subito
  try { const h = (await DS_EXT.storage.local.get({ hanLlm: {} })).hanLlm || {}; for (const [k, v] of Object.entries(h)) { const [l2, c2, t2] = k.split("|"); if (l2 === lang && t2 === target && !llmCache[c2]) llmCache[c2] = v; } } catch {}
  if (me && D.c[me] && !level) level = SYS[sys].of(D.c[me]);
  render();
})();

# 1.6.3: «🔁 Rifai solo la traduzione»: la traduzione si cancella e si rifà, il testo dei sottotitoli resta; la scheda col pulsante nel popup
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false, learnNgram:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=redoTr1"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/GEM\\[/.test((document.querySelector('.dualsub-trans')||{}).textContent||'')", timeout=40000)
        g0 = len(log["gcalls"])
        tab = await sw.evaluate("chrome.tabs.query({}).then(t=>t.find(x=>/redoTr1/.test(x.url)).id)")
        st = await sw.evaluate(f"chrome.tabs.sendMessage({tab}, {{type:'liveState'}}).then(r=>JSON.stringify({{hasTrack:r.hasTrack, cues:r.cues}}))")
        print("1. stato per il popup:", st)
        await sw.evaluate(f"chrome.tabs.sendMessage({tab}, {{type:'redo', what:'translation'}})")
        await pg.wait_for_timeout(9000)
        g1 = len(log["gcalls"])
        print("2. richieste a Gemini prima/dopo:", g0, g1, "| riga originale ancora:", (await pg.evaluate("document.querySelector('.dualsub-orig').textContent"))[:40], "| traduzione:", (await pg.evaluate("document.querySelector('.dualsub-trans').textContent"))[:30])
        print("   stato:", (await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)"))[:100])
        ok = '"hasTrack":true' in st and g1 > g0
        print("errori:", errs if ok else errs + ["rifai solo la traduzione non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

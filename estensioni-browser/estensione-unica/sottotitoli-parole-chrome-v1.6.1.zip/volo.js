// Parole al Volo — sulla pagina: passando il mouse su una parola compare la sua scheda (significato, pronuncia,
// IPA, trascrizione, frase tradotta, vocabolario, Anki); selezionando un pezzo di testo lo traduce tutto insieme.
// Usa: DS_CONFIG, DS_EXT, dsServiceLinks (config.js), DS_TTS (tts.js), PAV_* (volo-config.js).
(() => {
  if (window.__paroleAlVolo) return;
  window.__paroleAlVolo = true;

  let S = { ...PAV_DEFAULTS };
  let keys = {};
  let vocab = {};
  let idiomStore = {};   // modi di dire trovati: "parole normalizzate" → { text, meaning, lang, at } (sottolineati sulle pagine)
  let idiomSeen = {};    // frasi già controllate dal modello (per non chiedere due volte)
  let idiomFlags = {};   // modi di dire segnalati da te: "parole normalizzate" → { bad } | { meaning } (come in Sottotitoli Doppi)
  let fixes = {};   // traduzioni corrette a mano: "w|lingua|arrivo|parola" o "t|lingua|arrivo|testo" → testo
  const ipaCache = new Map();
  let ready = false;

  async function load() {
    S = await PAV_SYNC.get(PAV_DEFAULTS);
    const l = await DS_EXT.storage.local.get({ keys: {}, vocab: {}, ipaCache: {}, pavFix: {}, idiomFlags: {}, pavIdioms: {}, pavIdiomSeen: {} });
    fixes = l.pavFix || {};
    idiomFlags = l.idiomFlags || {};
    idiomStore = l.pavIdioms || {};
    idiomSeen = l.pavIdiomSeen || {};
    keys = l.keys || {};
    vocab = l.vocab || {};
    // 1.10: prima a volte si salvava la pronuncia di un'altra forma della parola: ricomincio da capo, una volta
    const iv = (await DS_EXT.storage.local.get({ ipaCacheV: 0 })).ipaCacheV;
    if (iv !== 2) DS_EXT.storage.local.set({ ipaCache: {}, ipaCacheV: 2 }).catch(() => {});
    else for (const [k, v] of Object.entries(l.ipaCache || {})) ipaCache.set(k, v);
    ready = true;
  }
  load().catch(() => {});
  PAV_ONCHANGED.addListener((ch, area) => {
    if (area === "sync") for (const k of Object.keys(ch)) if (k in PAV_DEFAULTS) S[k] = ch[k].newValue === undefined ? PAV_DEFAULTS[k] : ch[k].newValue;
    if (area === "sync" && Object.keys(ch).some((k) => k.startsWith("card")) && root && typeof dsCardVars === "function") { dsCardVars(root, S); replaceSoon(); }
    if (area === "local" && ch.keys) keys = ch.keys.newValue || {};
    if (area === "local" && ch.pavFix) fixes = ch.pavFix.newValue || {};
    if (area === "local" && ch.idiomFlags) { idiomFlags = ch.idiomFlags.newValue || {}; knownPageSoon(300); }
    if (area === "local" && ch.pavIdioms) { idiomStore = ch.pavIdioms.newValue || {}; knownPageSoon(300); }
    if (area === "local" && ch.vocab) { vocab = ch.vocab.newValue || {}; refreshStars(); }
    if (area === "sync" && (ch.on || ch.disabledSites || ch.mode) && !active()) closeAll();
    if (area === "sync" && ch.hover && !hoverOn() && card && card.kind === "word") closeAll();
    if (area === "sync" && (ch.siteLang || ch.sourceLang || ch.targetLang)) sameLangBlocks = new WeakSet();   // lingua cambiata: ricontrollo
    if (area === "sync" && ch.selection && S.selection === false && card && card.kind === "text") closeAll();
    // cambio fatto con la tastiera o dal popup: un avviso breve sulla pagina, così sai cosa è successo
    if (area === "sync" && window === window.top && document.visibilityState === "visible") {
      if (ch.hover) toast(ch.hover.newValue === false ? "Parole al Volo: scheda passando il mouse SPENTA" : "Parole al Volo: scheda passando il mouse accesa");
      if (ch.selection) toast(ch.selection.newValue === false ? "Parole al Volo: traduzione quando evidenzi SPENTA" : "Parole al Volo: traduzione quando evidenzi accesa");
      if (ch.on) toast(ch.on.newValue === false ? "Parole al Volo: spenta" : "Parole al Volo: accesa");
    }
  });

  const host = location.hostname;
  // lingua del testo scelta a mano: per questo sito, altrimenti per tutti i siti, altrimenti riconosciuta da sola
  const forcedLang = () => ((S.siteLang || {})[host]) || S.sourceLang || "";
  const siteOff = () => (S.disabledSites || []).includes(host);
  const active = () => ready && S.on !== false && !siteOff();
  const hoverOn = () => S.hover !== false && S.mode !== "off";
  let toastEl = null, toastTimer = 0;
  function toast(text) {
    if (!toastEl || !toastEl.isConnected) {
      toastEl = document.createElement("div");
      toastEl.className = "pav-toast";
      toastEl.setAttribute("translate", "no");
      (document.body || document.documentElement).append(toastEl);
    }
    toastEl.textContent = text;
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { if (toastEl) toastEl.hidden = true; }, 2200);
  }

  // ---------- Elementi della pagina da non toccare ----------
  const SKIP = "input, textarea, select, option, button, [contenteditable=''], [contenteditable='true'], script, style, noscript, " +
    "svg, canvas, video, audio, code, pre, .dualsub-overlay, .dualsub-card, .dualsub-align-tip, .pav-root";
  const skipNode = (n) => { const e = n && (n.nodeType === 1 ? n : n.parentElement); return !e || !!e.closest(SKIP) || e.isContentEditable; };

  const segCache = new Map();
  function segmenter(gran, lang) {
    const k = gran + "|" + (lang || "");
    if (!segCache.has(k)) { try { segCache.set(k, new Intl.Segmenter(lang || undefined, { granularity: gran })); } catch { segCache.set(k, new Intl.Segmenter(undefined, { granularity: gran })); } }
    return segCache.get(k);
  }
  const langHint = (n) => { const e = n && (n.nodeType === 1 ? n : n.parentElement); const l = e && e.closest("[lang]"); return l ? pavBase(l.getAttribute("lang")) : ""; };
  const nonLatin = (s) => /[^\p{Script=Latin}\p{Script=Common}\p{Script=Inherited}\s]/u.test(s);

  function caretAt(x, y) {
    try {
      if (document.caretPositionFromPoint) { const p = document.caretPositionFromPoint(x, y); if (p && p.offsetNode) return { node: p.offsetNode, offset: p.offset }; }
      if (document.caretRangeFromPoint) { const r = document.caretRangeFromPoint(x, y); if (r) return { node: r.startContainer, offset: r.startOffset }; }
    } catch {}
    return null;
  }
  function rangeHas(r, x, y, pad = 2) {
    for (const b of r.getClientRects()) if (x >= b.left - pad && x <= b.right + pad && y >= b.top - pad && y <= b.bottom + pad) return true;
    return false;
  }

  // Il primo pezzo di testo con lettere dentro una selezione (la selezione può partire da un elemento,
  // per esempio con il triplo clic o selezionando una cella di tabella)
  function firstTextIn(range) {
    const sc = range.startContainer;
    if (sc.nodeType === 3 && /\p{L}/u.test(sc.data.slice(range.startOffset))) return { node: sc, offset: range.startOffset };
    const rootN = range.commonAncestorContainer.nodeType === 3 ? range.commonAncestorContainer.parentNode : range.commonAncestorContainer;
    const tw = document.createTreeWalker(rootN, NodeFilter.SHOW_TEXT);
    for (let n = tw.nextNode(); n; n = tw.nextNode()) {
      if (!range.intersectsNode(n)) continue;
      const from = n === sc ? range.startOffset : 0;
      const i = n.data.slice(from).search(/\p{L}/u);
      if (i >= 0) return { node: n, offset: from + i };
    }
    return null;
  }

  // Una parola può essere spezzata dai tag della pagina (accento colorato: Дореф<span>о́</span>рменная,
  // corsivo su una parte…): unisco i pezzi vicini senza spazi, ma solo dentro la stessa riga di testo
  const WORDCH = /^[\p{L}\p{M}\u00AD\u200B-\u200D\u2060]+/u, WORDCH_END = /[\p{L}\p{M}\u00AD\u200B-\u200D\u2060]+$/u;
  function inlineNeighbor(node, dir) {
    const block = blockOf(node);
    if (!block) return null;
    const tw = document.createTreeWalker(block, NodeFilter.SHOW_TEXT);
    tw.currentNode = node;
    const nx = dir > 0 ? tw.nextNode() : tw.previousNode();
    if (!nx || !nx.data || skipNode(nx) || blockOf(nx) !== block) return null;
    const r = document.createRange();
    try { if (dir > 0) { r.setStart(node, node.data.length); r.setEnd(nx, 0); } else { r.setStart(nx, nx.data.length); r.setEnd(node, 0); } } catch { return null; }
    const between = r.cloneContents();
    if (between.textContent || (between.querySelector && between.querySelector("br, img, hr, td, th, li, p, div, tr, input, button"))) return null;
    return nx;
  }
  function growWord(hit) {
    let { node, start, end } = hit, word = node.data.slice(start, end);
    let sNode = node, sOff = start, eNode = node, eOff = end;
    for (let k = 0; k < 4 && eOff === eNode.data.length; k++) {
      const nx = inlineNeighbor(eNode, 1); const m = nx && nx.data.match(WORDCH);
      if (!m) break;
      word += m[0]; eNode = nx; eOff = m[0].length;
    }
    for (let k = 0; k < 4 && sOff === 0; k++) {
      const pv = inlineNeighbor(sNode, -1); const m = pv && pv.data.match(WORDCH_END);
      if (!m) break;
      word = m[0] + word; sNode = pv; sOff = pv.data.length - m[0].length;
    }
    if (sNode === node && eNode === node) return hit;
    const r = document.createRange();
    r.setStart(sNode, sOff); r.setEnd(eNode, eOff);
    return { ...hit, node: sNode, start: sOff, word: dsCleanWord(word), range: r };
  }

  // La parola sotto il mouse (anche cinese e giapponese, grazie a Intl.Segmenter)
  function wordAt(x, y) {
    const c = caretAt(x, y);
    if (!c || !c.node || c.node.nodeType !== 3 || skipNode(c.node)) return null;
    const node = c.node, text = node.data;
    if (!text || !text.trim()) return null;
    const from = Math.max(0, c.offset - 80), to = Math.min(text.length, c.offset + 80);
    const lang = langHint(node);
    for (const sg of segmenter("word", lang).segment(text.slice(from, to))) {
      if (!dsIsWord(sg)) continue;
      const s = from + sg.index, e = s + sg.segment.length;
      if (c.offset < s - 1 || c.offset > e + 1) continue;
      const r = document.createRange();
      r.setStart(node, s); r.setEnd(node, e);
      if (!rangeHas(r, x, y)) continue;
      if (!/\p{L}/u.test(sg.segment)) return null;   // numeri, simboli
      return growWord({ node, start: s, end: e, word: dsCleanWord(sg.segment), range: r, lang });
    }
    return null;
  }

  // La frase che contiene un punto del testo (dentro il blocco: paragrafo, voce di elenco, cella…)
  function blockOf(node) {
    let e = node.parentElement;
    for (let i = 0; e && i < 8; i++, e = e.parentElement) {
      const d = getComputedStyle(e).display;
      if (/block|list-item|table-cell|flex|grid/.test(d) && e.textContent.trim().length > 0) return e;
    }
    return node.parentElement;
  }
  function sentenceAt(node, offset, lang) {
    const block = blockOf(node);
    if (!block) return node.data.trim();
    let pos = 0, found = -1, text = "";
    const tw = document.createTreeWalker(block, NodeFilter.SHOW_TEXT);
    for (let n = tw.nextNode(); n; n = tw.nextNode()) {
      if (n === node) found = pos + offset;
      text += n.data; pos += n.data.length;
      if (pos > 20000 && found >= 0) break;
    }
    if (found < 0) return node.data.trim();
    const a = Math.max(0, found - 600), win = text.slice(a, found + 600);
    for (const sg of segmenter("sentence", lang).segment(win)) {
      if (a + sg.index <= found && found < a + sg.index + sg.segment.length) return sg.segment.replace(/\s+/g, " ").trim().slice(0, 500);
    }
    return win.replace(/\s+/g, " ").trim().slice(0, 500);
  }

  // ---------- Parola evidenziata (CSS Custom Highlight, se il browser la conosce) ----------
  function highlight(range) {
    try {
      if (!window.CSS || !CSS.highlights) return;
      if (range) CSS.highlights.set("pav-word", new Highlight(range)); else CSS.highlights.delete("pav-word");
    } catch {}
  }

  // ---------- Interfaccia: un solo contenitore, stili in volo.css con nomi "pav-" ----------
  let root = null;
  function ensureRoot() {
    if (root && root.isConnected) return root;
    root = document.createElement("div");
    root.className = "pav-root";
    root.setAttribute("translate", "no");
    for (const t of ["mousedown", "mouseup", "click", "dblclick", "pointerdown", "pointerup", "keydown", "keyup", "wheel"]) root.addEventListener(t, (e) => e.stopPropagation());
    root.addEventListener("mouseenter", () => { clearTimeout(hideTimer); if (card && card.kind === "word") card.pinned = true; });
    root.addEventListener("mouseleave", () => { if (card && card.kind === "word" && !card.sticky) scheduleHide(500); });
    (document.body || document.documentElement).append(root);
    if (typeof DS_UI !== "undefined") DS_UI.watch(root);   // interfaccia nella lingua di «Traduci in», se scelta
    if (typeof dsCardVars === "function") dsCardVars(root, S);   // aspetto delle schede scelto nel popup
    return root;
  }
  const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
  function button(label, title, fn, cls = "pav-btn") {
    const b = el("button", cls, label);
    b.type = "button";
    if (title) b.title = title;
    b.addEventListener("click", (e) => { e.preventDefault(); if (card) card.sticky = true; fn(b, e); });
    return b;
  }

  let card = null;            // { kind: "word" | "text", box, key, data, pinned, sticky, ... }
  let hideTimer = 0, reqId = 0;

  function closeAll() {
    reqId++;
    clearTimeout(hideTimer);
    if (card && card.box) card.box.remove();
    card = null;
    highlight(null);
  }
  function scheduleHide(ms = 350) {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { if (card && !card.sticky) closeAll(); }, ms);
  }

  // Posizione: sotto la parola (o sopra se non c'è spazio), dentro la finestra
  // rect = posizione della parola sullo schermo quando la scheda si è aperta. Ricordo anche lo scorrimento di quel
  // momento: la scheda resta attaccata alla parola nella pagina. Prima, a ogni aggiornamento (per esempio le foto
  // che arrivano) si usava lo scorrimento di adesso: scorrendo la pagina la scheda scendeva sempre più giù.
  // La scheda cresce dopo l'apertura (spiegazione del modello, albero etimologico, immagini): prima restava con l'alto
  // fermo sotto la parola e, a schermo intero (un PDF di Google Libri), finiva sotto il bordo dello schermo senza modo di
  // vederne la fine. Ora l'altezza massima è lo spazio visibile, e se non c'entra né sotto né sopra la parola la scheda
  // sale quanto serve (anche coprendo la parola): la fine resta sempre raggiungibile scorrendo dentro la scheda.
  function place(box, rect) {
    if (rect.pavSy == null) { rect.pavSx = window.scrollX; rect.pavSy = window.scrollY; }
    const vw = document.documentElement.clientWidth, vh = window.innerHeight;
    // posizione scelta nel popup (🗒 Aspetto delle schede): sempre sul lato destro o sinistro della finestra, in alto
    if (S.cardPosPage === "right" || S.cardPosPage === "left") {
      const mh = Math.max(120, vh - 16) + "px";
      if (box.style.maxHeight !== mh) box.style.maxHeight = mh;
      const w = box.offsetWidth || 340;
      box.style.left = Math.round((S.cardPosPage === "right" ? vw - w - 8 : 8) + rect.pavSx) + "px";
      box.style.top = Math.round(8 + rect.pavSy) + "px";
      box.pavRect = rect;
      if (cardResize && !box.pavObserved) { box.pavObserved = true; cardResize.observe(box); }
      return;
    }
    // altezza massima: lo spazio sotto la parola, o sopra se è di più; solo se tutti e due sono troppo piccoli la scheda
    // copre la parola (prima: sempre 70% dello schermo, anche quando sotto la parola ce n'era molto meno)
    const cap = Math.max(120, Math.min(Math.round(vh * 0.7), vh - 16));
    const below = vh - 16 - rect.bottom - 8, above = rect.top - 16 - 8;
    const nat = (box.scrollHeight || 180) + 2;
    let maxH, top;
    if (nat <= below || (below >= above && below >= 260)) { maxH = Math.min(cap, below); top = rect.bottom + 8; }
    else if (above >= 260 || nat <= above) { maxH = Math.min(cap, above); top = rect.top - 8 - Math.min(nat, maxH); }
    else { maxH = cap; top = vh - 8 - Math.min(nat, cap); }
    maxH = Math.max(120, Math.round(maxH));
    if (box.style.maxHeight !== maxH + "px") box.style.maxHeight = maxH + "px";
    const w = box.offsetWidth || 340, h = Math.min(nat, maxH);
    const left = Math.min(Math.max(8, rect.left + rect.width / 2 - w / 2), vw - w - 8);
    // (posizioni sullo schermo del momento dell'apertura: la scheda resta attaccata alla parola se scorri la pagina)
    top = Math.max(8, top);
    // se adesso il fondo uscirebbe dallo schermo (la scheda è cresciuta), la alzo quanto basta
    const dy = window.scrollY - rect.pavSy;
    if (top - dy + h > vh - 8) top = Math.max(dy + 8, dy + vh - 8 - h);
    box.style.left = Math.round(left + rect.pavSx) + "px";
    box.style.top = Math.round(top + rect.pavSy) + "px";
    box.pavRect = rect;
    if (cardResize && !box.pavObserved) { box.pavObserved = true; cardResize.observe(box); }
  }
  const replace = () => { if (card && card.box && card.box.isConnected && card.box.pavRect) place(card.box, card.box.pavRect); };
  let replaceRaf = 0;
  const replaceSoon = () => { cancelAnimationFrame(replaceRaf); replaceRaf = requestAnimationFrame(replace); };
  const cardResize = typeof ResizeObserver === "function" ? new ResizeObserver(replaceSoon) : null;
  window.addEventListener("resize", replaceSoon);
  document.addEventListener("fullscreenchange", () => setTimeout(replace, 200));

  // ---------- Servizi ----------
  // le richieste ai modelli possono durare minuti (soprattutto sul computer): passano dalla porta che tiene sveglio il background
  const send = (m) => (m && m.engine && m.engine !== "google" && /^(define|idiomsFind|etymLlm|translate|align)$/.test(m.type) ? dsSendLong(m) : DS_EXT.runtime.sendMessage(m))
    .catch((e) => ({ error: String(e.message || e) }));
  // (1.6.1: con il primo modello non finito oggi; exhausted = finiti tutti i modelli di quel servizio)
  function engineOf(id, task = "explainEngine") {
    const E = DS_CONFIG.ENGINES[id];
    if (!E) return null;
    return dsTaskModel(S, task, { id, E, key: keys[id] || "", model: (S.models || {})[id] || E.defaultModel || "", localUrl: S.localUrl }, modelBlocked);
  }
  const isLlm = (e) => !!e && (e.E.kind === "openai" || e.E.kind === "claude") && (!e.E.needsKey || !!e.key) && !!e.model && !e.exhausted;
  // Servizi che hanno finito le richieste gratuite di oggi (si azzerano a mezzanotte di Los Angeles): si salta al
  // primo di riserva con la chiave, e la scheda lo dice (con "Riprova …")
  let dsBlocked = {};
  const pacificDay = () => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return new Date().toISOString().slice(0, 10); } };
  DS_EXT.storage.local.get({ dsBlocked: {} }).then((r) => { dsBlocked = r.dsBlocked || {}; }).catch(() => {});
  PAV_ONCHANGED.addListener((ch, area) => { if (area === "local" && ch.dsBlocked) dsBlocked = ch.dsBlocked.newValue || {}; });
  const blockedOn = (k) => { const b = dsBlocked[k]; return !!b && b.day === pacificDay(); };
  // 1.6.1: come nei video, i limiti di Gemini, Groq e Mistral sono per modello: si blocca solo il modello finito
  // (un blocco di tutto il servizio scritto dalle versioni prima vale solo per i servizi che non sono modelli)
  const llmSvc = (id) => { const E = DS_CONFIG.ENGINES[id]; return !!E && (E.kind === "openai" || E.kind === "claude") && !E.local; };
  function modelBlocked(id, m) { return (!llmSvc(id) && blockedOn(id)) || (!!m && blockedOn(id + "|" + m)); }
  const isBlocked = (id) => (!llmSvc(id) && blockedOn(id)) || (!!engineOf(id) && engineOf(id).exhausted);
  function markBlocked(id, model) {
    const E = DS_CONFIG.ENGINES[id];
    const k = model && E && (E.kind === "openai" || E.kind === "claude") && !E.local ? id + "|" + model : id;
    dsBlocked = { ...dsBlocked, [k]: { day: pacificDay(), at: Date.now() } }; DS_EXT.storage.local.set({ dsBlocked }).catch(() => {});
  }
  function unblock(id) { const m = { ...dsBlocked }; for (const k of Object.keys(m)) if (k === id || k.startsWith(id + "|")) delete m[k]; dsBlocked = m; DS_EXT.storage.local.set({ dsBlocked: m }).catch(() => {}); }
  // il modello per «✨ Spiega con…»: quello scelto se è un modello, altrimenti il primo pronto nell'ordine scelto nel
  // popup («Ordine dei servizi»); se ha finito le richieste di oggi, il successivo della fila
  let ownSkipUntil = 0;   // il modello scelto per le spiegazioni non ha risposto: per qualche minuto uso la fila
  // il modello preciso scelto per il compito («Modello per ogni compito», dsTaskModel in config.js)
  const explainEngine = () => { const x = explainEngine0(); return x ? dsTaskModel(S, "explainEngine", x, modelBlocked) : x; };
  const explainEngine0 = () => {
    // scelto nel popup «Spiegazioni con»: quello, se è pronto e ha ancora richieste oggi
    const own = S.explainEngine && Date.now() > ownSkipUntil ? engineOf(S.explainEngine) : null;
    if (isLlm(own) && !isBlocked(own.id)) return own;
    const e = engineOf(S.engine);
    if (isLlm(e) && !isBlocked(e.id)) return e;
    if (isLlm(e) && S.fallback === false) return null;
    for (const id of DS_CONFIG.engineOrder(S)) {
      if ((e && id === e.id) || isBlocked(id)) continue;
      const x = engineOf(id);
      if (isLlm(x)) return isLlm(e) ? { ...x, fallbackFrom: e.id } : x;
    }
    return null;
  };
  // DeepL o Microsoft scelti nel popup: traducono loro la frase e il testo selezionato
  const txEngine = () => { const e = engineOf(S.engine); return e && (e.E.kind === "deepl" || e.E.kind === "microsoft") && e.key ? { engine: e.id, key: e.key } : {}; };
  // la riga che spiega perché si usa un altro servizio, con "Riprova"
  function blockedNote(rerender) {
    const chosen = engineOf(S.engine);
    if (!chosen || !isLlm(chosen) || !isBlocked(chosen.id)) return null;
    const e = explainEngine();
    const row = el("div", "pav-note pav-blocked");
    row.append(document.createTextNode("⚠ " + engineName(chosen) + " ha finito le richieste gratuite di oggi" + (e ? ": uso " + engineName(e) + ". " : ". ")));
    row.append(button("Riprova " + engineName(chosen), "Se pensi che le richieste ci siano di nuovo, riprova subito", () => { unblock(chosen.id); rerender(); }, "pav-linkbtn"));
    return row;
  }
  // prima Gemini (molti token), poi Groq; un servizio che ha appena detto "limite raggiunto" si salta per un po'
  const ipaSkip = {};
  // il modello scelto per un compito nel popup («Modello per ogni compito»), se è pronto e ha richieste oggi
  const taskEngine = (key) => { const e = S[key] ? engineOf(S[key]) : null; return isLlm(e) && !isBlocked(e.id) ? dsTaskModel(S, key, e, modelBlocked) : null; };
  function ipaEngine() {
    const own = taskEngine("ipaEngine");
    if (own && own.E.kind === "openai" && !((ipaSkip[own.id] || 0) > Date.now())) return own;
    const order = [...new Set([...DS_CONFIG.engineOrder(S), S.engine])];
    for (const id of order) { const e = engineOf(id); if (e && e.E.kind === "openai" && !e.E.local && isLlm(e) && !((ipaSkip[id] || 0) > Date.now())) return dsTaskModel(S, "ipaEngine", e, modelBlocked); }
    return null;
  }
  const engineName = (e) => e.E.label.split(" (")[0].split(",")[0];

  // ---------- Pronuncia IPA: una volta per parola, salvata; nella scheda chiedo insieme le parole della frase ----------
  const ipaKey = (lang, w) => (pavBase(lang) || "auto") + "|" + String(w).toLowerCase();
  let ipaBusy = null, ipaSaveTimer = 0;
  function ipaSave() {
    clearTimeout(ipaSaveTimer);
    ipaSaveTimer = setTimeout(() => {
      while (ipaCache.size > 30000) ipaCache.delete(ipaCache.keys().next().value);
      DS_EXT.storage.local.set({ ipaCache: Object.fromEntries(ipaCache) }).catch(() => {});
    }, 1200);
  }
  const wordsIn = (text, lang) => [...segmenter("word", lang).segment(text || "")].filter((s) => dsIsWord(s) && /\p{L}/u.test(s.segment)).map((s) => s.segment);
  function ipaOf(text, lang) {
    // prima la parola intera così com'è (in giapponese e cinese, divisa da sola può venire spezzata in modo diverso
    // rispetto a dentro la frase, e i pezzi non sono tra quelli chiesti)
    const whole = ipaCache.get(ipaKey(lang, text));
    if (whole) return whole;
    const ws = wordsIn(text, lang);
    if (!ws.length) return "";
    const v = ws.map((w) => ipaCache.get(ipaKey(lang, w)));
    return v.every(Boolean) ? v.join(" ") : "";
  }
  async function ipaFetch(words, lang, sentence, force) {
    const e = ipaEngine();
    if (!e) return { error: "serve la chiave di Groq o Gemini (popup)" };
    // force: parole chieste da te con il pulsante, anche se l'altra volta il modello non le aveva date
    const want = [...new Set(words.filter((w) => !ipaCache.has(ipaKey(lang, w)) || ((force || []).includes(w) && !ipaCache.get(ipaKey(lang, w)))))].slice(0, 300);
    if (!want.length) return {};
    while (ipaBusy) await ipaBusy;
    let done;
    ipaBusy = new Promise((r) => (done = r));
    try {
      let r = await send({ type: "ipa", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, lang: pavBase(lang), words: want, sentence, priority: true });
      if (r && r.error && (r.daily || r.rateLimited || r.tooLarge || r.hourly)) {
        ipaSkip[e.id] = Date.now() + (r.daily ? 6 * 3600e3 : Math.max(120e3, (r.retryAfter || 0) * 1000));
        const o = ipaEngine();
        if (o && o.id !== e.id) r = await send({ type: "ipa", engine: o.id, key: o.key, model: o.model, localUrl: o.localUrl, lang: pavBase(lang), words: want, sentence, priority: true });
      }
      if (r && !r.error) {
        const got = r.ipa || {}, n = Object.keys(got).length;
        for (const w of want) {
          if (got[w]) ipaCache.set(ipaKey(lang, w), got[w]);
          else if (n >= want.length * 0.6) ipaCache.set(ipaKey(lang, w), "");
        }
        ipaSave();
      }
      return r || {};
    } finally { ipaBusy = null; done(); }
  }

  // ---------- Modi di dire (⚑): a volte il modello se li inventa o sbaglia il significato ----------
  const idiomKey = (t) => (String(t || "").toLowerCase().normalize("NFD").replace(/\p{M}/gu, "").match(/[\p{L}\p{N}']+/gu) || []).join(" ");
  const idiomBad = (t) => !!(idiomFlags[idiomKey(t)] || {}).bad;
  const idiomMeaning = (t, m) => (idiomFlags[idiomKey(t)] || {}).meaning || m || "";
  // un "modo di dire" lungo o che è quasi tutta la frase è un errore del modello: non lo mostro
  function idiomPlausible(expr, sentence) {
    const e = idiomKey(expr).split(" ").filter(Boolean), all = idiomKey(sentence).split(" ").filter(Boolean);
    if (e.length < 2 || e.length > 7) return false;
    if (all.length >= 3 && e.length >= Math.max(3, Math.ceil(all.length * 0.75))) return false;
    // ogni parola dell'espressione deve essere nella frase: mai un'espressione tradotta o in un'altra lingua
    const sk = " " + all.join(" ") + " ";
    if (!e.every((w) => sk.includes(w))) return false;
    return !idiomBad(expr);
  }
  async function idiomFlag(text, patch) {
    const k = idiomKey(text);
    if (!k) return;
    if (patch) idiomFlags[k] = { ...(idiomFlags[k] || {}), ...patch, at: Date.now() }; else delete idiomFlags[k];
    const ks = Object.keys(idiomFlags);
    for (const x of ks.slice(0, Math.max(0, ks.length - 2000))) delete idiomFlags[x];
    await DS_EXT.storage.local.set({ idiomFlags }).catch(() => {});
  }
  function idiomFixRow(c, text, meaning) {
    const row = el("div", "pav-fixrow");
    const fixed = (idiomFlags[idiomKey(text)] || {}).meaning;
    row.append(button(c.idiomFix ? "chiudi" : "⚑ modo di dire sbagliato?", "Non è un modo di dire, o il significato è sbagliato", () => { c.idiomFix = !c.idiomFix; c.idiomEdit = false; renderWord(); }, "pav-linkbtn"));
    if (fixed) row.append(el("span", "pav-muted", " · corretto da te"));
    if (!c.idiomFix) return row;
    const box = el("div", "pav-fixbox");
    box.append(button("Non è un modo di dire", "Non lo mostro più per questa espressione (resta salvato; si annulla dalla scheda di una sua parola: «🚫 … annulla»)", async () => { await idiomFlag(text, { bad: true, t: text, m: fixed || "", om: meaning || "" }); c.idiomFix = false; renderWord(); knownPageSoon(300); }, "pav-btn"));
    box.append(button("✎ Correggi il significato", "Scrivi tu il significato giusto: resta salvato", () => { c.idiomEdit = !c.idiomEdit; c.idiomTextEdit = false; renderWord(); }, "pav-btn"));
    box.append(button("✎ Correggi il modo di dire", "Il modo di dire è un altro (più lungo, più corto, altre parole): scrivilo tu, con il suo significato", () => { c.idiomTextEdit = !c.idiomTextEdit; c.idiomEdit = false; renderWord(); }, "pav-btn"));
    if (fixed) box.append(button("Togli la mia correzione", "", async () => { await idiomFlag(text, null); c.idiomFix = false; renderWord(); }, "pav-btn"));
    if (c.idiomEdit) {
      const t = el("textarea", "pav-fixinput");
      t.rows = 2; t.value = fixed || meaning || "";
      t.addEventListener("keydown", (ev) => ev.stopPropagation());
      box.append(t, button("Salva", "", async () => { await idiomFlag(text, { meaning: t.value.trim(), bad: false }); c.idiomEdit = false; c.idiomFix = false; renderWord(); }, "pav-btn"));
      setTimeout(() => t.focus(), 0);
    }
    // il modo di dire stesso è sbagliato: quello vecchio diventa «non è un modo di dire» (annullabile), quello scritto da
    // te un modo di dire di questa frase, con il suo significato
    if (c.idiomTextEdit) {
      const tx = el("input", "pav-fixinput"); tx.value = text; tx.placeholder = "Il modo di dire giusto (parole della frase)";
      const tm = el("textarea", "pav-fixinput"); tm.rows = 2; tm.value = fixed || meaning || ""; tm.placeholder = "Il suo significato";
      for (const x of [tx, tm]) x.addEventListener("keydown", (ev) => ev.stopPropagation());
      box.append(el("div", "pav-muted pav-small", "Il modo di dire giusto e il suo significato:"), tx, tm, button("Salva", "", async () => {
        const nt = tx.value.replace(/\s+/g, " ").trim(), nm = tm.value.trim();
        if (!nt) return;
        if (idiomKey(nt) !== idiomKey(text)) await idiomFlag(text, { bad: true, t: text, m: fixed || "", om: meaning || "", renamed: nt });
        await idiomFlag(nt, { bad: false, meaning: nm });
        await idiomAdd([{ text: nt, meaning: nm }], c.lang, c.sentence || nt);
        c.idiomTextEdit = false; c.idiomFix = false; renderWord(); knownPageSoon(300);
      }, "pav-btn"));
      setTimeout(() => tx.focus(), 0);
    }
    row.append(box);
    return row;
  }
  // modi di dire segnati come «non è un modo di dire» che contengono questa parola, in questa frase: si annulla da qui
  function idiomFlaggedRow(c) {
    if (!c.sentence || !c.word) return null;
    const sent = " " + idiomKey(c.sentence) + " ", w = idiomKey(c.word);
    const list = Object.entries(idiomFlags).filter(([k, f]) => f && f.bad && k.includes(" ") && (" " + k + " ").includes(" " + w + " ") &&
      k.split(" ").every((x) => sent.includes(" " + x + " ")));
    if (!list.length) return null;
    const box = el("div", "pav-flagged");
    for (const [k, f] of list) {
      const line = el("div", "pav-muted pav-small", `🚫 «${f.t || k}» segnato da te come «non è un modo di dire»${f.renamed ? ` (corretto in «${f.renamed}»)` : ""} `);
      line.append(button("annulla", "Torna a essere un modo di dire, sottolineato in arancione", async () => {
        delete idiomFlags[k];
        await idiomFlag(f.t || k, f.m ? { meaning: f.m } : null);
        await idiomAdd([{ text: f.t || k, meaning: f.m || f.om || "" }], c.lang, c.sentence);
        renderWord(); knownPageSoon(300);
      }, "pav-linkbtn"));
      box.append(line);
    }
    return box;
  }

  // ---------- Modi di dire trovati da soli: salvati, sottolineati in arancione su tutte le pagine (come nei sottotitoli) ----------
  async function idiomAdd(list, lang, sentence) {
    let n = 0;
    for (const it of list || []) {
      if (!it || !it.text || !idiomPlausible(it.text, sentence || "")) continue;
      const k = idiomKey(it.text);
      if (!idiomStore[k]) n++;
      idiomStore[k] = { text: it.text, meaning: it.meaning || (idiomStore[k] || {}).meaning || "", lang: pavBase(lang) || "", at: Date.now() };
    }
    if (!n) return;
    const ks = Object.keys(idiomStore);
    for (const x of ks.slice(0, Math.max(0, ks.length - 3000))) delete idiomStore[x];
    await DS_EXT.storage.local.set({ pavIdioms: idiomStore }).catch(() => {});
  }
  // dal dizionario dei modi di dire di Wiktionary (words.js, gratis): quello della frase che contiene questa parola
  function idiomFromDict(c) {
    if (typeof wordsDictFind !== "function" || !c.sentence) return null;
    const lang = pavBase(c.lang);
    wordsDictLoad(lang);
    if (wordsDict.lang !== lang) return null;
    if (wordsDict.whole.length) { const t = wordsDict.whole.find((x) => c.sentence.includes(x) && x.includes(c.word)); return t ? { text: t, meaning: "", dict: true } : null; }
    const raw = String(c.sentence).split(/[^\p{L}\p{N}']+/u).filter((x) => wordsNorm(x));
    const norm = raw.map(wordsNorm), w = wordsNorm(c.word);
    for (const f of wordsDictFind(norm)) if (norm.slice(f.from, f.to + 1).includes(w)) return { text: raw.slice(f.from, f.to + 1).join(" "), meaning: "", dict: f.title };
    return null;
  }
  // il modo di dire della frase che contiene questa parola (tra quelli trovati), se c'è
  function idiomFor(c) { const x = idiomFor0(c); return x || (S.idiomsUnderline === false ? null : idiomFromDict(c)); }
  function idiomFor0(c) {
    if (!c.sentence) return null;
    const sk = " " + idiomKey(c.sentence) + " ", wk = idiomKey(c.word);
    let best = null;
    for (const [k, it] of Object.entries(idiomStore)) {
      if (idiomBad(it.text) || !sk.includes(" " + k + " ") || !(" " + k + " ").includes(" " + wk + " ")) continue;
      if (!best || k.length > idiomKey(best.text).length) best = it;
    }
    return best;
  }
  // il modello cerca i modi di dire della frase (una richiesta piccola, solo se la scheda resta aperta; una volta per frase)
  function idiomAuto(c) {
    if (S.idiomAuto === false || !c.sentence || c.sentence === c.word || !explainEngine()) return;
    const words = wordsIn(c.sentence, c.lang);
    if (words.length < 3 || words.length > 60) return;
    const sk = idiomKey(c.sentence).slice(0, 300);
    if (idiomSeen[sk]) return;
    setTimeout(async () => {
      if (card !== c || idiomSeen[sk]) return;
      idiomSeen[sk] = Date.now();
      const e = taskEngine("alignEngine") || explainEngine();
      const r = await send({ type: "idiomsFind", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, sentence: c.sentence, lang: c.lang, target: S.targetLang });
      if (!r || r.error) { delete idiomSeen[sk]; if (r && r.llmDaily) markBlocked(e.id, e.model); return; }
      const ks = Object.keys(idiomSeen);
      for (const x of ks.slice(0, Math.max(0, ks.length - 4000))) delete idiomSeen[x];
      DS_EXT.storage.local.set({ pavIdiomSeen: idiomSeen }).catch(() => {});
      await idiomAdd(r.idioms, c.lang, c.sentence);
      if (card === c) renderWord();
    }, 1200);
  }

  // ---------- Traduzione sbagliata (⚑): rifarla con Google o con il modello, o correggerla a mano ----------
  // Le correzioni a mano restano salvate e valgono le volte successive per la stessa parola o lo stesso testo.
  const fixNorm = (t) => String(t || "").replace(/\s+/g, " ").trim().toLowerCase().slice(0, 400);
  const fixKey = (kind, lang, text) => [kind, pavBase(lang) || "?", S.targetLang, fixNorm(text)].join("|");
  async function fixSet(kind, lang, text, value) {
    const l = await DS_EXT.storage.local.get({ pavFix: {} });
    const m = l.pavFix || {};
    const k = fixKey(kind, lang, text);
    if (value && String(value).trim()) m[k] = String(value).trim(); else delete m[k];
    const ks = Object.keys(m);
    for (const x of ks.slice(0, Math.max(0, ks.length - 3000))) delete m[x];
    fixes = m;
    await DS_EXT.storage.local.set({ pavFix: m }).catch(() => {});
  }
  function fixApplyWord(c) {
    c.fixMeaning = fixes[fixKey("w", c.lang, c.word)] || "";
    const fs = fixes[fixKey("t", c.lang, c.sentence)];
    c.fixSent = !!fs;
    if (fs) c.sentTrans = fs;
  }
  function fixApplyText(c) {
    const ft = fixes[fixKey("t", c.lang, c.text)];
    c.fixText = !!ft;
    if (ft) { c.translation = ft; c.better = null; }
  }
  // rifà la traduzione con Google, senza usare quella già vista
  async function redoGoogle(c) {
    c.fixWait = "google";
    if (c.kind === "word") {
      renderWord();
      for (const k of [...wordCache.keys()]) if (k.startsWith(c.word.toLowerCase() + "|")) wordCache.delete(k);
      for (const k of [...sentCache.keys()]) if (k.startsWith(c.sentence + "|")) sentCache.delete(k);
      const lang = forcedLang() || c.lang;
      const [sent, data] = await Promise.all([
        send({ ...txEngine(), type: "pavText", text: c.sentence, target: S.targetLang, lang }),
        send({ type: "pavWord", word: c.word, target: S.targetLang, lang })]);
      if (card !== c) return;
      if (sent && !sent.error) c.sentTrans = sent.translation;
      if (data && !data.error) c.data = data;
      c.fixWait = ""; c.fixOpen = false; c.llm = null;
      fixApplyWord(c);
      renderWord();
    } else {
      c.wait = true; renderText();
      const r = await send({ ...txEngine(), type: "pavText", text: c.text, target: S.targetLang, lang: forcedLang() || c.lang });
      if (card !== c) return;
      c.wait = false; c.fixWait = ""; c.fixOpen = false; c.better = null;
      if (r && !r.error) Object.assign(c, { translation: r.translation, translit: nonLatin(c.text) ? r.translit : "" });
      fixApplyText(c);
      renderText();
    }
  }
  // con il modello: la parola si spiega nel contesto, e la frase si ritraduce nella stessa occasione
  async function redoModel(c) {
    const e = explainEngine();
    if (!e) return;
    if (c.kind === "text") { c.fixOpen = false; return better(); }
    // una sola richiesta: significato nel contesto e, insieme, la traduzione della frase
    c.fixWait = "model"; c.fixOpen = false; c.llm = null; renderWord();
    await explain();
    c.fixWait = "";
    if (card === c) renderWord();
  }
  function fixBox(c, rerender) {
    const wrap = el("div", "pav-fixrow");
    const fixed = c.kind === "word" ? (c.fixMeaning || c.fixSent) : c.fixText;
    wrap.append(button(c.fixOpen ? "chiudi" : "⚑ Traduzione sbagliata?", "Rifai la traduzione con Google o con il modello, oppure correggila a mano (resta salvata)", () => { c.fixOpen = !c.fixOpen; c.fixEdit = false; rerender(); }, "pav-linkbtn"));
    if (fixed) wrap.append(el("span", "pav-muted", " · corretta da te"));
    if (c.fixWait) wrap.append(el("span", "pav-muted", " …"));
    if (!c.fixOpen) return wrap;
    const box = el("div", "pav-fixbox");
    const e = explainEngine();
    box.append(button("↻ Rifai con Google", "Una nuova traduzione di Google (gratis)", () => redoGoogle(c), "pav-btn"));
    if (e) box.append(button(`Rifai con ${engineName(e)}`, c.kind === "word" ? "Significato nel contesto e traduzione della frase: una richiesta in più" : "Traduzione che tiene conto del contesto", () => redoModel(c), "pav-btn"));
    box.append(button("✎ Correggi a mano", "Scrivi tu la traduzione giusta: resta salvata per le prossime volte", () => { c.fixEdit = !c.fixEdit; rerender(); }, "pav-btn"));
    if (fixed) box.append(button("Togli la correzione", "", async () => {
      if (c.kind === "word") { await fixSet("w", c.lang, c.word, ""); await fixSet("t", c.lang, c.sentence, ""); c.fixMeaning = ""; c.fixSent = false; }
      else { await fixSet("t", c.lang, c.text, ""); c.fixText = false; }
      c.fixOpen = false; redoGoogle(c);
    }, "pav-btn"));
    box.append(button("Lingua sbagliata", "Se il testo non è nella lingua riconosciuta", () => { c.fixOpen = false; c.picker = true; rerender(); }, "pav-btn"));
    if (c.fixEdit) {
      const form = el("div", "pav-fixform");
      const fields = [];
      const field = (label, value, rows) => {
        const lab = el("label", "pav-fixlabel", label);
        const t = el("textarea", "pav-fixinput");
        t.rows = rows; t.value = value || "";
        t.addEventListener("keydown", (ev) => ev.stopPropagation());
        form.append(lab, t);
        fields.push(t);
        return t;
      };
      let fm, fsn, ft;
      if (c.kind === "word") {
        const d = c.llm || c.data || {};
        fm = field("Significato di «" + c.word + "»", c.fixMeaning || d.meaning, 2);
        if (c.sentence && c.sentence !== c.word) fsn = field("Traduzione della frase", c.sentTrans, 3);
      } else ft = field("Traduzione", c.better || c.translation, 5);
      form.append(button("Salva", "La correzione resta salvata", async () => {
        if (c.kind === "word") {
          await fixSet("w", c.lang, c.word, fm.value);
          if (fsn) await fixSet("t", c.lang, c.sentence, fsn.value);
          fixApplyWord(c);
        } else { await fixSet("t", c.lang, c.text, ft.value); fixApplyText(c); }
        c.fixEdit = false; c.fixOpen = false;
        if (card === c) rerender();
      }, "pav-btn pav-main"));
      box.append(form);
      setTimeout(() => { if (fields[0]) fields[0].focus(); }, 0);
    }
    wrap.append(box);
    return wrap;
  }

  // ---------- Vocabolario e Anki ----------
  function saved(entry) { return !!vocab[pavVocabId(entry)]; }
  // immagine per la carta (solo se accesa nel popup): una ricerca su Wikimedia Commons, una volta per scheda
  // quella scelta nella scheda (‹ › sotto "Immagine per Anki"), altrimenti la prima trovata
  async function withImage(entry) {
    if (!S.ankiImage || entry.kind !== "word" || typeof DS_LEARN === "undefined") return entry;
    const c = card;
    const mine = c && c.kind === "word" && c.word === entry.word;
    const ch = mine && c.learn ? DS_LEARN.chosenImage(c.learn.img) : undefined;
    if (ch === undefined && entry.image) return entry;
    const img = ch !== undefined ? ch : await DS_LEARN.image(entry.lemma || entry.word, entry.lang);
    if (mine) c.image = img;
    return { ...entry, image: img };
  }
  // immagine cambiata nella scheda: se la parola è già nel vocabolario, la aggiorno anche lì
  async function updateSavedImage(c, url) {
    c.image = url;
    if (!c.entry) return;
    const l = await DS_EXT.storage.local.get({ vocab: {} });
    const id = pavVocabId(c.entry());
    if (l.vocab[id]) { l.vocab[id].image = url; await DS_EXT.storage.local.set({ vocab: l.vocab }); }
  }
  async function toggleSave(entry) {
    if (!saved(entry)) entry = await withImage(entry);
    const l = await DS_EXT.storage.local.get({ vocab: {} });
    const v = l.vocab || {};
    const id = pavVocabId(entry);
    if (v[id]) delete v[id]; else v[id] = { ...entry, id, added: Date.now(), status: "learning" };
    vocab = v;
    await DS_EXT.storage.local.set({ vocab: v });
    if (v[id] && S.ankiAuto) sendAnki(entry, null);
    refreshStars();
  }
  async function sendAnki(entry, btn) {
    if (btn) { btn.disabled = true; btn.textContent = "…"; }
    entry = await withImage(entry);
    const r = await send({ type: "pavAnki", entries: [entry], deck: S.ankiDeck, model: S.ankiModel });
    if (btn) {
      btn.disabled = false;
      btn.textContent = r && !r.error ? (r.dup ? "✓ già in Anki" : "✓ in Anki") : "Anki";
      btn.title = r && r.error ? r.error : `Aggiunta al mazzo "${(r && r.deck) || S.ankiDeck}"`;
      if (r && !r.error && r.deck) showNote((r.dup ? "Era già in Anki" : "Aggiunta ad Anki") + ", mazzo «" + r.deck + "»" + (r.imgNote ? " (" + r.imgNote + ")" : "") + ".");
    } else if (r && !r.error && r.imgNote) showNote("Aggiunta ad Anki " + r.imgNote + ".");
    if (r && !r.error) {
      const l = await DS_EXT.storage.local.get({ vocab: {} });
      const id = pavVocabId(entry);
      if (l.vocab[id]) { l.vocab[id].anki = 1; await DS_EXT.storage.local.set({ vocab: l.vocab }); }
    } else if (r && r.error) showNote(r.error);
    return r;
  }
  function refreshStars() {
    if (!card || !card.box) return;
    const star = card.box.querySelector(".pav-star");
    if (!star || !card.entry) return;
    const on = saved(card.entry());
    star.textContent = on ? "★" : "☆";
    star.classList.toggle("pav-on", on);
    star.title = on ? "Togli dal vocabolario" : "Salva nel vocabolario";
  }
  function showNote(text) {
    if (!card || !card.box) return;
    let n = card.box.querySelector(".pav-note");
    if (!n) { n = el("div", "pav-note"); card.box.append(n); }
    n.textContent = text;
  }

  // la parola della scheda: registrazione vera se c'è (fetch: la cerca subito su Wiktionary), altrimenti voce sintetica
  async function speakWord(c, btn, fetch) {
    c.learn = c.learn || {};
    const tts = () => speak(c.word, c.lang, btn);
    if (typeof DS_LEARN === "undefined" || wordsIn(c.word, c.lang).length !== 1) return tts();
    if (!fetch && !DS_LEARN.recordingOf(c.learn, c.word, S)) return tts();
    const had = !!DS_LEARN.recordingOf(c.learn, c.word, S);
    await DS_LEARN.playWord({ word: c.word, lang: c.lang, target: S.targetLang, lemma: c.llm && c.llm.lemma, st: c.learn, prefs: S, tts });
    if (card === c && had !== !!DS_LEARN.recordingOf(c.learn, c.word, S)) renderWord();
  }

  async function speak(text, lang, btn, rate) {
    try {
      const r = await DS_TTS.speak(text, lang, { lang: S.ttsLang, voice: S.ttsVoice, rate: rate || 0 });
      if (btn) btn.title = "Pronuncia: " + r.how;
    } catch {}
  }

  async function copy(text, btn) {
    try { await navigator.clipboard.writeText(text); }
    catch {
      const t = document.createElement("textarea"); t.value = text; t.style.cssText = "position:fixed;left:-9999px";
      document.documentElement.append(t); t.select(); try { document.execCommand("copy"); } catch {} t.remove();
    }
    if (btn) { const o = btn.textContent; btn.textContent = "✓ copiato"; setTimeout(() => { btn.textContent = o; }, 1200); }
  }

  function linksRow(text, from, isWord, lemma) {
    const row = el("div", "pav-links");
    row.append(el("span", "pav-muted", "Apri in: "));
    dsServiceLinks(text, from, S.targetLang, isWord, lemma).forEach((l, i) => {
      if (i) row.append(el("span", "pav-muted", " · "));
      const a = el("a", "pav-link", l.label);
      a.href = l.url; a.target = "_blank"; a.rel = "noopener noreferrer";
      if (l.title) a.title = l.title;
      if (l.copy) a.addEventListener("click", () => copy(text));
      row.append(a);
    });
    return row;
  }

  function switchRow(label, title, change) {
    const row = el("div", "pav-switch");
    row.append(button(label, title, () => { closeAll(); PAV_SYNC.set(change); }, "pav-linkbtn pav-off"));
    return row;
  }

  // ---------- Scheda della parola ----------
  const sentCache = new Map();       // frase → { translation, lang }
  const wordCache = new Map();       // parola|lingua|arrivo → dati di Google
  let sameLangBlocks = new WeakSet();

  async function openWord(hit, how) {
    const sentence = dsCleanWord(sentenceAt(hit.node, hit.start, hit.lang) || hit.word);
    const key = hit.word + "\u0001" + sentence;
    if (card && card.key === key) return;
    const block = blockOf(hit.node);
    if (how === "hover" && block && !forcedLang() && sameLangBlocks.has(block)) return;
    const my = ++reqId;
    // lingua della frase e sua traduzione (Google, gratis): serve anche a non disturbarti sui testi già nella tua lingua
    const forced = forcedLang();
    const hint = forced || (hit.lang && !pavSameLang(hit.lang, S.targetLang) ? hit.lang : "");
    let sent = sentCache.get(sentence + "|" + hint + "|" + S.targetLang);
    const sentP = sent ? Promise.resolve(sent) : send({ ...txEngine(), type: "pavText", text: sentence, target: S.targetLang, lang: hint });
    const wk = hit.word.toLowerCase() + "|" + hint + "|" + S.targetLang;
    const wordP = wordCache.has(wk) ? Promise.resolve(wordCache.get(wk)) : send({ type: "pavWord", word: hit.word, target: S.targetLang, lang: hint });
    sent = await sentP;
    if (my !== reqId) return;
    if (sent && !sent.error) sentCache.set(sentence + "|" + hint + "|" + S.targetLang, sent);
    const lang = forced || (sent && sent.detected) || hit.lang || "";
    if (!forced && pavSameLang(lang, S.targetLang) && how === "hover") {
      if (block) sameLangBlocks.add(block);
      return;
    }
    let data = await wordP;
    if (my !== reqId) return;
    if (data && !data.error) wordCache.set(wk, data);
    closeAll();
    reqId = my;
    highlight(hit.range);
    card = { kind: "word", key, word: hit.word, sentence, sentTrans: (sent && sent.translation) || "", lang: pavBase(lang || (data && data.lang)),
      data: data || { error: "nessuna risposta" }, rect: hit.range.getBoundingClientRect(), pinned: how !== "hover", sticky: how !== "hover", llm: null };
    fixApplyWord(card);
    // questa parola in questa frase è già stata spiegata da un modello (🗂): la mostro subito, senza richieste
    { const sv = typeof DS_EXPL !== "undefined" ? DS_EXPL.same(card.lang, card.word, card.sentence) : null; if (sv) card.llm = savedData(sv); }
    card.entry = () => {
      const d = card.llm || card.data || {};
      return { kind: "word", word: card.word, lemma: d.lemma || "", pos: d.pos || "", meaning: card.fixMeaning || d.meaning || "",
        explanation: d.explanation || (card.data && card.data.dict ? card.data.dict.map((x) => `${x.pos}: ${x.words.join(", ")}`).join(" · ") : ""),
        ipa: ipaOf(card.word, card.lang) || (card.llm && card.llm.ipa) || "", translit: (card.data && card.data.translit) || "",
        ...(typeof DS_LEARN !== "undefined" ? DS_LEARN.entryExtras(card.learn || {}, card.lang) : {}), image: card.image || "",
        lang: card.lang, sentence: card.sentence, sentenceTrans: card.sentTrans, url: location.href, title: document.title };
    };
    renderWord();
    if (S.autoSpeak) speakWord(card, null, false);
    autoIpa(card);
    idiomAuto(card);
  }

  // pronuncia IPA: prima Wiktionary (gratis, sempre, anche con la pronuncia del modello spenta), solo della parola
  // che guardi e solo se la scheda resta aperta almeno 0,8 secondi. Se lì non c'è, il modello la scrive soltanto
  // nella richiesta unica di "Spiega con…" (se l'opzione è accesa): nessuna richiesta a parte.
  async function autoIpa(c) {
    if (ipaOf(c.word, c.lang) || !canWiktIpa(c)) return;
    c.ipaWait = true; renderWord();
    await new Promise((r) => setTimeout(r, 800));
    if (card !== c) return;
    await wiktIpa(c);
    if (card === c) { c.ipaWait = false; renderWord(); }
  }

  // pronuncia IPA da Wiktionary (gratis, nessun token): prima di chiederla a Gemini o Groq
  const canWiktIpa = (c) => typeof DS_ETYM !== "undefined" && /^[a-z]{2,3}$/.test(c.lang || "") && wordsIn(c.word, c.lang).length === 1 && !c.wiktIpaTried;
  async function wiktIpa(c) {
    if (!canWiktIpa(c)) return false;
    c.wiktIpaTried = true;
    const r = await DS_ETYM.ipa(c.word, c.lang, S.targetLang);
    c.learn = c.learn || {};
    if (r.info && !c.learn.wikt) c.learn.wikt = r.info;
    if (!r.ipa) return false;
    ipaCache.set(ipaKey(c.lang, c.word), r.ipa); ipaSave();
    c.ipaSource = r.source || "Wiktionary";
    return true;
  }

  // ---------- Strumenti per imparare (learn.js): etimologia, frequenza, genere, audio di madrelingua, tabelle, esempi, scrittura ----------
  function learnBox(c) {
    c.learn = c.learn || {};
    // etimologia arrivata con la spiegazione del modello (solo se Wiktionary non l'aveva)
    if (c.llm && c.llm.etymology && (!c.learn.wikt || !c.learn.wikt.trans)) {
      const src = engineName(explainEngine() || {}) || "modello";
      c.learn.wikt = { ...(c.learn.wikt || {}), text: c.llm.etymology, trans: c.llm.etymology, source: src, none: false };
    }
    const e = explainEngine();
    return DS_LEARN.render({
      word: c.word, lemma: c.llm && c.llm.lemma, lang: c.lang, target: S.targetLang, sentence: c.sentence, prefs: S, llm: c.llm, st: c.learn,
      gdict: c.data && c.data.gdict,
      rerender: () => { if (card === c) renderWord(); },
      stale: () => card !== c,
      speak: (t, l) => speak(t, l || c.lang),
      etymHint: e && !c.llm ? `Premi "Spiega con ${engineName(e)}": la chiedo insieme alla spiegazione (una richiesta sola).` : "",
      onKnown: () => knownPageSoon(100),
      onImage: (url) => updateSavedImage(c, url),
      engine: () => { const x = explainEngine(); return x ? { ...x, name: engineName(x) } : null; },
      openWord: (ch, pre) => openChar(c, ch, pre),
      // kanji/caratteri della parola nel vocabolario, ognuno come voce a sé (toggle = uno solo: lo salva o lo toglie)
      isSaved: (l, ch) => !!vocab[pavVocabId({ lang: l, word: ch })],
      saveChars: async (entries, toggle) => {
        const l = await DS_EXT.storage.local.get({ vocab: {} });
        const v = l.vocab || {};
        const added = [];
        for (const e of entries) {
          const id = pavVocabId(e);
          if (v[id]) { if (toggle) delete v[id]; continue; }
          v[id] = { kind: "word", ...e, id, sentence: c.sentence, sentenceTrans: c.sentTrans, url: location.href, title: document.title, fromWord: c.word, added: Date.now(), status: "learning" };
          added.push(v[id]);
        }
        vocab = v;
        await DS_EXT.storage.local.set({ vocab: v });
        if (S.ankiAuto) for (const e of added) await sendAnki(e, null);
        refreshStars();
      }
    });
  }

  // un kanji o carattere cinese della parola nella sua scheda (Google e dizionari gratuiti, come una parola);
  // in alto il collegamento per tornare alla parola intera
  async function openChar(c, ch, pre) {
    const my = ++reqId;
    const wk = ch.toLowerCase() + "|" + (c.lang || "") + "|" + S.targetLang;
    const have = wordCache.get(wk);
    // la scheda si apre subito (con il significato già trovato nel riquadro del carattere); Google la completa dopo
    if (c.box) { c.box.remove(); c.box = null; }
    const k = { kind: "word", key: ch + "\u0001" + c.sentence, word: ch, sentence: c.sentence, sentTrans: c.sentTrans, lang: c.lang,
      data: have || { meaning: (pre && pre.meaning) || "…", pos: (pre && pre.pos) || "", source: "dizionario dei caratteri (arriva Google…)", lang: c.lang },
      rect: c.rect, pinned: true, sticky: true, llm: null, back: c, entry: c.entry };
    card = k;
    fixApplyWord(k);
    renderWord();
    autoIpa(k);
    if (have) return;
    const data = await send({ type: "pavWord", word: ch, target: S.targetLang, lang: c.lang });
    if (data && !data.error) wordCache.set(wk, data);
    if (my !== reqId || card !== k || !data || data.error) return;
    k.data = data;
    fixApplyWord(k);
    renderWord();
  }
  function backToWord() {
    const c = card;
    if (!c || !c.back) return;
    reqId++;
    if (c.box) c.box.remove();
    card = c.back;
    card.box = null;
    renderWord();
  }

  // ---------- Parole che conosci colorate sulla pagina (si accende nel popup) e percentuale per il popup ----------
  let knownTimer = 0;
  function pageLang() { return pavBase(forcedLang() || document.documentElement.lang || "") || "?"; }
  function pageWords(max, withRanges) {
    const out = [];
    if (!document.body) return out;
    const lang = pageLang();
    const seg = segmenter("word", lang === "?" ? "" : lang);
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode: (n) => {
      const p = n.parentElement;
      if (!p || !n.nodeValue.trim() || p.closest("script,style,noscript,textarea,input,select,code,pre,.pav-root,.dualsub-layer,.dualsub-overlay,.dualsub-card,[contenteditable='true']")) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    } });
    let n;
    while ((n = walker.nextNode()) && out.length < max) {
      for (const x of seg.segment(n.nodeValue)) {
        if (!dsIsWord(x)) continue;
        out.push(withRanges ? { w: dsCleanWord(x.segment), node: n, i: x.index, len: x.segment.length } : dsCleanWord(x.segment));
        if (out.length >= max) break;
      }
    }
    return out;
  }
  let knownObs = null;
  // parole del vocabolario ancora da imparare (sottolineate in celeste, come nei sottotitoli di Sottotitoli Doppi)
  function savedForms(lang) {
    const out = new Set();
    for (const e of Object.values(vocab || {})) {
      if (!e || e.status === "known" || e.kind === "text") continue;
      for (const w of [e.word, e.lemma]) if (w && wordsIn(w, e.lang || lang).length === 1) out.add(dsCleanWord(String(w)).toLowerCase());
    }
    return out;
  }
  // i modi di dire trovati, sottolineati in arancione dove compaiono (una regola sola per tutti, dentro ogni pezzo di testo)
  function idiomPage() {
    if (!window.CSS || !CSS.highlights) return;
    const list = Object.values(idiomStore).filter((it) => it && it.text && !idiomBad(it.text)).map((it) => it.text.trim()).sort((a, b) => b.length - a.length);
    if (!active() || S.idiomPage === false || !list.length || !document.body) { CSS.highlights.delete("pav-idiom"); return; }
    const esc = (t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+");
    let re;
    try { re = new RegExp("(?<![\\p{L}\\p{N}])(?:" + list.slice(0, 1500).map(esc).join("|") + ")(?![\\p{L}\\p{N}])", "giu"); } catch { return; }
    const ranges = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, { acceptNode: (n) => {
      const p = n.parentElement;
      if (!p || n.nodeValue.length < 4 || p.closest("script,style,noscript,textarea,input,select,code,pre,.pav-root,.dualsub-layer,.dualsub-overlay,.dualsub-card,[contenteditable='true']")) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    } });
    let n, count = 0;
    while ((n = walker.nextNode()) && count < 5000) {
      re.lastIndex = 0;
      for (const m of n.nodeValue.matchAll(re)) {
        const r = document.createRange();
        try { r.setStart(n, m.index); r.setEnd(n, m.index + m[0].length); ranges.push(r); count++; } catch {}
      }
    }
    if (ranges.length) CSS.highlights.set("pav-idiom", new Highlight(...ranges)); else CSS.highlights.delete("pav-idiom");
  }
  function knownPage() {
    if (!window.CSS || !CSS.highlights || typeof DS_KNOWN === "undefined") return;
    const wantKnown = S.learnKnownPage === true && S.learnKnown !== false;
    const wantSaved = S.savedPage !== false;
    if (!active() || (!wantKnown && !wantSaved)) { CSS.highlights.delete("pav-known"); CSS.highlights.delete("pav-saved"); idiomPage(); return; }
    if (!knownObs && document.body) {   // pagine che cambiano (scorrimento infinito, chat…): ricoloro ogni tanto
      // i cambiamenti dentro la scheda o dentro i sottotitoli di Sottotitoli Doppi (10 volte al secondo) non contano
      knownObs = new MutationObserver((list) => { if (list.some((m) => !(m.target.closest && m.target.closest(".pav-root, .dualsub-layer, .dualsub-overlay, .dualsub-card")))) knownPageSoon(2000); });
      knownObs.observe(document.body, { childList: true, subtree: true, characterData: true });
    }
    const lang = pageLang();
    const saved = wantSaved ? savedForms(lang) : new Set();
    if (!wantKnown && !saved.size) { CSS.highlights.delete("pav-known"); CSS.highlights.delete("pav-saved"); idiomPage(); return; }
    const ranges = [], sRanges = [];
    for (const x of pageWords(20000, true)) {
      const lw = String(x.w).toLowerCase();
      const isSaved = saved.has(lw);
      const isKnown = wantKnown && !isSaved && DS_KNOWN.has(lang, x.w);
      if (!isSaved && !isKnown) continue;
      const r = document.createRange();
      try { r.setStart(x.node, x.i); r.setEnd(x.node, x.i + x.len); (isSaved ? sRanges : ranges).push(r); } catch {}
    }
    if (ranges.length) CSS.highlights.set("pav-known", new Highlight(...ranges)); else CSS.highlights.delete("pav-known");
    if (sRanges.length) CSS.highlights.set("pav-saved", new Highlight(...sRanges)); else CSS.highlights.delete("pav-saved");
    idiomPage();
  }
  function knownPageSoon(ms = 1500) { clearTimeout(knownTimer); knownTimer = setTimeout(knownPage, ms); }
  PAV_ONCHANGED.addListener((ch, area) => {
    if ((area === "local" && (ch.knownWords || ch.vocab)) || (area === "sync" && (ch.learnKnownPage || ch.learnKnown || ch.savedPage || ch.idiomPage || ch.on))) knownPageSoon(300);
  });
  if (window === window.top) {
    DS_KNOWN.ready.then(() => setTimeout(() => { if (S.learnKnownPage === true || S.savedPage !== false || S.idiomPage !== false) knownPage(); }, 1500));
    DS_EXT.runtime.onMessage.addListener((msg, sender, reply) => {
      if (!msg || msg.type !== "pavComp") return false;
      try {
        const lang = pageLang();
        const st = DS_KNOWN.stats(pageWords(30000, false), lang);
        reply({ ...st, lang, mine: DS_KNOWN.count(lang) });
      } catch (e) { reply({ error: String(e.message || e) }); }
      return false;
    });
  }

  // ---------- Lingua sbagliata: la scegli tu (per questa scheda, ed eventualmente per tutto il sito) ----------
  async function changeLang(c, code, remember) {
    if (remember) {
      const m = { ...(S.siteLang || {}) };
      if (code) m[host] = code; else delete m[host];
      S.siteLang = m;
      PAV_SYNC.set({ siteLang: m }).catch(() => {});
    }
    c.picker = false; c.langWait = true;
    if (c.kind === "word") {
      renderWord();
      const [sent, data] = await Promise.all([
        send({ ...txEngine(), type: "pavText", text: c.sentence, target: S.targetLang, lang: code }),
        send({ type: "pavWord", word: c.word, target: S.targetLang, lang: code })]);
      if (card !== c) return;
      c.langWait = false;
      if (sent && !sent.error) c.sentTrans = sent.translation;
      c.data = data || { error: "nessuna risposta" };
      c.llm = null; c.ipaWait = false; c.learn = {}; c.wiktIpaTried = false; c.ipaSource = "";
      c.lang = pavBase(code || (sent && sent.detected) || (data && data.lang) || ""); fixApplyWord(c);
      renderWord();
      autoIpa(c);
    } else {
      c.wait = true; renderText();
      const r = await send({ ...txEngine(), type: "pavText", text: c.text, target: S.targetLang, lang: code });
      if (card !== c) return;
      c.wait = false; c.langWait = false; c.better = null; c.ipa = "";
      if (r && !r.error) Object.assign(c, { translation: r.translation, translit: nonLatin(c.text) ? r.translit : "", lang: pavBase(code || r.detected || ""), error: "" });
      else c.error = (r && r.error) || "nessuna risposta";
      renderText();
    }
  }

  // riga "Lingua: inglese (cambia)" e, aperta, la scelta con ricerca
  function langRow(c, rerender) {
    const wrap = el("div", "pav-langrow");
    const name = c.lang ? pavLangName(c.lang) : "non riconosciuta";
    wrap.append(el("span", "pav-muted", "Lingua del testo: "), el("b", null, name + (forcedLang() ? " (scelta da te)" : "")), document.createTextNode(" "));
    wrap.append(button(c.picker ? "chiudi" : "sbagliata? cambia", "Se la lingua riconosciuta è sbagliata, scegli quella giusta e ritraduco", () => { c.picker = !c.picker; rerender(); }, "pav-linkbtn"));
    if (c.langWait) wrap.append(el("span", "pav-muted", " …"));
    if (!c.picker) return wrap;
    const box = el("div", "pav-picker");
    const q = el("input", "pav-search");
    q.type = "text"; q.placeholder = "Cerca: ceco, czech, čeština…"; q.setAttribute("aria-label", "Cerca la lingua");
    const rem = el("label", "pav-remember");
    const chk = el("input"); chk.type = "checkbox"; chk.checked = !!(S.siteLang || {})[host];
    rem.append(chk, document.createTextNode(" Ricorda per " + host));
    const list = el("div", "pav-langlist");
    const all = pavSourceLangs();
    const fill = () => {
      const t = q.value.trim().toLowerCase();
      list.textContent = "";
      if (!t || "automatica".includes(t)) list.append(button("Automatica (riconosciuta da sola)", "", () => changeLang(c, "", chk.checked), "pav-btn pav-langbtn"));
      const shown = t ? all.filter((l) => l.key.includes(t)) : PAV_COMMON_LANGS.map((code) => all.find((l) => l.code === code)).filter(Boolean);
      for (const l of shown.slice(0, 40)) list.append(button((l.code === c.lang ? "► " : "") + l.label, "", () => changeLang(c, l.code, chk.checked), "pav-btn pav-langbtn"));
    };
    q.addEventListener("input", fill);
    // Invio = la prima lingua trovata (con la casella vuota: "Automatica")
    q.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter") { const b = list.querySelector("button"); if (b) b.click(); } });
    box.append(q, rem, list);
    wrap.append(box);
    fill();
    setTimeout(() => q.focus(), 0);
    return wrap;
  }

  // la parola, con le lettere latine sopra ogni lettera se l'opzione è accesa (roman.js, tabelle: nessun servizio)
  // reading: lettura della parola intera (Jisho in kana o Google in lettere latine), per scrivere sopra i kanji
  function romanWord(word, lang, reading) {
    const w = el("span", "pav-word");
    if (!S.roman || typeof DS_ROMAN === "undefined" || !DS_ROMAN.needs(word)) { w.textContent = word; return w; }
    if (DS_ROMAN.rtl(word)) w.dir = "rtl";
    const us = reading && DS_ROMAN.withReading ? DS_ROMAN.withReading(word, lang, reading) : DS_ROMAN.units(word, lang);
    for (const u of us) {
      const x = el("span", "pav-dsr" + (u.han ? " pav-dsr-han" : ""), u.t);
      x.dataset.r = u.r || "";
      w.append(x);
    }
    return w;
  }
  function renderWord() {
    const c = card;
    if (!c || c.kind !== "word") return;
    const d = c.llm || c.data || {};
    const box = c.box || el("div", "pav-card");
    box.textContent = "";
    const head = el("div", "pav-head");
    const title = el("div", "pav-title");
    // lettura per i kanji: Jisho (in kana, si allinea con le parti in kana) oppure quella di Google
    const jt = c.learn && c.learn.jisho && c.learn.jisho.items && c.learn.jisho.items.find((x) => x.word === c.word && x.reading);
    title.append(romanWord(c.word, c.lang, (jt && jt.reading) || (c.data && c.data.translit) || ""));
    // Aa: lettere latine sopra le lettere (alfabeti non latini), si accende e spegne subito
    if (typeof DS_ROMAN !== "undefined" && DS_ROMAN.needs(c.word)) title.append(button("Aa", S.roman ? "Lettere latine sopra le lettere: accese (clic per spegnerle)" : "Lettere latine sopra le lettere: clic per accenderle (per imparare l'alfabeto)",
      () => { S.roman = !S.roman; PAV_SYNC.set({ roman: S.roman }); renderWord(); }, "pav-linkbtn pav-romabtn" + (S.roman ? " pav-on" : "")));
    if (d.lemma && d.lemma.toLowerCase() !== c.word.toLowerCase()) title.append(el("span", "pav-lemma", "→ " + d.lemma));
    if (d.pos) title.append(el("span", "pav-pos", d.pos));
    head.append(title);
    const tools = el("div", "pav-tools");
    tools.append(
      // 🔊 = registrazione di una persona (Wiktionary), quando c'è; 🔈 = voce sintetica (sempre)
      ...((typeof DS_LEARN !== "undefined" && DS_LEARN.recordingOf(c.learn, c.word, S)) ? (() => { const lb = DS_LEARN.recordingLabel(c.learn, c.word, S);
        return [button(lb.form ? "🔊*" : "🔊", lb.title, async (b) => { if (!(await DS_LEARN.playUrl(DS_LEARN.recordingOf(c.learn, c.word, S), null))) b.textContent = "✕"; }, "pav-btn" + (lb.form ? " pav-recform" : ""))]; })() : []),
      button("🔈", "Ascolta la pronuncia (voce sintetica)", (b) => speak(c.word, c.lang, b)),
      button("⚙", "Scegli la voce per questa lingua", () => { c.voiceMenu = !c.voiceMenu; renderWord(); }),
      button("☆", "Salva nel vocabolario", () => toggleSave(c.entry()), "pav-btn pav-star"),
      button("×", "Chiudi (Esc)", closeAll)
    );
    head.append(tools);
    box.append(head);
    if (c.back) box.append(button(`‹ Torna alla parola «${c.back.word}»`, "La scheda della parola intera", backToWord, "pav-linkbtn pav-back"));
    if (c.voiceMenu && typeof DS_TTS.voiceMenu === "function") {
      box.append(DS_TTS.voiceMenu(S.ttsLang || c.lang, () => { c.voiceMenu = false; if (card === c) { renderWord(); speak(c.word, c.lang, null); } }));
    }

    const ipa = ipaOf(c.word, c.lang) || (c.llm && c.llm.ipa) || "";
    const pron = el("div", "pav-pron");
    // IPA: da Wiktionary sempre (gratis); dal modello solo con "Spiega con…", se l'opzione è accesa
    if (ipa) { const sp = el("span", "pav-ipa", "/" + ipa + "/"); sp.title = "Pronuncia IPA" + (c.ipaSource ? " da " + c.ipaSource : c.llm && c.llm.ipa ? " (" + (c.llm.source || "modello") + ")" : ""); pron.append(sp); }
    else if (c.ipaWait) pron.append(el("span", "pav-ipa pav-muted", "IPA …"));
    else if (S.ipa !== false && explainEngine() && !c.llm && wordsIn(c.word, c.lang).length === 1)
      pron.append(el("span", "pav-muted pav-small", `IPA: non c'è su Wiktionary — arriva con «Spiega con ${engineName(explainEngine())}»`));
    const tr = (c.data && c.data.translit) || "";
    if (tr) pron.append(el("span", "pav-translit", tr));
    if (pron.childNodes.length) box.append(pron);

    if (c.data && c.data.error && !c.llm) box.append(el("div", "pav-error", "Non trovo il significato: " + c.data.error));
    else {
      if (d.untranslated && !c.llm) box.append(el("div", "pav-expl", "Google non ha una traduzione per questa parola da sola (spesso è un nome)."));
      else box.append(el("div", "pav-meaning", (c.fixMeaning || d.meaning || "—") + (c.fixMeaning ? " ✎" : "")));
      if (c.llm && c.llm.explanation) box.append(el("div", "pav-expl", c.llm.explanation));
      const gdShown = S.gdAlt !== false && c.data.gdict && c.data.gdict.alt && c.data.gdict.alt.length && typeof DS_LEARN !== "undefined";
      if (!c.llm && !gdShown && c.data.dict && c.data.dict.length) {
        const dl = el("div", "pav-dict");
        for (const x of c.data.dict) { const r = el("div", "pav-dictrow"); r.append(el("b", null, x.pos + ": "), document.createTextNode(x.words.join(", "))); dl.append(r); }
        box.append(dl);
      }
      // modo di dire: dalla spiegazione del modello, oppure tra quelli già trovati in questa frase
      const found = c.llm && c.llm.expression && c.llm.expression.toLowerCase() !== c.word.toLowerCase() && idiomPlausible(c.llm.expression, c.sentence || "")
        ? { text: c.llm.expression, meaning: c.llm.expressionMeaning } : idiomFor(c);
      if (found) {
        const idi = el("div", "pav-idiom");
        const em = idiomMeaning(found.text, found.meaning);
        idi.append(el("b", null, "Modo di dire: "), document.createTextNode(`«${found.text}»` + (em ? " = " + em : "")));
        // trovato nel dizionario di Wiktionary: il significato lo dà «Spiega» (o la pagina di Wiktionary)
        if (found.dict && !em) {
          const a = el("a", "pav-linkbtn", " Wiktionary ↗");
          a.href = "https://en.wiktionary.org/wiki/" + encodeURIComponent(String(found.dict === true ? found.text : found.dict).replace(/ /g, "_"));
          a.target = "_blank"; a.rel = "noopener";
          idi.append(el("span", "pav-muted", " (dal dizionario dei modi di dire;"), a, el("span", "pav-muted", ")"));
        }
        idi.append(idiomFixRow(c, found.text, em));
        // ☆ salva il modo di dire nel vocabolario (come un pezzo di testo, con la sua frase)
        const ie = () => ({ ...c.entry(), kind: "text", word: found.text, lemma: "", pos: "espressione", meaning: em || "", explanation: "", ipa: "" });
        const isave = el("button", "pav-linkbtn pav-idiom-save", saved(ie()) ? "★ modo di dire salvato" : "☆ Salva il modo di dire");
        isave.addEventListener("click", async (ev) => { ev.stopPropagation(); await toggleSave(ie()); isave.textContent = saved(ie()) ? "★ modo di dire salvato" : "☆ Salva il modo di dire"; });
        idi.append(el("br"), isave);
        box.append(idi);
      }
      if (c.llm && c.llm.example) {
        const ex = el("div", "pav-example");
        ex.append(el("div", null, c.llm.example));
        if (c.llm.exampleTrans) ex.append(el("div", "pav-muted", c.llm.exampleTrans));
        box.append(ex);
      }
    }
    if (typeof DS_LEARN !== "undefined") box.append(learnBox(c));
    if (S.sentence !== false && c.sentence && c.sentence !== c.word) {
      const s = el("div", "pav-sentence");
      const i = c.sentence.toLowerCase().indexOf(c.word.toLowerCase());
      if (i >= 0) s.append(c.sentence.slice(0, i), el("b", null, c.sentence.slice(i, i + c.word.length)), c.sentence.slice(i + c.word.length));
      else s.textContent = c.sentence;
      box.append(s);
      if (c.sentTrans) box.append(el("div", "pav-sentrans", c.sentTrans + (c.fixSent ? " ✎" : c.sentBy ? " (" + c.sentBy + ")" : "")));
    }
    const acts = el("div", "pav-actions");
    const ex = explainEngine();
    if (ex && (!c.llm || c.llm.savedAt)) acts.append(button(c.llmWait ? "Chiedo…" : `Spiega con ${engineName(ex)}`, "Una sola richiesta: significato in questa frase, forma base, modo di dire, esempio, e anche etimologia e pronuncia se mancano", () => { c.altEngine = ""; explain(); }, "pav-btn pav-main"));
    // 🔎 i modi di dire della frase con questa parola, chiesti al modello (una richiesta, solo quando lo premi)
    if (ex && c.sentence && c.sentence !== c.word && !c.llmWait && !idiomFor(c) && !(c.llm && c.llm.expression))
      acts.append(button(c.idiomAsk === "wait" ? "Cerco…" : "🔎 Modi di dire con questa parola", "Il modello cerca nella frase i modi di dire che contengono questa parola: una richiesta. Quelli trovati restano sottolineati", () => idiomAsk(c), "pav-btn"));
    // ⇄ la stessa parola spiegata da un altro modello (una richiesta, solo quando lo scegli)
    const others = otherLlms(c.llmBy || (ex && ex.id));
    if (ex && others.length && !c.llmWait) acts.append(button(c.altOpen ? "⇄ Altro modello ▴" : "⇄ Altro modello ▾", "Spiega la stessa parola con un altro modello, per confrontare: una richiesta, solo a quello che scegli. Anche questa spiegazione resta nelle 🗂 salvate", () => { c.altOpen = !c.altOpen; renderWord(); }, "pav-btn"));
    acts.append(button("Copia", "Copia la parola", (b) => copy(c.word, b)),
      button("Copia la frase", "Copia la frase e la sua traduzione", (b) => copy(c.sentence + (c.sentTrans ? "\n" + c.sentTrans : ""), b)),
      button("🔈 frase", "Ascolta la frase (voce sintetica)", (b) => speak(c.sentence, c.lang, b)),
      button("🔈 lenta", "Ascolta la frase lentamente (voce sintetica)", (b) => speak(c.sentence, c.lang, b, 0.6)));
    box.append(acts);
    if (c.altOpen && ex && others.length && !c.llmWait) {
      const row = el("div", "pav-actions pav-altllm");
      for (const o of others) row.append(button(engineName(o), "Spiega con " + engineName(o) + (o.model ? " (" + o.model + ")" : ""), () => { c.altOpen = false; c.altEngine = o.id; explain(); }, "pav-btn"));
      box.append(row);
    }
    { const sr = savedRow(c); if (sr) box.append(sr); }
    { const fr = idiomFlaggedRow(c); if (fr) box.append(fr); }
    box.append(linksRow(c.word, c.lang, true, d.lemma));
    box.append(el("div", "pav-source", "Fonte: " + (c.llm ? c.llm.source + (c.llm.checkNote ? " — " + c.llm.checkNote : "") : (c.data && c.data.source) || "Google Traduttore")));
    { const bn = blockedNote(renderWord); if (bn) box.append(bn); }
    box.append(fixBox(c, renderWord));
    box.append(langRow(c, renderWord));
    if (hoverOn()) box.append(switchRow("Spegni la scheda al passaggio del mouse", "Si riaccende dal popup o con Alt+Maiusc+M", { hover: false }));
    if (!c.box) { c.box = box; ensureRoot().append(box); }
    place(box, c.rect);
    refreshStars();
  }

  async function idiomAsk(c) {
    const e = taskEngine("alignEngine") || explainEngine();
    if (!e || c.idiomAsk === "wait") return;
    c.idiomAsk = "wait"; renderWord();
    const r = await send({ type: "idiomsFind", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, sentence: c.sentence, lang: c.lang, target: S.targetLang, word: c.word });
    c.idiomAsk = "";
    if (r && r.llmDaily) markBlocked(e.id, e.model);
    if (r && !r.error) await idiomAdd(r.idioms, c.lang, c.sentence);
    if (card !== c) return;
    renderWord();
    if (!r || r.error) showNote("Modi di dire non disponibili: " + ((r && r.error) || "nessuna risposta"));
    else if (!idiomFor(c)) showNote(`Nessun modo di dire con «${c.word}» in questa frase.`);
    knownPageSoon(300);
  }

  // i modelli pronti (chiave, modello, richieste di oggi) diversi da quello già usato: per «⇄ Altro modello»
  function otherLlms(except) {
    return DS_CONFIG.engineOrder(S).filter((id) => id !== except && !isBlocked(id)).map(engineOf).filter(isLlm);
  }

  async function explain() {
    const c = card;
    const alt = c && c.altEngine ? engineOf(c.altEngine) : null;
    const e = isLlm(alt) ? alt : explainEngine();
    if (!c || !e || c.llmWait) return;
    c.llmWait = true; renderWord();
    if (typeof dsUserLlm !== "undefined") dsUserLlm = { id: e.id, at: Date.now() };
    // una sola richiesta: spiegazione + etimologia (solo se Wiktionary non l'ha data) + pronuncia (solo se accesa e mancante)
    const known = DS_ETYM.peek(c.word, c.lang, S.targetLang);
    const wantEtym = S.etym !== false && !(known && known.trans);
    const wantIpa = S.ipa !== false && !ipaOf(c.word, c.lang);
    const r = await send({ type: "define", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, target: S.targetLang,
      word: c.word, sentence: c.sentence, sentenceTrans: c.sentTrans, lang: c.lang, etym: wantEtym, ipa: wantIpa,
      sentFix: S.sentence !== false && !c.fixSent && !!c.sentence && c.sentence !== c.word,   // anche la frase tradotta meglio, nella stessa richiesta
      extra: S.learnLlmExtra !== false || S.learnSpell !== false });
    c.llmWait = false;
    if (typeof dsUserLlm !== "undefined" && dsUserLlm.id === e.id) dsUserLlm = { id: "", at: 0 };
    if (card !== c) return;
    // richieste di oggi finite: lo segno e, se c'è un servizio di riserva, rifaccio subito con quello
    if (r && r.llmDaily && (c.dailyRetries || 0) < 6) {
      // 1.6.1: finito questo modello: il prossimo modello dello stesso servizio, poi il servizio di riserva
      markBlocked(e.id, e.model);
      c.dailyRetries = (c.dailyRetries || 0) + 1;
      if (c.altEngine && !isLlm(engineOf(c.altEngine))) c.altEngine = "";
      if (c.altEngine || explainEngine()) return explain();
    }
    // il modello scelto per le spiegazioni (per esempio Ollama) non risponde: rifaccio con il primo pronto della fila
    if (r && (r.error || r.fallback) && !r.llmDaily && !c.altEngine && S.explainEngine === e.id && !c.retriedOwn) {
      ownSkipUntil = Date.now() + 5 * 60e3;
      c.retriedOwn = true;
      const alt = explainEngine();
      if (alt) { showNote("⚠ " + engineName(e) + " non risponde (" + String(r.error || r.source || "").slice(0, 90) + "): uso " + engineName(alt) + "."); return explain(); }
    }
    if (r && !r.error && !r.fallback) {
      c.llm = r; c.llmBy = e.id;
      if (typeof DS_EXPL !== "undefined") DS_EXPL.put(c.lang, c.word, c.sentence, engineName(e), e.model, r);
      if (r.ipa && wordsIn(c.word, c.lang).length === 1 && !ipaCache.get(ipaKey(c.lang, c.word))) { ipaCache.set(ipaKey(c.lang, c.word), r.ipa); ipaSave(); }
      if (r.etymology) DS_ETYM.put(c.word, c.lang, S.targetLang, r.etymology, engineName(e));
      if (r.sentenceTrans && !c.fixSent) { c.sentTrans = r.sentenceTrans; c.sentBy = engineName(e); }
      if (r.expression && r.expression.toLowerCase() !== c.word.toLowerCase()) idiomAdd([{ text: r.expression, meaning: r.expressionMeaning }], c.lang, c.sentence);
    }
    renderWord();
    if (!r || r.error || r.fallback) showNote("Spiegazione non disponibile: " + ((r && (r.error || r.source)) || "nessuna risposta"));
  }

  // ---------- 🗂 Spiegazioni salvate (DS_EXPL in learn.js, comuni con i video) ----------
  function savedData(x) {
    return { ...x.d, source: x.e + (x.m ? " (" + x.m + ")" : "") + " — salvata il " + DS_EXPL.when(x.at), savedAt: x.at };
  }
  function savedRow(c) {
    if (typeof DS_EXPL === "undefined") return null;
    const all = DS_EXPL.list(c.lang, c.word);
    if (!all.length) return null;
    const box = el("div", "pav-saved");
    box.append(button("🗂 " + all.length + (all.length === 1 ? " spiegazione salvata" : " spiegazioni salvate") + (c.savedOpen ? " ▴" : " ▾"),
      "Le spiegazioni dei modelli già chieste per questa parola (anche in altre frasi): nessuna richiesta nuova",
      () => { c.savedOpen = !c.savedOpen; renderWord(); }, "pav-btn pav-savedbtn"));
    if (!c.savedOpen) return box;
    const here = DS_EXPL.norm(c.sentence).slice(0, 400);
    for (const x of all) {
      const item = el("div", "pav-saved-item" + (c.llm && c.llm.savedAt === x.at ? " pav-saved-on" : ""));
      const head = el("div", "pav-saved-head");
      head.append(el("b", null, x.e), el("span", "pav-muted pav-small", (x.m ? " " + x.m : "") + " · " + DS_EXPL.when(x.at)));
      head.append(button("✕", "Togli questa spiegazione salvata", () => { DS_EXPL.remove(c.lang, c.word, x.at); if (c.llm && c.llm.savedAt === x.at) c.llm = null; renderWord(); }, "pav-btn pav-saved-del"));
      item.append(head, el("div", "pav-saved-mean", x.d.meaning || ""));
      item.append(el("div", "pav-muted pav-small", x.s === here ? "in questa frase" : "spiegata nella frase: «" + x.s.slice(0, 140) + (x.s.length > 140 ? "…" : "") + "»"));
      item.title = "Mostra questa spiegazione nella scheda";
      item.addEventListener("click", (ev) => { if (ev.target.closest("button")) return; if (card) card.sticky = true; c.llm = savedData(x); renderWord(); });
      box.append(item);
    }
    return box;
  }

  // ---------- Pannello del testo selezionato: tradotto tutto insieme ----------
  async function openText(text, rect, lang) {
    text = dsCleanWord(text).replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
    const key = "T" + text;
    if (card && card.key === key) return;
    closeAll();
    const my = reqId;
    const forced = forcedLang();
    if (forced) lang = forced;
    card = { kind: "text", key, text, rect, lang: pavBase(lang), translation: "", translit: "", wait: true, pinned: true, sticky: true };
    card.entry = () => ({ kind: "text", word: card.text.slice(0, 600), meaning: card.better || card.translation, lang: card.lang,
      ipa: card.ipa || "", translit: card.translit || "", sentence: "", sentenceTrans: "", url: location.href, title: document.title });
    renderText();
    const r = await send({ ...txEngine(), type: "pavText", text, target: S.targetLang, lang: forced || (lang && !pavSameLang(lang, S.targetLang) ? lang : "") });
    if (my !== reqId || !card || card.key !== key) return;
    card.wait = false;
    if (r && !r.error) Object.assign(card, { translation: r.translation, translit: nonLatin(text) ? r.translit : "", lang: pavBase(forced || r.detected || lang), cut: r.cut });
    else card.error = (r && r.error) || "nessuna risposta";
    if (!card.error) fixApplyText(card);
    renderText();
    // la pronuncia di tutto il testo selezionato solo con il pulsante "Pronuncia IPA" (consuma token)
  }

  async function loadTextIpa() {
    const c = card;
    if (!c || c.kind !== "text") return;
    c.ipaWait = true; renderText();
    const r = await ipaFetch(wordsIn(c.text, c.lang), c.lang, c.text.slice(0, 300));
    c.ipaWait = false;
    if (card !== c) return;
    c.ipa = ipaOf(c.text, c.lang);
    renderText();
    if (r && r.error) showNote("IPA: " + r.error);
  }

  async function better() {
    const c = card, e = explainEngine();
    if (!c || !e || c.betterWait) return;
    c.betterWait = true; renderText();
    const parts = [...segmenter("sentence", c.lang).segment(c.text.slice(0, 5000))].map((s) => s.segment.trim()).filter(Boolean).slice(0, 60);
    const r = await send({ type: "translate", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl, target: S.targetLang, texts: parts, priority: true });
    c.betterWait = false;
    if (card !== c) return;
    if (r && !r.error && Array.isArray(r.translations)) { c.better = r.translations.join(" ").replace(/\s+/g, " ").trim(); c.betterBy = engineName(e); }
    renderText();
    if (!r || r.error) showNote("Non riesco: " + ((r && r.error) || "nessuna risposta"));
  }

  function renderText() {
    const c = card;
    if (!c || c.kind !== "text") return;
    const box = c.box || el("div", "pav-card pav-textcard");
    box.textContent = "";
    const head = el("div", "pav-head");
    head.append(el("div", "pav-title", (c.lang ? pavLangName(c.lang) : "Testo") + " → " + pavLangName(S.targetLang)));
    const tools = el("div", "pav-tools");
    tools.append(
      button("🔈", "Leggi il testo originale (voce sintetica)", (b) => speak(c.text.slice(0, 1500), c.lang, b)),
      button("☆", "Salva nel vocabolario", () => toggleSave(c.entry()), "pav-btn pav-star"),
      button("×", "Chiudi (Esc)", closeAll));
    head.append(tools);
    box.append(head);
    box.append(el("div", "pav-orig", c.text.length > 1200 ? c.text.slice(0, 1200) + "…" : c.text));
    if (c.translit) box.append(el("div", "pav-translit pav-block", c.translit));
    if (c.ipa && S.ipa !== false) box.append(el("div", "pav-ipa pav-block", "/" + c.ipa + "/"));
    else if (c.ipaWait) box.append(el("div", "pav-ipa pav-muted pav-block", "IPA …"));
    if (c.wait) box.append(el("div", "pav-muted pav-block", "Traduco…"));
    else if (c.error) box.append(el("div", "pav-error", "Non riesco a tradurre: " + c.error));
    else {
      box.append(el("div", "pav-trans", (c.better || c.translation) + (c.fixText ? " ✎" : "")));
      if (c.better) box.append(el("div", "pav-muted pav-small", "Traduzione di " + c.betterBy + ". Google: " + c.translation));
      if (c.cut) box.append(el("div", "pav-muted pav-small", "Testo lungo: ho tradotto i primi 5000 caratteri."));
    }
    const acts = el("div", "pav-actions");
    const ex = explainEngine();
    if (ex && !c.better && !c.wait) acts.append(button(c.betterWait ? "Traduco…" : `Traduci meglio (${engineName(ex)})`, "Traduzione che tiene conto del contesto: una richiesta", better, "pav-btn pav-main"));
    if (S.ipa !== false && !c.ipa && !c.ipaWait && ipaEngine() && !c.wait) acts.append(button("Pronuncia IPA", "Pronuncia di ogni parola (Groq o Gemini); le parole restano salvate", loadTextIpa));
    acts.append(button("Copia la traduzione", "", (b) => copy(c.better || c.translation, b)),
      button("Copia tutti e due", "Originale e traduzione", (b) => copy(c.text + "\n\n" + (c.better || c.translation), b)));
    box.append(acts);
    box.append(linksRow(c.text.slice(0, 1500), c.lang, false));
    { const bn = blockedNote(renderText); if (bn) box.append(bn); }
    if (!c.wait) box.append(fixBox(c, renderText));
    if (!c.wait) box.append(langRow(c, renderText));
    box.append(switchRow("Spegni la traduzione quando evidenzi", "Si riaccende dal popup o con Alt+Maiusc+S", { selection: false }));
    if (!c.box) { c.box = box; ensureRoot().append(box); }
    place(box, c.rect);
    refreshStars();
  }

  // ---------- Eventi ----------
  let hoverTimer = 0, last = null;
  document.addEventListener("mousemove", (e) => {
    if (!active() || e.buttons) return;
    if (root && root.contains(e.target)) return;
    last = { x: e.clientX, y: e.clientY, alt: e.altKey };
    // il mouse ha lasciato la parola della scheda: la chiudo (se non ci sei entrato dentro)
    if (card && card.kind === "word" && !card.sticky && !card.pinned) {
      const r = card.rect;
      const near = last.x >= r.left - 4 && last.x <= r.right + 4 && last.y >= r.top - 4 && last.y <= r.bottom + 12;
      if (!near) scheduleHide(300); else clearTimeout(hideTimer);
    }
    clearTimeout(hoverTimer);
    if (!hoverOn() || (S.mode === "alt" && !e.altKey)) return;
    // scheda su cui hai cliccato: resta finché il mouse è vicino (se si rimpicciolisce, la parola sotto non la sostituisce)
    if (card && card.sticky && card.box) {
      const b = card.box.getBoundingClientRect();
      if (last.x > b.left - 40 && last.x < b.right + 40 && last.y > b.top - 40 && last.y < b.bottom + 40) return;
    }
    if (card && card.kind === "text") return;   // il pannello della selezione resta finché non lo chiudi
    hoverTimer = setTimeout(() => {
      const hit = wordAt(last.x, last.y);
      if (hit) openWord(hit, "hover");
    }, Math.max(100, Number(S.delay) || 350));
  }, { passive: true, capture: true });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && card) { closeAll(); return; }
    // modalità "Alt": premendo Alt con il mouse fermo su una parola
    if (e.key === "Alt" && active() && hoverOn() && S.mode === "alt" && last) {
      const hit = wordAt(last.x, last.y);
      if (hit) openWord(hit, "hover");
    }
  }, true);

  document.addEventListener("mousedown", (e) => {
    if (root && root.contains(e.target)) return;
    clearTimeout(hoverTimer);
    if (card) closeAll();
  }, true);

  document.addEventListener("mouseup", (e) => {
    if (!active() || S.selection === false || e.button !== 0) return;
    if (root && root.contains(e.target)) return;
    setTimeout(checkSelection, 30);
  }, true);

  function checkSelection() {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) return;
    const text = sel.toString();
    if (!text.trim() || !/[\p{L}\p{N}]/u.test(text)) return;   // anche le parole di una lettera (в, v, a, I)
    const range = sel.getRangeAt(0);
    const anc = range.commonAncestorContainer, ae = anc.nodeType === 1 ? anc : anc.parentElement;
    if (!ae || ae.closest(".pav-root, input, textarea, select, [contenteditable=''], [contenteditable='true'], .dualsub-overlay, .dualsub-card") || ae.isContentEditable) return;
    const lang = langHint(range.startContainer);
    const rect = range.getBoundingClientRect();
    const clean = dsCleanWord(text).trim();
    const words = wordsIn(clean, lang);
    // una parola sola (anche se il browser la vede in due pezzi, ma senza spazi in mezzo): la sua scheda
    if ((words.length === 1 || (words.length > 1 && !/[\s\u3000]/.test(clean) && /^[\p{L}\p{M}'’\-]+$/u.test(clean))) && clean.length <= 40) {
      const t = firstTextIn(range);
      const hit = { node: t ? t.node : range.startContainer, start: t ? t.offset : 0, end: 0, word: clean.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, ""), range: range.cloneRange(), lang };
      openWord(hit, "select");
      return;
    }
    openText(text, rect, lang);
  }

  window.addEventListener("scroll", () => { if (card && card.kind === "word" && !card.sticky) closeAll(); }, { passive: true });
})();

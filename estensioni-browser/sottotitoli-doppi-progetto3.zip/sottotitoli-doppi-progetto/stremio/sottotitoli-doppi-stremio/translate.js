// Sottotitoli Doppi per Stremio - traduzione e file doppio (senza dipendenze esterne, Node.js 18+)
"use strict";

const URLS = {
  google: process.env.SD_GOOGLE_URL || "https://translate.googleapis.com",
  gemini: process.env.SD_GEMINI_URL || "https://generativelanguage.googleapis.com/v1beta/openai",
  groq: process.env.SD_GROQ_URL || "https://api.groq.com/openai/v1",
  openrouter: process.env.SD_OPENROUTER_URL || "https://openrouter.ai/api/v1",
  claude: process.env.SD_CLAUDE_URL || "https://api.anthropic.com",
};

const ENGINES = {
  google: { kind: "google", chunk: 12 },
  gemini: { kind: "openai", base: URLS.gemini, model: "gemini-flash-lite-latest", gap: 6500, chunk: 40 },
  groq: { kind: "openai", base: URLS.groq, model: "llama-3.3-70b-versatile", gap: 2200, chunk: 35 },
  openrouter: { kind: "openai", base: URLS.openrouter, model: "", gap: 3500, chunk: 40 },
  local: { kind: "openai", base: "http://localhost:11434/v1", model: "", gap: 0, chunk: 15 },
  deepl: { kind: "deepl", gap: 500, chunk: 25 },
  claude: { kind: "claude", model: "claude-haiku-4-5-20251001", gap: 0, chunk: 40 },
};

const LANG_EN = { it: "Italian", en: "English", es: "Spanish", fr: "French", de: "German", pt: "Portuguese", nl: "Dutch",
  pl: "Polish", ro: "Romanian", ru: "Russian", uk: "Ukrainian", tr: "Turkish", ar: "Arabic", ja: "Japanese", ko: "Korean", zh: "Simplified Chinese" };

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------- lettura dei sottotitoli
function toMs(t) {
  const m = String(t).trim().replace(",", ".").match(/(?:(\d+):)?(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?/);
  if (!m) return null;
  return ((+(m[1] || 0) * 60 + +m[2]) * 60 + +m[3]) * 1000 + +String(m[4] || "0").padEnd(3, "0");
}
const cleanText = (t) => t.replace(/\{\\[^}]*\}/g, "").replace(/\\N/gi, " ").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();

function parseSubs(text) {
  text = String(text).replace(/\r/g, "").replace(/^\uFEFF/, "");
  const cues = [];
  if (text.includes("[Events]") && text.includes("Dialogue:")) {
    let fmt = null;
    for (const line of text.split("\n")) {
      if (line.startsWith("Format:") && !fmt && line.includes("Start")) fmt = line.slice(7).split(",").map((x) => x.trim().toLowerCase());
      else if (line.startsWith("Dialogue:") && fmt) {
        const parts = line.slice(9).split(",");
        const row = {};
        fmt.forEach((k, i) => { row[k] = i === fmt.length - 1 ? parts.slice(i).join(",") : parts[i]; });
        const s = toMs(row.start || ""), e = toMs(row.end || ""), t = cleanText(row.text || "");
        if (s != null && e != null && t) cues.push({ s, e, t });
      }
    }
  } else {
    for (const block of text.split(/\n\s*\n/)) {
      const lines = block.split("\n").filter((l) => l.trim());
      const i = lines.findIndex((l) => l.includes("-->"));
      if (i < 0) continue;
      const [a, b] = lines[i].split("-->");
      const s = toMs(a), e = toMs(b.trim().split(/\s+/)[0]);
      const t = cleanText(lines.slice(i + 1).join(" "));
      if (s != null && e != null && t) cues.push({ s, e: Math.max(e, s + 300), t });
    }
  }
  return cues.sort((x, y) => x.s - y.s);
}

// ---------------------------------------------------------------- controlli sulle traduzioni
const STOP = {
  en: "the and is are of to in that it you was for on with this have be not but they what we my your do there a i our were".split(" "),
  it: "il lo gli di che è e un una per non sono con del della mi ti si ma come anche ho questo questa nel alla perché più la al a da io abbiamo siamo".split(" "),
  es: "el los las de que es y un una por para con no se del pero como está muy yo tú al esto pues también la en me".split(" "),
  fr: "le les des que et est un une pour pas je vous il elle dans ce qui sur avec mais au du très la en nous ne".split(" "),
  de: "der die das und ist nicht ich du ein eine zu mit den dem auf für es sie wir aber auch sehr".split(" "),
  pt: "o os as de que e é um uma para com não se do da mas como você eu isso muito também a no na em ao".split(" "),
};
function guessLang(text) {
  const w = String(text || "").toLowerCase().split(/[^\p{L}]+/u).filter(Boolean);
  if (w.length < 5) return "";
  const sc = Object.entries(STOP).map(([l, list]) => [l, w.filter((x) => list.includes(x)).length]).sort((a, b) => b[1] - a[1]);
  return sc[0][1] >= 3 && sc[0][1] >= sc[1][1] * 1.5 ? sc[0][0] : "";
}
function isEcho(orig, trans, target) {
  const words = (t) => String(t || "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  const a = words(orig), b = words(trans);
  if (a.length >= 3 && b.length) {
    if (a.join(" ") === b.join(" ")) return true;
    const set = new Set(a), ratio = b.length / a.length;
    if (ratio > 0.7 && ratio < 1.45 && b.filter((x) => set.has(x)).length / Math.max(a.length, b.length) >= 0.8) return true;
  }
  const g = guessLang(trans);
  return !!(g && g !== target);
}
function badAlignment(texts, trans) {
  if (texts.length < 2) return false;
  return texts.some((src, i) => {
    const t = trans[i] || "";
    if (src.split(/\s+/).length < 3) return false;
    return !t.trim() || t.length > src.length * 2.6 + 25 || t.length < src.length * 0.3;
  });
}

// ---------------------------------------------------------------- servizi
class RateLimited extends Error { constructor(wait, daily) { super("limite di richieste"); this.wait = wait; this.daily = daily; } }
class Fatal extends Error {}

async function check(r, service) {
  if (r.ok) return;
  const text = await r.text().catch(() => "");
  if (r.status === 429) {
    const m = text.match(/"retryDelay"\s*:\s*"(\d+)/);
    const wait = Number(r.headers.get("retry-after")) || (m ? Number(m[1]) : 15);
    throw new RateLimited(Math.min(90, Math.max(5, wait)) * 1000, /PerDay|per day|daily/i.test(text));
  }
  if (r.status === 401 || r.status === 403) throw new Fatal(`${service}: chiave non valida (${r.status})`);
  throw new Error(`${service} ha risposto ${r.status}: ${text.slice(0, 160)}`);
}

async function google(texts, target, source) {
  const tl = target === "zh" ? "zh-CN" : target;
  const sl = source && source !== target ? source : "auto";
  const one = async (q) => {
    const url = `${URLS.google}/translate_a/single?client=gtx&dt=t&sl=${sl}&tl=${tl}&q=${encodeURIComponent(q)}`;
    const r = await fetch(url);
    await check(r, "Google Traduttore");
    const d = await r.json();
    return (d[0] || []).map((p) => (p && p[0]) || "").join("");
  };
  const lines = (await one(texts.join("\n"))).split("\n");
  if (lines.length === texts.length) return lines.map((l) => l.trim());
  const out = [];
  for (const t of texts) out.push((await one(t)).trim());
  return out;
}

function prompt(target, n) {
  const lang = LANG_EN[target] || target;
  return `You translate film and TV subtitles into ${lang}. You receive a JSON object whose "segments" array holds consecutive subtitles. ` +
    `"context_before" and "context_after" are only there to help you understand; do not translate them. Write natural, fluent ${lang} ` +
    `the way a professional subtitler would. Each segment is a separate subtitle shown at a different time: keep every translation ` +
    `aligned with its own segment, never move words between segments, never merge them, never leave one empty. Always translate into ` +
    `${lang}, never copy the original. Do not add numbers, quotes or notes. Return exactly ${n} strings as JSON: {"t": ["..."]} and nothing else.`;
}

function parseList(content, n) {
  const s = String(content || "").replace(/<think>[\s\S]*?<\/think>/g, "").replace(/```(?:json)?/g, "");
  let arr = null;
  const a = s.indexOf("{"), b = s.lastIndexOf("}");
  if (a >= 0 && b > a) { try { const o = JSON.parse(s.slice(a, b + 1)); arr = o.t || o.translations || Object.values(o).find(Array.isArray); } catch {} }
  if (!arr) { const x = s.indexOf("["), y = s.lastIndexOf("]"); if (x >= 0 && y > x) { try { arr = JSON.parse(s.slice(x, y + 1)); } catch {} } }
  if (!Array.isArray(arr) || !arr.length) throw new Error("risposta del modello non leggibile");
  const out = Array.from({ length: n }, (_, i) => String(arr[i] || "").replace(/^\s*\d{1,3}[.)]\s+/, "").trim());
  return { out, misaligned: arr.length !== n };
}

async function llm(engine, conf, texts, before, after, target) {
  const E = ENGINES[engine];
  const user = JSON.stringify({ context_before: before, segments: texts, context_after: after });
  let content;
  if (E.kind === "claude") {
    const r = await fetch(URLS.claude + "/v1/messages", { method: "POST",
      headers: { "content-type": "application/json", "x-api-key": conf.key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: conf.model || E.model, max_tokens: 8000, system: prompt(target, texts.length), messages: [{ role: "user", content: user }] }) });
    await check(r, "Claude");
    content = ((await r.json()).content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
  } else {
    const model = conf.model || E.model;
    if (!model) throw new Fatal("scegli un modello nella configurazione dell'add-on");
    const headers = { "Content-Type": "application/json" };
    if (conf.key) headers.Authorization = "Bearer " + conf.key;
    const r = await fetch((conf.url || E.base).replace(/\/+$/, "") + "/chat/completions", { method: "POST", headers,
      body: JSON.stringify({ model, temperature: 0.2, max_tokens: 8192, messages: [{ role: "system", content: prompt(target, texts.length) }, { role: "user", content: user }] }) });
    await check(r, engine);
    const d = await r.json();
    content = ((d.choices || [])[0] || {}).message?.content || "";
  }
  return parseList(content, texts.length);
}

async function deepl(conf, texts, before, after, target) {
  const host = conf.key.endsWith(":fx") ? "https://api-free.deepl.com" : "https://api.deepl.com";
  const body = { text: texts, target_lang: { en: "EN-US", pt: "PT-BR", zh: "ZH-HANS" }[target] || target.toUpperCase() };
  if (before.length || after.length) body.context = [...before, ...after].join("\n");
  const r = await fetch(host + "/v2/translate", { method: "POST", headers: { "Content-Type": "application/json", Authorization: "DeepL-Auth-Key " + conf.key }, body: JSON.stringify(body) });
  await check(r, "DeepL");
  return ((await r.json()).translations || []).map((t) => t.text || "");
}

// Traduce tutte le frasi; "job.trans" si riempie man mano (serve per servire il file prima della fine)
async function translateAll(job, cues, cfg) {
  let engine = ENGINES[cfg.engine] ? cfg.engine : "google";
  const E = ENGINES[engine];
  const conf = { key: cfg.key || "", model: cfg.model || "", url: cfg.url || "" };
  let useGoogle = E.kind === "google" || (engine !== "local" && !conf.key);
  const texts = cues.map((c) => c.t);
  const size = useGoogle ? ENGINES.google.chunk : E.chunk;
  const queue = [];
  for (let i = 0; i < texts.length; i += size) queue.push(Array.from({ length: Math.min(size, texts.length - i) }, (_, k) => i + k));
  let last = 0;
  job.engineUsed = useGoogle ? "google" : engine;
  while (queue.length) {
    if (job.cancelled) return;
    const ch = queue.shift();
    if (ch.every((i) => job.trans[i] && job.final[i])) continue;
    const src = ch.map((i) => texts[i]);
    const before = texts.slice(Math.max(0, ch[0] - 4), ch[0]), after = texts.slice(ch[ch.length - 1] + 1, ch[ch.length - 1] + 3);
    let res, misaligned = false;
    try {
      if (useGoogle) res = await google(src, cfg.target, cfg.sourceLang);
      else {
        const wait = (E.gap || 0) - (Date.now() - last);
        if (wait > 0) await sleep(wait);
        last = Date.now();
        if (E.kind === "deepl") res = await deepl(conf, src, before, after, cfg.target);
        else ({ out: res, misaligned } = await llm(engine, conf, src, before, after, cfg.target));
        misaligned = misaligned || badAlignment(src, res);
      }
    } catch (e) {
      if (e instanceof RateLimited) {
        if (e.daily) { useGoogle = true; job.engineUsed = "google"; } else await sleep(e.wait);
        queue.unshift(ch);
        continue;
      }
      if (e instanceof Fatal) { useGoogle = true; job.engineUsed = "google"; job.note = e.message; queue.unshift(ch); continue; }
      if (!useGoogle && ch.length > 3) { queue.unshift(ch.slice(0, ch.length >> 1), ch.slice(ch.length >> 1)); continue; }
      try { res = await google(src, cfg.target, cfg.sourceLang); } catch (e2) { job.error = String(e2.message || e2); return; }
    }
    if (misaligned && ch.length > 1) { queue.unshift(ch.slice(0, ch.length >> 1), ch.slice(ch.length >> 1)); continue; }
    const echo = ch.map((i, k) => (isEcho(texts[i], res[k] || "", cfg.target) ? k : -1)).filter((k) => k >= 0);
    if (echo.length && !useGoogle) {
      try {
        const g = await google(echo.map((k) => src[k]), cfg.target, cfg.sourceLang);
        echo.forEach((k, j) => { res[k] = isEcho(src[k], g[j], cfg.target) ? "" : g[j]; });
      } catch {}
    }
    ch.forEach((i, k) => { job.trans[i] = res[k] || ""; job.final[i] = true; });
    job.done = job.final.filter(Boolean).length;
  }
  job.complete = true;
}

// Riempie con Google le frasi non ancora tradotte (quando Stremio chiede il file prima della fine)
// Pezzi da circa 1500 caratteri, 6 richieste alla volta: un film intero si completa in pochi secondi
// (prima andava una richiesta alla volta e Stremio smetteva di aspettare il file)
async function fillMissing(job, cues, cfg) {
  const missing = cues.map((_, i) => i).filter((i) => !job.trans[i]);
  const parts = [];
  let cur = [], chars = 0;
  for (const k of missing) {
    if (cur.length && (cur.length >= 30 || chars + cues[k].t.length > 1500)) { parts.push(cur); cur = []; chars = 0; }
    cur.push(k); chars += cues[k].t.length + 1;
  }
  if (cur.length) parts.push(cur);
  let failed = false;
  const worker = async () => {
    while (parts.length && !failed) {
      const part = parts.shift();
      try {
        const g = await google(part.map((k) => cues[k].t), cfg.target, cfg.sourceLang);
        part.forEach((k, j) => { if (!job.trans[k]) job.trans[k] = g[j] || ""; });
      } catch { failed = true; }
    }
  };
  await Promise.all(Array.from({ length: 6 }, worker));
}

// ---------------------------------------------------------------- file doppio
const msSrt = (ms) => {
  ms = Math.max(0, Math.round(ms));
  const p = (n, l = 2) => String(n).padStart(l, "0");
  return `${p(Math.floor(ms / 3600000))}:${p(Math.floor(ms / 60000) % 60)}:${p(Math.floor(ms / 1000) % 60)},${p(ms % 1000, 3)}`;
};
const esc = (t) => String(t).replace(/</g, "‹").replace(/>/g, "›");

function dualSrt(cues, trans, cfg) {
  const color = String(cfg.color || "FFFF00").replace(/[^0-9a-f]/gi, "").slice(0, 6) || "FFFF00";
  return cues.map((c, i) => {
    const t = trans[i] ? (cfg.plain ? esc(trans[i]) : `<font color="#${color}">${esc(trans[i])}</font>`) : "";
    const o = esc(c.t);
    const body = cfg.layout === "trans_only" ? t || o : cfg.layout === "trans_top" ? [t, o].filter(Boolean).join("\n") : [o, t].filter(Boolean).join("\n");
    return `${i + 1}\n${msSrt(c.s)} --> ${msSrt(c.e)}\n${body}\n`;
  }).join("\n");
}

module.exports = { parseSubs, translateAll, fillMissing, dualSrt, guessLang, isEcho, ENGINES, LANG_EN };

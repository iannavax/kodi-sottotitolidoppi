# 1.4.13: spiegazioni salvate (🗂). La spiegazione del modello resta salvata: riaprendo la parola nella stessa frase si
# vede subito (nessuna richiesta), anche dopo aver ricaricato la pagina; 🗂 apre l'elenco con modello, data e frase.
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
MEAN = "(document.querySelector('.dualsub-card .dualsub-card-meaning')||{}).textContent"
CARD = "(document.querySelector('.dualsub-card')||{}).innerText||''"
async def open_bread(pg, first):
    if first:
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
    words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
    await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
gem = lambda: len([c for c in log.get("gcalls", []) if c[1] == 200])
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}, defCache:[['bread|vecchia frase di prova|gemini|gemini-flash-lite-latest|it',{meaning:'pane (vecchio)',lang:'en',source:'Gemini'}]]})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false, learnExamples:false, learnSpell:false, learnFreq:false, learnLlmExtra:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await open_bread(pg, True)
        print("1. prima: 🗂 =", await pg.evaluate("(document.querySelector('.dualsub-savedbtn')||{}).textContent||'nessuno'"))
        g0 = gem(); await spiega(pg, 4000); await pg.wait_for_timeout(3000)
        m1 = await pg.evaluate(MEAN)
        print("2. spiegazione:", m1, "| richieste a Gemini:", gem() - g0)
        await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-card-btn')].find(b=>b.textContent==='×').click()"); await pg.wait_for_timeout(500)
        await pg.reload(); g1 = gem()
        await open_bread(pg, True)
        m2 = await pg.evaluate(MEAN); src = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-card-source')].map(x=>x.textContent).join(' ')")
        btn = await pg.evaluate("(document.querySelector('.dualsub-savedbtn')||{}).textContent||''")
        print("3. dopo aver ricaricato: significato", m2, "| richieste nuove:", gem() - g1, "| fonte:", src[:80], "| 🗂:", btn)
        print("   ✨ ancora disponibile:", await pg.evaluate("!!document.querySelector('.dualsub-card .dualsub-explainbtn')"))
        await pg.evaluate("document.querySelector('.dualsub-savedbtn').click()"); await pg.wait_for_timeout(300)
        items = await pg.evaluate("[...document.querySelectorAll('.dualsub-saved-item')].map(x=>x.innerText.replace(/\\n/g,' | '))")
        print("4. elenco:", items)
        # quella della vecchia memoria (altra frase): clic → si vede
        await pg.evaluate("[...document.querySelectorAll('.dualsub-saved-item')].find(x=>/vecchia frase/.test(x.innerText)).click()"); await pg.wait_for_timeout(300)
        m3 = await pg.evaluate(MEAN)
        print("5. clic su quella dell'altra frase:", m3)
        await pg.evaluate("[...document.querySelectorAll('.dualsub-saved-item')].find(x=>/vecchia frase/.test(x.innerText)).querySelector('.dualsub-saved-del').click()"); await pg.wait_for_timeout(600)
        left = await sw.evaluate("chrome.storage.local.get(['explSaved','defCache']).then(r=>[Object.values(r.explSaved||{}).flat().length, r.defCache===undefined])")
        print("6. dopo ✕: salvate", left[0], "| vecchia memoria tolta:", left[1])
        ok = m1 and m2 == m1 and gem() - g1 == 0 and "salvata" in src and len(items) == 2 and "pane (vecchio)" in (m3 or "") and left == [1, True]
        print("errori:", errs if ok else errs + ["spiegazioni salvate non vanno"], log["errors"])
        await ctx.close()
asyncio.run(main())

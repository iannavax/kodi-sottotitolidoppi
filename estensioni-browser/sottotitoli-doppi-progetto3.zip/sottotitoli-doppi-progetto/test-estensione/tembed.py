import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
MODE = os.environ.get("TMODE", "live")
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate(f"""chrome.storage.sync.set({{engine:'google', targetLang:'it', transcribeMode:'{MODE}'}})
          .then(()=>chrome.storage.local.set({{keys:{{groq:'gsk_test'}}}}))""")
        for page in ["tvgarden.html", "tvgarden-diretta.html"]:
            n0 = len(log["groq"])
            pg = await ctx.new_page(); errs = []
            pg.on("pageerror", lambda e: errs.append(str(e)))
            await pg.goto(f"https://example.test/{page}"); await pg.wait_for_timeout(2500)
            fr = pg.frames[1]
            await fr.evaluate("document.querySelector('video').play()")
            await pg.wait_for_timeout(16000)
            info = await fr.evaluate("""(()=>{const v=document.querySelector('video'),o=document.querySelector('.dualsub-orig'),t=document.querySelector('.dualsub-trans');
               return {durata: String(v.duration), tempo: Math.round(v.currentTime), orig: o?o.textContent:'(nessuna riga)', trad: t?t.textContent:''}})()""")
            st = await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)")
            print(f"{page}: {info} | richieste Whisper: {len(log['groq'])-n0} | stato: {st}")
            if errs: print("   errori:", errs)
            await pg.close()
        await ctx.close()
asyncio.run(main())

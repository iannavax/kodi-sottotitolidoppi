# 1.7.9: ✎ forma base: si sceglie la radice di una forma flessa e si apre la sua scheda intera (da vedere e salvare)
import asyncio, os, sys
os.environ.setdefault("NO_ALIGN_IDIOM", "1")
sys.path.insert(0, "/home/claude/e2e")
from charness import *
WORD = "(document.querySelector('.dualsub-card .dualsub-card-word')||{}).textContent||''"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({idioms:true, engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnFreq:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ruIdiom"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/сожалению/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=30000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("сожалению")).click(); await pg.wait_for_timeout(2500)
        print("1. scheda:", await pg.evaluate(WORD), "| pulsante:", await pg.locator(".dualsub-card-lemmabtn").count())
        await pg.locator(".dualsub-card-lemmabtn").click(); await pg.wait_for_timeout(3000)
        cands = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-lemmabox .dsx-baselist button')].map(b=>b.textContent)")
        print("2. proposte:", cands)
        await pg.locator(".dualsub-card .dsx-lemmabox .dsx-baselist button", has_text="сожаление").first.click(); await pg.wait_for_timeout(3000)
        print("3. scheda aperta:", await pg.evaluate(WORD), "| torna indietro:", await pg.locator(".dualsub-card .dualsub-card-link", has_text="Torna alla parola").count())
        print("   etimologia salvata:", await sw.evaluate("chrome.storage.local.get('etymBase').then(r=>JSON.stringify(r.etymBase))"))
        await pg.locator(".dualsub-card .dualsub-star").first.click() if await pg.locator(".dualsub-card .dualsub-star").count() else None
        await pg.wait_for_timeout(1500)
        voc = await sw.evaluate("chrome.storage.local.get('vocab').then(r => Object.keys(r.vocab || {}))")
        print("4. salvata nel vocabolario:", voc)
        await pg.locator(".dualsub-card .dualsub-card-link", has_text="Torna alla parola").click(); await pg.wait_for_timeout(2500)
        back = await pg.evaluate(WORD)
        print("5. dopo «Torna alla parola»:", back, "| schede aperte:", await pg.locator(".dualsub-card").count(), "| riga:", await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent"))
        ok = back == 'сожалению' and len(cands) >= 1 and any("сожаление" in c for c in cands) and not [v for v in voc if "сожалению" in v] and any("сожаление" in v for v in voc)
        print("errori:", errs if ok else errs + ["forma base non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

// Adattatore del lettore: YouTube oppure qualsiasi <video>/<audio> di qualsiasi sito, file aperti
// direttamente nel browser (mp4, webm, mp3, ogg, wav…) e file dal computer (file://).
// Fornisce a tutto il resto: getVideo(), currentVideoId(), dsPlayerBox(), dsCaptionsOn().

const DS_IS_YT = /(^|\.)youtube(-nocookie)?\.com$/.test(location.hostname);
const DS_IS_YTMUSIC = location.hostname === "music.youtube.com";   // 1.6.3: YouTube Music (stesso lettore, comandi diversi)
let dsYtReportedId = null;   // identificativo vero del video, comunicato dal lettore di YouTube (serve nei video incorporati)
const dsYtLive = {};         // video di YouTube che sono dirette
let dsChosen = null;
let dsLayer = null;

function dsHash(str) {
  let h1 = 5381, h2 = 52711;
  for (let i = 0; i < str.length; i++) {
    const c = str.charCodeAt(i);
    h1 = (h1 * 33) ^ c;
    h2 = (h2 * 33) ^ c;
  }
  return (h1 >>> 0).toString(36) + (h2 >>> 0).toString(36);
}

function dsAnyMedia() {
  return document.getElementsByTagName("video").length + document.getElementsByTagName("audio").length > 0;
}

function dsArea(m) {
  if (m.tagName !== "VIDEO") return 0;
  const r = m.getBoundingClientRect();
  return Math.max(0, r.width) * Math.max(0, r.height);
}

// Il lettore "giusto" della pagina: quello che sta suonando (meglio se non muto e grande),
// altrimenti l'ultimo scelto, altrimenti il video visibile più grande
function dsPickMedia() {
  const list = [...document.querySelectorAll("video, audio")];
  if (!list.length) { dsChosen = null; return null; }
  const playing = list.filter((m) => !m.paused && !m.ended && m.readyState > 1);
  const score = (m) => (m.muted ? 0 : 1e9) + dsArea(m);
  if (dsChosen && dsChosen.isConnected && (!dsChosen.paused || !playing.length)) return dsChosen;
  if (playing.length) {
    dsChosen = playing.sort((a, b) => score(b) - score(a))[0];
    return dsChosen;
  }
  const visible = list.filter((m) => m.tagName === "AUDIO" || dsArea(m) > 160 * 90)
    .filter((m) => m.currentSrc || m.src || m.querySelector("source"));
  dsChosen = visible.sort((a, b) => score(b) - score(a))[0] || null;
  return dsChosen;
}

function getVideo() {
  if (DS_IS_YT) return document.querySelector("#movie_player video");
  return dsPickMedia();
}

// Identificativo stabile del video: serve per salvare trascrizioni e traduzioni
function currentVideoId() {
  if (DS_IS_YT) {
    const v = new URLSearchParams(location.search).get("v");
    if (v) return v;
    const m = location.pathname.match(/^\/(embed|shorts|live)\/([\w-]{6,})/);
    // "embed/live_stream?channel=…" è lo stesso indirizzo per le dirette di tutti i canali: serve l'identificativo vero
    if (!m || m[2] === "live_stream") {
      if (dsYtReportedId) return dsYtReportedId;
      const ch = new URLSearchParams(location.search).get("channel");
      return m ? "live_stream:" + (ch || "") : null;
    }
    return m[2];
  }
  const m = getVideo();
  if (!m) return null;
  const src = m.currentSrc || m.src || "";
  const key = src && !/^(blob|mediasource):/.test(src)
    ? src.split("#")[0]
    : location.origin + location.pathname + location.search + "#" + [...document.querySelectorAll("video, audio")].indexOf(m);
  return "m" + dsHash(key);
}

// Una diretta: non ha una durata, non si può scaricare tutta e non ha senso salvarla
function dsIsLiveStream(m) {
  if (!m) return false;
  if (m.duration === Infinity) return true;
  return DS_IS_YT && !!dsYtLive[currentVideoId()];
}

// La pagina è un file audio/video aperto direttamente (anche dal computer)
function dsIsDirectMedia() {
  if (DS_IS_YT) return false;
  if (location.protocol === "file:") return true;
  if (/^(video|audio)\//.test(document.contentType || "")) return true;
  const b = document.body;
  return !!(b && b.children.length === 1 && b.firstElementChild.matches("video, audio"));
}

function dsMediaSrc() {
  const m = getVideo();
  const src = m ? m.currentSrc || m.src || "" : "";
  return /^(https?|file):/.test(src) ? src : "";
}

// Contenitore dei sottotitoli: su YouTube il lettore, altrove uno strato sopra il video
// (o una fascia in basso per l'audio e i video nascosti)
function dsPlayerBox() {
  if (DS_IS_YT) return document.querySelector("#movie_player");
  const m = getVideo();
  if (!m) { if (dsLayer) dsLayer.hidden = true; return null; }
  if (!dsLayer) {
    dsLayer = document.createElement("div");
    dsLayer.className = "dualsub-layer";
  }
  const fs = document.fullscreenElement || document.webkitFullscreenElement;
  const parent = fs && fs !== m && fs.contains(m) ? fs : document.body || document.documentElement;
  if (dsLayer.parentNode !== parent) parent.appendChild(dsLayer);
  dsLayer.hidden = false;

  const r = m.getBoundingClientRect();
  const hasPicture = m.readyState < 1 || m.videoWidth > 0; // un file solo audio aperto nel browser è un <video> senza immagine
  const asVideo = m.tagName === "VIDEO" && hasPicture && r.width >= 200 && r.height >= 110 &&
    r.bottom > 0 && r.top < innerHeight && getComputedStyle(m).visibility !== "hidden";
  dsLayer.classList.toggle("dualsub-audio", !asVideo);
  if (asVideo) {
    dsLayer.style.left = r.left + "px";
    dsLayer.style.top = r.top + "px";
    dsLayer.style.width = r.width + "px";
    dsLayer.style.height = r.height + "px";
  } else {
    dsLayer.style.left = "0px";
    dsLayer.style.top = Math.max(0, innerHeight - 260) + "px";
    dsLayer.style.width = innerWidth + "px";
    dsLayer.style.height = Math.min(260, innerHeight) + "px";
  }
  return dsLayer;
}

function dsCaptionsOn() {
  if (!DS_IS_YT) return true;
  const btn = document.querySelector("#movie_player .ytp-subtitles-button");
  return !btn || btn.getAttribute("aria-pressed") === "true";
}

// ---------- Sottotitoli già presenti nel video (<track>) ----------
function dsTextTracks(m) {
  if (!m || !m.textTracks) return [];
  return [...m.textTracks].filter((t) => t.kind === "subtitles" || t.kind === "captions");
}

function dsReadTextTrack(m) {
  const tracks = dsTextTracks(m);
  if (!tracks.length) return null;
  const tt = tracks.find((t) => t.mode === "showing") || tracks[0];
  if (tt.mode === "disabled") tt.mode = "hidden"; // così il browser carica le frasi
  if (!tt.cues || !tt.cues.length) return null;
  const events = [...tt.cues].map((c) => ({
    tStartMs: Math.round(c.startTime * 1000),
    dDurationMs: Math.round((c.endTime - c.startTime) * 1000),
    segs: [{ utf8: String(c.text || "").replace(/<[^>]+>/g, "") }]
  }));
  return { lang: tt.language || "", events, count: tt.cues.length };
}

function dsHideNativeTracks(m) {
  for (const t of dsTextTracks(m)) if (t.mode === "showing") t.mode = "hidden";
}

// ---------- File di sottotitoli (.srt, .vtt) ----------
function dsParseSubs(text) {
  const toMs = (t) => {
    const m = t.trim().replace(",", ".").match(/(?:(\d+):)?(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?/);
    if (!m) return NaN;
    return ((+(m[1] || 0) * 60 + +m[2]) * 60 + +m[3]) * 1000 + +((m[4] || "0").padEnd(3, "0"));
  };
  const events = [];
  const blocks = String(text).replace(/\r/g, "").replace(/^\uFEFF/, "").split(/\n\s*\n/);
  for (const b of blocks) {
    const lines = b.split("\n").filter((l) => l.trim() !== "");
    const i = lines.findIndex((l) => l.includes("-->"));
    if (i < 0) continue;
    const [a, z] = lines[i].split("-->");
    const s = toMs(a), e = toMs(z.split(/\s+/).filter(Boolean)[0] || "");
    const body = lines.slice(i + 1).join(" ").replace(/<[^>]+>/g, "").replace(/\{\\[^}]*\}/g, "").trim();
    if (!isNaN(s) && !isNaN(e) && body) events.push({ tStartMs: s, dDurationMs: Math.max(300, e - s), segs: [{ utf8: body }] });
  }
  return events.sort((x, y) => x.tStartMs - y.tStartMs);
}

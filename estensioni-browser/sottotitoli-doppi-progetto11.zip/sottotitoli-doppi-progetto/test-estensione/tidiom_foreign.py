# Un «modo di dire» che non è nella frase (il modello l'ha scritto tradotto in inglese: «in the secret life») non deve
# comparire mai; quello vero sì. Uso: python3 tidiom_foreign.py <estensione>
import asyncio, os, sys, subprocess
sys.path.insert(0, "/home/claude/e2e")
if len(sys.argv) > 2 and sys.argv[2] == "--case":
    from charness import *
    async def main():
        async with async_playwright() as p:
            ctx, sw = await launch(p, "", None)
            await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', hoverPause:true, learnExamples:false, learnFreq:false})
              .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
            pg = await ctx.new_page(); errs = []
            pg.on("pageerror", lambda e: errs.append(str(e)))
            await pg.goto("https://www.youtube.com/watch?v=ruIdiom"); await pg.wait_for_timeout(1200)
            await pg.evaluate("document.querySelector('video').play()")
            await pg.wait_for_function("/сожалению/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=30000)
            await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
            words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
            await words.nth(texts.index("сожалению")).click(); await spiega(pg, 800)
            for _ in range(40):
                await pg.wait_for_timeout(500)
                if not await pg.evaluate("/Chiedo a/.test((document.querySelector('.dualsub-card')||{}).innerText||'')"): break
            print(f"  {'estraneo' if os.environ.get('EXPR_FOREIGN') else 'vero'}: modo di dire =", await pg.evaluate("(document.querySelector('.dualsub-card-idiom')||{}).textContent||'(nessuno)'"),
                  "| significato:", await pg.evaluate("(document.querySelector('.dualsub-card-meaning')||{}).textContent"))
            print("  errori:", errs, log["errors"])
            await ctx.close()
    asyncio.run(main())
else:
    for env in ({"EXPR_FOREIGN": "1"}, {}):
        subprocess.run([sys.executable, __file__, sys.argv[1], "--case"], env={**os.environ, "NO_ALIGN_IDIOM": "1", **env})

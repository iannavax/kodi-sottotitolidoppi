# 5.17: immagine per Anki — si vede nella scheda, si cambia con ‹ › / altre…, arriva ad Anki come file (data), fonti nel popup
import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
IMG = "(document.querySelector('.dualsub-card .dsx-img')||{}).innerText||'(nessuna)'"
SRC = "(document.querySelector('.dualsub-card .dsx-imgthumb')||{}).src||''"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(900)
        await pp.evaluate("document.getElementById('dAnki').open=true")
        print("1. opzioni:", await pp.evaluate("[...document.querySelectorAll('#ankiImageSource option')].map(o=>o.textContent)"))
        await pp.check("#ankiImage"); await pp.check("#ankiAuto"); await pp.wait_for_timeout(300)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false})")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=imgTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        print("2. scheda:", (await pg.evaluate(IMG)).replace("\n", " | "), "|", (await pg.evaluate(SRC))[-50:])
        await pg.locator(".dualsub-card .dsx-img .dsx-btn", has_text="›").click(); await pg.wait_for_timeout(300)
        print("3. dopo ›:", (await pg.evaluate(IMG)).replace("\n", " | "), "|", (await pg.evaluate(SRC))[-50:])
        await pg.locator(".dualsub-card .dsx-img .dsx-btn", has_text="altre…").click(); await pg.wait_for_timeout(300)
        print("4. griglia:", await pg.evaluate("document.querySelectorAll('.dualsub-card .dsx-imgcell').length"))
        await pg.locator(".dualsub-card .dsx-imgtools select").select_option("openverse"); await pg.wait_for_timeout(1200)
        print("5. Openverse:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-imgcell')].map(i=>i.title)"), "| cercato:", log.get("ov"))
        await pg.locator(".dualsub-card .dsx-imgcell").first.click(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-card .dualsub-star").click(); await pg.wait_for_timeout(2500)
        add = [x[1]["note"] for x in log.get("anki", []) if x[0] == "addNote"]
        pic = add[-1].get("picture") if add else None
        print("6. carta Anki:", pic and [{k: (v[:20] if isinstance(v, str) else v) for k, v in x.items()} for x in pic])
        print("   nota:", await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-anki-note')||{}).textContent"))
        print("   vocabolario:", await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab).map(e=>e.image))"))
        await pg.locator(".dualsub-card .dsx-img .dsx-btn", has_text="✕").click(); await pg.wait_for_timeout(600)
        print("7. ✕ tolta:", (await pg.evaluate(IMG)).replace("\n", " | "), "| vocabolario:", await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab).map(e=>e.image))"))
        vp = await ctx.new_page(); vp.on("pageerror", lambda e: errs.append(str(e)))
        await vp.goto(f"chrome-extension://{eid}/vocab.html"); await vp.wait_for_timeout(800)
        await vp.locator("button", has_text="🖼").first.click(); await vp.wait_for_timeout(1500)
        print("8. vocabolario 🖼:", (await vp.evaluate("(document.querySelector('.dsx-img')||{}).innerText||''")).replace("\n", " | "), "| celle:", await vp.evaluate("document.querySelectorAll('.dsx-imgcell').length"))
        await vp.locator(".dsx-imgcell").nth(1).click(); await vp.wait_for_timeout(800)
        print("   scelta:", await vp.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab).map(e=>e.image))"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

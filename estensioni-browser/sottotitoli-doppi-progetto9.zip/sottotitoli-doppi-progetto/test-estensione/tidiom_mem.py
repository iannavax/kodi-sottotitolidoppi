# Il modo di dire trovato nella scheda resta: se la spiegazione rifatta non lo riporta, la scheda mostra quello di
# prima; «☆ Salva il modo di dire» lo mette nel vocabolario. Uso: NO_ALIGN_IDIOM=1 IDIOM_ONCE=1 python3 tidiom_mem.py <estensione>
import asyncio, os, sys, json
os.environ.setdefault("NO_ALIGN_IDIOM", "1"); os.environ.setdefault("IDIOM_ONCE", "1")
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def settle(pg):
    for _ in range(40):
        await pg.wait_for_timeout(500)
        if not await pg.evaluate("/Chiedo a|…$/.test((document.querySelector('.dualsub-card')||{}).innerText||'')"): break
IDIOM = "(document.querySelector('.dualsub-card-idiom')||{}).textContent||'(nessuno)'"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', hoverPause:true, learnExamples:false, learnFreq:false})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ruIdiom"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/сожалению/.test((document.querySelector('.dualsub-orig')||{}).textContent||'') && document.querySelectorAll('.dualsub-tword').length>1", timeout=30000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("сожалению")).click(); await settle(pg)
        print("1. prima spiegazione:", (await pg.evaluate(IDIOM))[:70])
        await pg.locator(".dualsub-card button", has_text="⚑ Traduzione sbagliata?").click(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-card button", has_text="Rifai con Gemini").click(); await pg.wait_for_timeout(1500); await settle(pg)
        print("2. rifatta (senza modo di dire):", await pg.evaluate("(document.querySelector('.dualsub-card-meaning')||{}).textContent"), "|", (await pg.evaluate(IDIOM))[:70])
        await pg.locator(".dualsub-card .dualsub-idiom-save").click(); await pg.wait_for_timeout(800)
        print("3. salvato:", await pg.evaluate("(document.querySelector('.dualsub-idiom-save')||{}).textContent"), "|", await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab||{}).map(e=>e.word+' = '+e.meaning))"))
        print("4. ricordato:", await sw.evaluate("chrome.storage.local.get('idiomMemory').then(r=>JSON.stringify(r.idiomMemory))"))
        print("errori:", errs, log["errors"], "spiegazioni:", log.get("define"))
        await ctx.close()
asyncio.run(main())

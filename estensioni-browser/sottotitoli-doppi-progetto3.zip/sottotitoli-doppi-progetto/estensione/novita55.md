## Dalla parola tradotta alla parola originale (5.5)

Passa il mouse su una parola della **traduzione**: la parola corrispondente si illumina nella riga originale, così la vedi nel suo contesto, e sotto compare una piccola etichetta con l'originale. **Cliccando** la parola tradotta si apre la scheda con il significato della parola originale in quella frase.

- **Con Google (gratis)** la corrispondenza è approssimata (nell'etichetta compare "circa"): l'estensione traduce al contrario la parola e la cerca nell'originale. Funziona bene per nomi, verbi e aggettivi, meno per le parole grammaticali o quando la traduzione è molto libera.
- **Con Gemini, Groq, Claude o un modello locale**, alla prima parola su cui passi il modello "allinea" tutta la frase con una sola richiesta, e da lì la corrispondenza è precisa anche per le espressioni di più parole. Intanto vedi quella approssimata, che viene sostituita da sola dopo pochi secondi. Quando una frase è allineata funziona anche al contrario: passando su una parola originale si illumina la sua traduzione.


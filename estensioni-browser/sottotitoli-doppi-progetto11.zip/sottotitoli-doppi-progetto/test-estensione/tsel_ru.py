# Selezione manuale di "к сожалению" (parola di una lettera) trascinando il mouse, nei due versi
import asyncio, os, sys
os.environ["NO_ALIGN_IDIOM"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({idioms:true, engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it', hoverPause:true}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ruIdiom"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/сожалению/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=30000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
        words = pg.locator(".dualsub-orig .dualsub-word")
        texts = await words.all_inner_texts()
        async def drag(a, b):
            ba = await words.nth(texts.index(a)).bounding_box(); bb = await words.nth(texts.index(b)).bounding_box()
            await pg.mouse.move(ba["x"] + ba["width"] / 2, ba["y"] + ba["height"] / 2); await pg.mouse.down()
            await pg.mouse.move(bb["x"] + bb["width"] / 2, bb["y"] + bb["height"] / 2, steps=6); await pg.mouse.up(); await pg.wait_for_timeout(2000)
            return (await pg.evaluate("[...document.querySelectorAll('.dualsub-sel')].map(x=>x.textContent)"),
                    await pg.evaluate("(document.querySelector('.dualsub-card-word')||{}).textContent"))
        print("1. da к a сожалению:", await drag("к", "сожалению"))
        await pg.keyboard.press("Escape"); await pg.mouse.move(600, 40); await pg.wait_for_timeout(400)
        print("2. da сожалению a к:", await drag("сожалению", "к"))
        await pg.keyboard.press("Escape"); await pg.mouse.move(600, 40); await pg.wait_for_timeout(400)
        await words.nth(texts.index("сожалению")).click(); await spiega(pg)
        await pg.wait_for_function("!!document.querySelector('.dualsub-card-idiom')", timeout=20000)
        S = "[['tratteggio', [...document.querySelectorAll('.dualsub-idiom-near')].map(x=>x.textContent)], ['selezione', [...document.querySelectorAll('.dualsub-sel')].map(x=>x.textContent)], ['onda', [...document.querySelectorAll('.dualsub-idiom')].map(x=>x.textContent)]]"
        print("3. clic su сожалению: scheda", (await pg.evaluate("document.querySelector('.dualsub-card-idiom').textContent"))[:45], "|", await pg.evaluate(S))
        await pg.keyboard.press("Escape"); await pg.wait_for_timeout(300)
        print("4. scheda chiusa:", await pg.evaluate(S))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

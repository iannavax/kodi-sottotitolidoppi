# Parole al Volo 1.3: etimologia nella scheda (Wiktionary finto), sezione della lingua giusta, si spegne dal popup
import asyncio, os, sys, json, urllib.parse
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
W = []
orig = tvolo.handle
H = lambda lvl, t: f'<div class="mw-heading mw-heading{lvl}"><h{lvl} id="{t}">{t}</h{lvl}></div>'
async def handle(route, request):
    url = request.url
    if url.startswith("https://en.wiktionary.org/w/api.php"):
        page = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("page", [""])[0]; W.append(page)
        pages = {"bread": H(2, "English") + H(3, "Etymology") + "<p>From Old English brēad.</p>",
                 "Кошка": "", "кошка": H(2, "Bulgarian") + H(3, "Etymology") + "<p>SBAGLIATA bulgaro.</p>" + H(2, "Russian") + H(3, "Etymology") + "<p>From Proto-Slavic *kòška.</p>"}
        body = {"parse": {"title": page, "text": '<div class="mw-parser-output">' + pages[page] + "</div>"}} if pages.get(page) else {"error": {"code": "missingtitle"}}
        return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body, ensure_ascii=False))
    return await orig(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/pagina.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "en", "bread", 2500)
        print("1. bread:", await pg.evaluate("(document.querySelector('.pav-card .dsx-etym')||{}).innerText"))
        await tvolo.hover(pg, "ru", "Кошка", 2500)
        print("2. Кошка:", await pg.evaluate("(document.querySelector('.pav-card .dsx-etym')||{}).innerText"), "| pagine:", W)
        await tvolo.hover(pg, "en", "market", 2500)
        print("3. market:", await pg.evaluate("(document.querySelector('.pav-card .dsx-etym')||{}).innerText"))
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini'}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza'}}))"); await pg.wait_for_timeout(300)
        await tvolo.hover(pg, "en", "market", 2500)
        print("3b. con Gemini:", await pg.evaluate("(document.querySelector('.pav-card .dsx-etym')||{}).innerText"))
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.get_by_role("button", name="Spiega con Gemini").click(); await pg.wait_for_timeout(3000)
        print("    dopo 'Spiega con Gemini':", await pg.evaluate("(document.querySelector('.pav-card .dsx-etym')||{}).innerText"), "| richieste (parola, etimologia, ipa):", [(x[1].split('"')[1], x[2], x[3]) for x in tvolo.log["gem"] if x[0] == "define"])
        await pg.keyboard.press("Escape")
        await tvolo.hover(pg, "en", "bread", 2500)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.get_by_role("button", name="Spiega con Gemini").click(); await pg.wait_for_timeout(8000)
        print("    bread (Wiktionary c'è):", [(x[1].split('"')[1], x[2], x[3]) for x in tvolo.log["gem"] if x[0] == "define"][-1])
        await pg.keyboard.press("Escape")
        await sw.evaluate("chrome.storage.sync.set({etym:false})"); await pg.wait_for_timeout(300)
        n = len(W)
        await tvolo.hover(pg, "en", "walked", 2500)
        print("4. spenta:", await pg.evaluate("!!document.querySelector('.pav-card .dsx-etym')"), "| richieste", len(W) - n)
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

# 1.6.6: scheda delle pagine spostabile con la maniglia ⠿, posizione ricordata, doppio clic = torna al posto
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'google', pavEngine:'google', learnExamples:false, learnFreq:false, learnSpell:false, learnNgram:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.set_viewport_size({"width": 1200, "height": 800})
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        box = lambda: pg.evaluate("(()=>{const r=document.querySelector('.pav-card').getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top)]})()")
        b = await tvolo.hover(pg, "en", "bread", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        b0 = await box()
        g = await pg.locator(".pav-card .pav-grip").bounding_box()
        await pg.mouse.move(g["x"] + g["width"] / 2, g["y"] + 5); await pg.mouse.down()
        await pg.mouse.move(g["x"] + g["width"] / 2 + 150, g["y"] + 5 + 90, steps=8); await pg.mouse.up(); await pg.wait_for_timeout(500)
        b1 = await box()
        print("1. dopo il trascinamento:", b0, "→", b1)
        await pg.mouse.click(5, 5); await pg.wait_for_timeout(500)
        b = await tvolo.hover(pg, "en", "market", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        b2 = await box()
        print("2. scheda dopo:", b2, "| salvata:", await sw.evaluate("chrome.storage.local.get('cardUser').then(r=>JSON.stringify(r.cardUser))"))
        g = await pg.locator(".pav-card .pav-grip").bounding_box()
        await pg.mouse.dblclick(g["x"] + g["width"] / 2, g["y"] + 5); await pg.wait_for_timeout(800)
        b3 = await box()
        print("3. dopo doppio clic:", b3)
        ok = abs(b1[0] - b0[0] - 150) < 40 and abs(b1[1] - b0[1] - 90) < 40 and abs(b2[0] - b1[0]) < 30 and abs(b2[1] - b1[1]) < 40 and (b3[0] != b2[0] or b3[1] != b2[1])
        print("errori:", errs if ok else errs + ["scheda delle pagine spostabile non va"])
        await ctx.close()
asyncio.run(main())

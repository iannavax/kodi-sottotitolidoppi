# Crea /tmp/mkvt/film.mkv (video + audio + sottotitoli danesi con 40 frasi) per le prove 6-9 e 13
import os
os.makedirs("/tmp/mkvt", exist_ok=True)
def ts(ms): return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)
with open("/tmp/mkvt/s.srt", "w") as f:
    for i in range(40):
        f.write("%d\n%s --> %s\nRiga numero %d del film\n\n" % (i + 1, ts(i * 3000 + 500), ts(i * 3000 + 2500), i + 1))
os.system("cd /tmp/mkvt && ffmpeg -y -loglevel error -f lavfi -i testsrc=size=320x180:rate=25 -f lavfi -i sine=frequency=440:sample_rate=48000 "
          "-i s.srt -t 125 -map 0:v -map 1:a -map 2 -c:v libx264 -preset ultrafast -b:v 400k -c:a aac -b:a 64k -c:s srt "
          "-metadata:s:s:0 language=dan -metadata:s:s:0 title=Dansk film.mkv")
print(os.path.getsize("/tmp/mkvt/film.mkv"))

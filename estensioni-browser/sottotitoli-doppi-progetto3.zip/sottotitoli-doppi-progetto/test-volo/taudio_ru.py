# Parole al Volo 1.7.1: registrazione da Wiktionary anche quando è solo un collegamento al file o è nell'edizione russa
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
PAGE = """<!doctype html><html lang="ru"><head><meta charset="utf-8"></head><body style="margin:40px;font:20px/2 sans-serif">
<p id="a">Это примечание к тексту.</p><p id="b">Кошка спит дома.</p></body></html>"""
async def handle(route, request):
    u = request.url
    if u.startswith("https://example.test/"): return await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=PAGE)
    if ".wiktionary.org/" in u or "wikimedia.org/" in u: return await charness.handle(route, request)
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false, learnFreq:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        for pid, w in [("a", "примечание"), ("b", "Кошка")]:
            await tvolo.hover(pg, pid, w, 4500)
            btns = await pg.evaluate("[...document.querySelectorAll('.pav-card .pav-tools .pav-btn')].map(b=>b.textContent+(b.title?' ('+b.title+')':''))")
            print(w, "→ pulsanti:", btns[:2])
            box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
            n = len(charness.log.get("audio", []))
            if await pg.locator(".pav-card .pav-tools .pav-btn", has_text="🔊").count():
                await pg.locator(".pav-card .pav-tools .pav-btn", has_text="🔊").click(); await pg.wait_for_timeout(1200)
            print("   audio scaricato:", charness.log.get("audio", [])[n:], "| edizioni:", charness.log.get("wikt_other", []))
            await pg.keyboard.press("Escape")
        print("errori:", errs, tvolo.log["errors"], charness.log["errors"])
        await ctx.close()
asyncio.run(main())

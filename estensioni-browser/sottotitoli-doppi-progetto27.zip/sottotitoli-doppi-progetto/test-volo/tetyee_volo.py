# 1.5.3: ↗ Etymology Explorer su ogni passo dell'albero. (Da tetytree_volo 1.4.4: albero etimologico vero di Wiktionary ({{etymon|tree=1}}: caselle .etytree-block) dalle pagine salvate
# dall'utente (fixtures/wikt-*.htm): embarazado (spagnolo) e diabolically (inglese)
import asyncio, os, sys, json, urllib.parse
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
SHOT = sys.argv[2] if len(sys.argv) > 2 else "/tmp/tetytree.png"
HERE = os.path.dirname(os.path.abspath(__file__))
FIX = {w: open(os.path.join(HERE, "fixtures", "wikt-" + w + ".htm"), encoding="utf-8").read() for w in ["embarazado", "diabolically"]}
PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Prova</title></head><body style="margin:40px;font:18px/1.6 Georgia">
<p id="es" lang="es">Mi hermana está muy embarazado hoy.</p>
<p id="en">He laughed diabolically at the end.</p></body></html>"""
orig = tvolo.handle
async def handle(route, request):
    url = request.url
    if url.startswith("https://example.test/ety.html"):
        return await route.fulfill(status=200, content_type="text/html; charset=utf-8", body=PAGE)
    if url.startswith("https://en.wiktionary.org/w/api.php"):
        page = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("page", [""])[0]
        print("   wiktionary:", page, page in FIX)
        body = {"parse": {"title": page, "text": FIX[page]}} if page in FIX else {"error": {"code": "missingtitle"}}
        return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body, ensure_ascii=False))
    return await orig(route, request)
TREE = "(document.querySelector('.pav-card .dsx-etytree')||{}).innerText||'(nessun albero)'"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, viewport={"width": 1000, "height": 1400},
            args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/ety.html"); await pg.wait_for_timeout(800)
        res = {}
        for pid, w in [("es", "embarazado"), ("en", "diabolically")]:
            await tvolo.hover(pg, pid, w, 3500)
            print("   scheda:", (await pg.evaluate("(document.querySelector('.pav-card')||{}).innerText||''"))[:300].replace("\n", " | "))
            print("==", w, "| riga:", (await pg.evaluate("(document.querySelector('.pav-card .dsx-etym')||{}).innerText||''"))[:120].replace("\n", " | "))
            box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
            b = pg.locator(".pav-card button", has_text="albero etimologico")
            if await b.count(): await b.first.click(); await pg.wait_for_timeout(600)
            links = await pg.evaluate("[...document.querySelectorAll('.pav-card .dsx-etytree a.dsx-ety-ee')].map(a=>decodeURIComponent(a.href.replace('https://etymologyexplorer.com/word/','')))")
            print("   ↗:", links)
            res[w] = links
        ok = any(l.startswith("Old Spanish/") or l.startswith("Latin/") for l in res.get("embarazado", [])) and any(l.startswith("English/diabolical") for l in res.get("diabolically", []))
        print("errori:", errs if ok else errs + ["↗ Etymology Explorer nell'albero non va"])
        await ctx.close()
asyncio.run(main())

// Parole interattive (significato nel contesto, pronuncia) e vocabolario personale.
// Usa: settings, engine, liveEngine, getVideo, overlay, lineOrig (da content.js)

let vocab = {};
let vocabForms = new Set();
let vocabFormsAny = new Set();
let vocabVersion = 0;
let wordsCurrent = null;        // frase mostrata ora: { text, trans, start, end, lang, live }
let wordsOrigKey = "";
let wordsCard = null;
let wordsCardState = null;      // { pinned, word, data }
let wordsAutoPaused = false;
let wordsHovering = false;
let wordsHoverTimer = 0, wordsLeaveTimer = 0, wordsReqId = 0;
let wordsReplayUntil = null;
const wordsDefCache = new Map();
// Le spiegazioni chieste a un modello restano salvate (anche chiudendo il browser): la stessa parola nella stessa
// frase non si richiede più. Le ultime 1500.
let wordsDefSaveTimer = 0;
// 1.4.13: su disco restano nelle «spiegazioni salvate» (DS_EXPL in learn.js, comuni a video e pagine, con il 🗂 della
// scheda); quelle della vecchia memoria (defCache: parola|frase|servizio|modello|lingua…) passano lì una volta sola
let wordsExplHook = false;
function wordsExplHookInit() {   // il pezzo delle spiegazioni salvate è arrivato: la scheda si ridisegna (🗂). (DS_EXPL è in learn.js, caricato dopo questo file)
  if (wordsExplHook || typeof DS_EXPL === "undefined") return;
  wordsExplHook = true;
  DS_EXPL.onLoad(() => { try { if (wordsCardState) wordsFillCard(); } catch {} });
}
chrome.storage.local.get({ defCache: [] }, async (r) => {
  const old = Array.isArray(r.defCache) ? r.defCache : [];
  if (!old.length || typeof DS_EXPL === "undefined") return;
  await DS_EXPL.ready;
  for (const [k, d] of old) {
    const [w, sent, id, model] = String(k).split("|");
    if (!d || d.error || !w || !sent || id === "google") continue;
    const E = C.ENGINES[id];
    DS_EXPL.put(d.lang || "", w, sent, E ? E.label.split(" (")[0].split(",")[0] : id, model, d);
  }
  DS_EXT.storage.local.remove("defCache").catch(() => {});
});
function wordsDefRemember(k, v) {
  wordsDefCache.set(k, v);
  while (wordsDefCache.size > 1500) wordsDefCache.delete(wordsDefCache.keys().next().value);
}
const wordsSegmenters = new Map();

// ---------- Vocabolario ----------
function vocabId(lang, lemma, word) {
  return `${(lang || "?").split("-")[0].toLowerCase()}|${String(lemma || word).toLowerCase()}`;
}

function vocabRebuild() {
  vocabForms = new Set();
  vocabFormsAny = new Set();
  for (const e of Object.values(vocab)) {
    if (e.status === "known") continue;
    const l = String(e.lang || "").split("-")[0].toLowerCase();
    for (const w of [e.word, e.lemma]) {
      if (!w) continue;
      vocabForms.add(l + "|" + String(w).toLowerCase());
      vocabFormsAny.add(String(w).toLowerCase());
    }
  }
  vocabVersion++;
}
// la parola è nel vocabolario NELLA LINGUA della riga («ne» ceco ≠ «ne» italiano); lingua della riga sconosciuta: qualunque lingua
function vocabHas(lang, w) {
  const l = String(lang || "").split("-")[0].toLowerCase(), t = String(w).toLowerCase();
  return l ? vocabForms.has(l + "|" + t) : vocabFormsAny.has(t);
}

chrome.storage.local.get({ vocab: {} }, (r) => { vocab = r.vocab || {}; vocabRebuild(); });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.vocab) {
    vocab = changes.vocab.newValue || {};
    vocabRebuild();
    wordsRefreshStar();
  }
});

async function vocabToggle(entry) {
  const { vocab: current = {} } = await DS_EXT.storage.local.get({ vocab: {} });
  if (current[entry.id]) delete current[entry.id];
  else current[entry.id] = entry;
  await DS_EXT.storage.local.set({ vocab: current });
}

// ---------- Nomi cinesi (e giapponesi) che il dizionario del browser spezza ideogramma per ideogramma ----------
// 1.7.26: quando il modello allinea la frase con la traduzione (una sola parola tradotta ↔ più pezzetti dell'originale, per esempio
// «Netanyahu» ↔ 内塔尼亚胡) la parola intera si ricorda (storage.local hanJoin) e da allora, in tutte le frasi, è una parola sola.
let wordsHanJoin = new Set(), wordsHanJoinV = 0;
DS_EXT.storage.local.get({ hanJoin: [] }).then((r) => { wordsHanJoin = new Set(r.hanJoin || []); wordsHanJoinV++; }).catch(() => {});
const wordsHanRe = /^\p{Script=Han}+$/u;
function wordsHanApply(parts) {
  if (!wordsHanJoin.size) return parts;
  const out = [];
  for (let i = 0; i < parts.length; i++) {
    let done = false;
    if (parts[i].word && wordsHanRe.test(parts[i].text)) {
      for (let len = Math.min(6, parts.length - i); len >= 2 && !done; len--) {
        const seg = parts.slice(i, i + len);
        if (!seg.every((p) => p.word)) continue;
        const s = seg.map((p) => p.text).join("");
        if (wordsHanJoin.has(s)) { out.push({ text: s, word: true }); i += len - 1; done = true; }
      }
    }
    if (!done) out.push(parts[i]);
  }
  return out;
}
// pairs: [[parole della traduzione, parti dell'originale, extra]]; text: la frase originale
function wordsHanLearn(pairs, text, lang) {
  if (!text || typeof DS_ROMAN === "undefined" || !DS_ROMAN.hasHan(text)) return;
  const parts = wordsTokenizeRaw(text, lang).filter((p) => p.word).map((p) => p.text);
  let added = false;
  for (const [t, o] of pairs || []) {
    const oo = String(o || "").replace(/\s+/g, "");
    if (oo.length < 2 || oo.length > 8 || !wordsHanRe.test(oo) || wordsHanJoin.has(oo)) continue;
    if (String(t || "").trim().split(/\s+/).length !== 1) continue;
    for (let i = 0; i < parts.length; i++) {
      let s = "", j = i;
      while (j < parts.length && s.length < oo.length) s += parts[j++];
      if (s !== oo || j - i < 2) continue;
      // un nome proprio (maiuscola nella traduzione), oppure solo pezzetti di un carattere che il modello vede come una parola sola
      if (/^\p{Lu}/u.test(String(t).trim()) || parts.slice(i, j).every((p) => [...p].length === 1)) { wordsHanJoin.add(oo); added = true; }
      break;
    }
  }
  if (!added) return;
  wordsHanJoinV++;
  const all = [...wordsHanJoin];
  if (all.length > 800) wordsHanJoin = new Set(all.slice(-800));
  DS_EXT.storage.local.set({ hanJoin: [...wordsHanJoin] }).catch(() => {});
  if (wordsCurrent && !wordsCardState) wordsRenderOriginal(wordsCurrent.text, wordsCurrent.lang);
}

// ---------- Suddivisione della frase in parole ----------
function wordsTokenize(text, lang) { return wordsHanApply(wordsTokenizeRaw(text, lang)); }
function wordsTokenizeRaw(text, lang) {
  try {
    const key = lang || "";
    if (!wordsSegmenters.has(key)) {
      let seg;
      try { seg = new Intl.Segmenter(lang || undefined, { granularity: "word" }); }
      catch { seg = new Intl.Segmenter(undefined, { granularity: "word" }); }
      wordsSegmenters.set(key, seg);
    }
    return [...wordsSegmenters.get(key).segment(text)].map((s) => ({ text: s.segment, word: dsIsWord(s) }));
  } catch {
    return text.split(/([\p{L}\p{M}\p{N}'’-]+)/u).filter(Boolean).map((t) => ({ text: t, word: /[\p{L}\p{N}]/u.test(t) }));
  }
}

// ---------- Parole della traduzione ↔ parole dell'originale ----------
let wordsTransKey = "";
let wordsAlignTip = null;
let wordsAlignTimer = 0;
const wordsAlignCache = new Map();   // frase + traduzione → coppie allineate dal modello
const wordsAlignAsked = new Set();
const wordsBackCache = new Map();    // parola tradotta → parole originali possibili (Google)
const wordsIdioms = new Map();       // frase originale → modi di dire [{ text, meaning }] (dal modello, nella richiesta dell'allineamento)
let wordsSel = null;                 // selezione a mano di più parole: { start, end, moved }
let wordsNoClickUntil = 0;
let wordsIdiomTimer = 0;
let wordsTSel = null;                // selezione a mano di più parole della traduzione: { start, end, moved }
let wordsCompare = null;             // confronto attivo: { key, tSpans } (parte della traduzione ↔ parte dell'originale)

function wordsRenderTrans(text) {
  const key = text + "\u0001" + (wordsCurrent ? wordsCurrent.text : "");
  if (key === wordsTransKey) return;
  wordsTransKey = key;
  wordsCompare = null;
  lineTrans.textContent = "";
  for (const part of wordsTokenize(text, settings.targetLang)) {
    if (!part.word) { lineTrans.append(part.text); continue; }
    lineTrans.append(Object.assign(document.createElement("span"), { className: "dualsub-tword", textContent: part.text }));
  }
  wordsMarkParticles();
}

const wordsNorm = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/\p{M}/gu, "").replace(/[^\p{L}\p{N}]/gu, "");
function wordsSame(a, b) {
  if (!a || !b) return false;
  if (a === b) return true;
  const n = Math.min(a.length, b.length);
  if (n < 4 || Math.abs(a.length - b.length) > 3) return false;   // "bread" non è "breakfast"
  const k = Math.max(4, n - 2);   // stessa radice (bread/breads, andare/andato)
  return a.slice(0, k) === b.slice(0, k);
}
const wordsSplit = (s) => String(s || "").split(/[^\p{L}\p{N}']+/u).map(wordsNorm).filter(Boolean);
const wordsNoSpaces = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Thai}\p{Script=Lao}\p{Script=Khmer}\p{Script=Myanmar}]/u;

function wordsFindSeq(tokens, seq, from) {
  const at = (i) => seq.every((w, j) => wordsSame(tokens[i + j], w));
  for (let i = from; i + seq.length <= tokens.length; i++) if (at(i)) return i;
  for (let i = 0; i < Math.min(from, tokens.length); i++) if (i + seq.length <= tokens.length && at(i)) return i;
  return -1;
}

// Indici delle parole della frase (già normalizzate) che contengono il pezzo `phrase`, cercando da `from` in poi.
// Se parola per parola non lo trovo (apostrofi diversi "l’acqua"/"l'acqua", trattini, cinese e giapponese
// divisi in parole in modo diverso) lo cerco nel testo unito senza spazi.
function wordsLocate(tok, phrase, from) {
  const seq = wordsSplit(phrase);
  if (!seq.length) return [];
  const i = wordsFindSeq(tok, seq, from);
  if (i >= 0) return seq.map((_, k) => i + k);
  const p = wordsNorm(phrase);
  if (!p) return [];
  let s = "";
  const st = [], en = [];
  tok.forEach((t) => { st.push(s.length); s += t; en.push(s.length); });
  const loose = p.length >= 4 || wordsNoSpaces.test(p);   // pezzi di parola solo se abbastanza lunghi
  let best = null;
  for (let at = s.indexOf(p); at >= 0; at = s.indexOf(p, at + 1)) {
    const end = at + p.length;
    const idx = [];
    tok.forEach((_, k) => { if (st[k] < end && en[k] > at && tok[k]) idx.push(k); });
    if (!idx.length) continue;
    const whole = st[idx[0]] === at && en[idx[idx.length - 1]] === end;
    if (!whole && !loose) continue;
    const score = (whole ? 2 : 0) + (idx[0] >= from ? 1 : 0);
    if (!best || score > best.score) best = { idx, score };
    if (score === 3) break;
  }
  return best ? best.idx : [];
}

// Dalle coppie del modello: per ogni parola della traduzione, le parole dell'originale che traduce.
// Coppie: [parole della traduzione, parole dell'originale, parole "in più" della traduzione].
// Valore: { o: [indici nell'originale], how, group: [indici delle parole della traduzione nella stessa coppia] }
//   "model"    → traduce quella parte dell'originale
//   "particle" → non traduce una parola: la richiede la grammatica della traduzione (articolo, preposizione…);
//                o = la parte dell'originale di cui fa parte
//   "lost"     → il modello l'ha saltata o scritta diversa: va cercata in un altro modo (mai indovinata dalla vicina)
function wordsAlignMap(tTok, oTok, pairs) {
  const t2o = new Map();
  let tp = 0, op = 0;
  for (const p of pairs) {
    const tPhrase = p[0], oPhrase = String(p[1] || "").trim();
    const extra = new Set((Array.isArray(p[2]) ? p[2] : []).flatMap(wordsSplit));
    const ti = wordsLocate(tTok, tPhrase, tp);
    if (!ti.length) continue;
    const oi = oPhrase ? wordsLocate(oTok, oPhrase, op) : [];
    for (const i of ti) {
      const old = t2o.get(i);
      if (old && old.how !== "lost") continue;
      const how = !oPhrase ? "empty" : !oi.length ? "lost" : extra.has(tTok[i]) ? "particle" : "model";
      t2o.set(i, { o: oi, how, group: ti });
    }
    tp = ti[ti.length - 1] + 1;
    if (oi.length) op = oi[oi.length - 1] + 1;
  }
  // originale lasciato vuoto dal modello: è una parola aggiunta dalla traduzione, la lego alla parte che accompagna
  // (di solito la parola dopo: "il gatto", "di fumare"; alla fine della frase quella prima)
  const sure = (i) => { const e = t2o.get(i); return !!e && e.how === "model"; };
  for (const [i, e] of [...t2o]) {
    if (e.how !== "empty") continue;
    let r = i + 1; while (r < tTok.length && !sure(r) && t2o.has(r) && t2o.get(r).how === "empty") r++;
    let l = i - 1; while (l >= 0 && !sure(l) && t2o.has(l) && t2o.get(l).how === "empty") l--;
    const from = sure(r) ? r : sure(l) ? l : -1;
    t2o.set(i, from >= 0 ? { o: t2o.get(from).o, how: "particle", group: [Math.min(i, from), Math.max(i, from)] } : { o: [], how: "lost", group: [i] });
  }
  return t2o;
}

// Parole della traduzione che sono solo particelle (dopo l'allineamento del modello): sottolineate a puntini
function wordsMarkParticles() {
  if (!lineTrans || !wordsCurrent || !wordsCurrent.trans) return;
  const tSpans = [...lineTrans.querySelectorAll(".dualsub-tword")];
  tSpans.forEach((s) => s.classList.remove("dualsub-tpart"));
  const pairs = wordsAlignCache.get(wordsCurrent.text + "\u0001" + wordsCurrent.trans);
  if (!pairs || !lineOrig) return;
  const oTok = [...lineOrig.querySelectorAll(".dualsub-word")].map((s) => wordsNorm(s.textContent));
  for (const [ti, e] of wordsAlignMap(tSpans.map((s) => wordsNorm(s.textContent)), oTok, pairs)) {
    if (e.how === "particle" && tSpans[ti]) {
      tSpans[ti].classList.add("dualsub-tpart");
      tSpans[ti].title = "Particella della traduzione: non traduce una parola dell'originale";
    }
  }
}

function wordsClearAlign() {
  clearTimeout(wordsAlignTimer);
  if (!overlay) return;
  overlay.querySelectorAll(".dualsub-hl, .dualsub-hl-part, .dualsub-hl-group").forEach((x) => x.classList.remove("dualsub-hl", "dualsub-hl-part", "dualsub-hl-group"));
  if (wordsAlignTip) { wordsAlignTip.remove(); wordsAlignTip = null; }
}

// res = { o: [indici nell'originale], how, group } con how:
//   "model" (traduzione di quella parte), "particle" (particella della traduzione), "google" (circa),
//   "zone" (traduzione diretta non trovata: zona della frase), "wait" (sto cercando)
function wordsShowAlign(tEl, res) {
  overlay.querySelectorAll(".dualsub-hl, .dualsub-hl-part, .dualsub-hl-group").forEach((x) => x.classList.remove("dualsub-hl", "dualsub-hl-part", "dualsub-hl-group"));
  const oSpans = [...lineOrig.querySelectorAll(".dualsub-word")];
  const tSpans = [...lineTrans.querySelectorAll(".dualsub-tword")];
  const sorted = [...new Set(res.o || [])].sort((a, b) => a - b);
  const hit = sorted.map((i) => oSpans[i]).filter(Boolean);
  const part = res.how === "particle" || res.how === "zone";
  hit.forEach((s) => { s.classList.add("dualsub-hl"); if (part) s.classList.add("dualsub-hl-part"); });
  tEl.classList.add("dualsub-hl");
  // le altre parole della traduzione che vanno insieme a questa (per esempio "gli" con "angoli")
  const group = (res.group || []).map((i) => tSpans[i]).filter((s) => s && s !== tEl);
  group.forEach((s) => s.classList.add("dualsub-hl-group"));
  if (!wordsAlignTip) {
    wordsAlignTip = document.createElement("div");
    wordsAlignTip.className = "dualsub-align-tip";
    overlay.append(wordsAlignTip);
  }
  wordsAlignTip.textContent = "";
  wordsAlignTip.classList.toggle("dualsub-tip-long", part && hit.length > 0);
  const joined = sorted.every((v, k) => k === 0 || v === sorted[k - 1] + 1);
  const hitText = joined ? wordsRangeText(hit) : hit.map((x) => x.textContent).join(" … ");
  const word = tEl.textContent;
  if (res.how === "wait" || !hit.length) {
    wordsAlignTip.append(el("span", null, "Cerco la parola nell'originale…"));
  } else if (res.how === "particle") {
    const whole = group.length ? wordsRangeText([tEl, ...group].sort((a, b) => tSpans.indexOf(a) - tSpans.indexOf(b))) : "";
    wordsAlignTip.append(el("span", "dualsub-tip-part", "particella"), el("span", null, ` «${word}» non traduce una parola dell'originale: la aggiunge la grammatica della traduzione` +
      (whole ? ` in «${whole}», che traduce ` : `. Fa parte della traduzione di `)), el("b", null, hitText));
  } else if (res.how === "zone") {
    wordsAlignTip.append(el("span", null, `Non trovo la traduzione diretta di «${word}»: è probabilmente una particella della traduzione, o la frase è tradotta liberamente. Zona corrispondente: `),
      el("b", null, hitText), el("span", null, "  ·  circa"));
  } else {
    wordsAlignTip.append(el("b", null, hitText), el("span", null, res.how === "google" ? "  ·  circa · clic per il significato" : "  ·  clic per il significato"));
  }
  const or = overlay.getBoundingClientRect(), r = tEl.getBoundingClientRect();
  wordsAlignTip.style.left = r.left + r.width / 2 - or.left + "px";
  const transFirst = settings.transFirst;
  if (transFirst) { wordsAlignTip.style.top = ""; wordsAlignTip.style.bottom = or.bottom - r.top + 6 + "px"; }
  else { wordsAlignTip.style.bottom = ""; wordsAlignTip.style.top = r.bottom - or.top + 6 + "px"; }
  return hit;
}

// Posizione stimata di una parola della traduzione nell'originale (ultima risorsa)
const wordsGuessAt = (ti, nT, nO) => Math.round((ti / Math.max(1, nT - 1)) * Math.max(0, nO - 1));

// Tra più posizioni possibili tengo quella più vicina alla posizione della parola nella traduzione
function wordsNearest(idx, ti, nT, nO) {
  if (idx.length <= 1) return idx;
  const rel = ti / Math.max(1, nT - 1);
  return [[...idx].sort((a, b) => Math.abs(a / Math.max(1, nO - 1) - rel) - Math.abs(b / Math.max(1, nO - 1) - rel))[0]];
}

// Allineamento del modello in corso per questa frase (vale la pena aspettarlo)?
const wordsAlignPending = (key) => wordsAlignAsked.has(key);

// Senza modello (o se il modello ha saltato la parola): traduzione parola per parola dell'originale con Google
// (una richiesta per frase, gratis) e, se non basta, traduzione inversa della parola. Una parola della traduzione
// rimanda solo a una parola dell'originale che la traduce davvero: mai alla vicina.
const wordsGlossCache = new Map();   // frase originale + lingua → traduzione di ogni parola
async function wordsGloss(cur, oWords) {
  const k = cur.text + "|" + settings.targetLang;
  if (wordsGlossCache.has(k)) return wordsGlossCache.get(k);
  const src = (cur.lang || "").split("-")[0] || DualSubs.guessLang(cur.text) || "";
  let gloss = [];
  try {
    const r = await DS_EXT.runtime.sendMessage({ type: "translate", engine: "google", target: settings.targetLang, source: src,
      texts: oWords.slice(0, 60) });
    gloss = (r && r.translations) || [];
  } catch {}
  if (gloss.length) {
    wordsGlossCache.set(k, gloss);
    if (wordsGlossCache.size > 300) wordsGlossCache.delete(wordsGlossCache.keys().next().value);
  }
  return gloss;
}

async function wordsBack(word, cur) {
  const src = (cur.lang || "").split("-")[0] || DualSubs.guessLang(cur.text) || "";
  const k = word + "|" + src;
  if (wordsBackCache.has(k)) return wordsBackCache.get(k);
  let c = [];
  try {
    const r = await DS_EXT.runtime.sendMessage({ type: "wordBack", word, from: settings.targetLang, to: src || "en" });
    c = (r && r.candidates) || [];
  } catch {}
  wordsBackCache.set(k, c);
  if (wordsBackCache.size > 500) wordsBackCache.delete(wordsBackCache.keys().next().value);
  return c;
}

// Parole dell'originale che traducono la parola ti della traduzione (con Google); [] se nessuna
async function wordsGoogleFind(cur, ti, tSpans, oSpans) {
  const tTok = tSpans.map((s) => wordsNorm(s.textContent)), oTok = oSpans.map((s) => wordsNorm(s.textContent));
  const w = tTok[ti];
  const gloss = await wordsGloss(cur, oSpans.map((s) => s.textContent));
  let idx = [];
  gloss.forEach((g, i) => { if (wordsSplit(g).some((x) => wordsSame(x, w))) idx.push(i); });
  // una parola uguale nelle due lingue (nomi, numeri)
  if (!idx.length) oTok.forEach((o, i) => { if (wordsSame(o, w)) idx.push(i); });
  if (!idx.length) {
    const cands = (await wordsBack(tSpans[ti].textContent, cur)).map(wordsNorm).filter(Boolean);
    oTok.forEach((o, i) => { if (cands.some((c) => wordsSame(o, c))) idx.push(i); });
  }
  return wordsNearest(idx, ti, tTok.length, oTok.length);
}

// Zona della frase dove dovrebbe stare la parola (quando non c'è una traduzione diretta)
function wordsZone(ti, nT, nO) {
  const c = wordsGuessAt(ti, nT, nO);
  return [c - 1, c, c + 1].filter((i) => i >= 0 && i < nO);
}

async function wordsAlignHover(tEl) {
  const cur = wordsCurrent;
  if (!cur || !cur.trans || !tEl.isConnected) return;
  const tSpans = [...lineTrans.querySelectorAll(".dualsub-tword")];
  const oSpans = [...lineOrig.querySelectorAll(".dualsub-word")];
  if (!oSpans.length) return;
  const ti = tSpans.indexOf(tEl);
  const tTok = tSpans.map((s) => wordsNorm(s.textContent)), oTok = oSpans.map((s) => wordsNorm(s.textContent));
  const key = cur.text + "\u0001" + cur.trans;
  // stessa frase ancora sullo schermo (l'oggetto della frase viene ricreato di continuo: confronto il testo)
  const sameLine = () => !!wordsCurrent && wordsCurrent.text + "\u0001" + wordsCurrent.trans === key;
  const still = () => sameLine() && tEl.isConnected && tEl.matches(":hover");

  // 1) allineamento del modello già pronto per questa frase
  const pairs = wordsAlignCache.get(key);
  const e = pairs ? wordsAlignMap(tTok, oTok, pairs).get(ti) : null;
  if (e && e.how === "particle") return wordsShowAlign(tEl, e);
  if (e && e.how === "model") {
    wordsShowAlign(tEl, e);
    // controllo con la traduzione parola per parola di Google (gratis, una richiesta per frase): se dice chiaramente
    // che la parola traduce un'altra parola dell'originale (il modello ha sbagliato di una), mostro quella
    if (tTok[ti].length < 2) return;
    const gloss = await wordsGloss(cur, oSpans.map((s) => s.textContent));
    if (!still()) return;
    const g = [];
    gloss.forEach((x, i) => { if (wordsSplit(x).some((w) => wordsSame(w, tTok[ti]))) g.push(i); });
    if (g.length === 1 && !e.o.includes(g[0])) wordsShowAlign(tEl, { o: g, how: "google", group: e.group });
    return;
  }

  // 2) con Google: la parola dell'originale che la traduce davvero
  wordsShowAlign(tEl, { o: [], how: "wait" });
  if (!pairs) wordsAskAlign(cur);
  const idx = await wordsGoogleFind(cur, ti, tSpans, oSpans);
  if (!still() || (!pairs && wordsAlignCache.has(key))) return;
  if (idx.length) return wordsShowAlign(tEl, { o: idx, how: "google" });
  if (wordsLlmAvailable() && wordsAlignPending(key)) return;   // aspetto il modello: rifarà questo passaggio quando risponde
  // 3) nessuna traduzione diretta: lo dico, e indico la zona della frase
  wordsShowAlign(tEl, { o: wordsZone(ti, tTok.length, oTok.length), how: "zone" });
}

// Una sola richiesta per frase: allineamento parola per parola e modi di dire dell'originale
const wordsAlignFailed = new Map();   // frase → quando è fallita (non riprovo subito, per non consumare quota)
function wordsAskAlign(cur) {
  // consuma richieste del modello passando il mouse: solo se l'hai acceso nel popup (spento di serie)
  // (per le frasi con ideogrammi serve comunque, anche con i modi di dire spenti: ricostruisce i nomi propri spezzati)
  const hanLine = !!cur && typeof DS_ROMAN !== "undefined" && DS_ROMAN.hasHan(cur.text || "");
  if (!cur || !cur.text || !cur.trans || !wordsLlmAvailable() || !settings || (settings.idioms !== true && !hanLine)) return;
  const key = cur.text + "\u0001" + cur.trans;
  if (wordsAlignCache.has(key) || wordsAlignAsked.has(key)) return;
  if (Date.now() - (wordsAlignFailed.get(key) || 0) < 60000) return;
  // insieme a questa frase chiedo anche le prossime già tradotte (una richiesta ogni 8 frasi invece di una per frase)
  const more = dsUpcomingLines(cur, 7).filter((x) => {
    const k = x.text + "\u0001" + x.trans;
    return !wordsAlignCache.has(k) && !wordsAlignAsked.has(k);
  });
  const keys = [key, ...more.map((x) => x.text + "\u0001" + x.trans)];
  keys.forEach((k) => wordsAlignAsked.add(k));
  const items = [{ original: cur.text, translation: cur.trans }, ...more.map((x) => ({ original: x.text, translation: x.trans }))];
  const e = dsTaskEngine("alignEngine") || wordsDefineEngine();   // «Collegamento parole e modi di dire» nel popup
  const done = (ok) => {
    keys.forEach((k) => wordsAlignAsked.delete(k));   // (se la frase esce dalla memoria si potrà richiedere)
    if (!ok) {
      wordsAlignFailed.set(key, Date.now());
      if (wordsAlignFailed.size > 300) wordsAlignFailed.delete(wordsAlignFailed.keys().next().value);
    }
    const same = !!wordsCurrent && wordsCurrent.text + "\u0001" + wordsCurrent.trans === key;
    if (same && ok) wordsMarkParticles();
    const hovered = lineTrans && lineTrans.querySelector(".dualsub-tword:hover");
    // ridisegno l'etichetta: con le coppie del modello, oppure (se è fallito) con Google
    if (hovered && same && !wordsCompare) wordsAlignHover(hovered);
  };
  DS_EXT.runtime.sendMessage({ type: "align", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl,
    original: cur.text, translation: cur.trans, items, lang: cur.lang || "", target: settings.targetLang })
    .then((r) => {
      if (!(r && r.pairs)) {
        if (r && r.daily) dsMarkBlocked(e.id, e.model);
        return done(false);
      }
      const res = r.results || [{ pairs: r.pairs, idioms: r.idioms }];
      res.forEach((x, i) => {
        if (!x || !x.pairs || !x.pairs.length || !keys[i]) return;
        wordsAlignCache.set(keys[i], x.pairs);
        if (settings.idioms === true) wordsAddIdioms(items[i].original, x.idioms || []);
        wordsHanLearn(x.pairs, items[i].original, cur.lang || "");
      });
      while (wordsAlignCache.size > 400) wordsAlignCache.delete(wordsAlignCache.keys().next().value);
      done(true);
    }).catch(() => done(false));
}

// ---------- Modi di dire ----------
// Modi di dire segnalati da te: { "testo normalizzato": { bad: true } | { meaning: "corretto" } } (restano salvati)
let wordsIdiomFlags = {};
DS_EXT.storage.local.get({ idiomFlags: {} }).then((r) => { wordsIdiomFlags = r.idiomFlags || {}; }).catch(() => {});
const wordsIdiomKey = (t) => wordsSplit(t).join(" ");
async function wordsIdiomFlag(text, patch) {
  const k = wordsIdiomKey(text);
  if (!k) return;
  if (patch) wordsIdiomFlags[k] = { ...(wordsIdiomFlags[k] || {}), ...patch, at: Date.now() }; else delete wordsIdiomFlags[k];
  const keys = Object.keys(wordsIdiomFlags);
  for (const x of keys.slice(0, Math.max(0, keys.length - 2000))) delete wordsIdiomFlags[x];
  await DS_EXT.storage.local.set({ idiomFlags: wordsIdiomFlags }).catch(() => {});
  wordsMarkIdioms();
}
const wordsIdiomBad = (t) => !!(wordsIdiomFlags[wordsIdiomKey(t)] || {}).bad;
const wordsIdiomMeaning = (t, m) => (wordsIdiomFlags[wordsIdiomKey(t)] || {}).meaning || m || "";
// un "modo di dire" che è quasi tutta la frase (o molto lungo) è un errore del modello: non lo sottolineo
function wordsIdiomPlausible(expr, sentence) {
  const e = wordsSplit(expr), all = wordsSplit(sentence);
  if (e.length < 2 || e.length > 7) return false;
  // ogni parola dell'espressione deve essere nella frase (anche attaccata a un prefisso: «بالغيب»); mai un'espressione
  // tradotta o in un'altra lingua
  const sent = " " + all.map(wordsNorm).join(" ") + " ";
  if (!e.map(wordsNorm).filter(Boolean).every((w) => sent.includes(w))) return false;
  if (all.length >= 3 && e.length >= Math.max(3, Math.ceil(all.length * 0.75))) return false;
  return !wordsIdiomBad(expr);
}

// Modi di dire trovati dal modello nella scheda, ricordati (anche chiudendo il browser): se una spiegazione dopo
// (per esempio rifatta con un altro servizio) non lo riporta, la scheda mostra comunque quello trovato prima.
// Solo per la scheda: non sottolinea niente nei sottotitoli.
const wordsIdiomMemory = new Map();   // frase → [{ text, meaning }]
let wordsIdiomMemTimer = 0;
DS_EXT.storage.local.get({ idiomMemory: {} }).then((r) => {
  for (const [k, v] of Object.entries(r.idiomMemory || {})) if (!wordsIdiomMemory.has(k) && Array.isArray(v)) wordsIdiomMemory.set(k, v);
}).catch(() => {});
function wordsRememberIdiom(sentence, text, meaning) {
  if (!sentence || !text) return;
  const list = wordsIdiomMemory.get(sentence) || [];
  const old = list.find((x) => wordsNorm(x.text) === wordsNorm(text));
  if (old) { if (meaning) old.meaning = meaning; } else list.push({ text: String(text).trim(), meaning: String(meaning || "") });
  wordsIdiomMemory.delete(sentence); wordsIdiomMemory.set(sentence, list);
  while (wordsIdiomMemory.size > 2000) wordsIdiomMemory.delete(wordsIdiomMemory.keys().next().value);
  clearTimeout(wordsIdiomMemTimer);
  wordsIdiomMemTimer = setTimeout(() => DS_EXT.storage.local.set({ idiomMemory: Object.fromEntries(wordsIdiomMemory) }).catch(() => {}), 1000);
}
function wordsRememberedIdiom(sentence, word) {
  const w = wordsNorm(word);
  return (wordsIdiomMemory.get(sentence) || []).find((x) => wordsSplit(x.text).some((p) => wordsNorm(p) === w)) || null;
}

function wordsAddIdioms(text, list) {
  const have = wordsIdioms.get(text) || [];
  for (const it of list) {
    if (!it || !String(it.text || "").trim()) continue;
    if (!wordsIdiomPlausible(it.text, text)) continue;
    const k = wordsNorm(it.text);
    const old = have.find((x) => wordsNorm(x.text) === k);
    if (old) { if (!old.meaning && it.meaning) old.meaning = it.meaning; }
    else have.push({ text: String(it.text).trim(), meaning: String(it.meaning || "") });
  }
  wordsIdioms.set(text, have);
  if (wordsIdioms.size > 300) wordsIdioms.delete(wordsIdioms.keys().next().value);
  if (wordsCurrent && wordsCurrent.text === text) wordsMarkIdioms();
}

// Posizione di un'espressione tra le parole della frase mostrata (indici delle parole)
function wordsFindExpr(text) {
  if (!lineOrig) return [];
  const oSpans = [...lineOrig.querySelectorAll(".dualsub-word")];
  return wordsLocate(oSpans.map((s) => wordsNorm(s.textContent)), text, 0).map((k) => oSpans[k]).filter(Boolean);
}

// ---------- Modi di dire senza richieste in più (1.6.0) ----------
// 1. trovati dal modello nella stessa richiesta della traduzione dei sottotitoli: restano in memoria (wordsIdiomMemory)
function wordsTrIdioms(texts, list) {
  for (const it of list) {
    const t = texts[it.i];
    if (!t || !wordsIdiomPlausible(it.text, t)) continue;
    wordsRememberIdiom(t, it.text, it.meaning);
    wordsAddIdioms(t, [{ text: it.text, meaning: it.meaning }]);
  }
}
// 2. il dizionario dei modi di dire di Wiktionary per la lingua del video (scaricato una volta, cercato qui)
const wordsDict = { lang: "", loading: "", first: new Map(), whole: [] };
// (wordsNorm toglie gli apostrofi: «one's» → «ones»)
const WORDS_FILLER = new Set(["ones", "someone", "someones", "somebody", "somebodys", "something", "somethings", "oneself", "sb", "sth", "x", "y"]);
const WORDS_POSS = new Set(["my", "your", "his", "her", "its", "our", "their", "ones"]);
const WORDS_POSS_SLOT = new Set(["ones", "someones", "somebodys", "somethings"]);
function wordsDictLoad(lang) {
  lang = String(lang || "").split("-")[0].toLowerCase();
  if (!lang || wordsDict.lang === lang || wordsDict.loading === lang) return;
  wordsDict.loading = lang;
  DS_EXT.runtime.sendMessage({ type: "idiomDict", lang }).then((r) => {
    if (wordsDict.loading !== lang) return;
    wordsDict.lang = lang; wordsDict.loading = ""; wordsDict.first = new Map(); wordsDict.whole = [];
    const spaced = !/^(ja|zh|th|lo|km|my)$/.test(lang);
    for (const title of (r && r.list) || []) {
      if (!spaced) { if (title.length >= 3) wordsDict.whole.push(title); continue; }
      const toks = wordsSplit(title).map(wordsNorm).filter(Boolean);
      // almeno due parole, e non solo parole brevi («at all», «of course» restano: hanno una parola di 4 lettere o sono lunghe)
      if (toks.length < 2 || toks.length > 8 || !toks.some((t) => t.length >= 4 && !WORDS_FILLER.has(t))) continue;
      const head = toks.find((t) => !WORDS_FILLER.has(t));
      const list = wordsDict.first.get(head) || [];
      list.push({ title, toks });
      wordsDict.first.set(head, list);
    }
    wordsDictChecked.clear();
    if (wordsCurrent) wordsMarkIdioms();
  }).catch(() => { wordsDict.loading = ""; });
}
// una parola della frase va bene per una parola del modo di dire: uguale, o con una desinenza (kick → kicked)
function wordsDictTok(tok, w) {
  if (tok === w) return true;
  if (tok.length >= 3 && w.startsWith(tok) && w.length - tok.length <= 3) return true;
  if (tok.length >= 4 && /e$/.test(tok) && w.startsWith(tok.slice(0, -1)) && w.length - tok.length <= 2) return true;
  return false;
}
// i modi di dire del dizionario in una frase (indici delle parole); «one's», «someone»… valgono per 0-3 parole qualsiasi
function wordsDictFind(words) {
  const found = [];
  for (let start = 0; start < words.length; start++) {
    const cands = (wordsDict.first.get(words[start]) || []).slice();
    for (const [w0, list] of wordsDict.first) if (w0 !== words[start] && w0.length >= 3 && wordsDictTok(w0, words[start])) cands.push(...list);
    for (const c of cands) {
      const head = c.toks.findIndex((t) => !WORDS_FILLER.has(t));
      let i = start, ok = head === 0 || head === -1;
      if (!ok) continue;
      for (let k = 0; k < c.toks.length && ok; k++) {
        const t = c.toks[k];
        if (WORDS_FILLER.has(t)) {
          // «one's» = un possessivo; «someone/something» = da 1 a 3 parole
          if (WORDS_POSS_SLOT.has(t)) { if (i < words.length && WORDS_POSS.has(words[i])) i++; else ok = false; }
          else { let j = i + 1; while (j < words.length && j - i < 3 && !wordsDictTok(c.toks[k + 1] || "\u0000", words[j])) j++; if (i >= words.length) ok = false; i = j; }
        } else if (i < words.length && wordsDictTok(t, words[i])) i++;
        else ok = false;
      }
      if (ok) found.push({ title: c.title, from: start, to: i - 1 });
    }
  }
  return found;
}
const wordsDictChecked = new Set();
function wordsDictMark(cur) {
  if (!cur || !cur.text || !lineOrig || wordsDictChecked.has(cur.text)) return;
  const lang = (cur.lang || "").split("-")[0] || DualSubs.guessLang(cur.text) || "";
  wordsDictLoad(lang);
  if (wordsDict.lang !== lang.toLowerCase()) return;
  wordsDictChecked.add(cur.text);
  if (wordsDictChecked.size > 2000) wordsDictChecked.delete(wordsDictChecked.values().next().value);
  const spans = [...lineOrig.querySelectorAll(".dualsub-word")];
  const out = [];
  if (wordsDict.whole.length) {
    for (const t of wordsDict.whole) if (cur.text.includes(t)) out.push({ text: t, meaning: "" });
  } else {
    const words = spans.map((s) => wordsNorm(s.textContent));
    for (const f of wordsDictFind(words)) out.push({ text: wordsRangeText(spans.slice(f.from, f.to + 1)), meaning: "", dict: f.title });
  }
  if (out.length) wordsAddIdioms(cur.text, out);
}

function wordsMarkIdioms() {
  if (!lineOrig || !wordsCurrent) return;
  lineOrig.querySelectorAll(".dualsub-idiom").forEach((s) => { s.classList.remove("dualsub-idiom"); delete s.dataset.idiom; });
  // 1.6.0: si sottolineano sempre (spento solo da «Sottolinea i modi di dire»): quelli del dizionario, quelli trovati
  // nella traduzione e quelli già visti; il modello frase per frase solo con «idioms» acceso
  if (settings && settings.idiomsUnderline === false) return;
  const mem = wordsIdiomMemory.get(wordsCurrent.text);
  if (mem && mem.length && !(wordsIdioms.get(wordsCurrent.text) || []).length) { wordsAddIdioms(wordsCurrent.text, mem); return; }
  if (!wordsDictChecked.has(wordsCurrent.text)) { wordsDictMark(wordsCurrent); if (wordsDictChecked.has(wordsCurrent.text) && (wordsIdioms.get(wordsCurrent.text) || []).length) return; }
  (wordsIdioms.get(wordsCurrent.text) || []).forEach((it, n) => {
    if (!wordsIdiomPlausible(it.text, wordsCurrent.text)) return;
    const spans = wordsFindExpr(it.text);
    if (spans.length < 2 || spans.length > wordsSplit(it.text).length + 1) return;
    spans.forEach((s) => { if (s.dataset.idiom == null) { s.classList.add("dualsub-idiom"); s.dataset.idiom = String(n); } });
  });
}

// L'espressione a cui appartiene una parola sottolineata
function wordsIdiomOf(w) {
  if (!w || w.dataset.idiom == null || !wordsCurrent) return null;
  const it = (wordsIdioms.get(wordsCurrent.text) || [])[Number(w.dataset.idiom)];
  if (!it) return null;
  const spans = wordsFindExpr(it.text);
  return spans.length ? { text: wordsRangeText(spans), meaning: wordsIdiomMeaning(it.text, it.meaning), spans, fromWord: w.textContent.trim(), idiom: true } : null;
}

function wordsRangeText(spans) {
  try {
    const r = document.createRange();
    r.setStartBefore(spans[0]);
    r.setEndAfter(spans[spans.length - 1]);
    return r.toString().replace(/\s+/g, " ").trim();
  } catch { return spans.map((s) => s.textContent).join(" "); }
}

function wordsPaint(cls, spans) {
  if (!overlay) return;
  overlay.querySelectorAll("." + cls).forEach((x) => x.classList.remove(cls));
  (spans || []).forEach((s) => s.classList.add(cls));
}

// Selezione a mano: tieni premuto sulla prima parola e trascina fino all'ultima
function wordsSelSpans() {
  if (!wordsSel || !lineOrig) return [];
  const all = [...lineOrig.querySelectorAll(".dualsub-word")];
  const a = Math.min(wordsSel.start, wordsSel.end), b = Math.max(wordsSel.start, wordsSel.end);
  return all.slice(a, b + 1);
}

function wordsTSelSpans() {
  if (!wordsTSel || !lineTrans) return [];
  const all = [...lineTrans.querySelectorAll(".dualsub-tword")];
  const a = Math.min(wordsTSel.start, wordsTSel.end), b = Math.max(wordsTSel.start, wordsTSel.end);
  return all.slice(a, b + 1);
}

function wordsEndCompare() {
  wordsCompare = null;
  wordsPaint("dualsub-tsel", []);
  wordsClearAlign();
}

// Parte della traduzione selezionata → la parte corrispondente dell'originale, illuminata e scritta nell'etichetta
async function wordsCompareShow(tSpans) {
  const cur = wordsCurrent;
  if (!cur || !cur.trans || !tSpans.length) return;
  const key = cur.text + "\u0001" + cur.trans;
  wordsCompare = { key, tSpans };
  wordsPaint("dualsub-tsel", tSpans);
  const all = [...lineTrans.querySelectorAll(".dualsub-tword")];
  const oSpans = [...lineOrig.querySelectorAll(".dualsub-word")];
  const oTok = oSpans.map((s) => wordsNorm(s.textContent));
  const show = (idx, how) => {
    if (!wordsCompare || wordsCompare.key !== key) return;
    idx = [...new Set(idx)].sort((a, b) => a - b);
    // senza buchi: dalla prima all'ultima parola trovata (una frase si confronta per intero)
    const span = idx.length ? oSpans.slice(idx[0], idx[idx.length - 1] + 1) : [];
    const hit = wordsShowAlign(tSpans[Math.floor(tSpans.length / 2)], { o: span.map((s) => oSpans.indexOf(s)), how: how === "zone" ? "zone" : how });
    tSpans.forEach((t) => t.classList.add("dualsub-hl"));
    if (!wordsAlignTip) return;
    wordsAlignTip.textContent = "";
    if (how === "wait" || !hit.length) {
      wordsAlignTip.append(el("span", null, "Cerco la parte corrispondente nell'originale…"));
      return;
    }
    wordsAlignTip.append(el("b", null, wordsRangeText(hit)));
    const more = el("button", "dualsub-tip-btn", "Spiega");
    more.title = "Apri la scheda con il significato di questa parte dell'originale";
    more.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const spans = hit;
      wordsEndCompare();
      wordsOpenCard(spans[Math.floor(spans.length / 2)], true, { text: wordsRangeText(spans), spans });
    });
    const cp = el("button", "dualsub-tip-btn", "Copia");
    cp.title = "Copia la parte originale e la parte della traduzione scelta";
    cp.addEventListener("click", (ev) => { ev.stopPropagation(); wordsCopy(wordsRangeText(hit) + "\n" + wordsRangeText(tSpans), cp); });
    wordsAlignTip.append(el("span", null, how === "zone" ? "  ·  zona corrispondente, circa  " : how === "google" ? "  ·  circa  " : "  "), more, el("span", null, " "), cp);
    const src = (cur.lang || "").split("-")[0] || DualSubs.guessLang(cur.text) || "";
    wordsAlignTip.append(wordsLinksRow(() => wordsRangeText(hit), src, settings.targetLang, hit.length <= 3));
  };
  const tIdx = tSpans.map((t) => all.indexOf(t));
  // con Google: per ogni parola scelta, la parola dell'originale che la traduce
  const viaGoogle = async (list) => {
    const out = [];
    for (const i of list) out.push(...(await wordsGoogleFind(cur, i, all, oSpans)));
    return out;
  };
  // 1) allineamento del modello già pronto (o in arrivo)
  const fromPairs = async () => {
    const pairs = wordsAlignCache.get(key);
    if (!pairs) return null;
    const map = wordsAlignMap(all.map((s) => wordsNorm(s.textContent)), oTok, pairs);
    const known = tIdx.filter((i) => map.has(i) && map.get(i).how !== "lost");
    const lost = tIdx.filter((i) => !known.includes(i));
    const idx = known.flatMap((i) => map.get(i).o);
    if (lost.length) idx.push(...(await viaGoogle(lost)));
    return { idx, how: lost.length ? "google" : "model" };
  };
  let got = await fromPairs();
  if (got && got.idx.length) return show(got.idx, got.how);
  show([], "wait");
  if (!got && wordsLlmAvailable()) {
    wordsAskAlign(cur);
    for (let i = 0; i < 40 && wordsCompare && wordsCompare.key === key && wordsAlignPending(key); i++) {
      await new Promise((r) => setTimeout(r, 500));
      if (!wordsAlignCache.has(key)) continue;
      got = await fromPairs();
      if (got && got.idx.length) return show(got.idx, got.how);
      break;
    }
    if (!got && wordsAlignCache.has(key)) {
      got = await fromPairs();
      if (got && got.idx.length) return show(got.idx, got.how);
    }
  }
  // 2) con Google (gratis): le parole dell'originale che traducono quelle scelte
  if (!wordsCompare || wordsCompare.key !== key) return;
  const idx = await viaGoogle(tIdx);
  if (!wordsCompare || wordsCompare.key !== key) return;
  if (idx.length) return show(idx, "google");
  // 3) nessuna traduzione diretta: la zona corrispondente della frase
  const nT = all.length, nO = oTok.length;
  const lo = wordsGuessAt(Math.min(...tIdx), nT, nO), hi = wordsGuessAt(Math.max(...tIdx), nT, nO);
  const zone = [];
  for (let i = lo; i <= hi; i++) zone.push(i);
  show(zone, "zone");
}

function wordsEndTSelect() {
  if (!wordsTSel) return false;
  const spans = wordsTSel.moved ? wordsTSelSpans() : [];
  wordsTSel = null;
  if (spans.length < 2) { if (!wordsCompare) wordsPaint("dualsub-tsel", []); return false; }
  wordsNoClickUntil = Date.now() + 300;
  wordsCompareShow(spans);
  return true;
}

function wordsEndSelect() {
  if (wordsEndTSelect()) return;
  if (!wordsSel) return;
  const spans = wordsSel.moved ? wordsSelSpans() : [];
  wordsSel = null;
  if (spans.length < 2) { if (!(wordsCardState && wordsCardState.expr)) wordsPaint("dualsub-sel", []); return; }
  wordsNoClickUntil = Date.now() + 300;
  wordsOpenCard(spans[Math.floor(spans.length / 2)], true, { text: wordsRangeText(spans), spans });
}

// Al contrario: parola dell'originale → la sua traduzione. Con la frase allineata dal modello è preciso; altrimenti
// (modello spento o frase non ancora allineata) uso le traduzioni del dizionario di Google della parola (gratis) e
// illumino le parole della traduzione che corrispondono, anche con un'altra desinenza (gatto/gatti).
const wordsRevCache = new Map();   // "lingua|parola|arrivo" → traduzioni possibili (normalizzate)
function wordsReverseClear() {
  overlay.querySelectorAll(".dualsub-tword.dualsub-hl, .dualsub-tword.dualsub-hl-group").forEach((x) => x.classList.remove("dualsub-hl", "dualsub-hl-group"));
}
function wordsReverseHover(oEl) {
  const cur = wordsCurrent;
  if (!cur || !cur.trans) return;
  const tSpans = [...lineTrans.querySelectorAll(".dualsub-tword")];
  const oSpans = [...lineOrig.querySelectorAll(".dualsub-word")];
  const oi = oSpans.indexOf(oEl);
  wordsReverseClear();
  const pairs = wordsAlignCache.get(cur.text + "\u0001" + cur.trans);
  if (pairs) {
    const map = wordsAlignMap(tSpans.map((x) => wordsNorm(x.textContent)), oSpans.map((x) => wordsNorm(x.textContent)), pairs);
    let hit = false;
    for (const [ti, e] of map) {
      if (!e.o.includes(oi)) continue;
      // la traduzione vera piena, le particelle che la accompagnano più tenui
      if (e.how === "model") { tSpans[ti].classList.add("dualsub-hl"); hit = true; }
      else if (e.how === "particle") tSpans[ti].classList.add("dualsub-hl-group");
    }
    if (hit) return;
  }
  wordsReverseGoogle(oEl, cur, tSpans);
}
// due parole "uguali" a meno della desinenza: stessa radice (almeno 4 lettere) e poca differenza in fondo
function wordsStemSame(a, b) {
  if (!a || !b) return false;
  if (a === b) return true;
  const min = Math.min(a.length, b.length);
  if (min < 4) return false;
  let i = 0;
  while (i < a.length && i < b.length && a[i] === b[i]) i++;
  // pane/pani, gatto/gatti, mangiare/mangiato sì; parlo/parte, casa/cane no
  return i >= Math.max(3, min <= 5 ? min - 1 : min - 2) && Math.max(a.length, b.length) - i <= 3;
}
async function wordsReverseGoogle(oEl, cur, tSpans) {
  const word = dsCleanWord(oEl.textContent || "");
  if (!word) return;
  const k = [(cur.lang || "").split("-")[0], word.toLowerCase(), settings.targetLang].join("|");
  let cands = wordsRevCache.get(k);
  if (!cands) {
    let g = null;
    try { g = await DS_EXT.runtime.sendMessage({ type: "define", engine: "google", target: settings.targetLang, word, sentence: cur.text, lang: cur.lang || "" }); } catch {}
    const list = [];
    const add = (t) => { for (const w of wordsSplit(String(t || ""))) { const n = wordsNorm(w); if (n && !list.includes(n)) list.push(n); } };
    if (g && !g.error) {
      add(g.meaning);
      for (const a of (g.gdict && g.gdict.alt) || []) for (const it of a.items || []) add(it.word);
    }
    cands = list;
    wordsRevCache.set(k, cands);
    if (wordsRevCache.size > 600) wordsRevCache.delete(wordsRevCache.keys().next().value);
  }
  // nel frattempo il mouse è andato altrove, o la frase è cambiata
  if (!oEl.isConnected || !oEl.matches(":hover") || wordsCurrent !== cur) return;
  if (!cands.length) return;
  // le parole corte (articoli, preposizioni: «il», «di») solo se uguali e se la parola è corta anche nell'originale
  const short = wordsNorm(word).length <= 3;
  for (const t of tSpans) {
    const n = wordsNorm(t.textContent);
    if (!n || (n.length <= 2 && !short)) continue;
    if (cands.some((c) => wordsStemSame(n, c))) t.classList.add("dualsub-hl");
  }
}

function wordsRenderOriginal(text, lang) {
  const knownOn = settings && settings.learnKnown !== false && settings.learnKnownPage !== false && typeof DS_KNOWN !== "undefined";
  const romanOn = !!(settings && settings.roman && typeof DS_ROMAN !== "undefined" && DS_ROMAN.needs(text));
  const key = text + "\u0001" + vocabVersion + "\u0001" + (knownOn ? DS_KNOWN.version : "") + "\u0001" + (romanOn ? "r" + (settings.romanHan !== false ? "h" : "") : "") + "\u0001" + wordsHanJoinV + (settings && settings.levelColors ? "L" : "");
  if (key === wordsOrigKey) return;
  wordsOrigKey = key;
  lineOrig.textContent = "";
  if (!text) return;
  for (const part of wordsTokenize(text, lang)) {
    if (!part.word) { lineOrig.append(part.text); continue; }
    const span = document.createElement("span");
    span.className = "dualsub-word" + (vocabHas(lang, part.text) ? " dualsub-saved" : "") +
      (knownOn && DS_KNOWN.has((lang || "").split("-")[0], dsCleanWord(part.text)) ? " dualsub-known" : "");
    if (romanOn) wordsRomanize(span, part.text, lang); else span.textContent = part.text;
    lineOrig.append(span);
  }
  if (settings && settings.levelColors === true) wordsLevelMark(lang);
  lineOrig.classList.toggle("dualsub-roman", romanOn);
  if (romanOn && DS_ROMAN.rtl(text)) lineOrig.dir = "rtl"; else lineOrig.removeAttribute("dir");
  wordsRomanLine(romanOn && settings.romanHan !== false && DS_ROMAN.hasHan(text) ? text : "", lang, [...lineOrig.querySelectorAll(".dualsub-word")]);
  wordsMarkIdioms();
  wordsMarkParticles();
}

// ---------- Colore per livello (frequenza della parola nella sua lingua) ----------
// 1.7.30: ≤1000 (molto comune) resta del colore normale, ≤5000 celeste, ≤15000 giallo, più rara (o non nell'elenco) arancio.
// La posizione la calcola il sottofondo (DS_FREQ.rank) e si ricorda; se la lingua non ha l'elenco, niente cambia.
function wordsLevelMark(lang) {
  if (typeof DS_FREQ === "undefined") return;
  const key = wordsOrigKey;
  for (const sp of lineOrig.querySelectorAll(".dualsub-word")) {
    const w = dsCleanWord(sp.textContent || "");
    if (!w) continue;
    DS_FREQ.rank(w, lang).then((r) => {
      if (wordsOrigKey !== key || !sp.isConnected || r == null) return;
      const lv = r === 0 || r > 15000 ? 4 : r <= 1000 ? 1 : r <= 5000 ? 2 : 3;
      sp.classList.add("dualsub-lv" + lv);
      sp.title = sp.title || DS_FREQ.label(r);
    }).catch(() => {});
  }
}

// ---------- Lettere latine sopra le lettere (DS_ROMAN, roman.js): si accende e spegne con "Aa" accanto ai sottotitoli ----------
// La trascrizione è disegnata dal CSS (attributo data-r), quindi non entra nel testo copiato né nelle ricerche.
function wordsRomanize(span, word, lang) {
  span.textContent = "";
  if (DS_ROMAN.rtl(word)) span.dir = "rtl";
  for (const u of DS_ROMAN.units(word, lang)) {
    const x = document.createElement("span");
    x.className = "dsr" + (u.han ? " dsr-han" : "");
    x.dataset.r = u.r || "";
    x.textContent = u.t;
    span.append(x);
  }
}
// righe con kanji o caratteri cinesi: la lettura di tutta la riga (Google, gratis), sopra il sottotitolo
let wordsRomanLineText = "";
function wordsRomanLine(text, lang, spans) {
  let row = overlay && overlay.querySelector(".dualsub-romaline");
  if (!text) { if (row) row.hidden = true; wordsRomanLineText = ""; return; }
  if (!row) {
    row = document.createElement("div"); row.className = "dualsub-romaline"; lineOrig.before(row);
    // 1.7.26: passando il mouse su una parola della lettura si illumina la parola nell'originale (e un clic la apre)
    row.addEventListener("mouseover", (e) => {
      const w = e.target.closest && e.target.closest(".dsr-w");
      const o = w && lineOrig.querySelectorAll(".dualsub-word")[Number(w.dataset.i)];
      wordsPaint("dualsub-hl", o ? [o] : []);
    });
    row.addEventListener("mouseout", (e) => { if (e.target.closest && e.target.closest(".dsr-w")) wordsPaint("dualsub-hl", []); });
    row.addEventListener("click", (e) => {
      const w = e.target.closest && e.target.closest(".dsr-w");
      const o = w && lineOrig.querySelectorAll(".dualsub-word")[Number(w.dataset.i)];
      if (o) wordsOpenCard(o, true, null);
    });
  }
  const words = (spans || []).map((s) => s.textContent);
  const key = text + "\u0001" + words.join("\u0002");
  if (wordsRomanLineText === key) { row.hidden = !row.textContent; return; }
  wordsRomanLineText = key;
  row.textContent = ""; row.hidden = true;
  const whole = () => DS_EXT.runtime.sendMessage({ type: "romanLine", text, lang }).then((r) => {
    if (wordsRomanLineText !== key || !r || !r.text) return;
    row.textContent = r.text; row.hidden = false;
    row.title = "Lettura della riga (Google, gratis): i kanji e i caratteri cinesi hanno più letture, quindi non c'è sopra ogni carattere";
  }).catch(() => {});
  if (!words.length) return whole();
  // lettura parola per parola (le parole con ideogrammi da Google, le altre dalla tabella): ognuna è legata alla sua parola
  const han = words.map((w) => DS_ROMAN.hasHan(w));
  DS_EXT.runtime.sendMessage({ type: "romanWords", words: words.filter((_, i) => han[i]), lang }).then((r) => {
    if (wordsRomanLineText !== key) return;
    const rd = r && r.readings;
    if (!rd || rd.length !== han.filter(Boolean).length || rd.some((x) => !x)) return whole();
    let k = 0;
    words.forEach((w, i) => {
      const t = han[i] ? rd[k++] : DS_ROMAN.word(w, lang);
      if (!t) return;
      const s = document.createElement("span");
      s.className = "dsr-w"; s.dataset.i = i; s.textContent = t;
      if (row.firstChild) row.append(" ");
      row.append(s);
    });
    row.hidden = !row.textContent;
    row.title = "Lettura parola per parola (Google, gratis): passa col mouse su una parola per vederla nell'originale, clic per aprirla";
  }).catch(() => whole());
}
function wordsRomanButton() {
  const b = document.createElement("button");
  b.className = "dualsub-fixbtn dualsub-romabtn";
  b.textContent = "Aa";
  b.addEventListener("click", async (e) => {
    e.stopPropagation();
    settings.roman = !settings.roman;
    wordsOrigKey = "";
    if (wordsCurrent) wordsRenderOriginal(wordsCurrent.text, wordsCurrent.lang);
    wordsRomanButtonUpdate();
    await DS_EXT.storage.sync.set({ roman: settings.roman });
  });
  return b;
}
function wordsRomanButtonUpdate() {
  const b = overlay && overlay.querySelector(".dualsub-romabtn");
  if (!b) return;
  const on = !!(settings && settings.roman);
  b.classList.toggle("on", on);
  b.setAttribute("aria-pressed", String(on));
  b.title = on ? "Lettere latine sopra le parole: accese (clic per spegnerle)" : "Lettere latine sopra le parole (cirillico, greco, arabo, ebraico, giapponese, coreano, hindi…): clic per accenderle";
  b.hidden = !(wordsCurrent && typeof DS_ROMAN !== "undefined" && DS_ROMAN.needs(wordsCurrent.text));
}

// ---------- Eventi del mouse sui sottotitoli ----------
function wordsSetup() {
  // I clic sui sottotitoli non devono arrivare al player (che metterebbe in pausa/play)
  for (const type of ["click", "dblclick", "mousedown", "mouseup", "pointerdown", "pointerup", "touchstart"]) {
    overlay.addEventListener(type, (e) => e.stopPropagation());
  }
  overlay.addEventListener("mousedown", (e) => {
    const tw = e.button === 0 && e.target.closest && e.target.closest(".dualsub-tword");
    if (tw) {
      // selezione di più parole della traduzione, per confrontarle con l'originale
      e.preventDefault();
      if (wordsCompare) wordsEndCompare();
      const i = [...lineTrans.querySelectorAll(".dualsub-tword")].indexOf(tw);
      wordsTSel = { start: i, end: i, moved: false };
      return;
    }
    if (wordsCompare && !(e.target.closest && e.target.closest(".dualsub-align-tip"))) wordsEndCompare();
    const w = e.button === 0 && e.target.closest && e.target.closest(".dualsub-word");
    if (!w) return;
    e.preventDefault();   // niente selezione del testo del browser
    const i = [...lineOrig.querySelectorAll(".dualsub-word")].indexOf(w);
    wordsSel = { start: i, end: i, moved: false };
  });
  overlay.addEventListener("mouseup", wordsEndSelect);
  overlay.addEventListener("mouseover", (e) => {
    clearTimeout(wordsLeaveTimer);
    if (!wordsHovering) {
      wordsHovering = true;
      const v = getVideo();
      if (settings && settings.hoverPause && v && !v.paused && !wordsReplayUntil) { v.pause(); wordsAutoPaused = true; }
    }
    const w = e.target.closest && e.target.closest(".dualsub-word");
    const tw = e.target.closest && e.target.closest(".dualsub-tword");
    clearTimeout(wordsHoverTimer);
    // ti fermi sulle parole dell'originale: chiedo i modi di dire della frase (insieme all'allineamento, una richiesta).
    // Solo dopo un attimo, così passare sopra per andare al pulsante delle correzioni non consuma richieste.
    clearTimeout(wordsIdiomTimer);
    if (w && settings && settings.idioms !== false) wordsIdiomTimer = setTimeout(() => wordsAskAlign(wordsCurrent), 700);
    if (w && wordsCurrent && (!wordsReading || wordsReading.text !== wordsCurrent.text)) wordsMarkReading(wordsCurrent);
    if (wordsSel && w) {
      if (!(e.buttons & 1)) { wordsSel = null; }
      else {
        const i = [...lineOrig.querySelectorAll(".dualsub-word")].indexOf(w);
        if (i !== wordsSel.end) { wordsSel.end = i; wordsSel.moved = wordsSel.moved || i !== wordsSel.start; }
        wordsPaint("dualsub-sel", wordsSelSpans());
        return;
      }
    }
    const idiom = w ? wordsIdiomOf(w) : null;
    wordsPaint("dualsub-idiom-on", idiom ? idiom.spans : []);
    if (w && !(wordsCardState && wordsCardState.pinned)) {
      wordsHoverTimer = setTimeout(() => wordsOpenCard(w, false, idiom), 300);
    }
    if (w) wordsReverseHover(w);
    if (wordsTSel && tw && (e.buttons & 1)) {
      const i = [...lineTrans.querySelectorAll(".dualsub-tword")].indexOf(tw);
      if (i !== wordsTSel.end) { wordsTSel.end = i; wordsTSel.moved = wordsTSel.moved || i !== wordsTSel.start; }
      wordsPaint("dualsub-tsel", wordsTSelSpans());
      return;
    }
    if (wordsCompare) return;   // confronto aperto: resta finché non clicchi altrove
    if (tw) { clearTimeout(wordsAlignTimer); wordsAlignTimer = setTimeout(() => wordsAlignHover(tw), 180); }
    else if (!w && !(e.target.closest && e.target.closest(".dsr-w"))) wordsClearAlign();
  });
  overlay.addEventListener("mouseout", (e) => {
    const from = e.target.closest && e.target.closest(".dualsub-tword, .dualsub-word");
    const to = e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest(".dualsub-tword, .dualsub-word");
    if (from && from !== to && !wordsCompare) wordsClearAlign();
    if (from && !(to && to.dataset.idiom != null && to.dataset.idiom === from.dataset.idiom)) wordsPaint("dualsub-idiom-on", []);
  });
  overlay.addEventListener("mouseout", (e) => {
    if (e.relatedTarget && overlay.contains(e.relatedTarget)) return;
    clearTimeout(wordsHoverTimer);
    clearTimeout(wordsIdiomTimer);
    wordsLeaveTimer = setTimeout(wordsOnLeave, 400);
  });
  overlay.addEventListener("click", (e) => {
    if (Date.now() < wordsNoClickUntil) return;   // fine di una selezione a mano
    const w = e.target.closest && e.target.closest(".dualsub-word");
    if (w) {
      // parola dentro un modo di dire: il primo clic apre l'espressione, il secondo (con l'espressione già aperta)
      // apre la parola da sola; e di nuovo l'espressione al clic dopo
      const st = wordsCardState;
      const idiom = wordsIdiomOf(w);
      const inOpenIdiom = idiom && st && st.pinned && st.expr && st.expr.idiom && (st.expr.spans || []).includes(w);
      wordsOpenCard(w, true, inOpenIdiom ? null : idiom);
    }
    // clic su una parola della traduzione: scheda della parola originale corrispondente
    const tw = e.target.closest && e.target.closest(".dualsub-tword");
    if (tw) {
      // se la parte corrispondente ha più parole, apro la più lunga (di solito quella che porta il significato)
      const hl = [...lineOrig.querySelectorAll(".dualsub-word.dualsub-hl")];
      const o = hl.reduce((a, b) => (!a || b.textContent.length > a.textContent.length ? b : a), null);
      if (o) { wordsClearAlign(); wordsOpenCard(o, true); }
    }
  });
}

function wordsOnLeave() {
  wordsHovering = false;
  if (wordsCardState && wordsCardState.pinned) return;
  wordsCloseCard();
}

function wordsResume() {
  if (wordsAutoPaused) {
    wordsAutoPaused = false;
    const v = getVideo();
    if (v && v.paused) v.play().catch(() => {});
  }
}

// Se la scheda sparisce sotto il mouse, il browser non segnala l'uscita dai sottotitoli:
// me ne accorgo quando il mouse passa su qualcos'altro della pagina
document.addEventListener("mouseover", (e) => {
  // il mouse è sopra la scheda anche se un altro elemento della pagina la copre: non la chiudo
  if (wordsCard && wordsCard.isConnected) {
    const r = wordsCard.getBoundingClientRect();
    if (e.clientX >= r.left - 4 && e.clientX <= r.right + 4 && e.clientY >= r.top - 4 && e.clientY <= r.bottom + 4) { clearTimeout(wordsLeaveTimer); return; }
  }
  if (wordsHovering && overlay && !overlay.contains(e.target)) {
    clearTimeout(wordsLeaveTimer);
    wordsLeaveTimer = setTimeout(wordsOnLeave, 400);
  }
}, true);

document.addEventListener("mouseup", () => wordsEndSelect(), true);
document.addEventListener("mousedown", (e) => {
  if (wordsCardState && wordsCardState.pinned && overlay && !overlay.contains(e.target)) wordsCloseCard();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && wordsCompare) wordsEndCompare();
  if (e.key === "Escape" && wordsCardState) wordsCloseCard();
});

// ---------- Scheda della parola ----------
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}

function wordsCloseCard() {
  wordsReqId++;
  wordsCardState = null;
  if (wordsCard) { wordsCard.remove(); wordsCard = null; }
  if (overlay) overlay.classList.remove("dualsub-cardopen");
  wordsPaint("dualsub-sel", []);
  wordsPaint("dualsub-idiom-near", []);
  if (!wordsHovering) wordsResume();
}

// maniglia ⠿ per spostare la scheda (1.6.6)
function wordsGrip(st) {
  return dsCardGrip("dualsub-card-grip", {
    start() {
      const r = wordsCard.getBoundingClientRect(), or = overlay.getBoundingClientRect();
      st.dragging = true; st.pinned = true; st.noUser = false;
      return { cx: r.left + r.width / 2 - or.left, top: r.top - or.top, h: r.height };
    },
    move(s, dx, dy) {
      if (!wordsCard) return;
      wordsCard.style.bottom = "auto";
      wordsCard.style.left = s.cx + dx + "px";
      wordsCard.style.top = s.top + dy + "px";
      wordsCard.style.maxHeight = "";
    },
    end() {
      st.dragging = false;
      const player = dsPlayerBox();
      if (!wordsCard || !player) return;
      const pr = player.getBoundingClientRect(), r = wordsCard.getBoundingClientRect();
      dsCardUserSet("video", { ...(dsCardUser.video || {}), fx: (r.left + r.width / 2 - pr.left) / pr.width, fy: (r.top - pr.top) / pr.height });
      wordsReplace();
    },
    reset() { st.dragging = false; dsCardUserSet("video", null); st.noUser = true; wordsReplace(); }
  });
}
// 1.7.5: ridimensionare la scheda dai bordi e dagli angoli (dsCardResizer in config.js); grandezza e posizione restano per le schede dopo
function wordsResizer(st) {
  return dsCardResizer(wordsCard, {
    z: 71,
    hold() { st.pinned = true; },
    start() { st.dragging = true; st.pinned = true; st.noUser = false; return { or: overlay.getBoundingClientRect() }; },
    apply(g, s) {
      if (!wordsCard) return;
      wordsCard.style.bottom = "auto";
      wordsCard.style.width = g.w + "px"; wordsCard.style.maxWidth = g.w + "px";
      if (g.hTouched || (dsCardUser.video && dsCardUser.video.h)) { wordsCard.style.height = g.h + "px"; wordsCard.style.maxHeight = g.h + "px"; }
      wordsCard.style.left = g.l + g.w / 2 - s.or.left + "px";   // (la scheda è centrata sul suo «left»)
      wordsCard.style.top = g.t - s.or.top + "px";
    },
    end(g) {
      st.dragging = false;
      const player = dsPlayerBox();
      if (!wordsCard || !player) return;
      const pr = player.getBoundingClientRect(), r = wordsCard.getBoundingClientRect(), u = dsCardUser.video || {};
      const o = { fx: (r.left + r.width / 2 - pr.left) / pr.width, fy: (r.top - pr.top) / pr.height, w: Math.round(r.width) };
      if (g.hTouched || u.h) o.h = Math.round(r.height);
      dsCardUserSet("video", o);
      wordsReplace();
    }
  });
}
function wordsPlace(anchor) {
  const player = dsPlayerBox();
  if (!wordsCard || !player || !anchor.isConnected) return;
  const pr = player.getBoundingClientRect(), or = overlay.getBoundingClientRect(), wr = anchor.getBoundingClientRect();
  // 1.7.5: grandezza scelta da te con le maniglie sui bordi (se l'hai cambiata); altrimenti quella automatica
  const uz = dsCardUser.video;
  if (wordsCardState.dragging) { /* sto trascinando o ridimensionando: ci pensa il gesto */ }
  else if (uz && uz.w && !wordsCardState.noUser) { wordsCard.style.width = uz.w + "px"; wordsCard.style.maxWidth = uz.w + "px"; }
  else if (wordsCard.style.width) { wordsCard.style.width = ""; wordsCard.style.maxWidth = ""; wordsCard.style.height = ""; }
  const cw = wordsCard.offsetWidth || 300;
  let center = wr.left + wr.width / 2 - pr.left;
  // posizione scelta nel popup (🗒 Aspetto delle schede): sopra la parola, oppure sempre a sinistra o a destra del video
  if (settings.cardPosVideo === "left") center = cw / 2 + 8;
  else if (settings.cardPosVideo === "right") center = pr.width - cw / 2 - 8;
  center = Math.max(cw / 2 + 8, Math.min(pr.width - cw / 2 - 8, center));
  // 1.6.6: posizione scelta da te trascinando la scheda (⠿): frazioni del lettore, valgono anche a schermo intero
  const u = dsCardUser.video;
  if (u && !wordsCardState.noUser && !wordsCardState.dragging) {
    const ch = wordsCard.offsetHeight || 200;
    const cx = Math.max(cw / 2 + 4, Math.min(window.innerWidth - cw / 2 - 4, pr.left + u.fx * pr.width));
    const top = Math.max(4, Math.min(window.innerHeight - 60, pr.top + u.fy * pr.height));
    wordsCard.style.left = cx - or.left + "px";
    wordsCard.style.bottom = "auto";
    wordsCard.style.top = top - or.top + "px";
    const mh = Math.max(120, window.innerHeight - top - 8, 0);
    wordsCard.style.maxHeight = (u.h ? Math.min(u.h, mh) : mh) + "px";
    if (u.h) wordsCard.style.height = Math.min(u.h, mh) + "px"; else wordsCard.style.height = "";
    if (wordsCard._rz) wordsCard._rz._sync();
    return;
  }
  if (wordsCardState.dragging) return;
  wordsCard.style.top = "";
  wordsCard.style.left = center + pr.left - or.left + "px";
  wordsCard.style.bottom = or.height + 10 + "px";
  // spazio sopra i sottotitoli dentro la parte visibile dello schermo (a schermo intero il lettore è grande quanto lo
  // schermo, ma la scheda non deve uscire né sopra né sotto)
  const topLimit = Math.max(pr.top, 0) + 10;
  const bottomEdge = Math.min(or.top - 10, window.innerHeight - 10);
  wordsCard.style.maxHeight = Math.max(120, bottomEdge - topLimit) + "px";
  if (wordsCard._rz) wordsCard._rz._sync();
}

// Passando il mouse o cliccando: significato dal dizionario di Google (gratis, nessun limite di richieste); il clic fissa
// la scheda. La spiegazione nel contesto con il servizio scelto (Gemini, Groq, Claude…) parte SOLO dal pulsante
// «✨ Spiega con …» (wordsExplainNow): l'utente non vuole consumare token senza chiederlo.
// expr = espressione di più parole (modo di dire riconosciuto o selezione a mano): { text, meaning, spans, fromWord }
function wordsOpenCard(wordEl, pinned, expr) {
  if (!wordsCurrent || !overlay) return;
  const word = dsCleanWord(expr ? expr.text : wordEl.textContent.trim());
  if (!word) return;
  // un kanji/carattere aperto dalla scheda della parola: solo Google e dizionari gratuiti (niente richiesta al modello)
  const contextual = false;   // il modello solo dal pulsante «✨ Spiega con …»
  if (wordsCardState && wordsCardState.word === word && wordsCard) {
    wordsCardState.pinned = wordsCardState.pinned || pinned;
    if (contextual && !wordsCardState.contextual) {
      wordsCardState.contextual = true;
      // intanto resta il significato di Google: la spiegazione del modello lo sostituisce appena arriva
      if (wordsCardState.data && !wordsCardState.data.error) wordsCardState.quick = wordsCardState.data;
      wordsCardState.data = null;
      wordsFillCard();
      wordsLoadDefinition(word, wordsCardState.sentence, wordEl, true);
    }
    return;
  }
  if (wordsCard) wordsCard.remove();
  const sentence = wordsCurrent;
  wordsMarkReading(sentence);
  wordsCardState = { pinned, word, sentence, data: null, contextual, expr: expr || null, anchor: wordEl };
  // carattere aperto dalla scheda della parola: subito il significato già trovato, poi arriva quello di Google
  if (expr && expr.quick) wordsCardState.quick = expr.quick;
  wordsPaint("dualsub-sel", expr ? expr.spans : []);
  wordsPaint("dualsub-idiom-near", []);
  wordsCard = el("div", "dualsub-card");
  overlay.append(wordsCard);
  wordsResizer(wordsCardState);
  if (wordsCardResize) { wordsCardResize.disconnect(); wordsCardResize.observe(wordsCard); }
  // dove sei arrivato scorrendo la scheda (non le correzioni automatiche subito dopo un ridisegno)
  wordsCard.addEventListener("scroll", () => {
    if (Date.now() - wordsFillAt < 400 || !wordsCardState) return;
    wordsCardState.scrollWant = wordsCard.scrollTop;
  }, { passive: true });
  // con la scheda aperta i sottotitoli stanno sopra i comandi del lettore (titolo e pulsanti in alto di YouTube):
  // prima la parte alta della scheda finiva sotto di loro e, passandoci col mouse, la scheda si chiudeva
  overlay.classList.add("dualsub-cardopen");
  // modo di dire già spiegato dal modello (nella richiesta dell'allineamento): nessuna richiesta in più
  if (expr && expr.meaning && (!contextual || expr.preset)) {
    wordsCardState.contextual = false;   // un clic sull'espressione chiede poi la spiegazione completa
    wordsCardState.data = { meaning: expr.meaning, source: wordsDefineEngine().E.label.split(" (")[0].split(",")[0] + " · modo di dire", lang: sentence.lang || "" };
    wordsFillCard();
    wordsPlace(wordEl);
    return;
  }
  wordsFillCard();
  wordsPlace(wordEl);
  wordsLoadDefinition(word, sentence, wordEl, contextual);
}

// «✨ Spiega con …»: la spiegazione nel contesto con il modello (una richiesta), solo quando la chiedi
function wordsExplainNow(again, precise) {
  const st = wordsCardState;
  // 1.6.3: «🎯 Rifai più precisa»: stesso servizio, il modello ragiona di più e sa cosa c'era di sbagliato (la spiegazione di prima)
  if (st) {
    st.precise = !!precise;
    st.avoid = precise && st.data && !st.data.error ? [st.data.meaning, st.data.explanation].filter(Boolean).map((x) => String(x).slice(0, 300)) : [];
    if (precise && st.llmBy && !st.engineAlt) { st.engineAlt = st.llmBy.split("|")[0]; st.modelAlt = ""; }
  }
  const fromSaved = !!(st && st.data && (st.data.savedAt || again || precise));   // si vedeva una spiegazione salvata (o «⇄ Altro modello»): ne chiedo una nuova
  if (!st || (st.contextual && !fromSaved) || !wordsLlmAvailable() || (st.expr && st.expr.han)) return;
  st.contextual = true; st.pinned = true;
  // intanto resta il significato di Google: la spiegazione del modello lo sostituisce appena arriva
  if (st.data && !st.data.error && !fromSaved) st.quick = st.data;
  st.data = null;
  wordsFillCard();
  wordsLoadDefinition(st.word, st.sentence, wordsAnchorOf(st) || st.anchor, true);
}

// la parola della scheda nel sottotitolo: se la riga è stata ridisegnata (per esempio dopo «la conosco?»)
// la ritrovo dal testo
function wordsAnchorOf(st) {
  if (st.anchor && st.anchor.isConnected) return st.anchor;
  const w = st.expr && (st.expr.han || st.expr.lemmaOf) ? st.expr.fromWord : st.word;
  const a = lineOrig && [...lineOrig.querySelectorAll(".dualsub-word")].find((x) => dsCleanWord(x.textContent.trim()) === w);
  if (a) st.anchor = a;
  return a || null;
}

// 1.6.3: i modi di dire con una parola, in generale (non solo in questa frase): prima il dizionario gratuito di Wiktionary,
// poi il modello (una richiesta, solo quando premi 🔎). Quelli che sono nella frase restano sottolineati. Ogni parola di un
// modo di dire trovato è un pulsante: cercarne altri partendo da lì. Un errore momentaneo (modello occupato) si riprova
// da solo con il modello successivo.
async function wordsIdiomAsk(st, word, tries) {
  word = word || st.word;
  tries = tries || 0;
  if (st.idPanel && st.idPanel.wait && st.idPanel.word === word && !tries) return;
  const pn = st.idPanel = { word, wait: true, dict: [], idioms: [], error: "", source: "", noLlm: false };
  wordsFillCard();
  const e = wordsLlmAvailable() ? (dsTaskEngine("alignEngine") || wordsDefineEngine()) : null;
  const llm = !!e && (e.E.kind === "openai" || e.E.kind === "claude");
  pn.noLlm = !llm;
  const text = st.sentence.text;
  let r;
  try {
    r = await DS_EXT.runtime.sendMessage({ type: "idiomsAbout", ...(llm ? { engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl } : {}),
      sentence: text, lang: (st.sentence.lang || "").split("-")[0], target: settings.targetLang, word });
  } catch (err) { r = { error: String(err.message || err) }; }
  if (llm && r && r.error) {
    // finito oggi: quel modello salta; errore momentaneo (503, troppe richieste…): salta per 10 minuti. Poi rifaccio una volta col prossimo
    dsMarkBlocked(e.id, e.model, r.daily ? undefined : 10 * 60e3);
    if (!r.fatal && tries < 2) { const nx = dsTaskEngine("alignEngine") || wordsDefineEngine(); if (nx && (nx.id !== e.id || nx.model !== e.model) && dsReady(nx)) return wordsIdiomAsk(st, word, tries + 1); }
  }
  if (wordsCardState !== st || st.idPanel !== pn) return;
  pn.wait = false;
  if (r && !r.error) {
    pn.dict = r.dict || []; pn.idioms = r.idioms || []; pn.source = r.source || "";
    const here = pn.idioms.filter((it) => it.inSentence);
    for (const it of here) wordsRememberIdiom(text, it.text, it.meaning);
    if (here.length) wordsAddIdioms(text, here);
  } else if (r && r.error) {
    // l'elenco gratuito c'è comunque
    try { const d = await DS_EXT.runtime.sendMessage({ type: "idiomsAbout", sentence: text, lang: (st.sentence.lang || "").split("-")[0], word }); pn.dict = (d && d.dict) || []; } catch {}
    pn.error = String(r.error).slice(0, 140);
  }
  wordsFillCard();
}
// 1.6.7: i modi di dire della parola arrivati nella stessa richiesta della spiegazione: riempiono subito il pannello
// (niente seconda richiesta); l'elenco gratuito di Wiktionary si aggiunge dopo; quelli nella frase si sottolineano
function wordsIdiomsFromExplain(st, data, word) {
  const text = st.sentence.text;
  const pn = st.idPanel = { word, wait: false, dict: [], idioms: data.wordIdioms || [], error: "", source: data.source ? String(data.source).split(" (")[0] : "", noLlm: false };
  const here = pn.idioms.filter((it) => it.inSentence);
  for (const it of here) wordsRememberIdiom(text, it.text, it.meaning);
  if (here.length) wordsAddIdioms(text, here);
  DS_EXT.runtime.sendMessage({ type: "idiomsAbout", sentence: text, lang: (st.sentence.lang || "").split("-")[0], word }).then((d) => {
    if (wordsCardState === st && st.idPanel === pn) { pn.dict = (d && d.dict) || []; wordsFillCard(); }
  }).catch(() => {});
}
// l'immagine scelta per un modo di dire, altrimenti la prima trovata
async function wordsIdiomImage(im, text, lang) {
  if (typeof DS_LEARN === "undefined") return "";
  const ch = im ? DS_LEARN.chosenImage(im) : undefined;
  return ch !== undefined ? ch : await DS_LEARN.image(text, String(lang || "").split("-")[0]);
}
function wordsIdiomPanelOpts(st) {
  const lang = () => (st.data && st.data.lang) || st.sentence.lang || "";
  const idOf = (it) => vocabId(lang(), "", it.text);
  return {
    target: settings.targetLang, get lang() { return (lang() || "").split("-")[0]; },
    llm: () => { try { if (!wordsLlmAvailable()) return null; const e = wordsDefineEngine(); return e && (e.E.kind === "openai" || e.E.kind === "claude") ? { id: e.id, key: e.key, model: e.model, localUrl: e.localUrl, name: e.E.label.split(" (")[0].split(",")[0] } : null; } catch { return null; } },
    searchWord: (w) => wordsIdiomAsk(st, w),
    retry: () => wordsIdiomAsk(st, st.idPanel && st.idPanel.word, 1),
    ankiImage: !!settings.ankiImage,
    rerender: () => { if (wordsCardState === st && wordsCard) wordsFillCard(); },
    isSaved: (it) => !!vocab[idOf(it)],
    save: async (it) => {
      const e = { ...wordsEntry(), id: idOf(it), word: it.text, lemma: "", pos: "espressione", meaning: it.meaning || "", explanation: "", ipa: "", sentence: it.example || "", sentenceTrans: "", etym: "" };
      const adding = !vocab[e.id];
      if (settings.ankiImage && adding) e.image = await wordsIdiomImage(it._img, it.text, lang());
      await vocabToggle(e);
      if (adding && settings.ankiAuto) wordsAnki(null, e);
    }
  };
}

// i modelli pronti (chiave, modello, richieste di oggi) diversi da quello già usato: per «⇄ Altro modello»
// 1.6.2: ogni modello di ogni servizio (Gemini Flash, Gemini Flash-Lite, Groq…): ognuno ha il suo limite al giorno
// (except = "servizio|modello" della spiegazione che si vede)
function wordsOtherLlms(except) {
  const isLlm = (x) => x.E.kind === "openai" || x.E.kind === "claude";
  const out = [];
  for (const id of C.engineOrder(settings)) {
    if (!C.ENGINES[id] || !isLlm({ E: C.ENGINES[id] }) || dsIsBlocked(id)) continue;
    const e = engineById(id);
    if (!dsReady({ ...e, exhausted: false })) continue;
    for (const m of dsModelChain(settings, "explainEngine", id)) {
      if (dsModelBlocked(id, m) || id + "|" + m === except) continue;
      out.push({ ...e, model: m, exhausted: false });
    }
  }
  return out;
}

// i servizi con modello (Gemini, Groq…) che hanno la chiave, anche se ora hanno finito le richieste
function wordsLlmIds() {
  const isLlm = (id) => C.ENGINES[id] && (C.ENGINES[id].kind === "openai" || C.ENGINES[id].kind === "claude");
  return [...new Set([settings.explainEngine, settings.engine, ...C.engineOrder(settings)])].filter((id) => id && isLlm(id));
}
function wordsLlmConfigured() {
  for (const id of wordsLlmIds()) { const e = engineById(id); if (e && (!e.E.needsKey || e.key) && (e.model || e.E.defaultModel)) return e; }
  return null;
}
function wordsLlmAvailable() {
  const e = wordsDefineEngine();
  return (e.E.kind === "openai" || e.E.kind === "claude") && (!e.E.needsKey || !!e.key) && !!(e.model || e.E.defaultModel);
}

// Ridisegno della scheda (arriva l'etimologia, cambi immagine per Anki, apri l'albero…): resta dov'era scorsa (prima
// tornava in cima a ogni clic sulle frecce delle immagini) e si rimette dentro lo schermo con la nuova altezza (prima
// l'altezza massima era quella calcolata all'apertura: a schermo intero la fine della scheda non si raggiungeva più)
// (la posizione voluta è quella scelta da te scorrendo: i ridisegni intermedi, più corti mentre si cerca l'immagine,
// la schiacciavano e il ridisegno dopo ripartiva da lì)
// 1.7.14: «✨ Spiega con …» accanto alla parola (sempre presente, anche dopo la spiegazione e con i limiti finiti) e la tendina ▾ con
// TUTTI i modelli di tutti i servizi (anche i diversi modelli dello stesso servizio, per esempio i vari Gemini)
let wordsModelLists = {};
DS_EXT.storage.local.get({ dsModelLists: {} }).then((r) => { wordsModelLists = r.dsModelLists || {}; }).catch(() => {});
DS_EXT.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.dsModelLists) wordsModelLists = ch.dsModelLists.newValue || {}; });
const wordsModelAsked = new Set();
function wordsAllModels() {
  const out = [];
  for (const id of wordsLlmIds()) {
    const e = engineById(id);
    if (!e || (e.E.needsKey && !e.key)) continue;
    const ms = [...new Set([...dsModelChain(settings, "explainEngine", id), ...(wordsModelLists[id] || [])].filter(Boolean))];
    out.push({ id, e, label: e.E.local ? "Ollama" : e.E.label.split(" (")[0].split(",")[0], models: ms, listed: !!wordsModelLists[id] });
  }
  return out;
}
function wordsExplainCtl(st, d) {
  if (st.expr && st.expr.han) return null;
  const cfg = wordsLlmConfigured();
  if (!cfg) return null;
  const avail = wordsLlmAvailable();
  const eng = avail ? wordsDefineEngine() : cfg;
  const name = eng.E.label.split(" (")[0].split(",")[0];
  const explained = !!(st.contextual && st.data && !st.data.error) && !st.data.savedAt;
  const wrap = el("span", "dualsub-explainctl");
  const ex = el("button", "dualsub-card-btn dualsub-explainbtn" + (avail ? "" : " dualsub-explainwait"),
    avail ? (explained ? "✨ Rifai con " + name : "✨ Spiega con " + name) : "✨ Spiega con " + name + " — richieste finite, riprova");
  ex.title = avail
    ? (st.expr ? "Il significato dell'espressione" : "Il significato in questa frase, la forma base, se fa parte di un modo di dire, un esempio") + " (e pronuncia ed etimologia se mancano): una richiesta a " + name + ", solo quando la premi"
    : "Le richieste di " + name + " sono finite (limite al minuto o di oggi). Premi per riprovare adesso; se ci sono di nuovo, parte la spiegazione";
  ex.addEventListener("click", async (ev) => {
    ev.stopPropagation();
    if (!avail) {
      try { const cur = (await DS_EXT.storage.local.get({ dsBlocked: {} })).dsBlocked || {}; let m = cur; for (const id of wordsLlmIds()) m = dsUnblock(m, id); await DS_EXT.storage.local.set({ dsBlocked: m }); } catch {}
      await new Promise((r) => setTimeout(r, 150));
      if (!wordsLlmAvailable()) { wordsFillCard(); return; }
    }
    st.engineAlt = ""; st.modelAlt = ""; st.altOpen = false;
    wordsExplainNow(explained || !!(d && d.savedAt));
  });
  const more = el("button", "dualsub-card-btn dualsub-explainmenu" + (st.altOpen ? " on" : ""), "▾");
  more.title = "Scegli il modello (anche un altro modello dello stesso servizio)";
  more.addEventListener("click", (ev) => { ev.stopPropagation(); st.altOpen = !st.altOpen; wordsFillCard(); });
  wrap.append(ex, more);
  return wrap;
}
function wordsModelMenu(st) {
  const box = el("div", "dualsub-modelmenu");
  const cur = st.llmBy || (() => { const x = wordsDefineEngine(); return x.id + "|" + x.model; })();
  const groups = wordsAllModels();
  for (const g of groups) {
    const head = el("div", "dualsub-modelmenu-head", g.label);
    if (!g.listed && !wordsModelAsked.has(g.id) && !g.e.E.staticModels) {
      wordsModelAsked.add(g.id);
      DS_EXT.runtime.sendMessage({ type: "listModels", engine: g.id, key: g.e.key || "", localUrl: settings.localUrl }).then((r) => { if (r && r.models && !wordsModelLists[g.id]) wordsModelLists = { ...wordsModelLists, [g.id]: r.models }; if (wordsCardState === st && st.altOpen) wordsFillCard(); }).catch(() => {});
      head.append(el("span", "dualsub-card-hint", "  cerco gli altri modelli…"));
    }
    box.append(head);
    for (const m of g.models) {
      const blocked = dsModelBlocked(g.id, m);
      const b = el("button", "dualsub-pill dualsub-modelmenu-item" + (g.id + "|" + m === cur ? " dualsub-on" : ""), (g.id + "|" + m === cur ? "● " : "") + m.replace(/^models\//, "") + (blocked ? " (finito)" : ""));
      b.title = "Spiega con " + g.label + " · " + m + (blocked ? " — le richieste di questo modello sono finite per ora" : "");
      b.disabled = blocked;
      b.addEventListener("click", (ev) => { ev.stopPropagation(); st.altOpen = false; st.engineAlt = g.id; st.modelAlt = m; wordsExplainNow(true); });
      box.append(b);
    }
  }
  return box;
}

let wordsFillAt = 0;
function wordsFillCard() {
  const st = wordsCardState;
  const keep = st && st.scrollWant != null ? st.scrollWant : wordsCard ? wordsCard.scrollTop : 0;
  wordsFillAt = Date.now();
  wordsFillCardNow();
  if (!wordsCard) return;
  wordsCard.scrollTop = keep;
  wordsReplace();
}
let wordsReplaceRaf = 0;
function wordsReplace() {
  if (wordsReplaceRaf) return;
  wordsReplaceRaf = requestAnimationFrame(() => {
    wordsReplaceRaf = 0;
    const st = wordsCardState;
    const a = st && (wordsAnchorOf(st) || st.anchor);
    if (wordsCard && a && a.isConnected) wordsPlace(a);
    if (wordsCard && st && st.scrollWant != null && Math.abs(wordsCard.scrollTop - st.scrollWant) > 2) { wordsFillAt = Date.now(); wordsCard.scrollTop = st.scrollWant; }
  });
}
// la scheda cresce anche da sola (immagini, tabelle, albero che arrivano dopo): la rimetto a posto
const wordsCardResize = typeof ResizeObserver === "function" ? new ResizeObserver(() => wordsReplace()) : null;
window.addEventListener("resize", () => wordsReplace());
document.addEventListener("fullscreenchange", () => setTimeout(wordsReplace, 200));
function wordsFillCardNow() {
  const st = wordsCardState;
  if (!wordsCard || !st) return;
  const llmWait = !st.data && st.contextual && !!st.quick;
  const d = st.data || st.quick || null;
  wordsCard.textContent = "";
  wordsCard.append(wordsGrip(st));

  const head = el("div", "dualsub-card-head");
  const title = el("div", "dualsub-card-title");
  title.append(el("span", "dualsub-card-word", st.word));
  if (d && d.lemma && d.lemma.toLowerCase() !== st.word.toLowerCase()) title.append(el("span", "dualsub-card-lemma", "→ " + d.lemma));
  if (d && d.pos) title.append(el("span", "dualsub-card-pos", d.pos));
  // 1.7.9: ✎ forma base: sceglie la radice da cui deriva questa forma e apre la sua scheda intera (da vedere e salvare)
  if (d && !st.expr && typeof DS_LEARN.lemmaPicker === "function" && wordsSplit(st.word).length === 1) {
    const lb = el("button", "dualsub-card-lemmabtn" + (st.lemmaPick ? " on" : ""), "✎ forma base");
    lb.title = `Scegli la forma base (radice) da cui deriva «${st.word}» e apri la sua scheda intera, da vedere e salvare`;
    lb.addEventListener("click", (ev) => { ev.stopPropagation(); st.lemmaPick = !st.lemmaPick; wordsFillCard(); });
    title.append(lb);
  }
  { const ctl = wordsExplainCtl(st, d); if (ctl) title.append(ctl); }
  head.append(title);

  const lang = wordsSpeechLang();
  // 🔈 = voce sintetica (sempre); accanto 🔊 = registrazione di una persona (Wiktionary), quando c'è
  const hasLearn = typeof DS_LEARN !== "undefined" && (!st.expr || st.expr.han) && wordsSplit(st.word).length === 1;
  st.learn = st.learn || {};
  const rec = hasLearn && DS_LEARN.recordingOf(st.learn, st.word, settings);
  const speak = el("button", "dualsub-card-btn dualsub-speak", "🔈");
  if (lang) speak.append(el("span", "dualsub-speak-lang", DS_TTS.base(lang).toUpperCase()));
  speak.title = lang ? `Ascolta la pronuncia con la voce sintetica (${lang}). La lingua si può cambiare nel popup.` : "Ascolta la pronuncia (voce sintetica)";
  speak.addEventListener("click", async () => {
    const restore = wordsDuck();
    try {
      const r = await DS_TTS.speak(st.word, wordsSpeechLang(), { lang: settings.ttsLang, voice: settings.ttsVoice });
      speak.title = "Pronuncia: " + r.how;
      await Promise.race([r.done, new Promise((ok) => setTimeout(ok, 10000))]);
    } catch {}
    restore();
  });
  let recBtn = null;
  if (rec) {
    const lb = DS_LEARN.recordingLabel(st.learn, st.word, settings);
    recBtn = el("button", "dualsub-card-btn dualsub-speak dualsub-rec" + (lb && lb.form ? " dsx-recform" : ""), lb && lb.form ? "🔊*" : "🔊");
    recBtn.title = lb ? lb.title : "Ascolta la registrazione di un madrelingua (Wiktionary)";
    recBtn.addEventListener("click", async () => {
      const restore = wordsDuck();
      try {
        const r = await DS_LEARN.playUrl(rec, null);
        if (r) await Promise.race([r.done, new Promise((ok) => setTimeout(ok, 10000))]);
        else recBtn.textContent = "✕";
      } catch {}
      restore();
    });
  }
  const star = el("button", "dualsub-card-btn dualsub-star", "☆");
  star.title = "Salva nel vocabolario";
  star.addEventListener("click", () => wordsSave());
  const close = el("button", "dualsub-card-btn", "×");
  close.title = "Chiudi";
  close.addEventListener("click", wordsCloseCard);
  // ⚙: voce per questa lingua (resta salvata)
  const gear = el("button", "dualsub-card-btn dualsub-voicegear", "⚙");
  gear.title = "Scegli la voce per questa lingua";
  gear.addEventListener("click", (ev) => {
    ev.stopPropagation();
    st.voiceMenu = !st.voiceMenu;
    wordsFillCard();
  });
  // Anki: niente pulsante a parte; con "Manda ad Anki quando salvi con ☆" (popup → Anki) la stella fa anche quello
  star.title = settings.ankiAuto ? "Salva nel vocabolario (e manda ad Anki)" : "Salva nel vocabolario";
  head.append(...(recBtn ? [recBtn] : []), speak, gear, star, close);
  if (st.altOpen && wordsLlmConfigured()) wordsCard.append(wordsModelMenu(st));
  wordsCard.append(head);
  if (st.lemmaPick && d && !st.expr) {
    const lang0 = (d.lang || (st.sentence.lang || "").split("-")[0] || DualSubs.guessLang(st.sentence.text) || "");
    wordsCard.append(DS_LEARN.lemmaPicker({
      word: st.word, lang: lang0, target: settings.targetLang, lemma: d.lemma || "", hints: DS_LEARN.baseHints({ lemma: d.lemma, st: st.learn, gdict: st.learn && st.learn.gdict }),
      store: st, rerender: () => { if (wordsCardState === st) wordsFillCard(); },
      open: (lemma) => {
        const a = wordsAnchorOf(st);
        if (!a) return;
        const back = { fromWord: st.word, backContextual: st.contextual };
        wordsCloseCard();
        wordsOpenCard(a, true, { text: lemma, spans: [], lemmaOf: true, ...back });
      }
    }));
  }
  if (llmWait) wordsCard.append(el("div", "dualsub-card-hint", "Chiedo a " + wordsDefineEngine().E.label.split(" (")[0].split(",")[0] + " la spiegazione nel contesto…"));
  if (st.voiceMenu && typeof DS_TTS.voiceMenu === "function") {
    const vl = wordsSpeechLang() || lang;
    wordsCard.append(DS_TTS.voiceMenu(vl, () => { st.voiceMenu = false; if (wordsCardState === st && wordsCard) { wordsFillCard(); const b = wordsCard.querySelector(".dualsub-speak:not(.dualsub-rec)"); if (b) b.click(); } }));
  }
  wordsCardIpa(st, d);

  if (!d) {
    wordsCard.append(el("div", "dualsub-card-loading", "Cerco il significato…"));
  } else if (d.error) {
    wordsCard.append(el("div", "dualsub-card-error", d.error));
  } else {
    if (d.untranslated) {
      wordsCard.append(el("div", "dualsub-card-expl", "Google non ha una traduzione per questa parola da sola (spesso è un nome, o un pezzo di un'espressione)." +
        (wordsLlmAvailable() && !st.contextual ? "" : "")));
    } else {
      const fx = wordsWordFix(st, d);
      wordsCard.append(el("div", "dualsub-card-meaning", (fx || d.meaning || "—") + (fx ? " ✎" : "")));
    }
    // ⚑ significato sbagliato: rifarlo con Google o con il modello, o correggerlo a mano (come in Parole al Volo)
    if (!st.expr || !st.expr.idiom) wordsCard.append(wordsMeaningFixRow(st, d));
    // modo di dire (sottolineato dal modello): si può segnalare, correggere o ricontrollare
    if (st.expr && st.expr.idiom && wordsSplit(st.word).length > 1) wordsCard.append(wordsIdiomFixRow(st, st.word, d.meaning));
    // le traduzioni del dizionario di Google compaiono già (ordinate, con il peso) negli strumenti per imparare
    const gdShown = (!st.contextual || llmWait) && settings.gdAlt !== false && d.gdict && d.gdict.alt && d.gdict.alt.length && typeof DS_LEARN !== "undefined";
    if (d.explanation && !gdShown) wordsCard.append(el("div", "dualsub-card-expl", d.explanation));
    // la parola cliccata fa parte di un modo di dire: lo segnalo e lo sottolineo nella frase
    // il modo di dire di questa spiegazione, o quello trovato prima per la stessa parola nella stessa frase
    const mem = !st.expr && !d.expression ? wordsRememberedIdiom(st.sentence.text, st.word) : null;
    const dx = mem ? { ...d, expression: mem.text, expressionMeaning: mem.meaning } : d;
    if (!st.expr && dx.expression && wordsNorm(dx.expression) !== wordsNorm(st.word) && wordsSplit(dx.expression).length > 1 && wordsIdiomPlausible(dx.expression, st.sentence.text)) {
      const d = dx;
      if (!mem) wordsRememberIdiom(st.sentence.text, d.expression, d.expressionMeaning);
      const box = el("div", "dualsub-card-idiom");
      const em = wordsIdiomMeaning(d.expression, d.expressionMeaning);
      // le altre parole del modo di dire (per "сожалению" la "к") si vedono nel sottotitolo con un tratteggio leggero,
      // diverso dalla parola cliccata e dalla selezione a mano; la selezione dell'espressione resta manuale
      wordsPaint("dualsub-idiom-near", wordsFindExpr(d.expression).filter((x) => x !== st.anchor));
      box.append(el("b", null, "Modo di dire: "), document.createTextNode(`«${d.expression}»` + (em ? " = " + em : "")));
      box.append(wordsIdiomFixRow(st, d.expression, em));
      const spans = wordsFindExpr(d.expression);
      if (spans.length > 1) {
        const go = el("button", "dualsub-card-link", "Mostra tutta l'espressione");
        go.addEventListener("click", () => wordsOpenCard(spans[Math.floor(spans.length / 2)], true,
          { text: wordsRangeText(spans), meaning: wordsIdiomMeaning(d.expression, d.expressionMeaning), spans, preset: true, idiom: true }));
        box.append(document.createElement("br"), go);
      }
      // ☆ salva il modo di dire nel vocabolario (come una parola, con la sua frase)
      const lang = d.lang || st.sentence.lang || "";
      const ientry = () => ({ ...wordsEntry(), id: vocabId(lang, "", d.expression), word: d.expression, lemma: "", pos: "espressione",
        meaning: em || "", explanation: "", ipa: "" });
      const isave = el("button", "dualsub-card-link dualsub-idiom-save", vocab[vocabId(lang, "", d.expression)] ? "★ modo di dire salvato" : "☆ Salva il modo di dire");
      isave.addEventListener("click", async () => {
        const e = ientry();
        const adding = !vocab[e.id];
        if (settings.ankiImage && adding) e.image = await wordsIdiomImage(st.idImg, d.expression, lang);
        await vocabToggle(e);
        if (adding && settings.ankiAuto) wordsAnki(null, e);
        isave.textContent = vocab[e.id] ? "★ modo di dire salvato" : "☆ Salva il modo di dire";
      });
      box.append(document.createElement("br"), isave);
      if (settings.ankiImage && typeof DS_LEARN !== "undefined") { st.idImg = st.idImg || { list: [], i: 0 }; box.append(DS_LEARN.imagePicker(st.idImg, { word: d.expression, lang: String(lang).split("-")[0], autoload: true, rerender: () => { if (wordsCardState === st && wordsCard) wordsFillCard(); } })); }
      wordsCard.append(box);
    }
    // (la traduzione della frase del modello, se diversa da quella sotto il video, sta in fondo alla scheda: dualsub-card-sentfoot)
    if (d.example) {
      const ex = el("div", "dualsub-card-example");
      ex.append(el("div", null, d.example));
      if (d.exampleTrans) ex.append(el("div", "dualsub-card-extrans", d.exampleTrans));
      wordsCard.append(ex);
    }
    wordsCardLearn(st, d);
    wordsCard.append(el("div", "dualsub-card-source", "Fonte: " + d.source + (d.checkNote ? " — " + d.checkNote : "")));
    const tools = el("div", "dualsub-copy-actions");
    const cp = el("button", "dualsub-card-replay dualsub-pill", st.expr && !st.expr.han ? "⧉ Espressione" : "⧉ Parola");
    cp.title = st.expr && !st.expr.han ? "Copia l'espressione" : "Copia la parola";
    cp.addEventListener("click", (ev) => { ev.stopPropagation(); wordsCopy(st.word, cp); });
    const cps = el("button", "dualsub-card-replay dualsub-pill", "⧉ Frase");
    cps.title = "Copia la frase originale e la sua traduzione";
    cps.addEventListener("click", (ev) => { ev.stopPropagation(); wordsCopy(st.sentence.text + (st.sentence.trans ? "\n" + st.sentence.trans : ""), cps); });
    tools.append(cp, cps);
    wordsCard.append(tools);
    const src = d.lang || (st.sentence.lang || "").split("-")[0] || DualSubs.guessLang(st.sentence.text) || "";
    wordsCard.append(wordsLinksRow(() => st.word, src, settings.targetLang, wordsSplit(st.word).length <= 3, st.expr ? "" : d.lemma));
    if (st.expr && st.expr.han) {
      // scheda di un solo kanji: si torna alla parola intera (senza una nuova richiesta al modello, se prima non c'era)
      const back = el("button", "dualsub-card-link", `‹ Torna alla parola «${st.expr.fromWord}»`);
      back.addEventListener("click", (ev) => {
        ev.stopPropagation();
        const a = wordsAnchorOf(st), ctxl = st.expr.backContextual;
        wordsCloseCard();
        if (!a) return;
        wordsOpenCard(a, ctxl, null);
        if (wordsCardState) wordsCardState.pinned = true;
      });
      wordsCard.append(back);
    } else if (st.expr && st.expr.fromWord) {
      const only = el("button", "dualsub-card-link", st.expr.lemmaOf ? `‹ Torna alla parola «${st.expr.fromWord}»` : `Solo la parola «${st.expr.fromWord}»`);
      only.title = "Oppure clicca di nuovo la parola nel sottotitolo";
      only.addEventListener("click", (ev) => { ev.stopPropagation(); const a = wordsAnchorOf(st); wordsCloseCard(); if (a && a.isConnected) wordsOpenCard(a, true, null); });
      wordsCard.append(only);
    }
    // parola da sola che fa parte di un modo di dire sottolineato: si torna all'espressione intera
    const idiomHere = !st.expr && st.anchor && st.anchor.isConnected ? wordsIdiomOf(st.anchor) : null;
    if (idiomHere) {
      const back = el("button", "dualsub-card-link", `Tutto il modo di dire «${idiomHere.text}» ›`);
      back.title = "Oppure clicca di nuovo la parola nel sottotitolo";
      back.addEventListener("click", (ev) => { ev.stopPropagation(); const a = st.anchor; wordsCloseCard(); if (a && a.isConnected) wordsOpenCard(a, true, wordsIdiomOf(a)); });
      wordsCard.append(back);
    }
    // 🔎 i modi di dire con questa parola, in generale: dizionario gratuito + modello (una richiesta, solo quando lo premi)
    if (!(st.expr && st.expr.han) && typeof DS_LEARN !== "undefined") {
      if (st.expr && !st.idPanel) {
        // espressione già trovata: ogni parola è un pulsante per cercarne altre con quella
        const row = el("div", "dualsub-card-hint dualsub-idwords");
        row.append(document.createTextNode("Cerca altri modi di dire con: "), DS_LEARN.idiomWords(st.word, wordsIdiomPanelOpts(st)));
        wordsCard.append(row);
      } else if (!st.expr && !st.idPanel && !wordsLlmAvailable()) {
        // con un modello il pulsante non serve: «✨ Spiega con…» porta già anche i modi di dire della parola (una richiesta sola)
        const ib = el("button", "dualsub-card-btn dualsub-idiomask", "🔎 Modi di dire con questa parola");
        ib.title = "I modi di dire che contengono questa parola, anche fuori da questa frase: prima l'elenco gratuito di Wiktionary, poi il modello (una richiesta). Quelli che sono in questa frase restano sottolineati";
        ib.addEventListener("click", (ev) => { ev.stopPropagation(); wordsIdiomAsk(st); });
        wordsCard.append(ib);
      }
      if (st.idPanel) {
        const pbox = DS_LEARN.idiomPanel(st.idPanel, wordsIdiomPanelOpts(st));
        const close = el("button", "dualsub-card-link dualsub-idclose", "✕ chiudi i modi di dire");
        close.addEventListener("click", (ev) => { ev.stopPropagation(); st.idPanel = null; wordsFillCard(); });
        wordsCard.append(pbox, close);
      }
    }
    // 🎯 la spiegazione del modello rifatta con più cura (stesso servizio, più ragionamento, sapendo cosa c'era prima)
    if (st.contextual && d && !d.error && !d.fallback && wordsLlmAvailable() && !(st.expr && st.expr.han) && (st.llmBy || d.savedAt)) {
      const pb = el("button", "dualsub-card-btn dualsub-precise", "🎯 Rifai più precisa");
      pb.title = "Chiede di nuovo la spiegazione allo stesso servizio, con più ragionamento e sapendo cosa c'era di sbagliato o vago prima: una richiesta, solo quando la premi. La nuova resta nelle 🗂 salvate";
      pb.addEventListener("click", (ev) => { ev.stopPropagation(); st.altOpen = false; wordsExplainNow(true, true); });
      wordsCard.append(pb);
    }
    const savedRow = wordsSavedRow(st);
    if (savedRow) wordsCard.append(savedRow);
    const flagged = wordsFlaggedRow(st);
    if (flagged) wordsCard.append(flagged);
  }

  const replay = el("button", "dualsub-card-replay dualsub-pill", "↺ Riascolta");
  replay.title = "Riascolta la frase dall'inizio";
  replay.addEventListener("click", () => wordsReplay(1, 1));
  const slow = el("button", "dualsub-card-replay dualsub-pill", "🐢 Lenta");
  slow.title = "Riascolta la frase al 75% della velocità";
  slow.addEventListener("click", () => wordsReplay(0.75, 1));
  const loop = el("button", "dualsub-card-replay dualsub-pill", "🔁 ×3");
  loop.title = "Riascolta la frase tre volte di fila (per ripeterla insieme)";
  loop.addEventListener("click", () => wordsReplay(1, 3));
  const row = el("div", "dualsub-replay-row");
  row.append(replay, slow, loop);
  wordsCard.append(row);
  // 1.6.3: la traduzione della frase, piccola e in fondo alla scheda (come in Parole al Volo). Quella del modello, se l'ha
  // fatta insieme alla spiegazione, sostituisce quella dei sottotitoli
  { const better = st && st.contextual && st.data && !st.data.error && st.data.sentenceTrans ? st.data.sentenceTrans : "";
    const tr = better || (st && st.sentence && st.sentence.trans) || "";
    if (tr && !(st.expr && st.expr.han)) {
      const f = el("div", "dualsub-card-sentfoot", tr);
      f.title = "Traduzione della frase" + (better ? " (fatta insieme alla spiegazione)" : "");
      wordsCard.append(f);
    }
  }
  wordsRefreshStar();
}

// ⚑ significato della parola sbagliato: le correzioni a mano restano salvate per la stessa parola (in quella lingua)
let wordsFixes = {};
DS_EXT.storage.local.get({ wordFix: {} }).then((r) => { wordsFixes = r.wordFix || {}; }).catch(() => {});
DS_EXT.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.wordFix) wordsFixes = ch.wordFix.newValue || {}; });
function wordsFixKey(st, d) {
  const lang = ((d && d.lang) || st.sentence.lang || "").split("-")[0] || "?";
  return [lang, settings.targetLang, String(st.word).toLowerCase().trim()].join("|");
}
const wordsWordFix = (st, d) => wordsFixes[wordsFixKey(st, d)] || "";
async function wordsSetFix(st, d, value) {
  const k = wordsFixKey(st, d);
  if (value) wordsFixes[k] = value; else delete wordsFixes[k];
  const ks = Object.keys(wordsFixes);
  for (const x of ks.slice(0, Math.max(0, ks.length - 3000))) delete wordsFixes[x];
  await DS_EXT.storage.local.set({ wordFix: wordsFixes }).catch(() => {});
}
function wordsMeaningFixRow(st, d) {
  const row = el("div", "dualsub-idiom-fix");
  const fixed = wordsWordFix(st, d);
  const b = el("button", "dualsub-card-link", st.meanFix ? "chiudi" : "⚑ Traduzione sbagliata?");
  b.title = "Rifai la traduzione con Google o con il modello, oppure correggila a mano (resta salvata)";
  b.addEventListener("click", (ev) => { ev.stopPropagation(); st.meanFix = !st.meanFix; st.meanEdit = false; wordsFillCard(); });
  row.append(b);
  if (fixed) row.append(el("span", "dualsub-card-hint", " ✎ corretta da te"));
  if (!st.meanFix) return row;
  const box = el("div", "dualsub-idiom-fixbox");
  const btn = (label, title, fn) => { const x = el("button", "dualsub-card-replay dualsub-replay-small", label); x.title = title; x.addEventListener("click", (ev) => { ev.stopPropagation(); fn(); }); box.append(x); };
  // rifà la richiesta senza usare la risposta già salvata
  const redo = (contextual) => {
    const w = String(st.word).toLowerCase() + "|" + st.sentence.text + "|";
    for (const k of [...wordsDefCache.keys()]) if (k.startsWith(w)) wordsDefCache.delete(k);
    st.meanFix = false; st.data = null; st.quick = null; st.contextual = contextual;
    wordsFillCard();
    wordsLoadDefinition(st.word, st.sentence, st.anchor, contextual);
  };
  btn("↻ Rifai con Google", "Una nuova traduzione di Google (gratis)", () => redo(false));
  if (wordsLlmAvailable()) btn("Rifai con " + wordsDefineEngine().E.label.split(" (")[0].split(",")[0], "Significato nel contesto della frase (e la frase corretta, nella stessa richiesta): una richiesta", () => redo(true));
  btn("✎ Correggi a mano", "Scrivi tu il significato giusto: resta salvato per le prossime volte", () => { st.meanEdit = !st.meanEdit; wordsFillCard(); });
  if (fixed) btn("Togli la correzione", "", async () => { await wordsSetFix(st, d, ""); st.meanFix = false; wordsFillCard(); });
  if (st.meanEdit) {
    const t = el("textarea", "dsx-input");
    t.rows = 2; t.value = fixed || d.meaning || "";
    t.addEventListener("keydown", (ev) => ev.stopPropagation());
    const save = el("button", "dualsub-card-replay dualsub-replay-small", "Salva");
    save.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      await wordsSetFix(st, d, t.value.trim());
      st.meanEdit = false; st.meanFix = false;
      wordsFillCard(); wordsRefreshStar();
    });
    box.append(t, save);
    setTimeout(() => t.focus(), 0);
  }
  box.append(el("div", "dualsub-card-hint", "La frase intera si corregge con ⚑ accanto al sottotitolo."));
  row.append(box);
  return row;
}

// ⚑ sui modi di dire: a volte il modello se li inventa o sbaglia il significato
function wordsIdiomFixRow(st, text, meaning) {
  const row = el("div", "dualsub-idiom-fix");
  const fixed = (wordsIdiomFlags[wordsIdiomKey(text)] || {}).meaning;
  const b = el("button", "dualsub-card-link", st.idiomFix ? "chiudi" : "⚑ modo di dire sbagliato?");
  b.addEventListener("click", (ev) => { ev.stopPropagation(); st.idiomFix = !st.idiomFix; st.idiomEdit = false; wordsFillCard(); });
  row.append(b);
  if (fixed) row.append(el("span", "dualsub-card-hint", " ✎ corretto da te"));
  if (!st.idiomFix) return row;
  const box = el("div", "dualsub-idiom-fixbox");
  const btn = (label, title, fn) => { const x = el("button", "dualsub-card-replay dualsub-replay-small", label); x.title = title; x.addEventListener("click", (ev) => { ev.stopPropagation(); fn(); }); box.append(x); };
  btn("Non è un modo di dire", "Toglie la sottolineatura arancione per questa espressione (resta salvato; si annulla dalla scheda di una sua parola: «🚫 … annulla»)", async () => {
    await wordsIdiomFlag(text, { bad: true, t: text, m: fixed || "", om: meaning || "", s: st.sentence.text });
    st.idiomFix = false;
    if (st.expr && st.expr.idiom) wordsCloseCard(); else wordsFillCard();
  });
  if (wordsLlmAvailable()) btn("Ricontrolla con " + wordsDefineEngine().E.label.split(" (")[0].split(",")[0], "Chiede al modello la spiegazione completa dell'espressione in questa frase (una richiesta)", () => {
    const spans = wordsFindExpr(text);
    st.idiomFix = false;
    const anchor = spans[Math.floor(spans.length / 2)] || st.anchor;
    wordsCloseCard();
    if (anchor && anchor.isConnected) wordsOpenCard(anchor, true, { text: spans.length ? wordsRangeText(spans) : text, spans, fromWord: "" });
  });
  btn("✎ Correggi il significato", "Scrivi tu il significato giusto: resta salvato", () => { st.idiomEdit = !st.idiomEdit; st.idiomTextEdit = false; wordsFillCard(); });
  btn("✎ Correggi il modo di dire", "Il modo di dire è un altro (più lungo, più corto, altre parole): scrivilo tu, con il suo significato", () => { st.idiomTextEdit = !st.idiomTextEdit; st.idiomEdit = false; wordsFillCard(); });
  if (fixed || wordsIdiomBad(text)) btn("Togli la mia correzione", "", async () => { await wordsIdiomFlag(text, null); st.idiomFix = false; wordsFillCard(); });
  if (st.idiomEdit) {
    const t = el("textarea", "dsx-input");
    t.rows = 2; t.value = fixed || meaning || "";
    t.addEventListener("keydown", (ev) => ev.stopPropagation());
    const save = el("button", "dualsub-card-replay dualsub-replay-small", "Salva");
    save.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      await wordsIdiomFlag(text, { meaning: t.value.trim(), bad: false });
      st.idiomEdit = false; st.idiomFix = false;
      if (st.data && st.expr) st.data = { ...st.data, meaning: t.value.trim() };
      wordsFillCard();
    });
    box.append(t, save);
    setTimeout(() => t.focus(), 0);
  }
  // il modo di dire stesso è sbagliato: quello vecchio si segna come «non è un modo di dire» (annullabile) e quello
  // scritto da te diventa un modo di dire di questa frase, con il suo significato
  if (st.idiomTextEdit) {
    const tx = el("input", "dsx-input"); tx.value = text; tx.placeholder = "Il modo di dire giusto (parole della frase)";
    const tm = el("textarea", "dsx-input"); tm.rows = 2; tm.value = fixed || meaning || ""; tm.placeholder = "Il suo significato";
    for (const x of [tx, tm]) x.addEventListener("keydown", (ev) => ev.stopPropagation());
    const save = el("button", "dualsub-card-replay dualsub-replay-small", "Salva");
    save.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      const nt = tx.value.replace(/\s+/g, " ").trim(), nm = tm.value.trim();
      if (!nt) return;
      if (wordsIdiomKey(nt) !== wordsIdiomKey(text)) await wordsIdiomFlag(text, { bad: true, t: text, m: fixed || "", om: meaning || "", s: st.sentence.text, renamed: nt });
      await wordsIdiomFlag(nt, { bad: false, meaning: nm });
      wordsRememberIdiom(st.sentence.text, nt, nm);
      wordsAddIdioms(st.sentence.text, [{ text: nt, meaning: nm }]);
      st.idiomTextEdit = false; st.idiomFix = false;
      if (st.expr && st.expr.idiom) wordsCloseCard(); else wordsFillCard();
    });
    box.append(el("div", "dualsub-card-hint", "Il modo di dire giusto e il suo significato:"), tx, tm, save);
    setTimeout(() => tx.focus(), 0);
  }
  row.append(box);
  return row;
}

// Modi di dire che hai segnato come «non è un modo di dire» in questa frase, con questa parola: una riga piccola per
// annullare la segnalazione (prima, una volta segnato, il modo di dire spariva e non c'era modo di tornare indietro)
function wordsFlaggedRow(st) {
  if (!st || !st.sentence || !st.word) return null;
  const sent = " " + wordsSplit(st.sentence.text).map(wordsNorm).join(" ") + " ";
  const w = wordsNorm(st.word);
  const list = Object.entries(wordsIdiomFlags).filter(([k, f]) => f && f.bad && k.split(" ").length > 1 &&
    k.split(" ").map(wordsNorm).every((x) => sent.includes(" " + x + " ")) && k.split(" ").map(wordsNorm).includes(w));
  if (!list.length) return null;
  const box = el("div", "dualsub-idiom-flagged");
  for (const [k, f] of list) {
    const line = el("div", "dualsub-card-hint");
    line.append(document.createTextNode(`🚫 «${f.t || k}» segnato da te come «non è un modo di dire»${f.renamed ? ` (corretto in «${f.renamed}»)` : ""} `));
    const undo = el("button", "dualsub-card-link", "annulla");
    undo.title = "Torna a essere un modo di dire, sottolineato in arancione";
    undo.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      const keep = f.m ? { meaning: f.m } : null;
      delete wordsIdiomFlags[k];
      await wordsIdiomFlag(f.t || k, keep);
      wordsAddIdioms(st.sentence.text, [{ text: f.t || k, meaning: f.m || f.om || "" }]);
      wordsFillCard();
    });
    line.append(undo);
    box.append(line);
  }
  return box;
}

// Pronuncia IPA nella scheda: da Wiktionary, dalla spiegazione del modello o dalle parole già salvate.
function wordsCardIpa(st, d) {
  // Pronuncia IPA: prima Wiktionary (gratis, sempre, anche con la pronuncia del modello spenta). Se lì non c'è, la
  // scrive il modello solo nella stessa richiesta della spiegazione (clic sulla parola), se l'opzione è accesa.
  if (typeof ipaWordsOf !== "function") return;
  const lang = ipaLang(st.sentence.lang, st.sentence.text);
  const ws = ipaWordsOf(st.word, st.sentence.lang);
  const keyOf = (w) => ipaK(lang, w);
  // 1.7.3: la cache della pronuncia si legge a pezzi, solo quando serve: alla prima scheda di questa lingua aspetto un attimo
  if (!ipaCache.loaded(lang + "|")) { ipaCache.load(lang + "|").then(() => { if (wordsCardState === st) wordsFillCard(); }); return; }
  if (d && d.ipa && ws.length === 1 && !ipaCache.get(keyOf(ws[0]))) { ipaCache.set(keyOf(ws[0]), d.ipa); ipaSave(); }
  const vals = ws.map((w) => ipaCache.get(keyOf(w)));
  const whole = ipaCache.get(keyOf(st.word));   // la parola intera (in giapponese, divisa da sola può spezzarsi diversamente)
  const text = whole || (d && d.ipa && ws.length !== 1 ? d.ipa : vals.every(Boolean) && vals.length ? vals.join(" ") : "");
  st.ipa = text;
  // trascrizione in caratteri latini (alfabeti diversi), da Google, gratis
  if (d && d.translit) st.translit = d.translit;
  if (st.translit) { const t = el("div", "dualsub-card-translit", st.translit); t.title = "Trascrizione in caratteri latini"; wordsCard.append(t); }
  const box = el("div", "dualsub-card-ipa");
  if (text) {
    box.textContent = "/" + text + "/";
    box.title = "Pronuncia in alfabeto fonetico internazionale (IPA)" + (st.ipaSource ? " — da " + st.ipaSource : "");
    wordsCard.append(box);
    return;
  }
  if (!ws.length) return;
  const tryWikt = async () => {
    if (typeof DS_ETYM === "undefined" || ws.length !== 1 || st.wiktIpaTried || !/^[a-z]{2,3}$/.test(lang)) return false;
    st.wiktIpaTried = true;
    const r = await DS_ETYM.ipa(st.word, lang, settings.targetLang);
    if (r.info && st.learn && !st.learn.wikt) st.learn.wikt = r.info;
    if (!r.ipa) return false;
    ipaCache.set(keyOf(st.word), r.ipa); if (ws[0] !== st.word) ipaCache.set(keyOf(ws[0]), r.ipa);
    ipaSave();
    st.ipaSource = r.source || "Wiktionary";
    return true;
  };
  const canWikt = typeof DS_ETYM !== "undefined" && ws.length === 1 && !st.wiktIpaTried && /^[a-z]{2,3}$/.test(lang);
  if (canWikt) {
    box.textContent = "IPA …";
    box.title = "Cerco la pronuncia su Wiktionary (gratis)";
    wordsCard.append(box);
    if (!st.ipaAsked) {
      st.ipaAsked = true;
      // solo se la scheda resta aperta almeno 0,8 secondi (passando veloce sopra le parole non parte niente)
      setTimeout(async () => {
        if (wordsCardState !== st) { st.ipaAsked = false; return; }
        await tryWikt();
        if (wordsCardState === st && wordsCard) wordsFillCard();
      }, 800);
    }
    return;
  }
  // non c'è su Wiktionary: arriva con la spiegazione del modello (una sola richiesta), se l'opzione è accesa
  if (ipaOn() && !st.contextual && wordsLlmAvailable()) {
    const name = wordsDefineEngine().E.label.split(" (")[0].split(",")[0];
    box.className = "dualsub-card-ipa dualsub-card-hint";
    box.textContent = `IPA: non c'è su Wiktionary — arriva con «✨ Spiega con ${name}»`;
    wordsCard.append(box);
  }
}

// Strumenti per imparare (learn.js): frequenza, "la conosco", genere, scrittura corretta, etimologia, audio di
// madrelingua, tabella, esempi veri, falsi amici. Le parti gratis si caricano se la scheda resta aperta un attimo;
// quelle del modello arrivano con la spiegazione (clic sulla parola), nella stessa richiesta.
function wordsCardLearn(st, d) {
  if (!settings || typeof DS_LEARN === "undefined") return;
  if (st.expr && wordsSplit(st.word).length > 2) {
    // espressione lunga (modo di dire): niente scheda di studio, ma l'immagine per Anki sì (con l'opzione accesa)
    if (settings.ankiImage && !st.expr.han) {
      st.learn = st.learn || {};
      st.learn.img = st.learn.img || { list: [], i: 0 };
      const lg = (d && d.lang) || (st.sentence.lang || "").split("-")[0] || DualSubs.guessLang(st.sentence.text) || "";
      wordsCard.append(DS_LEARN.imagePicker(st.learn.img, { word: st.word, lang: String(lg).split("-")[0], autoload: true, rerender: () => { if (wordsCardState === st && wordsCard) wordsFillCard(); } }));
    }
    return;
  }
  const lang = (d && d.lang) || (st.sentence.lang || "").split("-")[0] || DualSubs.guessLang(st.sentence.text) || "";
  st.learn = st.learn || {};
  if (d && d.gdict) st.learn.gdict = d.gdict;   // dizionario di Google (resta anche dopo la spiegazione del modello)
  const llm = st.contextual && d && !d.error && !d.fallback && d.source && !/^Google/.test(d.source) ? d : null;
  // etimologia arrivata con la spiegazione del modello (solo se Wiktionary non l'aveva)
  if (llm && llm.etymology && (!st.learn.wikt || !st.learn.wikt.trans)) {
    DS_ETYM.put(st.word, lang, settings.targetLang, llm.etymology, String(llm.source || "").split(" (")[0]);
    st.learn.wikt = { ...(st.learn.wikt || {}), text: llm.etymology, trans: llm.etymology, source: String(llm.source || "").split(" (")[0], none: false };
  }
  const name = wordsLlmAvailable() ? wordsDefineEngine().E.label.split(" (")[0].split(",")[0] : "";
  wordsCard.append(DS_LEARN.render({
    word: st.word, lemma: d && d.lemma, lang, target: settings.targetLang, sentence: st.sentence.text, prefs: settings, llm, st: st.learn, gdict: st.learn.gdict,
    idOpts: wordsIdiomPanelOpts(st),
    // 1.6.6: i pezzi della scheda arrivano uno dopo l'altro (frequenza, Wiktionary, esempi, grafico…): ognuno rifaceva da capo
    // tutta la scheda. Quelli che arrivano a ridosso uno dell'altro (80 ms) si fondono in un solo disegno
    rerender: () => {
      if (st.rrT) return;
      st.rrT = setTimeout(() => { st.rrT = 0; if (wordsCardState === st && wordsCard) wordsFillCard(); }, 80);
    },
    stale: () => wordsCardState !== st,
    speak: (t, l) => DS_TTS.speak(t, l || wordsSpeechLang(), { lang: settings.ttsLang, voice: settings.ttsVoice }),
    etymHint: name && !st.contextual ? `Premi «✨ Spiega con ${name}»: arriva insieme alla spiegazione (una richiesta sola).` : "",
    onKnown: () => { wordsOrigKey = ""; },
    // ✨ del singolo kanji: finito il modello di oggi, il prossimo (dsMarkBlocked)
    onLlmDaily: (e) => dsMarkBlocked(e.id, e.model),
    // kanji/caratteri della parola nel vocabolario, ognuno come voce a sé (toggle = uno solo: lo salva o lo toglie)
    isSaved: (l, ch) => !!vocab[vocabId(l, "", ch)],
    saveChars: async (entries, toggle) => {
      const { vocab: cur = {} } = await DS_EXT.storage.local.get({ vocab: {} });
      const added = [];
      for (const e of entries) {
        const id = vocabId(e.lang, "", e.word);
        if (cur[id]) { if (toggle) delete cur[id]; continue; }
        cur[id] = { ...e, id, ipa: "", etym: "", sentence: st.sentence.text, sentenceTrans: st.sentence.trans || "",
          videoId: new URLSearchParams(location.search).get("v") || "", time: Math.max(0, Math.floor((st.sentence.start || 0) / 1000)),
          title: document.title.replace(/\s*-\s*YouTube\s*$/, ""), fromWord: st.word, added: Date.now(), status: "learning" };
        added.push(cur[id]);
      }
      await DS_EXT.storage.local.set({ vocab: cur });
      vocab = cur; vocabRebuild();
      if (settings.ankiAuto) for (const e of added) await wordsAnki(null, e);
    },
    // un kanji o carattere cinese della parola, aperto nella sua scheda (resta il collegamento per tornare alla parola)
    openWord: (ch, pre) => {
      const a = wordsAnchorOf(st);
      if (!a) return;
      const back = { fromWord: st.expr && st.expr.han ? st.expr.fromWord : st.word, backContextual: st.contextual };
      wordsCloseCard();
      const quick = pre && pre.meaning ? { meaning: pre.meaning, pos: pre.pos, source: "dizionario dei caratteri (arriva Google…)", lang: pre.lang } : null;
      wordsOpenCard(a, true, { text: ch, spans: [], han: true, quick, ...back });
    },
    // immagine cambiata: se la parola è già nel vocabolario, la aggiorno anche lì
    onImage: (url) => wordsUpdateSavedImage(url),
    engine: () => {
      if (!wordsLlmAvailable()) return null;
      const e = wordsDefineEngine();
      if (!e || !e.E || (e.E.kind !== "openai" && e.E.kind !== "claude")) return null;
      return { ...e, name: e.E.label.split(" (")[0].split(",")[0] };
    }
  }));
}

function wordsEntry() {
  const st = wordsCardState;
  const d = st.data && !st.data.error ? st.data : {};
  const lang = d.lang || st.sentence.lang || "";
  return {
    id: vocabId(lang, d.lemma, st.word),
    word: st.word, lemma: d.lemma || "", pos: d.pos || "", meaning: wordsWordFix(st, d) || d.meaning || "",
    explanation: d.explanation || "", lang, ipa: st.ipa || "",
    ...(typeof DS_LEARN !== "undefined" && st.learn ? DS_LEARN.entryExtras(st.learn, lang) : { etym: st.etym || "" }),
    sentence: st.sentence.text, sentenceTrans: st.sentence.trans || "",
    // 1.6.3: altre spiegazioni salvate di questa parola (altri modelli) e i modi di dire trovati con la parola: finiscono sulla carta di Anki
    expls: (typeof DS_EXPL !== "undefined" ? DS_EXPL.list(lang, st.word) : []).map((x) => x.d && x.d.explanation).filter((x) => x && x !== (d.explanation || "")).slice(0, 2),
    idioms: (wordsIdioms.get(st.sentence.text) || []).filter((it) => wordsSplit(it.text).some((p) => wordsNorm(p) === wordsNorm(st.word))).slice(0, 3).map((it) => ({ text: it.text, meaning: it.meaning || "" })),
    videoId: new URLSearchParams(location.search).get("v") || "",
    time: Math.max(0, Math.floor((st.sentence.start || 0) / 1000)),
    title: document.title.replace(/\s*-\s*YouTube\s*$/, ""),
    added: Date.now(), status: "learning"
  };
}

function wordsRefreshStar() {
  if (!wordsCard || !wordsCardState) return;
  const star = wordsCard.querySelector(".dualsub-star");
  if (!star) return;
  const saved = !!vocab[wordsEntry().id];
  star.textContent = saved ? "★" : "☆";
  star.title = saved ? "Togli dal vocabolario" : "Salva nel vocabolario";
  star.classList.toggle("on", saved);
}

async function wordsSave() {
  if (!wordsCardState) return;
  const entry = wordsEntry();
  const adding = !vocab[entry.id];
  // immagine per la carta di Anki, solo se l'hai chiesta nel popup: quella scelta nella scheda, altrimenti la prima trovata
  if (settings.ankiImage && adding) entry.image = await wordsImageFor(entry);
  await vocabToggle(entry);
  if (adding && settings.ankiAuto) wordsAnki(null, entry);
}

async function wordsImageFor(entry) {
  if (typeof DS_LEARN === "undefined") return "";
  const st = wordsCardState;
  const ch = st && st.learn ? DS_LEARN.chosenImage(st.learn.img) : undefined;
  return ch !== undefined ? ch : await DS_LEARN.image(entry.lemma || entry.word, entry.lang);
}
async function wordsUpdateSavedImage(url) {
  if (!wordsCardState) return;
  const id = wordsEntry().id;
  const { vocab: cur = {} } = await DS_EXT.storage.local.get({ vocab: {} });
  if (!cur[id]) return;
  cur[id].image = url;
  await DS_EXT.storage.local.set({ vocab: cur });
}

// Anki (AnkiConnect): la carta va nel mazzo della sua lingua ("Lingue::Inglese"), come in Parole al Volo
async function wordsAnki(btn, given) {
  const st = wordsCardState;
  let entry = given || (st && wordsEntry());
  if (!entry) return;
  if (!given && settings.ankiImage) {
    const saved = vocab[entry.id];
    entry.image = saved && saved.image != null ? saved.image : await wordsImageFor(entry);
  }
  if (btn) { btn.disabled = true; btn.textContent = "…"; }
  // 1.6.2: la registrazione di un madrelingua per la carta (se non c'è, Anki riceve la voce sintetica)
  if (settings.ankiAudio !== false && typeof DS_LEARN !== "undefined" && !entry.rec) {
    const same = st && st.word === entry.word;
    entry = { ...entry, rec: await DS_LEARN.ankiRec({ word: entry.word, lang: entry.lang, target: settings.targetLang, lemma: entry.lemma, st: same ? st.learn : null }) };
  }
  let r;
  try { r = await DS_EXT.runtime.sendMessage({ type: "ankiAdd", entries: [entry], update: !!btn }); } catch (e) { r = { error: String(e.message || e) }; }
  const ok = r && !r.error;
  if (btn && btn.isConnected) {
    btn.disabled = false;
    btn.textContent = ok ? (r.upd ? "✓ Anki aggiornata" : r.dup ? "✓ già in Anki" : "✓ Anki") : "Anki";
    btn.title = ok ? `Mazzo «${r.deck}»` + (r.imgNote ? " — " + r.imgNote : "") : r && r.error ? r.error : "Nessuna risposta";
  }
  if (ok) {
    const { vocab: cur = {} } = await DS_EXT.storage.local.get({ vocab: {} });
    if (cur[entry.id]) { cur[entry.id].anki = 1; await DS_EXT.storage.local.set({ vocab: cur }); }
  }
  if (wordsCardState === st && wordsCard) {
    let n = wordsCard.querySelector(".dualsub-anki-note");
    if (!n) { n = el("div", "dualsub-card-hint dualsub-anki-note"); wordsCard.append(n); }
    n.textContent = ok ? (r.upd ? "Carta aggiornata in Anki" : r.dup ? "Era già in Anki" : "Aggiunta ad Anki") + ", mazzo «" + r.deck + "»" + (r.imgNote ? " (" + r.imgNote + ")" : entry.image && !r.dup ? ", con l'immagine" : "") + dsAnkiAudioNote(r) + "." : "Anki: " + ((r && r.error) || "nessuna risposta");
  }
}

let wordsOwnSkipUntil = 0;   // il modello scelto per le spiegazioni non ha risposto: per qualche minuto uso la fila
// il modello delle spiegazioni: quello scelto per «Spiegazioni» in «Modello per ogni compito» (dsTaskModel)
function wordsDefineEngine() {
  const e = wordsDefineEngine0();
  if (!e || e.id === "google") return e;
  const x = dsTM("explainEngine", engineById(e.id));
  if (!x.exhausted) return x;
  // 1.6.1: finiti oggi tutti i modelli di quel servizio per le spiegazioni: il primo altro modello pronto della fila
  const isLlm = (y) => y.E.kind === "openai" || y.E.kind === "claude";
  return C.engineOrder(settings).filter((id) => id !== e.id && C.ENGINES[id] && isLlm({ E: C.ENGINES[id] }) && !dsIsBlocked(id))
    .map((id) => dsTM("explainEngine", engineById(id))).find((y) => dsReady(y)) || x;
}
function wordsDefineEngine0() {
  const e = track && !liveActive() ? trackEngine() : liveEngine();
  const isLlm = (x) => x.E.kind === "openai" || x.E.kind === "claude";
  // il primo modello pronto nell'ordine scelto nel popup («Ordine dei servizi»)
  const first = () => C.engineOrder(settings).filter((id) => !dsIsBlocked(id) && C.ENGINES[id] && isLlm({ E: C.ENGINES[id] })).map(engineById).find(dsReady);
  // scelto nel popup «Spiegazioni con»: quello, se è pronto e ha ancora richieste oggi
  const own = settings && settings.explainEngine && C.ENGINES[settings.explainEngine] && Date.now() > wordsOwnSkipUntil ? engineById(settings.explainEngine) : null;
  if (own && isLlm(own) && dsReady(own) && !dsIsBlocked(own.id)) return own;
  if (e.E.kind === "youtube") return first() || GOOGLE_ENGINE;
  const u = dsUsable(e);
  if (isLlm(u) && dsReady(u)) return u;
  // si traduce con Google, DeepL o Microsoft, o il modello scelto ha finito la quota di oggi: per spiegazioni e
  // allineamento uso il primo modello pronto della fila (sempre e solo quando lo chiedi con «✨ Spiega con…»)
  return first() || u;
}

async function wordsLoadDefinition(word, sentence, anchor, contextual) {
  const my = ++wordsReqId;
  // «⇄ Altro modello»: quello scelto nella scheda, solo per questa spiegazione
  const pick = contextual && wordsCardState && wordsCardState.engineAlt ? engineById(wordsCardState.engineAlt) : null;
  // il modello scelto nella scheda, se non è finito oggi; altrimenti il primo pronto di quel servizio
  const mAlt = pick && wordsCardState.modelAlt && !dsModelBlocked(pick.id, wordsCardState.modelAlt) ? wordsCardState.modelAlt : "";
  const pickE = pick ? (mAlt ? { ...pick, model: mAlt, exhausted: false } : dsTM("explainEngine", pick)) : null;
  const e = contextual ? (pickE && dsReady(pickE) ? pickE : wordsDefineEngine()) : GOOGLE_ENGINE;
  // nella stessa richiesta: etimologia (solo se Wiktionary non l'ha data) e pronuncia (solo se accesa)
  const elang = (sentence.lang || "").split("-")[0] || DualSubs.guessLang(sentence.text) || "";
  const known = typeof DS_ETYM !== "undefined" ? DS_ETYM.peek(word, elang, settings.targetLang) : null;
  const wantEtym = contextual && settings.etym !== false && !(known && known.trans);
  const precise = !!(contextual && wordsCardState && wordsCardState.precise);
  const cacheKey = [word.toLowerCase(), sentence.text, e.id, e.model, settings.targetLang].join("|") + (wantEtym ? "|e" : "") +
    (settings.learnLlmExtra !== false || settings.learnSpell !== false ? "|x" : "") + (precise ? "|p" : "");
  let data = precise ? null : wordsDefCache.get(cacheKey);
  // clic diretto (senza passare prima il mouse): il significato di Google arriva subito, il modello dopo
  if (!data && contextual && wordsCardState && !wordsCardState.quick) {
    const st0 = wordsCardState;
    DS_EXT.runtime.sendMessage({ type: "define", engine: "google", target: settings.targetLang, word, sentence: sentence.text, lang: sentence.lang || "" })
      .then((g) => { if (wordsCardState === st0 && !st0.data && g && !g.error) { st0.quick = g; wordsFillCard(); wordsPlace(anchor); } }).catch(() => {});
  }
  if (!data) {
    if (contextual && e.id !== "google") dsUserLlm = { id: e.id, at: Date.now() };
    try {
      data = await dsSendLong({
        type: "define", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl,
        target: settings.targetLang, word, sentence: sentence.text, sentenceTrans: sentence.trans || "", lang: sentence.lang || "",
        precise, avoid: precise ? wordsCardState.avoid : undefined, idioms: contextual && wordsSplit(word).length === 1, etym: wantEtym || (precise && settings.etym !== false), ipa: settings.ipa !== false && !(wordsCardState && wordsCardState.ipa), extra: settings.learnLlmExtra !== false || settings.learnSpell !== false,
        // la frase tradotta da Google/DeepL: nella stessa richiesta anche una traduzione corretta della frase intera
        sentFix: contextual && !!sentence.trans && (() => { try { const te = track && !liveActive() ? trackEngine() : liveEngine(); return te.E.kind !== "openai" && te.E.kind !== "claude"; } catch { return false; } })()
      });
    } catch (err) {
      data = { error: String(err.message || err) };
    }
    if (dsUserLlm.id === e.id) dsUserLlm = { id: "", at: 0 };
    if (!data) data = { error: "nessuna risposta" };
    // il modello scelto per le spiegazioni (per esempio Ollama) non risponde: rifaccio con il primo pronto della fila
    // (il background, se il modello non risponde, rimanda il significato di Google con fallback: true)
    if ((data.error || data.fallback) && !data.llmDaily && contextual && !pick && settings.explainEngine === e.id && Date.now() > wordsOwnSkipUntil) {
      wordsOwnSkipUntil = Date.now() + 5 * 60e3;
      const alt = wordsDefineEngine();
      if (alt && alt.id !== e.id && (alt.E.kind === "openai" || alt.E.kind === "claude")) {
        const why = String(data.error || (data.source || "").replace(/^[^(]*\(/, "").replace(/\)$/, "")).slice(0, 90), name = e.E.label.split(" (")[0].split(",")[0];
        await wordsLoadDefinition(word, sentence, anchor, contextual);
        if (wordsCardState && wordsCardState.data && !wordsCardState.data.error) {
          wordsCardState.data.source = (wordsCardState.data.source || "") + " — " + name + " non risponde (" + why + ")";
          wordsFillCard(); wordsPlace(anchor);
        }
        return;
      }
    }
    if (data.llmDaily) {
      // 1.6.1: finito questo modello: rifaccio subito con il prossimo (altro modello dello stesso servizio, poi la fila)
      dsMarkBlocked(e.id, e.model);
      const alt = contextual && my === wordsReqId ? (pick ? dsTM("explainEngine", engineById(pick.id)) : wordsDefineEngine()) : null;
      if (alt && dsReady(alt) && (alt.E.kind === "openai" || alt.E.kind === "claude") && (alt.id !== e.id || alt.model !== e.model)) {
        if (pick && wordsCardState) wordsCardState.engineAlt = alt.id;
        return wordsLoadDefinition(word, sentence, anchor, contextual);
      }
    }
    // 1.6.2: il modello ha risposto male (risposta illeggibile o tagliata, nessuna risposta): per mezz'ora salto quel
    // modello e rifaccio subito con il prossimo dell'elenco (al massimo 3 volte per spiegazione)
    if ((data.error || data.fallback) && !data.llmDaily && contextual && my === wordsReqId && e.id !== "google" && !e.E.local &&
        wordsCardState && (wordsCardState.failTries || 0) < 3) {
      wordsCardState.failTries = (wordsCardState.failTries || 0) + 1;
      dsMarkBlocked(e.id, e.model, 30 * 60e3);
      const alt = pick ? dsTM("explainEngine", engineById(pick.id)) : wordsDefineEngine();
      if (alt && dsReady(alt) && (alt.E.kind === "openai" || alt.E.kind === "claude") && (alt.id !== e.id || alt.model !== e.model)) {
        if (pick && wordsCardState) wordsCardState.engineAlt = alt.id;
        return wordsLoadDefinition(word, sentence, anchor, contextual);
      }
    }
    if (data.error) data = { error: "Non riesco a trovare il significato: " + data.error };
    else if (!data.fallback) {
      wordsDefRemember(cacheKey, data);
      // solo le spiegazioni dei modelli (quelle di Google sono gratis): restano nelle spiegazioni salvate (🗂)
      if (e.id !== "google" && typeof DS_EXPL !== "undefined") DS_EXPL.put(data.lang || elang, word, sentence.text, e.E.label.split(" (")[0].split(",")[0], e.model, data);
    }
  }
  if (data && data.etymology && typeof DS_ETYM !== "undefined") DS_ETYM.put(word, (data.lang || elang), settings.targetLang, data.etymology, data.source.split(" (")[0]);
  if (data && data.wordIdioms && wordsCardState && wordsCardState.word === word) wordsIdiomsFromExplain(wordsCardState, data, word);   // 1.6.7: arrivati con la spiegazione
  if (data && data.expression && wordsSplit(data.expression).length > 1) wordsAddIdioms(sentence.text, [{ text: data.expression, meaning: data.expressionMeaning || "" }]);
  if (my !== wordsReqId || !wordsCardState) return;
  // senza modello (scheda appena aperta): se questa parola in questa frase è già stata spiegata, la mostro subito
  wordsExplHookInit();
  if (!contextual && typeof DS_EXPL !== "undefined") await DS_EXPL.load((data && data.lang) || elang);   // 1.7.3: le spiegazioni salvate si leggono a pezzi per lingua
  if (my !== wordsReqId || !wordsCardState) return;
  const saved = !contextual && data && !data.error && typeof DS_EXPL !== "undefined" ? DS_EXPL.same(data.lang || elang, word, sentence.text) : null;
  if (saved && !(wordsCardState.expr && wordsCardState.expr.han)) {
    wordsCardState.contextual = true;
    wordsCardState.quick = data;
    wordsCardState.data = wordsSavedData(saved);
  } else {
    wordsCardState.data = data;
    if (contextual && e.id !== "google" && data && !data.error && !data.fallback) wordsCardState.llmBy = e.id + "|" + e.model;
    wordsCardState.precise = false;
  }
  wordsFillCard();
  wordsPlace(anchor);
}
// una spiegazione salvata (🗂), pronta per la scheda: la fonte dice da dove viene
function wordsSavedData(x) {
  return { ...x.d, source: x.e + (x.m ? " (" + x.m + ")" : "") + " — salvata il " + DS_EXPL.when(x.at), savedAt: x.at };
}
// 🗂 N: tutte le spiegazioni salvate di questa parola (altre frasi, altri modelli); clic su una per vederla
function wordsSavedRow(st) {
  if (typeof DS_EXPL === "undefined" || (st.expr && st.expr.han)) return null;
  const lang = (st.data && st.data.lang) || (st.quick && st.quick.lang) || (st.sentence.lang || "").split("-")[0];
  const all = DS_EXPL.list(lang, st.word);
  if (!all.length) return null;
  const box = el("div", "dualsub-saved");
  const b = el("button", "dualsub-card-link dualsub-savedbtn", "🗂 " + all.length + (all.length === 1 ? " spiegazione salvata" : " spiegazioni salvate") + (st.savedOpen ? " ▴" : " ▾"));
  b.title = "Le spiegazioni dei modelli già chieste per questa parola (anche in altre frasi): nessuna richiesta nuova";
  b.addEventListener("click", (ev) => { ev.stopPropagation(); st.savedOpen = !st.savedOpen; wordsFillCard(); });
  box.append(b);
  if (!st.savedOpen) return box;
  const here = DS_EXPL.norm(st.sentence.text).slice(0, 400);
  for (const x of all) {
    const item = el("div", "dualsub-saved-item" + (st.data && st.data.savedAt === x.at ? " dualsub-saved-on" : ""));
    const head = el("div", "dualsub-saved-head");
    head.append(el("b", null, x.e), el("span", "dualsub-card-hint", (x.m ? " " + x.m : "") + " · " + DS_EXPL.when(x.at)));
    const del = el("button", "dualsub-card-btn dualsub-saved-del", "✕");
    del.title = "Togli questa spiegazione salvata";
    del.addEventListener("click", (ev) => { ev.stopPropagation(); DS_EXPL.remove(lang, st.word, x.at); wordsFillCard(); });
    head.append(del);
    item.append(head, el("div", "dualsub-saved-mean", x.d.meaning || x.d.definition || ""));
    item.append(el("div", "dualsub-card-hint", x.s === here ? "in questa frase" : "spiegata nella frase: «" + x.s.slice(0, 140) + (x.s.length > 140 ? "…" : "") + "»"));
    item.title = "Mostra questa spiegazione nella scheda";
    item.addEventListener("click", (ev) => {
      ev.stopPropagation();
      if (!st.contextual) { st.quick = st.data && !st.data.error ? st.data : st.quick; st.contextual = true; }
      st.data = wordsSavedData(x);
      wordsFillCard();
    });
    box.append(item);
  }
  return box;
}

// Durante la pronuncia abbasso io il video, e alla fine lo riporto esattamente al volume di prima
function wordsDuck() {
  const v = getVideo();
  if (!v || v.paused || v.muted) return () => {};
  const before = v.volume;
  const low = Math.round(before * 0.3 * 100) / 100;
  v.volume = low;
  let restored = false;
  const restore = () => {
    if (restored) return;
    restored = true;
    // se nel frattempo hai cambiato tu il volume, non lo tocco
    if (Math.abs(v.volume - low) < 0.02) v.volume = before;
  };
  setTimeout(restore, 12000); // sicurezza: il volume torna comunque
  return restore;
}

// Lingua della pronuncia: quella scelta nel popup, altrimenti quella della parola o del video
function wordsSpeechLang() {
  const st = wordsCardState;
  if (settings.ttsLang) return settings.ttsLang;
  const d = st && st.data && !st.data.error ? st.data : null;
  return (d && d.lang) || (st && st.sentence.lang) || "";
}

// rate: velocità (0,75 = lenta); times: quante volte di fila
let wordsReplayLoop = null;
// ---------- ↺ Torna alla frase che stavi leggendo ----------
// Ti fermi su una parola (scheda aperta o mouse sulle parole) e intanto il video va avanti: il pulsante ↺ accanto ai
// sottotitoli torna all'inizio di quella frase e la riascolta. Senza una frase ricordata, riascolta quella sotto il video.
let wordsReading = null;
function wordsMarkReading(sentence) {
  if (sentence && sentence.text) wordsReading = { start: sentence.start || 0, end: sentence.end || 0, text: sentence.text, at: Date.now(), vid: typeof currentVideoId === "function" ? currentVideoId() : "" };
  wordsBackButtonUpdate();
}
function wordsBackTarget() {
  const v = getVideo();
  let r = wordsReading;
  // 1.7.28: la frase che leggevi vale solo per lo stesso video, se il video è andato avanti oltre di lei (non se hai riavvolto prima o dentro)
  // e per pochi minuti: prima ↺ restava anche dopo aver cambiato video o essere tornato indietro
  if (r && v) {
    const cv = typeof currentVideoId === "function" ? currentVideoId() : "";
    if ((r.vid && cv && r.vid !== cv) || v.currentTime * 1000 < (r.end || r.start) - 300 || Date.now() - r.at > 3 * 60000) { wordsReading = null; r = null; }
  }
  if (r && v && !(wordsCurrent && wordsCurrent.text === r.text && Math.abs((wordsCurrent.start || 0) - r.start) < 500)) return r;
  return wordsCurrent && wordsCurrent.text ? { start: wordsCurrent.start || 0, end: wordsCurrent.end || 0, text: wordsCurrent.text } : r;
}
function wordsBackButton() {
  const b = document.createElement("button");
  b.className = "dualsub-fixbtn dualsub-backbtn";
  b.textContent = "↺";
  b.addEventListener("click", (e) => {
    e.stopPropagation();
    const v = getVideo(), t = wordsBackTarget();
    if (!v || !t) return;
    wordsReading = null;
    wordsAutoPaused = false;
    if (wordsCardState) wordsCloseCard();
    wordsReplayLoop = null;
    wordsReplayUntil = null;
    v.currentTime = Math.max(0, t.start / 1000 - 0.3);
    v.play().catch(() => {});
    wordsBackButtonUpdate();
  });
  return b;
}
function wordsBackButtonUpdate() {
  const b = overlay && overlay.querySelector(".dualsub-backbtn");
  if (!b) return;
  const t = wordsBackTarget();
  const back = !!(t && wordsReading && t === wordsReading);
  b.classList.toggle("dualsub-has-target", !!t);
  // appena superata la frase che leggevi, ↺ resta in vista (in giallo) per un minuto, anche senza passare il mouse
  b.classList.toggle("dualsub-back-far", back && Date.now() - wordsReading.at < 60000);
  const short = t ? (t.text.length > 40 ? t.text.slice(0, 40) + "…" : t.text) : "";
  b.title = !t ? "Riascolta la frase" : back ? `Torna alla frase che stavi leggendo e riascoltala: «${short}»` : `Riascolta questa frase: «${short}»`;
}

function wordsReplay(rate = 1, times = 1) {
  const v = getVideo();
  if (!v || !wordsCardState) return;
  const s = wordsCardState.sentence;
  wordsAutoPaused = false;
  wordsCloseCard();
  if (!wordsReplayLoop) wordsReplayLoop = { prevRate: v.playbackRate };
  wordsReplayLoop.start = Math.max(0, (s.start || 0) / 1000 - 0.2);
  wordsReplayLoop.left = Math.max(0, times - 1);
  v.playbackRate = rate;
  v.currentTime = wordsReplayLoop.start;
  wordsReplayUntil = s.end || null;
  v.play().catch(() => {});
}

// Chiamata da tick() a ogni aggiornamento
function wordsTick(t, video) {
  if (wordsReplayUntil != null && t >= wordsReplayUntil) {
    if (wordsReplayLoop && wordsReplayLoop.left > 0) {   // ancora una volta
      wordsReplayLoop.left--;
      video.currentTime = wordsReplayLoop.start;
      return;
    }
    wordsReplayUntil = null;
    video.pause();
    if (wordsReplayLoop) { video.playbackRate = wordsReplayLoop.prevRate || 1; wordsReplayLoop = null; }
  }
}

// ---------- Copiare il testo e aprire i servizi di traduzione in un'altra scheda ----------
function wordsCopy(text, btn) {
  text = String(text || "").trim();
  if (!text) return;
  const done = (ok) => {
    if (!btn) return;
    const old = btn.dataset.label || btn.textContent;
    btn.dataset.label = old;
    btn.textContent = ok ? "Copiato ✓" : "Non riesco a copiare";
    setTimeout(() => { if (btn.isConnected) btn.textContent = old; }, 1400);
  };
  const fallback = () => {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0";
      document.body.append(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      done(ok);
    } catch { done(false); }
  };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(() => done(true), fallback);
  else fallback();
}

// Indirizzi dei servizi per consultare un testo (in config.js, li usa anche la pagina della trascrizione)
const wordsServiceLinks = (text, from, to, isWord, lemma) => dsServiceLinks(text, from, to, isWord, lemma);

// Riga di collegamenti: "Apri in: Google Traduttore · DeepL · …" (si aprono in un'altra scheda)
function wordsLinksRow(getText, from, to, isWord, lemma) {
  const box = el("div", "dualsub-links");
  box.append(el("span", "dualsub-links-label", "Apri in: "));
  const first = wordsServiceLinks(getText() || "x", from, to, isWord, lemma);
  first.forEach((l, i) => {
    const a = el("a", "dualsub-link", l.label);
    a.href = l.url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.title = l.title || "Si apre in un'altra scheda";
    // al momento del clic uso il testo aggiornato (per esempio la parte selezionata): lo leggo quando premi il tasto,
    // prima che il clic tolga la selezione
    const update = () => {
      const cur = wordsServiceLinks(getText(), from, to, isWord, lemma).find((x) => x.label === l.label);
      if (cur) a.href = cur.url;
    };
    a.addEventListener("mousedown", (ev) => { update(); ev.preventDefault(); });
    a.addEventListener("click", (ev) => {
      ev.stopPropagation();
      if (l.copy) wordsCopy(getText());   // da incollare nella pagina del servizio
      const v = getVideo();
      if (v && !v.paused) v.pause();
    });
    if (i) box.append(document.createTextNode(" · "));
    box.append(a);
  });
  return box;
}

// Testo selezionato con il mouse dentro un elemento (se c'è), altrimenti il testo dato
function wordsSelectedIn(node, whole) {
  try {
    const sel = window.getSelection();
    if (sel && !sel.isCollapsed && node && node.contains(sel.anchorNode) && node.contains(sel.focusNode)) {
      const t = sel.toString().replace(/\s+/g, " ").trim();
      if (t) return t;
    }
  } catch {}
  return whole;
}

// Scheda "Copia": la frase intera, selezionabile con il mouse, con i pulsanti per copiarla e consultarla
function wordsOpenLineCard(anchor) {
  if (!wordsCurrent || !overlay) return;
  if (wordsCard) wordsCard.remove();
  const s = wordsCurrent;
  wordsCardState = { pinned: true, word: null, copy: true, sentence: s, data: null };
  wordsCard = el("div", "dualsub-card dualsub-copycard");
  overlay.append(wordsCard);
  const v = getVideo();
  if (v && !v.paused) { v.pause(); wordsAutoPaused = true; }

  const head = el("div", "dualsub-card-head");
  head.append(el("div", "dualsub-card-title", "Copia o consulta la frase"));
  const close = el("button", "dualsub-card-btn", "×");
  close.title = "Chiudi";
  close.addEventListener("click", wordsCloseCard);
  head.append(close);
  const orig = el("div", "dualsub-copy-text", s.text || "");
  const trans = el("div", "dualsub-copy-text dualsub-copy-trans", s.trans || "");
  const hint = el("div", "dualsub-card-hint", "Puoi selezionare una parte del testo con il mouse: i pulsanti useranno solo quella.");
  wordsCard.append(head, orig);
  if (s.trans) wordsCard.append(trans);
  wordsCard.append(hint);

  const row = el("div", "dualsub-copy-actions");
  const b = (label, title, get) => {
    const btn = el("button", "dualsub-card-replay", label);
    btn.title = title;
    btn.addEventListener("click", (ev) => { ev.stopPropagation(); wordsCopy(get(), btn); });
    row.append(btn);
  };
  // 1.7.13: leggere il testo (o la parte selezionata), anche piano; i testi lunghi vengono letti per intero a pezzi
  const rd = (label, title, rate) => {
    const btn = el("button", "dualsub-card-replay", label);
    btn.title = title;
    btn.addEventListener("click", async (ev) => {
      ev.stopPropagation();
      const restore = wordsDuck();
      try {
        const r = await DS_TTS.speak(wordsSelectedIn(orig, s.text), s.lang || DualSubs.guessLang(s.text) || "", { lang: settings.ttsLang, voice: settings.ttsVoice, rate });
        btn.title = title + " — " + r.how;
        await Promise.race([r.done, new Promise((ok) => setTimeout(ok, 120000))]);
      } catch {}
      restore();
    });
    row.append(btn);
  };
  rd("🔈 Leggi", "Leggi la frase (o la parte selezionata) con la voce sintetica", 0);
  rd("🐢 Lenta", "Leggila lentamente", 0.6);
  b("Copia originale", "Copia la frase originale (o la parte selezionata)", () => wordsSelectedIn(orig, s.text));
  if (s.trans) {
    b("Copia traduzione", "Copia la traduzione (o la parte selezionata)", () => wordsSelectedIn(trans, s.trans));
    b("Copia tutte e due", "Copia originale e traduzione, una sotto l'altra", () => s.text + "\n" + s.trans);
  }
  wordsCard.append(row);
  const src = (s.lang || "").split("-")[0] || DualSubs.guessLang(s.text) || "";
  wordsCard.append(wordsLinksRow(() => wordsSelectedIn(orig, s.text), src, settings.targetLang, false));
  wordsPlace(anchor);
}

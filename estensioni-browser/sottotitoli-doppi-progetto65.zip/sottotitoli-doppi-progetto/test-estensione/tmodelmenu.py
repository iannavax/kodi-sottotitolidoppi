# 1.7.13: testo lungo letto per intero (a pezzi), limite dei modelli: il pulsante «Spiega» resta
import asyncio, sys, datetime
sys.path.insert(0, "/home/claude/e2e")
from charness import *
LONG = "Prima frase del testo evidenziato. " + "Seconda frase, un po' più lunga, con una virgola e altre parole per arrivare lontano. " * 2 + "Terza frase finale che non deve essere persa!"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'en', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1000)
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        print("1. nella testata:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card-title .dualsub-explainctl button')].map(b=>b.textContent)"))
        await pg.locator(".dualsub-explainmenu").click(); await pg.wait_for_timeout(1500)
        items = await pg.evaluate("[...document.querySelectorAll('.dualsub-modelmenu button, .dualsub-modelmenu-head')].map(b=>b.textContent)")
        print("2. tendina:", items)
        await pg.locator(".dualsub-modelmenu-item").nth(1).click(); await pg.wait_for_timeout(3500)
        print("3. dopo la scelta:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card-title .dualsub-explainctl button')].map(b=>b.textContent)"), "| fonte:", await pg.evaluate("(document.querySelector('.dualsub-card-source')||{}).textContent"))
        ok = len(items) >= 4
        print("errori:", errs if ok else errs + ["tendina povera"], log["errors"])
        await ctx.close()
asyncio.run(main())

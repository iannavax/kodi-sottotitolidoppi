# Prove della 1.10.6: frasi brevi (una o due parole) ricopiate uguali dal servizio di traduzione
import sys, os, json, time, shutil, re, urllib.parse
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
from resources.lib import core
G = {"ja.": "Sì.", "nej!": "No!", "karen.": "Karen.", "okay.": "Okay.", "hvad?": "Cosa?", "tak.": "Grazie."}
calls = {"gem": [], "google": []}
PROMPTS = []
def fake_http(url, data=None, headers=None, timeout=90):
    if "generativelanguage" in url:
        msgs = json.loads(data)["messages"]
        PROMPTS.append(msgs[0]["content"])
        segs = json.loads(msgs[1]["content"])["segments"]
        calls["gem"].append(list(segs))
        # come Gemini a volte: le frasi brevi le ricopia uguali
        out = [s if len(s.split()) <= 2 else "GEM[" + " ".join(w[::-1] for w in s.split()) + "]" for s in segs]
        return 200, json.dumps({"choices": [{"message": {"content": json.dumps({"t": out})}}]}).encode(), {}
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        calls["google"].append(q)
        res = "\n".join(G.get(l.lower(), "G[" + l + "]") for l in q.split("\n"))
        return 200, json.dumps([[[res, q]], None, "da"]).encode(), {}
    if "opensubtitles" in url or "cinemeta" in url:
        return 200, b'{"subtitles": [], "metas": []}', {}
    return 404, b"", {}
core.http = fake_http
core.ENGINES["gemini"]["gap"] = 0
from resources.lib import runner
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata", "/tmp/kodi-film10"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles"); os.makedirs("/tmp/kodi-film10")
LINES = ["Ja.", "Hvor skal vi hen i aften med bilen", "Nej!", "Karen.", "Okay.", "Det er en meget lang dag for os alle", "Hvad?", "Tak."]
def srt(lines):
    f = lambda ms: "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)
    return "\n".join("%d\n%s --> %s\n%s\n" % (i + 1, f(i * 4000), f(i * 4000 + 3000), l) for i, l in enumerate(lines))
open("/tmp/kodi-film10/Film.da.srt", "w").write(srt(LINES))
open("/tmp/kodi-film10/Film.mkv", "w").write("x")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "gemini (gratis con chiave, consigliato)", "gemini_key": "AIza",
                           "layout": "Originale sopra", "trans_color": "FFFF00", "auto": "true",
                           "source_mode": "file (solo sottotitoli, mai trascrizione)", "trans_mode": "nuova (con il servizio scelto qui sotto, salvata)"})
VIDEO = "/tmp/kodi-film10/Film.mkv"
def play():
    xbmc.Player.playing = True; xbmc.Player.playing_file = VIDEO
    xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": VIDEO, "at": time.time() - 20})
    xbmc.Player.subs.clear(); calls["gem"].clear(); calls["google"].clear()
def result():
    blocks = [b.split("\n") for b in open(xbmc.Player.subs[-1], encoding="utf-8").read().strip().split("\n\n")]
    return {b[2]: re.sub(r"<[^>]+>", "", b[3]) if len(b) > 3 else "" for b in blocks}
# 1. prima volta: le brevi ricopiate da Gemini vengono tradotte con Google; i nomi restano uguali
play(); runner.run(xbmc.Player(), interactive=True)
r = result()
print("1.", r)
ok1 = r["Ja."] == "Sì." and r["Nej!"] == "No!" and r["Hvad?"] == "Cosa?" and r["Tak."] == "Grazie." and r["Karen."] == "Karen." \
    and r["Okay."] == "Okay." and r["Hvor skal vi hen i aften med bilen"].startswith("GEM[")
print("   istruzione nel prompt:", "Short lines of one or two words" in PROMPTS[-1])
ok1 = ok1 and "Short lines of one or two words" in PROMPTS[-1]
# 2. rivisto: nessuna richiesta, neanche per i nomi già controllati
play(); runner.run(xbmc.Player(), interactive=True)
print("2. rivisto: Gemini", len(calls["gem"]), "Google", len(calls["google"]), "|", result()["Ja."])
ok2 = not calls["gem"] and not calls["google"] and result()["Ja."] == "Sì."
# 3. memoria di una versione precedente con le brevi ricopiate: si rifanno solo quelle
mp = runner.memory_path(VIDEO, "it")
mem = json.load(open(mp, encoding="utf-8"))
tag = runner.engine_tag(runner.settings())
for k in ("ja.", "nej!", "tak."):
    mem[k] = {tag: {"ja.": "Ja.", "nej!": "Nej!", "tak.": "Tak."}[k]}
json.dump(mem, open(mp, "w", encoding="utf-8"))
for f in os.listdir(runner.CACHE):
    if f.endswith(".json") and not f.startswith("memoria"): os.remove(os.path.join(runner.CACHE, f))
play(); runner.run(xbmc.Player(), interactive=True)
r = result()
print("3. vecchia memoria: Gemini ha ricevuto", calls["gem"], "|", r["Ja."], r["Nej!"], r["Tak."], r["Karen."])
ok3 = calls["gem"] == [["Ja.", "Nej!", "Tak."]] and r["Ja."] == "Sì." and r["Nej!"] == "No!" and r["Tak."] == "Grazie." and r["Karen."] == "Karen."
# 4. is_copy
print("4.", core.is_copy("Ja.", "ja"), core.is_copy("Ja.", "Sì."), core.is_copy("42", "42"))
ok4 = core.is_copy("Ja.", "ja") and not core.is_copy("Ja.", "Sì.") and not core.is_copy("42", "42")
print("ESITO:", bool(ok1 and ok2 and ok3 and ok4))

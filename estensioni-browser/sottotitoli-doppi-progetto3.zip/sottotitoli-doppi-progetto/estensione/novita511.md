## Novità della 5.11.6
- **Tabelle di Wiktionary leggibili**: nelle tabelle di declinazione e coniugazione (per esempio *источник*) la traslitterazione in alfabeto latino non è più attaccata alla parola: sta sotto, più piccola e separata.

## Novità della 5.11.5
- **Pronuncia IPA da tutte le edizioni di Wiktionary**: se il Wiktionary inglese non ha la pronuncia della parola (succede spesso con le forme flesse), si cerca nel Wiktionary della lingua della parola (russo, ceco, tedesco, francese, polacco… qualsiasi lingua che ne abbia uno), poi in quello della tua lingua e nei più grandi (francese, tedesco, russo). Gemini o Groq solo se non c'è da nessuna parte. Passando il mouse sulla pronuncia leggi da quale edizione viene.
- **Giapponese: dizionario Jisho** (gratis): nella scheda lettura in kana, livello JLPT, "parola comune" e significato in inglese. Si spegne nel popup → Strumenti per imparare → "Dizionario Jisho".

## Novità della 5.11.4
- **Pronuncia IPA da Wiktionary, gratis**: la pronuncia della parola si prende prima da Wiktionary (la stessa pagina già usata per etimologia, genere, tabelle e registrazione: nessuna richiesta in più). Gemini o Groq si usano solo se lì manca, e anche cliccando la parola la spiegazione non la richiede più se c'è già. Funziona anche senza chiavi.

## Novità della 5.11.3
- **Ascolto della parola**: in alto nella scheda c'è sempre 🔈 (voce sintetica) e, quando Wiktionary ha la registrazione di una persona, accanto 🔊. Tolto il pulsante "🔊 madrelingua". Icone uguali ovunque: 🔊 = registrazione vera, 🔈 = voce sintetica.
- **Corretto "Spiega con Groq"** (cliccando la parola): non arrivava niente ("Groq non ha risposto") perché la richiesta chiedeva una risposta troppo lunga e superava il limite al minuto di Groq. Ora è più corta e, se serve, si riprova da sola; in caso di errore la scheda dice il motivo.

## Novità della 5.11.2
- **Esempi di Tatoeba con la voce vera, davvero**: ora si usa l'API ufficiale di Tatoeba (v1), che dà le registrazioni dei madrelingua; prima si chiedono le frasi registrate (🔊), poi le altre. Se una registrazione non si può scaricare si prova l'altro indirizzo di Tatoeba. Quando per una parola non esistono frasi registrate, la scheda lo dice ("🔈 = voce sintetica").

## Novità della 5.11.1
- **Esempi di Tatoeba con la voce vera**: si chiedono prima le frasi registrate da un madrelingua (🔊), e solo se non bastano le altre (🔈 = voce sintetica). Vanno bene anche le forme flesse della parola (*кошка* → *кошку*).

## Novità della 5.11
- **Strumenti per imparare nella scheda della parola**, tutti gratis e senza chiavi, ognuno si accende e spegne nel popup → **Strumenti per imparare**:
  - **frequenza** della parola (molto comune, comune, rara…), dagli elenchi FrequencyWords;
  - **«la conosco?»**: le parole che conosci si colorano di verde nei sottotitoli e il popup dice **quanta parte del video conosci** (in percentuale). Anche "Segna come imparata" nel vocabolario la aggiunge;
  - **frasi d'esempio vere** da Tatoeba, con la traduzione e spesso con la **registrazione di un madrelingua** (🔊; 🔈 = voce sintetica);
  - **pronuncia di madrelingua** della parola (Wiktionary), **tabella di coniugazione o declinazione** (▦), **genere** dei nomi (in tedesco con der/die/das);
  - **controllo della scrittura**: se la parola è scritta bene (LanguageTool e dizionario); cliccando la parola anche un **voto da 0 a 100** del modello, con la forma corretta.
- **Una sola richiesta al modello, sempre**: cliccando la parola, la spiegazione porta nella stessa richiesta anche etimologia (se manca), IPA (se accesa), **falsi amici**, **parole parenti** e voto alla scrittura.
- **Riascolta più lenta o più volte**: nella scheda, accanto a "↺ Riascolta la frase", **🐢 lenta** (a 0,75) e **🔁 ×3**.
- **Immagine nelle carte di Anki** (spenta di serie): quando salvi una parola cerca un'immagine su Wikimedia Commons e la mette sul fronte della carta.
- Corretto: le parole russe con l'accento tonico (*Дорефо́рменная*) o con trattini invisibili ora aprono la scheda della parola.

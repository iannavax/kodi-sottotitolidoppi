# 1.6.2: carte di Anki con la pronuncia: registrazione di un madrelingua (Wiktionary) se c'è, altrimenti voce sintetica
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false, ankiAuto:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ankiTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        W = lambda t: words.nth(texts.index(t))
        res = []
        for w in ["bread", "market"]:
            await W(w).click(); await pg.wait_for_timeout(2500)
            await pg.locator(".dualsub-card .dualsub-star").click()
            for _ in range(30):
                if "Anki" in (await pg.evaluate("(document.querySelector('.dualsub-anki-note')||{}).textContent||''")): break
                await pg.wait_for_timeout(300)
            note = [x[1]["note"] for x in log.get("anki", []) if x[0] == "addNote"][-1]
            au = note.get("audio") or [{}]
            print(w, "→", au[0].get("filename"), "| campo:", au[0].get("fields"), "| dati:", len(au[0].get("data") or ""), "|", await pg.evaluate("(document.querySelector('.dualsub-anki-note')||{}).textContent"))
            res.append(au[0].get("filename") or "")
            await pg.keyboard.press("Escape"); await pg.wait_for_timeout(300)
        ok1 = "-rec-" in res[0] and "-tts-" in res[1]
        # spento: niente audio
        await sw.evaluate("chrome.storage.sync.set({ankiAudio:false})"); await pg.wait_for_timeout(300)
        await W("fresh").click() if "fresh" in texts else await W(texts[0]).click()
        await pg.wait_for_timeout(1500); await pg.locator(".dualsub-card .dualsub-star").click(); await pg.wait_for_timeout(2000)
        note = [x[1]["note"] for x in log.get("anki", []) if x[0] == "addNote"][-1]
        ok2 = "audio" not in note
        print("spento:", ok2, note["fields"]["Fronte"][:30])
        # vocabolario: manda tutto
        await sw.evaluate("chrome.storage.sync.set({ankiAudio:true})")
        log["anki_fronts"] = set()
        await sw.evaluate("chrome.storage.local.get('vocab').then(r=>{for(const e of Object.values(r.vocab)) delete e.anki; return chrome.storage.local.set({vocab:r.vocab})})")
        vp = await ctx.new_page(); vp.on("pageerror", lambda e: errs.append("vocab: " + str(e)))
        await vp.goto(f"chrome-extension://{eid}/vocab.html"); await vp.wait_for_timeout(800)
        await vp.select_option("#filter", "all"); await vp.wait_for_timeout(300)
        n0 = len([x for x in log["anki"] if x[0] == "addNote"])
        await vp.click("#send"); await vp.wait_for_timeout(6000)
        notes = [x[1]["note"] for x in log["anki"] if x[0] == "addNote"][n0:]
        print("vocabolario:", [(n["fields"]["Fronte"][:12], (n.get("audio") or [{}])[0].get("filename", "")[:22]) for n in notes], "|", await vp.inner_text("#ankiMsg"))
        ok3 = all(n.get("audio") for n in notes) and len(notes) >= 3
        print("OK" if ok1 and ok2 and ok3 else "NO", ok1, ok2, ok3)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

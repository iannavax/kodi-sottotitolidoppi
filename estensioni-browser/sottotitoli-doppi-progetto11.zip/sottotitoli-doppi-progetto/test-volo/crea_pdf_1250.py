# PDF ceco scritto in codifica Windows-1250 ma con il carattere dichiarato WinAnsi (Europa occidentale):
# i lettori mostrano "Pøíliš žlu ouèký kùò" al posto di "Příliš žluťoučký kůň" (difetto frequente nei PDF cechi vecchi)
def pdf(path, lines):
    body = b""
    for i, l in enumerate(lines):
        raw = l.encode("cp1250").replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)")
        body += (b"" if i == 0 else b" 0 -28 Td ") + b"(" + raw + b") Tj"
    stream = b"BT /F1 18 Tf 60 720 Td " + body + b" ET"
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
            b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"]
    out = b"%PDF-1.4\n"; offs = []
    for i, o in enumerate(objs, 1):
        offs.append(len(out)); out += str(i).encode() + b" 0 obj\n" + o + b"\nendobj\n"
    x = len(out)
    out += b"xref\n0 " + str(len(objs) + 1).encode() + b"\n0000000000 65535 f \n" + b"".join(b"%010d 00000 n \n" % o for o in offs)
    out += b"trailer\n<< /Size " + str(len(objs) + 1).encode() + b" /Root 1 0 R >>\nstartxref\n" + str(x).encode() + b"\n%%EOF\n"
    open(path, "wb").write(out)
pdf("/tmp/doc_1250.pdf", ["Blues pro bláznivou holku - Václav Hrabě", "Příliš žluťoučký kůň úpěl ďábelské ódy.", "Řekl jsem jí, že ji mám rád, a ona se smála.", "Večer jsme šli po nábřeží a dívali se na řeku."])
print("creato /tmp/doc_1250.pdf")

# 1.6.0: sulle pagine, il modo di dire dal dizionario di Wiktionary nella scheda (walk home → «walked home», gratis)
# e il pulsante «🔎 Modi di dire con questa parola» (una richiesta solo quando lo premi)
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
CARD = "(document.querySelector('.pav-card')||{}).innerText||''"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "walked", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        c1 = await pg.evaluate(CARD)
        print("1. walked:", [l for l in c1.split("\n") if "Modo di dire" in l], "| dizionario:", tvolo.log.get("idiomdict"), "| idiomsFind:", tvolo.log.get("idiomsFind"))
        await pg.mouse.click(5, 5); await pg.wait_for_timeout(500)
        b = await tvolo.hover(pg, "en", "market", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        btn = pg.locator(".pav-card button", has_text="Modi di dire con questa parola")
        n = await btn.count()
        if n: await btn.first.click(); await pg.wait_for_timeout(2500)
        c2 = await pg.evaluate(CARD + " + ' ' + ((document.querySelector('.pav-note')||{}).innerText||'')")
        print("2. market: pulsante", n, "| richieste:", tvolo.log.get("idiomsFind"), "|", [l for l in c2.split("\n") if "modo di dire" in l.lower() or "Nessun" in l][:3])
        ok = any("walked home" in l for l in c1.split("\n") if "Modo di dire" in l) and not tvolo.log.get("idiomsFind", [None])[:0] and n == 1 and len(tvolo.log.get("idiomsFind", [])) == 1
        print("errori:", errs if ok else errs + ["modi di dire sulle pagine non vanno"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

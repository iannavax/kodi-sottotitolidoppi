# 1.10: ⚑ sui modi di dire in Parole al Volo (non è un modo di dire / correggi), e scarto di quelli non plausibili
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
IDI = "(document.querySelector('.pav-card .pav-idiom')||{}).innerText||'(nessuno)'"
async def run(p, expr):
    os.environ["IDIOM"] = expr
    ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
    await ctx.route("**/*", tvolo.handle)
    sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
    try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
    except Exception: pass
    await sw.evaluate("chrome.storage.sync.set({targetLang:'it', engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
    pg = await ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
    async def explain():
        await tvolo.hover(pg, "en", "bread", 2500)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.get_by_role("button", name="Spiega con Groq").click(); await pg.wait_for_timeout(3000)
    await explain()
    return ctx, sw, pg, errs, explain
async def main():
    async with async_playwright() as p:
        ctx, sw, pg, errs, explain = await run(p, "We went to the market and bought some fresh bread")
        print("1. 'modo di dire' quasi tutta la frase:", await pg.evaluate(IDI)); await ctx.close()
        ctx, sw, pg, errs, explain = await run(p, "fresh bread")
        print("2. fresh bread:", (await pg.evaluate(IDI)).replace("\n", " | "))
        await pg.locator(".pav-card button", has_text="⚑ modo di dire sbagliato?").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card button", has_text="✎ Correggi il significato").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card .pav-idiom textarea").fill("pane fresco (mio)")
        await pg.locator(".pav-card .pav-idiom button", has_text="Salva").click(); await pg.wait_for_timeout(500)
        print("3. corretto:", (await pg.evaluate(IDI)).replace("\n", " | "))
        await pg.locator(".pav-card button", has_text="⚑ modo di dire sbagliato?").click(); await pg.wait_for_timeout(300)
        await pg.locator(".pav-card button", has_text="Non è un modo di dire").click(); await pg.wait_for_timeout(500)
        print("4. tolto:", await pg.evaluate(IDI), "| salvato:", await sw.evaluate("chrome.storage.local.get('idiomFlags').then(r=>Object.keys(r.idiomFlags))"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
CLEAN = os.environ.get("CLEAN", "1") == "1"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate(f"""chrome.storage.sync.set({{engine:'google', targetLang:'it', transcribeMode:'live', cleanTranscript:{'true' if CLEAN else 'false'}}})
          .then(()=>chrome.storage.local.set({{keys:{{gemini:'AIza-test', groq:'gsk_test'}}}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsClean2"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(34000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(30000)
        dbg = json.loads(await pg.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))
        for c in dbg: print(f"  {c['start']/1000:5.1f}s {'(TOLTA) ' if c['removed'] else ''}{'[corretta] ' if c['cleaned'] else ''}{c['text'][:44]:44} | {(c['trans'] or '')[:40]}")
        print("richieste a Gemini (solo correzione):", log["gemini"], "| Google:", log["google"])
        st = await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)")
        print("stato:", st)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# Prove della 1.12: SubDL (add-on principale e servizio «SubDL» del menu dei sottotitoli), trascrizione a pezzi in
# parallelo con la barra che avanza, trascrizione da sola subito, nome del servizio che traduce davvero.
import sys, os, json, time, shutil, re, io, zipfile, urllib.parse, threading
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
from resources.lib import core
calls = []
def zipped(name, text):
    b = io.BytesIO(); z = zipfile.ZipFile(b, "w"); z.writestr("leggimi.txt", "x"); z.writestr(name, text); z.close(); return b.getvalue()
SRT_EN = "1\n00:00:01,000 --> 00:00:03,000\nwhere are you going\n\n2\n00:00:05,000 --> 00:00:07,000\nI am going home\n"
SRT_E2 = "1\n00:00:01,000 --> 00:00:03,000\nepisode two line\n"
DA = ["hvor skal du hen", "jeg skal hjem", "det er langt", "vi ses i morgen"]
WLOCK = threading.Lock(); ACTIVE = [0, 0]
def fake_http(url, data=None, headers=None, timeout=90):
    calls.append(url.split("?")[0] + ("?" + url.split("?")[1] if "subdl" in url and "?" in url else ""))
    if url.startswith("https://api.subdl.com/api/v1/subtitles"):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        if q.get("api_key", [""])[0] != "sd-key":
            return 403, json.dumps({"status": False, "error": "API key is invalid"}).encode(), {}
        subs = [{"release_name": "Treno.2020.1080p.WEB", "lang": "english", "language": "EN", "url": "/subtitle/111-222.zip", "hi": False},
                {"release_name": "Treno.2020.HI", "lang": "english", "language": "EN", "url": "/subtitle/333-444.zip", "hi": True},
                {"release_name": "Treno.2020.ITA", "lang": "italian", "language": "IT", "url": "/subtitle/555-666.zip", "hi": False},
                {"release_name": "Serie.S01E02", "lang": "english", "language": "EN", "url": "/subtitle/777-888.zip", "season": 1, "episode": 2}]
        langs = q.get("languages", [""])[0].split(",")
        return 200, json.dumps({"status": True, "results": [{"imdb_id": "tt0001"}], "subtitles": [x for x in subs if x["language"] in langs]}).encode(), {}
    if url.startswith("https://dl.subdl.com/subtitle/"):
        if "777-888" in url:
            b = io.BytesIO(); z = zipfile.ZipFile(b, "w"); z.writestr("Serie.S01E01.srt", "1\n00:00:01,000 --> 00:00:02,000\nuno\n"); z.writestr("Serie.S01E02.srt", SRT_E2); z.close()
            return 200, b.getvalue(), {}
        return 200, zipped("Treno.2020.srt", SRT_EN), {}
    if "translate.googleapis.com" in url:
        qq = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + l + "]" for l in qq.split("\n")), qq]], None, "en"]).encode(), {}
    if "audio/transcriptions" in url:
        piece = int(re.search(rb'filename="pezzo(\d+)', data).group(1))
        with WLOCK:
            ACTIVE[0] += 1; ACTIVE[1] = max(ACTIVE[1], ACTIVE[0])
        time.sleep(0.4)
        with WLOCK:
            ACTIVE[0] -= 1
        calls.append("whisper:%d" % piece)
        segs = [{"start": k * 8 + 0.5, "end": k * 8 + 6, "text": " " + DA[(piece + k) % 4] + ".", "no_speech_prob": 0.02, "avg_logprob": -0.3} for k in range(3)]
        return 200, json.dumps({"language": "danish", "segments": segs}).encode(), {}
    if "opensubtitles-v3" in url or "cinemeta" in url:
        return 200, json.dumps({"subtitles": [], "metas": []}).encode(), {}
    return 404, b"", {}
core.http = fake_http
core.find_ffmpeg = lambda c="": "/usr/bin/ffmpeg"
core.audio_streams = lambda ffmpeg, media: []
core.speech_spans = lambda ffmpeg, path: []
EXTRACTED = []
def fake_piece(ffmpeg, media, workdir, n, piece_sec=600, stream=0):
    EXTRACTED.append(n)
    p = os.path.join(workdir, "pezzo%03d.ogg" % n); open(p, "wb").write(b"OggS" + bytes(3000)); return p
core.extract_piece = fake_piece
def no_whole(*a, **k): raise Exception("non deve estrarre tutto l'audio in una volta")
core.extract_audio_pieces = no_whole
from resources.lib import runner, subtitles
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "gemini (gratis con chiave, consigliato)", "layout": "Originale sopra",
                           "trans_color": "FFFF00", "auto": "true", "groq_key": "gsk_test", "stt": "groq (gratis con chiave)",
                           "stt_lang": "auto", "subdl_key": "sd-key", "stt_workers": "3"})
def play(url, total=0.0):
    xbmc.Player.playing_file = url; xbmc.Player.total = total; xbmc.Player.playing = True
    xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": url, "at": time.time() - 20})
    xbmc.Player.subs.clear(); xbmcgui.NOTES.clear(); calls.clear(); xbmc.LOG.clear(); xbmcplugin.ITEMS.clear(); xbmcgui.BARS.clear()

# 1. SubDL direttamente
r = core.subdl_search("sd-key", ["en", "it"], "tt0001")
print("1. SubDL:", [(x["lang"], x["release"], x["hi"]) for x in r])
body, ext = core.subdl_download(r[0]["url"])
print("   scaricato:", ext, body.decode()[:30].replace("\n", " "))
body, ext = core.subdl_download("https://dl.subdl.com/subtitle/777-888.zip", 1, 2)
print("   serie, puntata 2:", body.decode().split("\n")[2])
try:
    core.subdl_search("sbagliata", ["en"], "tt0001")
except Exception as e:
    print("   chiave sbagliata:", e)

# 2. Sottotitoli Doppi: elenco del menu del lettore con SubDL (OpenSubtitles senza risultati)
play("https://x.download.real-debrid.com/d/AA/Treno.2020.mkv")
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.IMDBNumber": "tt0001"})
runner.original_lang = lambda v: "en"
subtitles.search(1, xbmc.Player())
print("2. menu del lettore:", [li.label2 for _, li in xbmcplugin.ITEMS])
o = next(json.loads(__import__("base64").urlsafe_b64decode(u.split("o=")[1].encode()).decode()) for u, li in xbmcplugin.ITEMS if "SubDL" in li.label2)
xbmcplugin.ITEMS.clear()
subtitles.download(1, xbmc.Player(), o)
print("   scelto SubDL:", [open(u, encoding="utf-8").read().split("\n")[2:4] for u, _ in xbmcplugin.ITEMS], "| avvisi:", xbmcgui.NOTES[-1:])

# 3. servizio «SubDL» (finestra Scarica sottotitoli del lettore)
sys.argv = ["plugin://service.subtitles.subdl/", "1", "?action=search&languages=English,Italian&preferredlanguage=Italian"]
xbmcplugin.ITEMS.clear()
import importlib.util
spec = importlib.util.spec_from_file_location("subdl_service", "/home/claude/kodi/service.subtitles.subdl/service.py")
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
print("3. servizio SubDL:", [(li.label, li.label2, li.props.get("hearing_imp")) for _, li in xbmcplugin.ITEMS])
u = xbmcplugin.ITEMS[0][0]; xbmcplugin.ITEMS.clear()
mod.main(["plugin://service.subtitles.subdl/", "1", "?" + u.split("?", 1)[1]])
print("   scaricato:", [(os.path.basename(p), open(p, encoding="utf-8").read().split("\n")[2]) for p, _ in xbmcplugin.ITEMS])
xbmcaddon.SETTINGS["subdl_key"] = ""; xbmcgui.NOTES.clear(); xbmcplugin.ITEMS.clear()
mod.main(["plugin://service.subtitles.subdl/", "1", "?action=search&languages=English"])
print("   senza chiave:", xbmcgui.NOTES[-1:])
xbmcaddon.SETTINGS["subdl_key"] = "sd-key"

# 4. trascrizione: pezzi estratti uno alla volta, 3 insieme a Whisper, barra che va avanti; poi l'originale da solo subito
play("https://x.download.real-debrid.com/d/BB/Festen.1998.Danish.mkv", total=3000.0)
xbmc.INFO.clear(); EXTRACTED.clear(); runner.original_lang = lambda v: ""
t0 = time.time()
runner.run(xbmc.Player(), source_mode="trascrizione", interactive=True)
print("4. pezzi estratti:", sorted(EXTRACTED), "| Whisper insieme al massimo:", ACTIVE[1], "| tempo %.1f s" % (time.time() - t0))
print("   barra:", [" ".join(b[1:]) for b in xbmcgui.BARS if b[0] == "update" and ("Trascrivo" in " ".join(b) or "audio" in " ".join(b))][:8])
print("   sottotitoli mostrati:", [os.path.basename(p).split(".", 1)[1] for p in xbmc.Player.subs], "| avvisi:", [n for n in xbmcgui.NOTES if "Trascrizione" in n])
print("   prima riga del primo:", open(xbmc.Player.subs[0], encoding="utf-8").read().split("\n")[2:4])
# 5. menu del lettore: «solo la trascrizione»
xbmcplugin.ITEMS.clear()
subtitles.search(1, xbmc.Player())
print("5. menu:", [li.label2 for _, li in xbmcplugin.ITEMS][:3])
o = next(json.loads(__import__("base64").urlsafe_b64decode(u.split("o=")[1].encode()).decode()) for u, li in xbmcplugin.ITEMS if "Originale:" in li.label2)
xbmcplugin.ITEMS.clear(); subtitles.download(1, xbmc.Player(), o)
print("   solo originale:", [open(u, encoding="utf-8").read().split("\n")[2:4] for u, _ in xbmcplugin.ITEMS])
# 6. nome del servizio: Gemini scelto ma senza chiave → Groq (che ha la chiave)
print("6. servizio che traduce:", runner.engine_name(runner.settings()))

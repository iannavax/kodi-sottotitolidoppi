# 1.6.1: la spiegazione usa Gemini Flash; Flash ha finito le richieste di oggi → la scheda rifà subito con Flash-Lite
import asyncio, os, sys
os.environ["GEM_DAILY_MODEL"] = "gemini-flash-latest"
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false, learnExamples:false, learnSpell:false, learnFreq:false, learnLlmExtra:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(1500)
        n0 = len(log.get("gmodels", []))
        await spiega(pg, 4000)
        for _ in range(30):
            if "gemini-flash-lite-latest" in log.get("gmodels", [])[n0:]: break
            await pg.wait_for_timeout(500)
        await pg.wait_for_timeout(2500)
        mean = await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-card-meaning')||{}).textContent")
        src = await pg.evaluate("(document.querySelector('.dualsub-card')||{}).innerText.match(/Fonte:[^\\n]*/)?.[0]||''")
        used = log.get("gmodels", [])[n0:]
        print("spiegazione:", mean, "|", src, "| modelli:", used)
        ok = mean and "gemini-flash-latest" in used and used[-1] == "gemini-flash-lite-latest"
        print("errori:", errs if ok else errs + ["spiegazione con l'altro modello non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

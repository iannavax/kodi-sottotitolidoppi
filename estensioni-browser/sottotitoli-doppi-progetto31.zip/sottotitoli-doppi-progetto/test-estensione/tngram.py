# 1.4.3: «📈 uso nel tempo» leggibile: anni sotto nel punto giusto, scala, riassunto, valore dell'anno col mouse
import asyncio, sys, os
sys.path.insert(0, "/home/claude/e2e")
from charness import *
SHOT = sys.argv[2] if len(sys.argv) > 2 else "/tmp/tngram.png"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, learnExamples:false, learnFreq:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        if os.environ.get("HOSTILE"): await pg.add_style_tag(content="svg path, svg polyline, svg circle, svg line { fill: black; stroke: none; stroke-width: 0; } svg text { fill: #000; font-size: 4px; } svg { width: 0; }")
        await pg.wait_for_selector(".dualsub-card .dsx-gwngram", timeout=15000)   # 1.6.3: compare da solo; un'altra apertura non rifà la richiesta
        print("0. richieste a Google Books:", log.get("ngram")); await pg.wait_for_timeout(500)
        g = pg.locator(".dualsub-card .dsx-gwngram")
        print("1. riquadro:", (await g.inner_text()).replace("\n", " | "))
        print("   anni sull'asse:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-spark text')].map(t=>t.textContent+'@'+Math.round(+t.getAttribute('x')))"))
        await pg.locator(".dualsub-card .dsx-spark").scroll_into_view_if_needed(); await pg.wait_for_timeout(300)
        box = await pg.locator(".dualsub-card .dsx-spark").bounding_box()
        await pg.mouse.move(box["x"] + box["width"] * 0.5, box["y"] + box["height"] * 0.4); await pg.wait_for_timeout(300)
        print("2. mouse a metà:", await pg.evaluate("document.querySelector('.dualsub-card .dsx-sparkread').textContent"))
        print("3. fonte:", await pg.evaluate("(document.querySelector('.dualsub-card .dsx-sparksrc')||{}).innerText"), "|", await pg.evaluate("(document.querySelector('.dualsub-card .dsx-sparklink')||{}).href"))
        print("   anni (dimensione, colore):", await pg.evaluate("(() => { const t = document.querySelector('.dualsub-card .dsx-spark text'); return t ? [t.getAttribute('font-size'), t.getAttribute('fill')] : null; })()"))
        await g.screenshot(path=SHOT)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

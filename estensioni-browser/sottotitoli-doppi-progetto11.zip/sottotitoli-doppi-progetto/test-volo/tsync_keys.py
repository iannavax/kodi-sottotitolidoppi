# ⇄ porta anche chiavi e impostazioni: l'estensione unica appena installata riceve Gemini, modelli, immagini Anki
import asyncio, os, sys, json
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import charness
SD, PAV, UNI = sys.argv[1], sys.argv[2], sys.argv[3]
ST = "Promise.all([chrome.storage.local.get('keys'), chrome.storage.sync.get(null)]).then(([l,s])=>JSON.stringify({keys:l.keys||{}, engine:s.engine, pavEngine:s.pavEngine, ankiImage:s.ankiImage, models:s.models, fontSize:s.fontSize, hover:s.hover}))"
async def main():
    errs = []
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True,
            args=[f"--disable-extensions-except={SD},{PAV},{UNI}", f"--load-extension={SD},{PAV},{UNI}"])
        await ctx.route("**/*", charness.handle)
        await asyncio.sleep(2)
        ids = {}
        for sw in ctx.service_workers: ids[await sw.evaluate("chrome.runtime.getManifest().name")] = (sw, sw.url.split("/")[2])
        (sd, sdid), (pav, pavid), (uni, uniid) = ids["Sottotitoli Doppi"], ids["Parole al Volo"], ids["Sottotitoli Doppi + Parole al Volo"]
        await sd.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-SD', groq:'gsk-SD'}}).then(()=>chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, ankiImage:true, fontSize:30}))")
        await pav.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-PAV', mistral:'mis-PAV'}}).then(()=>chrome.storage.sync.set({engine:'gemini', hover:false, ankiImage:true}))")
        await uni.evaluate("chrome.storage.local.set({keys:{deepl:'dl-UNI'}})")
        up = await ctx.new_page(); up.on("pageerror", lambda e: errs.append(str(e)))
        await up.goto(f"chrome-extension://{uniid}/freq.html?lang=en"); await up.wait_for_timeout(1200)
        sibs = f"[{{name:'Sottotitoli Doppi', id:'{sdid}'}}, {{name:'Parole al Volo', id:'{pavid}'}}]"
        # 1) le altre non possono verificare chi chiede (nel banco non hanno il permesso): impostazioni sì, chiavi no
        await up.evaluate(f"dsSiblingIds = async () => {sibs}")
        await up.click("#sync"); await up.wait_for_timeout(2000)
        print("1.", await up.inner_text("#impMsg"))
        print("   unica:", await uni.evaluate(ST))
        print("   SD riceve:", json.loads(await sd.evaluate(ST))["keys"])
        # 2) con il permesso (lo simulo): arrivano anche le chiavi
        for sw in (sd, pav): await sw.evaluate("dsTrusted = async () => true")
        await up.click("#sync"); await up.wait_for_timeout(2000)
        print("2.", await up.inner_text("#impMsg"))
        print("   unica:", await uni.evaluate(ST))
        print("   SD:", await sd.evaluate(ST))
        print("   PAV:", await pav.evaluate(ST))
        print("errori:", errs, charness.log.get("errors"))
        await ctx.close()
asyncio.run(main())

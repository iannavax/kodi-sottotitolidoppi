# Prove della 1.10.9: OpenSubtitles.com solo se permesso; conta la lingua ORIGINALE del film (non il doppiaggio né la traccia accesa nel lettore);
# niente trascrizione di un doppiaggio senza chiedere; una scelta fatta a mano ferma il lavoro automatico
import sys, os, json, time, shutil, re, urllib.parse, threading, http.server, socketserver
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
FILM = "/tmp/mkvde/film.mkv"
if not os.path.isfile(FILM):
    # film con audio russo (prima traccia) e tedesco, sottotitoli russi (accesi), inglesi e tedeschi
    os.makedirs("/tmp/mkvde", exist_ok=True)
    src = open("/tmp/mkvt/s.srt").read()
    for code, word in (("ru", "Русская строка"), ("en", "English line"), ("de", "Deutsche Zeile")):
        open("/tmp/mkvde/%s.srt" % code, "w").write(re.sub(r"Riga numero (\d+) del film", lambda m: "%s %s" % (word, m.group(1)), src))
    os.system("cd /tmp/mkvde && ffmpeg -y -loglevel error -i /tmp/mkvt/film.mkv -i ru.srt -i en.srt -i de.srt -map 0:v -map 0:a -map 0:a "
              "-map 1 -map 2 -map 3 -c copy -metadata:s:a:0 language=rus -metadata:s:a:1 language=ger -metadata:s:s:0 language=rus "
              "-metadata:s:s:1 language=eng -metadata:s:s:2 language=ger film.mkv")
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def handle(self):
        try: super().handle()
        except Exception: pass
    def do_GET(self):
        size = os.path.getsize(FILM)
        m = re.match(r"bytes=(\d+)-(\d*)", self.headers.get("Range", ""))
        a = int(m.group(1)) if m else 0; b = min(int(m.group(2)) if m and m.group(2) else size - 1, size - 1)
        self.send_response(206 if m else 200); self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(b - a + 1)); self.send_header("Content-Range", "bytes %d-%d/%d" % (a, b, size)); self.end_headers()
        with open(FILM, "rb") as f:
            f.seek(a); self.wfile.write(f.read(b - a + 1))
srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), H); srv.daemon_threads = True
threading.Thread(target=srv.serve_forever, daemon=True).start()
URL = "http://127.0.0.1:%d/d/XYZ/Good%%20Bye%%20Lenin.mkv" % srv.server_address[1]
from resources.lib import core
def fake_http(url, data=None, headers=None, timeout=90):
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + l + "]" for l in q.split("\n")), q]], None, "de"]).encode(), {}
    if "cinemeta" in url and "/meta/" in url:
        return 200, json.dumps({"meta": {"country": "Germany", "name": "Good Bye Lenin!"}}).encode(), {}
    if "opensubtitles" in url or "cinemeta" in url:
        return 200, b'{"subtitles": [], "metas": []}', {}
    if "audio/transcriptions" in url:
        WH.append(re.search(rb'name="language"\r\n\r\n([^\r]*)', data).group(1).decode() if b'name="language"' in data else "-")
        return 200, json.dumps({"language": "german", "segments": [{"start": 1, "end": 3, "text": " Hallo zusammen.", "no_speech_prob": 0.01, "avg_logprob": -0.2}]}).encode(), {}
    return 404, b"", {}
WH = []
core.http = fake_http
from resources.lib import runner
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra",
                           "trans_color": "FFFF00", "auto": "true", "trans_mode": "nuova (x)", "groq_key": "gsk_x",
                           "stt": "groq (gratis con chiave)", "stt_lang": "auto", "sync_audio": "false"})
# nel lettore: audio russo e sottotitoli russi accesi (le prime tracce del file), film tedesco per il catalogo
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.IMDBNumber": "tt0301357", "VideoPlayer.AudioLanguage": "rus"})
def play():
    xbmc.Player.playing = True; xbmc.Player.playing_file = URL; xbmc.Player.sub_lang = "rus"
    xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": URL, "at": time.time() - 20})
    xbmc.Player.subs.clear(); xbmcgui.NOTES.clear(); xbmc.LOG.clear(); WH.clear()
def first():
    return open(xbmc.Player.subs[-1], encoding="utf-8").read().split("\n")[2] if xbmc.Player.subs else None
# 1. in automatico: la traccia tedesca, non quella russa accesa nel lettore
play(); runner.run(xbmc.Player(), interactive=False)
print("1. lingua originale:", runner.original_lang(URL), "| prima frase:", first())
ok1 = runner.original_lang(URL) == "de" and (first() or "").startswith("Deutsche Zeile")
# 2. nell'elenco della scelta a mano il tedesco è per primo e segnato
xbmcgui.SELECTS.clear(); xbmcgui.SELECT_ANSWER[0] = -1
runner.choose_original(xbmc.Player(), {})
print("2. elenco:", xbmcgui.SELECTS[-1][:3])
ok2 = "tedesco (lingua del film)" in xbmcgui.SELECTS[-1][0]
# 3. trascrizione: traccia audio tedesca (la seconda), Whisper in tedesco
print("3. tracce audio lette da ffmpeg:", core.audio_streams("/usr/bin/ffmpeg", FILM))
pieces = []
real_extract = core.extract_audio_pieces
def fake_extract(ffmpeg, media, workdir, piece_sec=600, stream=0):
    pieces.append(stream)
    p = os.path.join(workdir, "pezzo000.ogg"); open(p, "wb").write(b"OggS" + bytes(50)); return [p]
core.extract_audio_pieces = fake_extract
core.speech_spans = lambda *a: []
play(); runner.run(xbmc.Player(), interactive=True, source_mode="trascrizione")
print("   traccia trascritta:", pieces, "| lingua chiesta a Whisper:", WH)
ok3 = pieces == [1] and WH and WH[0] == "de"
# 4. file con solo il doppiaggio russo: non trascrive senza chiedere; in automatico avvisa e basta
real_streams = core.audio_streams
core.audio_streams = lambda ffmpeg, media: ["ru"]
for f in os.listdir(runner.CACHE):
    if "trascr" in f or f.endswith(".json"): os.remove(os.path.join(runner.CACHE, f))
for k in list(runner._ORIG): pass
pieces.clear(); play(); runner.run(xbmc.Player(), interactive=False, source_mode="trascrizione")
print("4. solo doppiaggio (automatico): pezzi", pieces, "| avviso:", [n for n in xbmcgui.NOTES if "audio originale" in n][:1])
ok4 = not pieces and any("audio originale" in n for n in xbmcgui.NOTES)
# 5. a mano: chiede; rispondendo sì trascrive il doppiaggio
asked = []
xbmcgui.Dialog.yesno = lambda self, *a: (asked.append(a), True)[1]
pieces.clear(); play(); runner.run(xbmc.Player(), interactive=True, source_mode="trascrizione")
print("5. a mano: domanda fatta:", bool(asked), "| pezzi:", pieces)
ok5 = bool(asked) and pieces == [0]
core.audio_streams = real_streams
# 6. una scelta fatta a mano ferma il lavoro automatico in corso
state = {}
def auto_worker():
    bar = runner.Bar("lavoro automatico", auto=True)
    try:
        for _ in range(200):
            bar.update(10, None, "leggo…"); time.sleep(0.1)
        state["fine"] = "finito"
    except core.Cancelled:
        state["fine"] = "interrotto"
    finally:
        bar.close()
t = threading.Thread(target=auto_worker); t.start(); time.sleep(0.5)
print("   occupato:", runner.busy_info())
xbmcgui.NOTES.clear(); play(); t0 = time.time()
runner.run(xbmc.Player(), interactive=True, source_mode="file")
t.join(5)
print("6. lavoro automatico:", state.get("fine"), "| scelta a mano partita dopo %.1f s" % (time.time() - t0), "| sottotitoli:", first(), "| avvisi:", xbmcgui.NOTES[:1])
ok6 = state.get("fine") == "interrotto" and (first() or "").startswith("Deutsche Zeile")
# 6b. file che parte con il doppiaggio russo e ha solo sottotitoli russi e inglesi: in automatico NON traduce niente
real_tracks = core.mkv_tracks
core.mkv_tracks = lambda url: ([t for t in real_tracks(url)[0] if t["lang"] != "de"], None)
runner._MKV.clear()
shutil.rmtree(runner.CACHE, ignore_errors=True)          # niente trascrizione salvata né tracce già lette
for f in os.listdir(runner.PROFILE):
    if f.startswith("scelte"): os.remove(os.path.join(runner.PROFILE, f))
play(); runner.run(xbmc.Player(), interactive=False)
print("6b. solo ru/en: sottotitoli caricati:", first(), "| avviso:", [n for n in xbmcgui.NOTES if "lingua del film" in n][:1])
ok6 = ok6 and first() is None and any("lingua del film" in n for n in xbmcgui.NOTES)
core.mkv_tracks = real_tracks; runner._MKV.clear()
# 7. OpenSubtitles.com (quota del tuo account): in automatico non si usa, a meno che tu lo permetta
xbmc.RPC.clear()
xbmc.RPC_HANDLER = lambda req: {"result": {"addons": [{"addonid": "service.subtitles.opensubtitles-com", "name": "OpenSubtitles.com"}], "files": []}}
runner.target_options(xbmc.Player(), URL, "it")
off = [r for r in xbmc.RPC if "opensubtitles-com" in r]
xbmcaddon.SETTINGS["use_services"] = "true"
runner.target_options(xbmc.Player(), URL, "it")
on = [r for r in xbmc.RPC if "opensubtitles-com" in r]
print("7. OpenSubtitles.com chiamato: spento %d volte, permesso %d volte" % (len(off), len(on)))
ok7 = not off and on
print("ESITO:", bool(ok1 and ok2 and ok3 and ok4 and ok5 and ok6 and ok7))
srv.shutdown()

# 1.4.2: l'albero dalla catena non mescola i pezzi della parola (на- + -чина́ть) con gli antenati
import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/vocab.html"); await pg.wait_for_timeout(800)
        for w, l in [("начинать", "ru"), ("bread", "en"), ("embarazar", "es")]:
            r = await pg.evaluate("(a) => DS_ETYM.get(a[0], a[1], 'it').then(o => ({chain: (o.chain||[]).map(c => (c.part ? '[pezzo di ' + (c.of||'?') + '] ' : c.kin ? '[parente] ' : '') + c.term), tree: o.wtree}))", [w, l])
            def show(n, d=0):
                out = []
                for x in n or []:
                    out.append("  " * d + x["text"]); out += show(x.get("kids"), d + 1)
                return out
            print("==", w, "catena:", r["chain"])
            print("\n".join(show(r["tree"])) or "(nessun albero)")
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

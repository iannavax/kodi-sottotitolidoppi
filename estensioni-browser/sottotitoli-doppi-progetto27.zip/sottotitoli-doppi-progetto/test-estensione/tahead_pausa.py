# 1.5.4: diretta sincronizzata in pausa: non si trascrive più di liveAheadMax s avanti; le traduzioni a gruppi.
# (da tahead) 5.20: diretta in anticipo. yt-dlp (finto) legge l'audio della diretta 15 s più avanti del video; l'estensione lo mette
# a tempo con il video confrontando i volumi, trascrive in anticipo e mostra le frasi in orario.
# Confronto: con la trascrizione normale le frasi compaiono qualche secondo dopo l'inizio del parlato.
import asyncio, os, sys, subprocess, shutil, time, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
PROFILE = "/tmp/pwprofile-ahead"
MODE = "ahead"
MAXS = os.environ.get("MAXS", "6")
# inizio di ogni "frase" dell'audio di prova (crea_audio.py: durate, ognuna seguita da 0,6 s di pausa)
DUR = [2.6, 3.8, 1.9, 5.2, 3.1, 16.0, 2.4, 4.4, 3.0, 2.2, 3.6, 2.8, 4.0, 3.3]
STARTS = []; t = 0
for d in DUR: STARTS.append(t); t += d + 0.6
async def main():
    shutil.rmtree(PROFILE, ignore_errors=True); shutil.rmtree("/tmp/sdhome-ahead", ignore_errors=True)
    os.makedirs("/tmp/sdhome-ahead", exist_ok=True)
    env = dict(os.environ, FAKE_LIVE_OFFSET=os.environ.get("FAKE_LIVE_OFFSET", "15"), FAKE_LOG="/tmp/fake-ytdlp.log")
    async with async_playwright() as p:
        ctx, sw = await launch(p, PROFILE, env)
        ext = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false, liveAheadMax:%s, liveAhead:%s}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test', gemini:'AIza-test'}}))" % (MAXS, "true"))
        errs = []
        if MODE == "ahead":
            hp = await ctx.new_page()
            await hp.goto(f"chrome-extension://{ext}/helper.html"); await hp.wait_for_timeout(1000)
            await hp.select_option("#os", "linux")
            async with hp.expect_download() as d:
                await hp.click("#download")
            path = await (await d.value).path()
            r = subprocess.run(["sh", path], capture_output=True, text=True, env=dict(os.environ, HOME="/tmp/sdhome-ahead",
                SD_YTDLP_URL="file:///home/claude/e2e/fake/yt-dlp", SD_DENO_URL="file:///tmp/fakedeno.zip", SD_EXTRA_CHROME_DIRS=PROFILE + "/NativeMessagingHosts"))
            print("installatore:", r.returncode, "|", [l.strip() for l in r.stdout.splitlines() if "ffmpeg" in l])
            await hp.close()
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/embed/direttaAhead?autoplay=1"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        gem = lambda: len([c for c in log.get("gcalls", []) if c[1] == 200])
        for _ in range(90):   # fino a quando è a tempo
            lg = json.loads(await pg.evaluate("document.documentElement.dataset.dsLiveLog||'[]'"))
            if any(", a tempo:" in l for l in lg): break
            await pg.wait_for_timeout(1000)
        print("a tempo:", [l for l in lg if ", a tempo:" in l][:1])
        await pg.wait_for_timeout(5000)
        await pg.evaluate("document.querySelector('video').pause()")
        await pg.wait_for_timeout(2000)
        w0, g0, vt = len(log["groq"]), gem(), await pg.evaluate("document.querySelector('video').currentTime")
        await pg.wait_for_timeout(11000)   # (la diretta finta dura poco: dopo ~15 s finisce)
        w1, g1 = len(log["groq"]), gem()
        lg = json.loads(await pg.evaluate("document.documentElement.dataset.dsLiveLog||'[]'"))
        cues = json.loads(await pg.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))
        far = max([c["start"] / 1000 for c in cues] or [0]) - vt
        print("in pausa a", round(vt, 1), "s: pezzi a Whisper", w0, "->", w1, "| traduzioni Gemini", g0, "->", g1, "| frase più avanti:", round(far, 1), "s oltre il video")
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(20000)
        w2, g2 = len(log["groq"]), gem()
        print("dopo la ripresa: pezzi a Whisper", w2, "| traduzioni Gemini", g2, "| frasi:", len(json.loads(await pg.evaluate("document.documentElement.dataset.dualsubDebug || '[]'"))))
        print("registro:", [l for l in lg if "anticipo massimo" in l][:2])
        ok = w1 - w0 <= 1 and w2 >= w1 and far < float(MAXS) + 8 and any("anticipo massimo" in l for l in lg) and g2 >= 1
        if os.environ.get("SHOWLOG"): print("\n".join(lg))
        print("errori:", errs if ok else errs + ["anticipo massimo non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

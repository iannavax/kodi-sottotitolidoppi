import math, json, re, time, urllib.parse, os, sys, threading
import asyncio
from playwright.async_api import async_playwright

EXT = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/v5/build/chrome"
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
AUDIO = open("/tmp/speech.wav", "rb").read()
WEBM = open("/tmp/speech.webm", "rb").read()
log = {"groq": [], "google": 0, "gemini": [], "errors": []}

_CYR = dict(zip("абвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ",
               ["a","b","v","g","d","e","e","zh","z","i","j","k","l","m","n","o","p","r","s","t","u","f","h","c","ch","sh","sch","","y","","e","ju","ja"] * 2))
def tr(x):
    # "traduzione" finta ma diversa dall'originale, come una vera: parole rovesciate. Il cirillico in lettere latine:
    # l'estensione scarta le traduzioni che non sono nell'alfabeto della lingua scelta (italiano)
    return "".join(_CYR.get(c, c) for c in " ".join(w[::-1] for w in str(x).split()))

def page_html(vid, has):
    return f"""<!doctype html><html><head><title>Video di prova - YouTube</title></head><body style="margin:0;background:#111">
<div id="movie_player" class="html5-video-player" style="position:relative;width:1000px;height:560px;background:#000;overflow:hidden">
  <video class="html5-main-video" style="width:100%;height:100%"></video>
  <div class="ytp-right-controls" style="position:absolute;top:0;right:0;display:flex"><button class="ytp-subtitles-button" aria-pressed="true">CC</button></div>
  <div class="ytp-caption-window-container" style="position:absolute;top:10px;left:10px;color:#fff">nativi</div>
</div>
<script>
const VID={json.dumps(vid)}, HAS={str(has).lower()};
// come il vero YouTube: il video arriva "a pezzi" (indirizzo blob:, non scaricabile)
if (VID.startsWith('diretta')) {{
  // come una diretta: MediaSource senza durata (Infinity)
  const ms = new MediaSource(); const v = document.querySelector('video'); v.src = URL.createObjectURL(ms);
  ms.addEventListener('sourceopen', async () => {{
    const sb = ms.addSourceBuffer('audio/webm; codecs="opus"');
    const data = await (await fetch('/media/speech.webm')).arrayBuffer();
    sb.addEventListener('updateend', () => {{ try {{ ms.duration = Infinity; }} catch (e) {{}} }}, {{ once: true }});
    sb.appendBuffer(data);
  }});
}} else fetch(VID.startsWith('noCapsBig') ? '/media/big.wav' : '/media/speech.wav').then(r=>r.blob()).then(b=>{{document.querySelector('video').src=URL.createObjectURL(b);}});
const p=document.getElementById('movie_player');
p.getVideoData=()=>({{video_id:VID}});
// comandi del lettore di YouTube usati dalla diretta sincronizzata
{{ const v=document.querySelector('video');
  p.getCurrentTime=()=>v.currentTime; p.seekTo=(t)=>{{v.currentTime=t; window.__ytSeeks=(window.__ytSeeks||[]).concat([['to',+t.toFixed(1)]]);}};
  p.seekBy=(s)=>{{v.currentTime=v.currentTime+s; window.__ytSeeks=(window.__ytSeeks||[]).concat([['by',+s.toFixed(1)]]);}};
  p.seekToLiveHead=()=>{{const b=v.buffered; if(b.length) v.currentTime=b.end(b.length-1)-1; window.__ytSeeks=(window.__ytSeeks||[]).concat([['live',0]]);}};
  // come il vero YouTube nelle dirette: video.seekable copre solo i pochi secondi già scaricati
  if (VID.startsWith('diretta') && {json.dumps(bool(os.environ.get("YT_SMALL_SEEKABLE")))}) Object.defineProperty(v,'seekable',{{get(){{const c=v.currentTime; return {{length:1,start:()=>Math.max(0,c-2),end:()=>c+4}};}}}});
}}
p.getPlayerResponse=()=>({{videoDetails:{{videoId:VID}},captions:HAS?{{playerCaptionsTracklistRenderer:{{captionTracks:[{{}}]}}}}:undefined, streamingData: {json.dumps({"hlsManifestUrl": os.environ["FAKE_PAGE_HLS"]} if os.environ.get("FAKE_PAGE_HLS") else {})}}});
document.querySelector('video').addEventListener('click',e=>{{const v=e.target; v.paused?v.play():v.pause();}});
p.addEventListener('click',()=>{{window.__playerClicks=(window.__playerClicks||0)+1}});
const LANG=VID.startsWith('es')?'es':VID.startsWith('ja')?'ja':VID.startsWith('ru')?'ru':'en';
const askCaps=()=>{{const x=new XMLHttpRequest();x.open('GET','/api/timedtext?v='+VID+'&lang='+LANG+'&kind=asr&fmt=json3&pot=abc');x.send();}};
if(HAS) setTimeout(askCaps,400);
// come YouTube: il pulsante CC accende/spegne i sottotitoli e, riaccendendoli, li richiede di nuovo
document.querySelector('.ytp-subtitles-button').addEventListener('click',e=>{{const b=e.currentTarget; const on=b.getAttribute('aria-pressed')!=='true'; b.setAttribute('aria-pressed',String(on)); window.__ccClicks=(window.__ccClicks||0)+1; if(on&&HAS) askCaps();}});
</script></body></html>"""

def json3_long():
    events = []
    for i in range(120):
        events.append({"tStartMs": i * 3000, "dDurationMs": 2800, "segs": [{"utf8": f"this is sentence number {i+1}."}]})
    return {"events": events}

SHORT_LINES = ["Ja.", "we went to the market and bought bread", "Nej!", "Karen.", "Okay.", "then we walked home very slowly", "Tak."]
def json3_short():
    return {"events": [{"tStartMs": i * 2500, "dDurationMs": 2300, "segs": [{"utf8": l}]} for i, l in enumerate(SHORT_LINES)]}

def json3():
    words = "so we went to the market and bought some really fresh bread then we walked home slowly".split()
    events, t = [], 0
    for i in range(0, len(words), 4):
        grp = words[i:i+4]
        segs = [{"utf8": grp[0]}] + [{"utf8": " " + w, "tOffsetMs": 300*(k+1)} for k, w in enumerate(grp[1:])]
        events.append({"tStartMs": t, "dDurationMs": 3000, "segs": segs}); t += 1300
    # pausa lunga e seconda frase
    events.append({"tStartMs": t + 2500, "dDurationMs": 4000, "segs": [{"utf8": "it"}, {"utf8": " was", "tOffsetMs": 300}, {"utf8": " amazing", "tOffsetMs": 600}]})
    return {"events": events}

def ipa_fake(w):
    return "ˈ" + w.lower().replace("th", "θ").replace("sh", "ʃ").replace("ee", "iː")

def ipa_answer(who, user):
    words = json.loads(user)["words"]
    if who == "groq" and os.environ.get("GROQ_TPM") and len(words) > 50:
        # come Groq: richiesta troppo grande per i token al minuto
        log.setdefault("ipa413", []).append(len(words))
        return (413, json.dumps({"error": {"message": "Request too large for model `llama-3.3-70b-versatile` in organization `org` service tier `on_demand` on tokens per minute (TPM): Limit 12000, Requested 14210, please reduce your message size and try again.", "type": "tokens", "code": "rate_limit_exceeded"}}))
    if who == "gemini" and os.environ.get("GEM_IPA_DAILY"):
        log.setdefault("gem_ipa_daily", []).append(len(words))
        return (429, '[{"error":{"code":429,"message":"You exceeded your current quota","status":"RESOURCE_EXHAUSTED","details":[{"violations":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel-FreeTier"}]}]}}]')
    log.setdefault("ipa", []).append((who, list(words)))
    if any(re.search(r"[\u3040-\u30ff\u4e00-\u9fff]", w) for w in words):
        # come un modello vero con il giapponese: chiavi riscritte (in kana), ma tutte e nello stesso ordine
        return json.dumps({"choices": [{"message": {"content": json.dumps({"ipa": {"よみ" + str(i): "ja-" + w for i, w in enumerate(words)}}, ensure_ascii=False)}}]})
    if os.environ.get("IPA_FAIL"):
        return json.dumps({"choices": [{"message": {"content": "non so"}}]})
    return json.dumps({"choices": [{"message": {"content": json.dumps({"ipa": {w: ipa_fake(w) for w in words}})}}]})

def multipart_file_size(body):
    m = re.search(rb'filename="audio\.wav"\r\nContent-Type: audio/wav\r\n\r\n', body)
    if not m: return -1
    start = m.end(); end = body.index(b"\r\n--", start)
    return end - start


def gdict_body(text, trans, lang):
    # risposta "completa" di Google (dt=bd,md,ss,ex,rw,qca) come la dà translate_a/single
    b = [[[trans, text]], [["sostantivo", ["pane", "pagnotta"], [["pane", ["bread", "loaf"], None, 0.6], ["pagnotta", ["loaf", "bread"], None, 0.02]], text, 1]], lang]
    b += [None] * 12
    if text.lower() == "bread":
        b[11] = [["noun", [[["loaf", "baked goods"], "s1"]], "bread"]]
        b[12] = [["noun", [["food made of flour, water, and yeast, mixed together and baked.", "m1", "a loaf of bread"]], "bread"]]
        b[13] = [[["they ate <b>bread</b> and cheese", None, None, None, 3, "e1"]]]
        b[14] = [["breadstick", "breadcrumb"]]
    if text.lower() == "breaad":
        b[7] = ["<b><i>bread</i></b>", "bread", None, None, 1]
    return b

async def handle(route, request):
    url = request.url
    if not url.startswith("http"):
        return await route.continue_()
    try:
        if url.startswith("https://www.youtube.com/media/speech.webm") or url.startswith("https://www.youtube-nocookie.com/media/speech.webm"):
            return await route.fulfill(status=200, content_type="audio/webm", body=WEBM)
        if url.startswith("https://www.youtube-nocookie.com/media/speech.wav"):
            return await route.fulfill(status=200, content_type="audio/wav", body=AUDIO)
        if re.match(r"https://www\.youtube(-nocookie)?\.com/embed/", url):
            u = urllib.parse.urlparse(url)
            vid = u.path.split("/")[2]
            ch = urllib.parse.parse_qs(u.query).get("channel", [""])[0]
            if vid == "live_stream": vid = "diretta" + ch   # il vero video della diretta del canale
            return await route.fulfill(status=200, content_type="text/html", body=page_html(vid, False))
        if url.startswith("https://www.youtube.com/watch"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            vid = q["v"][0]
            return await route.fulfill(status=200, content_type="text/html", body=page_html(vid, not vid.startswith("noCaps")))
        if url.startswith("https://example.test/"):
            path = urllib.parse.urlparse(url).path
            if path.endswith(".wav"):
                return await route.fulfill(status=200, content_type="audio/wav", body=AUDIO, headers={"Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*"})
            if path.endswith(".vtt"):
                vtt = "WEBVTT\n\n" + "\n".join(f"00:00:{i*3:02d}.000 --> 00:00:{i*3+2:02d}.800\nthis is caption number {i+1}.\n" for i in range(15))
                return await route.fulfill(status=200, content_type="text/vtt", body=vtt, headers={"Access-Control-Allow-Origin": "*"})
            pages = {
              "/video.html": '<h1>Un sito qualsiasi</h1><video id="v" src="/speech.wav" controls style="width:800px;height:450px;background:#000"></video>',
              "/track.html": '<video id="v" src="/speech.wav" controls crossorigin="anonymous" style="width:800px;height:450px;background:#000"><track kind="subtitles" srclang="en" src="/subs.vtt" default></video>',
              "/audio.html": '<h1>Podcast</h1><audio id="v" src="/speech.wav" controls></audio>',
              "/tvgarden.html": '<h1>Canale</h1><iframe id="f" src="https://www.youtube-nocookie.com/embed/abcdefghijk?autoplay=1" style="width:800px;height:450px;border:0" allow="autoplay"></iframe>',
              "/tvgarden-diretta.html": '<h1>Canale in diretta</h1><iframe id="f" src="https://www.youtube.com/embed/diretta1234?autoplay=1" style="width:800px;height:450px;border:0" allow="autoplay"></iframe>',
              "/iptv.html": '<h1>Sito IPTV</h1><video id="loro" src="/speech.wav" preload="auto" style="width:320px;height:180px;background:#000"></video><iframe id="f" src="https://www.youtube.com/embed/live_stream?channel=UCcccccccc" style="width:800px;height:450px;border:0" allow="autoplay"></iframe>',
              "/canaleA.html": '<iframe src="https://www.youtube.com/embed/live_stream?channel=UCaaaaaaaa" style="width:800px;height:450px;border:0" allow="autoplay"></iframe>',
              "/canaleB.html": '<iframe src="https://www.youtube.com/embed/live_stream?channel=UCbbbbbbbb" style="width:800px;height:450px;border:0" allow="autoplay"></iframe>',
              "/vimeo.html": '<h1>Come Vimeo</h1><video id="v" controls style="width:800px;height:450px;background:#000"></video><script>fetch("/speech.wav").then(r=>r.blob()).then(b=>{document.getElementById("v").src=URL.createObjectURL(b)})</script>',
            }
            if path in pages:
                return await route.fulfill(status=200, content_type="text/html", body=f"<!doctype html><html><head><title>Pagina {path}</title></head><body style='margin:20px'>{pages[path]}</body></html>")
            return await route.fulfill(status=404, body="")
        if url.startswith("https://www.youtube.com/media/big.wav"):
            return await route.fulfill(status=200, content_type="audio/wav", body=open("/tmp/big.wav","rb").read())
        if url.startswith("https://www.youtube.com/media/speech.wav"):
            return await route.fulfill(status=200, content_type="audio/wav", body=AUDIO, headers={"Accept-Ranges": "bytes"})
        if url.startswith("https://www.google.com/async/callback:5493"):
            # dizionario di Google (formato della pagina dei risultati, con ")]}'" davanti)
            a = urllib.parse.unquote(url.split("async=")[1]); term = a.split("term:")[1].split(",")[0]; corpus = a.split("corpus:")[1].split(",")[0]
            log.setdefault("gweb", []).append((term, corpus))
            E = {
              "market": {"headword": "market", "phonetics": [{"text": "ˈmɑːkɪt", "oxford_audio": "//ssl.gstatic.com/dictionary/static/sounds/oxford/market--_gb_1.mp3"}],
                         "etymology": {"etymology": {"text": "late Old English, from Latin mercatus 'purchase', from mercari 'buy'."}, "images": [{"image_url": "//ssl.gstatic.com/dictionary/static/images/etymology/market.png"}]},
                         "sense_families": [{"parts_of_speech": [{"value": "noun"}], "morph_units": [{"form_type": {"description": "plural"}, "word_form": "markets"}],
                                             "senses": [{"definition": {"text": "a regular gathering of people for the purchase and sale of provisions"}, "example_groups": [{"examples": ["farmers driving their cattle to market"]}],
                                                         "thesaurus_entries": [{"synonyms": [{"nyms": [{"nym": "marketplace"}, {"nym": "mart"}]}], "antonyms": []}]}]}]},
              "bread": {"headword": "bread", "phonetics": [{"text": "brɛd"}], "sense_families": [{"parts_of_speech": [{"value": "noun"}], "senses": [{"definition": {"text": "food made of flour, water, and yeast"}}]}]},
            }
            single = [{"entry": E[term]}] if term in E else []
            body = ")]}'\n" + json.dumps({"feature-callback": {"payload": {"single_results": single}}})
            return await route.fulfill(status=200, content_type="application/json", body=body)
        if url.startswith("https://books.google.com/ngrams/json"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            log.setdefault("ngram", []).append((q.get("content", [""])[0], q.get("corpus", [""])[0]))
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps([{"ngram": q.get("content", [""])[0], "timeseries": [1e-6 * max(0.05, 2 + 6 * math.exp(-((i - 150) / 30) ** 2) + i / 100 + (1.5 * math.sin(i * 1.7) if i < 40 else 0)) for i in range(223 if q.get("corpus", [""])[0] in ("en", "it", "fr", "de", "es", "ru") else 220)]}]))
        if url.startswith("https://ssl.gstatic.com/dictionary/"):
            log.setdefault("gstatic", []).append(url)
            if url.endswith(".png"):
                import base64 as _b
                return await route.fulfill(status=200, content_type="image/png", body=_b.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="))
            import io, wave as _w
            b = io.BytesIO(); ww = _w.open(b, "wb"); ww.setnchannels(1); ww.setsampwidth(2); ww.setframerate(16000); ww.writeframes(b"\x00\x10" * 4000); ww.close()
            return await route.fulfill(status=200, content_type="audio/mpeg", body=b.getvalue())
        if url.startswith("https://en.wiktionary.org/w/api.php") and "list=categorymembers" in url:
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query); cat = q.get("cmtitle", [""])[0]
            log.setdefault("idiomdict", []).append(cat)
            mem = {"Category:English idioms": ["kick the bucket", "break the ice", "at all", "pull someone's leg", "really good"] + (["walk home"] if os.environ.get("TR_IDIOMS") else [])}.get(cat, [])
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"query": {"categorymembers": [{"ns": 0, "title": t} for t in mem]}}), headers={"Access-Control-Allow-Origin": "*"})
        if url.startswith("https://en.wiktionary.org/w/api.php") and "list=prefixsearch" in url:
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query); pq = q.get("pssearch", [""])[0]
            log.setdefault("wiktprefix", []).append(pq)
            allp = ["сожаление", "сожалеть", "сожжение", "подошва", "подошвенный", "подошёл"]
            found = [t for t in allp if t.startswith(pq)][:8]
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"query": {"prefixsearch": [{"title": t} for t in found]}}), headers={"Access-Control-Allow-Origin": "*"})
        if url.startswith("https://en.wiktionary.org/w/api.php") and "list=search" in url:
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query); sq = q.get("srsearch", [""])[0].strip('"')
            log.setdefault("wiktsearch", []).append(sq)
            found = {"подошве": ["подошел", "подошва"], "сожалению": ["к сожалению", "сожаление"]}.get(sq, [])
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"query": {"search": [{"title": t} for t in found]}}), headers={"Access-Control-Allow-Origin": "*"})
        if url.startswith("https://en.wiktionary.org/w/api.php"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query); page = q.get("page", [""])[0]
            log.setdefault("wikt", []).append(page)
            H = lambda lvl, t: f'<div class="mw-heading mw-heading{lvl}"><h{lvl} id="{t.replace(" ", "_")}">{t}</h{lvl}><span class="mw-editsection">[edit]</span></div>'
            HO = lambda lvl, t: f'<h{lvl}><span class="mw-headline" id="{t.replace(" ", "_")}">{t}</span><span class="mw-editsection">[<a>edit</a>]</span></h{lvl}>'
            pages = {
              "bread": H(2, "Middle English") + H(3, "Etymology") + "<p>SBAGLIATA: questa è la sezione del medio inglese.</p>" +
                       H(2, "English") + H(3, "Etymology") + ('<div class="NavFrame etymtree"><div class="NavHead">Etymology tree</div><div class="NavContent"><ul><li>Proto-Indo-European *bʰrewh₁-<ul><li>Proto-Germanic *braudą<ul><li>Old English brēad<ul><li>Middle English breed<ul><li>English bread</li></ul></li></ul></li></ul></li><li>Proto-Germanic *brauþą (altro ramo)</li></ul></li></ul></div></div>' if os.environ.get("WIKT_TREE", "1") == "1" else "") + '<p>From <span class="etyl">Middle English</span> <i class="Latn mention" lang="enm">breed</i>, from <span class="etyl">Old English</span> <i class="Latn mention" lang="ang">brēad</i> <span class="mention-gloss-paren annotation-paren">(</span><span class="mention-gloss-double-quote">“</span><span class="mention-gloss">fragment, morsel</span><span class="mention-gloss-double-quote">”</span><span class="mention-gloss-paren annotation-paren">)</span>, from <span class="etyl">Proto-Germanic</span> <i class="Latn mention" lang="gem-pro">*braudą</i><sup class="reference">[1]</sup>.</p><p>Cognate with <span class="etyl">German</span> <i class="Latn mention" lang="de">Brot</i>, <span class="etyl">Dutch</span> <i class="Latn mention" lang="nl">brood</i>.</p>' +
                       H(3, "Pronunciation") + '<ul><li><a>IPA</a>: <span class="IPA">/bɹɛd/</span>, <span class="IPA">[bɹɛːd]</span></li><li><span class="unicode audiolink">Audio (US):</span><audio controls><source src="//upload.wikimedia.org/wikipedia/commons/transcoded/a/ab/En-us-bread.ogg/En-us-bread.ogg.mp3" type="audio/mpeg"><source src="//upload.wikimedia.org/wikipedia/commons/a/ab/En-us-bread.ogg" type="audio/ogg"></audio></li></ul>' +
                       H(3, "Noun") + '<p><span class="headword-line"><strong class="Latn headword">bread</strong> <span class="gender"><abbr title="neuter gender">n</abbr></span></span></p><ol><li>A foodstuff.</li></ol>',
              "кошка": H(2, "Russian") + H(3, "Pronunciation") + '<ul><li>Audio: <a href="/wiki/File:Ru-%D0%BA%D0%BE%D1%88%D0%BA%D0%B0.ogg" title="File:Ru-кошка.ogg">(file)</a></li></ul>' + H(3, "Noun") + "<p><b>ко́шка</b></p>",
              "гордую": H(2, "Russian") + H(3, "Adjective") + '<p><b>гордую</b></p><ol><li><span class="form-of-definition">accusative feminine singular of <span class="form-of-definition-link"><i class="Cyrl mention" lang="ru"><a href="/wiki/гордый#Russian" title="гордый">го́рдый</a></i></span></span></li></ol>',
              "гордый": H(2, "Russian") + H(3, "Etymology") + "<p>From Old East Slavic.</p>" + H(3, "Pronunciation") + '<ul><li>IPA: <span class="IPA">[ˈgordɨj]</span></li><li><audio><source src="//upload.wikimedia.org/wikipedia/commons/x/xx/Ru-гордый.ogg" type="audio/ogg"></audio></li></ul>' + H(3, "Adjective") + "<ol><li>proud</li></ol>",
              "embarazada": H(2, "Spanish") + H(3, "Adjective") + '<p><b>embarazada</b></p><ol><li><span class="form-of-definition">feminine singular of <span class="form-of-definition-link"><i class="Latn mention" lang="es"><a href="/wiki/embarazado#Spanish" title="embarazado">embarazado</a></i></span></span></li></ol>',
              "embarazado": H(2, "Spanish") + H(3, "Etymology") + '<p>Past participle of <i class="Latn mention" lang="es"><a href="/wiki/embarazar#Spanish" title="embarazar">embarazar</a></i>.</p>' + H(3, "Adjective") + "<ol><li>pregnant</li></ol>",
              "embarazar": H(2, "Spanish") + H(3, "Etymology") + '<p>Borrowed from <a href="/wiki/Portuguese">Portuguese</a> <i class="Latn mention" lang="pt"><a href="/wiki/embara%C3%A7ar#Portuguese">embaraçar</a></i>, from <i class="Latn mention" lang="pt"><a href="/wiki/em-#Portuguese">em-</a></i> + <i class="Latn mention" lang="pt"><a href="/wiki/bara%C3%A7o#Portuguese">baraço</a></i> (“cord, noose”).</p>' + H(3, "Verb") + "<ol><li>to hinder</li></ol>",
              "embaraçar": H(2, "Galician") + H(3, "Etymology") + "<p>SBAGLIATA: sezione del galiziano.</p>" + H(2, "Portuguese") + H(3, "Etymology") + '<p>From <i class="Latn mention" lang="pt"><a href="/wiki/em-#Portuguese">em-</a></i> + <i class="Latn mention" lang="pt"><a href="/wiki/bara%C3%A7o#Portuguese">baraço</a></i> + <i class="Latn mention" lang="pt"><a href="/wiki/-ar#Portuguese">-ar</a></i>.</p>',
              "baraço": H(2, "Portuguese") + H(3, "Etymology") + '<p>From Old Galician-Portuguese <i class="Latn mention" lang="roa-opt">baraço</i>, possibly from Arabic <i class="Arab mention" lang="ar">مَرَسَة</i> (“rope”).</p>',
              "подошел": H(2, "Russian") + H(3, "Etymology") + "<p>SBAGLIATA: non è la parola madre.</p>" + H(3, "Verb") + '<table class="inflection-table"><tr><th>past</th><td>подошёл, подошла́</td></tr></table>',
              "подошва": H(2, "Russian") + H(3, "Etymology") + '<p>From <i class="Cyrl mention" lang="ru">под-</i> + <i class="Cyrl mention" lang="ru">шить</i> (“to sew”); literally “something sewn underneath”.</p>' + H(3, "Pronunciation") + '<ul><li><audio><source src="//upload.wikimedia.org/wikipedia/commons/x/xx/Ru-подошва.ogg" type="audio/ogg"></audio></li></ul>' + H(3, "Noun") +
                         '<div class="NavFrame"><div class="NavContent"><table class="inflection-table"><tr><th></th><th>singular</th><th>plural</th></tr><tr><th>nominative</th><td>подо́шва</td><td>подо́швы</td></tr><tr><th>dative</th><td>подо́шве</td><td>подо́швам</td></tr><tr><th>prepositional</th><td>подо́шве</td><td>подо́швах</td></tr></table></div></div>',
              "сожалеть": H(2, "Russian") + H(3, "Etymology") + "<p>From <i class=\"Cyrl mention\" lang=\"ru\">жалеть</i> (“to pity”).</p>" + H(3, "Verb") + "<ol><li>to regret</li></ol>",
              "сожаление": H(2, "Russian") + H(3, "Etymology") + "<p>From <i class=\"Cyrl mention\" lang=\"ru\">сожале́ть</i> (“to regret”) + -ение.</p>" + H(3, "Noun") + "<ol><li>regret</li></ol>",
              "начинать": H(2, "Russian") + H(3, "Etymology") + '<p>Imperfective of <i class="Cyrl mention" lang="ru"><a href="/wiki/начать#Russian" title="начать">нача́ть</a></i> <span class="mention-gloss-paren annotation-paren">(</span><span lang="ru-Latn" class="mention-tr tr Latn">načátʹ</span><span class="mention-gloss-paren annotation-paren">)</span>. By surface analysis, <i class="Cyrl mention" lang="ru"><a href="/wiki/на-#Russian">на-</a></i> <span class="mention-gloss-paren annotation-paren">(</span><span lang="ru-Latn" class="mention-tr tr Latn">na-</span><span class="mention-gloss-paren annotation-paren">)</span> + <i class="Cyrl mention" lang="ru"><a href="/wiki/-чинать#Russian">-чина́ть</a></i> <span class="mention-gloss-paren annotation-paren">(</span><span lang="ru-Latn" class="mention-tr tr Latn">-činátʹ</span><span class="mention-gloss-paren annotation-paren">)</span>.</p>' + H(3, "Verb") + "<ol><li>to begin</li></ol>",
              "начать": H(2, "Russian") + H(3, "Etymology") + '<p>From <span class="etyl">Old East Slavic</span> <i class="Cyrl mention" lang="orv">начати</i> <span class="mention-gloss-paren annotation-paren">(</span><span lang="orv-Latn" class="mention-tr tr Latn">načati</span><span class="mention-gloss-paren annotation-paren">)</span>, from <span class="etyl">Proto-Slavic</span> <i class="Latn mention" lang="sla-pro">*načęti</i>, from <i class="Latn mention" lang="sla-pro">*na-</i> + <i class="Latn mention" lang="sla-pro">*-čęti</i> <span class="mention-gloss-paren annotation-paren">(</span><span class="mention-gloss-double-quote">“</span><span class="mention-gloss">to begin</span><span class="mention-gloss-double-quote">”</span><span class="mention-gloss-paren annotation-paren">)</span>. Cognate with <span class="etyl">Polish</span> <i class="Latn mention" lang="pl">zacząć</i>.</p>' + H(3, "Verb") + "<ol><li>to begin</li></ol>",
              "market": H(2, "English") + H(3, "Noun") + "<p><b>market</b></p><ol><li>A place.</li></ol>",
              "walked": HO(2, "English") + HO(3, "Verb") + '<ol><li><span class="form-of-definition use-with-mention">simple past and past participle of <span class="form-of-definition-link"><i class="Latn mention" lang="en"><a href="/wiki/walk#English" title="walk">walk</a></i></span></span></li></ol>',
              "walk": HO(2, "English") + HO(3, "Etymology 1") + "<p>From Middle English <i>walken</i>, from Old English <i>wealcan</i> (to roll).</p>" + '<ul><li><audio><source src="//upload.wikimedia.org/wikipedia/commons/x/xx/En-us-walk.ogg.mp3" type="audio/mpeg"></audio></li></ul>' + HO(3, "Verb") +
                      '<div class="NavFrame"><div class="NavHead">Conjugation of walk</div><div class="NavContent"><table class="inflection-table"><tr><th>infinitive</th><td>to walk</td></tr><tr><th>past</th><td>walked</td></tr><tr><th>present participle</th><td>walking</td></tr></table></div></div>' + HO(3, "Etymology 2") + "<p>Altra.</p>",
            }
            if page in pages:
                body = {"parse": {"title": page, "text": '<div class="mw-content-ltr mw-parser-output" lang="en">' + pages[page] + "</div>"}}
            else:
                body = {"error": {"code": "missingtitle", "info": "The page you specified doesn't exist."}}
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body), headers={"Access-Control-Allow-Origin": "*"})
        if url.startswith("https://commons.wikimedia.org/wiki/Special:FilePath/"):
            log.setdefault("audio", []).append(urllib.parse.unquote(url))
            import io, wave as _w
            b = io.BytesIO(); ww = _w.open(b, "wb"); ww.setnchannels(1); ww.setsampwidth(2); ww.setframerate(16000); ww.writeframes(b"\x00\x10" * 4000); ww.close()
            return await route.fulfill(status=200, content_type="audio/ogg", body=b.getvalue())
        if re.match(r"https://upload\.wikimedia\.org/.*\.(jpe?g|png)$", url, re.I) or url.startswith("https://api.openverse.org/v1/images/x"):
            log.setdefault("img", []).append(url)
            import base64 as _b
            return await route.fulfill(status=200, content_type="image/png", body=_b.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="))
        if url.startswith("https://en.wikipedia.org/w/api.php"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("gsrsearch", [""])[0]
            log.setdefault("wp", []).append(q)
            pages = [{"pageid": 9, "index": 1, "title": q.title(), "pageimage": q + ".jpg", "thumbnail": {"source": "https://upload.wikimedia.org/wikipedia/commons/thumb/w/wp/WP_" + q.replace(" ", "_") + ".jpg/400px-WP.jpg"}}] if q else []
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"query": {"pages": pages}}))
        if url.startswith("https://api.openverse.org/v1/images/"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("q", [""])[0]
            log.setdefault("ov", []).append(q)
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"results": [{"title": "OV " + q, "url": "https://api.openverse.org/v1/images/x1.jpg", "thumbnail": "https://api.openverse.org/v1/images/x1/thumb.jpg"}]}))
        if url.startswith("https://upload.wikimedia.org/") or url.startswith("https://audio.tatoeba.org/") or url.startswith("https://tatoeba.org/audio/") or url.startswith("https://tatoeba.org/en/audio/"):
            log.setdefault("audio", []).append(url)
            import io, wave as _w
            b = io.BytesIO(); ww = _w.open(b, "wb"); ww.setnchannels(1); ww.setsampwidth(2); ww.setframerate(16000); ww.writeframes(b"\x00\x10" * 8000); ww.close()
            return await route.fulfill(status=200, content_type="audio/mpeg", body=b.getvalue())
        if url.startswith("https://tatoeba.org/en/api_v0/search"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query); w = q.get("query", [""])[0]
            log.setdefault("tatoeba", []).append(w)
            if os.environ.get("TATOEBA_DOWN"): return await route.fulfill(status=503, body="")
            res = []
            withaudio = "has_audio=yes" in url
            log.setdefault("tatoeba_audio", []).append(withaudio)
            if w.lower() in ("bread", "walked", "market") and withaudio:
                res = [{"id": 101, "text": f"I like {w} very much.", "lang": "eng", "audios": [{"id": 5001, "source": "tatoeba", "author": "CK", "download_url": "/en/audio/download/5001"}],
                        "translations": [[{"id": 201, "text": f"Mi piace molto ({w}).", "lang": "ita", "audios": []}], []]}]
            elif w.lower() in ("bread", "walked", "market"):
                res = [{"id": 101, "text": f"I like {w} very much.", "lang": "eng", "audios": [{"id": 5001, "download_url": "/en/audio/download/5001"}], "translations": [[], []]},
                       {"id": 102, "text": f"Where is the {w}?", "lang": "eng", "audios": [], "translations": [[{"id": 202, "text": "x", "lang": "fra"}], []]},
                       {"id": 104, "text": f"Two {w[:-1]}s here.", "lang": "eng", "audios": [], "translations": [[], []]},
                       {"id": 103, "text": "Unrelated sentence.", "lang": "eng", "audios": [], "translations": [[]]}]
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"paging": {}, "results": res}))
        if url.startswith("https://api.tatoeba.org/v1/audio/"):
            log.setdefault("audio", []).append(url)
            if os.environ.get("TATOEBA_V1_AUDIO_403"): return await route.fulfill(status=403, body="")
            import io, wave as _w
            b = io.BytesIO(); ww = _w.open(b, "wb"); ww.setnchannels(1); ww.setsampwidth(2); ww.setframerate(16000); ww.writeframes(b"\x00\x10" * 8000); ww.close()
            return await route.fulfill(status=200, content_type="audio/mpeg", body=b.getvalue())
        if url.startswith("https://api.tatoeba.org/v1/sentences"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query); w = q.get("q", [""])[0]
            log.setdefault("tatoeba", []).append(w); log.setdefault("tatoeba_v1", []).append(("has_audio=yes" in url, "include=audios" in url))
            if os.environ.get("TATOEBA_V1_DOWN"): return await route.fulfill(status=500, body="")
            data = []
            if w.lower() in ("bread", "walked", "market") and "has_audio=yes" in url:
                data = [{"id": 101, "text": f"I like {w} very much.", "lang": "eng", "audios": [{"id": 5001, "author": "CK", "download_url": "https://api.tatoeba.org/v1/audio/5001/file"}],
                         "translations": [{"id": 201, "text": f"Mi piace molto ({w}).", "lang": "ita", "is_direct": True, "audios": []}]}]
            elif w.lower() in ("bread", "walked", "market"):
                data = [{"id": 101, "text": f"I like {w} very much.", "lang": "eng", "audios": [{"id": 5001, "download_url": "https://api.tatoeba.org/v1/audio/5001/file"}], "translations": []},
                        {"id": 102, "text": f"Where is the {w}?", "lang": "eng", "audios": [], "translations": []},
                        {"id": 104, "text": f"Two {w[:-1]}s here.", "lang": "eng", "audios": [], "translations": []}]
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"data": data, "paging": {}}))
        if url.startswith("https://api.tatoeba.org/"):
            return await route.fulfill(status=404, body="")
        if url.startswith("https://api.languagetool.org/v2/check"):
            f = urllib.parse.parse_qs(request.post_data or ""); text = f.get("text", [""])[0]
            log.setdefault("lt", []).append(text)
            m = []
            i = text.find("walkd")
            if i >= 0: m.append({"offset": i, "length": 5, "message": "Possible spelling mistake found.", "shortMessage": "Spelling mistake", "replacements": [{"value": "walked"}, {"value": "walk"}], "rule": {"issueType": "misspelling"}})
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"matches": m}))
        if url.startswith("https://raw.githubusercontent.com/hermitdave/FrequencyWords/"):
            log.setdefault("freq", []).append(url)
            if "/en/" not in url: return await route.fulfill(status=404, body="404: Not Found")
            words = ["you", "i", "the", "to", "a", "it", "and", "we", "so", "then", "home", "went", "some", "really", "very", "walked", "bought"] + [f"w{k}" for k in range(1500)] + ["market", "bread"] + [f"z{k}" for k in range(5000)] + ["slowly"]
            return await route.fulfill(status=200, content_type="text/plain", body="\n".join(f"{w} {100000 - k}" for k, w in enumerate(words)))
        if url.startswith("https://commons.wikimedia.org/w/api.php"):
            log.setdefault("commons", []).append(url)
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"query": {"pages": [
                {"pageid": 1, "index": 2, "title": "File:B.svg", "imageinfo": [{"url": "https://upload.wikimedia.org/b.svg", "mime": "image/svg+xml"}]},
                {"pageid": 2, "index": 1, "title": "File:Bread.jpg", "imageinfo": [{"url": "https://upload.wikimedia.org/wikipedia/commons/1/1a/Bread.jpg", "thumburl": "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Bread.jpg/320px-Bread.jpg", "mime": "image/jpeg"}]}]}}))
        m_ed = re.match(r"https://([a-z-]+)\.wiktionary\.org/w/api\.php", url)
        if m_ed and m_ed.group(1) != "en":
            ed = m_ed.group(1); page = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("page", [""])[0]
            log.setdefault("wikt_other", []).append((ed, page))
            P2 = lambda t: f'<div class="mw-heading mw-heading2"><h2>{t}</h2></div>'
            other = {("ru", "примечание"): P2("Русский") + '<h3>Произношение</h3><p>[prʲɪmʲɪˈt͡ɕænʲɪje]</p><p><span typeof="mw:File"><span><audio controls="" preload="none" class="mw-file-element" data-mwtitle="Ru-примечание.ogg" data-mwprovider="wikimediacommons"></audio></span></span></p>',
                     ("it", "market"): P2("Italiano") + "<p>/ˈsbaʎʎato/</p>" + P2("Inglese") + "<p>Pronuncia: IPA: /ˈmɑːkɪt/</p>",
                     ("fr", "walked"): P2("Anglais") + "<p>walked</p>",
                     ("ru", "кошка"): P2("Русский") + "<h3>Морфологические и синтаксические свойства</h3><p>Существительное.</p><h3>Семантические свойства</h3><h4>Значение</h4>" +
                        '<ol><li><a>зоол.</a> домашнее животное семейства кошачьих <span class="example-block">◆ Кошка спит на диване.</span></li><li>самка кота<sup class="reference">[1]</sup></li></ol>' +
                        '<h4>Синонимы</h4><ol><li>киса</li></ol>' + '<div class="mw-references-wrap"><ol class="references"><li>Словарь Ушакова</li></ol></div>'}
            if (ed, page) == ("ru", "гордую"):   # rimando alla forma base, come fa Wiktionary con redirects=1
                body = {"parse": {"title": "гордый", "text": '<div class="mw-parser-output">' + P2("Русский") + '<h3>Произношение</h3><p>[ˈgordɨj]</p><p><audio data-mwtitle="Ru-гордый.ogg"></audio></p></div>'}}
            elif (ed, page) in other:
                body = {"parse": {"title": page, "text": '<div class="mw-parser-output">' + other[(ed, page)] + "</div>"}}
            else:
                body = {"error": {"code": "missingtitle"}}
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body, ensure_ascii=False))
        m_az = re.match(r"https://([a-z0-9]+)\.tts\.speech\.microsoft\.com/cognitiveservices/(voices/list|v1)", url)
        if m_az:
            key = request.headers.get("ocp-apim-subscription-key", "")
            log.setdefault("azure", []).append((m_az.group(1), m_az.group(2), key, request.post_data if m_az.group(2) == "v1" else ""))
            if key != "AZ-OK": return await route.fulfill(status=401, content_type="application/json", body='{"error":{"code":"401","message":"Access denied due to invalid subscription key"}}')
            if m_az.group(2) == "voices/list":
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps([
                    {"ShortName": "en-US-AvaMultilingualNeural", "Locale": "en-US", "LocalName": "Ava Multilingual", "Gender": "Female", "VoiceType": "Neural"},
                    {"ShortName": "en-GB-SoniaNeural", "Locale": "en-GB", "LocalName": "Sonia", "Gender": "Female", "VoiceType": "Neural"},
                    {"ShortName": "en-US-JennyNeural", "Locale": "en-US", "LocalName": "Jenny", "Gender": "Female", "VoiceType": "Neural"},
                    {"ShortName": "cs-CZ-VlastaNeural", "Locale": "cs-CZ", "LocalName": "Vlasta", "Gender": "Female", "VoiceType": "Neural"}]))
            import io, wave as _w
            b = io.BytesIO(); ww = _w.open(b, "wb"); ww.setnchannels(1); ww.setsampwidth(2); ww.setframerate(16000); ww.writeframes(b"\x00\x10" * 4000); ww.close()
            return await route.fulfill(status=200, content_type="audio/mpeg", body=b.getvalue())
        if url.startswith("http://127.0.0.1:8765"):
            r = json.loads(request.post_data or "{}"); a = r.get("action"); par = r.get("params", {})
            log.setdefault("anki", []).append((a, par))
            if a == "addNote":
                f = par["note"]["fields"]["Fronte"]
                seen = log.setdefault("anki_fronts", set())
                if f in seen: return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"result": None, "error": "cannot create note because it is a duplicate"}))
                seen.add(f)
            res = {"requestPermission": {"permission": "granted", "requireApikey": False, "version": 6}, "version": 6,
                   "modelNames": ["Base", "Cloze"], "modelFieldNames": ["Fronte", "Retro"], "createDeck": 1, "deckNames": ["Default"],
                   "addNote": 1000 + len(log["anki"])}.get(a)
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"result": res, "error": None}))
        if "commons.wikimedia.org/wiki/Special:FilePath/" in url and ("-order.gif" in urllib.parse.unquote(url) or "-red.png" in url or "-bw.png" in url):
            # ordine dei tratti: c'è solo per 勉 (una GIF di 1 pixel)
            log.setdefault("strokeorder", []).append(urllib.parse.unquote(url.rsplit("/", 1)[1]))
            if urllib.parse.unquote(url.rsplit("/", 1)[1]) == "勉-order.gif":
                gif = bytes.fromhex("47494638396101000100800000000000ffffff21f90401000000002c00000000010001000002024401003b")
                return await route.fulfill(status=200, content_type="image/gif", body=gif)
            return await route.fulfill(status=404, body="")
        if url.startswith("https://kanjiapi.dev/v1/kanji/"):   # dati di KANJIDIC per un kanji (formato di kanjiapi.dev)
            ch = urllib.parse.unquote(url.rsplit("/", 1)[1])
            log.setdefault("kanjiapi", []).append(ch)
            K = {"勉": {"kanji": "勉", "grade": 3, "stroke_count": 10, "meanings": ["exertion", "endeavour", "strive"], "kun_readings": ["つと.める"], "on_readings": ["ベン"], "name_readings": [], "jlpt": 3, "unicode": "52c9", "heisig_en": "exertion"},
                 "強": {"kanji": "強", "grade": 2, "stroke_count": 11, "meanings": ["strong"], "kun_readings": ["つよ.い", "し.いる"], "on_readings": ["キョウ", "ゴウ"], "name_readings": ["こわ"], "jlpt": 3, "unicode": "5f37", "heisig_en": "strong"}}
            if ch not in K: return await route.fulfill(status=404, content_type="application/json", body="{}")
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(K[ch], ensure_ascii=False))
        if url.startswith("https://jisho.org/api/v1/search/words"):
            w = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("keyword", [""])[0]
            log.setdefault("jisho", []).append(w)
            if w.startswith("#jlpt-"):   # elenco di un livello: 20 per pagina, 勉強 a pagina 2
                pg_ = int(urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("page", ["1"])[0])
                n_ = 20 if pg_ == 1 else 10 if pg_ == 2 else 0
                data = [{"slug": f"語{pg_}-{i}", "is_common": i % 2 == 0, "jlpt": [w[1:]], "japanese": [{"word": f"語{pg_}-{i}", "reading": f"ご{pg_}{i}"}],
                         "senses": [{"english_definitions": [f"word {pg_}-{i}"], "parts_of_speech": ["Noun"]}]} for i in range(n_)]
                if pg_ == 2: data[3] = {"slug": "勉強", "is_common": True, "jlpt": ["jlpt-n5"], "japanese": [{"word": "勉強", "reading": "べんきょう"}], "senses": [{"english_definitions": ["study"], "parts_of_speech": ["Noun"]}]}
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"meta": {"status": 200}, "data": data}, ensure_ascii=False))
            data = [{"slug": "勉強", "is_common": True, "jlpt": ["jlpt-n3", "jlpt-n5"], "japanese": [{"word": "勉強", "reading": "べんきょう"}],
                     "senses": [{"english_definitions": ["study"], "parts_of_speech": ["Noun", "Suru verb"]}]}] if "勉強" in w else []
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"meta": {"status": 200}, "data": data}, ensure_ascii=False))
        if url.startswith("https://www.youtube.com/api/timedtext"):
            long = "v=long" in url
            if "v=ja" in url:   # sottotitoli giapponesi
                JA = ["日本語を勉強しています。", "毎日新しい言葉を覚えます。", "今日はとても暑いですね。"]
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"events": [{"tStartMs": i * 3000, "dDurationMs": 2800, "segs": [{"utf8": l}]} for i, l in enumerate(JA)]}))
            if "v=ruIdiom" in url:   # modo di dire con una parola di una lettera: "к сожалению"
                RU = ["Я, к сожалению, не могу прийти сегодня вечером."] * 3
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"events": [{"tStartMs": i * 3000, "dDurationMs": 2800, "segs": [{"utf8": l}]} for i, l in enumerate(RU)]}))
            if "v=ru" in url:   # sottotitoli russi
                RU = ["Привет, как дела?", "Кошка спит на диване.", "Я живу в доме."]
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"events": [{"tStartMs": i * 3000, "dDurationMs": 2800, "segs": [{"utf8": l}]} for i, l in enumerate(RU)]}))
            if "v=shortCopy" in url:
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps(json3_short()))
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(json3_long() if long else json3()))
        if "/translate_tts" in url:
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            log.setdefault("tts", []).append((q.get("tl", [""])[0], q.get("q", [""])[0]))
            import io, wave as _w
            b = io.BytesIO(); ww = _w.open(b, "wb"); ww.setnchannels(1); ww.setsampwidth(2); ww.setframerate(16000); ww.writeframes(b"\x00\x10" * 8000); ww.close()
            return await route.fulfill(status=200, content_type="audio/mpeg", body=b.getvalue())
        if url.startswith("https://translate.googleapis.com/"):
            log["google"] += 1
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            text = q.get("q", [""])[0]
            if "rm" in q.get("dt", []) and q.get("tl", [""])[0] == "en" and "bd" not in q.get("dt", []):
                log.setdefault("romanline", []).append(text)
                body = [[["EN", text], [None, None, None, "ROMA[" + text + "]"]], None, q.get("sl", ["ja"])[0]]
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
            if "rm" in q.get("dt", []) and "bd" in q.get("dt", []) and len(text) == 1 and "\u4e00" <= text <= "\u9fff":
                # un kanji/carattere cinese da solo (hanChar): significato, lettura e altre traduzioni
                log.setdefault("hanchar", []).append((text, q.get("sl", [""])[0], q.get("tl", [""])[0]))
                body = [[["CAR[" + text + "]", text], [None, None, None, "rd-" + text]], [["sostantivo", ["alt1-" + text, "alt2-" + text]]], q.get("sl", ["ja"])[0]]
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body, ensure_ascii=False))
            if "bd" in q.get("dt", []) and q.get("sl", [""])[0] == "it":
                # traduzione inversa di una parola (dalla traduzione all'originale): la simulata rovescia le lettere
                log.setdefault("wordback", []).append(text)
                body = [[[tr(text), text]], [["sostantivo", [tr(text)]]], "it"]
            elif "bd" in q.get("dt", []):
                body = [[["pane", text]], [["sostantivo", ["pane", "pagnotta"]]], "en"]
                if "md" in q.get("dt", []): body = gdict_body(text, "pane", "en")
            elif q.get("sl", [""])[0] == "it":
                # scritte dell'interfaccia (dall'italiano): «UI-en<testo>», così si riconoscono
                log.setdefault("uitr", []).extend(text.split("\n"))
                body = [[["\n".join("UI-" + q.get("tl", ["?"])[0] + "<" + l + ">" for l in text.split("\n")), text]], None, "it"]
            else:
                # i nomi Google li lascia uguali; le risposte brevi le traduce
                SHORT = {"ja.": "Sì.", "nej!": "No!", "tak.": "Grazie.", "karen.": "Karen.", "okay.": "Okay."}
                log.setdefault("gtexts", []).extend(text.split("\n"))
                body = [[["\n".join(SHORT.get(l.lower(), "IT[" + tr(l) + "]") for l in text.split("\n")), text]], None, "en"]
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
        # Speaches finto (Whisper sul computer, in Docker): conosce solo i suoi nomi di modello; poi risponde come Groq
        if url.startswith("http://localhost:8000/v1/"):
            log.setdefault("speaches", []).append(url.split("8000")[1])
            if url.endswith("/models"):
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"data": [{"id": "speaches-ai/Kokoro-82M-v1.0-ONNX"}, {"id": "Systran/faster-whisper-small"}, {"id": "deepdml/faster-whisper-large-v3-turbo-ct2"}]}))
            if "/audio/transcriptions" in url:
                if not re.search(rb'name="model"\r\n\r\n(deepdml/faster-whisper-large-v3-turbo-ct2|Systran/faster-whisper-small)\r\n', request.post_data_buffer or b""):
                    log.setdefault("speaches_404", []).append(1)
                    return await route.fulfill(status=404, content_type="application/json", body=json.dumps({"detail": "Model 'whisper-large-v3-turbo' is not installed locally. You can download the model using `POST /v1/models`"}))
                url = "https://api.groq.com/openai/v1/audio/transcriptions"
        if url.startswith("https://api.groq.com/openai/v1/audio/transcriptions"):
            if os.environ.get("GROQ_LIMIT") and len(log["groq"]) >= 2:
                # quota di Groq finita: "hour" = audio dell'ultima ora (ASH), "day" = audio del giorno (ASD)
                log["glimit"] = log.get("glimit", 0) + 1
                if os.environ["GROQ_LIMIT"] == "credit":
                    return await route.fulfill(status=402, content_type="application/json",
                        body=json.dumps({"error": {"message": "Your organization has insufficient credit balance. Please add credits.", "code": "insufficient_quota"}}))
                what = "audio seconds per day (ASD): Limit 28800" if os.environ["GROQ_LIMIT"] == "day" else "audio seconds per hour (ASH): Limit 7200"
                return await route.fulfill(status=429, content_type="application/json", headers={"retry-after": "130"},
                    body=json.dumps({"error": {"message": f"Rate limit reached for model `whisper-large-v3-turbo` on {what}, Used 7190, Requested 12. Please try again in 2m10s.", "type": "audio_seconds", "code": "rate_limit_exceeded"}}))
            if os.environ.get("GROQ_429") and len(log["groq"]) == 2 and not log.get("g429"):
                log["g429"] = True
                return await route.fulfill(status=429, content_type="application/json", headers={"retry-after": "3"}, body='{"error":{"message":"Rate limit reached"}}')
            raw = request.post_data_buffer or b""
            ctype = (await request.all_headers()).get("content-type", "")
            boundary = ctype.split("boundary=")[-1].encode()
            pm = re.search(rb'name="prompt"\r\n\r\n', raw)
            if pm:   # come Groq: il suggerimento al massimo 896 (byte)
                pl = len(raw[pm.end(): raw.index(b"\r\n--" + boundary, pm.end())])
                log.setdefault("groq_prompt", []).append(pl)
                if pl > 896:
                    return await route.fulfill(status=400, content_type="application/json", body=json.dumps({"error": {"message": f"prompt length must be 896 characters or fewer, but provided prompt contains {pl} characters", "type": "invalid_request_error"}}))
            fm = re.search(rb'name="file"; filename="([^"]+)"\r\n[^\r]*\r\n\r\n', raw)
            fdata = raw[fm.end(): raw.index(b"\r\n--" + boundary, fm.end())] if fm else b""
            if fdata[:4] == b"RIFF":
                secs = (len(fdata) - 44) / int.from_bytes(fdata[28:32], "little")
            else:
                secs = 66.7
            log.setdefault("groq_files", []).append((fm.group(1).decode() if fm else "?", len(fdata)))
            lang_forced = re.search(rb'name="language"\r\n\r\n([a-z]+)', raw)
            lang_forced = lang_forced.group(1).decode() if lang_forced else ""
            n = len(log["groq"]) + 1
            log["groq"].append(round(secs, 2))
            log.setdefault("groq_lang", []).append(lang_forced)
            mm = re.search(rb'name="model"\r\n\r\n([^\r]+)', raw)
            log.setdefault("groq_model", []).append(mm.group(1).decode() if mm else "")
            if os.environ.get("GROQ_HANG_AT") and n == int(os.environ["GROQ_HANG_AT"]):
                # richiesta che resta appesa (rete cambiata, scheda in sottofondo): nessuna risposta per 10 minuti
                log.setdefault("groq_hung", []).append(n)
                await asyncio.sleep(600)
                try: return await route.abort()
                except Exception: return
            italian = os.environ.get("LANG_FLIP") and n == 2 and not lang_forced
            if os.environ.get("RU_TRANSLATE"):
                # video russo: senza lingua imposta Whisper dal 2° pezzo "traduce" in inglese; il pezzo 3 resta in inglese
                # anche con la lingua imposta, finché non si usa il modello migliore
                import hashlib
                hkey = hashlib.md5(fdata).hexdigest()
                order = log.setdefault("audio_order", [])
                if hkey not in order: order.append(hkey)
                k = order.index(hkey) + 1
                mm = re.search(rb'name="model"\r\n\r\n([\w.-]+)', raw)
                model = mm.group(1).decode() if mm else ""
                pm = re.search(rb'name="prompt"\r\n\r\n([^\r]*)', raw)
                prompt = pm.group(1).decode("utf-8", "ignore") if pm else ""
                eng = (not lang_forced and k >= 2) or (lang_forced == "ru" and k == 3 and model != "whisper-large-v3")
                txt = f" this is the english translation of sentence number {k} of the video" if eng else f" это русская фраза номер {k} из видео"
                log.setdefault("ru_req", []).append((k, lang_forced or "auto", model, "EN" if eng else "RU", prompt[:30]))
                segs = [{"start": 0.1, "end": max(0.5, secs - 0.1), "text": txt, "no_speech_prob": 0.02, "avg_logprob": -0.3}]
                await asyncio.sleep(0.2)
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"language": "english" if eng else "russian", "segments": segs}))
            if os.environ.get("GROQ_LANG"):
                # Whisper simulato: il video passa dall'inglese all'italiano dal pezzo LANG_SWITCH_AT;
                # il pezzo MISDETECT viene riconosciuto (male) come italiano; il pezzo JUNK_AT è musica.
                import hashlib
                hkey = hashlib.md5(fdata).hexdigest()
                order = log.setdefault("audio_order", [])
                if hkey not in order: order.append(hkey)
                k = order.index(hkey) + 1
                true_lang = "it" if k >= int(os.environ.get("LANG_SWITCH_AT", "99")) else "en"
                text_for = lambda l: (f" questa è la frase italiana numero {k} del video" if l == "it" else f" this is english sentence number {k} of the video")
                if str(k) == os.environ.get("JUNK_AT"):
                    segs = [{"start": 0.3, "end": min(secs, 2.0), "text": " I'm sorry.", "no_speech_prob": 0.45, "avg_logprob": -0.7, "compression_ratio": 1.1}]
                    lang_out = "english"
                elif lang_forced:
                    good = lang_forced == true_lang
                    txt = text_for(lang_forced) if good else (" traduzione forzata numero " + str(k) if lang_forced == "it" else
                          " toto je česká věta číslo %d z videa" % k if lang_forced == "cs" else " forced translation number " + str(k))
                    if lang_forced == "cs": good = True
                    segs = [{"start": 0.1, "end": max(0.5, secs - 0.1), "text": txt, "no_speech_prob": 0.02, "avg_logprob": -0.2 if good else -0.9}]
                    lang_out = {"it": "italian", "en": "english", "cs": "czech"}.get(lang_forced, lang_forced)
                else:
                    det = "it" if str(k) == os.environ.get("MISDETECT") else true_lang
                    good = det == true_lang
                    txt = text_for(det) if good else " traduzione sbagliata numero " + str(k)
                    segs = [{"start": 0.1, "end": max(0.5, secs - 0.1), "text": txt, "no_speech_prob": 0.02, "avg_logprob": -0.2 if good else -0.8}]
                    lang_out = {"it": "italian", "en": "english"}[det]
                mm = re.search(rb'name="model"\r\n\r\n([\w.-]+)', raw)
                model = mm.group(1).decode() if mm else ""
                if model == "whisper-large-v3":
                    for x in segs: x["text"] = x["text"].rstrip() + " (preciso)"
                log.setdefault("groq_req", []).append((k, lang_forced or "auto", segs[0]["text"].strip(), model))
                await asyncio.sleep(0.3)
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"language": lang_out, "segments": segs}))
            if os.environ.get("GROQ_LONG"):
                # un solo segmento enorme con più frasi, e i tempi delle parole
                txt = f"Chunk {n} starts here and it keeps going for a while. Then there is a second sentence, which is longer than the first one and has a comma. Ok?"
                ws = txt.replace(".", "").replace(",", "").replace("?", "").split()
                step = max(0.2, (secs - 0.4) / len(ws))
                body = {"language": "english", "segments": [{"start": 0.1, "end": secs - 0.2, "text": " " + txt, "no_speech_prob": 0.02, "avg_logprob": -0.3}],
                        "words": [{"word": w, "start": 0.1 + i * step, "end": 0.1 + i * step + step * 0.8} for i, w in enumerate(ws)]}
                await asyncio.sleep(0.4)
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
            if secs > 20:
                segs = [{"start": k * 6 + 0.2, "end": min(secs, k * 6 + 5.5), "text": f" parte {n} frase {k+1}", "no_speech_prob": 0.02, "avg_logprob": -0.3} for k in range(int(secs // 6))]
                if os.environ.get("GAP") and secs > 120:   # Whisper "salta" un minuto (60-120 s del pezzo)
                    segs = [x for x in segs if not (60 <= x["start"] < 120)]
            else:
                segs = [{"start": 0.1, "end": max(0.5, secs - 0.1), "text": (f" questa frase italiana {n}" if italian else f" frase numero {n}"), "no_speech_prob": 0.02, "avg_logprob": -0.3}]
            body = {"language": "italian" if italian else "english", "segments": segs}
            await asyncio.sleep(0.4)
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
        if url.startswith("https://api.mistral.ai/v1/chat/completions"):
            payload = json.loads(request.post_data or "{}")
            for m_ in payload.get("messages", []): m_["content"] = str(m_.get("content", "")).replace("\n\n/no_think", "")   # interruttore di Qwen 3
            user = payload["messages"][1]["content"]
            log.setdefault("mistral", []).append(1)
            if payload["messages"][0]["content"].startswith("You are an expert phonetician"):
                return await route.fulfill(status=200, content_type="application/json", body=ipa_answer("mistral", user))
            if payload["messages"][0]["content"].startswith("You find idioms"):
                sent = json.loads(user)["sentence"]; log.setdefault("idiomsFind", []).append(sent)
                ids = [{"text": "went to the market", "meaning": "andare a fare la spesa"}] if "went to the market" in sent else []
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": json.dumps({"idioms": ids})}}]}))
            if payload["messages"][0]["content"].startswith("You align"):
                u = json.loads(user)
                its = u.get("items") or []
                content = json.dumps({"items": [{"pairs": [[w, w[::-1]] for w in it["translation"].replace("MIS[", "").replace("]", "").split()], "idioms": []} for it in its]})
            elif "Word:" in user or "Expression:" in user:
                content = json.dumps({"lemma": "", "pos": "", "meaning": "MISDEF", "explanation": "", "example": "", "example_translation": "", "lang": "en"})
            else:
                segs = json.loads(user)["segments"]
                sysmsg = payload["messages"][0]["content"]
                if '"src"' in sysmsg:
                    content = json.dumps({"src": segs, "t": ["MIS[" + tr(x) + "]" for x in segs]})
                else:
                    content = json.dumps({"t": ["MIS[" + tr(x) + "]" for x in segs]})
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": content}}]}))
        # Ollama finto (modello sul computer): risponde come Gemini; OLLAMA_DOWN=1 → non raggiungibile
        if url.startswith("http://localhost:11434/"):
            log.setdefault("ollama", []).append(url.split("11434")[1])
            if os.environ.get("OLLAMA_DOWN"): return await route.abort()
            have = os.environ.get("FAKE_OLLAMA_MODELS", "gemma4:e4b").split(",")
            if url.endswith("/models"): return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"data": [{"id": m} for m in have + ["nomic-embed-text:latest"]]}))
            want = (json.loads(request.post_data or "{}") or {}).get("model", "")
            if "/no_think" in (request.post_data or ""): log.setdefault("ollama_nothink", []).append(want)
            if want not in have:
                log.setdefault("ollama_404", []).append(want)
                return await route.fulfill(status=404, content_type="application/json", body=json.dumps({"error": {"message": f'model "{want}" not found, try pulling it first', "type": "api_error"}}))
        if url.startswith("https://generativelanguage.googleapis.com/") or url.startswith("http://localhost:11434/v1/chat"):
            now = time.time()
            g = log.setdefault("gcalls", [])
            # 1.6.1: un modello solo ha finito le richieste di oggi (le quote di Gemini sono per modello)
            try: gm_ = json.loads(request.post_data or "{}").get("model", "")
            except Exception: gm_ = ""
            log.setdefault("gmodels", []).append(gm_)
            # 1.6.2: un modello che risponde con una spiegazione tagliata (come Flash quando il ragionamento consuma i token)
            if gm_ and gm_ in os.environ.get("GEM_BAD_MODEL", "").split(",") and "language tutor" in (request.post_data or ""):
                log.setdefault("gbad_model", []).append(gm_)
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": '{"lemma": "bread", "meaning": "pa'}, "finish_reason": "length"}]}))
            if gm_ and gm_ in os.environ.get("GEM_DAILY_MODEL", "").split(","):
                log.setdefault("gdaily_model", []).append(gm_)
                return await route.fulfill(status=429, content_type="application/json", body='[{"error":{"code":429,"message":"You exceeded your current quota","status":"RESOURCE_EXHAUSTED","details":[{"@type":"type.googleapis.com/google.rpc.QuotaFailure","violations":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel-FreeTier"}]}]}}]')
            rpm = int(os.environ.get("GEM_RPM", "10")); daily = int(os.environ.get("GEM_DAILY", "100000"))
            ok = [c for c in g if c[1] == 200]
            if len(ok) >= daily:
                g.append((now, "day"))
                return await route.fulfill(status=429, content_type="application/json", body='[{"error":{"code":429,"message":"You exceeded your current quota","status":"RESOURCE_EXHAUSTED","details":[{"@type":"type.googleapis.com/google.rpc.QuotaFailure","violations":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel-FreeTier"}]}]}}]')
            if len([c for c in g if now - c[0] < 60]) >= rpm:
                g.append((now, "min"))
                return await route.fulfill(status=429, content_type="application/json", body='[{"error":{"code":429,"message":"quota","details":[{"quotaId":"GenerateRequestsPerMinutePerProjectPerModel-FreeTier"},{"retryDelay":"10s"}]}}]')
            g.append((now, 200))
            payload = json.loads(request.post_data or "{}")
            for m_ in payload.get("messages", []): m_["content"] = str(m_.get("content", "")).replace("\n\n/no_think", "")   # interruttore di Qwen 3
            user = payload["messages"][1]["content"]
            if payload["messages"][0]["content"].startswith("You are an expert phonetician"):
                a = ipa_answer("gemini", user)
                return await route.fulfill(status=a[0] if isinstance(a, tuple) else 200, content_type="application/json", body=a[1] if isinstance(a, tuple) else a)
            if payload["messages"][0]["content"].startswith("You explain a single"):
                u = json.loads(user); log.setdefault("hanexplain", []).append(u["character"])
                o = {"meaning": "SIGN[" + u["character"] + "]", "readings": "ben (on)", "words": [{"w": "勉強", "r": "benkyō", "t": "studio"}], "parts": "免 + 力", "mnemonic": "sforzo", "origin": "composto fono-semantico", "note": ""}
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": json.dumps(o)}}]}))
            if payload["messages"][0]["content"].startswith("You find idioms"):
                sent = json.loads(user)["sentence"]; log.setdefault("idiomsFind", []).append(sent)
                ids = [{"text": "went to the market", "meaning": "andare a fare la spesa"}] if "went to the market" in sent else []
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": json.dumps({"idioms": ids})}}]}))
            if payload["messages"][0]["content"].startswith("You align"):
                u = json.loads(user)
                its = u.get("items") or [{"original": u.get("original"), "translation": u.get("translation")}]
                log.setdefault("align", []).append(its[0]["original"])
                log.setdefault("align_items", []).append(len(its))
                out_items = []
                for it in its:
                    tw = it["translation"].replace("GEM[", "").replace("MIS[", "").replace("]", "").split()
                    ids = [{"text": "fresh bread", "meaning": "MODO[pane appena fatto]"}] if "fresh bread" in it["original"] else []
                    if "сожалению" in it["original"] and not os.environ.get("NO_ALIGN_IDIOM"): ids = [{"text": "к сожалению", "meaning": "MODO[purtroppo]"}]
                    if os.environ.get("ALIGN_WHOLE"): ids.append({"text": it["original"], "meaning": "TUTTA LA FRASE"})   # errore del modello
                    out_items.append({"pairs": [[w, w[::-1]] for w in tw], "idioms": ids})
                pairs = out_items[0]["pairs"]
                if os.environ.get("ALIGN_GAPS"):   # il modello lascia vuoto l'originale per alcune parole
                    pairs = [[a, "" if k % 2 else b] for k, (a, b) in enumerate(pairs)]
                if os.environ.get("ALIGN_SHIFT"):   # il modello sbaglia di una: ogni parola collegata alla parola dopo
                    pairs = [[a, pairs[k + 1][1] if k + 1 < len(pairs) else b] for k, (a, b) in enumerate(pairs)]
                if os.environ.get("ALIGN_EXTRA"):   # nuovo formato: le parole dispari sono particelle della coppia seguente
                    objs, k = [], 0
                    while k < len(pairs):
                        if k % 2 and k + 1 < len(pairs):
                            objs.append({"t": pairs[k][0] + " " + pairs[k + 1][0], "o": pairs[k + 1][1], "extra": [pairs[k][0]]}); k += 2
                        else:
                            objs.append({"t": pairs[k][0], "o": pairs[k][1], "extra": []}); k += 1
                    pairs = objs
                if os.environ.get("ALIGN_FAIL"):
                    return await route.fulfill(status=500, content_type="application/json", body='{"error":{"message":"errore finto"}}')
                out_items[0]["pairs"] = pairs
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": json.dumps({"items": out_items})}}]}))
            if payload["messages"][0]["content"].startswith("You are an etymologist"):
                w = json.loads(user).get("word", "")
                log.setdefault("etymllm", []).append(w)
                deep = "too terse" in payload["messages"][0]["content"]   # «✨ Spiegala meglio»: con il testo di Wiktionary
                if deep: log.setdefault("etymdeep", []).append(w)
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": json.dumps({"etymology": ("ETIMMEGLIO[" if deep else "ETIMLLM[") + w + "]", "lemma": w})}}]}))
            if user.startswith("Expression:"):
                log.setdefault("expr", []).append(user.split('"')[1])
                content = json.dumps({"lemma": "", "pos": "espressione", "meaning": "ESPR[" + user.split('"')[1] + "]", "explanation": "Spiegazione dell'espressione.", "example": "", "example_translation": "", "lang": "en"})
            elif "Word:" in user and '"сожалению"' in user:
                log.setdefault("define", []).append(("сожалению", False, False))
                n_def = sum(1 for x in log["define"] if x[0] == "сожалению")
                content = json.dumps({"lemma": "сожаление", "pos": "sostantivo", "meaning": "rimpianto", "explanation": "", "example": "", "example_translation": "", "lang": "ru", "expression": "к сожалению", "expression_meaning": "MODO[purtroppo]"})
                if os.environ.get("EXPR_FOREIGN"):   # il modello scrive il «modo di dire» tradotto, non quello della frase
                    content = json.dumps({"lemma": "сожаление", "pos": "sostantivo", "meaning": "rimpianto", "explanation": "", "example": "", "example_translation": "", "lang": "ru", "expression": "in the secret life", "expression_meaning": "nella vita segreta"})
                if os.environ.get("IDIOM_ONCE") and n_def > 1:   # la seconda spiegazione (altro servizio) non riporta il modo di dire
                    content = json.dumps({"lemma": "сожаление", "pos": "sostantivo", "meaning": "rimpianto (2)", "explanation": "", "example": "", "example_translation": "", "lang": "ru", "expression": "", "expression_meaning": ""})
            elif "Word:" in user and '"walked"' in user:
                ow = {"lemma": "walk", "pos": "verbo", "meaning": "camminare", "explanation": "", "example": "", "example_translation": "", "lang": "en", "expression": "walked home", "expression_meaning": "MODO[tornare a piedi]"}
                sysw = payload["messages"][0]["content"]
                log.setdefault("define", []).append(("walked", '"etymology"' in sysw, '"ipa"' in sysw))
                if '"ipa"' in sysw: ow["ipa"] = "wɔːkt"
                content = json.dumps(ow)
            elif "Word:" in user:
                o = {"lemma": "go", "pos": "verbo", "meaning": "andare (al passato)", "explanation": "Passato irregolare di go.", "example": "I went home.", "example_translation": "Sono andato a casa.", "lang": "en"}
                sysm = payload["messages"][0]["content"]
                log.setdefault("define", []).append((user.split('"')[1], '"etymology"' in sysm, '"ipa"' in sysm))
                if '"etymology"' in sysm: o["etymology"] = "ETIM[" + user.split('"')[1] + "]"
                if '"ipa"' in sysm: o["ipa"] = "IPADEF-" + user.split('"')[1]
                if '"sentence_translation"' in sysm: o["sentence_translation"] = "FRASE-GEM[" + tr(user.split('Sentence: "')[1].split('"')[0]) + "]"
                if os.environ.get("ALIGN_WHOLE"): o["false_friend"] = "false"
                if '"false_friend"' in sysm:
                    o["false_friend"] = "FALSO[" + user.split('"')[1] + "]"; o["related"] = "PARENTI[" + user.split('"')[1] + "]"
                    o["spelling"] = {"score": 100, "correct": "", "note": ""} if user.split('"')[1] != "walkd" else {"score": 40, "correct": "walked", "note": "manca la e"}
                # risposte sbagliate del modello: spiegazione in inglese, falso amico con una parola inglese o "non è un falso amico"
                dbad = os.environ.get("DEF_BAD", "")
                if dbad:
                    strict = "IMPORTANT:" in sysm
                    log.setdefault("def_strict", []).append(strict)
                    o["explanation"] = "This is the past tense of the verb go, used for completed actions in the past." if not (strict and dbad == "en_once") else "È il passato del verbo go, per le azioni finite."
                    o["false_friend"] = {"ff_en": "Attenzione: assomiglia a embarrassed in inglese, ma significa incinta", "ff_neg": "non è un alfabeto italiano o un'espressione simile, ma è una parola russa con un significato specifico",
                                         "ff_ok": "Attenzione: non significa imbarazzata, ma incinta"}.get(os.environ.get("DEF_FF", ""), o.get("false_friend", ""))
                log.setdefault("define_extra", []).append('"false_friend"' in sysm)
                content = json.dumps(o)
            else:
                if os.environ.get("GEM_429") and not log.get("gem429"):
                    log["gem429"] = True
                    return await route.fulfill(status=429, content_type="application/json", body='{"error":{"code":429,"message":"quota","details":[{"retryDelay":"4s"}]}}')
                segs = json.loads(user)["segments"]
                log["gemini"].append(len(segs))
                await asyncio.sleep(float(os.environ.get("GEM_DELAY", "2.5")))   # Gemini lento
                content = json.dumps({"t": ["GEM[" + tr(s) + "]" for s in segs]})
                if os.environ.get("GEM_VERSIONED") and len(segs) == 1:
                    log["gver"] = log.get("gver", 0) + 1
                    content = json.dumps({"t": [f"GEM{log['gver']}[" + tr(segs[0]) + "]"]})
                mode = os.environ.get("GEM_MODE", "")
                sysmsg = payload["messages"][0]["content"]
                if '"src"' in sysmsg:
                    # traduzione con pulizia: originale corretto + traduzione; le frasi inventate diventano vuote
                    junk = os.environ.get("GEM_JUNK", "thanks for watching")
                    fix = lambda x: "" if junk in x.lower() else (x[:1].upper() + x[1:]).rstrip(".") + "."
                    src = [fix(x) for x in segs]
                    content = json.dumps({"src": src, "t": ["" if not x else "GEM[" + tr(x) + "]" for x in src]})
                if mode == "english": content = json.dumps({"t": ["the thing is that we are here and it is good " + str(k) for k, _ in enumerate(segs)]})
                if mode == "echo": content = json.dumps({"t": segs})
                if mode == "arabic": content = json.dumps({"t": ["هذه هي الجملة رقم " + str(k + 1) + " من الفيديو" for k, _ in enumerate(segs)]})   # la "traduzione" arriva in arabo
                if mode == "shortcopy": content = json.dumps({"t": [x if len(x.split()) <= 2 else "GEM[" + tr(x) + "]" for x in segs]})
                if '"idioms" array' in sysmsg and os.environ.get("TR_IDIOMS"):
                    # 1.6.0: i modi di dire nella stessa richiesta della traduzione
                    log.setdefault("tr_idioms_asked", []).append(len(segs))
                    try:
                        o_ = json.loads(content); o_["idioms"] = [{"i": k, "text": "fresh bread", "m": "pane appena fatto"} for k, x in enumerate(segs) if "fresh bread" in x]
                        content = json.dumps(o_)
                    except Exception: pass
                log.setdefault("gemsegs", []).append(list(segs))
                if mode == "echocomma": content = json.dumps({"t": [x.replace(" ", ", ", 1) for x in segs]})
                if mode == "shift" and len(segs) > 1:
                    # il modello mette tutto sotto la prima frase e lascia vuote le altre
                    content = json.dumps({"t": ["GEM[" + tr(" ".join(segs)) + "]"] + [""] * (len(segs) - 1)})
                if mode == "numbered": content = json.dumps({"t": [f"{k+1}. GEM[{tr(s)}]" for k, s in enumerate(segs)]})
                if mode == "bad" and not log.get("gbad"):
                    log["gbad"] = True
                    content = "Mi dispiace, non posso aiutarti con questo."
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": content}}]}))
        if url.startswith("https://api.groq.com/openai/v1/chat/completions"):
            payload = json.loads(request.post_data or "{}")
            if payload["messages"][0]["content"].startswith("You are an expert phonetician"):
                a = ipa_answer("groq", payload["messages"][1]["content"])
                return await route.fulfill(status=a[0] if isinstance(a, tuple) else 200, content_type="application/json", body=a[1] if isinstance(a, tuple) else a)
            # 1.6.1: traduzione con Groq (servizio di riserva)
            try: segs_ = json.loads(payload["messages"][1]["content"]).get("segments")
            except Exception: segs_ = None
            if segs_:
                log.setdefault("groqtr", []).append(len(segs_))
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": json.dumps({"t": ["GROQ[" + x + "]" for x in segs_]})}}]}))
            return await route.fulfill(status=404, body="")
        return await route.fulfill(status=404, body="")
    except Exception as e:
        log["errors"].append(f"{url}: {e}")
        return await route.fulfill(status=500, body=str(e))

async def launch(p, user_dir="", env=None):
    ctx = await p.chromium.launch_persistent_context(user_dir, channel="chromium", headless=True, env=env,
        args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}", "--autoplay-policy=no-user-gesture-required"])
    await ctx.route("**/*", handle)
    sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
    # la prima richiesta del sottofondo sfugge al simulatore: la faccio a vuoto
    try: await sw.evaluate("fetch('https://example.test/riscaldamento').catch(()=>0)")
    except Exception: pass
    return ctx, sw


# «✨ Spiega con …» nella scheda della parola (dalla 1.4.1 il modello parte solo da questo pulsante)
async def spiega(pg, wait=0):
    b = pg.locator(".dualsub-card .dualsub-explainbtn")
    for _ in range(20):
        if await b.count(): break
        await pg.wait_for_timeout(250)
    if await b.count(): await b.first.click()
    if wait: await pg.wait_for_timeout(wait)

# Prove della 1.2: sottotitoli del film di prima, menu dei sottotitoli del lettore, tracce dentro il video
import sys, os, json, time, shutil, subprocess, urllib.parse, importlib
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
from resources.lib import core
calls = []
tr = lambda x: " ".join(w[::-1] for w in x.split())
def fake_http(url, data=None, headers=None, timeout=90):
    calls.append(url.split("?")[0])
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + tr(l) + "]" for l in q.split("\n")), q]], None, "en"]).encode(), {}
    if url.startswith("https://subs.addon-video.example/"):
        return 200, srt(["god morgen alle sammen", "hvor er toget", "vi kommer for sent"]).encode("utf-8"), {}
    if url.startswith("https://v3-cinemeta.strem.io/catalog/movie/top/search="):
        calls.append("cinemeta:" + urllib.parse.unquote(url.split("search=")[1]))
        return 200, json.dumps({"metas": [{"imdb_id": "tt9999999", "name": "The Burbs remake", "releaseInfo": "2026"},
                                          {"imdb_id": "tt0096734", "name": "The 'Burbs", "releaseInfo": "1989"}]}).encode(), {}
    if url.startswith("https://opensubtitles-v3.strem.io/subtitles/"):
        calls.append("os:" + url.split("/subtitles/")[1])
        subs = [{"id": str(i), "url": "https://dl.opensubtitles.example/%d.srt" % i, "lang": l} for i, l in enumerate(["eng", "ita", "eng", "eng", "eng", "spa"])]
        return 200, json.dumps({"subtitles": subs}).encode(), {}
    if url.startswith("https://dl.opensubtitles.example/"):
        n = url.rsplit("/", 1)[1].split(".")[0]
        if n == "1":   # nell'elenco il n. 1 è quello italiano
            return 200, srt(["ciao vicino", "cosa c'è in cantina", "niente di buono"]).encode(), {}
        return 200, srt(["hello neighbour version %s" % n, "what is in the basement", "nothing good"]).encode(), {}
    if "generativelanguage" in url:
        segs = json.loads(json.loads(data)["messages"][1]["content"])["segments"]
        return 200, json.dumps({"choices": [{"message": {"content": json.dumps({"t": ["GEM[" + tr(s) + "]" for s in segs]})}}]}).encode(), {}
    return 404, b"", {}
core.http = fake_http
from resources.lib import runner, subtitles
core.ENGINES["gemini"]["gap"] = 0

def srt(lines, start=0):  # noqa
    return "\n".join("%d\n00:00:%02d,000 --> 00:00:%02d,500\n%s\n" % (i + 1, start + i * 4, start + i * 4 + 3, l) for i, l in enumerate(lines))

for d in ("/tmp/kodi-temp", "/tmp/kodi-profile", "/tmp/kodi-film3"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles"); os.makedirs("/tmp/kodi-film3")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra", "trans_color": "FFFF00", "auto": "true", "human": "false"})

# ---------- 1. film in streaming: nella cartella temporanea c'è ancora il sottotitolo inglese del film di prima
old = "/tmp/kodi-temp/subtitles/Vecchio.Film.2019.English.srt"
open(old, "w").write(srt(["sottotitolo del film di prima"] * 3))
os.utime(old, (time.time() - 3 * 3600, time.time() - 3 * 3600))
new = "/tmp/kodi-temp/subtitles/Nuovo.Film.2024.Czech.srt"
open(new, "w").write(srt(["dobrý den jak se máte", "dnes je krásný den", "půjdeme spolu domů"]))
xbmc.Player.playing_file = "https://server.example/stream/abc123"
xbmc.Player.time = 900.0
xbmc.Player.sub_lang = "cze"
runner.mark_start(xbmc.Player()); xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": xbmc.Player.playing_file, "at": time.time() - 900})
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read()
print("1. streaming, film di prima nella cartella temporanea → usa il ceco appena scaricato:", "dobrý den" in t, "| quello vecchio:", "film di prima" in t)
print("   lingua riconosciuta dal nome:", core.lang_from_filename(new))

# ---------- 2. solo il vecchio file: non deve usarlo
os.remove(new)
xbmc.Player.subs.clear(); xbmcgui.NOTES.clear()
runner.run(xbmc.Player(), interactive=True)
print("2. c'è solo il file del film di prima: caricato qualcosa:", bool(xbmc.Player.subs), "| avviso:", (xbmcgui.NOTES[-1:] or [""])[0][:70])

# ---------- 3. menu dei sottotitoli del lettore: elenco
open(new, "w").write(srt(["dobrý den jak se máte", "dnes je krásný den", "půjdeme spolu domů"]))
xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://script.sottotitolidoppi/", "7", "?action=search&languages=Italian,English&preferredlanguage=Italian"])
print("3. menu Sottotitoli → Scarica → Sottotitoli Doppi:", [(li.label, li.label2) for u, li in xbmcplugin.ITEMS], "| chiuso:", xbmcplugin.ENDED[-1:] == [7])

# ---------- 4. scelta (Google): file doppio completo subito
url = xbmcplugin.ITEMS[0][0]; xbmcplugin.ITEMS.clear(); calls.clear()
q = urllib.parse.urlparse(url).query
t0 = time.time()
subtitles.main(["plugin://script.sottotitolidoppi/", "8", "?" + q])
path = xbmcplugin.ITEMS[0][0]
t = open(path, encoding="utf-8").read()
print("4. file restituito al lettore:", os.path.basename(path), "| righe tradotte:", t.count("IT["), "| richieste Google:", calls.count("https://translate.googleapis.com/translate_a/single"),
      "| %.1f s" % (time.time() - t0), "| altre traduzioni avviate:", xbmc.BUILTINS)

# ---------- 5. con Gemini: subito la versione Google, Gemini in sottofondo
xbmcaddon.SETTINGS.update({"engine": "gemini (gratis con chiave, consigliato)", "gemini_key": "AIza-test", "gemini_model": "gemini-flash-lite-latest"})
xbmcplugin.ITEMS.clear(); xbmc.BUILTINS.clear(); xbmcgui.NOTES.clear(); calls.clear()
subtitles.main(["plugin://script.sottotitolidoppi/", "9", "?" + q])
t = open(xbmcplugin.ITEMS[0][0], encoding="utf-8").read()
print("5. con Gemini: subito Google:", t.count("IT["), "righe | Gemini chiamato adesso:", any("generativelanguage" in c for c in calls), "| avviato:", xbmc.BUILTINS[-1][:52] if xbmc.BUILTINS else None)
print("   avviso:", xbmcgui.NOTES[-1:])
# il RunScript esegue default.py con "upgrade"
arg = xbmc.BUILTINS[-1].split(",")[-1].rstrip(")")
xbmc.Player.subs.clear(); calls.clear()
sys.argv = ["default.py", "upgrade", arg]
import importlib.util
spec = importlib.util.spec_from_file_location("default_upg", "/home/claude/kodi/script.sottotitolidoppi/default.py"); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read()
print("   in sottofondo: righe di Gemini", t.count("GEM["), "| sottotitoli cambiati", len(xbmc.Player.subs), "volta | avviso:", xbmcgui.NOTES[-1])
xbmcplugin.ITEMS.clear(); xbmc.BUILTINS.clear(); calls.clear()
subtitles.main(["plugin://script.sottotitolidoppi/", "10", "?" + q])
t = open(xbmcplugin.ITEMS[0][0], encoding="utf-8").read()
print("   di nuovo dal menu: versione Gemini già pronta:", t.count("GEM["), "| richieste:", len(calls), "| sottofondo:", xbmc.BUILTINS)

# ---------- 6. traccia di sottotitoli dentro il video (mkv), senza file esterni
xbmcaddon.SETTINGS.update({"engine": "google (gratis, senza chiave)"})
open("/tmp/kodi-film3/dentro.srt", "w").write(srt(["hej hvordan har du det", "vi ses i morgen tidlig", "det var en god dag"]))
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-t", "15", "-i", "anullsrc=r=16000:cl=mono", "-i", "/tmp/kodi-film3/dentro.srt",
                "-map", "0", "-map", "1", "-c:a", "aac", "-c:s", "srt", "-metadata:s:s:0", "language=nor", "/tmp/kodi-film3/Film Norvegese.mkv"], check=True)
os.remove("/tmp/kodi-film3/dentro.srt")
for f in os.listdir("/tmp/kodi-temp/subtitles"): os.remove(os.path.join("/tmp/kodi-temp/subtitles", f))
xbmc.Player.playing_file = "/tmp/kodi-film3/Film Norvegese.mkv"; xbmc.Player.sub_lang = "nor"; xbmc.Player.time = 5
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": xbmc.Player.playing_file, "at": time.time() - 5})
xbmc.Player.subs.clear()
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
print("6. traccia incorporata (norvegese):", "hej hvordan" in t, "| tradotta:", t.count("IT["), "righe")
xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://script.sottotitolidoppi/", "11", "?action=search&languages=Italian"])
print("   nel menu del lettore:", [li.label2 for u, li in xbmcplugin.ITEMS])
print("avvisi:", xbmcgui.NOTES[-3:])

# ---------- 7. film da un add-on video in streaming: sottotitoli passati al lettore come indirizzo internet
shutil.rmtree("/tmp/kodi-userdata", ignore_errors=True)
xbmc.Player.playing_file = "https://cdn.addon-video.example/play/xyz.mkv?token=1"
xbmc.Player.item_props = {"subtitle:1": "https://subs.addon-video.example/film.nor.srt"}
xbmc.Player.sub_lang = "nor"; xbmc.Player.time = 60
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": xbmc.Player.playing_file, "at": time.time() - 60})
xbmc.Player.subs.clear(); xbmcgui.NOTES.clear()
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
print("7. add-on video, sottotitoli dall'indirizzo dato al lettore:", "god morgen" in t, "| tradotte:", t.count("IT["), "| avvisi:", xbmcgui.NOTES[-1:])

# ---------- 8. add-on video che salva i sottotitoli nella sua cartella (nessuna proprietà)
xbmc.Player.item_props = {}
os.makedirs("/tmp/kodi-userdata/addon_data/plugin.video.esempio/temp/subs", exist_ok=True)
open("/tmp/kodi-userdata/addon_data/plugin.video.esempio/temp/subs/film.srt", "w").write(srt(["ahoj jak se máš", "mám se dobře", "díky moc"]))
old2 = "/tmp/kodi-userdata/addon_data/plugin.video.esempio/temp/subs/vecchio.srt"
open(old2, "w").write(srt(["film di ieri"] * 3)); os.utime(old2, (time.time() - 5 * 3600, time.time() - 5 * 3600))
xbmc.Player.playing_file = "https://cdn.addon-video.example/play/altro.mkv"
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": xbmc.Player.playing_file, "at": time.time() - 30})
xbmc.Player.subs.clear()
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
print("8. sottotitoli nella cartella dell'add-on video:", "ahoj jak" in t, "| quello di ieri:", "film di ieri" in t)

# ---------- 9. copia del file doppio salvata da Kodi senza lingua nel nome: non diventa l'originale
dual = open(xbmc.Player.subs[-1], encoding="utf-8").read()
os.remove("/tmp/kodi-userdata/addon_data/plugin.video.esempio/temp/subs/film.srt")
open("/tmp/kodi-temp/TempSubtitle.srt", "w").write(dual)
xbmc.Player.subs.clear(); xbmcgui.NOTES.clear()
for f in os.listdir(runner.CACHE):
    if f.endswith(".json"): os.remove(os.path.join(runner.CACHE, f))
runner.run(xbmc.Player(), interactive=True)
print("9. copia del file doppio ignorata:", not xbmc.Player.subs, "| avviso:", (xbmcgui.NOTES[-1:] or [""])[0][:60])
os.remove("/tmp/kodi-temp/TempSubtitle.srt")

# ---------- 10. il menu del lettore arriva dal nuovo add-on service.subtitles.sottotitolidoppi
xbmc.Player.item_props = {"subtitle:1": "https://subs.addon-video.example/film.nor.srt"}
xbmcplugin.ITEMS.clear()
sys.argv = ["plugin://service.subtitles.sottotitolidoppi/", "12", "?action=search&languages=Italian"]
spec = importlib.util.spec_from_file_location("svc", "/home/claude/kodi/service.subtitles.sottotitolidoppi/service_subtitles.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
print("10. menu del lettore (add-on di sottotitoli):", [(u.split("?")[0], li.label2) for u, li in xbmcplugin.ITEMS])
u = xbmcplugin.ITEMS[0][0]; xbmcplugin.ITEMS.clear()
sys.argv = ["plugin://service.subtitles.sottotitolidoppi/", "13", "?" + u.split("?", 1)[1]]
spec.loader.exec_module(importlib.util.module_from_spec(spec))
t = open(xbmcplugin.ITEMS[0][0], encoding="utf-8").read()
print("    scelto → file doppio:", t.count("IT["), "righe tradotte")

# ---------- 11. film in streaming (The Crew + Real-Debrid) con i sottotitoli dentro il video: li prendo da OpenSubtitles
xbmc.Player.item_props = {}
for d in ("/tmp/kodi-userdata", "/tmp/kodi-temp"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles")
xbmc.Player.playing_file = "https://45-4.download.real-debrid.com/d/PRPJ/The.Burbs.1989.2160p.UHD.Blu-ray.Remux.DV.HDR.HEVC.FLAC.2.0-CiNEPHiLES.mkv"
xbmc.Player.sub_lang = "eng"; xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.AudioLanguage": "eng", "VideoPlayer.Title": "The.Burbs.1989.2160p.UHD.Blu-ray.Remux.DV.HDR.HEVC.FLAC.2.0-CiNEPHiLES.mkv"})
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": xbmc.Player.playing_file, "at": time.time() - 20})
xbmc.Player.subs.clear(); xbmcgui.NOTES.clear(); calls.clear()
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
print("11. streaming con sottotitoli dentro il video:", [c for c in calls if c.startswith(("cinemeta", "os:"))], "| tradotto:", "hello neighbour version 0" in t, t.count("IT["))
print("    avviso:", xbmcgui.NOTES[-2:-1])
xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "14", "?action=search&languages=Italian"])
print("    nel menu del lettore:", [li.label2 for u, li in xbmcplugin.ITEMS])
u = xbmcplugin.ITEMS[1][0]; xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "15", "?" + u.split("?", 1)[1]])
print("    scelgo la versione 2:", "version 2" in open(xbmcplugin.ITEMS[0][0], encoding="utf-8").read())
# con il codice IMDb dato dall'add-on video non serve cercare il titolo
xbmc.INFO["VideoPlayer.IMDBNumber"] = "tt0096734"; calls.clear(); xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "16", "?action=search"])
print("    con il codice IMDb:", [c for c in calls if c.startswith(("cinemeta", "os:"))])
# film parlato in italiano: niente sottotitoli da OpenSubtitles
xbmc.INFO["VideoPlayer.AudioLanguage"] = "ita"; xbmc.Player.sub_lang = ""; xbmc.Player.subs.clear(); calls.clear()
for f in os.listdir(runner.CACHE):
    if f.endswith(".json"): os.remove(os.path.join(runner.CACHE, f))
runner.run(xbmc.Player(), interactive=False)
print("12. film già in italiano: nessuna richiesta a OpenSubtitles:", not any(c.startswith("os:") for c in calls), "| sottotitoli caricati:", len(xbmc.Player.subs))

# ---------- 13. (1.4.1) OpenSubtitles di Stremio rifiuta la richiesta: uso il servizio OpenSubtitles.com installato in Kodi
xbmcaddon.SETTINGS["use_services"] = "true"   # dalla 1.10.9 solo se permesso (consuma la quota dell'account)
print("    nome del programma nelle richieste:", core.UA[:11], "…")
xbmc.INFO["VideoPlayer.AudioLanguage"] = "eng"; xbmc.Player.sub_lang = "eng"
os.makedirs("/tmp/kodi-svc", exist_ok=True)
open("/tmp/kodi-svc/Get.Out.2017.en.srt", "w").write(srt(["just someone from the service", "get out", "now"]))
def rpc(req):
    m, p = req["method"], req["params"]
    if m == "Addons.GetAddons":
        return {"result": {"addons": [{"addonid": "service.subtitles.sottotitolidoppi", "name": "Sottotitoli Doppi"},
                                      {"addonid": "service.subtitles.opensubtitles-com", "name": "OpenSubtitles.com"}]}}
    if m == "Files.GetDirectory" and "action=search" in p["directory"]:
        assert "languages=English" in p["directory"], p["directory"]
        return {"result": {"files": [{"label": "English", "file": "plugin://service.subtitles.opensubtitles-com/?action=download&file_id=1"},
                                     {"label": "Italian", "file": "plugin://service.subtitles.opensubtitles-com/?action=download&file_id=2"}]}}
    if m == "Files.GetDirectory" and "action=download" in p["directory"]:
        return {"result": {"files": [{"label": "x", "file": "/tmp/kodi-svc/Get.Out.2017.en.srt"}]}}
    return {"error": "?"}
xbmc.RPC_HANDLER = rpc
real_http = core.http
def blocked_http(url, data=None, headers=None, timeout=90):
    if url.startswith("https://opensubtitles-v3.strem.io/"):
        calls.append("os-403"); return 403, b"<html>Cloudflare: access denied</html>", {}
    return fake_http(url, data, headers, timeout)
core.http = blocked_http
xbmc.Player.playing_file = "https://22-4.download.real-debrid.com/d/LRX/Get.Out.2017.UHD.BluRay.1080p.DDP.5.1.HDR10.x265-SM737.mkv"
xbmc.INFO["VideoPlayer.IMDBNumber"] = "tt5052448"
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": xbmc.Player.playing_file, "at": time.time() - 20})
xbmc.Player.subs.clear(); xbmcgui.NOTES.clear(); calls.clear(); xbmc.LOG.clear()
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
print("13. OpenSubtitles di Stremio rifiuta (403) → servizio di Kodi:", "just someone from the service" in t, t.count("IT["), "| tentativi:", calls.count("os-403"))
print("    registro:", [l for l in xbmc.LOG if "OpenSubtitles" in l or "servizio" in l][:2])
print("    avviso:", [n for n in xbmcgui.NOTES if "presi da" in str(n)][:1])
xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "17", "?action=search&languages=Italian"])
print("    nel menu del lettore:", [li.label2 for u, li in xbmcplugin.ITEMS])
core.http = real_http; xbmc.RPC_HANDLER = None


# ---------- 14. (1.5) traduzione già fatta: i sottotitoli italiani dello stesso film, messi in fase con l'originale
def srt_t(rows):
    def f(ms): return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)
    return "\n".join("%d\n%s --> %s\n%s\n" % (i + 1, f(a), f(b), t) for i, (a, b, t) in enumerate(rows))
EN = ["where are you going", "to the station", "the train leaves at six", "we are late again", "run faster please",
      "I can see the platform", "it is already moving", "jump now", "we made it", "barely", "next time we leave early",
      "you always say that", "this time I mean it", "sure you do", "look at the view", "it is beautiful", "I told you",
      "the mountains are white", "it snowed last night", "let us sit down", "I am tired", "me too"]
IT = ["dove stai andando", "alla stazione", "il treno parte alle sei", "siamo di nuovo in ritardo", "corri più veloce per favore",
      "vedo il binario", "si sta già muovendo", "salta adesso", "ce l'abbiamo fatta", "per un pelo", "la prossima volta partiamo presto",
      "lo dici sempre", "questa volta dico sul serio", "certo come no", "guarda il panorama", "è bellissimo", "te l'avevo detto",
      "le montagne sono bianche", "stanotte ha nevicato", "sediamoci", "sono stanco", "anch'io"]
import random as _r
_r.seed(5)
rows_en, t0 = [], 3000
for x in EN:
    d = _r.randint(1500, 3500); rows_en.append((t0, t0 + d, x)); t0 += d + _r.randint(300, 2500)
# edizione italiana a 25 fotogrammi al secondo, 4,2 s di ritardo, due frasi unite in una
sc, off = 25 / 23.976, 4200
rows_it = []
for i, (a, b, _) in enumerate(rows_en):
    if i == 9: continue
    if i == 8: rows_it.append((int(a * sc + off), int(rows_en[9][1] * sc + off), IT[8] + " - " + IT[9])); continue
    rows_it.append((int(a * sc + off) + _r.randint(-120, 120), int(b * sc + off) + _r.randint(-120, 120), IT[i]))
rows_it[12] = (rows_it[12][0], rows_it[12][1], rows_it[12][2])
shutil.rmtree("/tmp/kodi-film14", ignore_errors=True); os.makedirs("/tmp/kodi-film14")
open("/tmp/kodi-film14/Treno.2020.en.srt", "w").write(srt_t(rows_en))
open("/tmp/kodi-film14/Treno.2020.it.srt", "w").write(srt_t(rows_it))
xbmc.Player.playing_file = "/tmp/kodi-film14/Treno.2020.mkv"; open(xbmc.Player.playing_file, "w").write("x")
xbmc.INFO.clear(); xbmc.Player.item_props = {}; xbmc.Player.sub_lang = "eng"
xbmcaddon.SETTINGS.update({"human": "true", "engine": "gemini (gratis con chiave, consigliato)", "gemini_key": "AIza-test"})
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": xbmc.Player.playing_file, "at": time.time() - 20})
xbmc.Player.subs.clear(); xbmcgui.NOTES.clear(); calls.clear(); xbmc.LOG.clear()
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
blocks = [b for b in t.split("\n\n") if b.strip()]
good = sum(1 for i, b in enumerate(blocks) if EN[i] in b and (IT[i] in b))
print("14. traduzione già pronta (italiano a 25 fps, 4,2 s di ritardo):", good, "/", len(EN), "frasi giuste | richieste a Gemini:",
      sum(1 for c in calls if "generativelanguage" in c), "| Google:", sum(1 for c in calls if "translate.googleapis" in c))
print("    registro:", [l for l in xbmc.LOG if "già pronta" in l][:1])
print("    avviso:", [n for n in xbmcgui.NOTES if "già fatta" in str(n)][:1])
print("    esempio:", blocks[3].split("\n")[2:], "|", blocks[9].split("\n")[2:])
# il menu del lettore usa la stessa traduzione (dalla memoria, senza rifare niente)
xbmcplugin.ITEMS.clear(); calls.clear(); xbmc.BUILTINS.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "18", "?action=search"])
u = xbmcplugin.ITEMS[0][0]; xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "19", "?" + u.split("?", 1)[1]])
t = open(xbmcplugin.ITEMS[0][0], encoding="utf-8").read()
print("    dal menu del lettore:", IT[2] in t, "| richieste:", len(calls), "| traduzione con Gemini avviata dopo:", [b for b in xbmc.BUILTINS if "upgrade" in b])
# impostazione spenta: si traduce come prima
xbmcaddon.SETTINGS.update({"human": "false", "engine": "google (gratis, senza chiave)"})
for f in os.listdir(runner.CACHE): os.remove(os.path.join(runner.CACHE, f))
xbmc.Player.subs.clear(); calls.clear()
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read()
print("    impostazione spenta → Google:", t.count("IT["), "frasi")

# film in streaming: l'originale e la traduzione italiana presi tutti e due da OpenSubtitles
xbmcaddon.SETTINGS.update({"human": "true"})
for f in os.listdir(runner.CACHE): os.remove(os.path.join(runner.CACHE, f))
xbmc.Player.playing_file = "https://45-4.download.real-debrid.com/d/PRPJ/The.Burbs.1989.2160p.UHD.Blu-ray.Remux.DV.HDR.HEVC.FLAC.2.0-CiNEPHiLES.mkv"
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.AudioLanguage": "eng", "VideoPlayer.IMDBNumber": "tt0096734"})
xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": xbmc.Player.playing_file, "at": time.time() - 20})
xbmc.Player.subs.clear(); xbmcgui.NOTES.clear(); calls.clear()
runner.run(xbmc.Player(), interactive=True)
t = open(xbmc.Player.subs[-1], encoding="utf-8").read()
print("    streaming, italiano da OpenSubtitles:", "cosa c'è in cantina" in t, "| richieste all'elenco di OpenSubtitles:",
      len([c for c in calls if c.startswith("os:")]), "| Google:", sum(1 for c in calls if "translate.googleapis" in c))
print("    avviso:", [n for n in xbmcgui.NOTES if "già fatta" in str(n)][:1])

# ---------- 15. (1.6) lingua di arrivo qualsiasi: dalla lista, quella di Kodi, o scritta a mano
tls = []
def spy_http(url, data=None, headers=None, timeout=90):
    if "translate.googleapis.com" in url:
        tls.append(urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["tl"][0])
    return fake_http(url, data, headers, timeout)
core.http = spy_http
xbmcaddon.SETTINGS.update({"human": "false", "engine": "google (gratis, senza chiave)"})
res = []
for choice, custom in [("it (italiano)", ""), ("cs (ceco)", ""), ("sw (swahili)", ""), ("kodi (la lingua di Kodi)", ""),
                       ("altra (scrivi la sigla qui sotto)", "Tagalog"), ("altra (scrivi la sigla qui sotto)", "ceco"),
                       ("altra (scrivi la sigla qui sotto)", "pt-BR"), ("altra (scrivi la sigla qui sotto)", "yue"), ("altra (scrivi la sigla qui sotto)", "lingua strana"), ("altra (scrivi la sigla qui sotto)", "")]:
    xbmcaddon.SETTINGS.update({"target": choice, "target_custom": custom})
    res.append((choice.split(" ")[0] + ("/" + custom if custom else ""), runner.settings()["target"]))
print("15. lingua di arrivo:", res)
xbmcaddon.SETTINGS.update({"target": "cs (ceco)", "target_custom": ""})
for f in os.listdir(runner.CACHE): os.remove(os.path.join(runner.CACHE, f))
xbmc.Player.playing_file = "/tmp/kodi-film14/Treno.2020.mkv"; xbmc.Player.subs.clear(); tls.clear()
runner.run(xbmc.Player(), interactive=True)
print("    traduzione in ceco: Google chiamato con tl =", sorted(set(tls)), "| file:", os.path.basename(xbmc.Player.subs[-1]) if xbmc.Player.subs else None)
xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "20", "?action=search"])
print("    menu del lettore:", [(li.label, li.label2) for u, li in xbmcplugin.ITEMS][:2])
print("    prompt per Gemini in svedese:", "Swedish" in core._prompt("sv", 3))
core.http = fake_http

# ---------- 16. (1.6) salvare i sottotitoli (.srt) per riusarli o condividerli
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "human": "false"})
for f in os.listdir(runner.CACHE): os.remove(os.path.join(runner.CACHE, f))
os.remove("/tmp/kodi-film14/Treno.2020.it.srt")
xbmc.Player.playing_file = "/tmp/kodi-film14/Treno.2020.mkv"; xbmc.Player.subs.clear()
runner.run(xbmc.Player(), interactive=True)
shutil.rmtree("/tmp/kodi-salva", ignore_errors=True); os.makedirs("/tmp/kodi-salva")
xbmcgui.SELECTS.clear(); xbmcgui.SELECT_ANSWER[0] = 1; xbmcgui.BROWSE_ANSWER[0] = "/tmp/kodi-salva/"; xbmcgui.NOTES.clear()
runner.save_menu(xbmc.Player())
print("16. menu 'Salva': scelte", xbmcgui.SELECTS[-1])
print("    in una cartella scelta:", sorted(os.listdir("/tmp/kodi-salva")), "|", xbmcgui.NOTES[-1][:60])
d = open("/tmp/kodi-salva/" + [f for f in os.listdir("/tmp/kodi-salva") if ".doppi." in f][0], encoding="utf-8").read()
print("    il doppio:", d.split("\n\n")[0].replace("\n", " / "))
xbmcgui.SELECT_ANSWER[0] = 0
runner.save_menu(xbmc.Player())
print("    accanto al video:", sorted(f for f in os.listdir("/tmp/kodi-film14") if f.endswith(".srt")))
# rivedendo il video, il file accanto al video in inglese resta l'originale e quello italiano fa da traduzione già pronta
# (la "traduzione" finta del banco di prova sono parole rovesciate, che non sembrano italiano: metto frasi italiane vere)
_saved = open("/tmp/kodi-film14/Treno.2020.it.srt", encoding="utf-8").read().split("\n\n")
open("/tmp/kodi-film14/Treno.2020.it.srt", "w", encoding="utf-8").write("\n\n".join(
    "\n".join(b.split("\n")[:2] + [IT[i]]) for i, b in enumerate(x for x in _saved if x.strip())))
xbmcaddon.SETTINGS.update({"human": "true"}); calls.clear(); xbmc.LOG.clear()
for f in os.listdir(runner.CACHE): os.remove(os.path.join(runner.CACHE, f))
runner.run(xbmc.Player(), interactive=True)
print("    rivisto: traduzione da", [l for l in xbmc.LOG if "già pronta da" in l][:1], "| Google:", sum(1 for c in calls if "translate.googleapis" in c))
# salvataggio automatico
shutil.rmtree("/tmp/kodi-auto", ignore_errors=True); os.makedirs("/tmp/kodi-auto")
xbmcaddon.SETTINGS.update({"save_auto": "true", "save_folder": "/tmp/kodi-auto"})
for f in os.listdir(runner.CACHE): os.remove(os.path.join(runner.CACHE, f))
runner.run(xbmc.Player(), interactive=True)
print("    salvataggio automatico:", sorted(os.listdir("/tmp/kodi-auto")))
xbmcaddon.SETTINGS.update({"save_auto": "false", "save_folder": ""}); xbmcgui.SELECT_ANSWER[0] = -1

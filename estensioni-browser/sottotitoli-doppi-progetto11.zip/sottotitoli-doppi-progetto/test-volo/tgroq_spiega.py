# "Spiega con Groq" in Parole al Volo: la richiesta non deve superare il limite di Groq (max_tokens conta)
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:true, engine:'groq', pavEngine:'groq', learnExamples:false, learnFreq:false, learnSpell:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "en", "bread", 2500)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.get_by_role("button", name="Spiega con Groq").click(); await pg.wait_for_timeout(5000)
        print("scheda:", (await tvolo.card_text(pg)).replace("\n", " | ")[:400])
        print("max_tokens mandati:", tvolo.log.get("maxtok"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

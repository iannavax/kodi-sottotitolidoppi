#!/bin/bash
MODE="$1"; DELAY="$2"; WAIT="$3"
for f in /tmp/sd-mock.pid /tmp/sd-addon.pid; do [ -f $f ] && kill $(cat $f) 2>/dev/null; done
for p in $(ss -ltnp 2>/dev/null | grep -E ":(7000|7801) " | grep -o "pid=[0-9]*" | cut -d= -f2); do kill $p; done; sleep 0.5
rm -rf /home/claude/stremio/sottotitoli-doppi-stremio/cache
cd /home/claude/stremio
MOCK_LINES=${LINES:-60} GOOGLE_DELAY=${GDELAY:-0} GEM_MODE=$MODE GEM_DELAY=${DELAY:-300} setsid nohup node mock.js > /tmp/mock.log 2>&1 < /dev/null & echo $! > /tmp/sd-mock.pid
cd sottotitoli-doppi-stremio
SD_OPENSUBS_URL=http://127.0.0.1:7801 SD_GOOGLE_URL=http://127.0.0.1:7801 SD_GEMINI_URL=http://127.0.0.1:7801 SD_CINEMETA_URL=http://127.0.0.1:7801 SD_WAIT_MS=${WAIT:-3000} setsid nohup node server.js > /tmp/addon.log 2>&1 < /dev/null & echo $! > /tmp/sd-addon.pid
sleep 1

# 1.6.0: «Consumo: solo gratis»: con Gemini scelto per tradurre, i sottotitoli li traduce Google e nessuna richiesta va a Gemini
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', consumo:'free', targetLang:'it', ipa:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("(document.querySelector('.dualsub-trans')||{}).textContent", timeout=40000)
        await pg.wait_for_timeout(4000)
        tr = await pg.evaluate("(document.querySelector('.dualsub-trans')||{}).textContent")
        gem = len([c for c in log.get("gcalls", []) if c[1] == 200])
        print("traduzione:", tr[:60], "| richieste a Gemini:", gem, "| Google:", log["google"], "| motore salvato:", await sw.evaluate("chrome.storage.sync.get('engine').then(r=>r.engine)"))
        ok = gem == 0 and "GEM[" not in tr and tr
        print("errori:", errs if ok else errs + ["solo gratis usa Gemini"], log["errors"])
        await ctx.close()
asyncio.run(main())

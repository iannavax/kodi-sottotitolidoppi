# 1.7.15: sottotitoli automatici di YouTube corretti dal modello (opzione cleanAsr)
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def run(p, on):
    ctx, sw = await launch(p, "", None)
    await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
    await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, cleanAsr:%s, cleanMode:'off'})" % ("true" if on else "false"))
    pg = await ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
    await pg.evaluate("document.querySelector('video').play()")
    await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
    txt = await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent")
    await pg.wait_for_timeout(4000)
    st = await sw.evaluate("chrome.storage.local.get('status').then(r => (r.status||{}).text)")
    txt = await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent")
    await ctx.close()
    return txt, st, errs
async def main():
    async with async_playwright() as p:
        a = await run(p, False); b = await run(p, True)
        print("spenta:", a[0]); print("accesa:", b[0], "|", b[1])
        ok = a[0] != b[0] and b[0][:1].isupper() and b[0].rstrip().endswith(".")
        print("errori:", a[2] + b[2] if ok else a[2] + b[2] + ["non corretti"], log["errors"])
asyncio.run(main())

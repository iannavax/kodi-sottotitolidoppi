# unica 1.4.2: «Ordine dei servizi» nel popup — su e giù, spegnere, «Usa adesso» (Ollama finto) e «Prova»
import asyncio, sys, json, os
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        calls = []
        async def ollama(route, request):
            calls.append(request.url)
            if request.url.endswith("/models"):
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"data": [{"id": "gemma3:12b"}]}))
            if "OLLAMA_DOWN" in str(calls):
                return await route.abort()
            b = json.loads(request.post_data or "{}")
            calls.append("pensa=" + str(b.get("reasoning_effort")) + "/" + str(b.get("think")))
            if os.environ.get("NO_THINK_PARAM") and "reasoning_effort" in b:
                return await route.fulfill(status=400, content_type="application/json", body='{"error":{"message":"invalid reasoning_effort"}}')
            body = {"choices": [{"message": {"content": "<think>ragiono a lungo…</think>" + json.dumps({"t": ["Buongiorno, come stai oggi?"]})}}]}
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
        await ctx.route("http://localhost:11434/**", ollama)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{groq:'gsk'}})")
        await sw.evaluate("chrome.storage.sync.set({models:{local:'gemma3:12b'}})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1200)
        rows = lambda: pp.evaluate("[...document.querySelectorAll('.ds-order .ds-order-row')].map(r=>r.textContent.replace(/\\s+/g,' ').trim())")
        print("1. fila:", await rows())
        # Groq giù di uno
        await pp.evaluate("[...document.querySelectorAll('.ds-order .ds-order-row')][1].querySelectorAll('button')[1].click()"); await pp.wait_for_timeout(500)
        print("2. ordine salvato:", await sw.evaluate("chrome.storage.sync.get('engineOrder').then(r=>r.engineOrder)"))
        # spengo Mistral
        await pp.evaluate("[...document.querySelectorAll('.ds-order .ds-order-row')].find(r=>/Mistral/.test(r.textContent)).querySelector('input').click()"); await pp.wait_for_timeout(500)
        print("3. spenti:", await sw.evaluate("chrome.storage.sync.get('engineOff').then(r=>r.engineOff)"))
        # Usa adesso: Ollama
        await pp.evaluate("[...document.querySelectorAll('.ds-order .ds-order-row')].find(r=>/Ollama/.test(r.textContent)).querySelectorAll('button')[2].click()"); await pp.wait_for_timeout(2500)
        print("4. engine:", await sw.evaluate("chrome.storage.sync.get(['engine','engineOrder']).then(r=>[r.engine, r.engineOrder[0]])"), "| tendina:", await pp.evaluate("document.getElementById('engine').value"))
        print("5. riga:", [r for r in await rows() if r.startswith("1.")])
        print("   chiamate:", [c.split('11434')[1] if '11434' in c else c for c in calls])
        # Prova con Ollama spento
        calls.append("OLLAMA_DOWN")
        await pp.evaluate("[...document.querySelectorAll('.ds-order .ds-order-row')][0].querySelectorAll('button')[3].click()"); await pp.wait_for_timeout(2500)
        print("6. spento:", [r for r in await rows() if r.startswith("1.")])
        # nella scheda Parole al Volo dell'unica: stessa fila
        n = await pp.evaluate("document.querySelectorAll('.ds-order-row').length")
        print("7. righe in tutto il popup:", n)
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

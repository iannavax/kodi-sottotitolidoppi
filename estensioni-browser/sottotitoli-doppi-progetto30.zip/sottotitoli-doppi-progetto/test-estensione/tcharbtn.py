# «scheda del carattere ›» in situazioni reali: video che scorre, scheda aperta solo col mouse (non fissata)
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
T = "(s=>(document.querySelector(s)||{}).textContent||'')"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console: " + m.text) if m.type == "error" else None)
        await pg.goto("https://www.youtube.com/watch?v=jaKanji"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/勉強/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        for how in ("hover", "click"):
            w = pg.locator(".dualsub-orig .dualsub-word", has_text="勉強").first
            if how == "hover": await w.hover(); await pg.wait_for_timeout(1500)
            else: await w.click(); await pg.wait_for_timeout(1500)
            await pg.wait_for_selector(".dualsub-card .dsx-hanchip", timeout=8000)
            await pg.locator(".dualsub-card .dsx-hanchip", has_text="強").first.click()
            await pg.wait_for_function("/tratti/.test((document.querySelector('.dualsub-card .dsx-hanpanel')||{}).textContent||'')", timeout=8000)
            await pg.locator(".dualsub-card .dsx-btn", has_text="scheda del carattere").click(); await pg.wait_for_timeout(1500)
            print(how, "→ scheda:", await pg.evaluate(f"{T}('.dualsub-card .dualsub-card-word')"), "| video fermo:", await pg.evaluate("document.querySelector('video').paused"))
            await pg.keyboard.press("Escape"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(300)
            await pg.evaluate("document.querySelector('video').currentTime = 3.2; document.querySelector('video').play()"); await pg.wait_for_timeout(1000)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', transcribeMode:'live', cleanTranscript:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))""")
        pg = await ctx.new_page(); msgs = []
        pg.on("console", lambda m: msgs.append(m.text) if "SD-" in m.text else None)
        await pg.goto("https://www.youtube.com/watch?v=noCapsA"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("document.querySelector('video').currentTime > 5.0", timeout=10000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("document.querySelector('video').currentTime > 30", timeout=60000)
        await pg.wait_for_timeout(3000)
        print(log["groq"]); print(msgs)
        await ctx.close()
asyncio.run(main())

## Novità della 5.8.4
- **I sottotitoli non spariscono più a metà frase.** Spesso il tempo di fine di una frase (soprattutto nella trascrizione con Whisper e nei sottotitoli automatici) arriva prima che la frase sia finita di dire, e la riga spariva dopo un paio di secondi. Ora ogni frase resta visibile fino all'arrivo della successiva (se arriva entro 4 secondi), e comunque almeno il tempo per leggerla.

## Novità della 5.8.3
- **Quota di Whisper (Groq) finita: messaggio chiaro, subito.** Nella trascrizione di tutto il video l'estensione riprovava per minuti: ora dice se è finito il limite dell'ora o del giorno e tra quanto si libera, e si ferma (senza ripartire con la trascrizione mentre guardi, che finirebbe sulla stessa quota). Nella trascrizione mentre guardi l'attesa per il limite dell'ora mostra il tempo vero (prima al massimo 15 minuti). Se il credito dell'account è finito si ferma subito con un messaggio.

## Novità della 5.8.2
- **Le frasi brevi (una o due parole) ora vengono tradotte.** Gemini e gli altri modelli a volte ricopiavano uguali le frasi corte ("Ja." → "Ja.") e l'estensione non se ne accorgeva, perché controllava le copie solo dalle tre parole in su. Ora una frase ricopiata viene chiesta anche a Google: se Google la traduce si usa quella, se la lascia uguale anche lui è un nome o una parola internazionale ("Karen", "Okay") e resta così, senza richiederla più. Ai modelli viene anche detto esplicitamente di tradurre le risposte brevi e le esclamazioni.
- Le traduzioni di questo tipo già salvate vengono rifatte da sole la prima volta che riapri il video (solo quelle poche frasi), nei sottotitoli, nella trascrizione dal vivo e nella pagina "Trascrizione e traduzione".

## Novità della 5.8.1
- Guida completa riscritta (LEGGIMI): tutte le funzioni spiegate dall'inizio, con le istruzioni passo per passo.


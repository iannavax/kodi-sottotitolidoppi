# 5.14: dizionario di Google nella scheda (traduzioni con peso, definizioni, sinonimi), si spegne
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
DSX = "(document.querySelector('.dualsub-card .dsx')||{}).innerText"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false, etym:false, learnAudio:false, learnTable:false, learnGender:false, learnKnown:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).hover(); await pg.wait_for_timeout(2500)
        print("1. sinonimi cliccabili:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-gd .dsx-wordlink')].map(b=>b.textContent)"))
        n = await pg.locator(".dualsub-card .dsx-wordlink").count()
        if n:
            await pg.locator(".dualsub-card .dsx-wordlink").first.click(); await pg.wait_for_timeout(2500)
            print("2. scheda piccola:", (await pg.evaluate("(document.querySelector('.dualsub-card .dsx-idmini')||{}).innerText||''")).replace("\n", " | "))
            await pg.locator(".dualsub-card .dsx-wordlink").first.click(); await pg.wait_for_timeout(500)
            print("3. secondo clic (chiude):", await pg.locator(".dualsub-card .dsx-idmini").count())
        print("errori:", errs if n else errs + ["nessun sinonimo"], log["errors"])
        await ctx.close()
asyncio.run(main())

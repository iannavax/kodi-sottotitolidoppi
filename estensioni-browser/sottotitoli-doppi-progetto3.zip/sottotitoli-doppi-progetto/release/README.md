# Sottotitoli Doppi

**Impara le lingue guardando video, film e serie con i sottotitoli originali e la traduzione insieme.**

Sotto ogni frase nella lingua originale compare la traduzione nella tua lingua, in un altro colore. Così senti la lingua vera, leggi cosa si dice e capisci cosa significa, tutto nello stesso momento.

Il progetto ha due strumenti, per due modi di guardare:

| | 🌐 **Estensione per il browser** | 📺 **Add-on per Kodi** |
|---|---|---|
| **Dove** | YouTube e quasi tutti i siti con video o audio, su Edge, Chrome, Brave, Firefox | Film e serie su Kodi: file sul dispositivo, streaming (The Crew, Real-Debrid…) |
| **Sottotitoli originali** | Quelli del sito, oppure la trascrizione dell'audio | Dentro il film, accanto al video, OpenSubtitles, oppure la trascrizione dell'audio |
| **Parole interattive** | ✅ Passi il mouse su una parola: significato nella frase, pronuncia, vocabolario | — (Kodi mostra solo testo) |
| **Vocabolario ed esportazione per Anki** | ✅ | — |
| **Salvare i sottotitoli (.srt)** | ✅ | ✅ |
| **Traduzione con una chat (senza quote)** | ✅ | ✅ |
| **Guida** | [estensione/LEGGIMI](estensione/LEGGIMI.html) | [kodi/LEGGIMI](kodi/LEGGIMI.html) |

Entrambi traducono gratis con **Google Traduttore**, oppure molto meglio con **Gemini** (gratis con una chiave) e altri servizi. Tutto quello che viene tradotto o trascritto resta salvato: rivedere un video non costa niente.

---

## Cosa c'è in questa cartella

```
estensione/
  sottotitoli-doppi-chrome-v5.8.1.zip     → Edge, Chrome, Brave
  sottotitoli-doppi-firefox-v5.8.1.xpi    → Firefox
  LEGGIMI.html / LEGGIMI.md               → la guida completa
  NOVITA.md                               → cosa è cambiato in ogni versione
kodi/
  repository.sottotitolidoppi-1.0.0.zip   → per installare dal repository (si aggiorna da solo)
  script.sottotitolidoppi-1.10.1.zip      → l'add-on
  service.subtitles.sottotitolidoppi-1.0.0.zip → la voce nel menu Sottotitoli del lettore
  repository-kodi-github.zip              → la cartella da pubblicare su GitHub Pages
  PUBBLICARE-IL-REPOSITORY.md             → come pubblicarla, passo per passo
  LEGGIMI.html / LEGGIMI.md               → la guida completa
  NOVITA.md
stremio/
  sottotitoli-doppi-stremio-1.2.0.zip     → add-on per Stremio (sottotitoli doppi da OpenSubtitles)
  LEGGIMI.html / LEGGIMI.md               → come installarlo e usarlo
```

Le guide si aprono con un doppio clic sui file **.html** (si vedono nel browser, con l'indice cliccabile).

---

## Partire in 5 minuti

### Estensione (Edge o Chrome)
1. Estrai `sottotitoli-doppi-chrome-v5.8.1.zip` in una cartella che non cancellerai.
2. Apri `edge://extensions`, attiva **Modalità sviluppatore**, premi **Carica estensione non pacchettizzata** e scegli la cartella.
3. Clic sull'icona dell'estensione → **Traduci in**: la tua lingua.
4. Apri un video di YouTube, accendi i sottotitoli (CC): compare la doppia riga. Passa il mouse su una parola.

Su **Firefox**: `about:addons` → ⚙ → **Installa componente aggiuntivo da file…** → il file `.xpi`.

### Add-on per Kodi
1. Kodi → **Impostazioni → Sistema → Add-on**: attiva **Sorgenti sconosciute**.
2. **Impostazioni → Add-on → Installa da un file zip**: `script.sottotitolidoppi-1.10.1.zip`, poi `service.subtitles.sottotitolidoppi-1.0.0.zip`.
3. Nelle impostazioni dell'add-on scegli **Traduci in** e il **Servizio**.
4. Fai partire un film: dopo pochi secondi compaiono i sottotitoli doppi.

(Per gli aggiornamenti automatici installa invece dal repository: è spiegato nella guida di Kodi.)

### La chiave gratuita di Gemini (consigliata, per entrambi)
Vai su **aistudio.google.com/apikey**, accedi con un account Google e premi *Create API key* (non serve la carta). Incollala nel popup dell'estensione (Come tradurre → Gemini) e/o nelle impostazioni dell'add-on di Kodi (Servizio → gemini, Chiave Gemini).

Per **i video senza sottotitoli** serve anche una chiave **Groq** (gratis, console.groq.com/keys) per la trascrizione dell'audio.

---

## Aggiornare senza perdere niente

- **Edge/Chrome**: estrai la versione nuova **nella stessa cartella** e premi ↻ nella pagina delle estensioni.
- **Firefox**: installa il nuovo `.xpi` sopra quello vecchio.
- **Kodi**: dal repository si aggiorna da solo; altrimenti installa lo zip nuovo sopra quello vecchio.

Non rimuovere mai l'estensione o l'add-on per aggiornarli: con loro si cancellano chiavi, traduzioni salvate e vocabolario.

---

## Privacy

Non c'è nessun server del progetto: chiavi, traduzioni e vocabolario restano nel tuo browser o nel tuo Kodi. I testi vengono mandati solo ai servizi che scegli tu (Google, Gemini, Groq…).

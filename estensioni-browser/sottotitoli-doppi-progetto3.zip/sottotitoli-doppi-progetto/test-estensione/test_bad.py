import asyncio, os
from bharness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p)
        await sw.evaluate("""chrome.storage.sync.set({engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}, targetLang:'it'})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        os.environ["GEM_MODE"] = "bad"
        pg = await ctx.new_page()
        await pg.goto("https://www.youtube.com/watch?v=longE"); await pg.evaluate("document.querySelector('video').play()")
        seen = []
        for _ in range(70):
            await pg.wait_for_timeout(1000)
            st = await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status.text)")
            if not seen or seen[-1] != st: seen.append(st)
            if "completata" in st: break
        for x in seen: print("  stato:", x)
        print("  richieste a Gemini:", len(log.get("gcalls", [])), "| sul video:", await pg.evaluate("document.querySelector('.dualsub-trans').textContent"))
        # rivedendo: le frasi tradotte da Google al posto del modello non sono salvate come "di Gemini"
        cache = await sw.evaluate("chrome.storage.local.get(null).then(a=>{const k=Object.keys(a).find(k=>k.startsWith('cache:longE'));return a[k].filter(x=>x==null).length})")
        print("  frasi non salvate (verranno richieste di nuovo a Gemini la prossima volta):", cache)
        await ctx.close()
asyncio.run(main())

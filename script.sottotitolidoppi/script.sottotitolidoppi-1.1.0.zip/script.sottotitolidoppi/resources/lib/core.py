# -*- coding: utf-8 -*-
# Sottotitoli Doppi per Kodi - logica principale (senza dipendenze da Kodi, così si può provare anche fuori)
#
# Crea un file di sottotitoli "doppio": in ogni riga l'originale e, sotto, la traduzione colorata.
# L'originale viene da un file di sottotitoli (accanto al video, scaricato con un add-on di Kodi
# o scelto a mano) oppure dalla trascrizione dell'audio con Whisper (serve ffmpeg).
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
import urllib.parse
import urllib.request
import uuid

VERSION = "1.0.0"

LANG_EN = {"it": "Italian", "en": "English", "es": "Spanish", "fr": "French", "de": "German", "pt": "Portuguese",
           "nl": "Dutch", "pl": "Polish", "ro": "Romanian", "ru": "Russian", "uk": "Ukrainian", "tr": "Turkish",
           "ar": "Arabic", "hi": "Hindi", "ja": "Japanese", "ko": "Korean", "zh": "Simplified Chinese"}
WHISPER_LANGS = {"english": "en", "italian": "it", "spanish": "es", "french": "fr", "german": "de", "portuguese": "pt",
                 "dutch": "nl", "polish": "pl", "romanian": "ro", "russian": "ru", "ukrainian": "uk", "turkish": "tr",
                 "arabic": "ar", "hindi": "hi", "japanese": "ja", "korean": "ko", "chinese": "zh", "castilian": "es"}
# Sigle delle lingue nei nomi dei file (film.en.srt, film.eng.srt, film.English.srt…)
FILE_TAGS = {"en": "en", "eng": "en", "english": "en", "it": "it", "ita": "it", "italian": "it", "italiano": "it",
             "es": "es", "spa": "es", "spanish": "es", "fr": "fr", "fre": "fr", "fra": "fr", "french": "fr",
             "de": "de", "ger": "de", "deu": "de", "german": "de", "pt": "pt", "por": "pt", "pt-br": "pt",
             "nl": "nl", "dut": "nl", "pl": "pl", "pol": "pl", "ru": "ru", "rus": "ru", "ja": "ja", "jpn": "ja",
             "ko": "ko", "kor": "ko", "zh": "zh", "chi": "zh", "zho": "zh", "tr": "tr", "tur": "tr", "ar": "ar", "ara": "ar"}

ENGINES = {
    "google": {"kind": "google", "chunk": 12},
    "gemini": {"kind": "openai", "base": "https://generativelanguage.googleapis.com/v1beta/openai",
               "model": "gemini-flash-lite-latest", "gap": 6.5, "chunk": 40},
    "groq": {"kind": "openai", "base": "https://api.groq.com/openai/v1", "model": "llama-3.3-70b-versatile", "gap": 2.2, "chunk": 35},
    "openrouter": {"kind": "openai", "base": "https://openrouter.ai/api/v1", "model": "", "gap": 3.5, "chunk": 40},
    "local": {"kind": "openai", "base": "http://localhost:11434/v1", "model": "", "gap": 0, "chunk": 15},
    "deepl": {"kind": "deepl", "gap": 0.5, "chunk": 25},
    "claude": {"kind": "claude", "model": "claude-haiku-4-5-20251001", "gap": 0, "chunk": 40},
}

SUB_EXT = (".srt", ".vtt", ".ass", ".ssa")


# ====================================================================== lettura dei sottotitoli
def _ms(t):
    t = t.strip().replace(",", ".")
    m = re.match(r"(?:(\d+):)?(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?", t)
    if not m:
        return None
    h, mi, s, frac = int(m.group(1) or 0), int(m.group(2)), int(m.group(3)), (m.group(4) or "0").ljust(3, "0")
    return ((h * 60 + mi) * 60 + s) * 1000 + int(frac)


def _clean_text(t):
    t = re.sub(r"\{\\[^}]*\}", "", t)          # codici ASS {\i1}
    t = t.replace("\\N", " ").replace("\\n", " ")
    t = re.sub(r"<[^>]+>", "", t)              # <i>, <font>
    return re.sub(r"\s+", " ", t).strip()


def parse_subs(text):
    """Sottotitoli .srt, .vtt, .ass/.ssa → [{"s": ms, "e": ms, "t": testo}]"""
    text = text.replace("\r", "").lstrip("\ufeff")
    cues = []
    if "[Events]" in text and "Dialogue:" in text:
        fmt = None
        for line in text.split("\n"):
            if line.startswith("Format:") and fmt is None and "Start" in line:
                fmt = [x.strip().lower() for x in line[7:].split(",")]
            elif line.startswith("Dialogue:") and fmt:
                parts = line[9:].split(",", len(fmt) - 1)
                row = dict(zip(fmt, parts))
                s, e = _ms(row.get("start", "")), _ms(row.get("end", ""))
                t = _clean_text(row.get("text", ""))
                if s is not None and e is not None and t:
                    cues.append({"s": s, "e": e, "t": t})
    else:
        for block in re.split(r"\n\s*\n", text):
            lines = [l for l in block.split("\n") if l.strip()]
            idx = next((i for i, l in enumerate(lines) if "-->" in l), -1)
            if idx < 0:
                continue
            a, b = lines[idx].split("-->", 1)
            s, e = _ms(a), _ms(b.strip().split(" ")[0])
            t = _clean_text(" ".join(lines[idx + 1:]))
            if s is not None and e is not None and t:
                cues.append({"s": s, "e": max(e, s + 300), "t": t})
    cues.sort(key=lambda c: c["s"])
    return cues


def lang_from_filename(name):
    parts = os.path.basename(name).lower().split(".")[1:-1]
    for p in reversed(parts):
        p = re.sub(r"[^a-z-]", "", p)
        if p in FILE_TAGS:
            return FILE_TAGS[p]
    return ""


STOP = {
    "en": "the and is are of to in that it you was for on with this have be not but they what we my your do there a i our were".split(),
    "it": "il lo gli di che è e un una per non sono con del della mi ti si ma come anche ho questo questa nel alla perché più la al a da io abbiamo siamo".split(),
    "es": "el los las de que es y un una por para con no se del pero como está muy yo tú al esto pues también la en me".split(),
    "fr": "le les des que et est un une pour pas je vous il elle dans ce qui sur avec mais au du très la en nous ne".split(),
    "de": "der die das und ist nicht ich du ein eine zu mit den dem auf für es sie wir aber auch sehr".split(),
    "pt": "o os as de que e é um uma para com não se do da mas como você eu isso muito também a no na em ao".split(),
}


def guess_lang(text):
    words = [w for w in re.split(r"[^\w]+", text.lower()) if w and not w.isdigit()]
    if len(words) < 5:
        return ""
    scores = sorted(((l, sum(1 for w in words if w in lst)) for l, lst in STOP.items()), key=lambda x: -x[1])
    (best, b), (_, s2) = scores[0], scores[1]
    return best if b >= 3 and b >= s2 * 1.5 else ""


def guess_lang_cues(cues):
    return guess_lang(" ".join(c["t"] for c in cues[:200]))


# ====================================================================== scelta del file di sottotitoli
def pick_subtitle(candidates, video_path, target):
    """candidates: [(percorso, data di modifica)] → il file più adatto come "originale", oppure None.
    Preferisce i file con lo stesso nome del video e una lingua diversa da quella in cui traduci."""
    base = os.path.splitext(os.path.basename(video_path or ""))[0].lower()
    best, best_score = None, -1
    for path, mtime in candidates:
        name = os.path.basename(path).lower()
        if not name.endswith(SUB_EXT) or ".doppi." in name:
            continue
        lang = lang_from_filename(name)
        if lang and lang == target:
            continue                                   # è già nella tua lingua
        score = 0
        if base and name.startswith(base):
            score += 10
        if lang:
            score += 3
        if lang == "en":
            score += 1
        score += min(2, mtime / 1e10)                  # a parità, il più recente
        if score > best_score:
            best, best_score = path, score
    return best


# ====================================================================== rete
def http(url, data=None, headers=None, timeout=90):
    req = urllib.request.Request(url, data=data, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers or {})


class RateLimited(Exception):
    def __init__(self, wait, daily=False):
        Exception.__init__(self, "limite di richieste")
        self.wait, self.daily = wait, daily


class Fatal(Exception):
    pass


def _check(status, body, headers, service):
    if status == 429:
        text = body.decode("utf-8", "replace")
        m = re.search(r'"retryDelay"\s*:\s*"(\d+)', text)
        wait = int(headers.get("Retry-After") or headers.get("retry-after") or (m.group(1) if m else 15))
        raise RateLimited(min(90, max(5, wait)), daily=bool(re.search(r"PerDay|per day|daily", text, re.I)))
    if status in (401, 403):
        raise Fatal("%s: chiave non valida o senza permessi (%d)" % (service, status))
    if status >= 400:
        raise Exception("%s ha risposto %d: %s" % (service, status, body[:200].decode("utf-8", "replace")))


# ====================================================================== traduzione
def google_translate(texts, target, source=""):
    tl = "zh-CN" if target == "zh" else target
    sl = source.split("-")[0] if source and source.split("-")[0] != target else "auto"

    def one(q):
        url = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t&sl=%s&tl=%s&q=%s" % (
            sl, tl, urllib.parse.quote(q))
        st, body, h = http(url)
        _check(st, body, h, "Google Traduttore")
        data = json.loads(body.decode("utf-8"))
        return "".join((p[0] or "") for p in (data[0] or []) if p)

    lines = one("\n".join(texts)).split("\n")
    if len(lines) == len(texts):
        return [l.strip() for l in lines]
    return [one(t).strip() for t in texts]


def _prompt(target, n):
    lang = LANG_EN.get(target, target)
    return ("You translate video subtitles into %s. You receive a JSON object whose \"segments\" array holds consecutive "
            "subtitles of a film or video. \"context_before\" and \"context_after\" are only there to help you understand; "
            "do not translate them. Write natural, fluent %s the way a professional subtitler would. Each segment is a "
            "separate subtitle shown at a different time: keep every translation aligned with its own segment, never move "
            "words between segments, never merge them, never leave one empty. Always translate into %s, never copy the "
            "original. Do not add numbers, quotes or notes. Return exactly %d strings as JSON: {\"t\": [\"...\"]} and nothing else."
            % (lang, lang, lang, n))


def _parse_list(content, n):
    s = re.sub(r"<think>.*?</think>", "", content or "", flags=re.S).replace("```json", "").replace("```", "")
    arr = None
    a, b = s.find("{"), s.rfind("}")
    if a >= 0 and b > a:
        try:
            obj = json.loads(s[a:b + 1])
            arr = obj.get("t") or obj.get("translations") or next((v for v in obj.values() if isinstance(v, list)), None)
        except ValueError:
            pass
    if arr is None:
        a, b = s.find("["), s.rfind("]")
        if a >= 0 and b > a:
            try:
                arr = json.loads(s[a:b + 1])
            except ValueError:
                pass
    if not isinstance(arr, list) or not arr:
        raise Exception("risposta del modello non leggibile")
    out = [re.sub(r"^\s*\d{1,3}[.)]\s+", "", str(x or "")).strip() for x in arr[:n]]
    return out + [""] * (n - len(out)), len(arr) != n


def is_echo(orig, trans, target):
    wa = [w for w in re.split(r"[^\w]+", orig.lower()) if w]
    wb = [w for w in re.split(r"[^\w]+", trans.lower()) if w]
    if len(wa) >= 3 and wb:
        if wa == wb:
            return True
        ratio = len(wb) / float(len(wa))
        if 0.7 < ratio < 1.45 and sum(1 for w in wb if w in set(wa)) / float(max(len(wa), len(wb))) >= 0.8:
            return True
    g = guess_lang(trans)
    return bool(g and g != target)


def bad_alignment(texts, trans):
    if len(texts) < 2:
        return False
    for src, t in zip(texts, trans):
        if len(src.split()) < 3:
            continue
        if not t.strip() or len(t) > len(src) * 2.6 + 25 or len(t) < len(src) * 0.3:
            return True
    return False


def llm_translate(engine_id, conf, texts, before, after, target):
    E = ENGINES[engine_id]
    user = json.dumps({"context_before": before, "segments": texts, "context_after": after}, ensure_ascii=False)
    system = _prompt(target, len(texts))
    key = conf.get("key", "")
    if E["kind"] == "claude":
        body = json.dumps({"model": conf.get("model") or E["model"], "max_tokens": 8000, "system": system,
                           "messages": [{"role": "user", "content": user}]}).encode("utf-8")
        st, raw, h = http("https://api.anthropic.com/v1/messages", body, {
            "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"})
        _check(st, raw, h, "Claude")
        data = json.loads(raw.decode("utf-8"))
        content = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    else:
        base = (conf.get("url") or E["base"]).rstrip("/")
        model = conf.get("model") or E["model"]
        if not model:
            raise Fatal("scegli un modello nelle impostazioni dell'add-on")
        body = json.dumps({"model": model, "temperature": 0.2, "max_tokens": 8192,
                           "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if key:
            headers["Authorization"] = "Bearer " + key
        st, raw, h = http(base + "/chat/completions", body, headers)
        _check(st, raw, h, engine_id)
        data = json.loads(raw.decode("utf-8"))
        content = ((data.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
    return _parse_list(content, len(texts))


def deepl_translate(conf, texts, before, after, target):
    key = conf.get("key", "")
    host = "https://api-free.deepl.com" if key.endswith(":fx") else "https://api.deepl.com"
    tl = {"en": "EN-US", "pt": "PT-BR", "zh": "ZH-HANS"}.get(target, target.upper())
    payload = {"text": texts, "target_lang": tl}
    if before or after:
        payload["context"] = "\n".join(before + after)
    st, raw, h = http(host + "/v2/translate", json.dumps(payload).encode("utf-8"),
                      {"Content-Type": "application/json", "Authorization": "DeepL-Auth-Key " + key})
    _check(st, raw, h, "DeepL")
    return [t.get("text", "") for t in json.loads(raw.decode("utf-8")).get("translations", [])]


def translate_all(cues, settings, target, source="", start_ms=0, on_progress=None, on_batch=None, should_stop=None):
    """Traduce tutte le frasi. Parte dal punto in cui stai guardando, poi il resto.
    Restituisce la lista delle traduzioni (stesso ordine di cues)."""
    engine = settings.get("engine", "google")
    if engine not in ENGINES:
        engine = "google"
    E = ENGINES[engine]
    conf = {"key": settings.get(engine + "_key", ""), "model": settings.get(engine + "_model", ""), "url": settings.get(engine + "_url", "")}
    if E["kind"] != "google" and engine != "local" and not conf["key"]:
        engine, E = "google", ENGINES["google"]
    texts = [c["t"] for c in cues]
    trans = [None] * len(texts)
    size = E["chunk"]
    chunks = [list(range(i, min(i + size, len(texts)))) for i in range(0, len(texts), size)]
    k = next((i for i, ch in enumerate(chunks) if cues[ch[-1]]["e"] >= start_ms), 0)
    queue = chunks[k:] + chunks[:k]
    last_call = 0.0
    done = 0
    use_google = E["kind"] == "google"
    while queue:
        if should_stop and should_stop():
            break
        ch = queue.pop(0)
        src = [texts[i] for i in ch]
        before = texts[max(0, ch[0] - 4):ch[0]]
        after = texts[ch[-1] + 1:ch[-1] + 3]
        result, misaligned = None, False
        try:
            if use_google:
                result = google_translate(src, target, source)
            else:
                wait = E.get("gap", 0) - (time.time() - last_call)
                if wait > 0:
                    time.sleep(wait)
                last_call = time.time()
                if E["kind"] == "deepl":
                    result = deepl_translate(conf, src, before, after, target)
                else:
                    result, misaligned = llm_translate(engine, conf, src, before, after, target)
                misaligned = misaligned or bad_alignment(src, result)
        except RateLimited as e:
            if e.daily:
                use_google = True                     # quota del giorno finita: continuo con Google
            else:
                time.sleep(e.wait)
            queue.insert(0, ch)
            continue
        except Fatal:
            use_google = True
            queue.insert(0, ch)
            continue
        except Exception:
            if not use_google and len(ch) > 3:
                queue[0:0] = [ch[:len(ch) // 2], ch[len(ch) // 2:]]
                continue
            result = google_translate(src, target, source)
        if misaligned and len(ch) > 1:
            queue[0:0] = [ch[:len(ch) // 2], ch[len(ch) // 2:]]
            continue
        echo = [j for j, i in enumerate(ch) if is_echo(texts[i], result[j] or "", target)]
        if echo and not use_google:
            fixed = google_translate([src[j] for j in echo], target, source)
            for j, t in zip(echo, fixed):
                result[j] = "" if is_echo(src[j], t, target) else t
        for j, i in enumerate(ch):
            trans[i] = result[j] if j < len(result) else ""
        done += len(ch)
        if on_progress:
            on_progress(done, len(texts))
        if on_batch:
            on_batch(trans)
    return [t or "" for t in trans]


# ====================================================================== file doppio
def ms_srt(ms):
    ms = max(0, int(ms))
    return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


def _esc(t):
    return t.replace("<", "‹").replace(">", "›")


def make_dual_srt(cues, trans, layout="orig_top", color="FFFF00"):
    """In ogni sottotitolo l'originale e la traduzione (colorata). layout: orig_top, trans_top, trans_only"""
    out = []
    for n, (c, t) in enumerate(zip(cues, trans), 1):
        tr = '<font color="#%s">%s</font>' % (color.strip("#"), _esc(t)) if t else ""
        orig = _esc(c["t"])
        if layout == "trans_only":
            body = tr or orig
        elif layout == "trans_top":
            body = "\n".join(x for x in (tr, orig) if x)
        else:
            body = "\n".join(x for x in (orig, tr) if x)
        out.append("%d\n%s --> %s\n%s\n" % (n, ms_srt(c["s"]), ms_srt(c["e"]), body))
    return "\n".join(out)


def cache_key(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:16]


# ====================================================================== trascrizione (Whisper, serve ffmpeg)
HALLU = re.compile(r"(sottotitoli (creati|a cura)|amara\.org|thanks? (you )?for watching|grazie (per|della) (la )?visione|"
                   r"iscriviti al canale|subtitles by|please subscribe)", re.I)
STOCK = re.compile(r"^(i'?m sorry|sorry|it'?s over|thank you( so much| very much)?|thanks|bye( bye)?|you|oh|okay|ok|yeah|"
                   r"music|applause|grazie|ciao)[.!?…]*$", re.I)


def is_junk(seg, recent):
    t = (seg.get("text") or "").strip()
    if not t or HALLU.search(t) or re.match(r"^[\s♪♫.…*\-]*$", t) or re.match(r"^[\[(].*[\])]$", t):
        return True
    ns, lp = seg.get("no_speech_prob") or 0, seg.get("avg_logprob")
    lp = -1 if lp is None else lp
    if lp < -1.5 or (ns > 0.5 and lp < -0.4) or (seg.get("compression_ratio") or 0) > 2.4:
        return True
    if STOCK.match(t) and (ns > 0.15 or lp < -0.6):
        return True
    return t.lower() in [r.lower() for r in recent[-4:]] and len(t.split()) <= 6


def find_ffmpeg(configured=""):
    if configured and os.path.isfile(configured):
        return configured
    return shutil.which("ffmpeg")


def extract_audio_pieces(ffmpeg, media, workdir, piece_sec=600):
    """Audio del video in pezzi da 10 minuti, mono 16 kHz, opus 24 kbps (circa 1,8 MB a pezzo)"""
    pattern = os.path.join(workdir, "pezzo%03d.ogg")
    cmd = [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-i", media, "-vn", "-ac", "1",
           "-ar", "16000", "-c:a", "libopus", "-b:a", "24k", "-f", "segment", "-segment_time", str(piece_sec), pattern]
    flags = 0x08000000 if os.name == "nt" else 0
    p = subprocess.run(cmd, capture_output=True, creationflags=flags)
    files = sorted(f for f in os.listdir(workdir) if f.startswith("pezzo") and f.endswith(".ogg"))
    if p.returncode != 0 and not files:
        raise Exception("ffmpeg non riesce a leggere l'audio: " + p.stderr.decode("utf-8", "replace")[-200:])
    return [os.path.join(workdir, f) for f in files]


def _multipart(fields, file_field, filename, data, mime):
    boundary = uuid.uuid4().hex
    out = []
    for k, v in fields:
        out.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (boundary, k, v)).encode("utf-8"))
    out.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\nContent-Type: %s\r\n\r\n"
                % (boundary, file_field, filename, mime)).encode("utf-8"))
    out.append(data)
    out.append(("\r\n--%s--\r\n" % boundary).encode("utf-8"))
    return b"".join(out), "multipart/form-data; boundary=" + boundary


def whisper_request(path, settings, language="", prompt=""):
    stt = settings.get("stt", "groq") or "groq"
    local = stt == "local"
    openai = stt == "openai"
    base = (settings.get("stt_url") or "http://localhost:8000/v1") if local else \
        "https://api.openai.com/v1" if openai else "https://api.groq.com/openai/v1"
    model = settings.get("stt_model") or "whisper-large-v3-turbo"
    if openai and model.startswith("whisper-large"):
        model = "whisper-1"   # i modelli "large" sono di Groq: OpenAI ha whisper-1
    service = "OpenAI Whisper" if openai else "Il server di trascrizione" if local else "Groq Whisper"
    fields = [("model", model), ("response_format", "verbose_json"),
              ("temperature", "0")]
    if language:
        fields.append(("language", language))
    if prompt:
        fields.append(("prompt", prompt[-400:]))
    with open(path, "rb") as f:
        body, ctype = _multipart(fields, "file", os.path.basename(path), f.read(), "audio/ogg")
    headers = {"Content-Type": ctype}
    if not local:
        key = settings.get("openai_key" if openai else "groq_key", "")
        if not key:
            raise Fatal("Manca la chiave %s nelle impostazioni dell'add-on (Trascrizione)" % ("OpenAI" if openai else "Groq"))
        headers["Authorization"] = "Bearer " + key
    for _ in range(6):
        st, raw, h = http(base.rstrip("/") + "/audio/transcriptions", body, headers, timeout=300)
        try:
            _check(st, raw, h, service)
        except RateLimited as e:
            time.sleep(e.wait)
            continue
        return json.loads(raw.decode("utf-8"))
    raise Exception("%s continua a rifiutare le richieste: riprova più tardi" % service)


def _split_long(text, start, end):
    parts = [p for p in re.split(r"(?<=[.!?…])\s+", text) if p]
    if len(parts) <= 1 or end - start < 6:
        return [(start, end, text)]
    total = float(sum(len(p) for p in parts)) or 1.0
    out, t = [], start
    for p in parts:
        d = (end - start) * len(p) / total
        out.append((t, t + d, p))
        t += d
    return out


def transcribe(media, settings, workdir, on_progress=None, should_stop=None):
    """Trascrizione dell'audio a pezzi da 10 minuti. Ogni pezzo riconosce la sua lingua;
    se sembra diversa da quella del video, lo trascrivo in tutte e due e tengo la versione più sicura."""
    ffmpeg = find_ffmpeg(settings.get("ffmpeg", ""))
    if not ffmpeg:
        raise Fatal("ffmpeg non trovato: installalo o indica il percorso nelle impostazioni dell'add-on")
    pieces = extract_audio_pieces(ffmpeg, media, workdir)
    forced = settings.get("stt_lang", "")
    dom, cues, recent = forced, [], []

    def conf(r):
        segs = r.get("segments") or []
        w = sum(max(0.2, (s.get("end") or 0) - (s.get("start") or 0)) for s in segs) or 1
        return sum((s.get("avg_logprob") or -1) * max(0.2, (s.get("end") or 0) - (s.get("start") or 0)) for s in segs) / w

    for n, path in enumerate(pieces):
        if should_stop and should_stop():
            break
        if on_progress:
            on_progress(n, len(pieces))
        prompt = " ".join(c["t"] for c in cues[-4:])
        r = whisper_request(path, settings, forced, prompt)
        det = WHISPER_LANGS.get((r.get("language") or "").lower(), "")
        if not forced and dom and det and det != dom:
            alt = whisper_request(path, settings, dom, prompt)
            if conf(alt) >= conf(r) - 0.05:
                r = alt
        elif not dom and det:
            dom = det
        offset = n * 600 * 1000
        for s in r.get("segments") or []:
            if is_junk(s, recent):
                continue
            recent.append((s.get("text") or "").strip())
            for a, b, t in _split_long(s["text"].strip(), s.get("start") or 0, s.get("end") or 0):
                cues.append({"s": int(offset + a * 1000), "e": int(offset + max(b, a + 0.5) * 1000), "t": t})
    return cues, dom

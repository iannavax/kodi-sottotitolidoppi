import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', transcribeMode:'live', cleanTranscript:false})
          .then(()=>chrome.storage.local.set({keys:{groq:'gsk_test'}}))""")
        pg = await ctx.new_page()
        await pg.goto("https://www.youtube.com/watch?v=noCapsLimit"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(int(os.environ.get("WAIT","30000")))
        print(os.environ.get("GROQ_LIMIT"), "| richieste rifiutate:", log.get("glimit"), "| riuscite:", len(log["groq"]))
        print("   stato:", await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)"))
        tid = await sw.evaluate("chrome.tabs.query({}).then(t=>t.find(x=>(x.url||'').includes('noCapsLimit')).id)")
        print("   trascrizione attiva:", await sw.evaluate(f"chrome.tabs.sendMessage({tid}, {{type:'liveState'}}).then(r=>r.running)"))
        await ctx.close()
asyncio.run(main())

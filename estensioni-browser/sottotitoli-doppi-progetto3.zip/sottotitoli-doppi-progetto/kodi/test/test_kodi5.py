# Prove della 1.9: memoria delle traduzioni (salvate man mano, riusate cambiando sottotitoli o tornando indietro)
import sys, os, json, time, shutil, re, urllib.parse
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
from resources.lib import core
tr = lambda x: " ".join(w[::-1] for w in x.split())
gem = []
STOP = {"after": 0}
def fake_http(url, data=None, headers=None, timeout=90):
    if "generativelanguage" in url:
        segs = json.loads(json.loads(data)["messages"][1]["content"])["segments"]
        gem.append(len(segs))
        if STOP["after"] and len(gem) >= STOP["after"]:
            xbmc.Player.playing = False          # il film viene fermato durante la traduzione
        return 200, json.dumps({"choices": [{"message": {"content": json.dumps({"t": ["GEM[" + tr(s) + "]" for s in segs]})}}]}).encode(), {}
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("G[" + tr(l) + "]" for l in q.split("\n")), q]], None, "en"]).encode(), {}
    if "opensubtitles" in url or "cinemeta" in url:
        return 200, b'{"subtitles": [], "metas": []}', {}
    return 404, b"", {}
core.http = fake_http
core.ENGINES["gemini"]["gap"] = 0
from resources.lib import runner
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata", "/tmp/kodi-film5"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles"); os.makedirs("/tmp/kodi-film5")
def srt(lines):
    f = lambda ms: "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)
    return "\n".join("%d\n%s --> %s\n%s\n" % (i + 1, f(i * 4000), f(i * 4000 + 3000), l) for i, l in enumerate(lines))
A = ["line number %d of the film" % i for i in range(300)]
B = [("line number %d of the film" % i) if i % 2 == 0 else ("other version of line %d" % i) for i in range(300)]
open("/tmp/kodi-film5/Film.en.srt", "w").write(srt(A))
open("/tmp/kodi-film5/Film.mkv", "w").write("x")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "gemini (gratis con chiave, consigliato)", "gemini_key": "AIza",
                           "layout": "Originale sopra", "trans_color": "FFFF00", "auto": "true",
                           "source_mode": "file (solo sottotitoli, mai trascrizione)", "trans_mode": "nuova (con il servizio scelto qui sotto, salvata)"})
def play():
    xbmc.Player.playing = True
    xbmc.Player.playing_file = "/tmp/kodi-film5/Film.mkv"
    xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": xbmc.Player.playing_file, "at": time.time() - 20})
    xbmc.Player.subs.clear(); gem.clear(); xbmc.LOG.clear()
def gemlines(): return [b for b in open(xbmc.Player.subs[-1], encoding="utf-8").read().split("\n\n") if "GEM[" in b]

# 1. film fermato dopo il primo gruppo: le frasi tradotte restano salvate
play(); STOP["after"] = 1
runner.run(xbmc.Player(), interactive=True)
STOP["after"] = 0
first = list(gem)
play()
runner.run(xbmc.Player(), interactive=True)
print("1. fermato a metà: richieste", first, "→ ripreso:", gem, "| frasi con Gemini:", len(gemlines()))
# 2. rivisto: nessuna richiesta
play(); runner.run(xbmc.Player(), interactive=True)
print("2. rivisto: richieste", gem)
# 3. altri sottotitoli (metà delle frasi uguali): traduce solo quelle diverse
open("/tmp/kodi-film5/Film.en.srt", "w").write(srt(B))
play(); runner.run(xbmc.Player(), interactive=True)
print("3. altri sottotitoli con 150 frasi uguali: frasi chieste", sum(gem), "| registro:", [l for l in xbmc.LOG if "memoria" in l][:1])
# 4. di nuovo i primi: niente
open("/tmp/kodi-film5/Film.en.srt", "w").write(srt(A))
play(); runner.run(xbmc.Player(), interactive=True)
print("4. tornando ai primi sottotitoli: richieste", gem)
# 5. Rifai da capo
play(); runner.run(xbmc.Player(), interactive=True, retranslate=True)
print("5. rifai da capo: frasi chieste", sum(gem))
# 6. menu del lettore: traduzione già salvata, nessuna richiesta né "upgrade"
from resources.lib import subtitles
play(); xbmcplugin.ITEMS.clear(); xbmc.BUILTINS.clear(); xbmcgui.NOTES.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "1", "?action=search"])
u = xbmcplugin.ITEMS[0][0]; xbmcplugin.ITEMS.clear()
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "2", "?" + u.split("?", 1)[1]])
t = open(xbmcplugin.ITEMS[0][0], encoding="utf-8").read()
print("6. dal menu del lettore:", t.count("GEM["), "frasi con Gemini | richieste:", gem, "| avviso:", xbmcgui.NOTES[-1:], "| upgrade:", [b for b in xbmc.BUILTINS if "upgrade" in b])
# 7. menu "Scegli": la voce dice quante frasi sono salvate
seq = [2, 1, 0]
def sel(self, h, opts):
    xbmcgui.SELECTS.append((h, opts)); return seq.pop(0)
xbmcgui.Dialog.select = sel
play(); runner.choose_menu(xbmc.Player())
print("7. voci della traduzione:", xbmcgui.SELECTS[-2][1][1:3], "| richieste:", gem)

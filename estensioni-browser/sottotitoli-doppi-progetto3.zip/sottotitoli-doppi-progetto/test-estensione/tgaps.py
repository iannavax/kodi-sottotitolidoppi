# 5.7.2: ogni parola della traduzione rimanda sempre a una parte dell'originale
# (ALIGN_GAPS=1: il modello lascia vuoto l'originale per alcune parole; ALIGN_FAIL=1: il modello non risponde)
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
ENGINE = os.environ.get("ENG", "gemini")
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate(f"""chrome.storage.sync.set({{engine:'{ENGINE}', models:{{gemini:'gemini-flash-lite-latest'}}, targetLang:'it', hoverPause:true}})
          .then(()=>chrome.storage.local.set({{keys:{{gemini:'AIza-test'}}}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=longGaps"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("document.querySelectorAll('.dualsub-trans .dualsub-tword').length > 2", timeout=20000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(400)
        print("frase:", await pg.inner_text(".dualsub-orig"), "|", await pg.inner_text(".dualsub-trans"))
        tw = pg.locator(".dualsub-trans .dualsub-tword")
        n = await tw.count(); bad = 0
        for i in range(n):
            await tw.nth(i).hover(); await pg.wait_for_timeout(6000 if i == 0 else 2500)
            hl = await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-hl')].map(x=>x.textContent)")
            tip = await pg.evaluate("(document.querySelector('.dualsub-align-tip')||{}).textContent")
            if not hl or "Nessuna" in (tip or "") or "Cerco" in (tip or ""): bad += 1
            want = (await tw.nth(i).inner_text())[::-1].lower()
            if os.environ.get("CHECK_EXACT") and i > 0 and want not in [h.lower() for h in hl]: bad += 1; print("    ^ parola sbagliata")
            print(f"  '{await tw.nth(i).inner_text()}' → {hl} | {tip!r}")
            if os.environ.get("SHOT") and i == 2: await pg.screenshot(path="/tmp/claude-0/-home-claude/cf8f7e32-9052-5fdc-8148-ebb4c57e4969/scratchpad/particella.png", clip={"x": 0, "y": 300, "width": 1000, "height": 260})
            await pg.mouse.move(600, 40); await pg.wait_for_timeout(300)
        print("particelle sottolineate:", await pg.evaluate("[...document.querySelectorAll('.dualsub-tpart')].map(x=>x.textContent)"))
        ow = pg.locator(".dualsub-orig .dualsub-word").nth(2)
        await ow.hover(); await pg.wait_for_timeout(600)
        print("al contrario, passo su", repr(await ow.inner_text()), "→ piena:", await pg.evaluate("[...document.querySelectorAll('.dualsub-trans .dualsub-hl')].map(x=>x.textContent)"),
              "| tenue:", await pg.evaluate("[...document.querySelectorAll('.dualsub-trans .dualsub-hl-group')].map(x=>x.textContent)"))
        await pg.mouse.move(600, 40); await pg.wait_for_timeout(500)
        # confronto trascinando sulla traduzione
        a = await tw.nth(1).bounding_box(); b = await tw.nth(3).bounding_box()
        await pg.mouse.move(a["x"] + 3, a["y"] + 5); await pg.mouse.down()
        await pg.mouse.move(b["x"] + 5, b["y"] + 5, steps=6); await pg.mouse.up(); await pg.wait_for_timeout(4000)
        tip = await pg.evaluate("(document.querySelector('.dualsub-align-tip')||{}).textContent")
        hl = await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-hl')].map(x=>x.textContent)")
        print("confronto →", hl, "|", repr(tip))
        if not hl: bad += 1
        print("richieste di allineamento:", len(log.get("align", [])))
        print("RISULTATO:", "OK" if bad == 0 and not errs else f"PROBLEMI ({bad}) {errs}")
        await ctx.close()
asyncio.run(main())

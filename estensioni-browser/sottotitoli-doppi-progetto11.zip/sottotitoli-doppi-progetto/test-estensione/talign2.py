import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
ENGINE = os.environ.get("ENG", "google")
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate(f"""chrome.storage.sync.set({{idioms:true, engine:'{ENGINE}', models:{{gemini:'gemini-flash-lite-latest'}}, targetLang:'it', hoverPause:true}})
          .then(()=>chrome.storage.local.set({{keys:{{gemini:'AIza-test'}}}}))""")
        sw.on("console", lambda m: print("  [sottofondo]", m.text))
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console: " + m.text) if m.type in ("error","warning") else None)
        await pg.goto("https://www.youtube.com/watch?v=longAlign"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("document.querySelectorAll('.dualsub-trans .dualsub-tword').length > 2", timeout=20000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(400)
        print("frase:", await pg.inner_text(".dualsub-orig"), "|", await pg.inner_text(".dualsub-trans"))
        tw = pg.locator(".dualsub-trans .dualsub-tword")
        r = await sw.evaluate("""align({type:'align', engine:'gemini', key:'AIza-test', model:'gemini-flash-lite-latest', original:'this is sentence number 1.', translation:'GEM[siht si ecnetnes rebmun .1]', lang:'en'}).then(r=>JSON.stringify(r)).catch(e=>'ERRORE '+e.message)""")
        print("chiamata diretta di align nel sottofondo:", r[:150])
        await tw.nth(0).hover()
        for ms in (300, 1500, 4000, 9000):
            await pg.wait_for_timeout(ms - (0 if ms == 300 else [300,1500,4000,9000][[300,1500,4000,9000].index(ms)-1]))
            tip = await pg.evaluate("(document.querySelector('.dualsub-align-tip')||{}).textContent")
            print(f"  prima parola dopo {ms} ms: {tip!r}")
        await pg.mouse.move(600, 40); await pg.wait_for_timeout(500)
        for i in [1, 3]:
            await tw.nth(i).hover(); await pg.wait_for_timeout(8000 if ENGINE != "google" else 2500)
            hl = await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-hl')].map(x=>x.textContent)")
            tip = await pg.evaluate("(document.querySelector('.dualsub-align-tip')||{}).textContent")
            print(f"passo su '{await tw.nth(i).inner_text()}' → evidenziata nell'originale: {hl} | etichetta: {tip!r}")
        if ENGINE != "google":
            ow = pg.locator(".dualsub-orig .dualsub-word").nth(2)
            await ow.hover(); await pg.wait_for_timeout(600)
            print(f"al contrario, passo su '{await ow.inner_text()}' → nella traduzione:", await pg.evaluate("[...document.querySelectorAll('.dualsub-trans .dualsub-hl')].map(x=>x.textContent)"))
            await pg.mouse.move(600, 40); await pg.wait_for_timeout(700)
        # clic sulla parola tradotta → scheda della parola originale
        await tw.nth(3).hover(); await pg.wait_for_timeout(2500)
        await tw.nth(3).click(); await pg.wait_for_timeout(1500)
        print("clic sulla parola tradotta → scheda per:", await pg.evaluate("(document.querySelector('.dualsub-card-word')||{}).textContent"))
        print("richieste: allineamenti", len(log.get("align", [])), "| traduzioni inverse Google", len(log.get("wordback", [])))
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

// Pagina "Parole più usate": l'elenco delle parole più comuni di una lingua (FrequencyWords, lo stesso usato per
// la frequenza nella scheda), con la posizione della parola guardata e le parole che conosci.
// Indirizzo: freq.html?lang=cs&word=tento
const $ = (id) => document.getElementById(id);
const P = new URLSearchParams(location.search);
const lang = String(P.get("lang") || "en").split("-")[0].toLowerCase();
const word = String(P.get("word") || "").toLowerCase();
const target = P.get("target") || "it";
const levelParam = String(P.get("level") || "").toUpperCase();
let list = [], index = new Map(), known = new Set(), from = 0, to = 0, me = 0;
const STEP = 150;
const langName = (() => { try { return new Intl.DisplayNames(["it"], { type: "language" }).of(lang) || lang; } catch { return lang; } })();
const nf = (n) => n.toLocaleString("it-IT");

// livello indicativo (A1…C2) dalla posizione nell'elenco: DS_LEVELS in config.js
function band(r) {
  const l = dsLevelOf(r);
  return l ? `livello ${l.id} (n. ${nf(l.from)}–${nf(l.to)})` : "oltre le 16.000 più usate";
}
// la barra dei livelli: si salta all'inizio di ognuno; per il giapponese anche i livelli JLPT ufficiali
function levelsBar() {
  const nav = $("levels");
  nav.textContent = "";
  const lab = document.createElement("span"); lab.className = "lab"; lab.textContent = "Livelli:";
  nav.append(lab);
  const cur = dsLevelOf(me) || DS_LEVELS.find((l) => l.id === levelParam);
  for (const l of DS_LEVELS) {
    if (l.from > list.length) break;
    const b = document.createElement("button"); b.type = "button";
    let k = 0; for (let i = l.from - 1; i < Math.min(l.to, list.length); i++) if (known.has(list[i])) k++;
    b.textContent = l.id;
    b.title = `Parole n. ${nf(l.from)}–${nf(l.to)}: ne conosci ${nf(k)} su ${nf(Math.min(l.to, list.length) - l.from + 1)} (indicativo, dalla frequenza)`;
    if (cur && cur.id === l.id) b.className = "on";
    b.addEventListener("click", () => { nav.querySelectorAll(".on").forEach((x) => x.classList.remove("on")); b.classList.add("on"); from = l.from - 1; to = Math.min(list.length, from + STEP); render(); const el = $("r" + l.from); if (el) el.scrollIntoView({ block: "start" }); });
    nav.append(b);
  }
  if (lang === "ja") {
    const lab2 = document.createElement("span"); lab2.className = "lab"; lab2.textContent = " JLPT:";
    nav.append(lab2);
    for (const l of DS_JLPT) {
      const a = document.createElement("a"); a.textContent = l;
      a.href = "jlpt.html?level=" + l + "&target=" + encodeURIComponent(target);
      a.title = "Le parole del livello " + l + " del JLPT (Jisho)";
      nav.append(a);
    }
  }
}

async function loadList() {
  const key = "freq:" + lang;
  const got = await DS_EXT.storage.local.get({ [key]: null, knownWords: {} });
  known = new Set(String((got.knownWords || {})[lang] || "").split("\n").filter(Boolean));
  let text = got[key];
  if (!text) {
    $("sub").textContent = "Scarico l'elenco…";
    const r = await DS_EXT.runtime.sendMessage({ type: "freqList", lang }).catch((e) => ({ error: String(e.message || e) }));
    if (!r || r.error || !r.list) { $("sub").textContent = "Per questa lingua l'elenco non è disponibile" + (r && r.error ? ": " + r.error : "."); return false; }
    text = r.list;
    await DS_EXT.storage.local.set({ [key]: text }).catch(() => {});
  }
  list = text.split("\n").filter(Boolean);
  list.forEach((w, i) => { if (!index.has(w)) index.set(w, i + 1); });
  return true;
}

function stats() {
  const s = $("stats");
  s.textContent = "";
  for (const n of [100, 1000, 5000]) {
    if (list.length < n) continue;
    let k = 0;
    for (let i = 0; i < n; i++) if (known.has(list[i])) k++;
    const d = document.createElement("span");
    d.className = "stat";
    d.textContent = `Delle prime ${nf(n)} ne conosci ${nf(k)} (${Math.round((k * 100) / n)}%)`;
    s.append(d);
  }
  const d = document.createElement("span");
  d.className = "stat";
  d.textContent = `Parole che conosci in ${langName}: ${nf(known.size)}`;
  s.append(d);
}

async function setKnown(w, on) {
  const r = await DS_EXT.storage.local.get({ knownWords: {} });
  const kw = { ...(r.knownWords || {}) };
  const set = new Set(String(kw[lang] || "").split("\n").filter(Boolean));
  if (on) set.add(w); else set.delete(w);
  kw[lang] = [...set].join("\n");
  known = set;
  await DS_EXT.storage.local.set({ knownWords: kw });
}

function row(i) {
  const w = list[i], r = i + 1;
  const tr = document.createElement("tr");
  if (r === me) tr.className = "me";
  if (known.has(w)) tr.classList.add("known");
  tr.id = "r" + r;
  const n = document.createElement("td"); n.className = "n"; n.textContent = nf(r);
  const t = document.createElement("td"); t.className = "w"; t.textContent = w;
  const a = document.createElement("a"); a.className = "tr"; a.textContent = "↗"; a.title = "Traduzione su Google";
  a.href = `https://translate.google.com/?sl=${encodeURIComponent(lang)}&tl=${encodeURIComponent(target)}&text=${encodeURIComponent(w)}&op=translate`;
  a.target = "_blank"; a.rel = "noopener noreferrer";
  t.append(a);
  const k = document.createElement("td"); k.className = "k";
  const b = document.createElement("button"); b.className = "kbtn"; b.type = "button";
  b.textContent = known.has(w) ? "✓ la conosco" : "la conosco?";
  b.addEventListener("click", async () => {
    const on = !known.has(w);
    await setKnown(w, on);
    tr.classList.toggle("known", on);
    b.textContent = on ? "✓ la conosco" : "la conosco?";
    stats();
  });
  k.append(b);
  tr.append(n, t, k);
  return tr;
}

function render() {
  const tb = $("list");
  tb.textContent = "";
  let lastBand = "";
  for (let i = from; i < to; i++) {
    const b = band(i + 1);
    if (b !== lastBand && (i === from || DS_LEVELS.some((l) => l.from - 1 === i) || i === 16000)) {
      const tr = document.createElement("tr");
      const td = document.createElement("td"); td.colSpan = 3; td.className = "band"; td.textContent = "— " + b + " —";
      tr.append(td); tb.append(tr);
      lastBand = b;
    }
    tb.append(row(i));
  }
  $("prev").hidden = from <= 0;
  $("next").hidden = to >= list.length;
}

function show(rank, scroll) {
  from = Math.max(0, rank - 1 - Math.floor(STEP / 2));
  to = Math.min(list.length, from + STEP);
  render();
  if (scroll) { const el = $("r" + rank); if (el) el.scrollIntoView({ block: "center" }); }
}

// lingua, "segna le prime N", esporta e importa (funzionano anche se l'elenco della lingua non c'è)
async function setupTools() {
  const sel = $("langSel");
  const got = await DS_EXT.storage.local.get({ knownWords: {} });
  const name = (c) => { try { return new Intl.DisplayNames(["it"], { type: "language" }).of(c) || c; } catch { return c; } };
  const codes = new Set([lang, ...Object.keys(got.knownWords || {}), ...Object.keys((typeof DS_CONFIG !== "undefined" && DS_CONFIG.STT_LANGS) || {})]);
  [...codes].filter((c) => /^[a-z]{2,3}$/.test(c)).map((c) => [c, name(c)]).sort((a, b) => a[1].localeCompare(b[1], "it"))
    .forEach(([c, n]) => { const k = String((got.knownWords || {})[c] || "").split("\n").filter(Boolean).length; sel.append(new Option(n + (k ? ` (${nf(k)} conosciute)` : ""), c)); });
  sel.value = lang;
  sel.addEventListener("change", () => { location.search = "?lang=" + encodeURIComponent(sel.value) + "&target=" + encodeURIComponent(target); });
  const msg = $("impMsg");
  $("markTop").addEventListener("click", async () => {
    const n = Math.max(1, Math.min(list.length, parseInt($("topN").value, 10) || 0));
    if (!list.length) { msg.textContent = "Per questa lingua non c'è l'elenco."; return; }
    if (!confirm(`Segno come conosciute le prime ${nf(n)} parole dell'elenco (${langName})?`)) return;
    const r = await DS_EXT.storage.local.get({ knownWords: {} });
    const kw = { ...(r.knownWords || {}) };
    const set = new Set(String(kw[lang] || "").split("\n").filter(Boolean));
    const before = set.size;
    for (const w of list.slice(0, n)) set.add(w);
    kw[lang] = [...set].join("\n");
    await DS_EXT.storage.local.set({ knownWords: kw });
    msg.textContent = `Fatto: ${nf(set.size - before)} parole in più tra quelle che conosci.`;
  });
  $("exp").addEventListener("click", async () => {
    try { const r = await dsExportData({ known: true, vocab: false }); msg.textContent = `Salvato «${r.name}»: ${nf(r.known)} parole. Contiene tutte le lingue. Importalo nell'altra estensione (pagina delle parole più usate o del vocabolario: «Importa da un file…»).`; }
    catch (e) { msg.textContent = "Non riesco: " + (e.message || e); }
  });
  // con l'altra estensione: direttamente (pulsante) o con un file
  const other = dsSiblingNames().map((n) => "«" + n + "»").join(" e ");
  $("swapTitle").textContent = "⇄ Parole che conosco con le altre estensioni";
  $("swapHelp").textContent = `«Sincronizza adesso» passa le parole che conosci, in tutte le lingue, da qui a ${other} (quelle installate) e da lì a qui: si uniscono, non si cancella niente. Passano anche le chiavi dei servizi (Gemini, Groq…) e le impostazioni che lì non hai ancora scelto (le tue restano). Servono installate, accese e aggiornate` +
    (dsIsGecko() ? "." : "; la prima volta il browser chiede il permesso di vedere le estensioni installate, per trovarle.") +
    " Senza: «Esporta in un file» qui (tutte le lingue insieme) e «Importa da un file…» nella stessa pagina dell'altra estensione. Va bene anche un .txt con una parola per riga (nella lingua di questa pagina).";
  $("sync").addEventListener("click", async () => {
    msg.textContent = "Sincronizzo con le altre estensioni…";
    $("sync").disabled = true;
    try { msg.textContent = dsSyncReport(await dsSyncWithSibling({ known: true, vocab: false })); }
    catch (e) { msg.textContent = "Non riesco: " + (e.message || e); }
    $("sync").disabled = false;
  });
  $("imp").addEventListener("click", () => $("impFile").click());
  $("impFile").addEventListener("change", async () => {
    const f = $("impFile").files[0];
    $("impFile").value = "";
    if (!f) return;
    try { msg.textContent = dsImportReport(await dsImportData(await f.text(), lang)); }
    catch (e) { msg.textContent = "Non riesco a importare: " + (e.message || e); }
  });
}

(async () => {
  setupTools().catch(() => {});
  document.title = "Parole più usate in " + langName;
  $("title").textContent = "Le parole più usate in " + langName;
  if (!(await loadList())) { levelsBar(); return; }
  $("sub").textContent = `Le ${nf(list.length)} parole più frequenti (elenco FrequencyWords, dai sottotitoli di film e serie).`;
  me = word ? index.get(word) || 0 : 0;
  if (word) {
    const w = $("where");
    w.hidden = false;
    w.innerHTML = "";
    const b = document.createElement("b"); b.textContent = word;
    w.append("«", b, "» ");
    w.append(me ? `è la parola n. ${nf(me)} su ${nf(list.length)}: ${band(me)}.` : `non è tra le ${nf(list.length)} parole più usate: molto rara, oppure un nome o una forma poco comune.`);
    $("toMe").hidden = !me;
  }
  stats();
  levelsBar();
  const lp = !me && DS_LEVELS.find((l) => l.id === levelParam);
  if (lp && lp.from <= list.length) { from = lp.from - 1; to = Math.min(list.length, from + STEP); render(); const el = $("r" + lp.from); if (el) el.scrollIntoView({ block: "start" }); }
  else show(me || 1, !!me);
  $("prev").addEventListener("click", () => { const old = from; from = Math.max(0, from - STEP); render(); const el = $("r" + (old + 1)); if (el) el.scrollIntoView({ block: "start" }); });
  $("next").addEventListener("click", () => { to = Math.min(list.length, to + STEP); render(); });
  $("toTop").addEventListener("click", () => { show(1, false); window.scrollTo(0, 0); });
  $("toMe").addEventListener("click", () => show(me, true));
  $("q").addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    const q = $("q").value.trim().toLowerCase();
    if (!q) return;
    const r = index.get(q) || (list.findIndex((w) => w.startsWith(q)) + 1);
    if (r > 0) show(r, true);
    else { const s = $("sub"); s.textContent = `«${q}» non è nell'elenco.`; }
  });
  DS_EXT.storage.onChanged.addListener((ch, area) => {
    if (area === "local" && ch.knownWords) { known = new Set(String((ch.knownWords.newValue || {})[lang] || "").split("\n").filter(Boolean)); stats(); render(); levelsBar(); }
  });
})();

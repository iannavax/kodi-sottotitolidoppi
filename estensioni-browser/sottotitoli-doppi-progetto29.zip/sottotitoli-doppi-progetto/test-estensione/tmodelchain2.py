# 1.6.1: finiti oggi tutti i modelli di Gemini → si passa al servizio successivo (Groq)
import asyncio, os, sys, json
os.environ["GEM_DAILY_MODEL"] = "gemini-flash-lite-latest,gemini-flash-latest"
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk_test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/GROQ\\[/.test((document.querySelector('.dualsub-trans')||{}).textContent||'')", timeout=40000)
        tr = await pg.evaluate("(document.querySelector('.dualsub-trans')||{}).textContent")
        st = await sw.evaluate("chrome.storage.local.get(['status','dsBlocked']).then(r=>JSON.stringify([r.status&&r.status.text, Object.keys(r.dsBlocked||{})]))")
        print("traduzione:", tr[:60], "| Gemini:", log.get("gmodels"), "| Groq:", log.get("groqtr"), "| stato e blocchi:", st)
        ok = "GROQ[" in tr and log.get("groqtr") and "gemini|gemini-flash-latest" in st and "gemini|gemini-flash-lite-latest" in st
        print("errori:", errs if ok else errs + ["passaggio a Groq non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

let compLang = "";   // lingua del video (dal calcolo delle parole conosciute)
const C = DS_CONFIG;
const $ = (id) => document.getElementById(id);
const DEMO = {
  it: "Quindi ci siamo andati ed era davvero buono", en: "So we went there and it was really good",
  es: "Así que fuimos allí y estaba muy bueno", fr: "Alors on y est allés et c'était vraiment bon",
  de: "Also sind wir hingegangen und es war echt gut", pt: "Então fomos lá e estava muito bom"
};

// 1.6.2: «Traduci in» con tutte le lingue di Google Traduttore, con il nome nella lingua dell'interfaccia e nella lingua stessa
(() => {
  const sel = $("targetLang");
  let ui = null; try { ui = new Intl.DisplayNames([dsUiLocale()], { type: "language" }); } catch {}
  const own = (c) => { try { return new Intl.DisplayNames([c], { type: "language" }).of(c) || ""; } catch { return ""; } };
  const items = C.TARGET_LANGS.map((c) => {
    const n = (ui && ui.of(c)) || c, o = own(c);
    const cap = (x) => x.charAt(0).toUpperCase() + x.slice(1);
    return [c, cap(n) + (o && o.toLowerCase() !== n.toLowerCase() ? " · " + o : "")];
  }).sort((a, b) => a[1].localeCompare(b[1]));
  sel.textContent = "";
  for (const [c, t] of items) sel.append(new Option(t, c));
})();

let s = { ...C.SYNC_DEFAULTS };
let keys = {};

function current() {
  const id = C.ENGINES[s.engine] ? s.engine : "google";
  return { id, E: C.ENGINES[id] };
}

function render() {
  const { id } = current();
  renderCleanInfo();
  renderFallback();
  DS_ENGINES_UI.banner($("blockedBox"), id, () => { renderFallback(); });
}

// ---------- Trascrizione dell'audio ----------
function renderLiveSettings() {
  $("transcribeMode").value = s.autoTranscribe === false ? "off" : (s.transcribeMode || "live");
  $("fullMaxMin").value = s.fullMaxMin || 60;
  $("liveAhead").checked = !!s.liveAhead;
  $("liveAheadDelay").value = String(dsAheadStep(s.liveAheadDelay));
  renderAheadInfo();
  // chi trascrive e con quale modello si sceglie in «📊 Consumo e modelli» (1.6.2): qui solo il promemoria
  $("sttWho").textContent = "Trascrive " + (s.stt === "local" ? "il server Whisper sul tuo computer" : "Groq Whisper") + " con il modello «" + s.sttModel + "». Si cambia in 📊 Consumo e modelli → Trascrizione dell'audio; la chiave di Groq e l'indirizzo del server sono in 🔑 Servizi.";
  fillSttLangs();
}

const LEARN_KEYS = ["learnFreq", "learnKnown", "learnKnownPage", "learnExamples", "learnAudio", "learnTable", "learnGender", "learnSpell", "learnLlmExtra", "learnJisho", "learnGweb", "learnHan", "gdAlt", "gdDefs", "gdSyn", "gdSpell", "ankiImage"];
function updateComp(c) {
  if (c && c.lang) compLang = c.lang;
  const el = $("compInfo");
  if (!c || !c.total || (s && s.learnKnown === false)) { el.hidden = true; return; }
  el.hidden = false;
  el.textContent = c.mine
    ? `Conosci il ${c.pct}% delle parole di questo video (${c.uniqueKnown} parole diverse su ${c.unique}).`
    : "Segna le parole che conosci («la conosco?» nella scheda): qui vedrai quante parole del video conosci.";
}
function updateLiveMode(st) {
  const box = $("liveModeBox");
  box.hidden = !(st && st.onVideo && st.live && st.yt);
  if (box.hidden) return;
  $("liveModeSel").value = s.liveAhead ? "ahead" : "normal";
  const a = st.ahead || {};
  $("liveModeInfo").textContent = !s.liveAhead
    ? "Le frasi si trascrivono mentre le senti: arrivano qualche secondo dopo il parlato."
    : !st.running ? "Parte insieme alla trascrizione: premi «Trascrivi l'audio di questo video» (sezione 🎙 Trascrizione dell'audio)."
    : a.state === "on" ? `Attiva: le frasi sono pronte ${a.lead} s prima che il video arrivi lì.`
    : a.state === "aligning" ? "Sto leggendo l'audio della diretta e lo metto a tempo con il video (qualche secondo)…"
    : a.state === "failed" ? `Non disponibile per questa diretta${a.why ? ": " + a.why : ""}. Resta la trascrizione normale. Serve il programma per yt-dlp aggiornato (rilancia l'installatore dalla sezione 🎙 Trascrizione dell'audio), con ffmpeg.`
    : "Sto avviando la lettura dell'audio della diretta…";
}
// registro della diretta (per segnalare un problema): lo chiedo alla parte della pagina con il video e lo copio
// registro per il debug: quello della pagina (eventi + stato di adesso) e quello del sottofondo (richieste fallite)
function copyDebugLog(b, title, label) {
  withTab((tab) => {
    const done = async (resp) => {
      let bg = "";
      try { bg = ((await chrome.runtime.sendMessage({ type: "getBgLog" })) || {}).log || ""; } catch {}
      let ver = "";
      try { const m = chrome.runtime.getManifest(); ver = m.name + " " + m.version; } catch {}
      const lines = [title + " — " + new Date().toLocaleString(), ver, (resp && resp.url) || (tab && tab.url) || ""];
      if (!resp) lines.push("", "LA PAGINA NON RISPONDE: l'estensione non è attiva in questa scheda (ricarica la pagina con F5; se non basta, il sito potrebbe essere spento nel popup).");
      else {
        if (resp.ahead) lines.push("Sincronizzata: " + JSON.stringify(resp.ahead));
        if (resp.snap) lines.push("", "STATO ADESSO", ...Object.entries(resp.snap).map(([k, v]) => "  " + k + ": " + (typeof v === "object" ? JSON.stringify(v) : v)));
        lines.push("", "EVENTI DELLA PAGINA", resp.log || "(vuoto)");
      }
      lines.push("", "RICHIESTE FALLITE NEL SOTTOFONDO", bg || "(nessuna)");
      try { await navigator.clipboard.writeText(lines.join("\n")); b.textContent = "✓ Registro copiato: incollalo nella segnalazione"; }
      catch { b.textContent = "Non riesco a copiare"; }
      setTimeout(() => { b.textContent = label; }, 4000);
    };
    if (!tab) return done(null);
    chrome.tabs.sendMessage(tab.id, frameTarget ? { type: "getLiveLog", target: frameTarget } : { type: "getLiveLog" }, (resp) => done(chrome.runtime.lastError ? null : resp));
  });
}
$("liveLogCopy").addEventListener("click", (e) => copyDebugLog(e.currentTarget, "Registro della diretta", "📋 Copia il registro della diretta"));
$("debugLogCopy").addEventListener("click", (e) => copyDebugLog(e.currentTarget, "Registro per il debug", "📋 Copia il registro per il debug"));
$("liveModeSel").addEventListener("change", (e) => {
  s.liveAhead = e.target.value === "ahead";
  $("liveAhead").checked = s.liveAhead;
  chrome.storage.sync.set({ liveAhead: s.liveAhead });
  setTimeout(() => askTab({ type: "liveState" }), 400);
});
function updateLive(st) {
  updateComp(st && st.comp);
  updateLiveMode(st);
  // trascrizione in corso (o già fatta): la correzione con Gemini/Groq si accende e spegne da qui
  $("cleanQuick").hidden = !(st && st.onVideo && (st.running || st.full || st.fullBusy));
  if (!$("cleanQuick").hidden) renderCleanInfo();
  if (!st || !st.onVideo) {
    $("liveBtn").disabled = true;
    $("redoBox").hidden = true;
    $("videoMode").disabled = true;
    $("liveInfo").textContent = "In questa pagina non c'è un video o un audio (o va ricaricata dopo l'installazione).";
    return;
  }
  $("liveBtn").disabled = false;
  $("videoMode").disabled = false;
  // trascrizione già fatta (anche solo in parte): si può rifare da capo
  $("redoBox").hidden = !(st.cues > 0 || st.full) || !!st.fullBusy;
  $("redoSttBetter").hidden = !st.better;
  $("videoMode").value = st.mode || "";
  $("liveBtn").textContent = st.running || st.fullBusy ? "Ferma la trascrizione" : "Trascrivi l'audio di questo video";
  if (st.fullBusy) { $("liveInfo").textContent = "Trascrizione completa in corso: " + (st.fullText || "…"); return; }
  if (st.full) { $("liveInfo").textContent = "Questo video è già trascritto per intero."; return; }
  $("liveInfo").textContent = st.running
    ? "Trascrizione in corso: le frasi arrivano con qualche secondo di ritardo."
    : st.hasCaptions === false
      ? "Questo video non ha sottotitoli."
      : st.hasCaptions
        ? "Questo video ha già i sottotitoli: premi CC. Puoi comunque trascrivere l'audio."
        : "L'audio viene trascritto mentre guardi, con qualche secondo di ritardo.";
}

function withTab(fn) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => fn(tabs && tabs[0]));
}

let frameTarget = null;   // la parte della pagina (video) con cui sto parlando
function askTab(message) {
  withTab((tab) => {
    if (!tab) return updateLive(null);
    const msg = message.type === "liveState" || !frameTarget ? message : { ...message, target: frameTarget };
    chrome.tabs.sendMessage(tab.id, msg, (resp) => {
      if (chrome.runtime.lastError) return updateLive(null);
      if (resp && resp.frame) frameTarget = resp.frame;
      updateLive(resp);
    });
  });
}

function showStatus(st) {
  if (st && st.text) $("status").textContent = st.text;
}

function checkPerm() {
  chrome.permissions.contains({ origins: C.HOSTS }, (ok) => { $("perm").hidden = !!ok; });
}

chrome.storage.sync.get(C.SYNC_DEFAULTS, (stored) => {
  s = { ...stored, models: { ...(stored.models || {}) } };
  chrome.storage.local.get({ keys: {}, apiKey: "", status: null }, (l) => {
    keys = { ...(l.keys || {}) };
    if (!keys.claude && l.apiKey) keys.claude = l.apiKey;
    $("targetLang").value = s.targetLang;
    $("uiLang").checked = !!s.uiLang;
    $("enabled").checked = s.enabled;
    $("hideNative").checked = s.hideNative;
    $("fontSize").value = s.fontSize;
    $("hoverPause").checked = s.hoverPause !== false;
    $("idioms").checked = s.idioms === true;
    $("idiomsUnderline").checked = s.idiomsUnderline !== false;
    $("ipa").checked = s.ipa !== false;
    $("etym").checked = s.etym !== false;
    $("roman").checked = !!s.roman;
    $("romanHan").checked = s.romanHan !== false;
    $("ankiPerLang").checked = s.ankiPerLang !== false;
    $("ankiLangDeck").value = s.ankiLangDeck || "Lingue::{lingua}";
    $("ankiDeck").value = s.ankiDeck || "Sottotitoli Doppi";
    $("ankiAuto").checked = !!s.ankiAuto;
    $("ankiAudio").checked = s.ankiAudio !== false;
    ankiRows();
    for (const k of LEARN_KEYS) $(k).checked = k === "ankiImage" ? !!s[k] : s[k] !== false;
    $("cleanMode").value = dsCleanMode(s);
    renderCleanInfo();
    renderLook(); renderCardLook();
    ttsPicker.fill();
    fillVoices();
    $("demo").textContent = DEMO[s.targetLang] || DEMO.en;
    render();
    DS_ENGINES_UI.order($("orderBox"), { onUse: (id) => { s.engine = id; render(); } });
    DS_ENGINES_UI.services($("servicesBox"), { onKey: (id, k, prev) => {
      // la prima chiave incollata mentre i sottotitoli usano ancora Google: i sottotitoli passano a quel servizio
      const first = k[id] && s.engine === "google" && C.ENGINES[id] && C.ENGINES[id].needsKey && !Object.keys(prev || {}).some((x) => prev[x]);
      keys = { ...k };
      if (first) { s.engine = id; chrome.storage.sync.set({ engine: id }); }
      renderCleanInfo(); renderFallback(); renderUse();
    } });
    renderLiveSettings();
    renderConsumo();
    renderUse();
    // Whisper sul computer con il nome di modello di Groq (predefinito): provo subito a prendere quello giusto dal server
    if (s.stt === "local" && (C.STT_MODELS || []).includes(s.sttModel)) chrome.runtime.sendMessage({ type: "sttModels", url: s.sttUrl }).then((r) => { if (r && r.suggested) chrome.storage.sync.set({ sttModel: r.suggested }); }).catch(() => {});
    showStatus(l.status);
    askTab({ type: "liveState" });
  });
});
chrome.storage.onChanged.addListener((changes, area) => {
  // «Modello per ogni compito» (engines-ui.js) cambia anche servizio e trascrizione: aggiorno le sezioni del popup
  if (area === "sync" && s && ((changes.stt && changes.stt.newValue !== s.stt) || changes.sttModel)) {
    if (changes.stt) s.stt = changes.stt.newValue;
    if (changes.sttModel) s.sttModel = changes.sttModel.newValue;
    renderLiveSettings();
  }
  if (area === "local" && changes.keys) { keys = { ...(changes.keys.newValue || {}) }; renderCleanInfo(); renderFallback(); renderUse(); }
  if (area === "local" && changes.dsBlocked && s) render();
  if (area === "sync" && s && changes.engine && changes.engine.newValue && changes.engine.newValue !== s.engine) { s.engine = changes.engine.newValue; render(); }
  if (area === "sync" && s && (changes.engineOrder || changes.engineOff)) {
    if (changes.engineOrder) s.engineOrder = changes.engineOrder.newValue || [];
    if (changes.engineOff) s.engineOff = changes.engineOff.newValue || [];
    renderFallback();
  }
  // «Consumo»: una scelta cambiata (qui o in un'altra parte del popup) può farlo diventare «Personalizzato»
  if (area === "sync" && s) {
    let touched = false;
    for (const k of CONSUMO_KEYS) if (changes[k]) { s[k] = changes[k].newValue; touched = true; }
    if (touched) { renderConsumo(); renderLiveSettings(); $("cleanMode").value = dsCleanMode(s); renderCleanInfo(); $("idioms").checked = s.idioms === true; }
    if (changes.dailyCap) { s.dailyCap = changes.dailyCap.newValue || {}; renderUse(); }
  }
  if (area === "local" && changes.dsUsage) renderUse();
  if (area === "local" && changes.status) {
    showStatus(changes.status.newValue);
    askTab({ type: "liveState" });
  }
});
checkPerm();

$("grant").addEventListener("click", () => chrome.permissions.request({ origins: C.HOSTS }, () => checkPerm()));
$("targetLang").addEventListener("change", (e) => {
  s.targetLang = e.target.value;
  chrome.storage.sync.set({ targetLang: s.targetLang });
  $("demo").textContent = DEMO[s.targetLang] || DEMO.en;
});
$("enabled").addEventListener("change", (e) => chrome.storage.sync.set({ enabled: e.target.checked }));
// interfaccia nella lingua di «Traduci in»: le pagine aperte si aggiornano da sole, il popup si riapre già tradotto
$("uiLang").addEventListener("change", (e) => chrome.storage.sync.set({ uiLang: e.target.checked }, () => setTimeout(() => location.reload(), 150)));
$("hideNative").addEventListener("change", (e) => chrome.storage.sync.set({ hideNative: e.target.checked }));
$("fontSize").addEventListener("input", (e) => chrome.storage.sync.set({ fontSize: Number(e.target.value) }));

$("liveBtn").addEventListener("click", () => {
  const start = $("liveBtn").textContent.startsWith("Trascrivi");
  askTab({ type: "live", action: start ? "start" : "stop" });
});
$("transcribeMode").addEventListener("change", (e) => {
  s.transcribeMode = e.target.value;
  s.autoTranscribe = true;
  chrome.storage.sync.set({ transcribeMode: s.transcribeMode, autoTranscribe: true });
});
$("liveAhead").addEventListener("change", (e) => { s.liveAhead = e.target.checked; chrome.storage.sync.set({ liveAhead: s.liveAhead }); });
$("liveAheadDelay").addEventListener("change", (e) => {
  s.liveAheadDelay = dsAheadStep(e.target.value);
  chrome.storage.sync.set({ liveAheadDelay: s.liveAheadDelay });
  renderAheadInfo();
});
// la spiegazione breve sotto «Quanto indietro guardi la diretta» (i numeri vengono da dsAheadProfile, config.js)
function renderAheadInfo() {
  const p = dsAheadProfile(s.liveAheadDelay);
  $("liveAheadInfo").textContent = `Più indietro guardi, meno richieste: l'audio va a Whisper a pezzi di circa ${p.pieceS} s, e le frasi già pronte ` +
    `aspettano e si traducono insieme (fino a ${p.group}) quando la prima sta per comparire, ${p.trBeforeS} s prima. ` +
    "In cambio vedi la diretta più in ritardo (la chat va avanti rispetto a te).";
}
$("fullMaxMin").addEventListener("change", (e) => {
  s.fullMaxMin = Math.max(1, Number(e.target.value) || 60);
  chrome.storage.sync.set({ fullMaxMin: s.fullMaxMin });
});
function redoStt(precise) {
  if (!confirm("Cancellare la trascrizione di questo video e rifarla da capo?")) return;
  askTab({ type: "redo", what: "transcription", precise });
  $("redoBox").hidden = true;
  setTimeout(() => askTab({ type: "liveState" }), 800);
}
$("redoStt").addEventListener("click", () => redoStt(false));
$("redoSttBetter").addEventListener("click", () => redoStt(true));
$("videoMode").addEventListener("change", (e) => askTab({ type: "setMode", mode: e.target.value }));
$("helperBtn").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("helper.html") }));
// ---------- Lingua parlata: tutte le lingue di Whisper, con ricerca ----------
const STT_NAMES = (() => {
  let it = null, own = null;
  try { it = new Intl.DisplayNames([dsUiLocale()], { type: "language" }); } catch {}
  const fix = { jw: "jv" };   // codice di Whisper diverso da quello standard
  return Object.entries(C.STT_LANGS).map(([code, en]) => {
    const std = fix[code] || code;
    let name = "", native = "";
    try { name = it ? it.of(std) : ""; } catch {}
    try { own = new Intl.DisplayNames([std], { type: "language" }); native = own.of(std); } catch { native = ""; }
    if (!name || name === std) name = en.charAt(0).toUpperCase() + en.slice(1);
    name = name.charAt(0).toUpperCase() + name.slice(1);
    // senza i dati di quella lingua il browser restituisce il nome inglese: non lo mostro
    if (native && (native.toLowerCase() === name.toLowerCase() || native.toLowerCase() === en || native === std)) native = "";
    return { code, name, native, en, key: [name, native, en, code].join(" ").toLowerCase().normalize("NFD").replace(/\p{M}/gu, "") };
  }).sort((a, b) => a.name.localeCompare(b.name, "it"));
})();

// Menu di lingua con ricerca (usato per la lingua parlata e per quella della pronuncia)
function langPicker(o) {
  // o = { id, empty, emptyNow, key }: id = prefisso degli elementi (select #id, ricerca #idSearch, #idNow, #idHint)
  const sel = $(o.id), search = $(o.id + "Search");
  const norm = (x) => x.trim().toLowerCase().normalize("NFD").replace(/\p{M}/gu, "");
  const fill = (filter = "") => {
    const q = norm(filter), chosen = s[o.key] || "";
    const list = q ? STT_NAMES.filter((l) => l.key.includes(q)) : STT_NAMES;
    sel.textContent = "";
    if (!q || norm(o.empty + " automatica auto").includes(q)) sel.append(new Option(o.empty, ""));
    for (const l of list) sel.append(new Option(l.native ? `${l.name} · ${l.native}` : l.name, l.code));
    // la lingua scelta resta in cima anche se non è tra i risultati, così resta selezionata
    if (q && chosen && !list.some((l) => l.code === chosen)) {
      const cur = STT_NAMES.find((l) => l.code === chosen);
      if (cur) sel.prepend(new Option(cur.name + " (scelta ora)", cur.code));
    }
    sel.value = chosen;
    if (q) sel.size = Math.max(2, Math.min(7, sel.options.length)); else sel.removeAttribute("size");
    $(o.id + "Hint").hidden = !q || list.length > 0;
    const cur = STT_NAMES.find((l) => l.code === chosen);
    $(o.id + "Now").textContent = cur ? "· " + cur.name : "· " + o.emptyNow;
  };
  const choose = (code) => {
    s[o.key] = code || "";
    chrome.storage.sync.set({ [o.key]: s[o.key] });
    search.value = "";
    fill();
    if (o.onChange) o.onChange();
  };
  sel.addEventListener("change", () => choose(sel.value));
  sel.addEventListener("click", (e) => { if (sel.size > 1 && e.target.tagName === "OPTION") choose(e.target.value); });
  sel.addEventListener("keydown", (e) => { if (e.key === "Enter" && sel.size > 1) { e.preventDefault(); choose(sel.value); } });
  search.addEventListener("input", () => fill(search.value));
  search.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const first = [...sel.options].find((x) => !x.text.endsWith("(scelta ora)"));
      if (search.value.trim() && first) choose(first.value);
    } else if (e.key === "ArrowDown" && sel.size > 1) { e.preventDefault(); sel.focus(); sel.selectedIndex = 0; }
    else if (e.key === "Escape" && search.value) { e.preventDefault(); search.value = ""; fill(); }
  });
  return { fill: () => fill(search.value) };
}
const sttPicker = langPicker({ id: "sttLang", key: "sttLang", empty: "Rileva da sola", emptyNow: "rilevata da sola" });
const fillSttLangs = () => sttPicker.fill();

// ---------- Vocabolario ----------
function showVocabCount() {
  chrome.storage.local.get({ vocab: {} }, (r) => {
    const n = Object.keys(r.vocab || {}).length;
    $("vocabBtn").textContent = n ? `📒 Vocabolario (${n})` : "📒 Vocabolario";
    $("vocabBtn").title = n ? `Le ${n} parole e frasi salvate con ☆` : "Le parole e le frasi salvate con ☆";
  });
}
showVocabCount();
// ---------- Anki ----------
function ankiRows() { const on = $("ankiPerLang").checked; $("ankiLangDeckRow").hidden = !on; $("ankiDeckRow").hidden = on; }
$("ankiPerLang").addEventListener("change", (e) => { s.ankiPerLang = e.target.checked; chrome.storage.sync.set({ ankiPerLang: e.target.checked }); ankiRows(); });
$("ankiLangDeck").addEventListener("change", (e) => chrome.storage.sync.set({ ankiLangDeck: e.target.value.trim() || "Lingue::{lingua}" }));
$("ankiDeck").addEventListener("change", (e) => chrome.storage.sync.set({ ankiDeck: e.target.value.trim() || "Sottotitoli Doppi" }));
$("ankiAuto").addEventListener("change", (e) => { s.ankiAuto = e.target.checked; chrome.storage.sync.set({ ankiAuto: e.target.checked }); });
$("ankiAudio").addEventListener("change", (e) => { s.ankiAudio = e.target.checked; chrome.storage.sync.set({ ankiAudio: e.target.checked }); });
$("ankiTest").addEventListener("click", () => {
  const st = $("ankiStatus");
  st.textContent = "Collego… (se Anki chiede il permesso, premi Yes)";
  chrome.runtime.sendMessage({ type: "ankiCheck" }, (r) => {
    if (chrome.runtime.lastError) r = { error: chrome.runtime.lastError.message };
    st.textContent = r && !r.error ? `Collegato ad Anki (AnkiConnect ${r.version}). Tipo di nota: ${r.model}. Per esempio le parole inglesi vanno nel mazzo «${r.example}».` : (r && r.error) || "Nessuna risposta.";
  });
});
$("vocabBtn").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("vocab.html") }));
// elenco delle parole più usate (con le parole che conosci) nella lingua del video, o in quella con più parole conosciute
$("freqBtn").addEventListener("click", async () => {
  let lang = compLang;
  if (!lang) {
    const kw = (await DS_EXT.storage.local.get({ knownWords: {} })).knownWords || {};
    lang = Object.keys(kw).sort((a, b) => String(kw[b]).split("\n").length - String(kw[a]).split("\n").length)[0] || "en";
  }
  chrome.tabs.create({ url: chrome.runtime.getURL("freq.html") + "?lang=" + encodeURIComponent(String(lang).split("-")[0]) + "&target=" + encodeURIComponent((s && s.targetLang) || "it") });
});
$("hoverPause").addEventListener("change", (e) => chrome.storage.sync.set({ hoverPause: e.target.checked }));
$("idioms").addEventListener("change", (e) => chrome.storage.sync.set({ idioms: e.target.checked }));
$("idiomsUnderline").addEventListener("change", (e) => chrome.storage.sync.set({ idiomsUnderline: e.target.checked }));
$("ipa").addEventListener("change", (e) => chrome.storage.sync.set({ ipa: e.target.checked }));
$("etym").addEventListener("change", (e) => chrome.storage.sync.set({ etym: e.target.checked }));
$("roman").addEventListener("change", (e) => chrome.storage.sync.set({ roman: e.target.checked }));
$("romanHan").addEventListener("change", (e) => chrome.storage.sync.set({ romanHan: e.target.checked }));
for (const k of LEARN_KEYS) $(k).addEventListener("change", (e) => { s[k] = e.target.checked; chrome.storage.sync.set({ [k]: e.target.checked }); if (k === "learnKnown") askTab({ type: "liveState" }); });
$("fallback").addEventListener("change", (e) => { s.fallback = e.target.checked; chrome.storage.sync.set({ fallback: e.target.checked }); renderFallback(); });

// Quali servizi di riserva sono pronti (hanno la chiave) e quali hanno finito le richieste di oggi
function renderFallback() {
  $("fallback").checked = s.fallback !== false;
  chrome.storage.local.get({ dsBlocked: {} }, (r) => {
    const day = (() => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return ""; } })();
    const name = (id) => C.ENGINES[id].label.split(" (")[0].split(",")[0];
    const ready = C.engineOrder(s).filter((id) => keys[id] || (C.ENGINES[id].local && (s.models || {})[id]));
    const parts = ready.map((id) => { const b = dsBlockState(r.dsBlocked, id, s, day); return name(id) + (b.all ? " (finite per oggi)" : b.models.length ? " (finito oggi: " + b.models.join(", ") + ")" : ""); });
    $("fallbackInfo").textContent = s.fallback === false ? "" : ready.length
      ? "Servizi con la chiave, in quest'ordine: " + parts.join(", ") + ". Poi Google Traduttore."
      : "Per avere servizi di riserva, scegli Groq, Mistral o OpenRouter qui sopra e inserisci la loro chiave gratuita (poi torna al servizio che preferisci).";
  });
}
for (const id of ["cleanMode", "cleanMode2"]) $(id).addEventListener("change", (e) => {
  s.cleanMode = e.target.value;
  s.cleanTranscript = e.target.value !== "off";
  $("cleanMode").value = $("cleanMode2").value = e.target.value;
  chrome.storage.sync.set({ cleanMode: s.cleanMode, cleanTranscript: s.cleanTranscript });
  renderCleanInfo();
});

// Chi corregge la trascrizione (stessa scelta di cleanerEngine in content.js)
function renderCleanInfo() {
  const E = C.ENGINES[s.engine] || C.ENGINES.google;
  const name = E.label.split(" (")[0].split(",")[0];
  let t;
  const mode = dsCleanMode(s);
  if (mode === "off") t = "Spenta: le frasi restano come le ha capite Whisper.";
  else if (E.kind === "openai" || E.kind === "claude") t = `La fa ${name} nella stessa richiesta della traduzione: nessuna richiesta in più.`;
  else if (keys.gemini) t = "La fa Gemini con la tua chiave, a gruppi di frasi (una richiesta ogni 10-30 frasi). Intanto vedi la traduzione rapida; poi traduce " + name + " il testo corretto.";
  else if (keys.groq) t = "La fa Groq (stessa chiave della trascrizione), a gruppi di frasi (una richiesta ogni 10-30 frasi). Intanto vedi la traduzione rapida; poi traduce " + name + " il testo corretto.";
  else t = "Per correggerla serve una chiave Gemini o Groq (nella sezione Traduzione o qui sopra).";
  // solo frasi incerte: si correggono quelle di cui Whisper non è sicuro (con un modello che traduce non cambia niente)
  if (mode === "uncertain" && !(E.kind === "openai" || E.kind === "claude") && (keys.gemini || keys.groq)) t += " Solo le frasi di cui Whisper non è sicuro: circa metà delle richieste.";
  $("cleanInfo").textContent = t;
  $("cleanInfo2").textContent = t;
  $("cleanMode2").value = mode;
}

// ---------- Pronuncia ----------
async function fillVoices() {
  const voices = await DS_TTS.voicesReady();
  const lang = s.ttsLang || "";
  const group = $("ttsVoices");
  group.textContent = "";
  const list = voices
    .filter((v) => !lang || DS_TTS.base(v.lang) === lang)
    .sort((a, b) => a.lang.localeCompare(b.lang) || a.name.localeCompare(b.name));
  for (const v of list) {
    const o = document.createElement("option");
    o.value = v.voiceURI;
    o.textContent = `${v.name} (${v.lang})`;
    group.append(o);
  }
  group.label = list.length ? "Voci installate sul computer" : "Nessuna voce installata per questa lingua";
  const saved = s.ttsVoice || "";
  $("ttsVoice").value = saved;
  if ($("ttsVoice").value !== saved) $("ttsVoice").value = ""; // la voce salvata non è di questa lingua
  if (lang && !list.length) {
    $("ttsInfo").textContent = C.GOOGLE_TTS.includes(lang)
      ? "Sul computer non c'è una voce per questa lingua: in automatico verrà usata quella di Google."
      : "Per questa lingua non c'è una voce né sul computer né su Google, quindi la pronuncia non è disponibile. " +
        "Puoi aggiungere una voce al computer (Windows: Impostazioni → Ora e lingua → Voce) e poi riaprire questo menu.";
  } else {
    $("ttsInfo").textContent = "";
  }
}

const ttsPicker = langPicker({ id: "ttsLang", key: "ttsLang", empty: "Automatica (quella del video)", emptyNow: "quella del video", onChange: () => fillVoices() });
$("ttsVoice").addEventListener("change", (e) => {
  s.ttsVoice = e.target.value;
  chrome.storage.sync.set({ ttsVoice: s.ttsVoice });
});
$("ttsTest").addEventListener("click", async () => {
  const lang = s.ttsLang || "en";
  // per le lingue senza frase di prova dico il nome della lingua nella lingua stessa
  const own = STT_NAMES.find((l) => l.code === lang);
  const text = C.TTS_SAMPLES[lang] || (own && (own.native || own.name)) || C.TTS_SAMPLES.en;
  $("ttsInfo").textContent = "…";
  let r;
  try { r = await DS_TTS.speak(text, lang, { lang: s.ttsLang || "", voice: $("ttsVoice").value }); }
  catch (e) { $("ttsInfo").textContent = "Pronuncia non disponibile: " + (e.message || e); return; }
  $("ttsInfo").textContent = "Usata: " + r.how + (s.ttsLang ? "" : ". In automatico la lingua è quella del video; per la prova uso l'inglese.");
});

// ---------- Aspetto dei sottotitoli ----------
const LOOK = ["subShow", "transFirst", "fontSize", "transScale", "origColor", "transColor", "bgOpacity", "subPos", "subFont", "romanSize", "romanLineSize"];
const romanSizeShow = () => { for (const k of ["romanSize", "romanLineSize"]) $(k + "Val").textContent = $(k).value + "%"; };
function renderLook() {
  for (const k of LOOK) {
    const el = $(k);
    if (el.type === "checkbox") el.checked = !!s[k];
    else el.value = s[k] != null ? s[k] : C.SYNC_DEFAULTS[k];
  }
  romanSizeShow();
}
for (const k of LOOK) {
  const el = $(k);
  el.addEventListener(el.type === "range" || el.type === "color" ? "input" : "change", () => {
    const v = el.type === "checkbox" ? el.checked : el.type === "range" ? Number(el.value) : el.value;
    s[k] = v;
    chrome.storage.sync.set({ [k]: v });
    if (k === "romanSize" || k === "romanLineSize") romanSizeShow();
  });
}
$("resetLook").addEventListener("click", () => {
  const d = {};
  for (const k of LOOK) d[k] = C.SYNC_DEFAULTS[k];
  Object.assign(s, d);
  chrome.storage.sync.set(d);
  renderLook(); renderCardLook();
});

// ---------- Aspetto delle schede (video e pagine) ----------
const CARDLOOK = ["cardScale", "cardWidth", "cardBg", "cardOpacity", "cardText", "cardAccent", "cardPosVideo", "cardPosPage"];
const cardShow = () => { $("cardScaleVal").textContent = $("cardScale").value + "%"; $("cardWidthVal").textContent = $("cardWidth").value + "%"; };
function renderCardLook() {
  for (const k of CARDLOOK) $(k).value = s[k] != null ? s[k] : C.SYNC_DEFAULTS[k];
  cardShow();
  // la posizione sulle pagine c'è solo nell'estensione unica (Parole al Volo)
  $("cardPosPageRow").hidden = !document.getElementById("p-dPages");
}
for (const k of CARDLOOK) {
  const el = $(k);
  el.addEventListener(el.type === "range" || el.type === "color" ? "input" : "change", () => {
    const v = el.type === "range" ? Number(el.value) : el.value;
    s[k] = v;
    chrome.storage.sync.set({ [k]: v });
    cardShow();
  });
}
$("resetCardLook").addEventListener("click", () => {
  const d = {};
  for (const k of CARDLOOK) d[k] = C.SYNC_DEFAULTS[k];
  Object.assign(s, d);
  chrome.storage.sync.set(d);
  renderCardLook();
});

// ---------- Pagina della trascrizione ----------
$("transcriptBtn").addEventListener("click", () => {
  withTab((tab) => {
    const q = tab && tab.id != null ? "?tab=" + tab.id : "";
    chrome.tabs.create({ url: chrome.runtime.getURL("transcript.html" + q) });
  });
});

// ---------- Attiva / disattiva su questo sito ----------
withTab((tab) => {
  let host = "";
  try { host = tab && tab.url ? new URL(tab.url).hostname : ""; } catch {}
  if (!host) return;
  $("siteRow").hidden = false;
  $("siteLabel").textContent = "Attiva su " + host;
  chrome.storage.sync.get({ disabledSites: [] }, (r) => {
    $("siteOn").checked = !(r.disabledSites || []).includes(host);
  });
  $("siteOn").addEventListener("change", (e) => {
    chrome.storage.sync.get({ disabledSites: [] }, (r) => {
      const list = new Set(r.disabledSites || []);
      if (e.target.checked) list.delete(host); else list.add(host);
      chrome.storage.sync.set({ disabledSites: [...list] });
    });
  });
});

// da dove prendere le immagini per le carte di Anki
(() => {
  const sel = document.getElementById("ankiImageSource");
  if (!sel) return;
  DS_EXT.storage.sync.get({ ankiImageSource: "auto" }).then((r) => { sel.value = r.ankiImageSource || "auto"; }).catch(() => {});
  sel.addEventListener("change", () => DS_EXT.storage.sync.set({ ankiImageSource: sel.value }));
})();

// ---------- «Consumo delle richieste» e «📊 Consumo e modelli» ----------
const CONSUMO_KEYS = ["consumo", "liveAheadDelay", "cleanMode", "cleanTranscript", "idioms", "idiomAuto", "taskModels", "liveAheadMax"];
const CONSUMO_INFO = {
  quality: "Diretta 20 s indietro, correzione di tutte le frasi trascritte, modi di dire e collegamento tra le parole trovati dal modello, Gemini Flash per tutto. Più richieste: circa 150-250 a Gemini per ogni ora di diretta.",
  balanced: "Diretta 45 s indietro, correzione solo delle frasi incerte, Gemini Flash-Lite per tradurre e Flash per le spiegazioni (i limiti gratuiti di Gemini sono per modello: così si dividono). Circa 60-90 richieste per ora di diretta; un video con i sottotitoli circa 10.",
  saving: "Diretta 90 s indietro (gruppi di frasi più grandi), niente correzione della trascrizione, Flash-Lite per tradurre. Circa 30-60 richieste per ora di diretta; un video con i sottotitoli circa 10.",
  free: "Traduce Google Traduttore; la trascrizione dei video senza sottotitoli parte solo se la avvii tu. I modelli lavorano solo quando premi un pulsante (per esempio «✨ Spiega con…»). Il servizio scelto per tradurre resta salvato.",
  custom: "Hai cambiato a mano una delle scelte (diretta, correzione, modi di dire o modelli). Scegli una modalità per tornare ai suoi valori."
};
function renderConsumo() {
  const m = dsConsumoOf(s);
  $("consumo").value = m;
  $("consumoInfo").textContent = CONSUMO_INFO[m] || "";
}
$("consumo").addEventListener("change", async (e) => {
  const v = dsConsumoValues(e.target.value, s.taskModels);
  if (!v) return;
  Object.assign(s, v);
  await chrome.storage.sync.set(v);
  renderConsumo();
});
$("liveAheadMax").addEventListener("change", (e) => { s.liveAheadMax = Number(e.target.value) || 90; chrome.storage.sync.set({ liveAheadMax: s.liveAheadMax }); });
// richieste di oggi per servizio (le conta il sottofondo) e limite al giorno scelto da te
async function renderUse() {
  $("liveAheadMax").value = String([60, 90, 150, 240].includes(Number(s.liveAheadMax)) ? Number(s.liveAheadMax) : 90);
  const l = await chrome.storage.local.get({ dsUsage: null });
  const u = l.dsUsage;
  const day = (() => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return ""; } })();
  const n = u && u.day === day ? u.n || {} : {};
  const name = (id) => (id === "whisper" ? "Groq Whisper" : C.ENGINES[id] ? (C.ENGINES[id].local ? "Modello sul computer" : C.ENGINES[id].label.split(" (")[0].split(",")[0]) : id);
  const cap = s.dailyCap || {};
  const parts = Object.entries(n).filter(([, v]) => v > 0).map(([id, v]) => name(id) + " " + v + (cap[id] ? "/" + cap[id] : ""));
  $("usageBox").textContent = "Richieste di oggi: " + (parts.length ? parts.join(" · ") : "nessuna") + ". (Il giorno delle quote finisce a mezzanotte in California, verso le 9 in Italia.)";
  // limiti: per i servizi con la chiave (o il modello sul computer) e per Groq Whisper
  const ids = Object.keys(C.ENGINES).filter((id) => id !== "google" && id !== "youtube" && (keys[id] || (C.ENGINES[id].local && (s.models || {})[id])));
  if (keys.groq) ids.push("whisper");
  const box = $("capRows");
  box.textContent = "";
  if (!ids.length) { box.append(Object.assign(document.createElement("p"), { className: "small", textContent: "Nessun servizio con la chiave." })); return; }
  for (const id of ids) {
    const lab = document.createElement("label"); lab.className = "row"; lab.textContent = name(id) + " ";
    const inp = document.createElement("input"); inp.type = "number"; inp.min = "0"; inp.step = "10"; inp.placeholder = "nessuno";
    inp.style.cssText = "width:80px;background:var(--panel);color:var(--paper);border:1px solid var(--line);border-radius:6px;padding:4px 6px";
    inp.value = cap[id] ? String(cap[id]) : "";
    inp.addEventListener("change", () => {
      const c = { ...(s.dailyCap || {}) };
      const v = Math.max(0, Math.round(Number(inp.value) || 0));
      if (v) c[id] = v; else delete c[id];
      s.dailyCap = c;
      chrome.storage.sync.set({ dailyCap: c });
    });
    lab.append(inp);
    box.append(lab);
  }
}

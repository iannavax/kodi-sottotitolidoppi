# Diretta HLS finta, fatta come quella di YouTube: playlist principale -> variante, indirizzi senza estensione,
# pezzi MPEG-TS di 2 s; la "diretta" avanza in tempo reale partendo da FAKE_LIVE_OFFSET secondi dell'audio.
# Uso: python3 hls_server.py <porta>   (l'audio è FAKE_LIVE_AUDIO, /tmp/speech.wav)
import os, sys, glob, subprocess, time, http.server, threading
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8799
AUD = os.environ.get("FAKE_LIVE_AUDIO", "/tmp/speech.wav")
OFF = float(os.environ.get("FAKE_LIVE_OFFSET", "15"))
D = "/tmp/fakehls"; SEG = 2.0
if not os.path.exists(D + "/s0.ts"):
    os.makedirs(D, exist_ok=True)
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", "color=c=black:s=64x36:r=10", "-i", AUD, "-shortest",
                    "-c:v", "libx264", "-g", "20", "-c:a", "aac", "-f", "segment", "-segment_time", str(SEG),
                    "-segment_format", "mpegts", D + "/s%d.ts"], check=True)
N = len(glob.glob(D + "/s*.ts")); T0 = [None]; LOG = os.environ.get("FAKE_HLS_LOG", "/tmp/fakehls.log")
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): open(LOG, "a").write(self.path + "\n")
    def send(self, body, ct):
        self.send_response(200); self.send_header("Content-Type", ct); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        p = self.path
        if p.startswith("/api/manifest/hls_variant"):
            self.send(b"#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=900000,CODECS=\"avc1.4d401e,mp4a.40.2\"\n/api/manifest/hls_playlist/itag/93/playlist/index\n"
                      b"#EXT-X-STREAM-INF:BANDWIDTH=290000,CODECS=\"avc1.4d400c,mp4a.40.5\"\n/api/manifest/hls_playlist/itag/91/playlist/index\n", "application/vnd.apple.mpegurl")
        elif p.startswith("/api/manifest/hls_playlist"):
            if T0[0] is None: T0[0] = time.time()
            edge = int((OFF + time.time() - T0[0]) / SEG)          # pezzi completi fino a qui
            hi = min(edge, N); lo = max(0, hi - int(os.environ.get("FAKE_HLS_WINDOW") or 6))   # pezzi nella playlist (DVR)
            body = "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:%d\n" % lo
            for i in range(lo, hi): body += "#EXTINF:2.0,\n/videoplayback/id/x/itag/91/sq/%d/file/seg\n" % i
            if hi >= N: body += "#EXT-X-ENDLIST\n"
            self.send(body.encode(), "application/vnd.apple.mpegurl")
        elif p.startswith("/videoplayback/") and os.environ.get("FAKE_HLS_403"):
            self.send_response(403); self.end_headers()   # come YouTube con l'indirizzo del lettore web (manca il «gettone»)
        elif p.startswith("/videoplayback/"):
            i = int(p.split("/sq/")[1].split("/")[0]); self.send(open(D + "/s%d.ts" % i, "rb").read(), "video/mp2t")
        else:
            self.send_response(404); self.end_headers()
http.server.ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()

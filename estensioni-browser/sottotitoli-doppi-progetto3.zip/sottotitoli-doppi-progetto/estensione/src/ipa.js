// Pronuncia in alfabeto fonetico internazionale (IPA) sotto la frase originale.
// Google non la dà, quindi la chiedo a un modello (Groq o Gemini) UNA volta per parola: chiedo insieme
// le parole nuove della frase che stai vedendo e delle prossime (fino a 300 per richiesta) e le salvo.
// Le parole già viste, anche in altri video, non costano più niente. Si accende e spegne con il pulsante
// "IPA" accanto ai sottotitoli o nel popup (Aspetto).
let lineIpa = null;
const ipaCache = new Map();          // "lingua|parola" → IPA ("" = il modello non l'ha data)
const ipaPending = new Set();
const ipaSkip = {};   // servizio → fino a quando non usarlo per la pronuncia (limite raggiunto)
let ipaProblem = "", ipaBusy = false, ipaFailedAt = 0, ipaLastAt = 0, ipaSince = 0, ipaSaveTimer = 0, ipaKey = "";
let ipaReady = DS_EXT.storage.local.get({ ipaCache: {}, ipaCacheV: 0 }).then((r) => {
  // 5.17: prima a volte si salvava la pronuncia di un'altra forma della parola (гордую ← гордый): ricomincio da capo, una volta
  if (r.ipaCacheV !== 2) { DS_EXT.storage.local.set({ ipaCache: {}, ipaCacheV: 2 }).catch(() => {}); return; }
  for (const [k, v] of Object.entries(r.ipaCache || {})) if (!ipaCache.has(k)) ipaCache.set(k, v);
}).catch(() => {});

const ipaOn = () => !!settings && settings.ipa !== false;
const ipaLang = (lang, text) => String(lang || DualSubs.guessLang(text || "") || "auto").split("-")[0].toLowerCase();
const ipaK = (lang, w) => lang + "|" + String(w || "").toLowerCase();
function ipaOf(word, lang) {
  const v = ipaCache.get(ipaK(ipaLang(lang, word), word));
  return v || "";
}
function ipaWordsOf(text, lang) {
  return wordsTokenize(text || "", lang).filter((p) => p.word).map((p) => p.text);
}

function ipaSave() {
  clearTimeout(ipaSaveTimer);
  ipaSaveTimer = setTimeout(() => {
    // al massimo 30000 parole: tolgo le più vecchie
    while (ipaCache.size > 30000) ipaCache.delete(ipaCache.keys().next().value);
    DS_EXT.storage.local.set({ ipaCache: Object.fromEntries(ipaCache) }).catch(() => {});
  }, 1500);
}

// Chi scrive la pronuncia: preferisco un servizio diverso da quello che traduce (così non rallento la traduzione)
function ipaEngine() {
  if (!settings) return null;
  // prima Gemini (molti token al giorno e al minuto), poi Groq (i suoi token servono anche alla correzione della
  // trascrizione e finiscono presto). Solo questi due: gli altri servizi restano di riserva per la traduzione.
  // Un servizio che ha appena detto "limite raggiunto" viene saltato per un po' (ipaSkip).
  for (const id of ["gemini", "groq"]) {
    if (!C.ENGINES[id] || dsIsBlocked(id) || (ipaSkip[id] || 0) > Date.now()) continue;
    const e = engineById(id);
    if (dsReady(e)) return e;
  }
  return null;
}

// Le frasi che verranno dopo quella mostrata (anche non ancora tradotte)
function ipaUpcoming(cur, n) {
  const out = [];
  if (!cur) return out;
  if (cur.live && live && live.cues) {
    for (const c of live.cues) { if (out.length >= n) break; if (c.start > cur.start && !c.removed && c.text) out.push(c.text); }
  } else if (track && track.segments) {
    for (const sg of track.segments) { if (out.length >= n) break; if (sg.start > cur.start && sg.text) out.push(sg.text); }
  }
  return out;
}

function ipaMissing(cur) {
  const lang = ipaLang(cur.lang, cur.text);
  return ipaWordsOf(cur.text, cur.lang).filter((w) => !ipaCache.has(ipaK(lang, w)) && !ipaPending.has(ipaK(lang, w)));
}

// Chiamata a ogni giro di tick: se nella frase mostrata mancano parole, parte una richiesta (una alla volta)
function ipaTick(cur) {
  if (!ipaOn() || !cur || !cur.text || ipaBusy) return;
  if (Date.now() - ipaFailedAt < 60000) return;
  // trascrizione mentre guardi: le frasi arrivano una alla volta, quindi raccolgo le parole nuove per 40 secondi
  // (al massimo una richiesta ogni 40 s; le prime frasi restano un attimo senza pronuncia)
  if (cur.live && Date.now() - ipaLastAt < 40000) return;
  if (!ipaMissing(cur).length) return;
  // nei primi secondi dopo l'apertura del video lascio partire prima la traduzione. Dopo non aspetto che finisca:
  // con un film lungo ci vogliono minuti e la riga restava vuota. La richiesta si mette in fila con le altre dello
  // stesso servizio (una ogni 300 parole nuove, quindi rallenta la traduzione di pochissimo).
  if (!ipaSince) ipaSince = Date.now();
  if (Date.now() - ipaSince < 3000) return;
  ipaRequest(cur, false);
}

async function ipaRequest(cur, priority, extraWords) {
  const e = ipaEngine();
  if (!e) { ipaFailedAt = Date.now(); ipaProblem = "serve la chiave di Groq o di Gemini (popup → Traduzione)"; ipaKey = ""; return; }
  await ipaReady;
  const lang = ipaLang(cur.lang, cur.text);
  const words = [];
  const seen = new Set();
  const add = (w) => {
    const k = ipaK(lang, w);
    if (words.length >= 300 || seen.has(k) || ipaCache.has(k) || ipaPending.has(k)) return;
    seen.add(k); words.push(w);
  };
  (extraWords || []).forEach(add);
  // dalla scheda di una parola: solo quella parola (niente frase intera, niente frasi seguenti)
  if (priority) {
    if (!words.length) return;
  } else ipaWordsOf(cur.text, cur.lang).forEach(add);
  if (!priority) for (const t of ipaUpcoming(cur, 80)) ipaWordsOf(t, cur.lang).forEach(add);
  // trascrizione mentre guardi: anche le frasi appena passate (arrivate durante l'attesa)
  if (!priority && cur.live && live && live.cues) for (const c of live.cues.slice(-40)) if (!c.removed && c.text) ipaWordsOf(c.text, cur.lang).forEach(add);
  if (!words.length) return;
  const keys = words.map((w) => ipaK(lang, w));
  keys.forEach((k) => ipaPending.add(k));
  ipaBusy = true;
  ipaLastAt = Date.now();
  let resp;
  try {
    resp = await DS_EXT.runtime.sendMessage({ type: "ipa", engine: e.id, key: e.key, model: e.model, localUrl: e.localUrl,
      lang: lang === "auto" ? "" : lang, words, sentence: cur.text, priority });
  } catch (err) { resp = { error: String(err.message || err) }; }
  ipaBusy = false;
  keys.forEach((k) => ipaPending.delete(k));
  if (!resp || resp.error) {
    // limite raggiunto (del giorno, dell'ora o dei token al minuto): salto questo servizio e provo subito l'altro
    if (resp && (resp.daily || resp.rateLimited || resp.tooLarge || resp.hourly)) {
      if (resp.daily) dsMarkBlocked(e.id);
      ipaSkip[e.id] = Date.now() + (resp.daily ? 6 * 3600e3 : Math.max(120e3, (resp.retryAfter || 0) * 1000));
      const other = ipaEngine();
      if (other && other.id !== e.id) { ipaProblem = ""; ipaKey = ""; return ipaRequest(cur, priority, extraWords); }
    }
    ipaFailedAt = Date.now();
    ipaProblem = (e.E.label.split(" (")[0].split(",")[0]) + ": " + ((resp && resp.error) || "nessuna risposta") + " (riprovo tra un minuto)";
    setStatus("Pronuncia IPA non riuscita — " + ipaProblem);
    ipaKey = "";
    return;
  }
  const got = resp.ipa || {};
  const n = Object.keys(got).length;
  for (const w of words) {
    const v = got[w];
    // parola che il modello ha saltato: la segno vuota solo se la risposta era buona per il resto
    if (typeof v === "string" && v) ipaCache.set(ipaK(lang, w), v);
    else if (n >= words.length * 0.6) ipaCache.set(ipaK(lang, w), "");
  }
  if (!n) { ipaFailedAt = Date.now(); ipaProblem = "il servizio ha risposto senza pronunce (riprovo tra un minuto)"; }
  else ipaProblem = "";
  ipaSave();
  ipaKey = "";
  if (wordsCard && wordsCardState) wordsFillCard();
}

// La riga sotto l'originale: una parte per parola, nello stesso ordine (passando su una parola si illumina la sua)
function ipaRender(cur) {
  if (!lineIpa) return;
  const on = ipaOn() && !!cur && !!cur.text;
  if (!on) { if (lineIpa.textContent) lineIpa.textContent = ""; ipaKey = ""; return; }
  const lang = ipaLang(cur.lang, cur.text);
  const words = ipaWordsOf(cur.text, cur.lang);
  const vals = words.map((w) => ipaCache.get(ipaK(lang, w)));
  const key = cur.text + "\u0001" + vals.join("\u0002") + "\u0001" + ipaProblem;
  if (key === ipaKey) return;
  ipaKey = key;
  lineIpa.textContent = "";
  if (vals.every((v) => v === undefined || v === "")) {
    if (!ipaEngine()) ipaProblem = "serve la chiave di Groq o di Gemini (popup → Traduzione)";
    if (ipaProblem && vals.some((v) => v === undefined)) {
      // perché manca: si legge passando il mouse sui sottotitoli (così non disturba chi non la usa)
      lineIpa.append(Object.assign(document.createElement("span"), { className: "dualsub-ipa-hint", textContent: "IPA: " + ipaProblem }));
    } else if (vals.some((v) => v === undefined) && Date.now() - ipaFailedAt > 60000) lineIpa.append(Object.assign(document.createElement("span"), { className: "dualsub-ipa-wait", textContent: "…" }));
    return;
  }
  words.forEach((w, i) => {
    if (i) lineIpa.append(" ");
    const s = document.createElement("span");
    s.className = "dualsub-ipaw";
    s.textContent = vals[i] || (vals[i] === "" ? w : "…");
    if (!vals[i]) s.classList.add("dualsub-ipa-none");
    lineIpa.append(s);
  });
}

function ipaSetup() {
  // passando su una parola dell'originale si illumina la sua pronuncia, e viceversa
  const pair = (e, on) => {
    const w = e.target.closest && e.target.closest(".dualsub-word, .dualsub-ipaw");
    if (!w || !lineIpa) return;
    const isIpa = w.classList.contains("dualsub-ipaw");
    const a = [...(isIpa ? lineIpa : lineOrig).querySelectorAll(isIpa ? ".dualsub-ipaw" : ".dualsub-word")];
    const b = [...(isIpa ? lineOrig : lineIpa).querySelectorAll(isIpa ? ".dualsub-word" : ".dualsub-ipaw")];
    const o = b[a.indexOf(w)];
    if (o) o.classList.toggle("dualsub-ipa-hl", on);
    if (isIpa) w.classList.toggle("dualsub-ipa-hl", on);
  };
  overlay.addEventListener("mouseover", (e) => pair(e, true));
  overlay.addEventListener("mouseout", (e) => pair(e, false));
}

function ipaButton() {
  const b = document.createElement("button");
  b.className = "dualsub-fixbtn dualsub-ipabtn";
  b.textContent = "IPA";
  b.addEventListener("click", async (e) => {
    e.stopPropagation();
    const on = !ipaOn();
    ipaFailedAt = 0;
    settings.ipa = on;
    ipaKey = "";
    ipaRender(wordsCurrent);
    ipaButtonUpdate();
    if (on && !ipaEngine()) setStatus("Pronuncia IPA: serve la chiave di Groq o Gemini (popup → Traduzione).");
    else setStatus(on ? "Pronuncia IPA accesa." : "Pronuncia IPA spenta: nessuna richiesta in più.");
    await DS_EXT.storage.sync.set({ ipa: on });
  });
  return b;
}
function ipaButtonUpdate() {
  const b = overlay && overlay.querySelector(".dualsub-ipabtn");
  if (!b) return;
  const on = ipaOn();
  if (b.classList.contains("on") !== on) {
    b.classList.toggle("on", on);
    b.title = on ? "Pronuncia IPA accesa: clicca per spegnerla" : "Pronuncia IPA spenta: clicca per accenderla (usa Groq o Gemini)";
    b.setAttribute("aria-pressed", String(on));
  }
}

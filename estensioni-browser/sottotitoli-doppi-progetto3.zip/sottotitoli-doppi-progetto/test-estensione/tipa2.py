# 5.9.4: niente riga IPA sotto i sottotitoli; pronuncia solo della parola che guardi (scheda aperta almeno 0,8 s)
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("""chrome.storage.sync.set({engine:'google', targetLang:'it', hoverPause:true})
          .then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))""")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ipaParole"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent", timeout=30000)
        await pg.wait_for_timeout(6000)
        print("1. durante la visione: riga IPA", await pg.evaluate("!!document.querySelector('.dualsub-ipa')"), "| pulsante IPA", await pg.evaluate("!!document.querySelector('.dualsub-ipabtn')"),
              "| richieste IPA:", len(log.get("ipa", [])))
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word")
        # 2. passando veloce su tre parole: niente richieste
        for i in range(3):
            await words.nth(i).hover(); await pg.wait_for_timeout(450)
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(1500)
        print("2. passando veloce: richieste IPA:", len(log.get("ipa", [])))
        # 3. mi fermo su una parola: chiede solo quella
        await words.nth(4).hover(); await pg.wait_for_timeout(9000)
        print("3. ferma su", await words.nth(4).inner_text(), "→ scheda:", await pg.evaluate("(document.querySelector('.dualsub-card-ipa')||{}).textContent"), "| richieste:", [(w, x) for w, x in log.get("ipa", [])])
        # 4. di nuovo la stessa parola: niente richieste
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(800)
        n = len(log.get("ipa", []))
        await words.nth(4).hover(); await pg.wait_for_timeout(2500)
        print("4. rivista:", await pg.evaluate("(document.querySelector('.dualsub-card-ipa')||{}).textContent"), "| richieste nuove:", len(log.get("ipa", [])) - n)
        # 5. pronuncia spenta: pulsante nella scheda, chiede solo con il clic
        await sw.evaluate("chrome.storage.sync.set({ipa:false})"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(800)
        n = len(log.get("ipa", []))
        await words.nth(6).hover(); await pg.wait_for_timeout(2000)
        b = pg.locator(".dualsub-card-ipa button")
        print("5. spenta: riga IPA nella scheda", await pg.evaluate("!!document.querySelector('.dualsub-card-ipa')"), "| pulsante", await b.count(), "| richieste:", len(log.get("ipa", [])) - n)
        # 6. riaccesa, poi spenta con "spegni IPA" dalla scheda
        await sw.evaluate("chrome.storage.sync.set({ipa:true})"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(800)
        await words.nth(4).hover(); await pg.wait_for_timeout(1500)
        await words.nth(4).click(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-ipa-off").click(); await pg.wait_for_timeout(500)
        print("6. 'spegni IPA' dalla scheda:", await sw.evaluate("chrome.storage.sync.get('ipa').then(r=>r.ipa)"), "| riga:", await pg.evaluate("!!document.querySelector('.dualsub-card-ipa')"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

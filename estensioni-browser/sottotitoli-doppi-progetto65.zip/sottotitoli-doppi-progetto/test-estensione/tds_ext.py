# 1.7.8: su un sito qualsiasi (non YouTube) il pulsante DS c'è subito e, premuto, avvia la trascrizione
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', autoTranscribe:false, enabled:true})")
        await sw.evaluate("chrome.storage.local.set({keys:{groq:'gsk_test'}})")
        pg = await ctx.new_page(); errs=[]
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/video.html"); await pg.wait_for_timeout(2500)
        btn = pg.locator(".dualsub-toggle")
        n = await btn.count()
        print("1. pulsante DS prima di tutto:", n, "| nascosto:", await pg.evaluate("(document.querySelector('.dualsub-toggle')||{}).hidden"))
        await pg.evaluate("document.getElementById('v').play()")
        await btn.first.click(); await pg.wait_for_timeout(500)
        try:
            await pg.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent?.includes('frase')", timeout=25000)
            got = True
        except Exception: got = False
        print("2. dopo il clic su DS: sottotitoli arrivati:", got, "| testo:", await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent"))
        print("   pulsante acceso:", await pg.evaluate("document.querySelector('.dualsub-toggle').classList.contains('on')"))
        print("errori:", errs if (n == 1 and got) else errs + ["pulsante DS sui siti non va"])
        await ctx.close()
asyncio.run(main())

// Funzioni pure per leggere i sottotitoli di YouTube e unirli in frasi.
var DualSubs = (() => {
  const NO_SPACE = /^(ja|zh|th|lo|km|my)/i;

  // Una "cue" per evento, come le mostra YouTube (usata dalla modalità riga per riga)
  function parseCues(events) {
    const cues = [];
    for (const ev of events || []) {
      if (!ev.segs) continue;
      const text = ev.segs.map((s) => s.utf8 || "").join("").replace(/\s+/g, " ").trim();
      if (!text) continue;
      const start = ev.tStartMs || 0;
      cues.push({ start, end: start + (ev.dDurationMs || 0), text });
    }
    return cues;
  }

  // Unità minime: parole (sottotitoli automatici) o righe (sottotitoli manuali)
  function buildUnits(events, isAsr) {
    const units = [];
    for (const ev of events || []) {
      if (!ev.segs) continue;
      const start = ev.tStartMs || 0;
      if (isAsr) {
        for (const s of ev.segs) {
          const txt = (s.utf8 || "").replace(/\n/g, " ").trim();
          if (txt) units.push({ start: start + (s.tOffsetMs || 0), text: txt, word: true });
        }
      } else {
        const txt = ev.segs.map((s) => s.utf8 || "").join("").replace(/\s+/g, " ").trim();
        if (txt) units.push({ start, end: start + (ev.dDurationMs || 0), text: txt, word: false });
      }
    }
    units.sort((a, b) => a.start - b.start);
    units.forEach((u, i) => {
      if (u.word) {
        const next = units[i + 1];
        u.end = Math.min(next ? next.start : Infinity, u.start + 1500);
      }
    });
    return units;
  }

  // Unisce le unità in frasi: punteggiatura, pause, oppure lunghezza massima
  function segment(units, lang) {
    const joiner = NO_SPACE.test(lang || "") ? "" : " ";
    const segs = [];
    let cur = [];
    let chars = 0;
    const flush = () => {
      if (!cur.length) return;
      const text = cur.map((u) => u.text).join(joiner).replace(/\s+/g, " ").trim();
      if (text) segs.push({ start: cur[0].start, end: cur[cur.length - 1].end, text });
      cur = [];
      chars = 0;
    };
    for (let i = 0; i < units.length; i++) {
      const u = units[i];
      const next = units[i + 1];
      cur.push(u);
      chars += u.text.length + 1;
      const ended = /[.!?。！？…]["'»”)\]]*$/.test(u.text);
      const gap = next ? next.start - (u.word ? u.start : u.end) : Infinity;
      const pause = u.word ? gap > 1300 : gap > 800;
      const tooLong = u.end - cur[0].start > 12000 || chars > 200;
      if (!next || ended || pause || tooLong) flush();
    }
    segs.forEach((s, i) => { s.showEnd = showEnd(s, segs[i + 1]); });
    return segs;
  }

  // Fino a quando resta visibile una frase. I tempi di fine (soprattutto quelli di Whisper e dei sottotitoli
  // automatici) spesso arrivano prima che la frase sia finita di dire: la tengo almeno il tempo per leggerla,
  // e se la frase dopo arriva entro 4 secondi la tengo fino a lì, così la riga non sparisce a metà.
  function readMs(text) {
    return Math.min(7000, 700 + 60 * String(text || "").length);
  }
  function showEnd(c, next) {
    const own = Math.max(c.end + 1200, c.start + readMs(c.text));
    if (!next) return own;
    if (next.start - c.end <= 4000) return next.start;
    return Math.min(own, next.start);
  }

  function activeText(cues, t) {
    const active = [];
    for (const c of cues) {
      if (c.start > t) break;
      if (t < c.end) active.push(c.text);
    }
    return [...new Set(active.slice(-2))].join("\n");
  }

  function findSegment(segs, t) {
    let lo = 0, hi = segs.length - 1, found = -1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (segs[mid].start <= t) { found = mid; lo = mid + 1; } else hi = mid - 1;
    }
    return found >= 0 && t < segs[found].showEnd ? found : -1;
  }

  // ---------- Frasi dalla trascrizione di Whisper ----------
  // Whisper restituisce "segmenti" di lunghezza molto variabile (da una parola a 30 secondi).
  // Qui li ritaglio in frasi: divise ai punti (e alle virgole se troppo lunghe), con i tempi
  // presi dalle singole parole, e con i frammenti minuscoli uniti a quelli vicini.
  const MAX_CHARS = 110;
  const wordsOf = (t) => t.trim().split(/\s+/).filter(Boolean);

  function splitText(text) {
    let parts = text.split(/(?<=[.!?…。？！])\s+/).map((x) => x.trim()).filter(Boolean);
    const out = [];
    for (const p of parts) {
      if (p.length <= MAX_CHARS) { out.push(p); continue; }
      // troppo lunga: la divido alle virgole, in pezzi di lunghezza simile
      const bits = p.split(/(?<=[,;:，、；])\s+/);
      let cur = "";
      for (const b of bits) {
        if (cur && (cur + " " + b).length > MAX_CHARS) { out.push(cur); cur = b; }
        else cur = cur ? cur + " " + b : b;
      }
      if (cur) {
        // ancora troppo lunga e senza virgole: taglio a parole
        if (cur.length > MAX_CHARS * 1.6) {
          const w = wordsOf(cur);
          const n = Math.ceil(cur.length / MAX_CHARS);
          const per = Math.ceil(w.length / n);
          for (let i = 0; i < w.length; i += per) out.push(w.slice(i, i + per).join(" "));
        } else out.push(cur);
      }
    }
    return out;
  }

  // segments: [{start, end, text}] in secondi; words: [{w, s, e}] in secondi (anche vuoto)
  function fromWhisper(segments, words, offsetMs = 0, rate = 1) {
    const toMs = (sec) => offsetMs + sec * 1000 * rate;
    const cues = [];
    for (const seg of segments) {
      const text = String(seg.text || "").trim();
      if (!text) continue;
      const parts = splitText(text);
      const segWords = (words || []).filter((w) => w.s >= seg.start - 0.3 && w.e <= seg.end + 0.3);
      const totalWords = parts.reduce((a, p) => a + wordsOf(p).length, 0);
      const useWords = segWords.length > 0 && Math.abs(segWords.length - totalWords) <= Math.max(2, totalWords * 0.15);
      const totalChars = parts.reduce((a, p) => a + p.length, 0) || 1;
      let wi = 0, t = seg.start;
      for (const p of parts) {
        let s, e;
        if (useWords) {
          const n = wordsOf(p).length;
          const first = segWords[Math.min(wi, segWords.length - 1)];
          const last = segWords[Math.min(wi + n - 1, segWords.length - 1)];
          s = first.s; e = Math.max(last.e, s + 0.3);
          wi += n;
        } else {
          s = t;
          e = t + ((seg.end - seg.start) * p.length) / totalChars;
          t = e;
        }
        cues.push({ start: toMs(s), end: toMs(e), text: p });
      }
    }
    return mergeTiny(cues);
  }

  // Frammenti di una o due parole (o più brevi di un secondo) uniti alla frase vicina
  function mergeTiny(cues) {
    const tiny = (c) => wordsOf(c.text).length < 3 || c.end - c.start < 900;
    const out = [];
    for (const c of cues) {
      const prev = out[out.length - 1];
      const endsSentence = prev && /[.!?…。？！]["'»”)\]]*$/.test(prev.text);
      const joined = prev ? (prev.text + " " + c.text).length : 0;
      const close = prev && c.start - prev.end < 700;
      // unisco: frammenti minuscoli (fino a 150 caratteri), oppure una frase non finita con il suo seguito (fino a 110)
      const glueTiny = close && (tiny(c) || (tiny(prev) && !endsSentence)) && joined <= 150 &&
        !(tiny(c) && endsSentence && wordsOf(c.text).length >= 2);
      const glueSentence = close && !endsSentence && joined <= MAX_CHARS;
      if (glueTiny || glueSentence) {
        prev.text = prev.text + " " + c.text;
        prev.end = Math.max(prev.end, c.end);
      } else out.push({ ...c });
    }
    return out;
  }

  // ---------- Frasi inventate da Whisper (musica, rumore, silenzio) ----------
  const CREDITS = /(sottotitoli (creati|a cura)|amara\.org|thanks? (you )?for watching|grazie (per|della) (la )?visione|iscriviti al canale|subtitles by|please subscribe|like and subscribe|продолжение следует|ご視聴ありがとう|redacted by)/i;
  const STOCK = /^(i'?m sorry|sorry|it'?s over|thank you( so much| very much)?|thanks|bye( bye)?|goodbye|you|oh|ah|uh|hmm|okay|ok|yeah|yes|no|so|the end|grazie|ciao|gracias|merci|danke|music|applause|laughter|silence)[.!?…]*$/i;
  function isJunk(seg, recentTexts = []) {
    const text = String(seg.text || "").trim();
    if (!text) return true;
    if (CREDITS.test(text)) return true;
    if (/^[\s♪♫🎵🎶.…*-]*$/.test(text) || /^[\[(].*[\])]$/.test(text)) return true;   // "♪", "[Musica]", "(applausi)"
    const ns = seg.noSpeech || 0, lp = seg.logprob == null ? 0 : seg.logprob;
    if (lp < -1.5) return true;                          // Whisper non è sicuro di niente
    if (ns > 0.5 && lp < -0.4) return true;              // probabilmente non c'è parlato
    if ((seg.compression || 0) > 2.4) return true;       // testo ripetitivo, tipico delle allucinazioni
    if (STOCK.test(text) && (ns > 0.15 || lp < -0.6)) return true; // frase "di riempimento" detta con poca sicurezza
    const norm = text.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
    return recentTexts.some((t) => String(t).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim() === norm) && norm.split(" ").length <= 6;
  }

  // Sicurezza media di Whisper su una trascrizione (per scegliere tra due lingue)
  function meanLogprob(segs) {
    let w = 0, sum = 0;
    for (const s of segs || []) {
      const d = Math.max(0.2, (s.end || 0) - (s.start || 0));
      sum += (s.logprob == null ? -1 : s.logprob) * d;
      w += d;
    }
    return w ? sum / w : -5;
  }

  // ---------- In che lingua è un testo (dalle parole più comuni) ----------
  const STOP = {
    en: "the and is are of to in that it you was for on with this have be not but they what we my your do there a i our were".split(" "),
    it: "il lo gli di che è e un una per non sono con del della mi ti si ma come anche ho questo questa nel alla perché più la al a da io abbiamo siamo".split(" "),
    es: "el los las de que es y un una por para con no se del pero como está muy yo tú al esto pues también la en me".split(" "),
    fr: "le les des que et est un une pour pas je vous il elle dans ce qui sur avec mais au du très la en nous ne".split(" "),
    de: "der die das und ist nicht ich du ein eine zu mit den dem auf für es sie wir aber auch sehr".split(" "),
    pt: "o os as de que e é um uma para com não se do da mas como você eu isso muito também a no na em ao".split(" ")
  };
  function guessLang(text) {
    const words = String(text || "").toLowerCase().split(/[^\p{L}]+/u).filter(Boolean);
    if (words.length < 5) return "";
    const scores = Object.entries(STOP).map(([l, list]) => [l, words.filter((w) => list.includes(w)).length]).sort((a, b) => b[1] - a[1]);
    const [best, second] = scores;
    return best[1] >= 3 && best[1] >= second[1] * 1.5 ? best[0] : "";
  }

  // Quanto due frasi hanno le stesse parole (0-1)
  // Una correzione è accettabile se lascia la frase riconoscibile: stesse parole in buona parte,
  // oppure lettere quasi uguali (le correzioni di desinenze cambiano le parole ma non le lettere)
  function charSimilarity(a, b) {
    const x = String(a || "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim().slice(0, 400);
    const y = String(b || "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim().slice(0, 400);
    if (!x || !y) return 0;
    let prev = Array.from({ length: y.length + 1 }, (_, j) => j);
    for (let i = 1; i <= x.length; i++) {
      const cur = [i];
      for (let j = 1; j <= y.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x[i - 1] === y[j - 1] ? 0 : 1));
      prev = cur;
    }
    return 1 - prev[y.length] / Math.max(x.length, y.length);
  }
  function closeFix(a, b) {
    return similarity(a, b) >= 0.5 || charSimilarity(a, b) >= 0.6;
  }

  function similarity(a, b) {
    const wa = String(a || "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
    const wb = String(b || "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
    if (!wa.length || !wb.length) return 0;
    const set = new Set(wa);
    return wb.filter((x) => set.has(x)).length / Math.max(wa.length, wb.length);
  }

  // Parti del video davvero coperte da frasi: i buchi di oltre 25 secondi restano "da ascoltare"
  function coverFromCues(cues, pad = 4000, maxGap = 25000) {
    const spans = cues.filter((c) => !c.removed).map((c) => [Math.max(0, c.start - pad), c.end + pad]).sort((a, b) => a[0] - b[0]);
    const out = [];
    for (const [a, b] of spans) {
      const last = out[out.length - 1];
      if (last && a - last[1] < maxGap) last[1] = Math.max(last[1], b);
      else out.push([a, b]);
    }
    return out;
  }

  // Il testo è nella lingua attesa? No se è in inglese (Whisper ha tradotto) o in un altro alfabeto
  // (per il russo lettere latine al posto del cirillico, ecc.)
  const SCRIPT = { ru: "Cyrillic", uk: "Cyrillic", bg: "Cyrillic", be: "Cyrillic", sr: "Cyrillic", mk: "Cyrillic", kk: "Cyrillic", el: "Greek",
    ar: "Arabic", fa: "Arabic", ur: "Arabic", he: "Hebrew", hi: "Devanagari", mr: "Devanagari", ne: "Devanagari", th: "Thai", ka: "Georgian", hy: "Armenian",
    ja: "Han|Hiragana|Katakana", zh: "Han", ko: "Hangul" };
  function wrongLang(text, lang) {
    const l = String(lang || "").split("-")[0].toLowerCase();
    const t = String(text || "");
    if (!l || !t.trim()) return false;
    if (l !== "en" && guessLang(t) === "en") return true;
    const sc = SCRIPT[l];
    const letters = t.match(/\p{L}/gu) || [];
    if (letters.length < 4) return false;
    if (sc) {
      const re = new RegExp("[" + sc.split("|").map((x) => "\\p{Script=" + x + "}").join("") + "]", "u");
      return letters.filter((c) => re.test(c)).length / letters.length < 0.5;
    }
    // lingua con l'alfabeto latino: sbagliato se quasi tutto è in un altro alfabeto
    return letters.filter((c) => /\p{Script=Latin}/u.test(c)).length / letters.length < 0.5;
  }

  return { parseCues, buildUnits, segment, activeText, findSegment, fromWhisper, splitText, showEnd, readMs,
    isJunk, meanLogprob, guessLang, similarity, charSimilarity, closeFix, coverFromCues, wrongLang };
})();

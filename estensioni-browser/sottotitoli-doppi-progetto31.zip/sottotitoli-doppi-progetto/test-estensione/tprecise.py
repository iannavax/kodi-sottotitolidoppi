# 1.6.3: «🎯 Rifai più precisa»: la spiegazione chiesta di nuovo allo stesso servizio con più ragionamento, sapendo cosa c'era prima
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false, hoverPause:true, learnNgram:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2000)
        await pg.locator(".dualsub-card .dualsub-explainbtn").click()
        for _ in range(60):
            if log.get("define_plain"): break
            await pg.wait_for_timeout(500)
        await pg.wait_for_timeout(2500)
        pb = pg.locator(".dualsub-card .dualsub-precise")
        print("1. pulsante dopo la spiegazione:", await pb.count(), "| prima richiesta, ragionamento:", log.get("define_plain"))
        await pb.click()
        for _ in range(40):
            if log.get("precise"): break
            await pg.wait_for_timeout(500)
        await pg.wait_for_timeout(1500)
        print("2. richiesta precisa:", log.get("precise"), "| scheda:", (await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-card-meaning')||{}).textContent")))
        print("3. salvate:", await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-savedbtn')||{}).textContent"))
        ok = (await pb.count()) == 1 and log.get("precise") and log["precise"][0][0] == "medium" and log["precise"][0][1] == "DIVERSA" and log["define_plain"][0] in (None, "none")
        print("errori:", errs if ok else errs + ["rifai precisa non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

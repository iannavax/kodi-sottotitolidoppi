// Parole al Volo — impostazioni e funzioni condivise da pagine, popup, vocabolario e background.
// (config.js di Sottotitoli Doppi è caricato prima: servizi, chiavi, prompt, collegamenti ai dizionari.)
var PAV_DEFAULTS = {
  uiLang: false,   // interfaccia nella lingua di «Traduci in» (la stessa scelta di Sottotitoli Doppi)
  on: true,                 // estensione accesa
  hover: true,              // scheda passando il mouse sopra le parole (si accende e spegne: popup, Alt+Maiusc+M, scheda)
  mode: "hover",            // come: hover = subito, alt = solo tenendo premuto Alt ("off" delle prime prove = hover spento)
  delay: 350,               // attesa (ms) prima di mostrare la scheda passando il mouse
  selection: true,          // tradurre il testo quando lo evidenzi (si accende e spegne: popup, Alt+Maiusc+S, pannello)
  targetLang: "it",
  sourceLang: "",           // lingua del testo imposta per tutti i siti ("" = riconosciuta da sola)
  siteLang: {},             // lingua del testo imposta per un sito: { "www.sito.cz": "cs" } (vince su sourceLang)
  ipa: true,                // pronuncia IPA (Groq o Gemini, una volta per parola)
  sentence: true,           // traduzione della frase nella scheda della parola
  etym: true,               // etimologia nella scheda della parola (Wiktionary, gratis)
  // strumenti per imparare (prova): tutti gratis tranne learnLlmExtra, che arriva nella stessa richiesta di "Spiega con"
  learnFreq: true, learnKnown: true, learnExamples: true, learnAudio: true, learnTable: true, learnGender: true, learnSpell: true, learnLlmExtra: true, learnJisho: true, learnGweb: true, learnHan: true, gdAlt: true, gdDefs: true, gdSyn: true, gdSpell: true,
  learnKnownPage: false,    // colora sulla pagina le parole che conosci
  savedPage: true,
  idiomAuto: false,         // il modello cerca da solo i modi di dire nella frase (una richiesta piccola per frase): spento di serie, niente token senza chiederlo
  idiomPage: true,          // modi di dire trovati sottolineati in arancione sulle pagine
  roman: false,             // lettere latine sopra le lettere (alfabeti non latini) nella scheda          // sottolinea in celeste le parole del vocabolario ancora da imparare
  ankiImage: false,         // immagine nelle carte di Anki
  ankiImageSource: "auto",  // da dove: auto (Wikipedia + Commons), wikipedia, commons, openverse, all
  engine: "google",         // chi spiega le parole nel contesto e "traduci meglio" (google = solo Google)
  models: {}, localUrl: "http://localhost:11434/v1", msRegion: "", fallback: true,
  ttsLang: "", ttsVoice: "", autoSpeak: false,
  disabledSites: [],
  pdfAuto: false,           // i PDF aperti nel browser si aprono da soli nel lettore di Parole al Volo
  ankiDeck: "Parole al Volo", ankiModel: "", ankiAuto: false,
  ankiPerLang: true, ankiLangDeck: "Lingue::{lingua}"   // un mazzo per lingua, gli stessi di Sottotitoli Doppi
};

// Lingue di arrivo (sigla per Google Traduttore)
var PAV_TARGETS = ["it", "en", "es", "fr", "de", "pt", "nl", "pl", "ro", "ru", "uk", "tr", "ar", "hi", "ja", "ko", "zh-Hans",
  "cs", "da", "sv", "no", "fi", "el", "hu", "sk", "sl", "hr", "sr", "bg", "he", "fa", "id", "vi", "th", "ca", "lt", "lv", "et"];

function pavLangName(code, inLang) {
  try { return new Intl.DisplayNames([inLang || "it"], { type: "language" }).of(code === "zh-Hans" ? "zh-Hans" : code) || code; } catch { return code; }
}
const pavBase = (l) => {
  const b = String(l || "").split("-")[0].toLowerCase();
  return ({ iw: "he", nb: "no", jw: "jv", in: "id", fil: "tl", zh: "zh" })[b] || b;
};
const pavSameLang = (a, b) => !!a && !!b && pavBase(a) === pavBase(b);

// ---------- Schede per Anki (stesso formato per il file e per l'invio diretto con AnkiConnect) ----------
const pavEsc = (s) => String(s || "").replace(/[\t\r\n]+/g, " ").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
function pavMark(sentence, word) {
  const s = pavEsc(sentence), w = pavEsc(word);
  const i = s.toLowerCase().indexOf(w.toLowerCase());
  return !w || i < 0 ? s : s.slice(0, i) + "<b>" + s.slice(i, i + w.length) + "</b>" + s.slice(i + w.length);
}
function pavAnkiFields(e) {
  const isText = e.kind === "text";
  let front = isText ? pavEsc(e.word) : `<b>${pavEsc(e.word)}</b>`;
  if (!isText && e.sentence) front += `<br><br><i>${pavMark(e.sentence, e.word)}</i>`;
  let back = `<b>${pavEsc(e.meaning || "")}</b>`;
  const info = [e.lemma && e.lemma.toLowerCase() !== String(e.word || "").toLowerCase() ? pavEsc(e.lemma) : "", pavEsc(e.pos)].filter(Boolean).join(" · ");
  if (info) back += `<br>${info}`;
  if (e.ipa) back += `<br>/${pavEsc(e.ipa)}/`;
  if (e.gender) back += `<br><small>${pavEsc(e.gender)}</small>`;
  if (e.etym) back += `<br><small>Etimologia: ${pavEsc(e.etym)}</small>`;
  if (e.translit) back += `<br>${pavEsc(e.translit)}`;
  if (e.explanation) back += `<br>${pavEsc(e.explanation)}`;
  if (!isText && e.sentenceTrans) back += `<br><br><i>${pavEsc(e.sentenceTrans)}</i>`;
  if (e.url) back += `<br><br><a href="${pavEsc(e.url)}">${pavEsc(e.title || e.url)}</a>`;
  const tags = ["parole-al-volo", pavBase(e.lang)].filter(Boolean);
  return { front, back, tags };
}
function pavAnkiFile(entries, deckOpts) {
  const lines = ["#separator:tab", "#html:true", "#tags column:3"];
  if (deckOpts && typeof dsAnkiDeckFor === "function") lines.push("#deck column:4");
  for (const e of entries) {
    const f = pavAnkiFields(e);
    if (e.image && /^https:\/\//.test(e.image)) f.front += `<br><img src="${pavEsc(e.image)}">`;   // nel file: immagine da internet
    lines.push([f.front, f.back, f.tags.join(" "), ...(deckOpts && typeof dsAnkiDeckFor === "function" ? [dsAnkiDeckFor(e.lang, deckOpts)] : [])].join("\t"));
  }
  return lines.join("\n") + "\n";
}
function pavVocabId(e) {
  return [pavBase(e.lang) || "?", String(e.lemma || e.word || "").toLowerCase().trim()].join("|");
}

// Lingue da cui si può tradurre (le stesse di Whisper, quasi tutte conosciute da Google), con il nome in italiano
function pavSourceLangs() {
  const codes = Object.keys((typeof DS_CONFIG !== "undefined" && DS_CONFIG.STT_LANGS) || {});
  return codes.map((code) => {
    let native = "";
    try { native = new Intl.DisplayNames([code], { type: "language" }).of(code) || ""; } catch {}
    const it = pavLangName(code);
    return { code, label: it + (native && native.toLowerCase() !== it.toLowerCase() ? " · " + native : ""), key: [code, it, native, DS_CONFIG.STT_LANGS[code]].join(" ").toLowerCase() };
  }).sort((a, b) => a.label.localeCompare(b.label, "it"));
}
var PAV_COMMON_LANGS = ["en", "cs", "de", "fr", "es", "pt", "ru", "pl", "sk", "uk", "nl", "da", "sv", "no", "fi", "hu", "ro", "el", "tr", "ja", "zh", "ko", "ar", "he", "hi", "it"];

#!/usr/bin/env python3
# Crea estensione/src/han-data.json: i dati di ogni kanji / carattere cinese / hanja, uguali per tutte le lingue,
# dentro l'estensione (niente richieste in rete). Fonti (scaricate con `npm pack` e curl):
#   @mandel59/mojidata  → dist/moji.db: Unihan (Unicode 18), IDS di BabelStone (parti), radicali, 通用规范汉字表 (tghb)
#   @leonsilicon/hsk3.0 → HSK3.0_chars_level*.json (livelli ufficiali HSK 3.0)
#   davidluzgouveia/kanji-data (GitHub) → kanji.json (JLPT nuovo N5–N1, classe, frequenza, letture kun con okurigana)
# Uso: python3 crea_han_data.py moji.db cartella-hsk3.0 kanji.json ../src/han-data.json
import sqlite3, json, sys, re
db, hskdir, kdfile, out = sys.argv[1:5]
c = sqlite3.connect(db)
U = {}
WANT = ("kDefinition", "kMandarin", "kCantonese", "kJapanese", "kHangul", "kVietnamese", "kTotalStrokes", "kRSUnicode",
        "kSimplifiedVariant", "kTraditionalVariant", "kJoyoKanji", "kJinmeiyoKanji", "kKoreanEducationHanja")
for p in WANT:
    for ch, v in c.execute(f'select UCS, value from "unihan_{p}"'):
        U.setdefault(ch, {})[p] = v
ids = {}
for ch, src, s in c.execute("select UCS, source, IDS from ids"):
    if ch not in ids or "G" in src: ids[ch] = s   # forma cinese prima, se le forme sono diverse
tghb = {ch: lv for ch, lv in c.execute("select 规范字, 级 from tghb")}
rad = {}
for num, simp, rch, cjk in c.execute("select radical_number, radical_simplified, radical_character, radical_CJKUI from radicals"):
    rad[str(num) + "'" * simp] = cjk
hsk = {}
for lv, f in ((1, "1"), (2, "2"), (3, "3"), (4, "4"), (5, "5"), (6, "6"), (7, "7-9")):
    for ch in json.load(open(f"{hskdir}/HSK3.0_chars_level{f}.json", encoding="utf-8")): hsk.setdefault(ch, lv)
kd = json.load(open(kdfile, encoding="utf-8"))
uplus = lambda v: [chr(int(x[2:].split("<")[0], 16)) for x in str(v or "").split() if x.startswith("U+")]

keep = set(tghb) | set(hsk)
keep |= {ch for ch, u in U.items() if "kJoyoKanji" in u or "kJinmeiyoKanji" in u or "kKoreanEducationHanja" in u}
keep |= {ch for ch, k in kd.items() if k.get("jlpt_new") or k.get("grade") or k.get("freq")}
# forme tradizionali dei caratteri cinesi comuni (sottotitoli di Taiwan e Hong Kong)
for ch in list(keep):
    if tghb.get(ch) in (1, 2) or ch in hsk: keep |= set(uplus(U.get(ch, {}).get("kTraditionalVariant")))
IDC = re.compile(r"[⿰-⿿㇯]")
parts_of = lambda ch: [x for x in IDC.sub("", ids.get(ch, "")) if x != ch and not x.isascii()]
# le parti (una volta), così anche loro hanno un significato
for ch in list(keep): keep |= {p for p in parts_of(ch) if p in U and U[p].get("kDefinition")}
keep = {ch for ch in keep if ch in U}

data = {}
for ch in sorted(keep):
    u, k = U[ch], kd.get(ch, {})
    e = {}
    if u.get("kDefinition"): e["d"] = u["kDefinition"][:120]
    if u.get("kMandarin"): e["py"] = u["kMandarin"]
    if u.get("kCantonese"): e["yue"] = u["kCantonese"]
    ja = (u.get("kJapanese") or "").split()
    on = [x for x in ja if re.match(r"^[゠-ヿ]+$", x)]
    kun = [x for x in ja if re.match(r"^[぀-ゟ]+$", x)]
    if k.get("readings_kun"): kun = [x.lstrip("-").rstrip("-") for x in k["readings_kun"]]
    if on: e["on"] = on[:6]
    if kun: e["kun"] = kun[:8]
    if k.get("meanings") and (on or kun): e["jm"] = ", ".join(k["meanings"][:5])[:100]
    if u.get("kHangul"): e["ko"] = " ".join(dict.fromkeys(x.split(":")[0] for x in u["kHangul"].split()))
    if u.get("kVietnamese"): e["vi"] = ", ".join(u["kVietnamese"].split()[:3])
    if u.get("kTotalStrokes"): e["s"] = int(u["kTotalStrokes"].split()[0])
    if u.get("kRSUnicode"): e["r"] = u["kRSUnicode"].split()[0]
    p = IDC.sub("", ids.get(ch, ""))
    if len(p) > 1 and ch not in p: e["p"] = ids[ch]
    if k.get("jlpt_new"): e["jlpt"] = k["jlpt_new"]
    if k.get("grade"): e["g"] = k["grade"]
    if k.get("freq"): e["f"] = k["freq"]
    if ch in hsk: e["hsk"] = hsk[ch]
    if ch in tghb: e["tg"] = tghb[ch]
    if "kKoreanEducationHanja" in u: e["koe"] = 1
    if "kJoyoKanji" in u: e["joyo"] = 1
    sv = [x for x in uplus(u.get("kSimplifiedVariant")) if x != ch]
    tv = [x for x in uplus(u.get("kTraditionalVariant")) if x != ch]
    if sv: e["sv"] = "".join(sv)
    if tv: e["tv"] = "".join(tv)
    data[ch] = e
radicals = {n: [cj, (U.get(cj, {}).get("kDefinition") or "").split(";")[0][:40]] for n, cj in rad.items()}
json.dump({"v": 1, "src": "Unihan (Unicode 18), BabelStone IDS, KANJIDIC (kanji-data), HSK 3.0, 通用规范汉字表", "rad": radicals, "c": data},
          open(out, "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))
print(len(data), "caratteri")

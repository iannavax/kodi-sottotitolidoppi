# 5.17: definizioni (Google + Wiktionary) e ⚑ Traduzione sbagliata? per la parola in Sottotitoli Doppi
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
DEFS = "(document.querySelector('.dualsub-card .dsx-defs')||{}).innerText||'(nessuna)'"
MEAN = "(document.querySelector('.dualsub-card .dualsub-card-meaning')||{}).textContent"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({idioms:true, engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(3500)
        print("1. definizioni:", (await pg.evaluate(DEFS)).replace("\n", " | "))
        print("   significato:", await pg.evaluate(MEAN))
        await pg.locator(".dualsub-card button", has_text="⚑ Traduzione sbagliata?").click(); await pg.wait_for_timeout(300)
        print("2. pulsanti:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-idiom-fixbox button')].map(b=>b.textContent)"))
        await pg.locator(".dualsub-card button", has_text="✎ Correggi a mano").click(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-card .dualsub-idiom-fixbox textarea").fill("pane (corretto)")
        await pg.locator(".dualsub-card .dualsub-idiom-fixbox button", has_text="Salva").click(); await pg.wait_for_timeout(500)
        print("3. dopo la correzione:", await pg.evaluate(MEAN), "| salvata:", await sw.evaluate("chrome.storage.local.get('wordFix').then(r=>r.wordFix)"))
        await pg.locator(".dualsub-card .dualsub-star, .dualsub-card [class*=star]").first.click(); await pg.wait_for_timeout(800)
        print("4. vocabolario:", await sw.evaluate("chrome.storage.local.get('vocab').then(r=>Object.values(r.vocab||{}).map(e=>e.meaning))"))
        await pg.keyboard.press("Escape"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(800)
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        print("5. riaperta:", await pg.evaluate(MEAN))
        await pg.locator(".dualsub-card button", has_text="⚑ Traduzione sbagliata?").click(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-card button", has_text="Togli la correzione").click(); await pg.wait_for_timeout(500)
        print("6. tolta:", await pg.evaluate(MEAN))
        await pg.locator(".dualsub-card button", has_text="⚑ Traduzione sbagliata?").click(); await pg.wait_for_timeout(300)
        await pg.locator(".dualsub-card button", has_text="↻ Rifai con Google").click(); await pg.wait_for_timeout(2500)
        print("7. rifatta con Google:", await pg.evaluate(MEAN))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

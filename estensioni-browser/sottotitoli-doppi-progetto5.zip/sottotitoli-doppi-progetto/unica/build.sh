#!/bin/bash
# Build dell'estensione unica "Sottotitoli Doppi + Parole al Volo": le due estensioni in una sola, con i file presi
# da ../estensione/src e ../parole-al-volo/src (niente copie da tenere allineate). Uso: ./build.sh 1.0.0
set -e; cd "$(dirname "$0")"; V=${1:-1.0.0}
SD=../estensione/src; PAV=../parole-al-volo/src
SDFILES="han-data.json config.js subs.js media.js tts.js whole.js inject.js live.js ahead.js roman.js words.js ipa.js etym.js learn.js fix.js content.js background.js popup.js vocab.html vocab.js transcript.html transcript.js helper.html helper.js overlay.css voices-ui.js freq.html freq.js jlpt.html jlpt.js engines-ui.js"
# Parole al Volo: il suo codice usa un archivio delle impostazioni suo (unica-pav.js) per i nomi in comune con Sottotitoli Doppi
pavfix() { sed -e 's/DS_EXT\.storage\.sync/PAV_SYNC/g' -e 's/DS_EXT\.storage\.onChanged/PAV_ONCHANGED/g' "$1"; }
rm -rf build && for b in chrome firefox; do mkdir -p build/$b/helper build/$b/icons
  for f in $SDFILES; do cp $SD/$f build/$b/; done
  cp $SD/helper/sd_host.py $SD/helper/install-windows.ps1 $SD/helper/install-unix.sh build/$b/helper/
  cp $SD/icons/icon-16.png $SD/icons/icon-32.png $SD/icons/icon-48.png $SD/icons/icon-96.png $SD/icons/icon-128.png build/$b/icons/
  cp $PAV/volo-config.js $PAV/volo.css build/$b/
  pavfix $PAV/volo.js > build/$b/volo.js
  pavfix $PAV/volo-bg.js | sed 's/importScripts("config.js", "volo-config.js", "background.js")/importScripts("config.js", "volo-config.js", "unica-pav.js", "background.js")/' > build/$b/volo-bg.js
  pavfix $PAV/popup.js > build/$b/popup-pagine.js
  cp src/unica-pav.js src/popup.html src/popup-start.js src/unica-tabs.js build/$b/
  # popup "Video" = quello di Sottotitoli Doppi; popup "Pagine" = quello di Parole al Volo; tutti e due con le schede in cima
  sed 's#<script src="voices-ui.js"></script>#<script src="voices-ui.js"></script>\n  <script src="unica-tabs.js"></script>#' $SD/popup.html > build/$b/popup-video.html
  sed -e 's#<script src="volo-config.js"></script>#<script src="volo-config.js"></script>\n<script src="unica-pav.js"></script>#' \
      -e 's#<script src="popup.js"></script>#<script src="popup-pagine.js"></script>#' \
      -e 's#<script src="voices-ui.js"></script>#<script src="voices-ui.js"></script>\n<script src="unica-tabs.js"></script>#' $PAV/popup.html > build/$b/popup-pagine.html
  python3 - "$b" "$V" << 'PYEOF'
import json, sys
b, v = sys.argv[1:3]
sd = json.load(open(f"../estensione/manifest.{b}.json", encoding="utf-8"))
pav = json.load(open(f"../parole-al-volo/manifest.{b}.json", encoding="utf-8"))
m = dict(sd)
m["name"] = "Sottotitoli Doppi + Parole al Volo"
m["version"] = v
m["description"] = "Sottotitoli doppi nei video (con trascrizione e scheda delle parole) e Parole al Volo sulle pagine web: le due estensioni in una sola."
m["action"] = dict(sd["action"], default_popup="popup.html", default_title="Sottotitoli Doppi + Parole al Volo")
m["commands"] = pav.get("commands", {})
m["permissions"] = sorted(set(sd.get("permissions", [])) | set(pav.get("permissions", [])))
hp = []
for x in sd.get("host_permissions", []) + pav.get("host_permissions", []):
    if x not in hp: hp.append(x)
m["host_permissions"] = hp
if b == "chrome":
    m["background"] = {"service_worker": "volo-bg.js"}
else:
    m["background"] = {"scripts": ["config.js", "volo-config.js", "unica-pav.js", "background.js", "volo-bg.js"]}
    m["browser_specific_settings"] = {"gecko": {"id": "sottotitoli-parole@estensione.local", "strict_min_version": sd["browser_specific_settings"]["gecko"].get("strict_min_version", "128.0")}}
# Parole al Volo dopo Sottotitoli Doppi, nello stesso spazio degli script: i file in comune (config.js, tts.js,
# etym.js, learn.js, roman.js) ci sono già e non si caricano due volte
pcs = pav["content_scripts"][0]
m["content_scripts"] = sd["content_scripts"] + [{"matches": ["<all_urls>"], "js": ["unica-pav.js", "volo-config.js", "volo.js"],
    "css": pcs.get("css", ["volo.css"]), "all_frames": True, "run_at": "document_idle"}]
json.dump(m, open(f"build/{b}/manifest.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
PYEOF
  { echo "*Versione $V*"; echo; cat LEGGIMI.md; } > build/$b/LEGGIMI.md
done
for f in build/chrome/*.js; do node --check $f; done
# nessun nome dichiarato due volte tra i due codici (stesso spazio degli script nelle pagine e nel sottofondo)
(cd build/chrome && cat config.js subs.js media.js tts.js whole.js live.js ahead.js roman.js words.js ipa.js etym.js learn.js fix.js content.js unica-pav.js volo-config.js volo.js > /tmp/unica-all.js) && node --check /tmp/unica-all.js
(cd build/chrome && cat config.js volo-config.js unica-pav.js background.js volo-bg.js > /tmp/unica-bg.js) && node --check /tmp/unica-bg.js
(cd build/chrome && cat config.js volo-config.js unica-pav.js tts.js engines-ui.js popup-pagine.js voices-ui.js unica-tabs.js > /tmp/unica-pop.js) && node --check /tmp/unica-pop.js
rm -f *.zip *.xpi; (cd build/chrome && zip -rq ../../sottotitoli-parole-chrome-v$V.zip .); (cd build/firefox && zip -rq ../../sottotitoli-parole-firefox-v$V.xpi .)
echo "fatto: sottotitoli-parole-chrome-v$V.zip e sottotitoli-parole-firefox-v$V.xpi"

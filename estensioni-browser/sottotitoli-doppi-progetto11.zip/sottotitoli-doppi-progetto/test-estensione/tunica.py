# Estensione unica: popup con le schede Video/Pagine, impostazioni con lo stesso nome tenute separate
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1200)
        print("1. si apre:", pp.url.split("/")[-1], "| schede:", await pp.evaluate("[...document.querySelectorAll('.unica-tabs button')].map(b=>b.textContent)"))
        await pp.locator(".unica-tabs button", has_text="Pagine").click(); await pp.wait_for_timeout(1200)
        print("2. dopo «Pagine»:", pp.url.split("/")[-1])
        await pp.evaluate("document.getElementById('dAi') && (document.getElementById('dAi').open=true)")
        await pp.select_option("#enginesBox select", "gemini"); await pp.wait_for_timeout(500)
        print("3. impostazioni:", await sw.evaluate("chrome.storage.sync.get(['engine','pavEngine']).then(r=>JSON.stringify(r))"))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1200)
        print("4. riaperto:", pp.url.split("/")[-1])
        await pp.locator(".unica-tabs button", has_text="Video").click(); await pp.wait_for_timeout(1200)
        print("5. video: servizio dei sottotitoli =", await pp.evaluate("(document.querySelector('#engine')||{}).value"))
        await pp.screenshot(path="/tmp/claude-0/unica-video.png")
        await pp.locator(".unica-tabs button", has_text="Pagine").click(); await pp.wait_for_timeout(1000)
        await pp.screenshot(path="/tmp/claude-0/unica-pagine.png")
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

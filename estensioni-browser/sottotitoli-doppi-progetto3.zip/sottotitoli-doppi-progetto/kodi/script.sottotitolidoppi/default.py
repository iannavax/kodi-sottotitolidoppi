# -*- coding: utf-8 -*-
# Sottotitoli Doppi - menu (aprilo dagli add-on "Programmi" mentre il video è in riproduzione,
# oppure dal lettore: Sottotitoli → Scarica → Sottotitoli Doppi)
import sys

import xbmc
import xbmcgui

from resources.lib import runner

player = xbmc.Player()

if len(sys.argv) > 2 and sys.argv[2].startswith("?"):
    # chiamata dal menu dei sottotitoli del lettore (servizio di sottotitoli di Kodi)
    from resources.lib import subtitles
    subtitles.main(sys.argv)
elif len(sys.argv) > 2 and sys.argv[1] == "upgrade":
    # traduzione con il servizio scelto dopo quella rapida di Google (avviata dal menu dei sottotitoli)
    from resources.lib import subtitles
    o = subtitles._dec(sys.argv[2])
    if o.get("p"):
        runner.run(player, manual_path=o["p"], upgrade=True)
    else:
        runner.run(player, source_mode="trascrizione", upgrade=True)
elif len(sys.argv) > 1 and sys.argv[1] == "transcribe":
    runner.run(player, source_mode="trascrizione", interactive=True)
else:
    options = [
        "Crea i sottotitoli doppi per il video in riproduzione",
        "Scegli originale e traduzione per questo video…",
        "Scegli i sottotitoli originali da tradurre (dentro il video, scaricati, file)…",
        "Controlla i sottotitoli dentro il video",
        "Rifai la trascrizione da capo",
        "Rifai la traduzione da capo",
        "Salva i sottotitoli (.srt) per riusarli o condividerli…",
        "Esporta trascrizione (.txt)",
        "Importa traduzione (.txt)",
        "Quando crearli da soli (per questo video, per la serie, sempre o mai)…",
        "Impostazioni",
    ]
    choice = xbmcgui.Dialog().select("Sottotitoli Doppi", options)
    if choice == 0:
        runner.run(player, interactive=True)
    elif choice == 1:
        runner.choose_menu(player)
    elif choice == 2:
        runner.pick_menu(player)
    elif choice == 3:
        runner.check_menu(player)
    elif choice == 4:
        if player.isPlayingVideo() and xbmcgui.Dialog().yesno("Sottotitoli Doppi",
                "Cancello la trascrizione salvata di questo video e la rifaccio da capo (usa di nuovo la quota di Whisper)?"):
            runner.forget_transcript(player.getPlayingFile(), runner.settings())
            runner.save_choice(player.getPlayingFile(), source="trascrizione")
            runner.run(player, source_mode="trascrizione", interactive=True)
    elif choice == 5:
        if player.isPlayingVideo() and xbmcgui.Dialog().yesno("Sottotitoli Doppi",
                "Rifaccio tutta la traduzione di questo video con il servizio scelto, ignorando quella salvata (consuma richieste)?"):
            runner.run(player, interactive=True, retranslate=True)
    elif choice == 6:
        runner.save_menu(player)
    elif choice == 7:
        runner.export_menu(player)
    elif choice == 8:
        runner.import_menu(player)
    elif choice == 9:
        runner.auto_menu(player)
    elif choice == 10:
        runner.ADDON.openSettings()

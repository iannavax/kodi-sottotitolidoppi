# 1.5.1: aspetto delle schede anche sulle pagine (grandezza, colori) e «Posizione sulle pagine: sempre a destra»
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
ST = "(()=>{const c=document.querySelector('.pav-card'); if(!c) return null; const cs=getComputedStyle(c), r=c.getBoundingClientRect(); return {font: cs.fontSize, bg: cs.backgroundColor, rightGap: Math.round(document.documentElement.clientWidth - r.right), top: Math.round(r.top)}})()"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnFreq:false, cardScale:130, cardBg:'#ffffff', cardPosPage:'right'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "en", "bread", 2500)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(1500)
        a = await pg.evaluate(ST); print("1. scheda:", a)
        await sw.evaluate("chrome.storage.sync.set({cardScale:100, cardBg:'#1d2430', cardPosPage:'word'})"); await pg.wait_for_timeout(800)
        c = await pg.evaluate(ST); print("2. di nuovo di serie:", c)
        ok = a and a["font"] == "18.2px" and a["bg"] == "rgb(255, 255, 255)" and a["rightGap"] <= 10 and a["top"] <= 10 and c and c["font"] == "14px" and c["rightGap"] > 50
        print("errori:", errs if ok else errs + ["aspetto delle schede sulle pagine non va"], tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

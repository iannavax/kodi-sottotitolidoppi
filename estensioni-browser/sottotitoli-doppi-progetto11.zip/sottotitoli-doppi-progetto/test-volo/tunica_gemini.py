# Estensione unica: «Spiega con Gemini» nelle schede delle pagine anche se Gemini è scelto solo per i video
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", tvolo.handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', engine:'gemini', models:{gemini:'gemini-flash-lite-latest'}}).then(()=>chrome.storage.local.set({keys:{gemini:'AIza-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/pagina.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "en", "bread", 2500)
        print("pulsante:", await pg.evaluate("[...document.querySelectorAll('.pav-card button')].map(b=>b.textContent).filter(t=>/Spiega/.test(t))"))
        await sw.evaluate("chrome.storage.sync.set({pavEngine:'google'})"); await pg.wait_for_timeout(300)
        await pg.keyboard.press("Escape"); await tvolo.hover(pg, "en", "market", 2500)
        print("con Google scelto per le pagine:", await pg.evaluate("[...document.querySelectorAll('.pav-card button')].map(b=>b.textContent).filter(t=>/Spiega/.test(t))"))
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

// Configurazione condivisa da pagina, popup e background.

// Interfaccia dell'estensione che restituisce promesse: "browser" in Firefox, "chrome" in Chrome ed Edge
var DS_EXT = typeof browser !== "undefined" && browser.runtime ? browser : chrome;
var DS_CONFIG = {
  LANG_EN: {
    it: "Italian", en: "English", es: "Spanish", fr: "French", de: "German", pt: "Portuguese",
    nl: "Dutch", pl: "Polish", ro: "Romanian", ru: "Russian", uk: "Ukrainian", tr: "Turkish",
    ar: "Arabic", hi: "Hindi", ja: "Japanese", ko: "Korean", "zh-Hans": "Simplified Chinese"
  },

  SYNC_DEFAULTS: {
    enabled: true, targetLang: "it", hideNative: true, fontSize: 22,
    engine: "google", models: {}, localUrl: "http://localhost:11434/v1",
    autoTranscribe: true, transcribeMode: "live", fullMaxMin: 60, liveAhead: false, liveAheadDelay: 20, hoverPause: true, ttsLang: "", ttsVoice: "",
    origColor: "#ffffff", transColor: "#f5c84b", bgOpacity: 0.75, subPos: 0, subFont: "default",
    subShow: "both", transFirst: false, transScale: 90, disabledSites: [], stt: "groq", sttModel: "whisper-large-v3-turbo",
    sttUrl: "http://localhost:8000/v1", sttLang: "", cleanTranscript: true, idioms: false,
    fallback: true, msRegion: "", ipa: true, etym: true,
    // strumenti per imparare (versione di prova)
    learnFreq: true, learnKnown: true, learnExamples: true, learnAudio: true, learnTable: true, learnGender: true,
    learnSpell: true, learnLlmExtra: true, learnJisho: true, learnGweb: true, learnHan: true, uiLang: false, ankiImage: false, ankiImageSource: "auto", learnKnownPage: true, roman: false, romanHan: true, romanSize: 65, romanLineSize: 80,
    gdAlt: true, gdDefs: true, gdSyn: true, gdSpell: true,   // dizionario di Google
    // Anki con AnkiConnect: un mazzo per lingua (stessi mazzi di Parole al Volo: "Lingue::Inglese"…)
    ankiDeck: "Sottotitoli Doppi", ankiPerLang: true, ankiLangDeck: "Lingue::{lingua}", ankiAuto: false, ankiModel: ""
  },

  // sigle ISO 639-3 (Tatoeba)
  LANG3: { en: "eng", it: "ita", cs: "ces", sk: "slk", de: "deu", fr: "fra", es: "spa", pt: "por", ru: "rus", uk: "ukr", pl: "pol",
    nl: "nld", da: "dan", sv: "swe", no: "nob", nb: "nob", fi: "fin", hu: "hun", ro: "ron", el: "ell", tr: "tur", ja: "jpn", zh: "cmn",
    ko: "kor", ar: "ara", he: "heb", hi: "hin", bg: "bul", hr: "hrv", sr: "srp", sl: "slv", lt: "lit", lv: "lvs", et: "est", ca: "cat",
    eo: "epo", la: "lat", fa: "pes", vi: "vie", id: "ind", th: "tha", is: "isl", ga: "gle", be: "bel", ka: "kat", hy: "hye" },
  // lingue controllate da LanguageTool
  LT_LANGS: { en: "en-US", de: "de-DE", fr: "fr", es: "es", it: "it", pt: "pt-PT", nl: "nl", pl: "pl-PL", ru: "ru-RU", uk: "uk-UA",
    sk: "sk-SK", sl: "sl-SI", ca: "ca-ES", da: "da-DK", sv: "sv", el: "el-GR", ro: "ro-RO", ja: "ja-JP", zh: "zh-CN", fa: "fa",
    ar: "ar", ga: "ga-IE", gl: "gl-ES", eo: "eo", be: "be-BY", br: "br-FR", ta: "ta-IN", tl: "tl-PH", km: "km-KH", no: "nb", nb: "nb" },

  STT_MODELS: ["whisper-large-v3-turbo", "whisper-large-v3"],

  HOSTS: [
    "<all_urls>",
    "https://www.youtube.com/*",
    "https://translate.googleapis.com/*",
    "https://translate.google.com/*",
    "https://generativelanguage.googleapis.com/*",
    "https://api.groq.com/*",
    "https://openrouter.ai/*",
    "https://api-free.deepl.com/*",
    "https://api.deepl.com/*",
    "https://api.anthropic.com/*",
    "https://api.mistral.ai/*",
    "https://api.cognitive.microsofttranslator.com/*",
    "http://localhost/*",
    "http://127.0.0.1/*"
  ],

  // kind: google | openai (qualsiasi servizio compatibile OpenAI) | deepl | claude | youtube
  ENGINES: {
    google: {
      label: "Google Traduttore, frasi intere (gratis)",
      note: "Nessuna chiave da configurare. Traduce ogni frase da sola, senza guardare il discorso.",
      kind: "google", chunk: { count: 12, chars: 1200 }
    },
    gemini: {
      label: "Gemini, contestuale (gratis con chiave)",
      note: "La chiave si crea gratis su Google AI Studio, senza carta. Consigliato: capisce il discorso. Il modello predefinito è gemini-flash-lite-latest, quello con più richieste gratuite al giorno.",
      kind: "openai", base: "https://generativelanguage.googleapis.com/v1beta/openai",
      needsKey: true, keyUrl: "https://aistudio.google.com/apikey",
      defaultModel: "gemini-flash-lite-latest", modelMatch: "gemini.*flash",
      prefer: ["flash-lite-latest", "flash-lite", "flash-latest", "flash"], extra: { reasoning_effort: "low" },
      chunk: { count: 120, chars: 14000 }, maxTokens: 16384, minIntervalMs: 6500, cache: true
    },
    groq: {
      label: "Groq, contestuale (gratis con chiave)",
      note: "La chiave si crea gratis su console.groq.com, senza carta. Molto veloce.",
      kind: "openai", base: "https://api.groq.com/openai/v1",
      needsKey: true, keyUrl: "https://console.groq.com/keys",
      defaultModel: "llama-3.3-70b-versatile", modelExclude: "whisper|tts|guard|playai|orpheus|prompt",
      prefer: ["llama-3.3-70b", "gpt-oss-120b", "qwen"],
      chunk: { count: 35, chars: 5000 }, minIntervalMs: 2200, cache: true
    },
    openrouter: {
      label: "OpenRouter, modelli gratuiti (con chiave)",
      note: "La chiave si crea gratis su openrouter.ai. Usa solo i modelli che finiscono in :free. Ci sono poche decine di richieste al giorno.",
      kind: "openai", base: "https://openrouter.ai/api/v1",
      needsKey: true, keyUrl: "https://openrouter.ai/keys",
      defaultModel: "", modelMatch: ":free$",
      prefer: ["deepseek", "llama-3.3-70b", "gemma-3-27b", "qwen", "mistral"],
      chunk: { count: 80, chars: 10000 }, minIntervalMs: 3500, cache: true
    },
    mistral: {
      label: "Mistral, contestuale (gratis con chiave)",
      note: "La chiave si crea gratis su console.mistral.ai (piano Experiment, serve solo un numero di telefono). Buona qualità in molte lingue europee.",
      kind: "openai", base: "https://api.mistral.ai/v1",
      needsKey: true, keyUrl: "https://console.mistral.ai/api-keys",
      defaultModel: "mistral-small-latest", modelExclude: "embed|moderation|ocr|codestral|devstral|voxtral|pixtral",
      prefer: ["mistral-small-latest", "mistral-medium-latest", "mistral-large-latest"],
      chunk: { count: 80, chars: 10000 }, minIntervalMs: 1500, cache: true
    },
    microsoft: {
      label: "Microsoft Translator (gratis con chiave, 2 milioni di caratteri al mese)",
      note: "Traduttore classico, più preciso di Google, senza limiti al minuto. Serve un account Azure gratuito: crea una risorsa \"Translator\" con il piano F0 e copia qui la chiave e l'area (per esempio westeurope).",
      kind: "microsoft", needsKey: true, keyUrl: "https://portal.azure.com/#create/Microsoft.CognitiveServicesTextTranslation",
      chunk: { count: 100, chars: 9000 }, minIntervalMs: 300, cache: true
    },
    deepl: {
      label: "DeepL (piano gratuito con chiave)",
      note: "Qualità molto alta. Il piano API Free ha un limite mensile di caratteri e alla registrazione chiede una carta per la verifica.",
      kind: "deepl", needsKey: true, keyUrl: "https://www.deepl.com/pro-api",
      chunk: { count: 25, chars: 5000 }, minIntervalMs: 500, cache: true
    },
    local: {
      label: "Modello sul tuo computer (Ollama o LM Studio)",
      note: "Gratis, senza limiti e privato. Il programma deve essere avviato e configurato come spiegato nel file LEGGIMI.",
      kind: "openai", local: true, defaultModel: "",
      prefer: ["gemma3:12b", "gemma3", "qwen3", "qwen2.5", "mistral", "llama3"],
      chunk: { count: 15, chars: 2500 }, cache: true
    },
    claude: {
      label: "Claude, contestuale (a pagamento)",
      note: "La chiave si crea su console.anthropic.com. Costa pochi centesimi a video.",
      kind: "claude", needsKey: true, keyUrl: "https://console.anthropic.com",
      defaultModel: "claude-haiku-4-5-20251001", staticModels: ["claude-haiku-4-5-20251001", "claude-sonnet-5"],
      chunk: { count: 100, chars: 12000 }, cache: true
    },
    youtube: {
      label: "YouTube, riga per riga",
      note: "La modalità della prima versione: veloce ma poco precisa.",
      kind: "youtube"
    }
  },

  // Quando un servizio finisce le richieste gratuite si continua con il primo di questi di cui hai la chiave
  FALLBACK: ["gemini", "groq", "mistral", "openrouter", "microsoft", "deepl"],

  // Tutte le lingue che Whisper sa trascrivere (codice → nome inglese, come lo restituisce Whisper)
  STT_LANGS: {
    en: "english", zh: "chinese", de: "german", es: "spanish", ru: "russian", ko: "korean",
    fr: "french", ja: "japanese", pt: "portuguese", tr: "turkish", pl: "polish", ca: "catalan",
    nl: "dutch", ar: "arabic", sv: "swedish", it: "italian", id: "indonesian", hi: "hindi",
    fi: "finnish", vi: "vietnamese", he: "hebrew", uk: "ukrainian", el: "greek", ms: "malay",
    cs: "czech", ro: "romanian", da: "danish", hu: "hungarian", ta: "tamil", no: "norwegian",
    th: "thai", ur: "urdu", hr: "croatian", bg: "bulgarian", lt: "lithuanian", la: "latin",
    mi: "maori", ml: "malayalam", cy: "welsh", sk: "slovak", te: "telugu", fa: "persian",
    lv: "latvian", bn: "bengali", sr: "serbian", az: "azerbaijani", sl: "slovenian", kn: "kannada",
    et: "estonian", mk: "macedonian", br: "breton", eu: "basque", is: "icelandic", hy: "armenian",
    ne: "nepali", mn: "mongolian", bs: "bosnian", kk: "kazakh", sq: "albanian", sw: "swahili",
    gl: "galician", mr: "marathi", pa: "punjabi", si: "sinhala", km: "khmer", sn: "shona",
    yo: "yoruba", so: "somali", af: "afrikaans", oc: "occitan", ka: "georgian", be: "belarusian",
    tg: "tajik", sd: "sindhi", gu: "gujarati", am: "amharic", yi: "yiddish", lo: "lao",
    uz: "uzbek", fo: "faroese", ht: "haitian creole", ps: "pashto", tk: "turkmen", nn: "nynorsk",
    mt: "maltese", sa: "sanskrit", lb: "luxembourgish", my: "myanmar", bo: "tibetan", tl: "tagalog",
    mg: "malagasy", as: "assamese", tt: "tatar", ln: "lingala", ha: "hausa", ba: "bashkir",
    jw: "javanese", su: "sundanese"
  },

  // Lingue per cui la voce online di Google esiste (le altre si pronunciano solo con una voce del computer)
  GOOGLE_TTS: ["af", "am", "ar", "bg", "bn", "bs", "ca", "cs", "cy", "da", "de", "el", "en", "es", "et", "eu", "fi", "fr", "gl",
    "gu", "ha", "he", "hi", "hr", "hu", "id", "is", "it", "ja", "jw", "km", "kn", "ko", "la", "lt", "lv", "ml", "mr", "ms", "my",
    "ne", "nl", "no", "pa", "pl", "pt", "ro", "ru", "si", "sk", "sq", "sr", "su", "sv", "sw", "ta", "te", "th", "tl", "tr", "uk",
    "ur", "vi", "zh"],

  // Nomi delle lingue come li restituisce Whisper → codici
  WHISPER_LANGS: {
    english: "en", italian: "it", spanish: "es", french: "fr", german: "de", portuguese: "pt",
    dutch: "nl", polish: "pl", romanian: "ro", russian: "ru", ukrainian: "uk", turkish: "tr",
    arabic: "ar", hindi: "hi", japanese: "ja", korean: "ko", chinese: "zh",
    greek: "el", czech: "cs", swedish: "sv", danish: "da", norwegian: "no", finnish: "fi",
    hungarian: "hu", hebrew: "he", indonesian: "id", malay: "ms", vietnamese: "vi", thai: "th",
    catalan: "ca", croatian: "hr", serbian: "sr", slovak: "sk", slovenian: "sl", bulgarian: "bg",
    persian: "fa", urdu: "ur", bengali: "bn", tamil: "ta", tagalog: "tl", swahili: "sw",
    castilian: "es", flemish: "nl", valencian: "ca", moldavian: "ro", sinhalese: "si", pushto: "ps", burmese: "my",
    "haitian creole": "ht", haitian: "ht", nynorsk: "nn", luxembourgish: "lb", letzeburgesch: "lb", panjabi: "pa", mandarin: "zh"
  },

  // Frasi per provare la voce dal popup
  TTS_SAMPLES: {
    en: "Hello, how are you today?", it: "Ciao, come stai oggi?", es: "Hola, ¿cómo estás hoy?",
    fr: "Bonjour, comment ça va aujourd'hui ?", de: "Hallo, wie geht es dir heute?", pt: "Olá, como você está hoje?",
    nl: "Hallo, hoe gaat het vandaag?", pl: "Cześć, jak się dziś masz?", ro: "Salut, ce mai faci azi?",
    ru: "Привет, как дела сегодня?", uk: "Привіт, як справи сьогодні?", tr: "Merhaba, bugün nasılsın?",
    ar: "مرحبا، كيف حالك اليوم؟", hi: "नमस्ते, आज आप कैसे हैं?", ja: "こんにちは、今日は元気ですか？",
    ko: "안녕하세요, 오늘 어떻게 지내세요?", zh: "你好，你今天好吗？"
  },

  // opts.etym: aggiungere l'etimologia (solo se Wiktionary non la ha); opts.ipa: false = senza pronuncia (pronuncia spenta)
  definePrompt(target, lang, opts = {}) {
    const t = this.LANG_EN[target] || target;
    return (
      `You are a friendly language tutor. The learner's native language is ${t}. ` +
      `They clicked a word, or selected a group of words, in a subtitle or text${lang ? ` (language: ${(() => { try { return new Intl.DisplayNames(["en"], { type: "language" }).of(String(lang).split("-")[0]) + ", code " + lang; } catch { return "code " + lang; } })()})` : ""}. ` +
      `Write every explanatory field (meaning, pos, explanation, translations, false_friend, etymology, notes) in ${t}, never in English or another language` +
      ` (even if you are asked again with another model); the meaning must be a ${t} translation, not the original word. ` +
      `Explain it AS USED IN THAT SENTENCE; if it is a group of words, explain the whole expression, not word by word. ` +
      `Reply only with JSON, no other text, in this form: ` +
      `{"lemma": "dictionary form in the original language", "pos": "part of speech, in ${t}", ` +
      `"meaning": "meaning in this sentence, in ${t}, 1-6 words", ` +
      `"explanation": "one or two short sentences in ${t} on nuance, idiom or grammar, only if useful, else empty", ` +
      `"example": "a new short example sentence in the original language", ` +
      `"example_translation": "its translation in ${t}", "lang": "ISO 639-1 code of the word's language", ` +
      `"expression": "if a single word was clicked and in this sentence it is part of an idiom, phrasal verb or fixed expression, ` +
      `that whole expression copied exactly from the sentence, character by character, in the language and script of the sentence (never translated), else empty", ` +
      `"expression_meaning": "meaning of that whole expression in ${t}, 1-6 words, else empty"` +
      (opts.ipa === false ? "" : `, "ipa": "pronunciation of the clicked word or words in the International Phonetic Alphabet, broad transcription with stress marks, without slashes"`) +
      (opts.extra ? `, "false_friend": "ONLY if the word looks or sounds like a word of ${t} (a ${t} word, not English or another language) with a different meaning, ` +
        `a short warning in ${t} naming that ${t} word (for example: careful, it does not mean ...); if there is no such ${t} word, exactly an empty string: ` +
        `never write that it is not a false friend or explain why", "related": "words with the same origin in ${t} or in other well known languages, ` +
        `useful to remember it, short, else exactly an empty string (never write that there are none)", "spelling": {"score": "0-100: how correctly the clicked word is written and used ` +
        `in this sentence (spelling and grammar; 100 = perfect)", "correct": "the correct form if it is wrong, else empty", "note": "short note in ${t} if not perfect, else empty"}` : "") +
      (opts.sentence ? `, "sentence_translation": "a correct, natural translation in ${t} of the WHOLE sentence (the given sentence translation may be wrong)"` : "") +
      (opts.etym ? `, "etymology": "origin of the word (of its dictionary form) in ${t}, 1-3 short sentences: do not stop at the word it is derived from in the same language, ` +
        `trace it back through every language to the oldest known root and its original meaning, as a good etymological dictionary does; if you are not sure, say so briefly"` : "") +
      `}`
    );
  },

  // Pronuncia in alfabeto fonetico internazionale (IPA) di un elenco di parole, chiesta una volta per parola
  ipaPrompt(lang) {
    const name = this.LANG_EN[lang] || lang;
    return (
      `You are an expert phonetician. You get a JSON list of words` + (name ? ` in ${name}` : ` (detect their language from the sentence given)`) + `. ` +
      `For each word give its standard pronunciation in the International Phonetic Alphabet (IPA): broad phonemic transcription ` +
      `as in a good dictionary, with primary stress marks (ˈ) for languages that have word stress, length marks where relevant, ` +
      `no slashes or brackets. For Chinese use IPA with tone letters, for Japanese IPA of the reading. Names and numbers too ` +
      `(numbers as spoken). Reply only with JSON in this form: {"ipa": {"word": "ipa", ...}}, with every word as a key, ` +
      `copied exactly as given (same characters and script: never convert keys to kana, pinyin or Latin letters), in the same order.`
    );
  },

  prompt(target, n, clean) {
    const lang = this.LANG_EN[target] || target;
    if (clean) return this.promptClean(target, n);
    return (
      `You translate video subtitles into ${lang}. You receive a JSON object whose "segments" array holds ` +
      `consecutive pieces of a transcript, often auto-generated: punctuation may be missing and some words may be ` +
      `misrecognized. "context_before" and "context_after" are only there to help you understand; do not translate them. ` +
      `Use the whole context to understand what is really being said and write natural, fluent ${lang} ` +
      `the way a professional subtitler would, silently fixing obvious recognition errors. ` +
      `Each segment is a separate subtitle shown at a different time: keep every translation aligned with its own segment. ` +
      `Never move words from one segment into another, never merge segments, never leave a segment empty; ` +
      `if a sentence continues in the next segment, translate only the words of this segment. ` +
      `Always translate into ${lang}, even when a segment seems to be in another language; never copy the original text. ` +
      `Short segments of one or two words (answers, interjections, greetings, exclamations) must be translated too; ` +
      `only names of people and places stay as they are. ` +
      `Do not add numbers, quotes or notes. Return exactly ${n} strings, one per segment, in the same order, ` +
      `as JSON in this form: {"t": ["...", "..."]} and nothing else.`
    );
  },

  // Traduzione e, nella stessa richiesta, pulizia della trascrizione di Whisper
  promptClean(target, n) {
    const lang = this.LANG_EN[target] || target;
    return (
      `You receive a JSON object whose "segments" array holds consecutive pieces of an automatic speech transcript ` +
      `of a video (speech recognition: words may be misheard, punctuation may be missing). "context_before" and ` +
      `"context_after" are only there to help you understand. For every segment return two things:\n` +
      `1. "src": the same segment in its ORIGINAL language, corrected. ${this.CLEAN_RULES}\n` +
      `2. "t": its translation into ${lang}, natural and fluent like a professional subtitler would write it.\n` +
      `If a segment is clearly not real speech (text invented by the speech recognizer during music, noise or silence, ` +
      `such as "thanks for watching", "I'm sorry", "it's over" out of context, subtitle credits, "[music]"), ` +
      `return an empty string for it in both arrays. ` +
      `Keep every item aligned with its own segment: never move words between segments, never merge segments. ` +
      `If a segment is already in ${lang}, "t" is simply the corrected segment. Do not add numbers, quotes or notes. ` +
      `Return exactly ${n} items in each array, as JSON in this form: {"src": ["..."], "t": ["..."]} and nothing else.`
    );
  },

  // Cosa si può correggere nella trascrizione (uguale per la correzione da sola e per quella insieme alla traduzione)
  CLEAN_RULES:
    `Fix what the speech recognizer got wrong: misheard or invented words (use the context and the meaning of the ` +
    `conversation), wrong word forms, endings and agreements, missing small words (articles, prepositions, pronouns), ` +
    `punctuation, capitalization and the spelling of names. The result must read as correct, natural written language ` +
    `in that same language. Keep the speaker's words and meaning: do not rephrase freely, summarize, shorten or translate.`,

  // Solo correzione della trascrizione (quando si traduce con Google o DeepL)
  promptCleanOnly(n) {
    return (
      `You receive a JSON object whose "segments" array holds consecutive pieces of an automatic speech transcript ` +
      `of a video. "context_before" and "context_after" are only there to help you understand. ` +
      `For every segment return the same segment in its ORIGINAL language, corrected. ${this.CLEAN_RULES} ` +
      `If a segment is clearly not real speech (text invented by the speech recognizer during music, noise or silence, ` +
      `such as "thanks for watching" out of context, subtitle credits, "[music]"), return an empty string for it. ` +
      `Keep every item aligned with its own segment: never move words between segments, never merge segments. ` +
      `Return exactly ${n} strings, as JSON in this form: {"src": ["..."]} and nothing else.`
    );
  },

  userMessage(texts, before, after) {
    return JSON.stringify({
      context_before: before || [],
      segments: texts,
      context_after: after || []
    });
  }
};

// Servizi per consultare un testo in un'altra scheda (parola o frase, dalla lingua `from` alla lingua `to`).
// Usati dai sottotitoli sul video e dalla pagina della trascrizione.
const DS_REVERSO = { ar: "arabic", de: "german", en: "english", es: "spanish", fr: "french", he: "hebrew", it: "italian", ja: "japanese",
  nl: "dutch", pl: "polish", pt: "portuguese", ro: "romanian", ru: "russian", sv: "swedish", tr: "turkish", uk: "ukrainian", zh: "chinese" };
const DS_WORDREF = new Set(["enit", "iten", "enes", "esen", "enfr", "fren", "ende", "deen", "enpt", "pten"]);
function dsServiceLinks(text, from, to, isWord, lemma) {
  text = String(text || "").replace(/\s+/g, " ").trim();
  if (!text) return [];
  const fix = { iw: "he", nb: "no", jw: "jv", in: "id", fil: "tl" };
  const base = (l) => { const b = String(l || "").split("-")[0].toLowerCase(); return fix[b] || b; };
  const f = base(from), t = base(to || "it");
  const q = encodeURIComponent(text);
  const out = [
    { label: "Google Traduttore", url: `https://translate.google.com/?sl=${f || "auto"}&tl=${to === "zh-Hans" ? "zh-CN" : t}&text=${q}&op=translate` },
    { label: "DeepL", url: `https://www.deepl.com/translator#${f || "auto"}/${t}/${q}` }
  ];
  // Reverso Context: collegamento diretto solo per le coppie di lingue che si possono aprire da un indirizzo.
  // Per le altre (per esempio il ceco) le pagine dirette rimandano alla pagina iniziale: apro quella e copio il testo,
  // così basta incollarlo e scegliere le lingue.
  if (DS_REVERSO[f] && DS_REVERSO[t] && f !== t && text.length <= 80)
    out.push({ label: "Reverso (esempi)", url: `https://context.reverso.net/translation/${DS_REVERSO[f]}-${DS_REVERSO[t]}/${q}` });
  else
    out.push({ label: "Reverso (esempi)", url: "https://context.reverso.net/translation/", copy: true,
      title: "Reverso non si apre già pronto con queste lingue: il testo viene copiato, incollalo nella casella e scegli le lingue" });
  if (isWord) {
    const w = encodeURIComponent(String(lemma || text).trim());
    if (DS_WORDREF.has(f + t)) out.push({ label: "WordReference", url: `https://www.wordreference.com/${f + t}/${w}` });
    let name = "";
    try { name = f ? new Intl.DisplayNames(["en"], { type: "language" }).of(f) : ""; } catch {}
    out.push({ label: "Wiktionary", url: `https://en.wiktionary.org/wiki/${w}` + (name && name !== f ? "#" + encodeURIComponent(name.replace(/ /g, "_")) : "") });
  }
  return out;
}


// ---------- Frasi brevi ricopiate ("Ja." → "Ja.") ----------
// Una "traduzione" con le stesse parole dell'originale non è una traduzione, anche se la frase è di una o due parole.
// Se però anche Google la lascia uguale è un nome o una parola internazionale ("Karen", "Okay"): la ricordo come
// controllata (copieOk, per lingua di arrivo) così non si richiede più.
function dsWords(t) { return String(t || "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean); }
function dsIsCopy(orig, trans) {
  const a = dsWords(orig), b = dsWords(trans);
  return a.length > 0 && a.join(" ") === b.join(" ") && !a.every((w) => /^\d+$/.test(w));
}
var dsCopyOkSet = new Set();
var dsCopyOkReady = (async () => {
  try { ((await DS_EXT.storage.local.get({ copieOk: [] })).copieOk || []).forEach((x) => dsCopyOkSet.add(x)); } catch {}
})();
function dsCopyKey(text, target) { return (target || "") + "|" + dsWords(text).join(" "); }
function dsCopyOk(text, target) { return dsCopyOkSet.has(dsCopyKey(text, target)); }
function dsMarkCopyOk(text, target) {
  const k = dsCopyKey(text, target);
  if (dsCopyOkSet.has(k)) return;
  dsCopyOkSet.add(k);
  try { DS_EXT.storage.local.set({ copieOk: [...dsCopyOkSet].slice(-3000) }); } catch {}
}
// Da rifare: copia non ancora controllata
function dsUncheckedCopy(orig, trans, target) { return !!trans && dsIsCopy(orig, trans) && !dsCopyOk(orig, target); }

// Parola "pulita" per dizionari e traduzioni: senza trattini morbidi e caratteri invisibili, e (nelle lingue
// in cirillico) senza gli accenti che indicano solo dove cade l'accento (Дорефо́рменная → Дореформенная).
// Con quegli accenti Google e Wiktionary non riconoscevano la parola e la traducevano come due pezzi.
function dsCleanWord(w) {
  let s = String(w || "").replace(/[\u00AD\u200B-\u200D\u2060\uFEFF]/g, "");
  if (/[\u0400-\u04FF]/.test(s)) s = s.normalize("NFD").replace(/[\u0300\u0301]/g, "").normalize("NFC");
  return s;
}


// ---------- Carte per Anki di Sottotitoli Doppi (file e invio diretto) ----------
function dsAnkiEsc(s) { return String(s || "").replace(/[\t\r\n]+/g, " ").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function dsAnkiMark(sentence, word) {
  const s = dsAnkiEsc(sentence), w = dsAnkiEsc(word);
  const i = s.toLowerCase().indexOf(w.toLowerCase());
  return !w || i < 0 ? s : s.slice(0, i) + "<b>" + s.slice(i, i + w.length) + "</b>" + s.slice(i + w.length);
}
function dsAnkiTime(s) {
  s = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(sec).padStart(2, "0");
}
function dsAnkiLink(e) {
  return e.videoId ? `https://www.youtube.com/watch?v=${encodeURIComponent(e.videoId)}&t=${Math.max(0, (e.time || 0) - 2)}s` : (e.url || "");
}
function dsAnkiFields(e) {
  const front = `<b>${dsAnkiEsc(e.word)}</b>` + (e.sentence ? `<br><br><i>${dsAnkiMark(e.sentence, e.word)}</i>` : "");
  let back = `<b>${dsAnkiEsc(e.meaning || "")}</b>`;
  const info = [e.lemma && e.lemma.toLowerCase() !== (e.word || "").toLowerCase() ? dsAnkiEsc(e.lemma) : "", dsAnkiEsc(e.pos)].filter(Boolean).join(" · ");
  if (info) back += `<br>${info}`;
  if (e.ipa) back += `<br>/${dsAnkiEsc(e.ipa)}/`;
  if (e.gender) back += `<br><small>${dsAnkiEsc(e.gender)}</small>`;
  if (e.etym) back += `<br><small>Etimologia: ${dsAnkiEsc(e.etym)}</small>`;
  if (e.explanation) back += `<br>${dsAnkiEsc(e.explanation)}`;
  if (e.sentenceTrans) back += `<br><br><i>${dsAnkiEsc(e.sentenceTrans)}</i>`;
  const link = dsAnkiLink(e);
  if (link) back += `<br><br><a href="${link}">${dsAnkiEsc(e.title || "Video")}${e.videoId ? " (" + dsAnkiTime(e.time) + ")" : ""}</a>`;
  const tags = ["sottotitoli-doppi", String(e.lang || "").split("-")[0]].filter(Boolean);
  return { front, back, tags };
}
// Nome del mazzo: un mazzo per lingua ("Lingue::Inglese") oppure uno solo
function dsAnkiLangName(lang) {
  const b = String(lang || "").split("-")[0].toLowerCase();
  if (!b || b === "?" || b === "auto") return "Altre lingue";
  try { const n = new Intl.DisplayNames(["it"], { type: "language" }).of(b); if (n && n.toLowerCase() !== b) return n.charAt(0).toUpperCase() + n.slice(1); } catch {}
  return b.toUpperCase();
}
function dsAnkiDeckFor(lang, o) {
  if (o && o.perLang !== false) {
    const tpl = String((o && o.tpl) || "Lingue::{lingua}").trim() || "Lingue::{lingua}";
    return /\{lingua\}/i.test(tpl) ? tpl.replace(/\{lingua\}/gi, dsAnkiLangName(lang)) : tpl + "::" + dsAnkiLangName(lang);
  }
  return String((o && o.deck) || "Sottotitoli Doppi").trim() || "Sottotitoli Doppi";
}

// ---------- Scambio tra Sottotitoli Doppi e Parole al Volo: vocabolario e parole che conosci ----------
// Le due estensioni hanno memorie separate: si passa da una all'altra con un file (Esporta qui, Importa là).
// Si unisce, non si sostituisce: niente si perde, e importare due volte lo stesso file non crea doppioni.
const DS_SWAP_FORMAT = "parole-sottotitoli-1";
async function dsExportData(what) {
  const l = await DS_EXT.storage.local.get({ vocab: {}, knownWords: {} });
  const out = { format: DS_SWAP_FORMAT, from: typeof PAV_DEFAULTS !== "undefined" ? "Parole al Volo" : "Sottotitoli Doppi", date: new Date().toISOString() };
  if (what.known !== false) {
    out.knownWords = {};
    for (const [lg, s] of Object.entries(l.knownWords || {})) { const w = String(s || "").split("\n").filter(Boolean); if (w.length) out.knownWords[lg] = w; }
  }
  if (what.vocab !== false) out.vocab = l.vocab || {};
  const name = (what.vocab === false ? "parole-che-conosco" : "vocabolario-e-parole-che-conosco") + "-" + (typeof PAV_DEFAULTS !== "undefined" ? "parole-al-volo" : "sottotitoli-doppi") + "-" + out.date.slice(0, 10) + ".json";
  const blob = new Blob([JSON.stringify(out, null, 1)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  return { known: Object.values(out.knownWords || {}).reduce((n, x) => n + x.length, 0), vocab: Object.keys(out.vocab || {}).length, name };
}
// text: il contenuto del file. Un file .json di una delle due estensioni, oppure un elenco di parole (una per riga)
// che diventano "parole che conosco" nella lingua txtLang.
async function dsImportData(text, txtLang) {
  let data = null;
  try { data = JSON.parse(text); } catch {}
  const l = await DS_EXT.storage.local.get({ vocab: {}, knownWords: {} });
  const kw = { ...(l.knownWords || {}) };
  const vocab = { ...(l.vocab || {}) };
  let addedKnown = 0, addedVocab = 0, updatedVocab = 0;
  const addKnown = (lg, words) => {
    lg = String(lg || "").split("-")[0].toLowerCase();
    if (!lg) return;
    const set = new Set(String(kw[lg] || "").split("\n").filter(Boolean));
    for (const w0 of words) { const w = String(w0 || "").toLowerCase().trim(); if (w && !set.has(w)) { set.add(w); addedKnown++; } }
    kw[lg] = [...set].join("\n");
  };
  if (data && typeof data === "object" && !Array.isArray(data)) {
    const known = data.knownWords || (data.format ? null : data.known);
    if (known) for (const [lg, ws] of Object.entries(known)) addKnown(lg, Array.isArray(ws) ? ws : String(ws || "").split("\n"));
    const v = data.vocab || (!data.format && !data.knownWords && Object.values(data).every((x) => x && typeof x === "object" && x.word) ? data : null);
    if (v) for (const e0 of Object.values(v)) {
      if (!e0 || typeof e0 !== "object" || !e0.word) continue;
      const id = e0.id || [String(e0.lang || "?").split("-")[0].toLowerCase(), String(e0.lemma || e0.word).toLowerCase().trim()].join("|");
      const cur = vocab[id];
      if (!cur) { vocab[id] = { ...e0, id }; addedVocab++; continue; }
      // c'è già: tengo la mia, ma prendo quello che manca e "imparata" se l'altra lo dice
      let ch = false;
      for (const [k, val] of Object.entries(e0)) if ((cur[k] == null || cur[k] === "") && val != null && val !== "") { cur[k] = val; ch = true; }
      if (e0.status === "known" && cur.status !== "known") { cur.status = "known"; ch = true; }
      if (ch) updatedVocab++;
    }
    if (!known && !v) throw new Error("questo file non contiene né parole né vocabolario");
  } else {
    if (!txtLang) throw new Error("scegli prima la lingua delle parole");
    const words = String(text || "").split(/[\r\n,;\t]+/).map((x) => x.trim().split(/\s+/)[0]).filter((x) => x && /\p{L}/u.test(x));
    if (!words.length) throw new Error("nel file non ci sono parole");
    addKnown(txtLang, words);
  }
  // le parole del vocabolario segnate come imparate diventano anche "parole che conosco"
  for (const e of Object.values(vocab)) if (e.status === "known" && e.kind !== "text" && e.word && !/\s/.test(String(e.word).trim())) addKnown(e.lang, [e.word]);
  await DS_EXT.storage.local.set({ knownWords: kw, vocab });
  return { addedKnown, addedVocab, updatedVocab };
}
// riga di testo per dire com'è andata
function dsImportReport(r) {
  return `Fatto: ${r.addedKnown} parole conosciute nuove` + (r.addedVocab || r.updatedVocab ? `, ${r.addedVocab} voci nuove nel vocabolario` + (r.updatedVocab ? ` (${r.updatedVocab} completate)` : "") : "") + ".";
}

// ---------- Livelli delle parole ----------
// Per tutte le lingue: un livello indicativo (come A1…C2 del QCER) ricavato solo dalla posizione nell'elenco delle
// parole più usate. Non è un elenco ufficiale: serve per orientarsi e per aprire le parole "dello stesso livello".
const DS_LEVELS = [
  { id: "A1", from: 1, to: 500 }, { id: "A2", from: 501, to: 1000 }, { id: "B1", from: 1001, to: 2000 },
  { id: "B2", from: 2001, to: 4000 }, { id: "C1", from: 4001, to: 8000 }, { id: "C2", from: 8001, to: 16000 }
];
function dsLevelOf(rank) { return rank ? DS_LEVELS.find((l) => rank >= l.from && rank <= l.to) || null : null; }
// Giapponese: i livelli ufficiali JLPT (N5 il più facile … N1), elenchi da Jisho
const DS_JLPT = ["N5", "N4", "N3", "N2", "N1"];

// ---------- Sincronizzazione diretta con le altre estensioni (senza file) ----------
// Le estensioni sorelle: Sottotitoli Doppi, Parole al Volo e l'estensione unica che le contiene tutte e due.
// Ognuna si sincronizza con le altre installate. Firefox: gli indirizzi sono fissi. Edge/Chrome: cambiano da computer
// a computer, quindi si cercano per nome (permesso "gestione estensioni", chiesto solo la prima volta).
const DS_UNI_NAME = "Sottotitoli Doppi + Parole al Volo";
const DS_SIBLINGS = { "Sottotitoli Doppi": "sottotitoli-doppi@estensione.local", "Parole al Volo": "parole-al-volo@estensione.local",
  [DS_UNI_NAME]: "sottotitoli-parole@estensione.local" };
const dsSelfName = () => { try { return DS_EXT.runtime.getManifest().name; } catch { return ""; } };
const dsSiblingNames = () => Object.keys(DS_SIBLINGS).filter((n) => n !== dsSelfName());
const dsOtherName = () => dsSiblingNames().join(" / ");
const dsIsGecko = () => { try { return DS_EXT.runtime.getURL("").startsWith("moz-extension:"); } catch { return false; } };
// Impostazioni e chiavi passano anche loro (solo dove nell'altra non sono ancora state scelte: niente si sovrascrive).
// Alcune impostazioni hanno lo stesso nome ma un altro significato in Sottotitoli Doppi e in Parole al Volo: viaggiano
// separate ("sd" e "pav"); nell'estensione unica quelle di Parole al Volo hanno il prefisso (unica-pav.js).
const DS_SET_CONFLICT = { engine: "pavEngine", disabledSites: "pavDisabledSites", ankiDeck: "pavAnkiDeck", learnKnownPage: "pavKnownPage", roman: "pavRoman" };
const dsRole = () => (dsSelfName() === DS_UNI_NAME ? "uni" : dsSelfName() === "Parole al Volo" ? "pav" : "sd");
async function dsSettingsOut() {
  const all = await DS_EXT.storage.sync.get(null), role = dsRole();
  const out = { shared: {}, sd: {}, pav: {} };
  const pavNames = {};
  for (const k in DS_SET_CONFLICT) pavNames[DS_SET_CONFLICT[k]] = k;
  for (const [k, v] of Object.entries(all)) {
    if (k in DS_SET_CONFLICT) out[role === "pav" ? "pav" : "sd"][k] = v;
    else if (role === "uni" && pavNames[k]) out.pav[pavNames[k]] = v;
    else out.shared[k] = v;
  }
  return out;
}
// riempie solo le impostazioni che qui non sono mai state scelte; restituisce quante
async function dsSettingsIn(inc) {
  if (!inc || typeof inc !== "object") return 0;
  const role = dsRole(), have = await DS_EXT.storage.sync.get(null), put = {};
  const add = (k, v) => { if (v !== undefined && !(k in have) && !(k in put)) put[k] = v; };
  for (const [k, v] of Object.entries(inc.shared || {})) if (!(k in DS_SET_CONFLICT) && !Object.values(DS_SET_CONFLICT).includes(k)) add(k, v);
  if (role !== "pav") for (const [k, v] of Object.entries(inc.sd || {})) if (k in DS_SET_CONFLICT) add(k, v);
  for (const [k, v] of Object.entries(inc.pav || {})) if (k in DS_SET_CONFLICT) { if (role === "pav") add(k, v); else if (role === "uni") add(DS_SET_CONFLICT[k], v); }
  // i modelli scelti per ogni servizio: aggiungo quelli che mancano
  if (inc.shared && inc.shared.models && typeof inc.shared.models === "object" && have.models) {
    const m = { ...have.models };
    let ch = false;
    for (const [e, v] of Object.entries(inc.shared.models)) if (v && !m[e]) { m[e] = v; ch = true; }
    if (ch) put.models = m;
  }
  if (Object.keys(put).length) await DS_EXT.storage.sync.set(put);
  return Object.keys(put).length;
}
// chiavi dei servizi: aggiungo quelle che qui mancano (le mie restano)
async function dsKeysIn(inc) {
  if (!inc || typeof inc !== "object") return 0;
  const l = await DS_EXT.storage.local.get({ keys: {} }), keys = { ...(l.keys || {}) };
  let n = 0;
  for (const [k, v] of Object.entries(inc)) if (typeof v === "string" && v.trim() && !String(keys[k] || "").trim()) { keys[k] = v; n++; }
  if (n) await DS_EXT.storage.local.set({ keys });
  return n;
}
// chi chiede è davvero una sorella? Firefox: indirizzo fisso. Edge/Chrome: nome nell'elenco delle estensioni installate
// (solo se questa estensione ha già il permesso di vederlo); altrimenti le chiavi non le mando indietro.
async function dsTrusted(sender, from) {
  if (!sender || !sender.id) return false;
  if (dsIsGecko()) return sender.id === DS_SIBLINGS[from];
  try {
    if (!DS_EXT.management || !(await DS_EXT.permissions.contains({ permissions: ["management"] }))) return false;
    const x = await DS_EXT.management.get(sender.id);
    return !!(x && x.name === from && x.enabled);
  } catch { return false; }
}

// le sorelle installate: [{ name, id }] (in Firefox tutte quelle possibili: quelle che mancano non rispondono)
async function dsSiblingIds() {
  const names = dsSiblingNames();
  if (dsIsGecko()) return names.map((name) => ({ name, id: DS_SIBLINGS[name] }));
  let ok = false;
  try { ok = await DS_EXT.permissions.request({ permissions: ["management"] }); } catch {}
  if (!ok || !DS_EXT.management) throw new Error("per trovare le altre estensioni serve il permesso di vedere le estensioni installate (puoi usare invece Esporta/Importa)");
  const all = await DS_EXT.management.getAll();
  const found = [];
  for (const name of names) {
    const x = all.find((e) => e.name === name && e.type === "extension");
    if (x && x.enabled) found.push({ name, id: x.id });
  }
  if (!found.length) {
    const off = all.filter((e) => names.includes(e.name) && !e.enabled).map((e) => e.name);
    throw new Error(off.length ? `${off.join(" e ")}: è spenta, accendila e riprova` : `nessuna delle altre estensioni (${names.join(", ")}) è installata`);
  }
  return found;
}
// what: { known: true, vocab: false } — manda le mie a ogni sorella, riceve le sue, unisce tutto da tutte le parti
async function dsSyncWithSibling(what = { known: true, vocab: false }) {
  const sibs = await dsSiblingIds();
  const here = { addedKnown: 0, addedVocab: 0, updatedVocab: 0 }, there = [], missing = [];
  // con più sorelle, un secondo giro: le prime ricevono anche quello che è arrivato dalle ultime
  const rounds = sibs.length > 1 ? [...sibs, ...sibs.slice(0, -1).map((x) => ({ ...x, again: true }))] : sibs;
  for (const sib of rounds) {
    if (sib.again && !there.some((x) => x.name === sib.name)) continue;
    const l = await DS_EXT.storage.local.get({ knownWords: {}, vocab: {} });
    const mine = { format: DS_SWAP_FORMAT, from: dsSelfName(), knownWords: {} };
    for (const [lg, s] of Object.entries(l.knownWords || {})) mine.knownWords[lg] = String(s || "").split("\n").filter(Boolean);
    if (what.vocab) mine.vocab = l.vocab || {};
    if (what.keys !== false) {
      mine.keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
      mine.settings = await dsSettingsOut();
    }
    let r;
    try { r = await DS_EXT.runtime.sendMessage(sib.id, { type: "dsSync", data: mine, vocab: !!what.vocab, keys: what.keys !== false }); }
    catch { missing.push(sib.name); continue; }
    if (!r || r.error || !r.data) { missing.push(sib.name + ((r && r.error) ? " (" + r.error + ")" : "")); continue; }
    const got = await dsImportData(JSON.stringify(r.data), "");
    here.addedKnown += got.addedKnown; here.addedVocab += got.addedVocab; here.updatedVocab += got.updatedVocab;
    here.keys = (here.keys || 0) + await dsKeysIn(r.data.keys);
    here.settings = (here.settings || 0) + await dsSettingsIn(r.data.settings);
    if (r.keysWithheld && !sib.again) (here.withheld = here.withheld || []).push(sib.name);
    if (sib.again) {   // stesso giro di prima: sommo quello che ha ricevuto in più
      const t = there.find((x) => x.name === sib.name), res = r.result || {};
      t.addedKnown = (t.addedKnown || 0) + (res.addedKnown || 0); t.addedVocab = (t.addedVocab || 0) + (res.addedVocab || 0);
    } else there.push({ name: sib.name, ...(r.result || {}) });
  }
  if (!there.length) {
    throw new Error(dsIsGecko() ? `nessuna delle altre estensioni ha risposto (${dsSiblingNames().join(", ")}): sono installate, accese e aggiornate?`
      : `${missing.join(", ")} non risponde: aggiornala all'ultima versione e controlla che sia accesa`);
  }
  return { here, there, missing: dsIsGecko() ? [] : missing, other: there.map((x) => x.name).join(" e ") };
}
// dal lato che riceve (background): unisce quello che arriva e risponde con quello che ha
async function dsSyncReceive(msg, sender) {
  const from = msg && msg.data && msg.data.from;
  if (!from || !dsSiblingNames().includes(from)) throw new Error("estensione non riconosciuta");
  if (dsIsGecko() && sender && sender.id !== DS_SIBLINGS[from]) throw new Error("estensione non riconosciuta");
  const result = await dsImportData(JSON.stringify(msg.data), "");
  result.keys = await dsKeysIn(msg.data.keys);
  result.settings = await dsSettingsIn(msg.data.settings);
  const l = await DS_EXT.storage.local.get({ knownWords: {}, vocab: {} });
  const data = { format: DS_SWAP_FORMAT, from: dsSelfName(), knownWords: {} };
  for (const [lg, s] of Object.entries(l.knownWords || {})) data.knownWords[lg] = String(s || "").split("\n").filter(Boolean);
  if (msg.vocab) data.vocab = l.vocab || {};
  let keysWithheld = false;
  if (msg.keys) {
    data.settings = await dsSettingsOut();
    if (await dsTrusted(sender, from)) data.keys = (await DS_EXT.storage.local.get({ keys: {} })).keys || {};
    else keysWithheld = true;
  }
  return { data, result, keysWithheld };
}
function dsSyncReport(r) {
  const there = Array.isArray(r.there) ? r.there : [{ name: r.other, ...(r.there || {}) }];
  return `Fatto: qui ${r.here.addedKnown} parole conosciute nuove` + (r.here.addedVocab ? ` e ${r.here.addedVocab} voci` : "") + "; " +
    there.map((x) => `in ${x.name} ${x.addedKnown || 0}` + (x.addedVocab ? ` e ${x.addedVocab} voci` : "")).join(", ") +
    ". Ora hanno le stesse." +
    (r.here.keys || r.here.settings || there.some((x) => x.keys || x.settings)
      ? ` Chiavi copiate: qui ${r.here.keys || 0}` + there.map((x) => `, in ${x.name} ${x.keys || 0}`).join("") +
        `; impostazioni prese: qui ${r.here.settings || 0}` + there.map((x) => `, in ${x.name} ${x.settings || 0}`).join("") + "." : "") +
    (r.here.withheld && r.here.withheld.length ? ` Le chiavi di ${r.here.withheld.join(" e ")} non sono arrivate (per sicurezza): premi ⇄ anche dentro ${r.here.withheld.length > 1 ? "quelle" : "quella"}.` : "") +
    (r.missing && r.missing.length ? ` (Non ha risposto: ${r.missing.join(", ")}.)` : "");
}

// Una parte di testo è una parola? In Firefox lo spezzatore di parole a volte non considera "parola" alcune
// sillabe giapponesi (は, い, わ…): basta che contenga una lettera o una cifra.
function dsIsWord(sg) { return !!(sg && (sg.isWordLike || /[\p{L}\p{N}]/u.test(sg.segment || ""))); }

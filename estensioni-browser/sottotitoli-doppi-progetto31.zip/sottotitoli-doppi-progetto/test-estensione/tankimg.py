import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(900)
        await pp.evaluate("document.getElementById('dAnki').open=true")
        print("1. nella sezione Anki:", await pp.evaluate("!!document.querySelector('#dAnki #ankiImage')"))
        await pp.check("#ankiImage"); await pp.check("#ankiAuto"); await pp.wait_for_timeout(300)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false})")
        pg = await ctx.new_page(); pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=imgTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(1500)
        await pg.locator(".dualsub-card .dualsub-star").click(); await pg.wait_for_timeout(2500)
        notes = list(log.get("anki_notes", {}).values())
        import re as _re
        print("2. carta Anki con immagine:", _re.findall(r'<img src="[^"]+">', notes[-1]["Fronte"]) if notes else None, "| file in Anki:", [m for m in log.get("anki_media", []) if "-img-" in m])
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

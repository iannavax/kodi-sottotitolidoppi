# 1.4.5: «Modello per ogni compito» nel popup (sottotitoli, pagine, trascrizione, spiegazioni, correzione, pronuncia,
# collegamento parole); la pronuncia con Ollama è in test-volo/tipa_task_volo.py
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test', groq:'gsk'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'google', models:{local:'gemma4:e4b'}, targetLang:'it', ipa:true, learnExamples:false, learnSpell:false, learnFreq:false, learnLlmExtra:false})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1500); await pp.evaluate("document.querySelectorAll('details').forEach(d=>d.open=true)"); await pp.wait_for_timeout(400)
        rows = await pp.evaluate("[...document.querySelectorAll('.ds-tasks')].map(w => [...w.querySelectorAll('label')].map(l => l.firstChild.textContent.trim()))")
        print("1. pannelli:", len(rows), "| righe del primo:", rows[0] if rows else None)
        await pp.select_option(".ds-tasks .ds-task-ipa >> nth=0", "local"); await pp.wait_for_timeout(300)
        await pp.select_option(".ds-tasks .ds-task-clean >> nth=0", "gemini"); await pp.wait_for_timeout(300)
        print("2. salvato:", await sw.evaluate("chrome.storage.sync.get(['ipaEngine','cleanEngine','engine','alignEngine']).then(r=>JSON.stringify(r))"))
        # 1.6.2: ogni compito ha la tendina del servizio e quella del modello (qui: sottotitoli e trascrizione)
        await pp.select_option(".ds-tasks .ds-task-video", "gemini"); await pp.wait_for_timeout(800)
        eng = await sw.evaluate("chrome.storage.sync.get('engine').then(r=>r.engine)")
        rows = await pp.evaluate("(()=>{const s=document.querySelector('.ds-tasks .ds-task-video'); const lab=s.closest('label'); let n=lab.nextElementSibling; while(n && !n.classList.contains('ds-task-model')) n=n.nextElementSibling; return n ? [...n.querySelectorAll('.ds-task-mrow')].map(r=>r.innerText.replace(/\\n/g,' ')) : []})()")
        addSel = await pp.evaluate("document.querySelectorAll('.ds-tasks .ds-task-model select').length")
        stt = await pp.evaluate("[document.querySelectorAll('.ds-tasks .ds-task-stt').length, document.querySelectorAll('.ds-tasks .ds-task-sttmodel').length]")
        print("3. sottotitoli:", eng, "| modelli:", rows, "| tendine dei modelli:", addSel, "| trascrizione (servizio, modello):", stt)
        ok = eng == "gemini" and len(rows) >= 2 and addSel >= 3 and stt == [1, 1]
        print("errori:", errs if ok else errs + ["pannello dei compiti non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

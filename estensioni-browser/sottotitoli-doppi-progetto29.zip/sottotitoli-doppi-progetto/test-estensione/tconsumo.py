# 1.6.0: «Consumo delle richieste»: la modalità scelta resta (e non diventa «Personalizzato» da sola)
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1200)
        res = {}
        for m in ["quality", "balanced", "saving", "free"]:
            await pp.select_option("#consumo", m); await pp.wait_for_timeout(500)
            await pp.reload(); await pp.wait_for_timeout(1000)
            res[m] = await pp.eval_on_selector("#consumo", "e=>e.value")
        print("modalità dopo ricarica:", res)
        ok = all(k == v for k, v in res.items())
        print("errori:", errs if ok else errs + ["consumo non resta"])
        await ctx.close()
asyncio.run(main())

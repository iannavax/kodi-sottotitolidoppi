# 1.6.0: modi di dire senza richieste in più: dal dizionario di Wiktionary (walk home → «walked home») e dalla stessa
import os; os.environ["TR_IDIOMS"] = "1"
# richiesta della traduzione con Gemini («fresh bread»), sottolineati; nessuna richiesta di allineamento
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', targetLang:'it', ipa:false, learnExamples:false, learnSpell:false, learnFreq:false, learnLlmExtra:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        seen = {}
        for _ in range(120):
            o = await pg.evaluate("(document.querySelector('.dualsub-orig')||{}).textContent||''")
            u = await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-idiom')].map(x=>x.textContent).join(' ')")
            if o and u: seen[o] = u
            await pg.wait_for_timeout(250)
            if "market" in o and "walked" in u and "fresh" in u: await pg.evaluate("document.querySelector('video').pause()"); break
            if len(seen) >= 2 and any("walked" in v for v in seen.values()) and any("fresh" in v for v in seen.values()): break
        print("1. sottolineati:", seen)
        print("2. dizionario chiesto:", log.get("idiomdict"), "| traduzioni con modi di dire:", log.get("tr_idioms_asked"), "| allineamenti:", len(log.get("align", [])))
        # 🔎 nella scheda di «market»: una richiesta, poi sottolineato
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        print("   parole:", texts)
        if "market" in texts:
            await words.nth(texts.index("market")).click(); await pg.wait_for_timeout(2000)
            b = pg.locator(".dualsub-card .dualsub-idiomask"); nb = await b.count()
            if nb: await b.first.click(); await pg.wait_for_timeout(2500)
            hint = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-card-hint')].map(x=>x.textContent).join(' | ')")
            und = await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-idiom')].map(x=>x.textContent).join(' ')")
            print("3. 🔎:", nb, "| richieste:", log.get("idiomsFind"), "|", hint[:160], "| sottolineati:", und)
            seen["ask"] = "went to the market" in und and nb == 1 and len(log.get("idiomsFind", [])) == 1
        ok = seen.get("ask") and any("walked home" in v for v in seen.values()) and any("fresh bread" in v for v in seen.values()) and log.get("tr_idioms_asked")
        print("errori:", errs if ok else errs + ["modi di dire gratis non vanno"], log["errors"])
        await ctx.close()
asyncio.run(main())

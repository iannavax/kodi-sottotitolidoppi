# Parole conosciute di tutte le lingue verso l'estensione unica: con ⇄ Sincronizza (tre estensioni) e con un file
import asyncio, os, sys, json
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import charness
SD, PAV, UNI = sys.argv[1], sys.argv[2], sys.argv[3]
KW = "chrome.storage.local.get('knownWords').then(r=>JSON.stringify(r.knownWords||{}))"
async def main():
    errs = []
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, accept_downloads=True,
            args=[f"--disable-extensions-except={SD},{PAV},{UNI}", f"--load-extension={SD},{PAV},{UNI}"])
        await ctx.route("**/*", charness.handle)
        await asyncio.sleep(2)
        ids = {}
        for sw in ctx.service_workers:
            ids[await sw.evaluate("chrome.runtime.getManifest().name")] = (sw, sw.url.split("/")[2])
        (sd, sdid), (pav, pavid), (uni, uniid) = ids["Sottotitoli Doppi"], ids["Parole al Volo"], ids["Sottotitoli Doppi + Parole al Volo"]
        await sd.evaluate("chrome.storage.local.set({knownWords:{ru:'кошка\\nдом\\nспасибо', de:'haus\\nund'}})")
        await pav.evaluate("chrome.storage.local.set({knownWords:{cs:'ahoj\\npivo'}})")
        # A) con un file: Sottotitoli Doppi → Esporta, estensione unica → Importa
        fp = await ctx.new_page(); fp.on("pageerror", lambda e: errs.append(str(e)))
        await fp.goto(f"chrome-extension://{sdid}/freq.html?lang=ru"); await fp.wait_for_timeout(1200)
        async with fp.expect_download() as d:
            await fp.click("#exp")
        path = "/tmp/claude-0/parole.json"; await (await d.value).save_as(path)
        print("A. esportato:", await fp.inner_text("#impMsg"), "| lingue nel file:", sorted(json.load(open(path))["knownWords"]))
        up = await ctx.new_page(); up.on("pageerror", lambda e: errs.append(str(e)))
        await up.goto(f"chrome-extension://{uniid}/freq.html?lang=de"); await up.wait_for_timeout(1200)
        await up.set_input_files("#impFile", path); await up.wait_for_timeout(800)
        print("   importato nell'unica:", await up.inner_text("#impMsg"), "|", await uni.evaluate(KW))
        # B) con ⇄ dall'estensione unica: prende anche quelle di Parole al Volo (nel banco il permesso non si concede: do io gli indirizzi)
        print("B. pagina:", await up.inner_text("#swapTitle"))
        await up.evaluate(f"dsSiblingIds = async () => [{{name:'Sottotitoli Doppi', id:'{sdid}'}}, {{name:'Parole al Volo', id:'{pavid}'}}]")
        await up.click("#sync"); await up.wait_for_timeout(2000)
        print("   ", await up.inner_text("#impMsg"))
        for n, sw in (("unica", uni), ("SD", sd), ("PAV", pav)): print(f"   {n}:", await sw.evaluate(KW))
        # C) da Sottotitoli Doppi verso l'unica (anche nell'altro verso)
        await uni.evaluate("chrome.storage.local.get('knownWords').then(r=>{const k=r.knownWords; k.ja='勉強'; return chrome.storage.local.set({knownWords:k})})")
        await fp.evaluate(f"dsSiblingIds = async () => [{{name:'Sottotitoli Doppi + Parole al Volo', id:'{uniid}'}}]")
        await fp.click("#sync"); await fp.wait_for_timeout(1500)
        print("C. da SD:", await fp.inner_text("#impMsg"), "| SD ja:", json.loads(await sd.evaluate(KW)).get("ja"))
        r = await fp.evaluate(f"chrome.runtime.sendMessage('{uniid}', {{type:'dsSync', data:{{from:'Altro', knownWords:{{en:['x']}}}}}})")
        print("D. estraneo:", r)
        print("errori:", errs, charness.log.get("errors"))
        await ctx.close()
asyncio.run(main())

//go:build !windows

package main

import (
	"os/exec"
	"syscall"
)

// ogni programma avviato è in un gruppo suo: si chiude insieme ai programmi che avvia
func setupProc(c *exec.Cmd) {
	c.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
}

func killTree(c *exec.Cmd) {
	if c == nil || c.Process == nil {
		return
	}
	_ = syscall.Kill(-c.Process.Pid, syscall.SIGKILL)
	_ = c.Process.Kill()
}

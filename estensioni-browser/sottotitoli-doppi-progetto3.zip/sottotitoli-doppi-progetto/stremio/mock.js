// Servizi simulati: OpenSubtitles (Stremio), Google Traduttore, Gemini
const http = require("http");
const tr = (x) => x.split(" ").map((w) => [...w].reverse().join("")).join(" ");
const lines = Array.from({ length: Number(process.env.MOCK_LINES) || 60 }, (_, i) => `this is the line number ${i + 1} of the film`);
const hms = (s) => `${String(Math.floor(s / 3600)).padStart(2, "0")}:${String(Math.floor(s / 60) % 60).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
const srt = lines.map((l, i) => `${i + 1}\n${hms(i * 3)},000 --> ${hms(i * 3 + 2)},500\n<i>${l}</i>\n`).join("\n");
const log = { gemini: 0, google: 0, os: [] };
const MODE = process.env.GEM_MODE || "";
http.createServer((req, res) => {
  const u = new URL(req.url, "http://x");
  let body = "";
  req.on("data", (d) => (body += d));
  req.on("end", () => {
    if (u.pathname === "/log") return res.end(JSON.stringify(log));
    if (u.pathname.startsWith("/subtitles/")) {
      log.os.push(u.pathname);
      return res.end(JSON.stringify({ subtitles: [
        { id: "1", url: `http://127.0.0.1:7801/file/eng1.srt`, lang: "eng" },
        { id: "2", url: `http://127.0.0.1:7801/file/ita1.srt`, lang: "ita" },
        { id: "3", url: `http://127.0.0.1:7801/file/eng2.srt`, lang: "eng" },
        { id: "4", url: `http://127.0.0.1:7801/file/fre1.srt`, lang: "fre" },
        { id: "5", url: `http://127.0.0.1:7801/file/jpn1.srt`, lang: "jpn" },
        { id: "6", url: `http://127.0.0.1:7801/file/hun1.srt`, lang: "hun" },
        // molte lingue con più sottotitoli di quella del film (prima ne restavano solo 12 e il norvegese spariva)
        ...["spa", "ger", "dut", "pol", "rum", "rus", "tur", "ara", "kor", "chi", "gre", "cze", "swe", "dan", "fin"].flatMap((l, k) =>
          [0, 1].map((j) => ({ id: `m${k}${j}`, url: `http://127.0.0.1:7801/file/${l}${j}.srt`, lang: l }))),
        { id: "n1", url: `http://127.0.0.1:7801/file/nor1.srt`, lang: "nor" } ] }));
    }
    if (u.pathname.startsWith("/meta/")) {
      log.meta = (log.meta || 0) + 1;
      const id = u.pathname.split("/").pop().replace(".json", "");
      const country = id === "tt0111161" ? "Norway, Sweden" : id === "tt0000002" ? "Czech Republic" : "";
      return res.end(JSON.stringify({ meta: { id, name: "Film", country } }));
    }
    if (u.pathname.startsWith("/file/")) return res.end(srt);
    if (u.pathname.startsWith("/translate_a/")) {
      log.google++; (log.sl = log.sl || []).push(u.searchParams.get("sl"));
      const q = u.searchParams.get("q");
      return setTimeout(() => res.end(JSON.stringify([[[q.split("\n").map((l) => "IT[" + tr(l) + "]").join("\n"), q]], null, "en"])), Number(process.env.GOOGLE_DELAY || 0));
    }
    if (u.pathname.endsWith("/chat/completions")) {
      log.gemini++;
      const segs = JSON.parse(JSON.parse(body).messages[1].content).segments;
      let t = segs.map((s) => "GEM[" + tr(s) + "]");
      if (MODE === "shift" && segs.length > 1) t = ["GEM[" + tr(segs.join(" ")) + "]", ...segs.slice(1).map(() => "")];
      setTimeout(() => res.end(JSON.stringify({ choices: [{ message: { content: JSON.stringify({ t }) } }] })), Number(process.env.GEM_DELAY || 300));
      return;
    }
    res.statusCode = 404; res.end();
  });
}).listen(7801, "127.0.0.1");

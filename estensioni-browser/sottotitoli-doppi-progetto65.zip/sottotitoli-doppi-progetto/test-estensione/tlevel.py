import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:false, levelColors:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(2500)
        print(await pg.evaluate("[...document.querySelectorAll('.dualsub-orig .dualsub-word')].map(w=>w.textContent+':'+(w.className.match(/lv\\d/)||['-'])[0])"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

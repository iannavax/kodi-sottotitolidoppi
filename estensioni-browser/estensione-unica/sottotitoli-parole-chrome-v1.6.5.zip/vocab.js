// Il mio vocabolario — pagina comune a Sottotitoli Doppi e Parole al Volo (stesso file nelle due estensioni).
// Usa: DS_EXT, dsAnki* (config.js), DS_TTS (tts.js), DS_ETYM (etym.js), DS_LEARN (learn.js);
// in Parole al Volo anche PAV_* (volo-config.js, aggiunto dal build).
const $ = (id) => document.getElementById(id);
const PAV = typeof PAV_DEFAULTS !== "undefined";
let vocab = {};
let view = {};
let target = "it";
const ngOpen = new Set();   // voci con il grafico dell'uso nel tempo aperto
const pickers = new Map();   // voce → immagine che stai scegliendo (lo stato del selettore)
const VIEW = [
  ["ipa", "Pronuncia IPA", true], ["translit", "Trascrizione", true], ["meaning", "Significato", true], ["expl", "Spiegazione", true],
  ["sentence", "Frase", true], ["sentTrans", "Traduzione della frase", true], ["etym", "Etimologia", false], ["gender", "Genere", true],
  ["freq", "Frequenza", false], ["image", "Immagine", true], ["source", "Da dove viene", true], ["audio", "Pulsanti di ascolto", true],
  ["examples", "Esempi veri (Tatoeba, quando li apri)", false]
];
const show = (k) => view[k] !== false && (view[k] === true || (VIEW.find((v) => v[0] === k) || [])[2]);

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
}
const langName = (l) => { try { return new Intl.DisplayNames([dsUiLocale()], { type: "language" }).of(String(l).split("-")[0]) || l; } catch { return l; } };
const baseLang = (l) => String(l || "").split("-")[0].toLowerCase();

function fmtTime(s) {
  s = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(sec).padStart(2, "0");
}
function videoLink(e) {
  return e.videoId ? `https://www.youtube.com/watch?v=${encodeURIComponent(e.videoId)}&t=${Math.max(0, (e.time || 0) - 2)}s` : "";
}
function sentenceNode(e) {
  const p = el("span");
  const text = e.sentence || "";
  const i = text.toLowerCase().indexOf((e.word || "").toLowerCase());
  if (!e.word || i < 0) { p.textContent = text; return p; }
  p.append(text.slice(0, i), el("mark", null, text.slice(i, i + e.word.length)), text.slice(i + e.word.length));
  return p;
}
const save = () => DS_EXT.storage.local.set({ vocab });

// "Segna come imparata" la aggiunge anche alle parole che conosci (percentuale e colore)
function markKnown(e, on) {
  const lang = baseLang(e.lang) || "?";
  DS_EXT.storage.local.get({ knownWords: {} }).then((r) => {
    const kw = { ...(r.knownWords || {}) };
    const set = new Set(String(kw[lang] || "").split("\n").filter(Boolean));
    const w = String(e.word || "").toLowerCase().trim();
    if (!w) return;
    if (on) set.add(w); else set.delete(w);
    kw[lang] = [...set].join("\n");
    return DS_EXT.storage.local.set({ knownWords: kw });
  }).catch(() => {});
}

function filtered() {
  const q = $("search").value.trim().toLowerCase();
  const f = $("filter").value, lf = $("langFilter").value, so = $("sort").value;
  const list = Object.values(vocab).filter((e) =>
    (f === "all" || (f === "known" ? e.status === "known" : e.status !== "known")) &&
    (!lf || baseLang(e.lang) === lf) &&
    (!q || [e.word, e.lemma, e.meaning, e.sentence, e.sentenceTrans, e.explanation].some((x) => (x || "").toLowerCase().includes(q))));
  if (so === "az") list.sort((a, b) => String(a.word).localeCompare(String(b.word)));
  else if (so === "old") list.sort((a, b) => (a.added || 0) - (b.added || 0));
  else list.sort((a, b) => (b.added || 0) - (a.added || 0));
  return list;
}

// ---------- Ascolto: registrazione vera (Wiktionary) se c'è, sennò voce sintetica ----------
const recCache = new Map();
async function recordingFor(e) {
  const k = baseLang(e.lang) + "|" + String(e.word).toLowerCase();
  if (recCache.has(k)) return recCache.get(k);
  let rec = null;
  try {
    const w = await DS_ETYM.get(e.word, e.lang, target, e.lemma);
    rec = DS_LEARN.recordingOf({ wikt: w }, e.word, {});
    if (!rec) { const o = await DS_ETYM.audioOther(e.word, e.lang, target); if (o.audio && o.audio.length) rec = o.audio; }
  } catch {}
  recCache.set(k, rec);
  return rec;
}
async function speak(text, lang, rate) {
  try { const r = await DS_TTS.speak(text, lang, { rate }); await r.done; } catch {}
}

function render() {
  const all = Object.values(vocab);
  const learning = all.filter((e) => e.status !== "known").length;
  $("count").textContent = all.length
    ? `${all.length} ${all.length === 1 ? "voce salvata" : "voci salvate"}, ${learning} da imparare, ${all.filter((e) => e.anki).length} già in Anki.` : "";
  // lingue presenti
  const lf = $("langFilter"), cur = lf.value;
  const langs = [...new Set(all.map((e) => baseLang(e.lang)).filter(Boolean))].sort();
  lf.textContent = "";
  lf.append(new Option("Tutte le lingue", ""));
  for (const l of langs) lf.append(new Option(langName(l) + " (" + all.filter((e) => baseLang(e.lang) === l).length + ")", l));
  lf.value = langs.includes(cur) ? cur : "";

  const shown = filtered();
  const list = $("list");
  list.textContent = "";
  if (!all.length) {
    list.append(el("p", "empty", PAV
      ? "Ancora niente. Passa il mouse su una parola di una pagina (o seleziona un pezzo di testo) e premi la stella ☆ per salvarla qui."
      : "Ancora nessuna parola. Mentre guardi un video, passa il mouse su una parola nei sottotitoli e premi la stella ☆ per salvarla qui."));
    return;
  }
  if (!shown.length) { list.append(el("p", "empty", "Niente corrisponde a questa ricerca.")); return; }
  for (const e of shown) list.append(entryNode(e));
}

function entryNode(e) {
  const row = el("article", "entry" + (e.status === "known" ? " known" : "") + (e.kind === "text" ? " text" : ""));
  if (show("image") && e.image) { const im = el("img", "pic"); im.src = e.image; im.alt = ""; im.loading = "lazy"; row.append(im); }
  const top = el("div", "top");
  top.append(el("span", "word", e.word));
  if (show("audio") && e.kind !== "text") {
    const tts = el("button", "icon", "🔈"); tts.title = "Ascolta (voce sintetica)";
    tts.addEventListener("click", () => speak(e.word, e.lang));
    const rec = el("button", "icon", "🔊"); rec.title = "Registrazione di una persona (Wiktionary): la cerco quando la premi";
    rec.addEventListener("click", async () => {
      rec.textContent = "…";
      const r = await recordingFor(e);
      if (r) { const ok = await DS_LEARN.playUrl(r, null); rec.textContent = ok ? "🔊" : "✕"; if (!ok) rec.title = "Registrazione non riproducibile"; }
      else { rec.textContent = "—"; rec.title = "Su Wiktionary non c'è una registrazione di questa parola"; rec.disabled = true; }
    });
    top.append(tts, rec);
  } else if (show("audio")) {
    const tts = el("button", "icon", "🔈"); tts.title = "Leggi il testo (voce sintetica)";
    tts.addEventListener("click", () => speak(String(e.word).slice(0, 1500), e.lang));
    top.append(tts);
  }
  if (e.lemma && e.lemma.toLowerCase() !== String(e.word).toLowerCase()) top.append(el("span", "lemma", "→ " + e.lemma));
  if (e.pos) top.append(el("span", "pos", e.pos));
  if (show("ipa") && e.ipa) top.append(el("span", "ipa", "/" + e.ipa + "/"));
  if (show("translit") && e.translit) top.append(el("span", "tr", e.translit));
  if (show("gender") && e.gender) top.append(el("span", "badge", e.gender));
  if (show("freq") && e.freq) top.append(el("span", "badge", typeof DS_FREQ !== "undefined" ? DS_FREQ.label(e.freq) : "n. " + e.freq));
  if (e.lang) top.append(el("span", "lang", langName(e.lang)));
  row.append(top);
  if (show("meaning") && e.meaning) row.append(el("div", "meaning", e.meaning));
  if (show("expl") && e.explanation) row.append(el("div", "expl", e.explanation));
  if (show("expl")) for (const x of e.expls || []) row.append(el("div", "expl", x));
  if (show("expl") && e.idioms && e.idioms.length) row.append(el("div", "etym", "Modi di dire: " + e.idioms.map((x) => "«" + x.text + "»" + (x.meaning ? " = " + x.meaning : "")).join("; ")));
  if (show("etym") && e.etym) row.append(el("div", "etym", "Etimologia: " + e.etym));
  if (show("sentence") && e.sentence && e.kind !== "text") {
    const s = el("div", "sentence");
    if (show("audio")) {
      const b = el("button", "icon", "🔈"); b.title = "Ascolta la frase (voce sintetica)";
      b.addEventListener("click", () => speak(e.sentence, e.lang));
      const sl = el("button", "icon", "🐢"); sl.title = "Ascolta la frase lentamente";
      sl.addEventListener("click", () => speak(e.sentence, e.lang, 0.6));
      s.append(b, sl);
    }
    s.append(sentenceNode(e));
    row.append(s);
  }
  if (show("sentTrans") && e.sentenceTrans) row.append(el("div", "trans", e.sentenceTrans));
  if (show("examples") && e.kind !== "text") {
    const exBox = el("div", "ex");
    const b = el("button", "ghost", "Esempi veri (Tatoeba)");
    b.addEventListener("click", async () => {
      b.textContent = "…";
      let r;
      try { r = await DS_EXT.runtime.sendMessage({ type: "tatoeba", word: e.word, lang: e.lang, target }); } catch (err) { r = { error: String(err.message || err) }; }
      exBox.textContent = "";
      if (!r || r.error || !r.items || !r.items.length) { exBox.append(el("div", "note", r && r.error ? "Tatoeba non risponde" : "Nessun esempio su Tatoeba")); return; }
      for (const it of r.items) {
        const d = el("div");
        const p = el("button", "icon", it.audio ? "🔊" : "🔈");
        p.addEventListener("click", () => it.audio ? DS_LEARN.playUrl([it.audio, ...(it.audioAlt || [])], null) : speak(it.text, e.lang));
        d.append(p, document.createTextNode(" " + it.text));
        exBox.append(d);
        if (it.trans) exBox.append(el("div", "t", it.trans));
      }
    });
    exBox.append(b);
    row.append(exBox);
  }

  const actions = el("div", "actions");
  if (show("source")) {
    const link = videoLink(e);
    if (link) {
      const a = el("a", null, `Riguarda nel video (${fmtTime(e.time)})${e.title ? " · " + e.title : ""}`);
      a.href = link; a.target = "_blank"; a.rel = "noopener";
      actions.append(a);
    } else if (e.url) {
      const a = el("a", null, "Pagina: " + (e.title || e.url).slice(0, 70));
      a.href = e.url; a.target = "_blank"; a.rel = "noopener";
      actions.append(a);
    }
  }
  if (e.anki) actions.append(el("span", "badge", "in Anki"));
  const known = el("button", "ghost", e.status === "known" ? "Rimetti da imparare" : "Segna come imparata");
  known.addEventListener("click", () => {
    vocab[e.id].status = e.status === "known" ? "learning" : "known";
    save();
    if (e.kind !== "text") markKnown(e, vocab[e.id].status === "known");
  });
  const anki = el("button", "ghost", e.anki ? "Rimanda ad Anki" : "Manda ad Anki");
  anki.addEventListener("click", () => sendAnki([e], anki, true));
  const edit = el("button", "ghost", "✎ Modifica");
  edit.addEventListener("click", () => {
    if (row.querySelector(".edit")) { row.querySelector(".edit").remove(); return; }
    const f = el("div", "edit");
    const m = el("textarea"); m.rows = 2; m.value = e.meaning || ""; m.setAttribute("aria-label", "Significato");
    const t = el("textarea"); t.rows = 2; t.value = e.sentenceTrans || ""; t.setAttribute("aria-label", "Traduzione della frase");
    const ok = el("button", null, "Salva");
    ok.addEventListener("click", () => { vocab[e.id].meaning = m.value.trim(); vocab[e.id].sentenceTrans = t.value.trim(); save(); });
    f.append(el("span", "note", "Significato"), m, el("span", "note", "Traduzione della frase"), t, ok);
    row.append(f);
  });
  // immagine per la carta di Anki: cambiala (Wikipedia, Commons, Openverse, un indirizzo tuo) o toglila
  if (e.kind !== "text" && typeof DS_LEARN !== "undefined" && DS_LEARN.imagePicker) {
    const pic = el("button", "ghost", pickers.has(e.id) ? "🖼 chiudi" : e.image ? "🖼 Cambia immagine" : "🖼 Immagine");
    pic.title = "Scegli l'immagine per la carta di Anki";
    pic.addEventListener("click", () => {
      if (pickers.has(e.id)) pickers.delete(e.id);
      else pickers.set(e.id, { list: e.image ? [{ url: e.image, thumb: e.image, source: "salvata" }] : [], i: 0, open: true, none: e.image === "" });
      render();
    });
    actions.append(pic);
    const im = pickers.get(e.id);
    if (im) {
      const redraw = () => { if (pickers.get(e.id) === im) render(); };
      const box = DS_LEARN.imagePicker(im, { word: e.lemma || e.word, lang: e.lang, rerender: redraw, autoload: true, onPick: (url) => {
        if (!vocab[e.id]) return;
        vocab[e.id].image = url;
        save();
      } });
      row.append(box);
      if (e.anki) row.append(el("span", "note", "Questa parola è già in Anki: la nuova immagine vale per «Rimanda ad Anki» e per il file esportato (in Anki la carta di prima resta com'è)."));
    }
  }
  // 📈 uso nel tempo (Google Books Ngram) della parola o del modo di dire
  if (e.kind !== "text" && typeof DS_LEARN !== "undefined" && DS_LEARN.ngramWidget && /^(en|fr|de|it|es|ru|he|iw|zh)/.test(String(e.lang || ""))) {
    const ng = el("button", "ghost", ngOpen.has(e.id) ? "📈 chiudi" : "📈 Uso nel tempo");
    ng.title = "Quanto compare nei libri dal 1800 a oggi (Google Books Ngram): passa il mouse sul grafico per vedere ogni anno";
    ng.addEventListener("click", () => { if (ngOpen.has(e.id)) ngOpen.delete(e.id); else ngOpen.add(e.id); render(); });
    actions.append(ng);
    if (ngOpen.has(e.id)) row.append(DS_LEARN.ngramWidget(e.lemma && !/\s/.test(e.word) ? e.word : e.word, e.lang));
  }
  const del = el("button", "ghost danger", "Elimina");
  del.addEventListener("click", () => { delete vocab[e.id]; save(); });
  // ✨ completa i dati che mancano (gratis); con il modello anche una spiegazione nuova e i modi di dire (una richiesta, solo se premi)
  const fillBtns = [];
  if (e.kind !== "text") {
    const fill = el("button", "ghost", "✨ Completa");
    fill.title = "Aggiunge i dati che mancano: IPA, genere, etimologia, significato, traduzione della frase, modi di dire del dizionario. Gratis, senza modello";
    fill.addEventListener("click", () => completeOne(e, fill, false));
    const fillL = el("button", "ghost", "✨ + modello");
    fillL.title = "Come «Completa», e in più una richiesta al modello: una spiegazione nuova e diversa da quelle che ci sono già e i modi di dire con la parola";
    fillL.addEventListener("click", () => completeOne(e, fillL, true));
    fillBtns.push(fill, fillL);
  }
  actions.append(known, anki, edit, ...fillBtns, del);
  row.append(actions);
  return row;
}

// ---------- Anki ----------
// update: la carta che c'è già in Anki si aggiorna («Rimanda ad Anki»); senza, quelle già presenti restano come sono
async function sendAnki(entries, btn, update) {
  const msg = $("ankiMsg");
  msg.className = "";
  msg.textContent = `Mando ${entries.length} ${entries.length === 1 ? "carta" : "carte"} ad Anki… (se Anki chiede il permesso, premi Yes)`;
  if (btn) btn.disabled = true;
  // 1.6.2: la registrazione di un madrelingua per ogni carta (se non c'è, Anki riceve la voce sintetica)
  const { ankiAudio } = await DS_EXT.storage.sync.get({ ankiAudio: true });
  if (ankiAudio !== false && typeof DS_LEARN !== "undefined") {
    msg.textContent = `Cerco le registrazioni della pronuncia (${entries.length} ${entries.length === 1 ? "parola" : "parole"})…`;
    const out = entries.slice();
    for (let i = 0; i < out.length; i += 4) {
      await Promise.all(out.slice(i, i + 4).map(async (e, j) => {
        if (e.rec) return;
        out[i + j] = { ...e, rec: await DS_LEARN.ankiRec({ word: e.word, lang: e.lang, target, lemma: e.lemma, kind: e.kind }) };
      }));
    }
    entries = out;
    msg.textContent = `Mando ${entries.length} ${entries.length === 1 ? "carta" : "carte"} ad Anki… (se Anki chiede il permesso, premi Yes)`;
  }
  let r;
  try {
    r = await DS_EXT.runtime.sendMessage(PAV ? { type: "pavAnki", entries, update: !!update } : { type: "ankiAdd", entries, update: !!update });
  } catch (e) { r = { error: String(e.message || e) }; }
  if (btn) btn.disabled = false;
  if (!r || r.error) { msg.className = "err"; msg.textContent = "Anki: " + ((r && r.error) || "nessuna risposta"); return; }
  const l = await DS_EXT.storage.local.get({ vocab: {} });
  entries.forEach((e, i) => { if (r.ids[i] != null && l.vocab[e.id]) l.vocab[e.id].anki = 1; });
  await DS_EXT.storage.local.set({ vocab: l.vocab });
  const added = r.ids.filter((x) => x != null && x !== "dup").length - (r.upd || 0);
  const parts = [added > 0 ? `${added} ${added === 1 ? "carta aggiunta" : "carte aggiunte"}` : "", r.upd ? `${r.upd} ${r.upd === 1 ? "aggiornata" : "aggiornate"}` : "", r.dup ? `${r.dup} c'erano già (per aggiornarle: «Rimanda ad Anki» o 🔄 qui sotto)` : ""].filter(Boolean);
  msg.textContent = `Fatto${r.deck ? " (" + r.deck + ")" : ""}: ${parts.join(", ") || "niente da fare"}` + dsAnkiAudioNote(r) + (r.imgNote ? " — " + r.imgNote : "") + ".";
  if (r.errors && r.errors.length) { msg.className = "err"; msg.textContent += ` Non riuscite: ${r.errors.slice(0, 5).map((x) => x.word + " (" + x.error + ")").join("; ")}${r.errors.length > 5 ? "…" : ""}.`; }
}
$("send").addEventListener("click", () => {
  const entries = filtered().filter((e) => !e.anki);
  if (!entries.length) { $("ankiMsg").textContent = "Tutte le voci mostrate sono già in Anki."; return; }
  sendAnki(entries, $("send"));
});

// file per Anki (tabulazioni), con il mazzo di ogni carta
$("export").addEventListener("click", async () => {
  const entries = filtered();
  if (!entries.length) { alert("Non c'è niente da esportare con questo filtro."); return; }
  const s = await DS_EXT.storage.sync.get({ ankiDeck: PAV ? PAV_DEFAULTS.ankiDeck : "Sottotitoli Doppi", ankiPerLang: true, ankiLangDeck: "Lingue::{lingua}" });
  const opts = { deck: s.ankiDeck, perLang: s.ankiPerLang !== false, tpl: s.ankiLangDeck };
  let text;
  if (PAV) text = pavAnkiFile(entries, opts);
  else {
    const lines = ["#separator:tab", "#html:true", "#tags column:3", "#deck column:4"];
    for (const e of entries) {
      const f = dsAnkiFields(e, { img: e.image && /^https:\/\//.test(e.image) ? e.image : "" });   // 1.6.3: l'immagine nel suo posto, come sulle carte inviate
      lines.push([f.front, f.back, f.tags.join(" "), dsAnkiDeckFor(e.lang, opts)].join("\t"));
    }
    text = lines.join("\n") + "\n";
  }
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${PAV ? "parole-al-volo" : "vocabolario"}-anki-${new Date().toISOString().slice(0, 10)}.txt`;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
});

// ascolta l'elenco: parola (registrazione se c'è) e poi il significato con la voce della tua lingua
let playing = false;
$("playAll").addEventListener("click", async () => {
  if (playing) { playing = false; $("playAll").textContent = "▶ Ascolta l'elenco"; return; }
  playing = true; $("playAll").textContent = "■ Ferma";
  for (const e of filtered().filter((x) => x.kind !== "text")) {
    if (!playing) break;
    await speak(e.word, e.lang);
    await new Promise((r) => setTimeout(r, 500));
    if (!playing) break;
    if (e.meaning) await speak(e.meaning, target);
    await new Promise((r) => setTimeout(r, 900));
  }
  playing = false; $("playAll").textContent = "▶ Ascolta l'elenco";
});

// ---------- Cosa mostrare (resta salvato) ----------
function renderOpts() {
  const box = $("opts");
  box.textContent = "";
  for (const [k, label] of VIEW) {
    const l = el("label");
    const c = el("input"); c.type = "checkbox"; c.checked = show(k);
    c.addEventListener("change", () => { view[k] = c.checked; DS_EXT.storage.local.set({ vocabView: view }).catch(() => {}); render(); });
    l.append(c, document.createTextNode(label));
    box.append(l);
  }
}

$("search").addEventListener("input", render);
$("filter").addEventListener("change", render);
$("langFilter").addEventListener("change", render);
$("sort").addEventListener("change", render);
DS_EXT.storage.onChanged.addListener((ch, area) => {
  if (area === "local" && ch.vocab) { vocab = ch.vocab.newValue || {}; render(); }
});
(async () => {
  const l = await DS_EXT.storage.local.get({ vocab: {}, vocabView: {} });
  const s = await DS_EXT.storage.sync.get({ targetLang: "it" });
  vocab = l.vocab || {}; view = l.vocabView || {}; target = s.targetLang || "it";
  if (PAV) document.title = "Parole al Volo — vocabolario";
  renderOpts();
  render();
})();

// ---------- Scambio con l'altra estensione (Sottotitoli Doppi ↔ Parole al Volo) ----------
$("swapExp").addEventListener("click", async () => {
  const msg = $("ankiMsg"); msg.className = "";
  try { const r = await dsExportData({ vocab: true, known: true }); msg.textContent = `Salvato «${r.name}»: ${r.vocab} voci e ${r.known} parole che conosci. Nell'altra estensione: Il mio vocabolario → ⇄ Importa…`; }
  catch (e) { msg.className = "err"; msg.textContent = "Non riesco: " + (e.message || e); }
});
$("swapImp").addEventListener("click", () => $("swapFile").click());
$("swapFile").addEventListener("change", async () => {
  const f = $("swapFile").files[0];
  $("swapFile").value = "";
  if (!f) return;
  const msg = $("ankiMsg"); msg.className = "";
  try { msg.textContent = dsImportReport(await dsImportData(await f.text(), "")); }
  catch (e) { msg.className = "err"; msg.textContent = "Non riesco a importare: " + (e.message || e); }
});
$("freqPage").addEventListener("click", async () => {
  // la lingua con più parole nel vocabolario
  const n = {};
  for (const e of Object.values(vocab)) { const l = String(e.lang || "").split("-")[0]; if (l) n[l] = (n[l] || 0) + 1; }
  const lang = $("langFilter").value || Object.keys(n).sort((a, b) => n[b] - n[a])[0] || "en";
  DS_EXT.tabs.create({ url: DS_EXT.runtime.getURL("freq.html") + "?lang=" + encodeURIComponent(lang) + "&target=" + encodeURIComponent(target) });
});

$("swapSync").textContent = "⇄ Sincronizza con le altre estensioni";
$("swapSync").title = "Passa vocabolario e parole conosciute da qui a " + dsSiblingNames().join(", ") + " (quelle installate) e viceversa: si uniscono, non si cancella niente. Passano anche le chiavi dei servizi e le impostazioni non ancora scelte";
$("swapSync").addEventListener("click", async () => {
  const msg = $("ankiMsg"); msg.className = "";
  msg.textContent = "Sincronizzo con le altre estensioni…";
  try { msg.textContent = dsSyncReport(await dsSyncWithSibling({ known: true, vocab: true })); }
  catch (e) { msg.className = "err"; msg.textContent = "Non riesco: " + (e.message || e); }
});

// ---------- 1.6.3: completare i dati di una voce, e aggiornare le carte già in Anki ----------
// Gratis: Wiktionary (IPA, genere, etimologia, forma base), Google (significato, traduzione della frase) e il dizionario dei
// modi di dire. Con il modello (solo se lo chiedi): una spiegazione nuova e diversa dalle altre, i modi di dire con la parola.
const pacificDay = () => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return ""; } };
// il modello per le spiegazioni, saltando quelli finiti oggi: { id, key, model, localUrl, name } oppure null
async function pickLlm() {
  const C = DS_CONFIG;
  const [sy, lo] = await Promise.all([DS_EXT.storage.sync.get(C.SYNC_DEFAULTS), DS_EXT.storage.local.get({ keys: {}, dsBlocked: {} })]);
  const map = lo.dsBlocked || {}, day = pacificDay();
  const on = (k) => !!(map[k] && map[k].day === day && (!map[k].ttl || Date.now() - map[k].at < map[k].ttl));
  const blocked = (id, m) => on(id) || (!!m && on(id + "|" + m));
  const mk = (id) => { const E = C.ENGINES[id]; return E ? { id, E, key: (lo.keys || {})[id] || "", model: (sy.models || {})[id] || E.defaultModel || "", localUrl: sy.localUrl } : null; };
  const ok = (e) => e && (e.E.kind === "openai" || e.E.kind === "claude") && !(e.E.needsKey && !e.key) && !(e.E.kind === "openai" && !e.model);
  const order = [sy.explainEngine, ...C.engineOrder(sy)].filter(Boolean);
  for (const id of order) {
    const e = mk(id);
    if (!ok(e)) continue;
    const t = dsTaskModel(sy, "explainEngine", e, blocked);
    if (t && !t.exhausted) return { id: t.id, key: t.key, model: t.model, localUrl: t.localUrl, name: t.E.label.split(" (")[0].split(",")[0] + (t.E.local ? "" : " · " + t.model) };
  }
  return null;
}
// completa e (se richiesto) arricchisce la voce e; → elenco di cosa è cambiato
async function completeEntry(e, o = {}) {
  const changed = [];
  const set = (k, v, label) => { if (v && !(Array.isArray(e[k]) ? e[k].length : e[k])) { e[k] = v; changed.push(label || k); return true; } return false; };
  const lang = e.lang;
  if (e.kind === "text" || !e.word) return changed;
  if (o.fill !== false) {
    if ((!e.ipa || !e.gender || !e.etym || !e.lemma) && typeof DS_ETYM !== "undefined") {
      const w = await DS_ETYM.get(e.word, lang, target, e.lemma).catch(() => null);
      if (w && !w.error) {
        if (!e.ipa && w.ipa && String(w.ipaTitle || "").toLowerCase() === e.word.toLowerCase()) set("ipa", String(w.ipa).replace(/^[\s\/\[]+|[\s\/\]]+$/g, ""), "IPA");
        if (!e.gender && w.gender && typeof DS_LEARN !== "undefined") { const g = DS_LEARN.genderInfo(w.gender, lang); if (g) set("gender", g.text, "genere"); }
        if (w.trans) set("etym", String(w.trans).slice(0, 600), "etimologia");
        if (w.lemma) set("lemma", w.lemma, "forma base");
      }
      if (!e.ipa) { const r = await DS_ETYM.ipa(e.word, lang, target).catch(() => null); if (r && r.ipa) set("ipa", String(r.ipa).replace(/^[\s\/\[]+|[\s\/\]]+$/g, ""), "IPA"); }
    }
    if (!e.meaning || !e.pos) {
      const g = await DS_EXT.runtime.sendMessage({ type: "define", engine: "google", target, word: e.word, sentence: e.sentence || "", lang }).catch(() => null);
      if (g && !g.error) { set("meaning", g.meaning, "significato"); set("pos", g.pos, "tipo di parola"); set("translit", g.translit, "trascrizione"); }
    }
    if (e.sentence && !e.sentenceTrans) {
      const t = await DS_EXT.runtime.sendMessage({ type: "translate", engine: "google", target, source: baseLang(lang), texts: [e.sentence] }).catch(() => null);
      if (t && t.translations && t.translations[0]) set("sentenceTrans", t.translations[0], "traduzione della frase");
    }
    if (!(e.idioms && e.idioms.length)) {
      const d = await DS_EXT.runtime.sendMessage({ type: "idiomsAbout", sentence: e.sentence || "", lang: baseLang(lang), word: e.word }).catch(() => null);
      const here = ((d && d.dict) || []).filter((t) => e.sentence && String(e.sentence).toLowerCase().includes(t.toLowerCase())).slice(0, 3).map((t) => ({ text: t, meaning: "" }));
      if (here.length) set("idioms", here, "modi di dire");
    }
  }
  if (o.llm && (o.expl || o.idioms)) {
    const llm = o.llm;
    if (o.expl) {
      const old = [e.explanation, ...(e.expls || [])].filter(Boolean);
      const r = await DS_EXT.runtime.sendMessage({ type: "define", engine: llm.id, key: llm.key, model: llm.model, localUrl: llm.localUrl, target, word: e.word, sentence: e.sentence || e.word,
        sentenceTrans: e.sentenceTrans || "", lang, etym: false, ipa: false, extra: false, avoid: old }).catch((x) => ({ error: String(x.message || x) }));
      if (r && !r.error && !r.fallback && r.explanation) {
        const same = old.some((x) => x.trim().toLowerCase() === r.explanation.trim().toLowerCase());
        if (!same) { if (!e.explanation) e.explanation = r.explanation; else e.expls = [...(e.expls || []), r.explanation]; changed.push("spiegazione nuova"); }
        if (!e.meaning && r.meaning) { e.meaning = r.meaning; changed.push("significato"); }
        if (!e.lemma && r.lemma) { e.lemma = r.lemma; changed.push("forma base"); }
        if (!e.pos && r.pos) { e.pos = r.pos; changed.push("tipo di parola"); }
      } else if (r && (r.error || r.fallback)) { e._llmError = String(r.error || r.source || "").slice(0, 120); if (r.daily || r.llmDaily) e._llmDaily = true; }
    }
    if (o.idioms && !e._llmDaily) {
      const r = await DS_EXT.runtime.sendMessage({ type: "idiomsAbout", engine: llm.id, key: llm.key, model: llm.model, localUrl: llm.localUrl, sentence: e.sentence || "", lang: baseLang(lang), target, word: e.word }).catch((x) => ({ error: String(x.message || x) }));
      if (r && !r.error && r.idioms && r.idioms.length) {
        const have = new Set((e.idioms || []).map((x) => x.text.toLowerCase()));
        const add = r.idioms.filter((x) => !have.has(x.text.toLowerCase())).slice(0, 4).map((x) => ({ text: x.text, meaning: x.meaning || "" }));
        // quelli già senza significato (dal dizionario) lo ricevono
        for (const x of e.idioms || []) if (!x.meaning) { const m = r.idioms.find((y) => y.text.toLowerCase() === x.text.toLowerCase()); if (m && m.meaning) x.meaning = m.meaning; }
        if (add.length) { e.idioms = [...(e.idioms || []), ...add].slice(0, 5); changed.push("modi di dire"); }
      } else if (r && r.error) { e._llmError = String(r.error).slice(0, 120); if (r.daily) e._llmDaily = true; }
    }
  }
  return changed;
}

// ✨ Completa i dati di una voce (gratis); con ✨ + modello anche una spiegazione nuova
async function completeOne(e, btn, withLlm) {
  const msg = $("ankiMsg"); msg.className = "";
  if (btn) { btn.disabled = true; btn.textContent = "…"; }
  const copy = { ...vocab[e.id] };
  let llm = null;
  if (withLlm) { llm = await pickLlm(); if (!llm) { msg.className = "err"; msg.textContent = "Per la spiegazione serve un modello con la chiave (popup → 🔑 Servizi)."; if (btn) { btn.disabled = false; btn.textContent = "✨ + modello"; } return; } }
  const changed = await completeEntry(copy, { fill: true, llm, expl: !!withLlm, idioms: !!withLlm });
  delete copy._llmError; delete copy._llmDaily;
  if (changed.length && vocab[e.id]) { vocab[e.id] = copy; await save(); }
  msg.textContent = changed.length ? `«${e.word}»: aggiunto ${changed.join(", ")}.` + (e.anki ? " Per aggiornare la carta in Anki: «Rimanda ad Anki»." : "") : `«${e.word}»: non manca niente che si possa trovare gratis.`;
  if (btn) { btn.disabled = false; btn.textContent = withLlm ? "✨ + modello" : "✨ Completa"; }
}

const updState = { running: false, stop: false };
function updLog(text, cls) { const d = el("div", cls || "", text); const box = $("updLog"); box.append(d); box.scrollTop = box.scrollHeight; return d; }
function updOpts() {
  return { rebuild: $("updRebuild").checked, audio: $("updAudio").checked, force: $("updAudioForce").checked, fill: $("updFill").checked, expl: $("updExpl").checked,
    idioms: $("updIdioms").checked, image: $("updImage").checked, scope: $("updScope").value };
}
const noteHasSound = (n) => /\[sound:/.test(n.front);
async function updPlan(o) {
  const r = await DS_EXT.runtime.sendMessage({ type: "ankiList" }).catch((e) => ({ error: String(e.message || e) }));
  if (!r || r.error) throw new Error((r && r.error) || "Anki non risponde");
  const byKey = new Map(Object.values(vocab).map((e) => [baseLang(e.lang) + "|" + String(e.word || "").toLowerCase().trim(), e]));
  let plan = r.notes.map((n) => { const p = dsAnkiParse(n.front, n.back, n.tags); return { n, p, v: byKey.get(baseLang(p.lang) + "|" + p.word.toLowerCase().trim()) || null }; });
  if (o.scope === "lang") { const l = $("langFilter").value; if (l) plan = plan.filter((x) => baseLang(x.p.lang) === l); }
  else if (o.scope === "nosound") plan = plan.filter((x) => !noteHasSound(x.n));
  return plan;
}
async function updCheck() {
  const o = updOpts(), box = $("updLog"); box.textContent = "";
  try {
    updLog("Leggo le carte da Anki…");
    const plan = await updPlan(o);
    const cnt = (f) => plan.filter(f).length;
    box.textContent = "";
    updLog(`${plan.length} carte (${cnt((x) => x.v)} anche nel vocabolario). Senza pronuncia: ${cnt((x) => !noteHasSound(x.n))}. Senza IPA: ${cnt((x) => !(x.v ? x.v.ipa : x.p.ipa))}. Senza etimologia: ${cnt((x) => !(x.v ? x.v.etym : x.p.etym))}. Senza significato: ${cnt((x) => !(x.v ? x.v.meaning : x.p.meaning))}. Senza traduzione della frase: ${cnt((x) => (x.v ? x.v.sentence && !x.v.sentenceTrans : x.p.sentence && !x.p.sentenceTrans))}.`);
    const ex = plan.slice(0, 1)[0];
    if (ex) { const f = dsAnkiFields({ ...(ex.v || {}), ...Object.fromEntries(Object.entries(ex.p).filter(([, v]) => v && (!Array.isArray(v) || v.length))) }, { keep: ex.p.keep }); updLog("Esempio (la prima carta), come diventerebbe:"); const d = el("div", "note"); d.innerHTML = ""; d.append(el("pre", "", f.front.replace(/<br>/g, "\n").replace(/<[^>]+>/g, "") + "\n———\n" + f.back.replace(/<br>/g, "\n").replace(/<[^>]+>/g, ""))); $("updLog").append(d); }
  } catch (e) { box.textContent = ""; updLog("Anki: " + (e.message || e), "err"); }
}
async function updRun() {
  if (updState.running) return;
  const o = updOpts();
  const box = $("updLog"); box.textContent = "";
  updState.running = true; updState.stop = false;
  $("updGo").disabled = true; $("updCheck").disabled = true; $("updStop").hidden = false;
  const bar = $("updBar"); bar.hidden = false; bar.value = 0;
  try {
    updLog("Leggo le carte da Anki…");
    const plan = await updPlan(o);
    if (!plan.length) { updLog("Nessuna carta da aggiornare."); return; }
    let llm = null;
    if (o.expl || o.idioms) { llm = await pickLlm(); if (!llm) updLog("Senza un modello con la chiave (popup → 🔑 Servizi) salto la spiegazione nuova e i modi di dire del modello.", "err"); else updLog(`Il modello per la spiegazione e i modi di dire: ${llm.name}.`); }
    const { ankiImage } = await DS_EXT.storage.sync.get({ ankiImage: false });
    const undo = [], done = { ok: 0, skip: 0, err: 0, rec: 0, tts: 0, filled: 0, expl: 0 }, vocabNew = {};
    bar.max = plan.length;
    for (let i = 0; i < plan.length; i++) {
      if (updState.stop) { updLog("Fermato.", "note"); break; }
      const { n, p, v } = plan[i];
      bar.value = i;
      // dati: quelli del vocabolario, completati con quelli letti dalla carta
      const e = { ...p, ...(v || {}) };
      for (const [k, val] of Object.entries(p)) if ((e[k] == null || e[k] === "" || (Array.isArray(e[k]) && !e[k].length)) && val && (!Array.isArray(val) || val.length)) e[k] = val;
      e.lang = e.lang || p.lang; e.linkHtml = v ? "" : p.linkHtml;
      let changed = [];
      try {
        changed = await completeEntry(e, { fill: o.fill, llm, expl: o.expl && !!llm, idioms: o.idioms && !!llm });
        const wantAudio = o.audio && (o.force || !noteHasSound(n));
        const wantImage = o.image && ankiImage && !e.image && !(n.front.match(/<img/i));
        if (wantImage && typeof DS_LEARN !== "undefined") { try { const im = await DS_LEARN.image(e.lemma || e.word, e.lang); if (im) { e.image = im; changed.push("immagine"); } } catch {} }
        if (!o.rebuild && !changed.length && !wantAudio) { done.skip++; continue; }
        if (wantAudio && typeof DS_LEARN !== "undefined") e.rec = await DS_LEARN.ankiRec({ word: e.word, lang: e.lang, target, lemma: e.lemma, kind: e.kind });
        undo.push({ id: n.id, names: n.names, front: n.front, back: n.back, model: n.model, tags: n.tags });
        const res = await DS_EXT.runtime.sendMessage({ type: "ankiUpdate", id: n.id, names: n.names, model: n.model, entry: e, keep: p.keep, audio: wantAudio, image: wantImage && !!e.image, tag: n.tags.includes("parole-al-volo") ? "parole-al-volo" : "sottotitoli-doppi" });
        if (!res || res.error) throw new Error((res && res.error) || "nessuna risposta");
        done.ok++; if (res.how === "rec") done.rec++; else if (res.how === "tts") done.tts++;
        if (changed.length) done.filled++;
        if (changed.includes("spiegazione nuova")) done.expl++;
        if (v) { const keepE = { ...e }; delete keepE.rec; delete keepE.keep; delete keepE.linkHtml; delete keepE._llmError; delete keepE._llmDaily; vocabNew[v.id] = { ...keepE, anki: 1 }; }
        updLog(`✓ ${e.word}` + (res.how ? (res.how === "rec" ? " · 🔊 madrelingua" : " · 🔈 voce sintetica") : "") + (changed.length ? " · " + changed.join(", ") : ""));
        if (e._llmDaily) { llm = null; updLog("Il modello ha finito le richieste di oggi: continuo senza.", "err"); }
      } catch (err) {
        done.err++; updLog(`✕ ${e.word}: ${String(err.message || err).slice(0, 140)}`, "err");
        if (/Anki non risponde|Failed to fetch/i.test(String(err.message || err))) break;
      }
      if (undo.length && undo.length % 15 === 0) await DS_EXT.storage.local.set({ ankiUndo: { at: Date.now(), items: undo } }).catch(() => {});
      if (Object.keys(vocabNew).length && Object.keys(vocabNew).length % 20 === 0) { const cur = (await DS_EXT.storage.local.get({ vocab: {} })).vocab || {}; for (const [k, x] of Object.entries(vocabNew)) if (cur[k]) cur[k] = { ...cur[k], ...x }; await DS_EXT.storage.local.set({ vocab: cur }).catch(() => {}); }
    }
    bar.value = bar.max;
    await DS_EXT.storage.local.set({ ankiUndo: { at: Date.now(), items: undo } }).catch(() => {});
    if (Object.keys(vocabNew).length) { const cur = (await DS_EXT.storage.local.get({ vocab: {} })).vocab || {}; for (const [k, x] of Object.entries(vocabNew)) if (cur[k]) cur[k] = { ...cur[k], ...x }; await DS_EXT.storage.local.set({ vocab: cur }).catch(() => {}); }
    updLog(`Finito: ${done.ok} carte aggiornate (${done.rec} con la registrazione di un madrelingua, ${done.tts} con la voce sintetica, ${done.filled} con dati nuovi${done.expl ? ", " + done.expl + " con una spiegazione nuova" : ""}), ${done.skip} già a posto, ${done.err} non riuscite.`, done.err ? "err" : "");
  } catch (e) { updLog("Anki: " + (e.message || e), "err"); }
  finally { updState.running = false; $("updGo").disabled = false; $("updCheck").disabled = false; $("updStop").hidden = true; updUndoShow(); }
}
async function updUndoShow() {
  const u = (await DS_EXT.storage.local.get({ ankiUndo: null })).ankiUndo;
  $("updUndo").hidden = !(u && u.items && u.items.length);
}
$("updCheck").addEventListener("click", updCheck);
$("updGo").addEventListener("click", updRun);
$("updStop").addEventListener("click", () => { updState.stop = true; });
$("updUndo").addEventListener("click", async () => {
  const u = (await DS_EXT.storage.local.get({ ankiUndo: null })).ankiUndo;
  if (!u || !u.items || !u.items.length) return;
  if (!confirm(`Rimettere com'erano ${u.items.length} carte cambiate nell'ultimo aggiornamento?`)) return;
  const r = await DS_EXT.runtime.sendMessage({ type: "ankiRestore", items: u.items }).catch((e) => ({ error: String(e.message || e) }));
  $("updLog").textContent = "";
  if (r && !r.error) { await DS_EXT.storage.local.set({ ankiUndo: null }); updLog(`Rimesse come prima ${r.restored} carte.`); } else updLog("Non riesco: " + ((r && r.error) || ""), "err");
  updUndoShow();
});
updUndoShow();
if (/[?&]upd=1/.test(location.search)) { $("ankiUpd").open = true; setTimeout(() => $("ankiUpd").scrollIntoView(), 300); }

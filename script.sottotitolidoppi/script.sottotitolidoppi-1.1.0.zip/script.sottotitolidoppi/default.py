# -*- coding: utf-8 -*-
# Sottotitoli Doppi - menu (aprilo dagli add-on "Programmi" mentre il video è in riproduzione,
# oppure assegnalo a un tasto del telecomando)
import xbmc
import xbmcgui

from resources.lib import runner

player = xbmc.Player()
options = [
    "Crea i sottotitoli doppi per il video in riproduzione",
    "Scegli un file di sottotitoli (.srt, .vtt, .ass)…",
    "Trascrivi l'audio con Whisper (anche se ci sono i sottotitoli)",
    "Impostazioni",
]
choice = xbmcgui.Dialog().select("Sottotitoli Doppi", options)
if choice == 0:
    runner.run(player, interactive=True)
elif choice == 1:
    path = xbmcgui.Dialog().browse(1, "Scegli i sottotitoli nella lingua originale", "files", ".srt|.vtt|.ass|.ssa")
    if path:
        runner.run(player, manual_path=path, interactive=True)
elif choice == 2:
    runner.run(player, force_transcribe=True, interactive=True)
elif choice == 3:
    runner.ADDON.openSettings()

# sottotitoli automatici di YouTube corretti con un modello SUL COMPUTER (Ollama), senza nessuna chiave
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:false, cleanAsr:true, cleanMode:'off', models:{local:'gemma4:e4b'}, localUrl:'http://localhost:11434/v1'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.wait_for_timeout(6000)
        T = "(document.querySelector('.dualsub-orig')||{}).textContent"
        print("testo:", repr(await pg.evaluate(T)))
        print("stato:", await sw.evaluate("chrome.storage.local.get('status').then(r => (r.status||{}).text)"))
        print("chiamate Ollama:", log.get("ollama"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# Sottotitoli Doppi per Kodi — novità delle versioni

## Novità della 1.11
- **Scegli tu quando fare i sottotitoli doppi.** Prima ogni video che partiva veniva tradotto, anche quando non serviva (film italiani, trailer, film già doppiati), sprecando quote. Ora l'impostazione **Generale → Quando parte un video** ha tre scelte: **chiedi** (di serie: una domanda con sì / no / sempre o mai per la serie / non chiedere più; senza risposta in 20 secondi vale "no"), **sempre**, **mai** (solo dal menu).
- **Controlli gratuiti prima di tutto**: video più corti di 15 minuti, TV in diretta, film o audio già nella lingua in cui traduci → nessuna richiesta, nessuna domanda.
- **Le risposte restano ricordate**: per il video (sì = la volta dopo li ricarica da solo, già pronti; no = non chiede più) e per la serie (sempre / mai per tutti gli episodi). Nuova voce del menu **Quando crearli da soli…** per cambiare idea.
- Banco di prova: `test/crea_film_mkv.py` crea il film di prova delle prove 6-9 e 13; nuova prova `test/test_kodi14.py`.

## Novità della 1.10.10
- **Crash di Kodi mentre l'add-on lavora.** Nella 1.10.5 la barra di avanzamento veniva aggiornata molte volte al secondo, anche da più thread insieme (durante la lettura dei sottotitoli dentro il video). Tutti i crash segnalati sono avvenuti con la 1.10.5 mentre l'add-on lavorava, dentro il driver video Intel, di solito quando la finestra cambiava dimensione. Ora la barra si aggiorna al massimo una volta al secondo e solo dal thread che l'ha creata; c'è anche un'impostazione per spegnerla (Generale → Mostra la barra di avanzamento).
- **In automatico mai sottotitoli in un'altra lingua.** Se il film è tedesco e il file parte con il doppiaggio russo, l'add-on non traduce i sottotitoli russi: cerca quelli tedeschi e, se non ce ne sono, lo dice e aspetta la tua scelta.

## Novità della 1.10.9
- **Conta sempre la lingua originale del film.** Con Good Bye Lenin (sottotitoli russi, inglesi e tedeschi dentro il file, sottotitoli russi accesi) l'add-on prendeva quelli russi perché erano accesi nel lettore. Ora sceglie quelli nella lingua in cui il film è stato girato (dal catalogo); nell'elenco della scelta a mano sono per primi, con "(lingua del film)". Lo stesso per OpenSubtitles.
- **Trascrizione: l'audio originale, non il doppiaggio.** L'add-on trascriveva la prima traccia audio, che spesso è un doppiaggio (per esempio il russo). Ora trascrive quella nella lingua del film e impone quella lingua a Whisper. Se il file ha solo doppiaggi non trascrive da solo: avvisa, e se lo avvii a mano chiede se vuoi trascrivere comunque.
- **Una scelta fatta a mano ferma il lavoro automatico.** Se l'add-on sta già preparando i sottotitoli da solo (per esempio leggendo una traccia scelta in automatico), la tua scelta lo interrompe subito e parte al suo posto, invece di farti aspettare.
- **OpenSubtitles.com non consuma più la tua quota di nascosto.** Per cercare una traduzione già pronta l'add-on scaricava file attraverso l'add-on OpenSubtitles.com, e ogni file contava nella quota del tuo account. Ora in automatico non lo usa più (nuova impostazione, spenta di serie); dall'elenco della scelta a mano puoi usarlo tu.

## Novità della 1.10.8
- **Sottotitoli scaricati messi in fase con l'audio.** Quelli di OpenSubtitles (o un file scelto a mano) spesso sono di un'altra edizione: partono prima o dopo, o si spostano piano piano (25 invece di 24 fotogrammi al secondo). L'add-on ascolta due tratti del film da 90 secondi, trova dove si parla e li sposta (anche correggendo la velocità) finché le frasi cadono sopra la voce. Se OpenSubtitles ha più versioni, tiene quella che va meglio con l'audio. Serve ffmpeg; si spegne nelle impostazioni (Trascrizione).
- **Quota di Whisper finita: messaggio chiaro, subito.** Prima l'add-on riprovava per minuti con la barra ferma. Ora dice se è finito il limite dell'ora o del giorno (o il credito), tra quanto si libera, e si ferma; la parte già trascritta è salvata e la volta dopo si riprende da lì.
- **OpenSubtitles.com senza quota non viene più richiamato di continuo.** L'add-on lo usava per cercare una traduzione già pronta e ogni volta compariva il suo avviso di quota giornaliera. Ora, dopo il primo rifiuto, non lo richiama fino al giorno dopo. I sottotitoli originali arrivano comunque da OpenSubtitles (un altro servizio, senza quota).

## Novità della 1.10.7
- **Le frasi brevi (una o due parole) ora vengono tradotte.** Gemini a volte ricopiava uguali le frasi corte ("Ja." → "Ja.") e l'add-on non se ne accorgeva, perché controllava le copie solo dalle tre parole in su. Ora una frase ricopiata viene chiesta anche a Google: se Google la traduce si usa quella, se la lascia uguale anche lui è un nome o una parola internazionale ("Karen", "Okay") e resta così. A Gemini viene anche detto esplicitamente di tradurre le risposte brevi e le esclamazioni.
- Le traduzioni sbagliate di questo tipo già salvate (anche con la 1.10.5) vengono rifatte da sole la prima volta che riapri il film: si ritraducono solo quelle poche frasi.

## Novità della 1.10.6
- **Lettura dei sottotitoli dentro il video più veloce.** Prima servivano due richieste per ogni frase (una per l'intestazione del pezzo di film, una per la frase) e solo 3 alla volta: ora ne basta una per frase e se ne fanno 5 alla volta, sempre sulle stesse connessioni. Per un film intero il tempo dovrebbe scendere a circa un terzo (stima, non misurata su Real-Debrid).
- Se la lettura si interrompe, la volta dopo l'add-on legge solo le frasi che mancano, non tutto da capo.
- Quando una parte del file non risponde, l'add-on rinuncia prima (meno attese inutili) e avvisa.

## Novità della 1.10.5
- **La barra di avanzamento compare subito**, in alto a destra, appena fai partire la traduzione. Prima compariva solo dopo aver letto i sottotitoli originali: con quelli dentro il video in streaming si aspettava anche un minuto senza nessun segnale. Ora la barra mostra anche la lettura ("Leggo i sottotitoli dentro il video: 120 su 987"), anche quando scegli i sottotitoli dal menu Sottotitoli del lettore.
- Se la fai ripartire mentre sta già lavorando, l'add-on avvisa ("Sto già preparando i sottotitoli doppi") invece di ricominciare da capo con una seconda lettura.

## Novità della 1.10.4
- **Sottotitoli dentro il video: non ne manca più nessuno.** Con Real-Debrid molte frasi andavano perse: il server chiudeva le connessioni perché l'add-on ne apriva troppe insieme, e le frasi non arrivate sparivano senza avviso (per esempio 279 lette su 987). Ora l'add-on usa poche connessioni e le tiene aperte, riprova le frasi non arrivate in più giri, e se alla fine ne manca qualcuna avvisa ("Letti N sottotitoli su M") e non le salva come definitive: la volta dopo rilegge e completa.
- I sottotitoli letti male con la versione precedente vengono riletti da capo (le traduzioni già fatte restano).

## Novità della 1.10.3
- Nuova voce del menu **"Scegli i sottotitoli originali da tradurre…"**: elenca tutti i sottotitoli originali trovati, per primi quelli **dentro il video** (anche Real-Debrid), poi quelli scaricati, OpenSubtitles, la trascrizione e un file dal dispositivo. Scegli e la traduzione parte subito da quelli; la scelta resta ricordata. Quella in uso è segnata con ►.
- Prima i sottotitoli dentro il video comparivano nell'elenco solo se non c'era nessun altro file (per esempio uno scaricato da OpenSubtitles): ora ci sono sempre, per primi.
- Con un film in streaming .mkv, in automatico si parte dai sottotitoli dentro il video invece che da quelli scaricati.

## Novità della 1.10.2
- Guida anche in inglese (GUIDE.en.md) e istruzioni di installazione semplificate.

## Novità della 1.10.1
- Guida completa riscritta (LEGGIMI): tutte le funzioni spiegate dall'inizio, con le istruzioni passo per passo.

## Novità della 1.10: i sottotitoli dentro il film che stai guardando
Con The Crew, Real-Debrid e simili il film è un file .mkv da decine di GB, e i sottotitoli che vedi sono dentro quel file. Prima l'add-on non riusciva a leggerli e proponeva solo quelli di OpenSubtitles, che spesso sono di un'altra edizione.

**Ora li legge senza scaricare il film.** Un .mkv contiene un indice che dice dove si trova ogni sottotitolo dentro il file. L'add-on legge l'inizio del file, l'indice e poi solo i pezzetti con le frasi, ognuno di poche centinaia di byte. Per un film intero si tratta di pochi megabyte, in circa un minuto. Non serve collegare Real-Debrid, né nessun token: basta il link che sta già usando Kodi.
- In automatico, se non ci sono file di sottotitoli, l'add-on prende la traccia **nella lingua dei sottotitoli che hai scelto nel lettore** (poi dell'audio, poi del film) e salta quelle "forzate" (che contengono solo le parti in altre lingue).
- Nel menu Sottotitoli del lettore e in "Scegli originale e traduzione" compaiono per primi come **"dentro il video: danese"** e così via.
- Una volta letti restano salvati con il nome del film: la volta dopo (anche con un nuovo link di Real-Debrid) sono subito pronti.

**Nuova voce nel menu dell'add-on: "Controlla i sottotitoli dentro il video".** Mostra le tracce di sottotitoli del file che stai guardando e dice se si possono leggere. Se qualcosa non va, mandami una foto di quella schermata o kodi.log.

**Limiti:**
- funziona con i sottotitoli di testo (SRT, ASS) dei file .mkv. Quelli a immagini (PGS, VobSub, tipici dei Blu-ray "remux") non sono testo: si possono solo trascrivere o prendere da OpenSubtitles;
- se l'indice del file non contiene i sottotitoli (succede di rado), andrebbe scaricato tutto il film: l'add-on lo dice nel controllo.


## Novità della 1.9: le traduzioni non si rifanno più da capo
**Memoria delle traduzioni.** Ogni frase tradotta viene salvata subito, gruppo per gruppo, nella memoria del film (nella cartella dei dati dell'add-on). Così:
- **se fermi il film a metà**, la volta dopo si traducono solo le frasi che mancano (prima la traduzione si salvava solo alla fine, e fermandosi prima si perdeva tutto);
- **passando dalla trascrizione a un file di sottotitoli** (o da un file a un altro, o tornando indietro) le frasi uguali non si traducono di nuovo, e tornando a una scelta di prima la traduzione è subito pronta, senza richieste;
- ogni servizio ha la sua memoria: tornando a Gemini dopo aver provato Google, le frasi di Gemini sono ancora lì;
- anche dal menu Sottotitoli del lettore: se la traduzione è già salvata non fa nessuna richiesta.

**Scegliere quando rifarla.** In "Scegli originale e traduzione per questo video…" la traduzione ha due voci:
- **"Con Gemini (o il servizio scelto): usa le frasi già tradotte e traduce solo quelle che mancano"**, con scritto quante frasi sono già salvate;
- **"Rifai da capo"**: ignora le traduzioni salvate e le chiede tutte di nuovo (consuma richieste). C'è anche nel menu dell'add-on: **"Rifai la traduzione da capo"**.

**Correzione.** Prima, se il file di sottotitoli cambiava ma aveva lo stesso nome e lo stesso numero di frasi, o se la trascrizione veniva rifatta, poteva essere riusata la traduzione vecchia, sfasata rispetto al testo nuovo. Ora la traduzione salvata è legata al contenuto, frase per frase. Le traduzioni complete fatte con le versioni precedenti vengono riusate se valgono per gli stessi sottotitoli.


## Novità della 1.8
**Sottotitoli dentro i film di Real-Debrid (The Crew e simili).** Spesso sono i più esatti per quel file. Il file da decine di GB non si può leggere tutto, ma Real-Debrid lo converte anche in uno streaming leggero (HLS) in cui le tracce di sottotitoli sono piccoli pezzi di testo: l'add-on li scarica in pochi secondi.
- Serve il **token di Real-Debrid**: l'add-on prova da solo a usare quello di ResolveURL (lo usano The Crew e molti altri add-on); se non lo trova, copialo da real-debrid.com/apitoken in **Impostazioni → Traduzione → Token di Real-Debrid**.
- In automatico, se non ci sono file di sottotitoli, l'add-on prende la traccia dentro il video nella lingua dell'audio (o in quella dei sottotitoli scelti nel lettore). Nel menu del lettore e in "Scegli originale e traduzione" compaiono come **"dentro il video (Real-Debrid): …"**.
- **Da provare su un Kodi vero**: non ho potuto verificarlo con un account Real-Debrid. Se non funziona, in kodi.log c'è scritto cosa ha risposto Real-Debrid (righe "[Sottotitoli Doppi] Real-Debrid: …"): mandamele.

**Scegliere a mano i sottotitoli originali.** In "Scegli originale e traduzione per questo video…", scegliendo "File di sottotitoli" compare l'elenco di tutti quelli trovati (accanto al video, dentro il video, Real-Debrid, OpenSubtitles con 5 versioni per lingua) più **"Scegli un file dal dispositivo…"**. La scelta viene ricordata per il film, anche quando parte da solo. Lo stesso succede scegliendo dal menu Sottotitoli del lettore.

**Trascrizione che diventava inglese.** Se Kodi non conosce la lingua della traccia audio (succede spesso con i film in streaming), ora l'add-on chiede al catalogo (Cinemeta) la lingua originale del film. Se Whisper riconosce un'altra lingua (per esempio l'inglese in un film danese), l'add-on confronta le due versioni e tiene quella del film, a meno che sia chiaramente peggiore.
- **Le trascrizioni salvate dalla 1.7 nella lingua sbagliata vengono rifatte da sole** una volta, nella lingua del film (per esempio il film danese che era diventato inglese). Se una trascrizione è comunque sbagliata: menu dell'add-on → "Rifai la trascrizione da capo", oppure imposta "Lingua parlata" in Impostazioni → Trascrizione.

**Sottotitoli che partivano molto prima della frase.** Whisper a volte fa cominciare un pezzo durante la musica o il silenzio, e a volte salta delle frasi. Ora:
- l'add-on chiede a Whisper i **tempi delle singole parole**: il sottotitolo parte quando parte la voce, e si divide dove c'è una pausa lunga;
- dopo ogni pezzo cerca le **parti con voce rimaste senza sottotitoli** e le fa riascoltare da sole a Whisper (al massimo 12 per pezzo da 10 minuti). Si può spegnere in Impostazioni → Trascrizione.

**Meno richieste a Gemini.** Gruppi di 120 frasi invece di 40: un film costa circa 12 richieste.

**Servizi di riserva.** Quando un servizio finisce le richieste gratuite di oggi, si continua con il primo altro servizio di cui hai inserito la chiave (Gemini, Groq, Mistral, OpenRouter, Microsoft Translator, DeepL), poi Google. Quello esaurito viene saltato fino al giorno dopo, anche negli altri film.

**Servizi nuovi:** **Mistral** (gratis con chiave) e **Microsoft Translator** (2 milioni di caratteri al mese gratis, chiave e area di una risorsa "Translator" F0 su Azure).

**Traduzione con una chat.** Nel menu dell'add-on:
- **Esporta trascrizione (.txt)**: scrive un file di testo con le frasi numerate e le istruzioni (a parti di 250 frasi), accanto al video o nella cartella che scegli;
- sul computer apri il file, incollalo in una chat (ChatGPT, Claude, Gemini…) e salva la risposta in un file .txt;
- **Importa traduzione (.txt)**: scegli il file (anche più parti insieme). La traduzione viene usata subito e resta salvata per il film (in "Scegli originale e traduzione" è la voce "Da una chat").


## Novità della 1.7: trascrizione più esatta, scelta di originale e traduzione
**Trascrizione che cambiava lingua (danese → inglese tradotto).** La causa: l'add-on conosceva i nomi di sole 17 lingue di Whisper, e il danese non c'era. Così la lingua del film non veniva mai fissata e Whisper, pezzo per pezzo, poteva decidere di scrivere direttamente in inglese, cioè tradurre invece di trascrivere. Ora:
- la lingua si stabilisce **una volta sola** e poi viene **imposta a Whisper per tutti i pezzi**: prima quella scelta in "Lingua parlata", poi quella della traccia audio che Kodi conosce (per esempio "dan"), poi quella riconosciuta nel primo pezzo con abbastanza parlato (non da una sigla musicale);
- se un pezzo esce comunque in inglese in un film non inglese, viene rifatto imponendo la lingua giusta;
- tutte le lingue di Whisper sono riconosciute (prima 17);
- **trascrizione più precisa** (attiva da sola): con Groq si usa whisper-large-v3 invece della versione turbo. È un po' più lenta; si può spegnere in Impostazioni → Trascrizione.

**La trascrizione non si rifà più da capo.**
- Viene salvata con il nome del film, non con l'indirizzo: con Real-Debrid l'indirizzo cambia a ogni visione (`/d/<codice>/Film.mkv`), per questo prima veniva rifatta ogni volta.
- Si salva **pezzo per pezzo**: se fermi il video a metà, la volta dopo riprende da dove era arrivata.
- Nel menu c'è **"Rifai la trascrizione da capo"** se una è venuta male.

**Scegli originale e traduzione, video per video.** Nel menu dell'add-on: **"Scegli originale e traduzione per questo video…"**.
- *Originale*: **automatico** (file di sottotitoli se c'è, altrimenti trascrizione), **trascrizione dell'audio** (con scritto se è già fatta, a metà o da fare), oppure **file di sottotitoli**.
- *Traduzione*: **automatica**, **nuova** con il servizio scelto (Gemini, Google…) oppure **già pronta** (sottotitoli tradotti da persone).
- La scelta viene **ricordata per quel video**, anche quando parte da solo. Trascrizione e traduzioni restano salvate, quindi cambiando scelta non si rifà niente e non si consuma quota.
- Gli stessi valori, per tutti i video, sono in **Impostazioni**: "Testo originale da" (Trascrizione) e "Traduzione" (Traduzione). **Controllale dopo l'aggiornamento**: sostituiscono "Trascrivi sempre l'audio" e "usa i sottotitoli tradotti già esistenti".
- Nel menu Sottotitoli del lettore (Scarica → Sottotitoli Doppi) compare anche **"trascrizione dell'audio (già fatta)"**, oppure **"trascrivi l'audio"**.

**Traduzione già pronta e trascrizione.** In automatico la traduzione già pronta si usa solo quando l'originale è un file di sottotitoli. Con la trascrizione si fa una traduzione nuova, perché Whisper divide le frasi in modo diverso dai sottotitoli e spesso le due versioni non vanno in fase. Se la vuoi comunque, scegli "già pronta": se non va in fase, l'add-on te lo dice e fa una traduzione nuova.

**La traduzione c'è sempre.** Le frasi rimaste senza traduzione (servizio che non risponde, righe saltate) vengono tradotte con Google, anche una per una.


## Novità della 1.6: traduzione in qualsiasi lingua
- In **Impostazioni → Generale → Traduci in** ora ci sono **82 lingue** (prima 16), in ordine alfabetico: dal ceco allo swahili, dal vietnamita al gallese.
- **"kodi (la lingua di Kodi)"**: traduce nella lingua in cui hai impostato Kodi. Utile se l'add-on lo usano più persone, o su dispositivi diversi.
- **"altra"**: se la lingua non è nella lista, sceglila e scrivi nella casella sotto la sigla o il nome, per esempio `yue` (cantonese), `ceco` o `Czech`. Se non la riconosce, l'add-on usa l'italiano e lo scrive nel registro.
- Tutto il resto segue la lingua scelta: la traduzione (Google, Gemini, Groq, DeepL, Claude…), la traduzione già fatta da persone (cerca i sottotitoli del film in quella lingua su OpenSubtitles), il nome dei file e la voce nel menu Sottotitoli del lettore.
- Le scritte dell'add-on restano in italiano.

## Novità della 1.6: salvare i sottotitoli (.srt)
- Nel menu dell'add-on (Add-on → Programmi → Sottotitoli Doppi) c'è **"Salva i sottotitoli (.srt) per riusarli o condividerli…"**. Salva i sottotitoli dell'ultimo video per cui li hai creati, in tre file:
  - `Titolo.en.srt`: l'originale (anche la **trascrizione** fatta con Whisper);
  - `Titolo.it.srt`: solo la traduzione;
  - `Titolo.doppi.it.srt`: originale e traduzione insieme.
- Puoi salvarli **accanto al video** (se è un file sul dispositivo o in rete di casa), in una cartella fissa scelta nelle impostazioni, oppure in una cartella che scegli ogni volta (anche una chiavetta USB o una cartella di rete).
- **Accanto al video hanno lo stesso nome del video**: Kodi li mostra da solo nell'elenco dei sottotitoli, e l'add-on la volta dopo li usa al posto di rifare la trascrizione e la traduzione (niente quota consumata).
- In **Impostazioni → Generale** puoi scegliere la cartella e attivare **"Salva sempre una copia dei sottotitoli"**: dopo ogni video i tre file vengono salvati da soli (nella cartella scelta o, se è vuota, accanto al video).
- Per un film in streaming (The Crew, Real-Debrid…) non c'è una cartella del video: scegli tu dove salvarli.


## Novità della 1.5: traduzione già fatta da persone
- **Se per il film esistono già i sottotitoli nella tua lingua** (per esempio quelli italiani su OpenSubtitles, o un file `.it.srt` accanto al video, o quelli che hai scaricato tu dal menu Sottotitoli), l'add-on li usa come traduzione: sotto ogni frase originale mette la frase italiana corrispondente. È gratis, di solito più precisa di Google Traduttore e non consuma la quota di Gemini o degli altri servizi.
- **Messa in fase automatica.** I sottotitoli originali e quelli italiani vengono spesso da edizioni diverse: uno può essere in ritardo di qualche secondo, o andare un po' più veloce (25 fotogrammi al secondo in Europa invece di 23,976). L'add-on lo calcola da solo. Se l'edizione italiana ha una scena in più (o in meno), rifà la messa in fase dopo quel punto.
- **Solo dove corrispondono davvero.** Una frase italiana viene presa solo se comincia o finisce insieme a quella originale e se attorno le due versioni sono in fase. Le frasi senza una corrispondente le traduce Google. Se meno di 6 frasi su 10 vanno in fase (un'altra edizione del film, o un altro film), quei sottotitoli non vengono usati e si traduce come prima.
- Quando chi ha fatto i sottotitoli ha unito due frasi in una, la frase italiana compare sotto tutte e due.
- **Da sapere:** i sottotitoli fatti da persone sono spesso un po' liberi o accorciati, per stare nei tempi di lettura. Sono traduzioni naturali e corrette, ma non sempre parola per parola come quelle di Gemini.
- Si può spegnere in **Impostazioni → Traduzione → "Se esistono già i sottotitoli tradotti del film, usa quelli"**.
- Nel registro (kodi.log) c'è scritto da dove viene la traduzione, di quanto è stata spostata e quante frasi ha coperto.


## Novità della 1.4.1: OpenSubtitles non dava mai risultati
- **Il problema** (dal tuo kodi.log): con Get Out e The 'Burbs il film veniva riconosciuto (codice IMDb giusto), ma OpenSubtitles rispondeva sempre "0 sottotitoli". Il sito rifiuta con buona probabilità le richieste che si presentano con il nome predefinito dei programmi in Python: ora l'add-on si presenta come un normale lettore.
- **Seconda strada**: se OpenSubtitles di Stremio non dà niente, l'add-on chiede i sottotitoli agli altri servizi di sottotitoli installati in Kodi (per esempio **OpenSubtitles.com**, che hai già installato), come se li cercassi tu dal menu Sottotitoli → Scarica. Il servizio deve essere configurato (nome utente e password nelle sue impostazioni).
- **Registro più chiaro**: in kodi.log ora c'è scritto cosa ha risposto OpenSubtitles (codice di risposta, quanti sottotitoli, in quali lingue) e cosa hanno dato gli altri servizi. Se qualcosa non va ancora, mandami di nuovo kodi.log.
- Perché non legge direttamente i sottotitoli che vedi sul video: sono una traccia dentro il file .mkv su Real-Debrid (decine di GB) e Kodi non li passa agli add-on. Per estrarli bisognerebbe scaricare tutto il file.

## Novità della 1.4: film in streaming con i sottotitoli dentro il video
Con gli add-on come The Crew e Real-Debrid i sottotitoli spesso sono **dentro il file video** che arriva da internet: Kodi li mostra, ma nessun add-on li può leggere (bisognerebbe scaricare tutto il film, decine di GB). Ora l'add-on in quel caso **prende gli stessi sottotitoli da OpenSubtitles** (gratis, senza account):
- riconosce il film dal codice IMDb che l'add-on video passa a Kodi o, se manca, dal titolo e dall'anno nel nome del file (per esempio `The.Burbs.1989.2160p…mkv`);
- cerca i sottotitoli nella lingua dell'audio del film (poi in quella dei sottotitoli scelti nel lettore, poi in inglese) e li traduce;
- se il film è già parlato nella tua lingua non fa niente.

Siccome non sono esattamente il file del tuo video, **possono essere un po' fuori sincrono**: nel menu del lettore (Sottotitoli → Scarica → **Sottotitoli Doppi**) trovi 3 versioni per lingua ("OpenSubtitles, versione 1, 2, 3"); se una non va a tempo, prova la successiva.


## Novità della 1.3
- **Il menu dei sottotitoli del lettore è un add-on a parte: "Sottotitoli Doppi" tra gli add-on di sottotitoli** (`service.subtitles.sottotitolidoppi`). Nella 1.2 la voce stava dentro l'add-on principale e Kodi lo mostrava solo come add-on video, non tra i servizi di sottotitoli. Va installato una volta (vedi "Installazione"); usa le stesse impostazioni dell'add-on principale.
  Mentre guardi il film: menu dei **sottotitoli** del lettore → **Scarica** → a sinistra **Sottotitoli Doppi** → scegli i sottotitoli originali proposti ("Doppi: norvegese → italiano"). I sottotitoli doppi compaiono subito tradotti con Google; se hai scelto Gemini, la sua traduzione arriva da sola poco dopo.
- **Riconosce i sottotitoli dati dagli add-on video in streaming.** Prima l'add-on cercava solo i file accanto al video o scaricati con Kodi, e diceva "scarica i sottotitoli" anche se il film li aveva già. Ora legge anche quelli che l'add-on video passa al lettore insieme al film (anche se sono un indirizzo internet: li scarica) e quelli che gli add-on salvano nelle loro cartelle mentre guardi.
- Una copia del file doppio salvata da Kodi non viene più scambiata per i sottotitoli originali.
- Se proprio non trova niente, lo dice chiaramente: i sottotitoli che stanno dentro un video in streaming non si possono leggere; in quel caso scaricali con OpenSubtitles o fai trascrivere l'audio. Nel registro di Kodi (`kodi.log`, righe "[Sottotitoli Doppi]") scrive dove ha cercato.

## Novità della 1.2
- **Direttamente dal lettore, mentre guardi il film** (dalla 1.3 con l'add-on a parte, vedi sopra):
  1. durante il film apri il menu dei **sottotitoli** del lettore (l'icona dei sottotitoli nella barra in basso) → **Scarica** (o "Cerca/Scarica sottotitoli");
  2. a sinistra, nell'elenco dei servizi, scegli **Sottotitoli Doppi**;
  3. compaiono i sottotitoli originali che ci sono per questo film (per esempio "Doppi: ceco → italiano"): sceglilo.

  I sottotitoli doppi compaiono subito, tradotti con Google. Se nelle impostazioni hai scelto Gemini (o un altro servizio), la traduzione migliore arriva da sola dopo qualche minuto e sostituisce quella di Google ("Traduzione migliorata con Gemini pronta"). La volta dopo è già pronta.

  Se prima vuoi i sottotitoli originali, scaricali come al solito con OpenSubtitles nello stesso menu, poi riapri **Scarica** e scegli **Sottotitoli Doppi**.
- **Non prende più i sottotitoli del film visto prima.** I sottotitoli che Kodi tiene nella sua cartella temporanea vengono usati solo se sono stati scaricati mentre guardi questo film (o se hanno il suo nome). Ha la precedenza quello nella lingua che hai scelto nel lettore. Prima il norvegese, il ceco e molte altre lingue non venivano riconosciute dal nome del file, e così vinceva un vecchio file inglese.
- **Sottotitoli dentro il video** (per esempio nei file .mkv): se non ci sono file di sottotitoli, l'add-on legge la traccia di testo dentro il video, nella lingua scelta nel lettore. Serve ffmpeg e funziona per i file sul dispositivo, non per lo streaming; le tracce fatte di immagini (PGS, DVD) non sono leggibili.

## Novità della 1.1
- **Trascrivi l'audio anche se ci sono i sottotitoli.** I sottotitoli scaricati a volte non corrispondono a quello che si sente (versioni diverse del film, frasi riassunte). Ora puoi far trascrivere l'audio in due modi:
  - dal menu dell'add-on: **"Trascrivi l'audio con Whisper (anche se ci sono i sottotitoli)"**, solo per il video che stai guardando;
  - nelle impostazioni, **Trascrizione → "Trascrivi sempre l'audio, anche se ci sono i sottotitoli"**, per tutti i video. Attenzione: ogni film consuma quota di Groq (un film di 2 ore è circa la quota di un'ora).
- **Scelta del servizio di trascrizione**: Groq (gratis con chiave), **OpenAI** (a pagamento, con la sua chiave) oppure un server Whisper sul computer.
- **Repository**: l'add-on si può installare su qualsiasi Kodi (TV box, Fire TV, altri computer) da un indirizzo internet, e si aggiorna da solo. Vedi "Installazione".

Crea un file di sottotitoli **doppio**: in ogni riga c'è l'originale e, sotto, la traduzione in giallo. Kodi lo carica come un normale sottotitolo, quindi funziona con qualsiasi lettore, telecomando e skin.

Richiede Kodi 19 (Matrix) o più recente.


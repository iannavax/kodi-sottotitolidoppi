# grafico «uso nel tempo» sulle pagine (Parole al Volo): si vede la curva? gli anni si leggono?
import asyncio, os, sys, json, math, urllib.parse
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]; SHOT = sys.argv[2] if len(sys.argv) > 2 else "/tmp/tngram_volo.png"
async def handle(route, request):
    if request.url.startswith("https://books.google.com/ngrams/json"):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(request.url).query)
        n = 223 if q.get("corpus", [""])[0] == "en" else 220
        return await route.fulfill(status=200, content_type="application/json", body=json.dumps([{"ngram": q["content"][0], "timeseries": [1e-6 * (2 + 6 * math.exp(-((i - 150) / 30) ** 2) + i / 100) for i in range(n)]}]))
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/pagina.html"); await pg.wait_for_timeout(800)
        await tvolo.hover(pg, "en", "bread", 3000)
        box = await pg.locator(".pav-card").bounding_box(); await pg.mouse.move(box["x"] + 30, box["y"] + 30, steps=3)
        await pg.wait_for_selector(".pav-card .dsx-gwngram", timeout=15000); await pg.wait_for_timeout(800)   # 1.6.3: compare da solo
        g = pg.locator(".pav-card .dsx-gwngram")
        print("1. riquadro:", (await g.inner_text()).replace("\n", " | ")[:200] if await g.count() else "(nessuno)", "|", (await tvolo.card_text(pg))[-200:].replace("\n", " | "))
        if await g.count():
            print("   svg:", await pg.evaluate("(() => { const s = document.querySelector('.pav-card .dsx-spark'); const r = s.getBoundingClientRect(); const p = s.querySelector('path'); return [Math.round(r.width), Math.round(r.height), getComputedStyle(s).color, p && p.getAttribute('d').slice(0, 60)]; })()"))
            await g.screenshot(path=SHOT)
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

#!/bin/sh
# Compila il programma di appoggio per yt-dlp (helper-go/) per Windows, Mac e Linux e lo mette compresso in src/helper/bin/.
# Serve Go (https://go.dev/dl/): nessun altro programma. Uso: tools/build-helper.sh
set -e
cd "$(dirname "$0")/../helper-go"
OUT=../src/helper/bin
mkdir -p "$OUT"
rm -f "$OUT"/sd_host-*.gz
for t in windows/amd64 darwin/amd64 darwin/arm64 linux/amd64 linux/arm64; do
  os=${t%/*}; arch=${t#*/}
  ext=""; [ "$os" = windows ] && ext=".exe"
  CGO_ENABLED=0 GOOS=$os GOARCH=$arch go build -trimpath -ldflags "-s -w" -o "/tmp/sd_host-$os-$arch$ext" .
  gzip -9 -n -c "/tmp/sd_host-$os-$arch$ext" > "$OUT/sd_host-$os-$arch.gz"
  rm -f "/tmp/sd_host-$os-$arch$ext"
  echo "$os/$arch: $(wc -c < "$OUT/sd_host-$os-$arch.gz") byte compressi"
done

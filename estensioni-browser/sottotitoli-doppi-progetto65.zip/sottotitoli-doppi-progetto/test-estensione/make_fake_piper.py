# modello Piper finto (stessi ingressi/uscita di una voce vera): l'uscita è un'onda che dipende dai suoni in ingresso
import onnx, numpy as np
from onnx import helper as h, TensorProto as T, numpy_helper as nh
inp = h.make_tensor_value_info("input", T.INT64, [1, "n"])
ln = h.make_tensor_value_info("input_lengths", T.INT64, [1])
sc = h.make_tensor_value_info("scales", T.FLOAT, [3])
out = h.make_tensor_value_info("output", T.FLOAT, [1, 1, 1, "m"])
nodes = [
  h.make_node("Cast", ["input"], ["f"], to=T.FLOAT),
  h.make_node("Mul", ["f", "k"], ["g"]),
  h.make_node("Tile", ["g", "rep"], ["t"]),
  h.make_node("Reshape", ["t", "shape"], ["output"]),
]
inits = [nh.from_array(np.array(0.01, dtype=np.float32), "k"), nh.from_array(np.array([1, 200], dtype=np.int64), "rep"), nh.from_array(np.array([1, 1, 1, -1], dtype=np.int64), "shape")]
g = h.make_graph(nodes, "fake", [inp, ln, sc], [out], inits)
m = h.make_model(g, opset_imports=[h.make_opsetid("", 13)]); m.ir_version = 8
onnx.checker.check_model(m); onnx.save(m, "/home/claude/e2e/fixtures/fake-piper.onnx")
print("ok", len(open("/home/claude/e2e/fixtures/fake-piper.onnx","rb").read()))

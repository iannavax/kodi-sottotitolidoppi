# 1.5.1: popup → 🗒 Aspetto delle schede: grandezza, larghezza, colori, posizione della scheda nei video
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
ST = "(()=>{const c=document.querySelector('.dualsub-card'); if(!c) return null; const cs=getComputedStyle(c), m=c.querySelector('.dualsub-card-meaning'), p=document.querySelector('#movie_player').getBoundingClientRect(), r=c.getBoundingClientRect(); return {font: cs.fontSize, w: Math.round(r.width), bg: cs.backgroundColor, fg: cs.color, mean: m && getComputedStyle(m).color, rightGap: Math.round(p.right - r.right)}})()"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, learnExamples:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        a = await pg.evaluate(ST); print("1. di serie:", a)
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(800)
        await pp.evaluate("document.getElementById('dCard').open=true")
        await pp.fill("#cardScale", "150"); await pp.dispatch_event("#cardScale", "input")
        await pp.fill("#cardWidth", "120"); await pp.dispatch_event("#cardWidth", "input")
        await pp.evaluate("for (const [id,v] of [['cardBg','#ffffff'],['cardText','#111111'],['cardAccent','#0055cc']]) { const e=document.getElementById(id); e.value=v; e.dispatchEvent(new Event('input')); }")
        await pp.select_option("#cardPosVideo", "right"); await pp.wait_for_timeout(500)
        print("   popup:", await pp.inner_text("#cardScaleVal"), "| riga pagine nascosta (SD da sola):", await pp.evaluate("document.getElementById('cardPosPageRow').hidden"))
        await pg.bring_to_front(); await pg.wait_for_timeout(800)
        b = await pg.evaluate(ST); print("2. cambiato:", b)
        await pp.click("#resetCardLook"); await pg.wait_for_timeout(800)
        c = await pg.evaluate(ST); print("3. ripristinato:", c)
        ok = a and b and a["font"] == "14px" and b["font"] == "21px" and b["w"] > a["w"] * 1.6 and b["bg"] == "rgb(255, 255, 255)" and b["mean"] == "rgb(0, 85, 204)" and b["rightGap"] < 20 and c["font"] == "14px"
        print("errori:", errs if ok else errs + ["aspetto delle schede non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

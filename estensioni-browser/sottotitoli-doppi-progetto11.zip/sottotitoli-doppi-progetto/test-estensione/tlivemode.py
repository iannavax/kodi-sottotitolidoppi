# 5.21: scelta della modalità nelle dirette: pulsante ⏱ accanto ai sottotitoli e riquadro in cima al popup
import asyncio, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/embed/direttaModo?autoplay=1"); await pg.wait_for_timeout(1500)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("(document.querySelector('.dualsub-orig')||{}).textContent", timeout=30000)
        B = "(()=>{const b=document.querySelector('.dualsub-aheadbtn'); return b ? [b.hidden, b.className.includes(' on'), b.title.slice(0,70)] : 'nessuno'})()"
        print("1. ⏱ in diretta:", await pg.evaluate(B))
        tab = await sw.evaluate("chrome.tabs.query({}).then(t=>t.find(x=>/direttaModo/.test(x.url)).id)")
        st = lambda: sw.evaluate(f"chrome.tabs.sendMessage({tab}, {{type:'liveState'}}).then(r=>JSON.stringify({{live:r.live, yt:r.yt, aheadOn:r.aheadOn, ahead:r.ahead, running:r.running}}))")
        print("   stato per il popup:", await st())
        L = "(()=>{const b=document.querySelector('.dualsub-langbtn'); if(!b) return 'nessuno'; const cs=getComputedStyle(b); return [b.hidden, cs.display, b.textContent, b.getBoundingClientRect().width]})()"
        print("   pulsante lingua:", await pg.evaluate(L), "| riga:", await pg.evaluate("document.querySelector('.dualsub-overlay').className"))
        await pg.evaluate("document.querySelector('.dualsub-aheadbtn').click()"); await pg.wait_for_timeout(1500)
        print("2. dopo ⏱:", await pg.evaluate(B), "| impostazione:", await sw.evaluate("chrome.storage.sync.get('liveAhead').then(r=>r.liveAhead)"))
        print("   stato:", await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)"), "|", await st())
        await pg.evaluate("document.querySelector('.dualsub-aheadbtn').click()"); await pg.wait_for_timeout(800)
        print("3. di nuovo ⏱:", await pg.evaluate(B), "|", (await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)"))[:90])
        # riquadro del popup (lo stato della diretta glielo do io: nel banco il popup non ha una scheda accanto)
        pp = await ctx.new_page(); pp.on("pageerror", lambda e: errs.append("popup: " + str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(800)
        print("4. popup senza diretta, riquadro nascosto:", await pp.evaluate("document.getElementById('liveModeBox').hidden"))
        await pp.evaluate("updateLive({onVideo:true, live:true, yt:true, running:true, ahead:{state:'off'}})")
        print("   in diretta:", await pp.evaluate("[document.getElementById('liveModeBox').hidden, document.getElementById('liveModeSel').value, document.getElementById('liveModeInfo').textContent]"))
        await pp.select_option("#liveModeSel", "ahead"); await pp.wait_for_timeout(300)
        await pp.evaluate("updateLive({onVideo:true, live:true, yt:true, running:true, ahead:{state:'on', lead:14}})")
        print("   scelta sincronizzata:", await sw.evaluate("chrome.storage.sync.get('liveAhead').then(r=>r.liveAhead)"), "|", await pp.inner_text("#liveModeInfo"), "| casella nella sezione:", await pp.is_checked("#liveAhead"))
        await pg.wait_for_timeout(800)
        print("5. sulla pagina:", await pg.evaluate(B))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

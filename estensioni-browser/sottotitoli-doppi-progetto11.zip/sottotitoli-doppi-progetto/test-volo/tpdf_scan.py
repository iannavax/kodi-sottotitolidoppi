# Lettore PDF: pagine scansionate (immagini JBIG2 e JPEG 2000 con testo OCR sotto) non devono restare bianche
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def handle(route, request):
    if request.url.split("?")[0].endswith(".pdf"):
        return await route.fulfill(status=200, content_type="application/pdf", body=open("/tmp/doc_scan.pdf", "rb").read())
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m: errs.append(m.text) if m.type in ("warning","error") else None)
        await pg.goto(f"chrome-extension://{eid}/pdf.html?file=https%3A%2F%2Fexample.test%2Fscan.pdf"); await pg.wait_for_timeout(4000)
        dark = await pg.evaluate("""()=>[...document.querySelectorAll('.page canvas')].map(c=>{const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data; let n=0; for(let i=0;i<d.length;i+=4) if(d[i]<100&&d[i+3]>0) n++; return n})""")
        print("1. pixel scuri per pagina:", dark, "->", "OK" if len(dark)==2 and all(x>500 for x in dark) else "PAGINE BIANCHE")
        print("2. testo OCR:", await pg.evaluate("[...document.querySelectorAll('.textLayer')].map(t=>t.textContent).join(' | ')"))
        cons = []
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

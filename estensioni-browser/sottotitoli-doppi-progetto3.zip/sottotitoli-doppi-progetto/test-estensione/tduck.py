import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', hoverPause:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=capsDuck"); await pg.wait_for_timeout(1000)
        await pg.evaluate("const v=document.querySelector('video'); v.volume=0.8; v.play()")
        await pg.wait_for_selector(".dualsub-orig .dualsub-word", timeout=15000)
        async def once(label, change_during=False):
            await pg.locator(".dualsub-orig .dualsub-word").nth(1).click()
            await pg.wait_for_selector(".dualsub-card-meaning", timeout=10000)
            await pg.click(".dualsub-speak"); await pg.wait_for_timeout(250)
            during = await pg.evaluate("document.querySelector('video').volume")
            if change_during: await pg.evaluate("document.querySelector('video').volume=0.5")
            await pg.wait_for_timeout(2500)
            after = await pg.evaluate("document.querySelector('video').volume")
            playing = not await pg.evaluate("document.querySelector('video').paused")
            print(f"{label}: prima 0.8 → durante {during} → dopo {after} | video in riproduzione: {playing}")
            await pg.click(".dualsub-card-btn[title='Chiudi']"); await pg.wait_for_timeout(300)
        await once("pronuncia")
        await once("pronuncia di nuovo")
        await pg.evaluate("document.querySelector('video').volume=0.8")
        await once("volume cambiato da te durante la pronuncia (a 0.5)", change_during=True)
        print("errori:", errs)
        await ctx.close()
asyncio.run(main())

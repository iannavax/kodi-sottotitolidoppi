# Crea /tmp/synct/film.mkv (16 minuti: parlato di /tmp/speech.wav a pezzi, con rumore e "musica") e truth.json
# (i tempi veri delle frasi), per test_kodi12.py
import subprocess, random, json, re, os
os.makedirs("/tmp/synct", exist_ok=True); os.chdir("/tmp/synct")
random.seed(3)
parts = []
for i in range(70):
    ln = random.uniform(5, 11); st = random.uniform(0, 66.0 - ln); gap = random.uniform(2, 9)
    parts.append((st, ln, gap))
filt = [f"[0:a]atrim={st:.2f}:{st+ln:.2f},asetpts=PTS-STARTPTS,apad=pad_dur={gap:.2f}[p{k}]" for k, (st, ln, gap) in enumerate(parts)]
fc = ";".join(filt) + ";" + "".join(f"[p{k}]" for k in range(len(parts))) + f"concat=n={len(parts)}:v=0:a=1[sp]"
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", "/tmp/speech.wav", "-filter_complex", fc, "-map", "[sp]", "-ar", "16000", "-ac", "1", "clean.wav"], check=True)
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", "clean.wav", "-f", "lavfi", "-i", "anoisesrc=color=pink:amplitude=0.06:r=16000", "-f", "lavfi", "-i", "sine=f=220:r=16000",
                "-filter_complex", "[2:a]volume=0.05[m];[0:a][1:a][m]amix=inputs=3:duration=first:normalize=0[o]", "-map", "[o]", "-c:a", "aac", "-b:a", "96k", "film.mkv"], check=True)
err = subprocess.run(["ffmpeg", "-nostdin", "-i", "clean.wav", "-af", "silencedetect=noise=-35dB:d=0.5", "-f", "null", "-"], capture_output=True).stderr.decode()
spans, t = [], 0.0
for m in re.finditer(r"silence_start:\s*([\d.]+)|silence_end:\s*([\d.]+)", err):
    if m.group(1):
        if float(m.group(1)) > t: spans.append((t, float(m.group(1))))
    else: t = float(m.group(2))
cues = []
for a, b in spans:
    x = a
    while x < b - 0.3:
        y = min(b, x + 3.5); cues.append({"s": int(x * 1000), "e": int(y * 1000), "t": "frase %d" % (len(cues) + 1)}); x = y
json.dump(cues, open("truth.json", "w"))
print("fatto:", len(cues), "frasi")

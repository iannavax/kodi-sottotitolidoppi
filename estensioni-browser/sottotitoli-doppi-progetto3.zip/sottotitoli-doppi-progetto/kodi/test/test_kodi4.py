# Prove della 1.8: tempi delle parole, parti saltate riascoltate, servizi di riserva, traduzione da una chat
import sys, os, json, time, shutil, re, urllib.parse
sys.path.insert(0, "/home/claude/kodi/test/stubs")
sys.path.insert(0, "/home/claude/kodi/script.sottotitolidoppi")
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
from resources.lib import core
calls = []
tr = lambda x: " ".join(w[::-1] for w in x.split())
MODE = {"gem": "ok"}
def field(data, name):
    m = re.search(rb'name="%s"\r\n\r\n([^\r]*)' % re.escape(name.encode()), data or b"")
    return m.group(1).decode() if m else ""
def words_for(text, a, b):
    ws = text.split(); step = (b - a) / max(1, len(ws))
    return [{"word": w, "start": round(a + k * step, 2), "end": round(a + (k + 1) * step - 0.05, 2)} for k, w in enumerate(ws)]
# parti con voce in /tmp/speech.wav: Whisper "salta" 39,2-43,6 e 50,6-54,2, e fa cominciare un segmento a 19,6 s
# quando la voce comincia a 30 s
SPANS = [(0, 2.6), (3.2, 7.0), (7.6, 9.5), (10.1, 15.3), (15.9, 19.0), (19.6, 35.6), (36.2, 38.6), (39.2, 43.6), (44.2, 47.2),
         (47.8, 50.0), (50.6, 54.2), (54.8, 57.6), (58.2, 62.1), (62.8, 66.1)]
def fake_http(url, data=None, headers=None, timeout=90):
    calls.append(url.split("?")[0])
    if "translate.googleapis.com" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["q"][0]
        return 200, json.dumps([[["\n".join("IT[" + tr(l) + "]" for l in q.split("\n")), q]], None, "en"]).encode(), {}
    if "audio/transcriptions" in url:
        name = re.search(rb'filename="([^"]+)"', data).group(1).decode()
        gran = field(data, "timestamp_granularities[]")
        calls.append("whisper:%s:%s:%s" % (name, field(data, "language") or "-", gran))
        if name.startswith("buco"):
            text = "recuperata %s davvero" % name[4:10]
            segs = [{"start": 0.3, "end": 3.0, "text": " " + text, "no_speech_prob": 0.02, "avg_logprob": -0.3}]
            return 200, json.dumps({"language": "english", "segments": segs, "words": words_for(text, 0.3, 3.0)}).encode(), {}
        segs, words = [], []
        for k, (a, b) in enumerate(SPANS):
            if (a, b) in ((39.2, 43.6), (50.6, 54.2)):
                continue
            text = "frase tardiva qui" if a == 19.6 else "frase numero %d qui" % (k + 1)
            segs.append({"start": a, "end": b, "text": " " + text, "no_speech_prob": 0.02, "avg_logprob": -0.3})
            words += words_for(text, 30.0 if a == 19.6 else a + 0.1, b - 0.1)
        return 200, json.dumps({"language": "english", "segments": segs, "words": words}).encode(), {}
    if "generativelanguage" in url:
        calls.append("gemini")
        if MODE["gem"] == "day":
            return 429, b'[{"error":{"code":429,"message":"You exceeded your current quota","details":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel-FreeTier"}]}}]', {}
        segs = json.loads(json.loads(data)["messages"][1]["content"])["segments"]
        return 200, json.dumps({"choices": [{"message": {"content": json.dumps({"t": ["GEM[" + tr(s) + "]" for s in segs]})}}]}).encode(), {}
    if "api.groq.com/openai/v1/chat" in url:
        calls.append("groq")
        return 429, b'{"error":{"message":"Rate limit reached for model llama-3.3-70b-versatile: Limit 100000, tokens per day (TPD)"}}', {}
    if "api.mistral.ai" in url:
        calls.append("mistral")
        segs = json.loads(json.loads(data)["messages"][1]["content"])["segments"]
        return 200, json.dumps({"choices": [{"message": {"content": json.dumps({"t": ["MIS[" + tr(s) + "]" for s in segs]})}}]}).encode(), {}
    if "cognitive.microsofttranslator" in url:
        calls.append("microsoft:" + (headers or {}).get("Ocp-Apim-Subscription-Region", ""))
        return 200, json.dumps([{"translations": [{"text": "MS[" + tr(x["Text"]) + "]"}]} for x in json.loads(data)]).encode(), {}
    if url.startswith("https://opensubtitles-v3.strem.io/") or "cinemeta" in url:
        return 200, b'{"subtitles": [], "metas": []}', {}
    return 404, b"", {}
core.http = fake_http
from resources.lib import runner
for d in ("/tmp/kodi-profile", "/tmp/kodi-temp", "/tmp/kodi-userdata", "/tmp/kodi-chat"):
    shutil.rmtree(d, ignore_errors=True)
os.makedirs("/tmp/kodi-temp/subtitles"); os.makedirs("/tmp/kodi-chat")
xbmcaddon.SETTINGS.clear()
xbmcaddon.SETTINGS.update({"target": "it (italiano)", "engine": "google (gratis, senza chiave)", "layout": "Originale sopra",
                           "trans_color": "FFFF00", "auto": "true", "groq_key": "gsk_test", "stt": "groq (gratis con chiave)",
                           "stt_lang": "auto", "source_mode": "trascrizione (sempre l'audio, salvata: si fa una volta sola)"})
def play(url):
    xbmc.Player.playing_file = url
    xbmcgui.PROPS[runner.START_PROP] = json.dumps({"file": url, "at": time.time() - 20})
    xbmc.Player.subs.clear(); xbmcgui.NOTES.clear(); calls.clear(); xbmc.LOG.clear()
def blocks():
    t = open(xbmc.Player.subs[-1], encoding="utf-8").read() if xbmc.Player.subs else ""
    return [b.split("\n") for b in t.strip().split("\n\n") if b.strip()]
W = lambda: [c for c in calls if c.startswith("whisper:")]

# 1. tempi delle parole e parti saltate
play("/tmp/speech.wav"); xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.AudioLanguage": "eng"})
runner.run(xbmc.Player(), interactive=True)
bl = blocks()
late = [b for b in bl if "tardiva" in b[2]]
print("1. richieste a Whisper:", len(W()), "| tempi delle parole chiesti:", all(c.endswith(":word") or c.endswith(":segment") for c in W()))
print("   segmento che Whisper faceva partire a 19,6 s ora parte a:", late[0][1].split(" --> ")[0] if late else None)
rec = [(b[1].split(" --> ")[0], b[2]) for b in bl if "recuperata" in b[2]]
print("   parti saltate riascoltate:", rec)
print("   frasi in tutto:", len(bl))

# 2. servizi di riserva: Gemini ha finito le richieste di oggi → Mistral; il film dopo non prova più Gemini
for f in os.listdir(runner.CACHE):
    if f.endswith(".json") and "parziale" not in f and "trascr" not in f: pass
xbmcaddon.SETTINGS.update({"engine": "gemini (gratis con chiave, consigliato)", "gemini_key": "AIza", "mistral_key": "mis-test",
                           "source_mode": "file (solo sottotitoli, mai trascrizione)"})
os.makedirs("/tmp/kodi-film9", exist_ok=True)
def srt(lines):
    return "\n".join("%d\n00:00:%02d,000 --> 00:00:%02d,500\n%s\n" % (i + 1, i * 4, i * 4 + 3, l) for i, l in enumerate(lines))
open("/tmp/kodi-film9/Uno.en.srt", "w").write(srt(["one two three four", "five six seven", "eight nine ten"]))
open("/tmp/kodi-film9/Uno.mkv", "w").write("x")
open("/tmp/kodi-film9/Due.en.srt", "w").write(srt(["alpha beta gamma", "delta epsilon"]))
open("/tmp/kodi-film9/Due.mkv", "w").write("x")
MODE["gem"] = "day"
play("/tmp/kodi-film9/Uno.mkv"); xbmc.INFO.clear()
runner.run(xbmc.Player(), interactive=True)
print("2. Gemini esaurito:", [c for c in calls if c in ("gemini", "groq", "mistral")], "| sottotitoli:", blocks()[0][3] if blocks() else None)
play("/tmp/kodi-film9/Due.mkv")
runner.run(xbmc.Player(), interactive=True)
print("   film successivo:", [c for c in calls if c in ("gemini", "groq", "mistral")], "| esauriti oggi:", open(core.BLOCKED_PATH).read())
# Microsoft Translator
os.remove(core.BLOCKED_PATH); MODE["gem"] = "ok"
xbmcaddon.SETTINGS.update({"engine": "microsoft (Microsoft Translator, 2 milioni di caratteri al mese gratis)", "microsoft_key": "ms-key", "microsoft_region": "westeurope"})
for f in os.listdir(runner.CACHE): os.remove(os.path.join(runner.CACHE, f))
play("/tmp/kodi-film9/Due.mkv")
runner.run(xbmc.Player(), interactive=True)
print("   Microsoft Translator:", [c for c in calls if c.startswith("microsoft")], "|", blocks()[0][3] if blocks() else None)
xbmcaddon.SETTINGS.update({"engine": "google (gratis, senza chiave)"})

# 3. traduzione con una chat: Esporta trascrizione → (chat) → Importa traduzione
play("/tmp/kodi-film9/Uno.mkv")
runner.run(xbmc.Player(), interactive=True)
xbmcgui.SELECT_ANSWER[0] = 1; xbmcgui.BROWSE_ANSWER[0] = "/tmp/kodi-chat/"
runner.export_menu(xbmc.Player())
files = sorted(os.listdir("/tmp/kodi-chat"))
print("3. esportata:", files, "|", xbmcgui.NOTES[-1][:70])
txt = open("/tmp/kodi-chat/" + files[0], encoding="utf-8").read()
print("   contenuto:", repr(txt[:120]), "…", repr(txt.strip().split("\n")[-1]))
open("/tmp/kodi-chat/risposta.txt", "w", encoding="utf-8").write("Certo! Ecco:\n**1.** CHAT uno\n2) CHAT due\n3: CHAT tre\n")
xbmcgui.BROWSE_ANSWER[0] = ["/tmp/kodi-chat/risposta.txt"]; xbmc.Player.subs.clear(); calls.clear()
runner.import_menu(xbmc.Player())
print("   importata:", [b[3] for b in blocks()], "| richieste di traduzione:", len([c for c in calls if "translate" in c or c in ("gemini", "mistral")]))
print("   avvisi:", [n for n in xbmcgui.NOTES if "importat" in n])
# si ritrova anche avviando di nuovo il video
xbmc.Player.subs.clear()
runner.run(xbmc.Player())
print("   rivisto:", [b[3] for b in blocks()])
xbmcgui.SELECT_ANSWER[0] = -1; xbmcgui.BROWSE_ANSWER[0] = ""

# 4. scelta a mano dei sottotitoli originali (film in streaming: versioni di OpenSubtitles)
def fake_os(url, data=None, headers=None, timeout=90):
    if url.startswith("https://opensubtitles-v3.strem.io/subtitles/"):
        subs = [{"id": str(i), "url": "https://dl.os.example/%d.srt" % i, "lang": "eng"} for i in range(4)]
        return 200, json.dumps({"subtitles": subs}).encode(), {}
    if url.startswith("https://dl.os.example/"):
        n = url.rsplit("/", 1)[1].split(".")[0]
        return 200, srt(["version %s line one" % n, "version %s line two" % n]).encode(), {}
    return fake_http(url, data, headers, timeout)
core.http = fake_os
xbmcaddon.SETTINGS.update({"source_mode": "auto (file di sottotitoli se c'è, altrimenti trascrizione se attiva qui sotto)"})
play("https://22-4.download.real-debrid.com/d/FFFF/The.Burbs.1989.mkv")
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.IMDBNumber": "tt0096734", "VideoPlayer.AudioLanguage": "eng"})
seq = [2, 0, 2]   # originale: file di sottotitoli; traduzione: automatica; terza versione
orig_select = xbmcgui.Dialog.select
def seq_select(self, h, opts):
    xbmcgui.SELECTS.append((h, opts)); return seq.pop(0)
xbmcgui.Dialog.select = seq_select
runner.choose_menu(xbmc.Player())
print("4. elenco dei sottotitoli originali:", xbmcgui.SELECTS[-1][1])
print("   scelta la versione 3:", [b[2] for b in blocks()])
xbmc.Player.subs.clear()
runner.run(xbmc.Player())
print("   avvio automatico, gli stessi:", [b[2] for b in blocks()][:1])
xbmcgui.Dialog.select = orig_select

# 5. sottotitoli dentro il file di Real-Debrid (streaming HLS di Real-Debrid)
VTT = ["WEBVTT\nX-TIMESTAMP-MAP=MPEGTS:900000,LOCAL:00:00:00.000\n\n00:00:01.000 --> 00:00:03.000\nHvor er du?\n\n00:00:09.000 --> 00:00:11.500\nJeg er her.\n",
       "WEBVTT\nX-TIMESTAMP-MAP=MPEGTS:900000,LOCAL:00:00:00.000\n\n00:00:09.000 --> 00:00:11.500\nJeg er her.\n\n00:00:14.000 --> 00:00:16.000\nKom nu.\n",
       "WEBVTT\nX-TIMESTAMP-MAP=MPEGTS:900000,LOCAL:00:00:00.000\n\n00:00:21.000 --> 00:00:23.000\nFarvel.\n"]
rd_calls = []
def fake_rd(url, data=None, headers=None, timeout=90):
    if url.startswith("https://api.real-debrid.com/"):
        rd_calls.append(url.split("rest/1.0")[1].split("?")[0])
        assert (headers or {}).get("Authorization") == "Bearer rd-token"
        if "/downloads" in url:
            return 200, json.dumps([{"id": "ABC123", "download": "https://22-4.download.real-debrid.com/d/QQQQ/Jagten.2012.mkv"}]).encode(), {}
        if "/streaming/transcode/ABC123" in url:
            return 200, json.dumps({"apple": {"full": "https://stream.real-debrid.example/t/ABC123/full.m3u8"}}).encode(), {}
        return 404, b"", {}
    if url == "https://stream.real-debrid.example/t/ABC123/full.m3u8":
        return 200, ('#EXTM3U\n#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="Dansk",LANGUAGE="dan",URI="subs/dan.m3u8"\n'
                     '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="English",LANGUAGE="eng",URI="subs/eng.m3u8"\n'
                     '#EXT-X-STREAM-INF:BANDWIDTH=5000000,SUBTITLES="subs"\nvideo.m3u8\n').encode(), {}
    if url == "https://stream.real-debrid.example/t/ABC123/subs/dan.m3u8":
        return 200, "#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nd0.vtt\n#EXTINF:10,\nd1.vtt\n#EXTINF:10,\nd2.vtt\n#EXT-X-ENDLIST\n".encode(), {}
    m = re.match(r"https://stream.real-debrid.example/t/ABC123/subs/d(\d).vtt", url)
    if m:
        return 200, VTT[int(m.group(1))].encode(), {}
    return fake_http(url, data, headers, timeout)
core.http = fake_rd
xbmcaddon.SETTINGS.update({"rd_token": "rd-token", "source_mode": "auto (file di sottotitoli se c'è, altrimenti trascrizione se attiva qui sotto)",
                           "trans_mode": "nuova (con il servizio scelto qui sotto, salvata)"})
play("https://22-4.download.real-debrid.com/d/QQQQ/Jagten.2012.mkv")
xbmc.INFO.clear(); xbmc.INFO.update({"VideoPlayer.AudioLanguage": "dan"})
runner.run(xbmc.Player(), interactive=True)
bl = blocks()
print("5. Real-Debrid:", rd_calls, "| frasi:", [(b[1].split(" --> ")[0], b[2]) for b in bl])
print("   avviso:", [n for n in xbmcgui.NOTES if "Real-Debrid" in n][:1])
xbmcplugin.ITEMS.clear()
from resources.lib import subtitles
subtitles.main(["plugin://service.subtitles.sottotitolidoppi/", "30", "?action=search"])
print("   nel menu del lettore:", [li.label2 for u, li in xbmcplugin.ITEMS][:3])

# 1.4.9: la scheda resta dentro lo schermo anche quando cresce dopo l'apertura (etimologia, immagini) e cliccando le
# frecce delle immagini per Anki non torna in cima / non si sposta
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
R = "(() => { const c = document.querySelector('.dualsub-card'); if (!c) return null; const r = c.getBoundingClientRect(); return {top: Math.round(r.top), bottom: Math.round(r.bottom), h: Math.round(r.height), sh: c.scrollHeight, st: Math.round(c.scrollTop), max: c.style.maxHeight, vh: innerHeight}; })()"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, ankiImage:true})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.set_viewport_size({"width": 1000, "height": 520})
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(300)
        print("1. subito:", await pg.evaluate(R))
        await pg.wait_for_timeout(4000)
        r = await pg.evaluate(R)
        print("2. dopo il caricamento:", r, "| dentro lo schermo:", r and r["top"] >= 0 and r["bottom"] <= r["vh"])
        await pg.evaluate("document.querySelector('.dualsub-card').scrollTop = 99999"); await pg.wait_for_timeout(300)
        before = await pg.evaluate(R)
        nxt = pg.locator(".dualsub-card button[title='Immagine successiva']")
        print("   frecce:", await nxt.count())
        for k in range(3):
            if await nxt.count(): await nxt.first.click(); await pg.wait_for_timeout(700)
        after = await pg.evaluate(R)
        print("3. prima delle frecce:", before, "\n   dopo 3 clic:", after, "| ferma:", before and after and abs(before["top"] - after["top"]) < 4 and abs(before["st"] - after["st"]) < 40)
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

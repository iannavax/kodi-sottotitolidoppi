// Logica principale: riceve i sottotitoli (o li crea dall'audio), li fa tradurre e li mostra sul video.
const C = DS_CONFIG;

let settings = null;
let track = null;       // sottotitoli di YouTube: { videoId, lang, kind, baseUrl, cues, segments }
let transCues = [];     // modalità YouTube riga per riga
let segTrans = [];      // una traduzione per frase
let translating = false;
let job = 0, reqId = 0;
let lastSignature = "";
const pending = new Map();
const hasCaptions = {};
const dsAsrInfo = {};      // video → { lang, segments } dei sottotitoli automatici di YouTube (lingua dell'audio)
let dsCcRetryAt = 0;
let overlay = null, lineOrig = null, lineTrans = null;

const baseLang = (l) => (l || "").split("-")[0].toLowerCase();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const toPage = (msg) => window.postMessage(JSON.stringify({ __dualsub: "ext", ...msg }), location.origin);
// getVideo(), currentVideoId(), dsPlayerBox() arrivano da media.js

// "Traduzione" identica all'originale (il modello o Google l'hanno solo ricopiata)
function dsNorm(t) { return String(t || "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ""); }
function dsIsEcho(orig, trans) {
  // Traduzione identica o quasi (una virgola, una parola in più o in meno) all'originale
  const words = (t) => String(t || "").toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  const a = words(orig), b = words(trans);
  if (a.length >= 3 && b.length) {
    if (a.join(" ") === b.join(" ")) return true;
    const set = new Set(a);
    const ratio = b.length / a.length;
    if (ratio > 0.7 && ratio < 1.45 && b.filter((x) => set.has(x)).length / Math.max(a.length, b.length) >= 0.8) return true;
  }
  // …oppure scritta in una lingua diversa da quella in cui traduci (per esempio l'originale ripulito)
  const g = DualSubs.guessLang(trans);
  const target = String((settings && settings.targetLang) || "").split("-")[0];
  if (g && target && g !== target) return true;
  // …o in un altro alfabeto (per esempio la trascrizione araba al posto della traduzione italiana): prima passava,
  // veniva salvata e ricompariva sempre, anche cambiando lingua
  return !!(target && DualSubs.wrongLang(trans, target));
}
// Traduzione salvata che non può essere quella della sua frase (vuota o di lunghezza molto diversa)
function dsBadSaved(src, t) {
  if (dsIsEcho(src, t) || dsUncheckedCopy(src, t, settings && settings.targetLang)) return true;
  if (String(src).trim().split(/\s+/).length < 3) return false;
  return !String(t).trim() || t.length > src.length * 2.6 + 25 || t.length < src.length * 0.3;
}
const dsSiteDisabled = () => !!(settings && (settings.disabledSites || []).includes(location.hostname));

function setStatus(text) {
  if (typeof live !== "undefined" && live.running && live.isLive) dsLiveLog("stato: " + text);
  try { chrome.storage.local.set({ status: { text, at: Date.now() } }); } catch {}
}

function loadSettings() {
  return new Promise((res) =>
    chrome.storage.sync.get(C.SYNC_DEFAULTS, (s) =>
      chrome.storage.local.get({ keys: {}, apiKey: "" }, (l) => {
        const keys = { ...(l.keys || {}) };
        if (!keys.claude && l.apiKey) keys.claude = l.apiKey; // chiave salvata dalla versione 2
        res({ ...s, models: { ...(s.models || {}) }, keys });
      })));
}

// traduttore scelto per un singolo video (⚑ → "Tutta la traduzione è sbagliata" → "Rifalla con Google"), o Google
// quando la traduzione di YouTube di questo video è nell'alfabeto sbagliato
let dsVideoEngine = {};
DS_EXT.storage.local.get({ videoEngine: {} }).then((r) => { dsVideoEngine = r.videoEngine || {}; }).catch(() => {});
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.videoEngine) dsVideoEngine = ch.videoEngine.newValue || {}; });
function engine(s = settings) {
  const over = dsVideoEngine[currentVideoId()];
  const id = over && C.ENGINES[over] ? over : C.ENGINES[s.engine] ? s.engine : "google";
  const E = C.ENGINES[id];
  return { id, E, key: s.keys[id] || "", model: s.models[id] || E.defaultModel || "", localUrl: s.localUrl };
}

// ---------- Servizi di riserva quando uno finisce le richieste gratuite ----------
// Un servizio che ha esaurito la quota di oggi viene saltato (anche negli altri video) fino al giorno dopo
// (le quote di Gemini si azzerano a mezzanotte di Los Angeles, verso le 9 in Italia); intanto si usa il primo
// servizio di riserva di cui hai la chiave (Groq, Mistral, OpenRouter…), e solo alla fine Google Traduttore.
let dsBlocked = {};
const dsPacificDay = () => { try { return new Date().toLocaleDateString("en-CA", { timeZone: "America/Los_Angeles" }); } catch { return new Date().toISOString().slice(0, 10); } };
chrome.storage.local.get({ dsBlocked: {} }, (r) => { dsBlocked = r.dsBlocked || {}; });
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== "local" || !ch.dsBlocked) return;
  const before = dsBlocked;
  dsBlocked = ch.dsBlocked.newValue || {};
  // "Riprova …" nel popup: il servizio scelto non è più bloccato → riprendo la traduzione con quello
  try {
    const id = settings && engine().id;
    if (id && before[id] && !dsBlocked[id] && track && !liveActive()) { setStatus(`Riprovo con ${engine().E.label.split(" (")[0]}…`); startTranslation(); }
  } catch {}
});
function dsIsBlocked(id) {
  const b = dsBlocked[id];
  return !!b && b.day === dsPacificDay() && Date.now() - b.at < 20 * 3600 * 1000;
}
function dsMarkBlocked(id) {
  if (!id || id === "google") return;
  dsBlocked = { ...dsBlocked, [id]: { day: dsPacificDay(), at: Date.now() } };
  DS_EXT.storage.local.set({ dsBlocked }).catch(() => {});
}
function engineById(id) {
  const E = C.ENGINES[id];
  return { id, E, key: settings.keys[id] || "", model: settings.models[id] || E.defaultModel || "", localUrl: settings.localUrl };
}
const dsReady = (e) => !(e.E.needsKey && !e.key) && !(e.E.kind === "openai" && !e.model) && e.E.kind !== "youtube";
// Il servizio da usare adesso: quello scelto, oppure (se ha finito la quota di oggi) il primo di riserva disponibile
function dsUsable(e) {
  if (!e || e.id === "google" || !dsIsBlocked(e.id)) return e;
  return dsNextEngine(e.id) || GOOGLE_ENGINE;
}
function dsNextEngine(fromId) {
  if (!settings || settings.fallback === false) return null;
  for (const id of C.engineOrder(settings)) {
    if (id === fromId || !C.ENGINES[id] || dsIsBlocked(id)) continue;
    const e = engineById(id);
    if (dsReady(e)) return e;
  }
  return null;
}

// Quante parole del video conosci (prova): sulle frasi dei sottotitoli o della trascrizione
function dsComprehension() {
  try {
    if (!settings || settings.learnKnown === false || typeof DS_KNOWN === "undefined") return null;
    let lang = "", texts = [];
    if (liveActive() || (!track && live.cues.length)) { lang = liveSourceLang(); texts = live.cues.filter((c) => !c.removed).map((c) => c.text); }
    else if (track && track.segments) { lang = track.lang; texts = track.segments.map((s) => s.text); }
    if (!texts.length) return null;
    let seg;
    try { seg = new Intl.Segmenter(lang || undefined, { granularity: "word" }); } catch { seg = new Intl.Segmenter(undefined, { granularity: "word" }); }
    const words = [];
    for (const t of texts) for (const x of seg.segment(String(t || ""))) if (dsIsWord(x)) words.push(dsCleanWord(x.segment));
    const st = DS_KNOWN.stats(words, lang);
    return { ...st, lang, mine: DS_KNOWN.count(lang) };
  } catch { return null; }
}

// Le prossime frasi già tradotte dopo quella mostrata (per allineare più frasi in una sola richiesta)
function dsUpcomingLines(cur, n) {
  const out = [];
  if (!cur) return out;
  if (cur.live && live && live.cues) {
    for (const c of live.cues) {
      if (out.length >= n) break;
      if (c.start > cur.start && !c.removed && c.trans && c.trans !== "…" && !c.quick) out.push({ text: c.text, trans: c.trans, lang: liveSourceLang() });
    }
  } else if (track && track.segments) {
    track.segments.forEach((sg, i) => {
      if (out.length < n && sg.start > cur.start && segTrans[i]) out.push({ text: sg.text, trans: segTrans[i], lang: track.lang });
    });
  }
  return out;
}

// Per i sottotitoli creati dall'audio la modalità riga per riga di YouTube non esiste: uso Google
function liveEngine() {
  const e = engine();
  return e.E.kind === "youtube" ? { id: "google", E: C.ENGINES.google, key: "", model: "", localUrl: "" } : e;
}

// Chi corregge la trascrizione quando si traduce con Google o DeepL: Gemini se hai la chiave,
// altrimenti Groq (la chiave è la stessa della trascrizione). Con un modello per tradurre, la correzione
// si fa già nella stessa richiesta della traduzione e questo non serve.
function cleanerEngine() {
  if (!settings || settings.cleanTranscript === false) return null;
  const e = liveEngine();
  if (e.E.kind === "openai" || e.E.kind === "claude") return null;
  // nell'ordine scelto nel popup («Ordine dei servizi»): il primo modello pronto
  for (const id of C.engineOrder(settings)) {
    const E = C.ENGINES[id];
    if (!E || (E.kind !== "openai" && E.kind !== "claude") || dsIsBlocked(id)) continue;
    const x = engineById(id);
    if (dsReady(x)) return x;
  }
  return null;
}

function signature(s) {
  const e = engine(s);
  return JSON.stringify([e.id, e.key, e.model, e.E.local ? e.localUrl : "", s.targetLang]);
}

(async () => {
  settings = await loadSettings();
  lastSignature = signature(settings);
  applyStyle();
})();
if (DS_IS_YT && window === window.top) setStatus("Attiva su YouTube: apri un video e premi CC.");

chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area === "local" && !("keys" in changes)) return; // stato e cache: ignora
  const prev = settings;
  settings = await loadSettings();
  applyStyle();
  if (prev && prev.enabled !== false && settings.enabled === false) dsOnDisable();
  if (prev && prev.enabled === false && settings.enabled !== false) dsOnEnable();
  if (prev && !!prev.liveAhead !== !!settings.liveAhead && typeof aheadSettingChanged === "function") aheadSettingChanged(!!settings.liveAhead);
  if (prev && (prev.transcribeMode !== settings.transcribeMode || prev.fullMaxMin !== settings.fullMaxMin)) {
    const v = currentVideoId();
    if (v && getVideo() && !live.modes[v] && hasCaptions[v] === false) liveApplyDefault(v);
  }
  const sig = signature(settings);
  if (sig !== lastSignature) {
    lastSignature = sig;
    if (track) startTranslation();
    liveRetranslate();
  }
});

// ---------- Messaggi dalla pagina ----------
window.addEventListener("message", (e) => {
  if (e.origin !== location.origin || typeof e.data !== "string" || !e.data.startsWith('{"__dualsub":"page"')) return;
  let m;
  try { m = JSON.parse(e.data); } catch { return; }
  if (m.type === "track") onTrack(m);
  else if (m.type === "captionsInfo") onCaptionsInfo(m);
  else if (m.type === "error") setStatus(m.text);
  else if (m.type === "ytResult") {
    const p = pending.get(m.id);
    if (!p) return;
    pending.delete(m.id);
    m.error ? p.reject(new Error(m.error)) : p.resolve(m.events);
  }
});

// ---------- Messaggi dal popup e dalla pagina "Trascrizione e traduzione" ----------
// In una scheda possono esserci più video (per esempio il lettore del sito e un riquadro di YouTube).
// Ogni parte della pagina con un video ha un suo contrassegno: alle domande risponde per prima quella
// con la trascrizione o con il video in riproduzione, e i comandi arrivano solo a quella.
const DS_FRAME = Math.random().toString(36).slice(2) + Date.now().toString(36);

function dsRelevance() {
  const v = getVideo();
  if (!v) return -1;
  if (live.running || live.fullBusy || (live.cues.length && live.videoId === currentVideoId()) || track) return 0;
  if (!v.paused) return 1;
  return 2;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !settings) return false;
  const rel = dsRelevance();
  if (rel < 0) return false;
  // comando indirizzato a un'altra parte della pagina
  if (msg.target && msg.target !== DS_FRAME) return false;
  // comando senza destinatario: lo esegue solo un video attivo, non quelli fermi
  const isQuery = msg.type === "liveState" || msg.type === "getTranscript" || msg.type === "getLiveLog";
  if (!isQuery && !msg.target && rel > 1) return false;

  const reply = (r) => { try { sendResponse(r && typeof r === "object" ? { ...r, frame: DS_FRAME } : r); } catch {} };
  const answer = (fn) => { setTimeout(() => reply(fn()), [0, 150, 450][rel]); return true; };

  if (msg.type === "liveState") return answer(() => ({ ...liveState(), disabled: dsSiteDisabled(), host: location.hostname, comp: dsComprehension() }));
  if (msg.type === "getTranscript") return answer(() => dsTranscript());
  if (msg.type === "getLiveLog") return answer(() => ({ log: dsLiveLogBuf.join("\n"), url: location.href, ahead: typeof aheadInfo === "function" ? aheadInfo() : null }));
  if (msg.type === "live") {
    const v = currentVideoId();
    if (msg.action === "start") liveManualStart(v);
    else if (msg.action === "full") liveFull();
    else {
      live.fullGen++; live.fullBusy = false; liveStop("Trascrizione fermata.");
      // video con i suoi sottotitoli: fermandola tornano quelli del sito, anche le volte dopo
      if (v && hasCaptions[v] && live.modes[v] === "live") liveSetMode(v, "").catch(() => {});
    }
    setTimeout(() => reply(liveState()), 50);
    return true;
  }
  if (msg.type === "setMode") {
    const v = currentVideoId();
    liveSetMode(v, msg.mode).then(() => {
      if (msg.mode === "full") liveFull();
      else if (msg.mode === "live") { if (!live.running) liveStart(true); }
      else if (msg.mode === "off") { live.fullGen++; live.fullBusy = false; liveStop("Trascrizione spenta per questo video."); }
      else if (!msg.mode && hasCaptions[v] !== true) liveApplyDefault(v);
      reply(liveState());
    });
    return true;
  }
  if (msg.type === "setTranscript") { reply({ ok: liveSetTranscript(msg) }); return false; }
  if (msg.type === "fixCue") { fixDo(msg.action, msg.start, msg.text, msg.trans).then(reply); return true; }
  if (msg.type === "manualTrans") {
    fixSaveMany(currentVideoId(), msg.items || []).then((n) => { setStatus(`Traduzione incollata: ${n} frasi.`); reply({ ok: true, n }); })
      .catch((e) => reply({ ok: false, error: String(e.message || e) }));
    return true;
  }
  if (msg.type === "loadSubs") {
    const events = dsParseSubs(msg.text);
    if (!events.length) { reply({ ok: false, error: "nel file non ho trovato sottotitoli validi (.srt o .vtt)" }); return false; }
    onTrack({ videoId: currentVideoId(), lang: msg.lang || "", kind: "file", baseUrl: null, events });
    reply({ ok: true, count: events.length });
    return false;
  }
  if (msg.type === "redo") {
    if (msg.what === "translation" && track && !liveActive()) {
      DS_EXT.storage.local.remove(cacheKey(track, trackEngine())).then(() => startTranslation());
    } else liveRedo(msg.what);
    reply({ ok: true });
    return false;
  }
  return false;
});

async function dsSetVideoEngine(v, id) {
  if (!v) return;
  const r = await DS_EXT.storage.local.get({ videoEngine: {} });
  const m = r.videoEngine || {};
  if (id) m[v] = id; else delete m[v];
  const ks = Object.keys(m);
  for (const k of ks.slice(0, Math.max(0, ks.length - 300))) delete m[k];
  dsVideoEngine = m;
  await DS_EXT.storage.local.set({ videoEngine: m });
}
// ⚑ → "Tutta la traduzione di questo video è sbagliata": cancella quella salvata e la rifà (con Google, se chiesto)
async function dsRedoWholeTranslation(engineId) {
  const v = currentVideoId();
  if (track && !liveActive()) {
    const before = cacheKey(track, trackEngine());
    if (engineId !== undefined) await dsSetVideoEngine(v, engineId);
    await DS_EXT.storage.local.remove([before, cacheKey(track, trackEngine())]);
    segTrans = new Array(track.segments.length).fill(null);
    transCues = [];
    startTranslation();
  } else {
    if (engineId !== undefined) await dsSetVideoEngine(v, engineId);
    await liveRedo("translation");
  }
  const name = engine().E.label.split(" (")[0];
  setStatus(`Rifaccio tutta la traduzione di questo video con ${name}.`);
}

// Trascrizione completa (con traduzioni) di quello che si sta guardando
function liveActive() {
  const v = currentVideoId();
  return live.videoId === v && live.cues.length > 0 && (live.running || live.full || !track || liveChosen(v));
}

function dsTranscript() {
  const r = dsTranscriptRaw();
  const v = currentVideoId();
  r.cues = (r.cues || []).map((c) => { const f = fixApply(v, c.start, c.text, c.trans); return f.gone ? null : { ...c, text: f.text, trans: f.trans, fixed: !!f.fixed }; }).filter(Boolean);
  return r;
}

function dsTranscriptRaw() {
  const m = getVideo();
  const base = {
    ok: true, title: document.title.replace(/\s*-\s*YouTube\s*$/, ""), url: location.href, mediaId: currentVideoId(),
    src: dsMediaSrc(), direct: dsIsDirectMedia(), duration: m && isFinite(m.duration) ? m.duration * 1000 : 0,
    live: dsIsLiveStream(m),
    target: settings.targetLang, running: live.running
  };
  if (liveActive() || (!track && live.cues.length)) {
    return { ...base, source: "whisper", lang: liveSourceLang(), full: live.full,
      cues: live.cues.filter((c) => !c.removed).map((c) => ({ start: c.start, end: c.end, text: c.text, trans: c.trans || "" })) };
  }
  if (track) {
    const lineMode = trackEngine().E.kind === "youtube";
    const cues = lineMode
      ? track.cues.map((c, i) => ({ start: c.start, end: c.end, text: c.text, trans: transCues.length === track.cues.length ? transCues[i].text : "" }))
      : track.segments.map((sg, i) => ({ start: sg.start, end: sg.end, text: sg.text, trans: segTrans[i] || "" }));
    return { ...base, source: track.kind === "file" ? "file" : DS_IS_YT ? "youtube" : "track", lang: track.lang, full: true, cues };
  }
  return { ...base, source: "", lang: "", full: false, cues: [] };
}

function fetchYT(url) {
  return new Promise((resolve, reject) => {
    const id = ++reqId;
    pending.set(id, { resolve, reject });
    toPage({ type: "fetchYT", id, url });
    setTimeout(() => {
      if (pending.has(id)) { pending.delete(id); reject(new Error("tempo scaduto")); }
    }, 20000);
  });
}

function trackEngine() {
  const e = engine();
  return e.E.kind === "youtube" && !(track && track.baseUrl) ? GOOGLE_ENGINE : e;
}

async function onTrack(m) {
  if (!settings) settings = await loadSettings();
  const isAsr = m.kind === "asr";
  const cues = DualSubs.parseCues(m.events);
  const segments = DualSubs.segment(DualSubs.buildUnits(m.events, isAsr), m.lang);
  if (!cues.length) { setStatus("Questa traccia di sottotitoli è vuota."); return; }
  track = { videoId: m.videoId, lang: m.lang, kind: m.kind, baseUrl: m.baseUrl, cues, segments };
  // i sottotitoli automatici di YouTube sono nella lingua dell'audio: la trascrizione (se la chiedi) resta in quella lingua
  if (isAsr && m.lang && m.videoId) dsAsrInfo[m.videoId] = { lang: String(m.lang).split("-")[0].toLowerCase(), segments };
  const what = m.kind === "file" ? "Sottotitoli caricati dal file" : DS_IS_YT ? "Sottotitoli trovati" : "Sottotitoli del video trovati";
  setStatus(`${what}${m.lang ? ` (${m.lang}${isAsr ? ", automatici" : ""})` : ""}: ${segments.length} frasi.`);
  startTranslation();
}

async function onCaptionsInfo(m) {
  if (m.embedded) {
    const before = currentVideoId();
    dsYtReportedId = m.videoId;
    if (before && before !== m.videoId && /^live_stream/.test(before)) {
      if (live.videoId === before) { live.videoId = m.videoId; live.loadedFor = m.videoId; }
      if (live.autoTried === before) live.autoTried = m.videoId;
    }
  }
  if (m.live) dsYtLive[m.videoId] = true;
  hasCaptions[m.videoId] = m.has;
  if (m.videoId !== currentVideoId()) return;
  if (!settings) settings = await loadSettings();
  if (live.running || live.fullBusy) return;
  // video con sottotitoli: si trascrive solo se l'hai scelto tu per questo video
  if (m.has && !liveChosen(m.videoId)) return;
  liveAutoStart(m.videoId);
}

function reset() {
  job++;
  track = null;
  transCues = [];
  segTrans = [];
  translating = false;
  toPage({ type: "reset" });
  liveReset();
}
document.addEventListener("yt-navigate-start", reset);

// ---------- Richiesta di traduzione con attesa sui limiti dei servizi gratuiti ----------
async function askTranslate(e, texts, before, after, stillValid, progress = "", source = "", clean = false, priority = false) {
  const name = e.E.label.split(" (")[0];
  for (let waits = 0; ; waits++) {
    let resp;
    try {
      resp = await DS_EXT.runtime.sendMessage({
        type: "translate", engine: e.id, target: settings.targetLang, source, clean, priority,
        texts, before, after, key: e.key, model: e.model, localUrl: e.localUrl
      });
    } catch (err) {
      resp = { error: String(err.message || err) };
    }
    if (!stillValid()) return null;
    if (resp && resp.rateLimited && !resp.daily && waits >= 6) resp.daily = true;   // non si sblocca: passo a un altro servizio
    if (resp && resp.rateLimited && !resp.daily && waits < 6) {
      const secs = Math.min(Math.max(resp.retryAfter || 0, 10 * (waits + 1)), 90);
      for (let s = secs; s > 0; s--) {
        if (!stillValid()) return null;
        setStatus(`${name}: limite di richieste raggiunto, riprovo tra ${s} s…${progress}`);
        await sleep(1000);
      }
      continue;
    }
    return resp || { error: "nessuna risposta" };
  }
}

// ---------- Traduzione dei sottotitoli di YouTube ----------
function makeChunks(segments, E) {
  const { count, chars: maxChars } = E.chunk;
  const chunks = [];
  let cur = [], chars = 0;
  segments.forEach((s, i) => {
    if (cur.length && (cur.length >= count || chars + s.text.length > maxChars)) {
      chunks.push(cur); cur = []; chars = 0;
    }
    cur.push(i);
    chars += s.text.length + 1;
  });
  if (cur.length) chunks.push(cur);
  return chunks;
}

// Prima il pezzo che stai guardando, poi il seguito, poi quello già passato
function orderFromNow(chunks, segments) {
  const video = getVideo();
  const t = video ? video.currentTime * 1000 : 0;
  let k = chunks.findIndex((ch) => segments[ch[ch.length - 1]].showEnd > t);
  if (k < 0) k = 0;
  return [...chunks.slice(k), ...chunks.slice(0, k)];
}

const cacheKey = (t, e) => `cache:${t.videoId}|${t.lang}|${t.kind}|${settings.targetLang}|${e.id}|${e.model}`;

async function saveCache(key, value) {
  const { cacheIndex = [] } = await DS_EXT.storage.local.get({ cacheIndex: [] });
  const index = cacheIndex.filter((k) => k !== key);
  index.push(key);
  const drop = index.length > 80 ? index.splice(0, index.length - 80) : [];
  if (drop.length) await DS_EXT.storage.local.remove(drop);
  await DS_EXT.storage.local.set({ [key]: value, cacheIndex: index });
}

const GOOGLE_ENGINE = { id: "google", E: C.ENGINES.google, key: "", model: "", localUrl: "" };
const DAILY_MSG = (name) =>
  `${name} ha esaurito le richieste gratuite di oggi (si azzerano verso le 9 del mattino, ora italiana). ` +
  `Intanto traduco con Google Traduttore. Consiglio: nel popup scegli un modello Flash-Lite, che ne ha molte di più.`;

async function startTranslation() {
  const my = ++job;
  if (settings && settings.enabled === false) { transCues = []; segTrans = track ? new Array(track.segments.length).fill(null) : []; translating = false; return; }
  const t = track;
  const chosen = trackEngine();
  const e = dsUsable(chosen);
  const { E } = e;
  const name = E.label.split(" (")[0];
  if (e !== chosen) setStatus(`${chosen.E.label.split(" (")[0]} ha finito le richieste gratuite di oggi: traduco con ${name}.`);
  const valid = () => my === job;
  transCues = [];
  segTrans = new Array(t.segments.length).fill(null);
  translating = false;

  if (baseLang(t.lang) === baseLang(settings.targetLang)) {
    setStatus("Il video è già nella lingua scelta: mostro solo l'originale.");
    return;
  }

  if (E.kind === "youtube" && t.baseUrl) {
    try {
      const u = new URL(t.baseUrl);
      u.searchParams.set("tlang", settings.targetLang);
      translating = true;
      const ev = await fetchYT(u.toString());
      if (!valid()) return;
      transCues = DualSubs.parseCues(ev);
      const tgt = String(settings.targetLang || "").split("-")[0];
      const bad = transCues.filter((c) => DualSubs.wrongLang(c.text, tgt)).length;
      if (transCues.length && bad > transCues.length * 0.4) {
        // YouTube ha dato la traduzione in un'altra lingua o alfabeto: per questo video traduco con Google
        transCues = [];
        await dsSetVideoEngine(currentVideoId(), "google");
        setStatus("La traduzione di YouTube di questo video era nella lingua sbagliata: traduco con Google Traduttore.");
        translating = false;
        if (valid()) startTranslation();
        return;
      }
      setStatus(transCues.length ? "Traduzione pronta (YouTube, riga per riga)." : "YouTube non offre la traduzione per questa traccia.");
    } catch (err) {
      if (valid()) setStatus("Errore dalla traduzione di YouTube: " + err.message);
    } finally {
      if (valid()) translating = false;
    }
    return;
  }

  if (E.needsKey && !e.key) { setStatus(`Per usare ${name} inserisci la chiave nel popup.`); return; }
  if (E.kind === "openai" && !e.model) { setStatus(`Per usare ${name} scegli un modello nel popup ("Carica modelli").`); return; }

  // La traduzione di questo video è salvata pezzo per pezzo: se l'avevi già guardato (anche solo in parte)
  // riparto da lì e chiedo al servizio solo le frasi che mancano
  const ck = cacheKey(t, e);
  const done = new Array(t.segments.length).fill(null); // solo le traduzioni fatte dal servizio scelto
  if (E.cache) {
    await dsCopyOkReady;      // frasi brevi già controllate (nomi): servono per decidere quali traduzioni salvate rifare
    const saved = (await DS_EXT.storage.local.get(ck))[ck];
    if (!valid()) return;
    if (Array.isArray(saved) && saved.length === done.length) {
      saved.forEach((x, i) => {
        if (typeof x === "string" && !dsBadSaved(t.segments[i].text, x)) { done[i] = x; segTrans[i] = x; }
      });
    }
  }
  const missing = () => done.map((x, i) => (x == null ? i : -1)).filter((i) => i >= 0);
  if (!missing().length) {
    setStatus(`Traduzione già salvata per questo video (${name}): nessuna richiesta necessaria.`);
    return;
  }
  const reused = done.length - missing().length;

  translating = true;
  let cur = e, fallback = false;
  let queue = orderFromNow(makeChunks(t.segments, E).map((ch) => ch.filter((i) => done[i] == null)).filter((ch) => ch.length), t.segments);
  let count = reused;
  const total = segTrans.length;
  const prefix = reused ? `${reused} frasi già salvate. ` : "";

  while (queue.length) {
    const ch = queue.shift();
    const first = ch[0], last = ch[ch.length - 1];
    const curName = cur.E.label.split(" (")[0];
    const resp = await askTranslate(
      cur,
      ch.map((i) => t.segments[i].text),
      t.segments.slice(Math.max(0, first - 4), first).map((s) => s.text),
      t.segments.slice(last + 1, last + 3).map((s) => s.text),
      valid,
      ` (${count}/${total} frasi)`,
      t.lang
    );
    if (!resp) return;
    if (resp.daily && !fallback) {
      dsMarkBlocked(cur.id);
      const next = dsNextEngine(cur.id);
      const left = [ch, ...queue].flat();
      if (next) {
        // un altro servizio con la chiave: continuo con quello (le sue traduzioni vengono salvate come le altre)
        setStatus(`${curName} ha finito le richieste gratuite di oggi: continuo con ${next.E.label.split(" (")[0]}.`);
        cur = next;
        queue = makeChunks(left.map((i) => t.segments[i]), next.E).map((c) => c.map((k) => left[k]));
        continue;
      }
      // Nessun servizio di riserva: continuo con Google per le frasi che mancano, senza salvarle come "fatte da Gemini"
      fallback = true;
      cur = GOOGLE_ENGINE;
      setStatus(DAILY_MSG(curName));
      queue = makeChunks(left.map((i) => t.segments[i]), C.ENGINES.google).map((c) => c.map((k) => left[k]));
      continue;
    }
    if (resp.error && (resp.fatal || cur.id === "google")) {
      // chiave sbagliata, modello inesistente, o anche Google non risponde: inutile continuare
      translating = false;
      setStatus("Errore di traduzione: " + resp.error);
      return;
    }
    // Risposta incompleta o illeggibile: divido il blocco e riprovo; se è già piccolo, quel pezzo lo fa Google
    if ((resp.error && ch.length > 3) || (resp.misaligned && ch.length > 1)) {
      const mid = Math.ceil(ch.length / 2);
      queue.unshift(ch.slice(0, mid), ch.slice(mid));
      continue;
    }
    let result = resp;
    let byGoogle = false;
    if (resp.error) {
      setStatus(`${curName}: ${resp.error}. Questo pezzo lo traduco con Google e vado avanti.`);
      result = await askTranslate(GOOGLE_ENGINE, ch.map((i) => t.segments[i].text), [], [], valid, "", t.lang);
      if (!result) return;
      if (result.error) { translating = false; setStatus("Errore di traduzione: " + result.error); return; }
      byGoogle = true;
    }
    const echoed = [];
    const tgt = settings.targetLang;
    ch.forEach((i, k) => {
      const src = t.segments[i].text, tr = result.translations[k] || "";
      if (!byGoogle && !fallback && cur.id !== "google" && (dsIsEcho(src, tr) || dsUncheckedCopy(src, tr, tgt))) { echoed.push(i); return; }
      segTrans[i] = dsIsEcho(src, tr) ? "" : tr;
      if (tr && dsIsCopy(src, tr) && (byGoogle || cur.id === "google")) dsMarkCopyOk(src, tgt);
      if (!fallback && !byGoogle) done[i] = segTrans[i];
    });
    // Frasi che il modello ha solo ricopiato (anche quelle di una o due parole): le traduce Google.
    // Se anche Google la lascia uguale è un nome ("Karen", "Okay"): resta così, segnata come controllata e salvata.
    if (echoed.length) {
      const g = await askTranslate(GOOGLE_ENGINE, echoed.map((i) => t.segments[i].text), [], [], valid, "", t.lang);
      if (!g) return;
      echoed.forEach((i, k) => {
        const src = t.segments[i].text, tr = (g.translations || [])[k] || "";
        segTrans[i] = dsIsEcho(src, tr) ? "" : tr;
        if (!tr || dsIsEcho(src, tr)) return;
        if (dsIsCopy(src, tr)) dsMarkCopyOk(src, tgt);
        // frase breve ricopiata dal modello: la traduzione di Google si salva, così non si richiede di nuovo
        if (!fallback && dsWords(src).length <= 2) done[i] = tr;
      });
    }
    count += ch.length;
    if (!fallback) {
      setStatus(`${prefix}Traduzione (${cur.E.label.split(" (")[0]}): ${count}/${total} frasi.`);
      if (E.cache) saveCache(ck, done).catch(() => {});
    }
  }

  translating = false;
  if (!fallback) setStatus(`Traduzione completata (${name}).${reused ? ` ${reused} frasi erano già salvate.` : ""}`);
  else setStatus(DAILY_MSG(name).replace("Intanto traduco", "Il resto è stato tradotto"));
}

// ---------- Pulsante per accendere/spegnere i sottotitoli doppi, dentro il lettore ----------
// YouTube: nella barra dei comandi, accanto al pulsante dei sottotitoli. Altri siti: piccolo pulsante in alto a destra del video.
let dsToggleBtn = null, dsToggleAt = 0;
function dsToggleUpdate(player, show, v) {
  if (!player) return;
  const now = Date.now();
  const want = DS_IS_YT || track || live.cues.length || live.running || live.fullBusy || settings.enabled === false;
  if (!want) { if (dsToggleBtn) dsToggleBtn.hidden = true; return; }
  if (!dsToggleBtn || !dsToggleBtn.isConnected || now - dsToggleAt > 1000) {
    dsToggleAt = now;
    const home = DS_IS_YT ? player.querySelector(".ytp-right-controls") : player;
    if (!home) return;
    if (!dsToggleBtn) {
      dsToggleBtn = document.createElement("button");
      dsToggleBtn.type = "button";
      dsToggleBtn.append(Object.assign(document.createElement("span"), { className: "dualsub-toggle-label", textContent: "DS" }));
      dsToggleBtn.addEventListener("click", (e) => { e.stopPropagation(); e.preventDefault(); dsToggleClick(); });
      for (const t of ["mousedown", "mouseup", "dblclick"]) dsToggleBtn.addEventListener(t, (e) => e.stopPropagation());
    }
    dsToggleBtn.className = "dualsub-toggle" + (DS_IS_YT ? " ytp-button" : " dualsub-toggle-float");
    if (dsToggleBtn.parentNode !== home) home.prepend(dsToggleBtn);
  }
  dsToggleBtn.hidden = false;
  const on = settings.enabled !== false && show;
  if (dsToggleBtn.classList.contains("on") !== on) {
    dsToggleBtn.classList.toggle("on", on);
    dsToggleBtn.setAttribute("aria-pressed", String(on));
    dsToggleBtn.title = on ? "Sottotitoli Doppi: spegni" : "Sottotitoli Doppi: accendi";
  }
}

// Spento: nascondo e fermo la trascrizione (così non consuma la quota). Acceso: faccio ripartire quello che serve.
async function dsToggleClick() {
  const v = currentVideoId();
  const showing = !!(overlay && !overlay.hidden);
  if (showing) {
    await DS_EXT.storage.sync.set({ enabled: false });
    return;
  }
  if (settings.enabled === false) await DS_EXT.storage.sync.set({ enabled: true });   // il resto lo fa dsOnEnable
  else dsOnEnable(v);
}

function dsOnEnable(v = currentVideoId()) {
  if (!v) return;
  setStatus("Sottotitoli doppi accesi.");
  if (DS_IS_YT && hasCaptions[v] !== false && !liveChosen(v)) {
    // i sottotitoli di YouTube: li accendo (servono per avere il testo); se il testo si era perso, li faccio richiedere di nuovo
    const cc = document.querySelector("#movie_player .ytp-subtitles-button");
    if (cc && cc.getAttribute("aria-pressed") !== "true") cc.click();
    else if (cc && !track) {
      // il testo dei sottotitoli non è arrivato: una volta sola spengo e riaccendo i CC per farlo richiedere,
      // poi basta (prima ogni clic su DS li faceva lampeggiare senza risultato)
      if (Date.now() - dsCcRetryAt < 20000) { setStatus("YouTube non manda il testo dei sottotitoli a Sottotitoli Doppi: ricarica la pagina (F5). Succede di solito dopo aver aggiornato l'estensione."); return; }
      dsCcRetryAt = Date.now();
      cc.click(); setTimeout(() => cc.click(), 400);
      setTimeout(() => { if (!track && currentVideoId() === v) setStatus("YouTube non manda il testo dei sottotitoli: ricarica la pagina (F5), oppure chiedi la trascrizione dal popup."); }, 5000);
    }
    else if (track && !translating && segTrans.every((x) => x == null)) startTranslation();
    return;
  }
  if (track && !liveChosen(v)) { if (!translating && segTrans.every((x) => x == null)) startTranslation(); return; }
  if (!live.running && !live.fullBusy) liveManualStart(v);
}

function dsOnDisable() {
  if (live.running) liveStop("Sottotitoli doppi spenti: la trascrizione è in pausa. Per riaccenderli usa il pulsante DS nel lettore.");
  else setStatus("Sottotitoli doppi spenti. Per riaccenderli usa il pulsante DS nel lettore.");
}

// ---------- Overlay sul video ----------
const DS_FONTS = {
  default: '"YouTube Noto", Roboto, Arial, sans-serif',
  sans: 'system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif',
  serif: 'Georgia, "Times New Roman", serif',
  mono: 'ui-monospace, "Cascadia Mono", Consolas, monospace',
  rounded: '"Trebuchet MS", "Comic Sans MS", Verdana, sans-serif'
};

function applyStyle() {
  if (!overlay || !settings) return;
  const st = overlay.style;
  st.setProperty("--dualsub-size", settings.fontSize + "px");
  st.setProperty("--dualsub-trans-scale", (settings.transScale || 90) / 100);
  st.setProperty("--dualsub-orig-color", settings.origColor || "#ffffff");
  st.setProperty("--dualsub-trans-color", settings.transColor || "#f5c84b");
  st.setProperty("--dualsub-bg", `rgba(8, 8, 8, ${Math.max(0, Math.min(1, Number(settings.bgOpacity)))})`);
  st.setProperty("--dualsub-lift", (Number(settings.subPos) || 0) + "px");
  st.setProperty("--dualsub-font", DS_FONTS[settings.subFont] || DS_FONTS.default);
  st.setProperty("--dualsub-roman", Math.max(0.3, Math.min(1.2, (Number(settings.romanSize) || 65) / 100)) + "em");
  st.setProperty("--dualsub-romanline", Math.max(0.3, Math.min(1.5, (Number(settings.romanLineSize) || 80) / 100)));
  overlay.dataset.show = settings.subShow || "both";
  overlay.classList.toggle("dualsub-trans-first", !!settings.transFirst);
}

function ensureOverlay() {
  const player = dsPlayerBox();
  if (!player) return null;
  if (overlay && player.contains(overlay)) return player;
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.className = "dualsub-overlay";
    lineOrig = document.createElement("div");
    lineOrig.className = "dualsub-line dualsub-orig";
    lineTrans = document.createElement("div");
    lineTrans.className = "dualsub-line dualsub-trans";
    const fixBtn = document.createElement("button");
    fixBtn.className = "dualsub-fixbtn";
    fixBtn.textContent = "⚑";
    fixBtn.title = "Frase sbagliata? Ritraduci, ritrascrivi o correggi a mano";
    fixBtn.addEventListener("click", () => fixOpenCard(fixBtn));
    const copyBtn = document.createElement("button");
    copyBtn.className = "dualsub-fixbtn dualsub-copybtn";
    copyBtn.textContent = "⧉";
    copyBtn.title = "Copia la frase o aprila in Google Traduttore, DeepL, Reverso";
    copyBtn.addEventListener("click", () => wordsOpenLineCard(copyBtn));
    const langBtn = document.createElement("button");
    langBtn.className = "dualsub-fixbtn dualsub-langbtn";
    langBtn.addEventListener("click", (e) => { e.stopPropagation(); fixLangOpen(langBtn); });
    overlay.append(lineOrig, lineTrans, fixBtn, copyBtn, langBtn, wordsRomanButton(), wordsBackButton(), aheadButton());
    wordsSetup();
    if (typeof DS_UI !== "undefined") DS_UI.watch(overlay);   // interfaccia nella lingua di «Traduci in», se scelta
  }
  player.appendChild(overlay);
  wordsOrigKey = "";
  wordsTransKey = "";
  applyStyle();
  return player;
}

function setText(el, text) {
  if (el.textContent !== text) el.textContent = text;
}

// Fuori da YouTube: sottotitoli già presenti nel video, e trascrizione automatica dei file aperti direttamente
let dsTrackRead = { id: null, count: 0, at: 0 };
function genericTick(video, v) {
  if (!v) return;
  if (hasCaptions[v] === undefined && video.readyState >= 1) hasCaptions[v] = dsTextTracks(video).length > 0;
  if (hasCaptions[v] && (!track || track.kind !== "file") && Date.now() - dsTrackRead.at > 3000) {
    dsTrackRead.at = Date.now();
    const got = dsReadTextTrack(video);
    if (got && (dsTrackRead.id !== v || got.count > dsTrackRead.count * 1.2)) {
      dsTrackRead = { id: v, count: got.count, at: Date.now() };
      onTrack({ videoId: v, lang: got.lang, kind: "track", baseUrl: null, events: got.events });
    }
  }
  // Parto da solo solo per il video "vero" della pagina: file diretto, oppure un video che suona,
  // non muto, grande e lungo almeno 30 secondi (così non spreco quote su anteprime e pubblicità)
  if (hasCaptions[v] === false && !video.paused && !live.running && !live.fullBusy && live.autoTried !== v) {
    const mainVideo = dsIsDirectMedia() || (!video.muted && video.volume > 0 &&
      (video.duration === Infinity || video.duration >= 30) && (video.tagName === "AUDIO" || dsArea(video) >= 400 * 225));
    if (mainVideo) { live.autoTried = v; liveAutoStart(v); }
  }
}

let dsYtPlayMs = 0, dsYtPlayLast = 0, dsYtPlayId = null;
function ytFallbackTick(video, v) {
  if (dsYtPlayId !== v) { dsYtPlayId = v; dsYtPlayMs = 0; }
  const now = Date.now();
  if (!video.paused && dsYtPlayLast) dsYtPlayMs += Math.min(1000, now - dsYtPlayLast);
  dsYtPlayLast = now;
  if (hasCaptions[v] !== undefined || track || live.running || live.fullBusy || live.autoTried === v) return;
  if (dsYtPlayMs > 12000 && !video.muted) {
    live.autoTried = v;
    hasCaptions[v] = false;
    liveAutoStart(v);
  }
}

function tick() {
  if (!settings) return;
  if (!DS_IS_YT && !dsAnyMedia()) { if (overlay) overlay.hidden = true; return; }
  if (dsSiteDisabled()) { if (overlay) overlay.hidden = true; document.documentElement.classList.remove("dualsub-hide-native"); return; }
  const player = ensureOverlay();
  const video = getVideo();

  const currentV = currentVideoId();
  if (currentV && dsFixVid !== currentV) fixLoad(currentV);
  if (track && currentV && currentV !== track.videoId) reset();
  if (live.videoId && currentV !== live.videoId) liveReset();
  if (!DS_IS_YT && video) genericTick(video, currentV);
  if (DS_IS_YT && video && currentV) ytFallbackTick(video, currentV);

  const liveOn = liveActive();
  if (liveOn) liveWatchdog();
  const fullWait = live.fullBusy && live.videoId === currentV;
  // trascrizione partita ma ancora nessuna frase (per esempio lingua sbagliata): il riquadro c'è, vuoto, con il
  // pulsante della lingua per correggerla
  const liveWaiting = live.running && live.videoId === currentV && !live.cues.length;
  const show = !!(settings.enabled && video && player && (liveOn || fullWait || liveWaiting || (track && dsCaptionsOn())));
  dsToggleUpdate(player, show, currentV);

  document.documentElement.classList.toggle("dualsub-hide-native", show && settings.hideNative);
  if (show && settings.hideNative && !DS_IS_YT) dsHideNativeTracks(video);
  if (!overlay) return;
  overlay.hidden = !show;
  if (!show) { wordsCurrent = null; return; }

  const t = video.currentTime * 1000;
  wordsTick(t, video);

  // Se la scheda di una parola è aperta, la frase resta ferma finché non la chiudi
  if (wordsCardState) {
    if (wordsCurrent) wordsRenderOriginal(wordsCurrent.text, wordsCurrent.lang); // aggiorna i colori delle parole salvate
    return;
  }

  let cur = null;
  if (liveOn) {
    const c = liveFind(t);
    if (c) cur = { text: c.text, trans: c.trans != null ? c.trans : "…", quick: c.quick, start: c.start, end: c.end, lang: liveSourceLang(), live: true };
  } else if (track && trackEngine().E.kind === "youtube") {
    const text = DualSubs.activeText(track.cues, t);
    if (text) {
      const c = track.cues.find((x) => x.start <= t && t < x.end) || { start: t, end: t + 3000 };
      cur = { text, trans: DualSubs.activeText(transCues, t), start: c.start, end: c.end, lang: track.lang };
    }
  } else if (track) {
    const i = DualSubs.findSegment(track.segments, t);
    if (i >= 0) {
      const sg = track.segments[i];
      const tr = segTrans[i];
      cur = { text: sg.text, trans: tr != null ? tr : (translating ? "…" : ""), start: sg.start, end: sg.end, lang: track.lang };
    }
  }

  if (cur) {
    const f = fixApply(currentV, cur.start, cur.text, cur.trans);
    if (f.gone) cur = null;
    else if (f.fixed || f.chat) { cur.text = f.text; cur.trans = f.trans; cur.quick = false; }
  }
  wordsCurrent = cur;
  overlay.classList.toggle("dualsub-has-line", !!cur);
  wordsRenderOriginal(cur ? cur.text : "", cur ? cur.lang : "");
  wordsRomanButtonUpdate();
  wordsBackButtonUpdate();
  aheadButtonUpdate();
  const lb = overlay.querySelector(".dualsub-langbtn");
  if (lb) {
    // anche senza frasi sullo schermo, mentre si trascrive: se Whisper sente la lingua sbagliata i pezzi vengono
    // scartati e non compare niente, e proprio allora serve poter scegliere la lingua giusta
    const transcribing = live.running && live.videoId === currentV;
    lb.hidden = !((cur && cur.live) || transcribing);
    lb.classList.toggle("dualsub-show", !cur && transcribing);
    const code = (liveSourceLang() || "?").split("-")[0].toUpperCase();
    if (lb.textContent !== code) { lb.textContent = code; lb.title = `Lingua della trascrizione: ${dsLangName(liveSourceLang() || "") || "automatica"}. Clic per cambiarla se è sbagliata`; }
  }
  if (cur && cur.trans && cur.trans !== "…") wordsRenderTrans(cur.trans);
  else { wordsTransKey = ""; setText(lineTrans, cur ? cur.trans : fullWait ? "⏳ " + live.fullText : ""); }
  lineTrans.classList.toggle("dualsub-quick", !!(cur && cur.quick));
}

setInterval(tick, 100);

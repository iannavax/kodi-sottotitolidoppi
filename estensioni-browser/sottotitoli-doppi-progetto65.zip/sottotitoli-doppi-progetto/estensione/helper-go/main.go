// Sottotitoli Doppi - programma di appoggio per yt-dlp (2.0: scritto in Go, un solo file eseguibile: NON serve Python).
// Il browser lo avvia da solo (messaggistica nativa) quando l'estensione chiede di trascrivere un video intero: scarica solo
// l'audio con yt-dlp e lo passa all'estensione a pezzi. Non tiene niente: il file scaricato viene cancellato subito.
// Per le dirette in anticipo legge l'audio con yt-dlp + ffmpeg e lo manda un secondo alla volta.
package main

import (
	"bufio"
	"bytes"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

const version = "2.1"
const chunkSize = 600 * 1024 // il browser accetta messaggi fino a 1 MB: 600 KB diventano ~800 KB in base64
const updateEvery = 3 * 86400 * time.Second

var here = func() string {
	if p, err := os.Executable(); err == nil {
		if r, err2 := filepath.EvalSymlinks(p); err2 == nil {
			p = r
		}
		return filepath.Dir(p)
	}
	return "."
}()
var isWin = runtime.GOOS == "windows"

type msg = map[string]interface{}

// ---------- Messaggi con il browser ----------
var stdin = bufio.NewReaderSize(os.Stdin, 1<<20)
var sendLock sync.Mutex

func readMsg() msg {
	var head [4]byte
	if _, err := io.ReadFull(stdin, head[:]); err != nil {
		return nil
	}
	n := binary.LittleEndian.Uint32(head[:])
	buf := make([]byte, n)
	if _, err := io.ReadFull(stdin, buf); err != nil {
		return nil
	}
	var m msg
	if json.Unmarshal(buf, &m) != nil {
		return msg{}
	}
	return m
}

func send(m msg) {
	data, err := json.Marshal(m)
	if err != nil {
		return
	}
	sendLock.Lock() // la diretta manda l'audio da un altro filo: un messaggio alla volta
	defer sendLock.Unlock()
	var head [4]byte
	binary.LittleEndian.PutUint32(head[:], uint32(len(data)))
	os.Stdout.Write(head[:])
	os.Stdout.Write(data)
}

func str(m msg, k string) string {
	if v, ok := m[k].(string); ok {
		return v
	}
	return ""
}

// ---------- Strumenti ----------
func findTool(names ...string) string {
	for _, n := range names {
		p := filepath.Join(here, n)
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			return p
		}
	}
	for _, n := range names {
		if p, err := exec.LookPath(n); err == nil {
			return p
		}
	}
	return ""
}

func ytdlpPath() string {
	if v := os.Getenv("SD_YTDLP"); v != "" {
		return v
	}
	if isWin {
		return findTool("yt-dlp.exe")
	}
	return findTool("yt-dlp_macos", "yt-dlp_linux", "yt-dlp")
}

func denoPath() string {
	if v := os.Getenv("SD_DENO"); v != "" {
		return v
	}
	n := "deno"
	if isWin {
		n = "deno.exe"
	}
	if p := findTool(n); p != "" {
		return p
	}
	if h, err := os.UserHomeDir(); err == nil {
		p := filepath.Join(h, ".deno", "bin", "deno")
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	return ""
}

func ffmpegPath() string {
	if v := os.Getenv("SD_FFMPEG"); v != "" {
		return v
	}
	if isWin {
		return findTool("ffmpeg.exe")
	}
	return findTool("ffmpeg")
}

func utf8Env() []string { return append(os.Environ(), "PYTHONIOENCODING=utf-8", "PYTHONUTF8=1") }

// i programmi avviati da qui non ricevono lo stdin del programma di appoggio (è il canale con il browser)
func runCmd(timeout time.Duration, name string, args ...string) (string, error) {
	c := exec.Command(name, args...)
	setupProc(c)
	var out bytes.Buffer
	c.Stdout = &out
	if err := c.Start(); err != nil {
		return "", err
	}
	done := make(chan error, 1)
	go func() { done <- c.Wait() }()
	select {
	case err := <-done:
		return out.String(), err
	case <-time.After(timeout):
		killTree(c)
		return out.String(), errors.New("timeout")
	}
}

func ytdlpVersion(y string) string {
	out, _ := runCmd(30*time.Second, y, "--version")
	return strings.TrimSpace(out)
}

func maybeUpdate(y string) {
	stamp := filepath.Join(here, ".last-update")
	if st, err := os.Stat(stamp); err == nil && time.Since(st.ModTime()) < updateEvery {
		return
	}
	if f, err := os.Create(stamp); err == nil {
		f.Close()
	}
	send(msg{"type": "status", "text": "Aggiorno yt-dlp…"})
	runCmd(120*time.Second, y, "-U")
}

func firefoxProfileExists() bool {
	var base string
	switch runtime.GOOS {
	case "windows":
		base = filepath.Join(os.Getenv("APPDATA"), "Mozilla", "Firefox", "Profiles")
	case "darwin":
		h, _ := os.UserHomeDir()
		base = filepath.Join(h, "Library", "Application Support", "Firefox", "Profiles")
	default:
		h, _ := os.UserHomeDir()
		base = filepath.Join(h, ".mozilla", "firefox")
	}
	st, err := os.Stat(base)
	return err == nil && st.IsDir()
}

// ---------- Download dell'audio ----------
// Prima l'audio più leggero adatto al parlato (opus), così il file resta piccolo;
// se il sito non separa l'audio, il video più piccolo disponibile.
const formatAudio = "ba[acodec^=opus][abr<=90]/ba[acodec^=opus]/ba[ext=m4a]/ba/wv*+wa/w"

type dlResult struct {
	code int
	path string
	meta map[string]interface{}
	err  string
	tmp  string
}

var rePct = regexp.MustCompile(`([\d.]+)%`)

func download(u string, cookies bool) dlResult {
	y := ytdlpPath()
	tmp, _ := os.MkdirTemp("", "sd-")
	args := []string{"--no-playlist", "--no-part", "--no-mtime", "--newline", "--no-simulate",
		"-f", formatAudio, "--max-filesize", "600M",
		"-o", filepath.Join(tmp, "audio.%(ext)s"),
		"--progress-template", "download:SDPROG %(progress._percent_str)s",
		"--print", "before_dl:SDMETA %(duration)s|%(ext)s|%(title)s",
		"--print", "after_move:SDFILE %(filepath)s"}
	if d := denoPath(); d != "" {
		args = append(args, "--js-runtimes", "deno:"+d)
	}
	if cookies {
		args = append(args, "--cookies-from-browser", "firefox")
	}
	args = append(args, u)
	c := exec.Command(y, args...)
	setupProc(c)
	c.Env = utf8Env()
	stdout, _ := c.StdoutPipe()
	var errBuf bytes.Buffer
	var errMu sync.Mutex
	stderr, _ := c.StderrPipe()
	if err := c.Start(); err != nil {
		return dlResult{code: 1, meta: map[string]interface{}{}, err: err.Error(), tmp: tmp}
	}
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		b, _ := io.ReadAll(stderr)
		errMu.Lock()
		errBuf.Write(b)
		errMu.Unlock()
	}()
	meta := map[string]interface{}{}
	filepathOut := ""
	last := -1
	sc := bufio.NewScanner(stdout)
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		switch {
		case strings.HasPrefix(line, "SDPROG"):
			if m := rePct.FindStringSubmatch(line); m != nil {
				f, _ := strconv.ParseFloat(m[1], 64)
				if pct := int(f); pct != last {
					last = pct
					send(msg{"type": "progress", "pct": pct})
				}
			}
		case strings.HasPrefix(line, "SDMETA"):
			parts := strings.SplitN(strings.TrimSpace(line[min(7, len(line)):]), "|", 3)
			for len(parts) < 3 {
				parts = append(parts, "")
			}
			d, err := strconv.ParseFloat(parts[0], 64)
			if err != nil {
				d = 0
			}
			meta["duration"], meta["ext"], meta["title"] = d, parts[1], parts[2]
			send(msg{"type": "status", "text": "Scarico l'audio…"})
		case strings.HasPrefix(line, "SDFILE"):
			filepathOut = strings.TrimSpace(line[min(7, len(line)):])
		}
	}
	wg.Wait()
	werr := c.Wait()
	code := 0
	if werr != nil {
		code = 1
	}
	if filepathOut == "" || !isFile(filepathOut) {
		// yt-dlp a volte non stampa il percorso: lo cerco nella cartella temporanea
		filepathOut = ""
		if es, err := os.ReadDir(tmp); err == nil && len(es) > 0 {
			filepathOut = filepath.Join(tmp, es[0].Name())
		}
	}
	errMu.Lock()
	defer errMu.Unlock()
	return dlResult{code: code, path: filepathOut, meta: meta, err: errBuf.String(), tmp: tmp}
}

func isFile(p string) bool {
	st, err := os.Stat(p)
	return err == nil && !st.IsDir()
}

var (
	reBot       = regexp.MustCompile(`(?i)Sign in to confirm|not a bot`)
	rePrivate   = regexp.MustCompile(`(?i)Private video|members-only|This video is private`)
	reForbidden = regexp.MustCompile(`(?i)HTTP Error 403|403: Forbidden|Forbidden`)
	reUnsup     = regexp.MustCompile(`(?i)Unsupported URL`)
	reBig       = regexp.MustCompile(`(?i)max-filesize|larger than max`)
	reJS        = regexp.MustCompile(`(?i)JavaScript runtime|jsc|challenge`)
)

func friendlyError(e string) (string, string) {
	switch {
	case reBot.MatchString(e):
		return "bot", "YouTube chiede di confermare che non sei un robot: apri il video da Firefox con l'account YouTube, oppure riprova più tardi."
	case rePrivate.MatchString(e):
		return "private", "Il video è privato o riservato agli abbonati del canale."
	case reForbidden.MatchString(e):
		return "forbidden", "YouTube rifiuta di far leggere la diretta (errore 403). Di solito si risolve aggiornando yt-dlp (lo fa da solo una volta al giorno) o riprovando tra poco."
	case reUnsup.MatchString(e):
		return "unsupported", "yt-dlp non sa scaricare da questo sito."
	case reBig.MatchString(e):
		return "toobig", "Il file è troppo grande (oltre 600 MB)."
	case reJS.MatchString(e):
		return "js", "yt-dlp non riesce a risolvere i controlli di YouTube: serve Deno aggiornato (rilancia l'installatore)."
	}
	var lines []string
	for _, l := range strings.Split(strings.TrimSpace(e), "\n") {
		if strings.Contains(l, "ERROR") {
			lines = append(lines, l)
		}
	}
	if len(lines) == 0 {
		all := strings.Split(strings.TrimSpace(e), "\n")
		if len(all) > 0 && all[len(all)-1] != "" {
			lines = all[len(all)-1:]
		}
	}
	txt := "yt-dlp non è riuscito a scaricare l'audio."
	if len(lines) > 0 {
		txt = lines[len(lines)-1]
	}
	return "failed", truncate(txt, 300)
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) > n {
		return string(r[:n])
	}
	return s
}

func cmdAudio(m msg) {
	y := ytdlpPath()
	if y == "" {
		send(msg{"type": "error", "code": "noytdlp", "message": "yt-dlp non è installato: rilancia l'installatore."})
		return
	}
	maybeUpdate(y)
	send(msg{"type": "status", "text": "Cerco l'audio del video…"})
	r := download(str(m, "url"), false)
	if r.path == "" && reBot.MatchString(r.err) && firefoxProfileExists() {
		send(msg{"type": "status", "text": "YouTube chiede una conferma: riprovo con i cookie di Firefox…"})
		os.RemoveAll(r.tmp)
		r = download(str(m, "url"), true)
	}
	defer os.RemoveAll(r.tmp)
	if r.path == "" {
		c, t := friendlyError(r.err)
		send(msg{"type": "error", "code": c, "message": t})
		return
	}
	st, _ := os.Stat(r.path)
	ext := strings.TrimPrefix(filepath.Ext(r.path), ".")
	if ext == "" {
		if e, ok := r.meta["ext"].(string); ok {
			ext = e
		}
	}
	title, _ := r.meta["title"].(string)
	dur, _ := r.meta["duration"].(float64)
	send(msg{"type": "meta", "size": st.Size(), "ext": ext, "title": title, "duration": dur})
	f, err := os.Open(r.path)
	if err != nil {
		send(msg{"type": "error", "code": "failed", "message": err.Error()})
		return
	}
	defer f.Close()
	seq := 0
	buf := make([]byte, chunkSize)
	for {
		n, err := io.ReadFull(f, buf)
		if n > 0 {
			send(msg{"type": "chunk", "seq": seq, "data": base64.StdEncoding.EncodeToString(buf[:n])})
			seq++
		}
		if err != nil {
			break
		}
	}
	send(msg{"type": "done", "chunks": seq})
}

// ---------- Diretta in anticipo ----------
// yt-dlp legge la diretta dal punto più recente e ffmpeg la trasforma in audio semplice (16 kHz, mono): l'estensione
// riceve un secondo alla volta, lo trascrive e mostra i sottotitoli quando il video (tenuto qualche secondo indietro)
// arriva lì. Niente viene salvato su disco. Si ferma quando l'estensione chiude il collegamento o manda "stop".
const liveFormat = "ba/91/92/93/w"

type stopper struct {
	ch   chan struct{}
	once sync.Once
}

func newStopper() *stopper { return &stopper{ch: make(chan struct{})} }
func (s *stopper) stop()   { s.once.Do(func() { close(s.ch) }) }
func (s *stopper) set() bool {
	select {
	case <-s.ch:
		return true
	default:
		return false
	}
}

// aspetta d, oppure fino allo stop: true se è stato fermato
func (s *stopper) wait(d time.Duration) bool {
	select {
	case <-s.ch:
		return true
	case <-time.After(d):
		return false
	}
}

var live = struct {
	sync.Mutex
	stop  *stopper
	procs []*exec.Cmd
}{}

func liveStop() {
	live.Lock()
	s, ps := live.stop, live.procs
	live.procs = nil
	live.Unlock()
	if s != nil {
		s.stop()
	}
	for _, p := range ps {
		killTree(p)
	}
}

func setProcs(ps ...*exec.Cmd) {
	live.Lock()
	live.procs = ps
	live.Unlock()
}

// ultime righe scritte da un programma (stderr in un file temporaneo condiviso con il programma stesso)
func tail(f *os.File, n int) string {
	if f == nil {
		return ""
	}
	b, err := os.ReadFile(f.Name())
	if err != nil {
		return ""
	}
	var lines []string
	for _, l := range strings.Split(string(b), "\n") {
		if l = strings.TrimSpace(l); l != "" {
			lines = append(lines, l)
		}
	}
	if len(lines) > n {
		lines = lines[len(lines)-n:]
	}
	return truncate(strings.Join(lines, " | "), 300)
}

func killAll(ps []*exec.Cmd) {
	for _, p := range ps {
		killTree(p)
	}
}

func tempFile() *os.File {
	f, err := os.CreateTemp("", "sd-err-")
	if err != nil {
		return nil
	}
	return f
}

func dropTemp(f *os.File) {
	if f != nil {
		f.Close()
		os.Remove(f.Name())
	}
}

// legge l'audio (16 kHz mono s16le) da ff e lo manda all'estensione, un secondo alla volta. Se per giveUp secondi non
// arriva niente ferma i programmi; a sayAt secondi dice cosa sta succedendo. Restituisce (pezzi mandati, posizione).
func pump(ff io.Reader, procs []*exec.Cmd, errf *os.File, stop *stopper, label string, pos0 int, sayAt, giveUp float64) (int, int) {
	started := time.Now()
	var mu sync.Mutex
	sent, done := 0, false
	go func() {
		said := false
		for !stop.set() {
			time.Sleep(2 * time.Second)
			mu.Lock()
			s, d := sent, done
			mu.Unlock()
			if s > 0 || stop.set() || d {
				return
			}
			waited := time.Since(started).Seconds()
			if waited > sayAt && !said {
				said = true
				last := tail(errf, 3)
				txt := fmt.Sprintf("Diretta: %s non manda ancora l'audio (%d s)", label, int(waited))
				if last != "" {
					txt += ": " + last
				} else {
					txt += ", nessun messaggio"
				}
				send(msg{"type": "status", "text": txt + "."})
			}
			if waited > giveUp {
				killAll(procs)
				return
			}
		}
	}()
	pos := pos0
	block := make([]byte, 32000) // un secondo di audio
	for !stop.set() {
		n, err := io.ReadFull(ff, block)
		if n == 0 {
			break
		}
		mu.Lock()
		first := sent == 0
		mu.Unlock()
		if first {
			txt := "Diretta: leggo l'audio in anticipo"
			if label != "yt-dlp" {
				txt += " (" + label + ")"
			}
			send(msg{"type": "status", "text": txt + "."})
		}
		send(msg{"type": "pcm", "pos": pos, "rate": 16000, "data": base64.StdEncoding.EncodeToString(block[:n])})
		pos += n / 2
		mu.Lock()
		sent++
		mu.Unlock()
		if err != nil {
			break
		}
	}
	mu.Lock()
	done = true
	s := sent
	mu.Unlock()
	killAll(procs)
	return s, pos
}

func ytdlpBase(cookies bool) []string {
	cmd := []string{ytdlpPath(), "--no-playlist"}
	if d := denoPath(); d != "" {
		cmd = append(cmd, "--js-runtimes", "deno:"+d)
	}
	if cookies {
		cmd = append(cmd, "--cookies-from-browser", "firefox")
	}
	return cmd
}

var ffPCM = []string{"-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "pipe:1"}

var reBW = regexp.MustCompile(`BANDWIDTH=(\d+)`)

// dalla playlist principale HLS di YouTube la variante più leggera (basta l'audio): meno dati da scaricare
func hlsVariant(hls string) (string, string) {
	body, _, err := httpGet(hls, 15*time.Second, false)
	if err != nil {
		return "", "playlist HLS non leggibile: " + err.Error()
	}
	text := string(body)
	if !strings.Contains(text, "#EXT-X-STREAM-INF") {
		return hls, ""
	}
	best, bw := "", -1
	lines := strings.Split(text, "\n")
	for i, l := range lines {
		if !strings.HasPrefix(l, "#EXT-X-STREAM-INF") {
			continue
		}
		m := reBW.FindStringSubmatch(l)
		nxt := ""
		for _, x := range lines[i+1:] {
			x = strings.TrimSpace(x)
			if x != "" && !strings.HasPrefix(x, "#") {
				nxt = x
				break
			}
		}
		if nxt != "" {
			b := -1
			if m != nil {
				b, _ = strconv.Atoi(m[1])
			}
			if bw == -1 || (m != nil && b < bw) {
				best = nxt
				if m != nil {
					bw = b
				}
			}
		}
	}
	if best != "" && !strings.HasPrefix(best, "http") {
		best = urlJoin(hls, best)
	}
	if best == "" {
		best = hls
	}
	return best, ""
}

func urlJoin(base, ref string) string {
	b, err := url.Parse(base)
	if err != nil {
		return ref
	}
	r, err := b.Parse(ref)
	if err != nil {
		return ref
	}
	return r.String()
}

func ffmpegLive(src string, stop *stopper, label string, sayAt, giveUp float64) (int, string) {
	f := ffmpegPath()
	errf := tempFile()
	defer dropTemp(errf)
	args := []string{"-hide_banner", "-loglevel", "warning"}
	if strings.HasPrefix(src, "file:") {
		args = append(args, "-re")
	}
	args = append(args, "-i", src)
	args = append(args, ffPCM...)
	c := exec.Command(f, args...)
	setupProc(c)
	c.Stderr = errf
	out, _ := c.StdoutPipe()
	if err := c.Start(); err != nil {
		return 0, label + ": " + err.Error()
	}
	setProcs(c)
	sent, _ := pump(out, []*exec.Cmd{c}, errf, stop, label, 0, sayAt, giveUp)
	c.Wait()
	t := tail(errf, 3)
	if t == "" {
		t = "nessun messaggio"
	}
	return sent, label + ": " + t
}

var backlogS = func() float64 {
	if v, err := strconv.ParseFloat(os.Getenv("SD_BACKLOG_S"), 64); err == nil && v > 0 {
		return v
	}
	return 120 // secondi di diretta già passati da leggere all'inizio
}()

const hlsUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36"

var httpClient = &http.Client{}

func httpGet(u string, timeout time.Duration, yt bool) ([]byte, string, error) {
	if strings.HasPrefix(u, "file:") {
		p := strings.TrimPrefix(strings.TrimPrefix(u, "file://"), "file:")
		if isWin && len(p) > 2 && p[0] == '/' && p[2] == ':' {
			p = p[1:]
		}
		b, err := os.ReadFile(p)
		return b, "", err
	}
	req, err := http.NewRequest("GET", u, nil)
	if err != nil {
		return nil, "", err
	}
	req.Header.Set("User-Agent", hlsUA)
	if yt {
		req.Header.Set("Origin", "https://www.youtube.com")
		req.Header.Set("Referer", "https://www.youtube.com/")
	}
	cl := &http.Client{Timeout: timeout, Transport: httpClient.Transport}
	resp, err := cl.Do(req)
	if err != nil {
		return nil, "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, "", fmt.Errorf("HTTP Error %d: %s", resp.StatusCode, http.StatusText(resp.StatusCode))
	}
	b, err := io.ReadAll(resp.Body)
	return b, resp.Header.Get("Content-Type"), err
}

// Legge la playlist HLS della diretta e i suoi pezzi e li passa a ffmpeg (stdin).
// 1.5 dava l'indirizzo direttamente a ffmpeg, ma le versioni nuove di ffmpeg rifiutano le playlist di YouTube
// («Invalid data found when processing input»): così ffmpeg vede solo l'audio/video.
func hlsFeed(src string, out io.WriteCloser, stop *stopper, note func(string)) {
	defer out.Close()
	last, fails, initDone := -1, 0, false
	haveLast := false
	got, refused := 0, 0 // pezzi arrivati / rifiutati (403) prima del primo arrivato
	for !stop.set() {
		body, ctype, err := httpGet(src, 15*time.Second, true)
		if err != nil {
			fails++
			note("playlist: " + err.Error())
			if fails >= 4 {
				return
			}
			time.Sleep(2 * time.Second)
			continue
		}
		fails = 0
		text := string(body)
		if !strings.HasPrefix(strings.TrimLeft(text, " \t\r\n"), "#EXTM3U") {
			if ctype == "" {
				ctype = "tipo sconosciuto"
			}
			note(fmt.Sprintf("la playlist non è HLS (%s): %q", ctype, truncate(text, 80)))
			return
		}
		seq, target, ended := 0, 4.0, false
		type segT struct {
			n   int
			uri string
		}
		var segs []segT
		initURI := ""
		reURI := regexp.MustCompile(`URI="([^"]+)"`)
		for _, l := range strings.Split(text, "\n") {
			l = strings.TrimSpace(l)
			switch {
			case strings.HasPrefix(l, "#EXT-X-MEDIA-SEQUENCE:"):
				digits := regexp.MustCompile(`\D`).ReplaceAllString(strings.SplitN(l, ":", 2)[1], "")
				seq, _ = strconv.Atoi(digits)
			case strings.HasPrefix(l, "#EXT-X-TARGETDURATION:"):
				if v, err := strconv.ParseFloat(strings.SplitN(l, ":", 2)[1], 64); err == nil {
					target = v
				}
			case strings.HasPrefix(l, "#EXT-X-MAP:"):
				if m := reURI.FindStringSubmatch(l); m != nil {
					initURI = m[1]
				}
			case strings.HasPrefix(l, "#EXT-X-ENDLIST"):
				ended = true
			case l != "" && !strings.HasPrefix(l, "#"):
				segs = append(segs, segT{seq + len(segs), l})
			}
		}
		if len(segs) == 0 {
			note("la playlist non ha pezzi")
			return
		}
		if !haveLast {
			// si parte fino a 2 minuti prima della fine della playlist (YouTube è già indietro rispetto al punto più recente)
			back := int(backlogS/maxf(1.0, target) + 0.5)
			if back < 3 {
				back = 3
			}
			i := len(segs) - back
			if i < 0 {
				i = 0
			}
			last = segs[i].n - 1
			haveLast = true
		}
		if initURI != "" && !initDone {
			if b, _, err := httpGet(urlJoin(src, initURI), 15*time.Second, true); err == nil {
				out.Write(b)
			}
			initDone = true
		}
		for _, s := range segs {
			if stop.set() {
				return
			}
			if s.n <= last {
				continue
			}
			data, _, err := httpGet(urlJoin(src, s.uri), 30*time.Second, true)
			if err != nil {
				note(fmt.Sprintf("pezzo %d: %s", s.n, err.Error()))
				last = s.n
				// YouTube rifiuta i pezzi (403): inutile aspettare, mi fermo subito e si passa alla strada successiva
				if got == 0 && strings.Contains(err.Error(), "403") {
					refused++
					if refused >= 3 {
						note("YouTube rifiuta i pezzi di questo indirizzo (403)")
						return
					}
				}
				continue
			}
			got++
			if _, werr := out.Write(data); werr != nil {
				return // ffmpeg chiuso
			}
			last = s.n
		}
		if ended {
			return
		}
		w := target / 2
		if w > 5 {
			w = 5
		}
		if w < 1 {
			w = 1
		}
		stop.wait(time.Duration(w * float64(time.Second)))
	}
}

func maxf(a, b float64) float64 {
	if a > b {
		return a
	}
	return b
}

// Piano 0/B: scarico la diretta HLS io, ffmpeg tira fuori solo l'audio
func hlsLive(src string, stop *stopper, label string, sayAt, giveUp float64) (int, string) {
	f := ffmpegPath()
	errf := tempFile()
	defer dropTemp(errf)
	args := append([]string{"-hide_banner", "-loglevel", "warning", "-i", "pipe:0"}, ffPCM...)
	c := exec.Command(f, args...)
	setupProc(c)
	c.Stderr = errf
	in, _ := c.StdinPipe()
	out, _ := c.StdoutPipe()
	if err := c.Start(); err != nil {
		return 0, label + ": " + err.Error()
	}
	setProcs(c)
	note := func(t string) {
		if errf != nil {
			errf.WriteString(t + "\n")
		}
	}
	go hlsFeed(src, in, stop, note)
	sent, _ := pump(out, []*exec.Cmd{c}, errf, stop, label, 0, sayAt, giveUp)
	c.Wait()
	t := tail(errf, 3)
	if t == "" {
		t = "nessun messaggio"
	}
	return sent, label + ": " + t
}

// l'indirizzo della diretta dato da «yt-dlp -g» (lento la prima volta: 10-30 s) resta ricordato per qualche ora
var liveURLs = filepath.Join(here, "live-urls.json")
var gTimeout = func() time.Duration {
	if v, err := strconv.ParseFloat(os.Getenv("SD_G_TIMEOUT"), 64); err == nil && v > 0 {
		return time.Duration(v * float64(time.Second))
	}
	return 60 * time.Second
}()

func loadLiveURLs() map[string][]interface{} {
	d := map[string][]interface{}{}
	if b, err := os.ReadFile(liveURLs); err == nil {
		json.Unmarshal(b, &d)
	}
	return d
}

func liveURLCached(u string) string {
	if x, ok := loadLiveURLs()[u]; ok && len(x) == 2 {
		h, _ := x[0].(string)
		at, _ := x[1].(float64)
		if float64(time.Now().Unix())-at < 4*3600 {
			return h
		}
	}
	return ""
}

func liveURLSave(u, hls string) {
	d := loadLiveURLs()
	now := float64(time.Now().Unix())
	for k, v := range d {
		if len(v) != 2 {
			delete(d, k)
			continue
		}
		if at, _ := v[1].(float64); now-at >= 4*3600 {
			delete(d, k)
		}
	}
	if hls != "" {
		d[u] = []interface{}{hls, now}
	} else {
		delete(d, u)
	}
	if b, err := json.Marshal(d); err == nil {
		os.WriteFile(liveURLs, b, 0o644)
	}
}

type gBox struct {
	sync.Mutex
	hls, err, last string
	done           chan struct{}
}

// «yt-dlp -g» in un filo a parte (parte subito, insieme al piano 0): mette in box l'indirizzo o l'errore. Al massimo gTimeout.
func ytdlpG(u string, cookies bool, box *gBox) {
	defer close(box.done)
	var lines []string
	var lmu sync.Mutex
	base := ytdlpBase(cookies)
	args := append(base[1:], "-v", "-g", "-f", "ba/91/92/93/94/95/96/b", u)
	c := exec.Command(base[0], args...)
	setupProc(c)
	c.Env = utf8Env()
	so, _ := c.StdoutPipe()
	se, _ := c.StderrPipe()
	if err := c.Start(); err != nil {
		box.Lock()
		box.err = "yt-dlp -g: " + err.Error()
		box.Unlock()
		return
	}
	var out []string
	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		sc := bufio.NewScanner(se)
		sc.Buffer(make([]byte, 1<<20), 1<<20)
		for sc.Scan() {
			l := strings.TrimSpace(sc.Text())
			if l != "" {
				lmu.Lock()
				lines = append(lines, l)
				lmu.Unlock()
				box.Lock()
				box.last = truncate(l, 200)
				box.Unlock()
			}
		}
	}()
	go func() {
		defer wg.Done()
		sc := bufio.NewScanner(so)
		sc.Buffer(make([]byte, 1<<20), 1<<20)
		for sc.Scan() {
			lmu.Lock()
			out = append(out, strings.TrimSpace(sc.Text()))
			lmu.Unlock()
		}
	}()
	waited := make(chan struct{})
	go func() { c.Wait(); close(waited) }()
	select {
	case <-waited:
	case <-time.After(gTimeout):
		killTree(c)
		box.Lock()
		last := box.last
		if last == "" {
			last = "nessuna"
		}
		box.err = fmt.Sprintf("yt-dlp -g: nessuna risposta in %d s (ultima riga: %s)", int(gTimeout.Seconds()), last)
		box.Unlock()
		<-waited
	}
	wg.Wait()
	reAddr := regexp.MustCompile(`^(https?|file):`)
	lmu.Lock()
	defer lmu.Unlock()
	for _, l := range out {
		if reAddr.MatchString(l) {
			box.Lock()
			box.hls = l
			box.Unlock()
			break
		}
	}
	box.Lock()
	defer box.Unlock()
	if box.hls == "" && box.err == "" {
		var errs []string
		for _, l := range lines {
			if strings.Contains(l, "ERROR") {
				errs = append(errs, l)
			}
		}
		if len(errs) == 0 && len(lines) > 0 {
			errs = lines[len(lines)-1:]
		}
		t := "nessun indirizzo"
		if len(errs) > 0 {
			t = errs[len(errs)-1]
		}
		box.err = "yt-dlp -g: " + truncate(t, 200)
	}
}

func (b *gBox) get() (string, string, string) {
	b.Lock()
	defer b.Unlock()
	return b.hls, b.err, b.last
}

// Ordine: piano 0 (indirizzo HLS del lettore, si ferma subito se YouTube rifiuta i pezzi con 403), piano B (indirizzo dato
// da yt-dlp -g, letto da noi), piano A (yt-dlp scarica e passa a ffmpeg).
func liveRun(u string, cookies bool, stop *stopper, hls string) (int, string) {
	f := ffmpegPath()
	var msgs []string
	// yt-dlp -g parte subito, insieme al piano 0 (se l'indirizzo non è già ricordato)
	var gbox *gBox
	startG := func() {
		gbox = &gBox{done: make(chan struct{})}
		go ytdlpG(u, cookies, gbox)
	}
	if liveURLCached(u) == "" || cookies {
		startG()
	}
	// --- piano 0
	if hls != "" && !cookies {
		send(msg{"type": "status", "text": "Diretta: leggo l'audio con ffmpeg dall'indirizzo del lettore di YouTube…"})
		src, why := hls, ""
		if !strings.HasPrefix(hls, "file:") {
			src, why = hlsVariant(hls)
		}
		if src != "" {
			var sent int
			var m string
			if strings.HasPrefix(src, "file:") {
				sent, m = ffmpegLive(src, stop, "indirizzo del lettore", 10, 25)
			} else {
				sent, m = hlsLive(src, stop, "indirizzo del lettore", 10, 25)
			}
			if sent > 0 || stop.set() {
				return sent, m
			}
			msgs = append(msgs, m)
		} else {
			msgs = append(msgs, why)
		}
		send(msg{"type": "status", "text": "Diretta: l'indirizzo del lettore non dà audio, provo con yt-dlp…"})
	}
	// --- piano B
	for attempt := 1; attempt <= 2; attempt++ {
		hlsB := ""
		if attempt == 1 && !cookies {
			hlsB = liveURLCached(u)
		}
		if hlsB == "" {
			if gbox == nil {
				startG()
			}
			t0 := time.Now()
			said := 0
		wait:
			for {
				select {
				case <-gbox.done:
					break wait
				case <-time.After(time.Second):
				}
				if stop.set() {
					return 0, ""
				}
				n := int(time.Since(t0).Seconds())
				if n >= said+10 {
					said = n
					_, _, last := gbox.get()
					txt := fmt.Sprintf("Diretta: yt-dlp sta ancora cercando l'indirizzo della diretta (%d s; la prima volta può volerci mezzo minuto)…", n)
					if last != "" {
						txt += " Ultima riga: " + last
					}
					send(msg{"type": "status", "text": txt})
				}
			}
			h, e, _ := gbox.get()
			hlsB = h
			if hlsB == "" {
				if e == "" {
					e = "yt-dlp -g: nessun indirizzo"
				}
				msgs = append(msgs, e)
				// yt-dlp vecchio è la causa più comune: lo aggiorno (al massimo ogni 3 giorni) e riprovo una volta
				if attempt == 1 && !cookies {
					maybeUpdate(ytdlpPath())
					gbox = nil
					continue
				}
				break
			}
			liveURLSave(u, hlsB)
		}
		if stop.set() {
			return 0, ""
		}
		send(msg{"type": "status", "text": "Diretta: leggo l'audio dall'indirizzo dato da yt-dlp…"})
		var sent int
		var m string
		if strings.HasPrefix(hlsB, "file:") {
			sent, m = ffmpegLive(hlsB, stop, "indirizzo di yt-dlp", 12, 30)
		} else {
			v, _ := hlsVariant(hlsB)
			if v == "" {
				v = hlsB
			}
			sent, m = hlsLive(v, stop, "indirizzo di yt-dlp", 12, 30)
		}
		if sent > 0 || stop.set() {
			return sent, m
		}
		msgs = append(msgs, m)
		liveURLSave(u, "") // indirizzo scaduto o rifiutato: lo dimentico e (al primo giro) ne chiedo uno nuovo
		gbox = nil
		if attempt == 2 {
			break
		}
	}
	// --- piano A (ultimo): yt-dlp scarica la diretta e la passa a ffmpeg
	send(msg{"type": "status", "text": "Diretta: provo a far scaricare la diretta a yt-dlp…"})
	errY := tempFile()
	defer dropTemp(errY)
	base := ytdlpBase(cookies)
	args := append(base[1:], "-v", "--no-part", "--no-progress", "-f", liveFormat, "-o", "-", "--ffmpeg-location", f, u)
	yt := exec.Command(base[0], args...)
	setupProc(yt)
	yt.Env = utf8Env()
	yt.Stderr = errY
	ytOut, _ := yt.StdoutPipe()
	ff := exec.Command(f, append([]string{"-hide_banner", "-loglevel", "error", "-i", "pipe:0"}, ffPCM...)...)
	setupProc(ff)
	ff.Stdin = ytOut
	ffOut, _ := ff.StdoutPipe()
	if err := yt.Start(); err != nil {
		return 0, strings.Join(append(msgs, "yt-dlp: "+err.Error()), " | ")
	}
	if err := ff.Start(); err != nil {
		killTree(yt)
		return 0, strings.Join(append(msgs, "ffmpeg: "+err.Error()), " | ")
	}
	setProcs(yt, ff)
	sent, _ := pump(ffOut, []*exec.Cmd{yt, ff}, errY, stop, "yt-dlp", 0, 12, 25)
	go yt.Wait()
	go ff.Wait()
	if t := tail(errY, 4); t != "" {
		msgs = append(msgs, t)
	}
	var keep []string
	for _, x := range msgs {
		if x != "" {
			keep = append(keep, x)
		}
	}
	return sent, strings.Join(keep, " | ")
}

func cmdLive(m msg) {
	y, f := ytdlpPath(), ffmpegPath()
	if y == "" {
		send(msg{"type": "error", "code": "noytdlp", "message": "yt-dlp non è installato: rilancia l'installatore."})
		return
	}
	if f == "" {
		send(msg{"type": "error", "code": "noffmpeg", "message": "manca ffmpeg (serve per le dirette sincronizzate): rilancia l'installatore."})
		return
	}
	stop := newStopper()
	live.Lock()
	live.stop = stop
	live.Unlock()
	u, hls := str(m, "url"), str(m, "hls")
	go func() {
		defer func() {
			if r := recover(); r != nil {
				send(msg{"type": "error", "code": "crash", "message": fmt.Sprintf("errore nella lettura della diretta: %v", r)})
			}
		}()
		sent, errS := liveRun(u, false, stop, hls)
		if sent == 0 && !stop.set() && reBot.MatchString(errS) && firefoxProfileExists() {
			send(msg{"type": "status", "text": "YouTube chiede una conferma: riprovo con i cookie di Firefox…"})
			sent, errS = liveRun(u, true, stop, "")
		}
		if stop.set() {
			return
		}
		if sent == 0 {
			c, t := friendlyError(errS)
			send(msg{"type": "error", "code": c, "message": t})
		} else {
			send(msg{"type": "done"})
		}
	}()
}

func main() {
	for {
		m := readMsg()
		if m == nil {
			liveStop() // l'estensione ha chiuso il collegamento: fermo yt-dlp e ffmpeg
			return
		}
		func() {
			defer func() {
				if r := recover(); r != nil {
					send(msg{"type": "error", "code": "crash", "message": fmt.Sprintf("errore del programma di appoggio: %v", r)})
				}
			}()
			switch str(m, "cmd") {
			case "ping":
				y := ytdlpPath()
				yv := ""
				if y != "" {
					yv = ytdlpVersion(y)
				}
				send(msg{"type": "pong", "version": version, "ytdlp": yv, "deno": denoPath() != "", "ffmpeg": ffmpegPath() != "", "platform": platformName()})
			case "audio":
				cmdAudio(m)
			case "live":
				liveStop()
				cmdLive(m)
			case "stop":
				liveStop()
			case "readfile":
				cmdReadFile(m)
			default:
				send(msg{"type": "error", "code": "unknown", "message": "comando sconosciuto"})
			}
		}()
	}
}

// 2.1: un PDF del computer aperto dal gestore dei file (indirizzo file://): Firefox non lascia leggere i file alle estensioni,
// quindi lo legge il programma e lo manda al lettore PDF a pezzi. Solo file .pdf, solo quello chiesto, niente altro.
func filePathFromURL(raw string) (string, error) {
	u, err := url.Parse(raw)
	if err != nil || u.Scheme != "file" {
		return "", errors.New("non è un indirizzo di un file del computer")
	}
	p := u.Path
	if isWin {
		// file:///C:/cartella/doc.pdf → C:\cartella\doc.pdf; file://server/cartella/doc.pdf → \\server\cartella\doc.pdf
		if u.Host != "" && u.Host != "localhost" {
			p = `\\` + u.Host + filepath.FromSlash(p)
		} else {
			p = filepath.FromSlash(strings.TrimPrefix(p, "/"))
		}
	} else if u.Host != "" && u.Host != "localhost" {
		return "", errors.New("file su un altro computer: aprilo con «Apri un PDF»")
	}
	return p, nil
}

func cmdReadFile(m msg) {
	p, err := filePathFromURL(str(m, "url"))
	if err != nil {
		send(msg{"type": "error", "code": "badurl", "message": err.Error()})
		return
	}
	if !strings.EqualFold(filepath.Ext(p), ".pdf") {
		send(msg{"type": "error", "code": "notpdf", "message": "posso aprire solo file PDF"})
		return
	}
	st, err := os.Stat(p)
	if err != nil || !st.Mode().IsRegular() {
		send(msg{"type": "error", "code": "missing", "message": "non trovo il file " + p})
		return
	}
	if st.Size() > 1<<30 {
		send(msg{"type": "error", "code": "toobig", "message": "il PDF è più grande di 1 GB"})
		return
	}
	f, err := os.Open(p)
	if err != nil {
		send(msg{"type": "error", "code": "denied", "message": "non posso leggere il file: " + err.Error()})
		return
	}
	defer f.Close()
	send(msg{"type": "meta", "size": st.Size(), "name": filepath.Base(p)})
	buf := make([]byte, chunkSize)
	seq := 0
	for {
		n, err := io.ReadFull(f, buf)
		if n > 0 {
			send(msg{"type": "chunk", "seq": seq, "data": base64.StdEncoding.EncodeToString(buf[:n])})
			seq++
		}
		if err == io.EOF || err == io.ErrUnexpectedEOF {
			break
		}
		if err != nil {
			send(msg{"type": "error", "code": "failed", "message": err.Error()})
			return
		}
	}
	send(msg{"type": "done", "chunks": seq})
}

// (come sys.platform di Python: win32 / darwin / linux)
func platformName() string {
	switch runtime.GOOS {
	case "windows":
		return "win32"
	default:
		return runtime.GOOS
	}
}

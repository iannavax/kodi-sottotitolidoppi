# 1.5.4: «⇄ Altro modello» nella scheda dei video: la stessa parola spiegata da un altro modello (Ollama dopo Gemini)
import asyncio, os, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
MEAN = "(document.querySelector('.dualsub-card .dualsub-card-meaning')||{}).textContent"
CARD = "(document.querySelector('.dualsub-card')||{}).innerText||''"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        await sw.evaluate("chrome.storage.sync.set({engine:'gemini', models:{local:'gemma4:e4b'}, targetLang:'it', ipa:false, learnExamples:false, learnSpell:false, learnFreq:false, learnLlmExtra:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(2500)
        g0 = len([c for c in log.get("gcalls", []) if c[1] == 200]); o0 = len(log.get("ollama", []))
        await spiega(pg, 4000); await pg.wait_for_timeout(2000)
        g1 = len([c for c in log.get("gcalls", []) if c[1] == 200])
        print("1. con Gemini:", await pg.evaluate(MEAN), "| richieste Gemini:", g1 - g0)
        alt = pg.locator(".dualsub-card .dualsub-altllm")
        print("2. pulsante:", await alt.count(), await alt.first.text_content() if await alt.count() else "")
        await alt.first.click(); await pg.wait_for_timeout(300)
        opts = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dualsub-altllm-row button')].map(b=>b.textContent)")
        print("3. scelte:", opts)
        await pg.locator(".dualsub-card .dualsub-altllm-row button", has_text="Ollama").first.click(); await pg.wait_for_timeout(5000)
        c2 = await pg.evaluate(CARD)
        o1 = len(log.get("ollama", [])) - o0
        print("4. dopo l'altro:", c2.replace("\n", " | ")[:400], "| richieste Ollama:", o1)
        print("   🗂:", "🗂 2" in c2)
        ok = g1 - g0 >= 1 and len(opts) >= 1 and not any(o.endswith("gemini-flash-latest") for o in opts) and o1 >= 1 and "🗂 2" in c2
        print("errori:", errs if ok else errs + ["altro modello non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

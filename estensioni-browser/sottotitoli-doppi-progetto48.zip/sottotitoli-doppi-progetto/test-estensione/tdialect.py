import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:true, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).click(); await pg.wait_for_timeout(4000)
        rows = await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-dialrow')].map(r=>r.innerText.replace(/\\n/g,' '))")
        print("varianti:", rows)
        print("IPA principale:", await pg.evaluate("(document.querySelector('.dualsub-card-ipa')||{}).textContent"))
        print("errori:", errs if len(rows) >= 4 else errs + ["varianti non mostrate"], log["errors"])
        await ctx.close()
asyncio.run(main())

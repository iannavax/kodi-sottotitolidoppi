# PDF ceco come quelli fatti con Word: il testo è in Windows-1250 ma il carattere dice Mac Roman, e i lettori
# mostrano "P·novÈ, vÏËnÈ skeptiËtÌ" invece di "Pánové, věčné skeptičtí". Il titolo è in un altro carattere,
# già giusto (WinAnsi, solo lettere dell'Europa occidentale): non va toccato.
def esc(b): return b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)")
def pdf(path, title, lines):
    body = b"BT /F2 22 Tf 60 740 Td (" + esc(title.encode("cp1252")) + b") Tj ET BT /F1 16 Tf 60 700 Td "
    for i, l in enumerate(lines):
        body += (b"" if i == 0 else b" 0 -26 Td ") + b"(" + esc(l.encode("cp1250")) + b") Tj"
    stream = body + b" ET"
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>",
            b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Times-Roman /Encoding /MacRomanEncoding >>",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"]
    out = b"%PDF-1.4\n"; offs = []
    for i, o in enumerate(objs, 1):
        offs.append(len(out)); out += str(i).encode() + b" 0 obj\n" + o + b"\nendobj\n"
    x = len(out)
    out += b"xref\n0 " + str(len(objs) + 1).encode() + b"\n0000000000 65535 f \n" + b"".join(b"%010d 00000 n \n" % o for o in offs)
    out += b"trailer\n<< /Size " + str(len(objs) + 1).encode() + b" /Root 1 0 R >>\nstartxref\n" + str(x).encode() + b"\n%%EOF\n"
    open(path, "wb").write(out)
pdf("/tmp/doc_mac.pdf", "Blues pro bláznivou holku", ["Pánové,", "věčné skeptičtí a přezíraví,", "kteří své smutky vážete do kytek", "a znáte už život nazpaměť", "jako verše svých kultivovaných přátel"])
print("creato /tmp/doc_mac.pdf")

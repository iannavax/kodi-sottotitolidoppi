# Parole al Volo 1.12: kanji uno per uno nella scheda (learn.js hanBox) e scheda del carattere (volo.js openChar)
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
sys.path.insert(0, "/home/claude/e2e")
from playwright.async_api import async_playwright
import tvolo, charness
EXT = sys.argv[1]
async def handle(route, request):
    if ".wiktionary.org/" in request.url or request.url.startswith("https://jisho.org/") or request.url.startswith("https://kanjiapi.dev/"): return await charness.handle(route, request)
    return await tvolo.handle(route, request)
T = "(s=>(document.querySelector(s)||{}).innerText||'')"
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(800)
        b = await tvolo.hover(pg, "ja", "勉強", 3000)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(2500)
        print("1. riga:", (await pg.evaluate(f"{T}('.pav-card .dsx-hanrow')")).replace("\n", " "))
        await pg.locator(".pav-card .dsx-hanchip", has_text="強").click()
        await pg.wait_for_function("/tratti/.test((document.querySelector('.pav-card .dsx-hanpanel')||{}).innerText||'')", timeout=8000)
        print("2. pannello 強:", (await pg.evaluate(f"{T}('.pav-card .dsx-hanpanel')")).replace("\n", " | "))
        await pg.locator(".pav-card .dsx-btn", has_text="scheda del carattere").click()
        await pg.wait_for_timeout(60)
        print("2b. dopo 60 ms:", (await pg.evaluate(f"{T}('.pav-card .pav-title')")).replace("\n", " "), "|", await pg.evaluate(f"{T}('.pav-card .pav-meaning')"))
        await pg.wait_for_function("/Torna alla parola/.test((document.querySelector('.pav-card')||{}).innerText||'')", timeout=8000)
        await pg.wait_for_function("/tratti/.test((document.querySelector('.pav-card .dsx-hanpanel')||{}).innerText||'')", timeout=8000)
        print("3. scheda del carattere:", (await pg.evaluate(f"{T}('.pav-card .pav-title')")).replace("\n", " "), "| significato:", await pg.evaluate(f"{T}('.pav-card .pav-meaning')"),
              "| riga pulsanti:", await pg.evaluate("!!document.querySelector('.pav-card .dsx-hanrow')"))
        await pg.locator(".pav-card .pav-star").click(); await pg.wait_for_timeout(500)
        print("4. ☆:", await sw.evaluate("chrome.storage.local.get(null).then(r=>JSON.stringify(Object.keys(r).filter(k=>/vocab/i.test(k)).map(k=>JSON.stringify(r[k]).includes('強'))))"))
        await pg.locator(".pav-card .pav-back").click(); await pg.wait_for_timeout(600)
        print("5. tornato:", (await pg.evaluate(f"{T}('.pav-card .pav-title')")).replace("\n", " "), "| riga:", await pg.evaluate("!!document.querySelector('.pav-card .dsx-hanrow')"),
              "| schede aperte:", await pg.evaluate("document.querySelectorAll('.pav-card').length"))
        await pg.locator(".pav-card .dsx-hansave").click()
        await pg.wait_for_function("/tutti salvati/.test((document.querySelector('.pav-card .dsx-hansave')||{}).innerText||'')", timeout=8000)
        print("5b. salva tutti:", await sw.evaluate("chrome.storage.local.get('vocab').then(r=>JSON.stringify(Object.values(r.vocab||{}).map(v=>[v.word,v.pos,v.fromWord||''])))"))
        print("6. modelli:", len(tvolo.log.get("gem", [])) if isinstance(tvolo.log.get("gem"), list) else tvolo.log.get("gem"), "| kanjiapi:", charness.log.get("kanjiapi"))
        # cinese: stessa scheda, letture in pinyin per prime, livelli HSK
        await sw.evaluate("chrome.storage.sync.set({sourceLang:'zh'})"); await pg.keyboard.press("Escape")
        await pg.evaluate("document.getElementById('ja').insertAdjacentHTML('afterend', '<p id=zh lang=zh>我们学习中文。</p>')"); await pg.wait_for_timeout(300)
        b = await tvolo.hover(pg, "zh", "学习", 3000)
        await pg.mouse.dblclick(b["x"], b["y"]); await pg.wait_for_timeout(2500)
        print("7. cinese riga:", (await pg.evaluate(f"{T}('.pav-card .dsx-hanrow')")).replace("\n", " "))
        await pg.locator(".pav-card .dsx-hanchip", has_text="学").first.click()
        await pg.wait_for_function("/tratti/.test((document.querySelector('.pav-card .dsx-hanpanel')||{}).innerText||'')", timeout=8000)
        print("8. pannello 学:", (await pg.evaluate(f"{T}('.pav-card .dsx-hanpanel')")).replace("\n", " | "))
        print("   richiesta:", charness.log.get("hanchar"))
        print("errori:", errs, tvolo.log["errors"], charness.log["errors"])
        await ctx.close()
asyncio.run(main())

# Lettore PDF: PDF ceco con gli accenti staccati (come LaTeX): la scheda deve ricevere la parola giusta ("člověku")
import asyncio, os, sys
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
async def handle(route, request):
    if request.url.split("?")[0].endswith(".pdf"):
        return await route.fulfill(status=200, content_type="application/pdf", body=open("/tmp/doc_cs.pdf", "rb").read())
    return await tvolo.handle(route, request)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, learnExamples:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(f"chrome-extension://{eid}/pdf.html?file=https%3A%2F%2Fexample.test%2Fcs.pdf"); await pg.wait_for_timeout(3000)
        print("1. testo:", await pg.evaluate("document.querySelector('.textLayer').textContent"))
        for w in ("člověku", "může"):
            box = await pg.evaluate("""(w)=>{const t=document.querySelector('.textLayer'); const tw=document.createTreeWalker(t, NodeFilter.SHOW_TEXT); let n;
              while((n=tw.nextNode())){const i=n.nodeValue.indexOf(w); if(i>=0){const r=document.createRange(); r.setStart(n,i+1); r.setEnd(n,i+3); const b=r.getBoundingClientRect(); return {x:b.x+b.width/2, y:b.y+b.height/2};}} return null}""", w)
            await pg.mouse.move(5, 5); await pg.wait_for_timeout(400)
            await pg.mouse.move(box["x"], box["y"], steps=4); await pg.wait_for_timeout(2500)
            print(f"2. scheda su {w}:", (await pg.evaluate("(document.querySelector('.pav-card .pav-word')||{}).textContent||''")), "|", (await pg.evaluate("(document.querySelector('.pav-card .pav-meaning')||{}).textContent||''"))[:40])
            await pg.keyboard.press("Escape")
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

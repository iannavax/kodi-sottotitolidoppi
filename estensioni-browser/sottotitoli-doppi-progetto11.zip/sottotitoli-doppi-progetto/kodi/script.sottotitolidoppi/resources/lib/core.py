# -*- coding: utf-8 -*-
# Sottotitoli Doppi per Kodi - logica principale (senza dipendenze da Kodi, così si può provare anche fuori)
#
# Crea un file di sottotitoli "doppio": in ogni riga l'originale e, sotto, la traduzione colorata.
# L'originale viene da un file di sottotitoli (accanto al video, scaricato con un add-on di Kodi
# o scelto a mano) oppure dalla trascrizione dell'audio con Whisper (serve ffmpeg).
import hashlib
import http.client as httpclient
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

VERSION = "1.10.10"

LANG_EN = {"it": "Italian", "en": "English", "es": "Spanish", "fr": "French", "de": "German", "pt": "Portuguese",
           "nl": "Dutch", "pl": "Polish", "ro": "Romanian", "ru": "Russian", "uk": "Ukrainian", "tr": "Turkish",
           "ar": "Arabic", "hi": "Hindi", "ja": "Japanese", "ko": "Korean", "zh": "Simplified Chinese"}
WHISPER_LANGS = {"english": "en", "italian": "it", "spanish": "es", "french": "fr", "german": "de", "portuguese": "pt",
                 "dutch": "nl", "polish": "pl", "romanian": "ro", "russian": "ru", "ukrainian": "uk", "turkish": "tr",
                 "arabic": "ar", "hindi": "hi", "japanese": "ja", "korean": "ko", "chinese": "zh", "castilian": "es"}
# Sigle delle lingue nei nomi dei file (film.en.srt, film.eng.srt, film.English.srt…)
FILE_TAGS = {
    'en': 'en',
    'eng': 'en',
    'english': 'en',
    'inglese': 'en',
    'it': 'it',
    'ita': 'it',
    'italian': 'it',
    'italiano': 'it',
    'es': 'es',
    'spa': 'es',
    'spanish': 'es',
    'spagnolo': 'es',
    'español': 'es',
    'espanol': 'es',
    'fr': 'fr',
    'fre': 'fr',
    'fra': 'fr',
    'french': 'fr',
    'francese': 'fr',
    'français': 'fr',
    'de': 'de',
    'ger': 'de',
    'deu': 'de',
    'german': 'de',
    'tedesco': 'de',
    'deutsch': 'de',
    'pt': 'pt',
    'por': 'pt',
    'portuguese': 'pt',
    'portoghese': 'pt',
    'pt-br': 'pt',
    'pob': 'pt',
    'português': 'pt',
    'nl': 'nl',
    'dut': 'nl',
    'nld': 'nl',
    'dutch': 'nl',
    'olandese': 'nl',
    'pl': 'pl',
    'pol': 'pl',
    'polish': 'pl',
    'polacco': 'pl',
    'ro': 'ro',
    'rum': 'ro',
    'ron': 'ro',
    'romanian': 'ro',
    'rumeno': 'ro',
    'ru': 'ru',
    'rus': 'ru',
    'russian': 'ru',
    'russo': 'ru',
    'uk': 'uk',
    'ukr': 'uk',
    'ukrainian': 'uk',
    'ucraino': 'uk',
    'tr': 'tr',
    'tur': 'tr',
    'turkish': 'tr',
    'turco': 'tr',
    'ar': 'ar',
    'ara': 'ar',
    'arabic': 'ar',
    'arabo': 'ar',
    'ja': 'ja',
    'jpn': 'ja',
    'japanese': 'ja',
    'giapponese': 'ja',
    'ko': 'ko',
    'kor': 'ko',
    'korean': 'ko',
    'coreano': 'ko',
    'zh': 'zh',
    'chi': 'zh',
    'zho': 'zh',
    'chinese': 'zh',
    'cinese': 'zh',
    'zht': 'zh',
    'zhs': 'zh',
    'el': 'el',
    'gre': 'el',
    'ell': 'el',
    'greek': 'el',
    'greco': 'el',
    'hu': 'hu',
    'hun': 'hu',
    'hungarian': 'hu',
    'ungherese': 'hu',
    'cs': 'cs',
    'cze': 'cs',
    'ces': 'cs',
    'czech': 'cs',
    'ceco': 'cs',
    'čeština': 'cs',
    'cestina': 'cs',
    'sk': 'sk',
    'slo': 'sk',
    'slk': 'sk',
    'slovak': 'sk',
    'slovacco': 'sk',
    'sv': 'sv',
    'swe': 'sv',
    'swedish': 'sv',
    'svedese': 'sv',
    'da': 'da',
    'dan': 'da',
    'danish': 'da',
    'danese': 'da',
    'no': 'no',
    'nor': 'no',
    'nob': 'no',
    'nno': 'no',
    'norwegian': 'no',
    'norvegese': 'no',
    'norsk': 'no',
    'bokmål': 'no',
    'bokmal': 'no',
    'fi': 'fi',
    'fin': 'fi',
    'finnish': 'fi',
    'finlandese': 'fi',
    'is': 'is',
    'ice': 'is',
    'isl': 'is',
    'icelandic': 'is',
    'islandese': 'is',
    'he': 'he',
    'heb': 'he',
    'hebrew': 'he',
    'ebraico': 'he',
    'hi': 'hi',
    'hin': 'hi',
    'hindi': 'hi',
    'id': 'id',
    'ind': 'id',
    'indonesian': 'id',
    'indonesiano': 'id',
    'th': 'th',
    'tha': 'th',
    'thai': 'th',
    'thailandese': 'th',
    'vi': 'vi',
    'vie': 'vi',
    'vietnamese': 'vi',
    'vietnamita': 'vi',
    'bg': 'bg',
    'bul': 'bg',
    'bulgarian': 'bg',
    'bulgaro': 'bg',
    'hr': 'hr',
    'hrv': 'hr',
    'croatian': 'hr',
    'croato': 'hr',
    'sr': 'sr',
    'srp': 'sr',
    'scc': 'sr',
    'serbian': 'sr',
    'serbo': 'sr',
    'sl': 'sl',
    'slv': 'sl',
    'slovenian': 'sl',
    'sloveno': 'sl',
    'fa': 'fa',
    'per': 'fa',
    'fas': 'fa',
    'persian': 'fa',
    'persiano': 'fa',
    'farsi': 'fa',
    'ms': 'ms',
    'may': 'ms',
    'msa': 'ms',
    'malay': 'ms',
    'malese': 'ms',
    'ca': 'ca',
    'cat': 'ca',
    'catalan': 'ca',
    'catalano': 'ca',
    'et': 'et',
    'est': 'et',
    'estonian': 'et',
    'estone': 'et',
    'lv': 'lv',
    'lav': 'lv',
    'latvian': 'lv',
    'lettone': 'lv',
    'lt': 'lt',
    'lit': 'lt',
    'lithuanian': 'lt',
    'lituano': 'lt',
}

ENGINES = {
    "google": {"kind": "google", "chunk": 12},
    # gruppi grandi = meno richieste (Gemini: un film di 2 ore in circa 12 richieste invece di 40)
    "gemini": {"kind": "openai", "base": "https://generativelanguage.googleapis.com/v1beta/openai",
               "model": "gemini-flash-lite-latest", "gap": 6.5, "chunk": 120, "max_tokens": 16384},
    "groq": {"kind": "openai", "base": "https://api.groq.com/openai/v1", "model": "llama-3.3-70b-versatile", "gap": 2.2, "chunk": 35},
    "mistral": {"kind": "openai", "base": "https://api.mistral.ai/v1", "model": "mistral-small-latest", "gap": 1.5, "chunk": 80},
    "openrouter": {"kind": "openai", "base": "https://openrouter.ai/api/v1", "model": "", "gap": 3.5, "chunk": 80},
    "local": {"kind": "openai", "base": "http://localhost:11434/v1", "model": "", "gap": 0, "chunk": 15},
    "deepl": {"kind": "deepl", "gap": 0.5, "chunk": 25},
    "microsoft": {"kind": "microsoft", "gap": 0.3, "chunk": 100},
    "claude": {"kind": "claude", "model": "claude-haiku-4-5-20251001", "gap": 0, "chunk": 100},
}
# Quando un servizio finisce le richieste gratuite di oggi si continua con il primo di questi di cui c'è la chiave
FALLBACK = ["gemini", "groq", "mistral", "openrouter", "microsoft", "deepl"]

# Tutte le lingue in cui si può tradurre: sigla, nome inglese, nome italiano, sigle a 3 lettere (OpenSubtitles, nomi dei file)
LANGS = [
    ("af", "Afrikaans", "afrikaans", ["afr"]), ("sq", "Albanian", "albanese", ["alb", "sqi"]), ("am", "Amharic", "amarico", ["amh"]),
    ("ar", "Arabic", "arabo", ["ara"]), ("hy", "Armenian", "armeno", ["arm", "hye"]), ("az", "Azerbaijani", "azero", ["aze"]),
    ("eu", "Basque", "basco", ["baq", "eus"]), ("be", "Belarusian", "bielorusso", ["bel"]), ("bn", "Bengali", "bengalese", ["ben"]),
    ("bs", "Bosnian", "bosniaco", ["bos"]), ("bg", "Bulgarian", "bulgaro", ["bul"]), ("my", "Burmese", "birmano", ["bur", "mya"]),
    ("ca", "Catalan", "catalano", ["cat"]), ("zh", "Simplified Chinese", "cinese", ["chi", "zho", "zhs", "zht", "zhe"]),
    ("hr", "Croatian", "croato", ["hrv"]), ("cs", "Czech", "ceco", ["cze", "ces"]), ("da", "Danish", "danese", ["dan"]),
    ("nl", "Dutch", "olandese", ["dut", "nld"]), ("en", "English", "inglese", ["eng"]), ("eo", "Esperanto", "esperanto", ["epo"]),
    ("et", "Estonian", "estone", ["est"]), ("tl", "Filipino", "filippino", ["fil", "tgl"]), ("fi", "Finnish", "finlandese", ["fin"]),
    ("fr", "French", "francese", ["fre", "fra"]), ("gl", "Galician", "galiziano", ["glg"]), ("ka", "Georgian", "georgiano", ["geo", "kat"]),
    ("de", "German", "tedesco", ["ger", "deu"]), ("el", "Greek", "greco", ["gre", "ell"]), ("gu", "Gujarati", "gujarati", ["guj"]),
    ("ht", "Haitian Creole", "creolo haitiano", ["hat"]), ("he", "Hebrew", "ebraico", ["heb"]), ("hi", "Hindi", "hindi", ["hin"]),
    ("hu", "Hungarian", "ungherese", ["hun"]), ("is", "Icelandic", "islandese", ["ice", "isl"]), ("id", "Indonesian", "indonesiano", ["ind"]),
    ("ga", "Irish", "irlandese", ["gle"]), ("it", "Italian", "italiano", ["ita"]), ("ja", "Japanese", "giapponese", ["jpn"]),
    ("kn", "Kannada", "kannada", ["kan"]), ("kk", "Kazakh", "kazako", ["kaz"]), ("km", "Khmer", "khmer", ["khm"]),
    ("ko", "Korean", "coreano", ["kor"]), ("ku", "Kurdish", "curdo", ["kur"]), ("lo", "Lao", "laotiano", ["lao"]),
    ("la", "Latin", "latino", ["lat"]), ("lv", "Latvian", "lettone", ["lav"]), ("lt", "Lithuanian", "lituano", ["lit"]),
    ("lb", "Luxembourgish", "lussemburghese", ["ltz"]), ("mk", "Macedonian", "macedone", ["mac", "mkd"]), ("ms", "Malay", "malese", ["may", "msa"]),
    ("ml", "Malayalam", "malayalam", ["mal"]), ("mt", "Maltese", "maltese", ["mlt"]), ("mr", "Marathi", "marathi", ["mar"]),
    ("mn", "Mongolian", "mongolo", ["mon"]), ("ne", "Nepali", "nepalese", ["nep"]), ("no", "Norwegian", "norvegese", ["nor", "nob", "nno"]),
    ("fa", "Persian", "persiano", ["per", "fas"]), ("pl", "Polish", "polacco", ["pol"]), ("pt", "Portuguese", "portoghese", ["por", "pob"]),
    ("pa", "Punjabi", "punjabi", ["pan"]), ("ro", "Romanian", "rumeno", ["rum", "ron"]), ("ru", "Russian", "russo", ["rus"]),
    ("sr", "Serbian", "serbo", ["srp", "scc"]), ("si", "Sinhala", "singalese", ["sin"]), ("sk", "Slovak", "slovacco", ["slo", "slk"]),
    ("sl", "Slovenian", "sloveno", ["slv"]), ("so", "Somali", "somalo", ["som"]), ("es", "Spanish", "spagnolo", ["spa", "spn", "ea"]),
    ("sw", "Swahili", "swahili", ["swa"]), ("sv", "Swedish", "svedese", ["swe"]), ("ta", "Tamil", "tamil", ["tam"]),
    ("te", "Telugu", "telugu", ["tel"]), ("th", "Thai", "thailandese", ["tha"]), ("tr", "Turkish", "turco", ["tur"]),
    ("uk", "Ukrainian", "ucraino", ["ukr"]), ("ur", "Urdu", "urdu", ["urd"]), ("uz", "Uzbek", "uzbeco", ["uzb"]),
    ("vi", "Vietnamese", "vietnamita", ["vie"]), ("cy", "Welsh", "gallese", ["wel", "cym"]), ("yi", "Yiddish", "yiddish", ["yid"]),
    ("xh", "Xhosa", "xhosa", ["xho"]), ("zu", "Zulu", "zulu", ["zul"]),
]
LANG_IT = {c: it for c, en, it, _ in LANGS}
# sigle a 3 lettere che sono anche parole comuni nei nomi dei file: non le uso per riconoscere la lingua dal nome
_AMBIGUOUS = {"may", "per", "cat", "fin", "est", "lit", "lat", "mon", "tam", "tel", "bos", "kan", "mar", "hat", "som", "pan", "lao",
              "sin", "ice", "mac", "geo", "wel", "ea", "mal", "kur", "gle", "nep", "bur", "baq", "arm", "alb"}
for _c, _en, _it, _codes in LANGS:
    LANG_EN.setdefault(_c, _en)
    for _k in [_c, _en.lower(), _it] + [x for x in _codes if x not in _AMBIGUOUS]:
        FILE_TAGS.setdefault(_k, _c)
_ALIAS = {"tagalog": "tl", "farsi": "fa", "iw": "he", "nb": "no", "nn": "no", "fil": "tl", "jw": "jv", "in": "id", "zh-cn": "zh", "zh-hans": "zh", "pt-br": "pt"}


# Whisper restituisce il nome inglese della lingua ("danish"): mappa completa, con i nomi particolari di Whisper
for _c, _en, _it, _codes in LANGS:
    WHISPER_LANGS.setdefault(_en.lower(), _c)
WHISPER_LANGS.update({"castilian": "es", "flemish": "nl", "valencian": "ca", "moldavian": "ro", "moldovan": "ro",
                      "letzeburgesch": "lb", "pushto": "ps", "pashto": "ps", "panjabi": "pa", "sinhalese": "si",
                      "haitian": "ht", "haitian creole": "ht", "tagalog": "tl", "burmese": "my", "myanmar": "my",
                      "nynorsk": "no", "norwegian": "no", "chinese": "zh", "mandarin": "zh", "cantonese": "yue",
                      "javanese": "jv", "sundanese": "su", "hawaiian": "haw", "tatar": "tt", "bashkir": "ba",
                      "faroese": "fo", "occitan": "oc", "breton": "br", "shona": "sn", "yoruba": "yo", "lingala": "ln",
                      "hausa": "ha", "tibetan": "bo", "turkmen": "tk", "tajik": "tg", "sanskrit": "sa", "assamese": "as",
                      "malagasy": "mg", "maori": "mi"})


def lang_code(value):
    """Sigla di una lingua da quello che scrive l'utente o da Kodi: "cs", "CS", "ceco", "Czech", "ces" → "cs" """
    v = str(value or "").strip().lower()
    if not v:
        return ""
    v = _ALIAS.get(v, v)
    if v in LANG_EN:
        return v
    if v in FILE_TAGS:
        return FILE_TAGS[v]
    for c, en, it, codes in LANGS:
        if v in (en.lower(), it) or v in codes:
            return c
    base = v.split("-")[0].split("_")[0]
    if base != v and (base in LANG_EN or base in _ALIAS):
        return _ALIAS.get(base, base)
    # una sigla che non conosco (2-3 lettere, o con la regione: "yue", "zh-tw"): la passo così ai servizi di traduzione
    return v if re.match(r"^[a-z]{2,3}(-[a-z0-9]{2,4})?$", v) else ""


SUB_EXT = (".srt", ".vtt", ".ass", ".ssa")


# ====================================================================== lettura dei sottotitoli
def _ms(t):
    t = t.strip().replace(",", ".")
    m = re.match(r"(?:(\d+):)?(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?", t)
    if not m:
        return None
    h, mi, s, frac = int(m.group(1) or 0), int(m.group(2)), int(m.group(3)), (m.group(4) or "0").ljust(3, "0")
    return ((h * 60 + mi) * 60 + s) * 1000 + int(frac)


def _clean_text(t):
    t = re.sub(r"\{\\[^}]*\}", "", t)          # codici ASS {\i1}
    t = t.replace("\\N", " ").replace("\\n", " ")
    t = re.sub(r"<[^>]+>", "", t)              # <i>, <font>
    return re.sub(r"\s+", " ", t).strip()


def parse_subs(text):
    """Sottotitoli .srt, .vtt, .ass/.ssa → [{"s": ms, "e": ms, "t": testo}]"""
    text = text.replace("\r", "").lstrip("\ufeff")
    cues = []
    if "[Events]" in text and "Dialogue:" in text:
        fmt = None
        for line in text.split("\n"):
            if line.startswith("Format:") and fmt is None and "Start" in line:
                fmt = [x.strip().lower() for x in line[7:].split(",")]
            elif line.startswith("Dialogue:") and fmt:
                parts = line[9:].split(",", len(fmt) - 1)
                row = dict(zip(fmt, parts))
                s, e = _ms(row.get("start", "")), _ms(row.get("end", ""))
                t = _clean_text(row.get("text", ""))
                if s is not None and e is not None and t:
                    cues.append({"s": s, "e": e, "t": t})
    else:
        for block in re.split(r"\n\s*\n", text):
            lines = [l for l in block.split("\n") if l.strip()]
            idx = next((i for i, l in enumerate(lines) if "-->" in l), -1)
            if idx < 0:
                continue
            a, b = lines[idx].split("-->", 1)
            s, e = _ms(a), _ms(b.strip().split(" ")[0])
            t = _clean_text(" ".join(lines[idx + 1:]))
            if s is not None and e is not None and t:
                cues.append({"s": s, "e": max(e, s + 300), "t": t})
    cues.sort(key=lambda c: c["s"])
    return cues


def lang_from_filename(name):
    parts = os.path.basename(name).lower().split(".")[1:-1]
    for p in reversed(parts):
        p = re.sub(r"[^a-z-]", "", p)
        if p in FILE_TAGS:
            return FILE_TAGS[p]
    return ""


STOP = {
    "en": "the and is are of to in that it you was for on with this have be not but they what we my your do there a i our were".split(),
    "it": "il lo gli di che è e un una per non sono con del della mi ti si ma come anche ho questo questa nel alla perché più la al a da io abbiamo siamo".split(),
    "es": "el los las de que es y un una por para con no se del pero como está muy yo tú al esto pues también la en me".split(),
    "fr": "le les des que et est un une pour pas je vous il elle dans ce qui sur avec mais au du très la en nous ne".split(),
    "de": "der die das und ist nicht ich du ein eine zu mit den dem auf für es sie wir aber auch sehr".split(),
    "pt": "o os as de que e é um uma para com não se do da mas como você eu isso muito também a no na em ao".split(),
}


def guess_lang(text):
    words = [w for w in re.split(r"[^\w]+", text.lower()) if w and not w.isdigit()]
    if len(words) < 5:
        return ""
    scores = sorted(((l, sum(1 for w in words if w in lst)) for l, lst in STOP.items()), key=lambda x: -x[1])
    (best, b), (_, s2) = scores[0], scores[1]
    return best if b >= 3 and b >= s2 * 1.5 else ""


def guess_lang_cues(cues):
    return guess_lang(" ".join(c["t"] for c in cues[:200]))


# ====================================================================== scelta del file di sottotitoli
def pick_subtitle(candidates, video_path, target, since=0, prefer_lang=""):
    """candidates: [(percorso, data di modifica, è_nella_cartella_temporanea)] → il file più adatto come "originale".
    since: inizio della visione del video in corso. I file della cartella temporanea di Kodi più vecchi
    (cioè scaricati per un film visto prima) vengono scartati, a meno che abbiano il nome di questo video.
    prefer_lang: lingua dei sottotitoli che stai guardando nel lettore."""
    base = os.path.splitext(os.path.basename(video_path or ""))[0].lower()
    best, best_score = None, -1
    for cand in candidates:
        path, mtime = cand[0], cand[1]
        is_temp = len(cand) > 2 and cand[2]
        name = os.path.basename(path).lower()
        if not name.endswith(SUB_EXT) or ".doppi." in name:
            continue
        lang = lang_from_filename(name)
        if lang and lang == target:
            continue                                   # è già nella tua lingua (o è un file doppio salvato da Kodi)
        same_name = bool(base) and name.startswith(base)
        fresh = bool(since) and mtime >= since
        if is_temp and since and not fresh and not same_name:
            continue                                   # scaricato per un altro film
        score = 0
        if fresh:
            score += 20                                # scaricato adesso, mentre guardi questo video
        if same_name:
            score += 10
        if prefer_lang and lang == prefer_lang:
            score += 5
        if lang:
            score += 1
        score += mtime / 1e11                          # a parità, il più recente
        if score > best_score:
            best, best_score = path, score
    return best


# ====================================================================== traduzione già fatta da persone
# Sottotitoli nella lingua di arrivo dello stesso film (per esempio quelli italiani di OpenSubtitles):
# li metto in fase con l'originale e per ogni frase originale prendo le frasi tradotte che si sovrappongono.
# Le due versioni possono venire da edizioni diverse: ritardo diverso e, a volte, velocità diversa
# (25 fotogrammi al secondo in Europa, 23,976 al cinema).
SCALES = (1.0, 25 / 23.976, 23.976 / 25, 24 / 23.976, 23.976 / 24, 25 / 24, 24 / 25)


def _overlap(a1, a2, b1, b2):
    return max(0, min(a2, b2) - max(a1, b1))


def _sync_score(cues, tcues, scale, off, tol=500):
    """Quante frasi originali, spostate così, cominciano o finiscono insieme a una frase tradotta
    (chi traduce i sottotitoli segue la voce: inizi e fini coincidono, anche quando unisce due frasi)"""
    hit, j = 0, 0
    for c in cues:
        s, e = c["s"] * scale + off, c["e"] * scale + off
        while j < len(tcues) and tcues[j]["e"] < s - tol:
            j += 1
        k = j
        while k < len(tcues) and tcues[k]["s"] <= e + tol:
            if abs(tcues[k]["s"] - s) <= tol or abs(tcues[k]["e"] - e) <= tol:
                hit += 1
                break
            k += 1
    return hit


def find_sync(cues, tcues, max_off_ms=120000, scales=None):
    """Ritardo e velocità che mettono in fase le due versioni: (scala, ritardo_ms, frazione di frasi in fase)"""
    if not cues or not tcues:
        return 1.0, 0, 0.0
    import bisect
    n = len(cues)
    starts = [t["s"] for t in tcues]
    best = (1.0, 0, -1)
    for scale in (scales or SCALES):
        bins = {}
        step = max(1, n // 400)                 # nei film molto lunghi basta un campione
        for c in cues[::step]:
            x = c["s"] * scale
            lo, hi = bisect.bisect_left(starts, x - max_off_ms), bisect.bisect_right(starts, x + max_off_ms)
            for j in range(lo, hi):
                b = int(round((starts[j] - x) / 250.0))
                bins[b] = bins.get(b, 0) + 1
        for b, _ in sorted(bins.items(), key=lambda x: -x[1])[:4]:
            sc = _sync_score(cues, tcues, scale, b * 250)
            if sc > best[2]:
                best = (scale, b * 250, sc)
    # affino il ritardo attorno al migliore, con tolleranza più stretta
    scale, off = best[0], best[1]
    fine = max(range(off - 240, off + 241, 40), key=lambda o: (_sync_score(cues, tcues, scale, o, tol=250), -abs(o - off)))
    return scale, fine, _sync_score(cues, tcues, scale, fine) / float(n)


def _anchors(cues, tcues, scale, off, tol=450):
    """Per ogni frase originale: comincia o finisce insieme a una frase tradotta?"""
    out, j = [], 0
    for c in cues:
        s, e = c["s"] * scale + off, c["e"] * scale + off
        while j < len(tcues) and tcues[j]["e"] < s - tol:
            j += 1
        k, ok = j, False
        while k < len(tcues) and tcues[k]["s"] <= e + tol:
            if abs(tcues[k]["s"] - s) <= tol or abs(tcues[k]["e"] - e) <= tol:
                ok = True
                break
            k += 1
        out.append(ok)
    return out


def merge_human(cues, tcues, target=""):
    """Traduzione di ogni frase originale presa dai sottotitoli già tradotti: (traduzioni, info).
    Le frasi originali senza una frase tradotta corrispondente restano "" (si traducono poi con Google).
    Prendo una frase solo se comincia o finisce insieme a una tradotta e se attorno le due versioni sono in fase.
    Una versione con scene in più va fuori fase da un certo punto in poi: lì rifaccio la messa in fase
    (fino a 3 tratti), invece di mettere la traduzione di un'altra frase."""
    n = len(cues)
    trans, taken = [""] * n, [False] * n
    first = None
    for _ in range(3):
        idx = [i for i in range(n) if not taken[i]]
        if not idx or (first is not None and len(idx) < 40):    # i tratti da rifare sono lunghi (una scena in più), non frasi sparse
            break
        sub = [cues[i] for i in idx]
        scale, off, ratio = find_sync(sub, tcues, scales=(first[0],) if first else None)
        if first is None:
            first = (scale, off, ratio)
        elif ratio < 0.6:
            break
        anch = _anchors(sub, tcues, scale, off)
        got = 0
        for k, i in enumerate(idx):
            win = anch[max(0, k - 5):k + 6]
            if not anch[k] or sum(win) < 0.8 * len(win):
                continue
            c = cues[i]
            s, e = c["s"] * scale + off, c["e"] * scale + off
            parts = []
            for t in _around(tcues, s, e):
                o = _overlap(s, e, t["s"], t["e"])
                # una frase tradotta va con quelle originali che copre in buona parte (anche due, se le unisce)
                if o >= 0.3 * min(e - s, t["e"] - t["s"]) and t["t"] not in parts:
                    parts.append(t["t"])
            if parts:
                trans[i], taken[i] = " ".join(parts), True
                got += 1
        if got < 10:
            break
    done = sum(taken)
    return trans, {"scale": round(first[0], 4) if first else 1.0, "offset_ms": first[1] if first else 0,
                   "in_fase": round(first[2], 2) if first else 0.0, "coperte": round(done / float(max(1, n)), 2)}


def _around(tcues, s, e):
    """Frasi tradotte che toccano l'intervallo s-e (le frasi sono in ordine di inizio)"""
    import bisect
    starts = _around.cache.get(id(tcues))
    if starts is None or len(starts) != len(tcues):
        starts = [t["s"] for t in tcues]
        _around.cache = {id(tcues): starts}
    k = max(0, bisect.bisect_left(starts, s - 30000))
    out = []
    while k < len(tcues) and tcues[k]["s"] < e:
        if tcues[k]["e"] > s:
            out.append(tcues[k])
        k += 1
    return out


_around.cache = {}


# ====================================================================== rete
# Alcuni servizi (OpenSubtitles di Stremio, dietro Cloudflare) rifiutano le richieste con il nome predefinito
# di Python ("Python-urllib"): mi presento come un normale lettore
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 Kodi SottotitoliDoppi"


def http(url, data=None, headers=None, timeout=90):
    headers = dict(headers or {})
    if not any(k.lower() == "user-agent" for k in headers):
        headers["User-Agent"] = UA
    req = urllib.request.Request(url, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers or {})


class RateLimited(Exception):
    def __init__(self, wait, daily=False):
        Exception.__init__(self, "limite di richieste")
        self.wait, self.daily = wait, daily


class Fatal(Exception):
    pass


class Cancelled(Exception):
    """Lavoro interrotto perché hai chiesto altro (per esempio una scelta fatta a mano mentre lavorava quello automatico)"""
    pass


class QuotaError(Fatal):
    """Quota o credito del servizio finiti: messaggio da mostrare bene in vista, non solo in un avviso"""
    pass


def _check(status, body, headers, service):
    if status == 429:
        text = body.decode("utf-8", "replace")
        m = re.search(r'"retryDelay"\s*:\s*"(\d+)', text)
        wait = int(headers.get("Retry-After") or headers.get("retry-after") or (m.group(1) if m else 15))
        raise RateLimited(min(90, max(5, wait)), daily=bool(re.search(r"PerDay|per day|daily", text, re.I)))
    if status in (401, 403):
        raise Fatal("%s: chiave non valida o senza permessi (%d)" % (service, status))
    if status >= 400:
        raise Exception("%s ha risposto %d: %s" % (service, status, body[:200].decode("utf-8", "replace")))


# ====================================================================== traduzione
def google_translate(texts, target, source=""):
    tl = "zh-CN" if target == "zh" else target
    sl = source.split("-")[0] if source and source.split("-")[0] != target else "auto"

    def one(q):
        url = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t&sl=%s&tl=%s&q=%s" % (
            sl, tl, urllib.parse.quote(q))
        st, body, h = http(url)
        _check(st, body, h, "Google Traduttore")
        data = json.loads(body.decode("utf-8"))
        return "".join((p[0] or "") for p in (data[0] or []) if p)

    lines = one("\n".join(texts)).split("\n")
    if len(lines) == len(texts):
        return [l.strip() for l in lines]
    return [one(t).strip() for t in texts]


def google_translate_fast(texts, target, source="", workers=6):
    """Tutte le frasi con Google, molte richieste insieme: un film intero in pochi secondi."""
    from concurrent.futures import ThreadPoolExecutor
    parts, cur, size = [], [], 0
    for i, t in enumerate(texts):
        if cur and (len(cur) >= 30 or size + len(t) > 1500):
            parts.append(cur); cur, size = [], 0
        cur.append(i); size += len(t) + 1
    if cur:
        parts.append(cur)
    out = [""] * len(texts)

    def job(part):
        res = google_translate([texts[i] for i in part], target, source)
        for i, t in zip(part, res):
            out[i] = "" if is_echo(texts[i], t, target) else t
    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(job, parts))
    return out


def _prompt(target, n):
    lang = LANG_EN.get(target, target)
    return ("You translate video subtitles into %s. You receive a JSON object whose \"segments\" array holds consecutive "
            "subtitles of a film or video. \"context_before\" and \"context_after\" are only there to help you understand; "
            "do not translate them. Write natural, fluent %s the way a professional subtitler would. Each segment is a "
            "separate subtitle shown at a different time: keep every translation aligned with its own segment, never move "
            "words between segments, never merge them, never leave one empty. Always translate into %s, never copy the "
            "original. Short lines of one or two words (answers, interjections, greetings, exclamations) must be translated too; "
            "only names of people and places stay as they are. Do not add numbers, quotes or notes. Return exactly %d strings as JSON: {\"t\": [\"...\"]} and nothing else."
            % (lang, lang, lang, n))


def _parse_list(content, n):
    s = re.sub(r"<think>.*?</think>", "", content or "", flags=re.S).replace("```json", "").replace("```", "")
    arr = None
    a, b = s.find("{"), s.rfind("}")
    if a >= 0 and b > a:
        try:
            obj = json.loads(s[a:b + 1])
            arr = obj.get("t") or obj.get("translations") or next((v for v in obj.values() if isinstance(v, list)), None)
        except ValueError:
            pass
    if arr is None:
        a, b = s.find("["), s.rfind("]")
        if a >= 0 and b > a:
            try:
                arr = json.loads(s[a:b + 1])
            except ValueError:
                pass
    if not isinstance(arr, list) or not arr:
        raise Exception("risposta del modello non leggibile")
    out = [re.sub(r"^\s*\d{1,3}[.)]\s+", "", str(x or "")).strip() for x in arr[:n]]
    return out + [""] * (n - len(out)), len(arr) != n


def _words(t):
    return [w for w in re.split(r"[^\w]+", (t or "").lower()) if w]


def is_copy(orig, trans):
    """La "traduzione" è l'originale ricopiato (anche per le frasi di una o due parole: "Ja." → "Ja.")"""
    wa, wb = _words(orig), _words(trans)
    return bool(wa) and wa == wb and not all(w.isdigit() for w in wa)


def is_echo(orig, trans, target):
    wa = [w for w in re.split(r"[^\w]+", orig.lower()) if w]
    wb = [w for w in re.split(r"[^\w]+", trans.lower()) if w]
    if len(wa) >= 3 and wb:
        if wa == wb:
            return True
        ratio = len(wb) / float(len(wa))
        if 0.7 < ratio < 1.45 and sum(1 for w in wb if w in set(wa)) / float(max(len(wa), len(wb))) >= 0.8:
            return True
    g = guess_lang(trans)
    return bool(g and g != target)


def bad_alignment(texts, trans):
    if len(texts) < 2:
        return False
    for src, t in zip(texts, trans):
        if len(src.split()) < 3:
            continue
        if not t.strip() or len(t) > len(src) * 2.6 + 25 or len(t) < len(src) * 0.3:
            return True
    return False


def llm_translate(engine_id, conf, texts, before, after, target):
    E = ENGINES[engine_id]
    user = json.dumps({"context_before": before, "segments": texts, "context_after": after}, ensure_ascii=False)
    system = _prompt(target, len(texts))
    key = conf.get("key", "")
    if E["kind"] == "claude":
        body = json.dumps({"model": conf.get("model") or E["model"], "max_tokens": 8000, "system": system,
                           "messages": [{"role": "user", "content": user}]}).encode("utf-8")
        st, raw, h = http("https://api.anthropic.com/v1/messages", body, {
            "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"})
        _check(st, raw, h, "Claude")
        data = json.loads(raw.decode("utf-8"))
        content = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    else:
        base = (conf.get("url") or E["base"]).rstrip("/")
        model = conf.get("model") or E["model"]
        if not model:
            raise Fatal("scegli un modello nelle impostazioni dell'add-on")
        body = json.dumps({"model": model, "temperature": 0.2, "max_tokens": E.get("max_tokens", 8192),
                           "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if key:
            headers["Authorization"] = "Bearer " + key
        st, raw, h = http(base + "/chat/completions", body, headers)
        _check(st, raw, h, engine_id)
        data = json.loads(raw.decode("utf-8"))
        content = ((data.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
    return _parse_list(content, len(texts))


def deepl_translate(conf, texts, before, after, target):
    key = conf.get("key", "")
    host = "https://api-free.deepl.com" if key.endswith(":fx") else "https://api.deepl.com"
    tl = {"en": "EN-US", "pt": "PT-BR", "zh": "ZH-HANS"}.get(target, target.upper())
    payload = {"text": texts, "target_lang": tl}
    if before or after:
        payload["context"] = "\n".join(before + after)
    st, raw, h = http(host + "/v2/translate", json.dumps(payload).encode("utf-8"),
                      {"Content-Type": "application/json", "Authorization": "DeepL-Auth-Key " + key})
    _check(st, raw, h, "DeepL")
    return [t.get("text", "") for t in json.loads(raw.decode("utf-8")).get("translations", [])]


def microsoft_translate(conf, texts, target, source=""):
    """Microsoft Translator (Azure, piano F0 gratuito: 2 milioni di caratteri al mese)"""
    ms = lambda l: {"zh": "zh-Hans", "no": "nb", "tl": "fil"}.get(l, (l or "").split("-")[0])
    url = "https://api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=" + ms(target)
    if source and ms(source) != ms(target):
        url += "&from=" + ms(source)
    headers = {"Content-Type": "application/json", "Ocp-Apim-Subscription-Key": conf.get("key", "").strip()}
    if conf.get("region"):
        headers["Ocp-Apim-Subscription-Region"] = conf["region"].strip()
    st, raw, h = http(url, json.dumps([{"Text": t} for t in texts]).encode("utf-8"), headers)
    if st == 403:
        raise RateLimited(0, daily=True)          # caratteri del mese finiti
    if st == 401:
        raise Fatal("Microsoft Translator: chiave o area sbagliata (impostazioni dell'add-on, Traduzione)")
    _check(st, raw, h, "Microsoft Translator")
    data = json.loads(raw.decode("utf-8"))
    return [((d.get("translations") or [{}])[0].get("text") or "") for d in data] + [""] * (len(texts) - len(data))


# ---------------------------------------------------------------------- servizi esauriti per oggi
BLOCKED_PATH = ""   # file in cui ricordarli (lo imposta runner)


def _pacific_day():
    # le quote gratuite di Gemini si azzerano a mezzanotte di Los Angeles (circa le 9 in Italia)
    return time.strftime("%Y-%m-%d", time.gmtime(time.time() - 8 * 3600))


def _blocked():
    try:
        return json.load(open(BLOCKED_PATH, encoding="utf-8")) if BLOCKED_PATH else {}
    except Exception:
        return {}


def is_blocked(engine):
    return _blocked().get(engine) == _pacific_day()


def mark_blocked(engine):
    if not BLOCKED_PATH or engine == "google":
        return
    b = _blocked()
    b[engine] = _pacific_day()
    try:
        json.dump(b, open(BLOCKED_PATH, "w", encoding="utf-8"))
    except Exception:
        pass


def engine_conf(settings, engine):
    return {"key": settings.get(engine + "_key", ""), "model": settings.get(engine + "_model", ""),
            "url": settings.get(engine + "_url", ""), "region": settings.get("microsoft_region", "")}


def engine_ready(settings, engine):
    E = ENGINES.get(engine)
    if not E:
        return False
    if E["kind"] == "google" or engine == "local":
        return True
    c = engine_conf(settings, engine)
    return bool(c["key"]) and (E["kind"] != "openai" or bool(c["model"] or E.get("model")))


def engine_chain(settings):
    """Servizi da provare in ordine: quello scelto (se non ha finito la quota di oggi), poi quelli di riserva con la chiave"""
    chosen = settings.get("engine", "google")
    out = [chosen] if engine_ready(settings, chosen) and not is_blocked(chosen) else []
    if settings.get("fallback", True) and ENGINES.get(chosen, {}).get("kind") != "google":
        out += [e for e in FALLBACK if e != chosen and engine_ready(settings, e) and not is_blocked(e)]
    return out + ["google"]


def translate_all(cues, settings, target, source="", start_ms=0, on_progress=None, on_batch=None, should_stop=None):
    """Traduce tutte le frasi. Parte dal punto in cui stai guardando, poi il resto.
    Restituisce la lista delle traduzioni (stesso ordine di cues)."""
    chain = engine_chain(settings)
    engine = chain.pop(0)
    E = ENGINES[engine]
    conf = engine_conf(settings, engine)
    used = [engine]
    waits = {}
    texts = [c["t"] for c in cues]
    trans = [None] * len(texts)
    size = E["chunk"]
    chunks = [list(range(i, min(i + size, len(texts)))) for i in range(0, len(texts), size)]
    k = next((i for i, ch in enumerate(chunks) if cues[ch[-1]]["e"] >= start_ms), 0)
    queue = chunks[k:] + chunks[:k]
    last_call = 0.0
    done = 0
    use_google = E["kind"] == "google"
    while queue:
        if should_stop and should_stop():
            break
        ch = queue.pop(0)
        src = [texts[i] for i in ch]
        before = texts[max(0, ch[0] - 4):ch[0]]
        after = texts[ch[-1] + 1:ch[-1] + 3]
        result, misaligned = None, False
        try:
            if use_google:
                result = google_translate(src, target, source)
            else:
                wait = E.get("gap", 0) - (time.time() - last_call)
                if wait > 0:
                    time.sleep(wait)
                last_call = time.time()
                if E["kind"] == "deepl":
                    result = deepl_translate(conf, src, before, after, target)
                elif E["kind"] == "microsoft":
                    result = microsoft_translate(conf, src, target, source)
                else:
                    result, misaligned = llm_translate(engine, conf, src, before, after, target)
                misaligned = misaligned or bad_alignment(src, result)
        except RateLimited as e:
            waits[engine] = waits.get(engine, 0) + 1
            if waits[engine] > 6:
                e.daily = True                        # il limite al minuto non si sblocca: passo a un altro servizio
            if e.daily and not use_google:
                # quota del giorno finita: continuo con il prossimo servizio con la chiave, alla fine Google
                mark_blocked(engine)
                engine = chain.pop(0) if chain else "google"
                E, conf = ENGINES[engine], engine_conf(settings, engine)
                used.append(engine)
                use_google = E["kind"] == "google"
                if not use_google:          # gruppi della misura giusta per il nuovo servizio
                    left = [i for c in [ch] + queue for i in c]
                    queue = [left[i:i + E["chunk"]] for i in range(0, len(left), E["chunk"])]
                    continue
            elif not e.daily:
                time.sleep(e.wait)
            queue.insert(0, ch)
            continue
        except Fatal:
            # chiave sbagliata o modello inesistente: prossimo servizio della catena
            engine = chain.pop(0) if chain else "google"
            E, conf = ENGINES[engine], engine_conf(settings, engine)
            used.append(engine)
            use_google = E["kind"] == "google"
            queue.insert(0, ch)
            continue
        except Exception:
            if not use_google and len(ch) > 3:
                queue[0:0] = [ch[:len(ch) // 2], ch[len(ch) // 2:]]
                continue
            result = google_translate(src, target, source)
        if misaligned and len(ch) > 1:
            queue[0:0] = [ch[:len(ch) // 2], ch[len(ch) // 2:]]
            continue
        echo = [j for j, i in enumerate(ch) if is_echo(texts[i], result[j] or "", target)]
        if echo and not use_google:
            fixed = google_translate([src[j] for j in echo], target, source)
            for j, t in zip(echo, fixed):
                result[j] = "" if is_echo(src[j], t, target) else t
        # frasi brevi ricopiate ("Ja." → "Ja."): seconda opinione di Google; se anche Google la lascia uguale
        # è un nome o una parola internazionale ("Okay", "Karen") e resta così
        short = [j for j, i in enumerate(ch) if j < len(result) and result[j] and is_copy(texts[i], result[j])
                 and not is_echo(texts[i], result[j], target)]
        if short and not use_google:
            try:
                fixed = google_translate([src[j] for j in short], target, source)
                for j, t in zip(short, fixed):
                    if t and not is_copy(src[j], t):
                        result[j] = t
            except Exception:
                pass
        for j, i in enumerate(ch):
            trans[i] = result[j] if j < len(result) else ""
        waits[engine] = 0
        done += len(ch)
        if on_progress:
            on_progress(done, len(texts))
        if on_batch:
            on_batch(trans)
    translate_all.used = used
    return [t or "" for t in trans]


translate_all.used = []


# ====================================================================== file doppio
def ms_srt(ms):
    ms = max(0, int(ms))
    return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


def _esc(t):
    return t.replace("<", "‹").replace(">", "›")


def make_dual_srt(cues, trans, layout="orig_top", color="FFFF00"):
    """In ogni sottotitolo l'originale e la traduzione (colorata). layout: orig_top, trans_top, trans_only"""
    out = []
    for n, (c, t) in enumerate(zip(cues, trans), 1):
        tr = '<font color="#%s">%s</font>' % (color.strip("#"), _esc(t)) if t else ""
        orig = _esc(c["t"])
        if layout == "trans_only":
            body = tr or orig
        elif layout == "trans_top":
            body = "\n".join(x for x in (tr, orig) if x)
        else:
            body = "\n".join(x for x in (orig, tr) if x)
        out.append("%d\n%s --> %s\n%s\n" % (n, ms_srt(c["s"]), ms_srt(c["e"]), body))
    return "\n".join(out)


def cache_key(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:16]


# ====================================================================== trascrizione (Whisper, serve ffmpeg)
HALLU = re.compile(r"(sottotitoli (creati|a cura)|amara\.org|thanks? (you )?for watching|grazie (per|della) (la )?visione|"
                   r"iscriviti al canale|subtitles by|please subscribe)", re.I)
STOCK = re.compile(r"^(i'?m sorry|sorry|it'?s over|thank you( so much| very much)?|thanks|bye( bye)?|you|oh|okay|ok|yeah|"
                   r"music|applause|grazie|ciao)[.!?…]*$", re.I)


def is_junk(seg, recent):
    t = (seg.get("text") or "").strip()
    if not t or HALLU.search(t) or re.match(r"^[\s♪♫.…*\-]*$", t) or re.match(r"^[\[(].*[\])]$", t):
        return True
    ns, lp = seg.get("no_speech_prob") or 0, seg.get("avg_logprob")
    lp = -1 if lp is None else lp
    if lp < -1.5 or (ns > 0.5 and lp < -0.4) or (seg.get("compression_ratio") or 0) > 2.4:
        return True
    if STOCK.match(t) and (ns > 0.15 or lp < -0.6):
        return True
    return t.lower() in [r.lower() for r in recent[-4:]] and len(t.split()) <= 6


def find_ffmpeg(configured=""):
    if configured and os.path.isfile(configured):
        return configured
    return shutil.which("ffmpeg")


class WrongAudio(Fatal):
    """Il file non ha l'audio nella lingua originale del film (solo doppiaggi)"""
    def __init__(self, msg, have=None):
        Fatal.__init__(self, msg)
        self.have = have or []


def audio_streams(ffmpeg, media):
    """Tracce audio del file, nell'ordine: [lingua o ""] ("ger" → "de")"""
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        p = subprocess.run([ffmpeg, "-nostdin", "-hide_banner", "-i", media], capture_output=True, timeout=90, creationflags=flags)
    except Exception:
        return []
    out = []
    for m in re.finditer(r"Stream #\d+:\d+(?:\[[^\]]*\])?(?:\(([a-zA-Z]{2,3})\))?[^:]*: Audio", p.stderr.decode("utf-8", "replace")):
        code = (m.group(1) or "").lower()
        out.append("" if code in ("", "und", "unk", "mul", "zxx") else (lang_code(code) or code))
    return out


def pick_audio_stream(ffmpeg, media, lang, allow_dub=False):
    """Quale traccia audio trascrivere: quella nella lingua originale del film. Se il file ha solo doppiaggi
    (tutte le tracce con una lingua dichiarata e nessuna è quella del film) → WrongAudio, a meno di allow_dub."""
    langs = audio_streams(ffmpeg, media)
    if not lang or not langs:
        return 0
    if lang in langs:
        return langs.index(lang)
    if "" in langs:
        return langs.index("")         # traccia senza lingua dichiarata: può essere l'originale
    if allow_dub:
        return 0
    raise WrongAudio("Questo file non ha l'audio originale del film (%s): ha solo l'audio in %s. Trascriverlo vorrebbe dire "
                     "imparare dal doppiaggio." % (LANG_IT.get(lang, lang), " e ".join(sorted(set(LANG_IT.get(l, l) for l in langs)))), langs)


def extract_audio_pieces(ffmpeg, media, workdir, piece_sec=600, stream=0):
    """Audio del video in pezzi da 10 minuti, mono 16 kHz, opus 24 kbps (circa 1,8 MB a pezzo)"""
    pattern = os.path.join(workdir, "pezzo%03d.ogg")
    cmd = [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-i", media, "-map", "0:a:%d" % stream, "-vn", "-ac", "1",
           "-ar", "16000", "-c:a", "libopus", "-b:a", "24k", "-f", "segment", "-segment_time", str(piece_sec), pattern]
    flags = 0x08000000 if os.name == "nt" else 0
    p = subprocess.run(cmd, capture_output=True, creationflags=flags)
    files = sorted(f for f in os.listdir(workdir) if f.startswith("pezzo") and f.endswith(".ogg"))
    if p.returncode != 0 and not files:
        raise Exception("ffmpeg non riesce a leggere l'audio: " + p.stderr.decode("utf-8", "replace")[-200:])
    return [os.path.join(workdir, f) for f in files]


# ====================================================================== sottotitoli da SubDL (subdl.com, chiave gratuita)
# API: https://subdl.com/api-doc — 20.000 richieste al giorno con il piano gratuito. Ricerca per IMDb (o titolo e anno),
# risultati con l'indirizzo di uno .zip su dl.subdl.com che contiene il sottotitolo.
SUBDL_API = "https://api.subdl.com/api/v1/subtitles"
SUBDL_DL = "https://dl.subdl.com"
SUBDL_SPECIAL = {"pt-br": "BR_PT", "pb": "BR_PT", "zh-tw": "ZH_BG", "zht": "ZH_BG"}
SUBDL_BACK = {"BR_PT": "pt", "ZH_BG": "zh", "BG_EN": "bg", "NL_EN": "nl", "EN_DE": "de", "HU_EN": "hu"}


def subdl_code(lang):
    l = str(lang or "").lower()
    return SUBDL_SPECIAL.get(l) or l.split("-")[0].upper()


def _subdl_lang(sub):
    """Sigla di due lettere del sottotitolo (SubDL dà «language»: EN, BR_PT… e «lang»: english)"""
    code = str(sub.get("language") or "").upper()
    if code:
        return SUBDL_BACK.get(code, code.split("_")[0].lower())
    name = str(sub.get("lang") or "").strip().lower()
    for c, en in LANG_EN.items():
        if en.lower() == name:
            return c
    return ""


def subdl_search(key, langs, imdb="", title="", year="", season=0, episode=0, per_page=30):
    """Sottotitoli su SubDL: [{"url", "lang", "release", "hi", "author", "season", "episode"}]"""
    if not key:
        raise Fatal("manca la chiave di SubDL (subdl.com → registrati → API key) nelle impostazioni dell'add-on")
    q = {"api_key": key.strip(), "subs_per_page": str(per_page)}
    if imdb and str(imdb).startswith("tt"):
        q["imdb_id"] = imdb
    elif title:
        q["film_name"] = title
        if year:
            q["year"] = str(year)[:4]
    else:
        return []
    if season:
        q["type"] = "tv"
        q["season_number"] = str(int(season))
        if episode:
            q["episode_number"] = str(int(episode))
    elif imdb or title:
        q["type"] = "movie"
    if langs:
        q["languages"] = ",".join(dict.fromkeys(subdl_code(l) for l in langs if l))
    st, body, h = http(SUBDL_API + "?" + urllib.parse.urlencode(q), timeout=25)
    try:
        d = json.loads(body.decode("utf-8", "replace"))
    except Exception:
        raise Exception("SubDL non ha risposto bene (%s)" % st)
    if st in (401, 403) or (isinstance(d, dict) and d.get("status") is False and "key" in str(d.get("error", "")).lower()):
        raise Fatal("la chiave di SubDL non va bene: %s" % (d.get("error") if isinstance(d, dict) else st))
    if not isinstance(d, dict) or d.get("status") is False:
        return []
    out = []
    for sub in d.get("subtitles") or []:
        u = sub.get("url") or ""
        if not u:
            continue
        out.append({"url": u if u.startswith("http") else SUBDL_DL + (u if u.startswith("/") else "/" + u),
                    "lang": _subdl_lang(sub), "release": sub.get("release_name") or sub.get("name") or "",
                    "hi": bool(sub.get("hi")), "author": sub.get("author") or "",
                    "season": sub.get("season"), "episode": sub.get("episode")})
    return out


def subdl_download(url, season=0, episode=0):
    """Scarica lo .zip di SubDL e restituisce (contenuto, estensione) del sottotitolo giusto (per le serie, quello
    dell'episodio)"""
    import io
    import zipfile
    st, body, h = http(url, timeout=40)
    if st != 200 or not body:
        raise Exception("SubDL non ha dato il file (risposta %s)" % st)
    if body[:2] != b"PK":
        if b"-->" in body:
            return body, ".srt"
        raise Exception("il file di SubDL non è uno .zip né un sottotitolo")
    z = zipfile.ZipFile(io.BytesIO(body))
    names = [n for n in z.namelist() if os.path.splitext(n)[1].lower() in (".srt", ".ass", ".ssa", ".vtt", ".sub")]
    if not names:
        raise Exception("nello .zip di SubDL non c'è un sottotitolo")
    if season and episode:
        pat = re.compile(r"s0*%d\s*[ex._-]?\s*0*%d(?!\d)|\b0*%dx0*%d\b" % (int(season), int(episode), int(season), int(episode)), re.I)
        hit = [n for n in names if pat.search(os.path.basename(n))]
        names = hit or names
    names.sort(key=lambda n: (os.path.splitext(n)[1].lower() != ".srt", -z.getinfo(n).file_size))
    return z.read(names[0]), os.path.splitext(names[0])[1].lower()


# ====================================================================== sottotitoli da OpenSubtitles (servizio di Stremio, senza chiave)
OPENSUBS = "https://opensubtitles-v3.strem.io"
CINEMETA = "https://v3-cinemeta.strem.io"
OS_CODES = {"en": ["eng"], "it": ["ita"], "es": ["spa", "spn"], "fr": ["fre", "fra"], "de": ["ger", "deu"], "pt": ["por", "pob"],
            "nl": ["dut", "nld"], "pl": ["pol"], "ro": ["rum", "ron"], "ru": ["rus"], "uk": ["ukr"], "tr": ["tur"], "ar": ["ara"],
            "ja": ["jpn"], "ko": ["kor"], "zh": ["chi", "zho", "zht", "zhs"], "el": ["gre", "ell"], "hu": ["hun"], "cs": ["cze", "ces"],
            "sk": ["slo", "slk"], "sv": ["swe"], "da": ["dan"], "no": ["nor", "nob", "nno"], "fi": ["fin"], "is": ["ice", "isl"],
            "he": ["heb"], "hi": ["hin"], "id": ["ind"], "th": ["tha"], "vi": ["vie"], "bg": ["bul"], "hr": ["hrv", "scc"],
            "sr": ["srp"], "sl": ["slv"], "fa": ["per", "fas"], "ms": ["may", "msa"], "ca": ["cat"], "et": ["est"], "lv": ["lav"], "lt": ["lit"]}
for _c, _en, _it, _codes in LANGS:
    OS_CODES.setdefault(_c, [x for x in _codes if len(x) == 3])


def find_imdb(title, year="", kind="movie"):
    """Codice IMDb di un film o di una serie partendo dal titolo (catalogo di Stremio)"""
    if not title:
        return ""
    url = "%s/catalog/%s/top/search=%s.json" % (CINEMETA, "series" if kind == "series" else "movie", urllib.parse.quote(title))
    st, body, h = http(url, timeout=20)
    if st != 200:
        return ""
    metas = json.loads(body.decode("utf-8")).get("metas") or []
    year = str(year or "")[:4]
    for m in metas:
        if year and str(m.get("releaseInfo") or m.get("year") or "")[:4] == year:
            return m.get("imdb_id") or m.get("id") or ""
    return (metas[0].get("imdb_id") or metas[0].get("id") or "") if metas else ""


_OS_CACHE = {}


COUNTRY_LANG = {
    "united states": "en", "usa": "en", "united kingdom": "en", "uk": "en", "ireland": "en", "canada": "en", "australia": "en",
    "new zealand": "en", "italy": "it", "spain": "es", "mexico": "es", "argentina": "es", "colombia": "es", "chile": "es",
    "peru": "es", "cuba": "es", "france": "fr", "germany": "de", "west germany": "de", "east germany": "de", "austria": "de",
    "portugal": "pt", "brazil": "pt", "netherlands": "nl", "poland": "pl", "romania": "ro", "russia": "ru", "soviet union": "ru",
    "ukraine": "uk", "turkey": "tr", "türkiye": "tr", "egypt": "ar", "japan": "ja", "south korea": "ko", "korea": "ko",
    "china": "zh", "taiwan": "zh", "hong kong": "zh", "greece": "el", "hungary": "hu", "czech republic": "cs", "czechia": "cs",
    "czechoslovakia": "cs", "sweden": "sv", "denmark": "da", "norway": "no", "finland": "fi", "iceland": "is", "israel": "he",
    "indonesia": "id", "thailand": "th", "vietnam": "vi", "bulgaria": "bg", "croatia": "hr", "serbia": "sr", "yugoslavia": "sr",
    "slovenia": "sl", "slovakia": "sk", "iran": "fa", "estonia": "et", "latvia": "lv", "lithuania": "lt", "india": "hi"}
_FILM_LANG = {}


def film_language(imdb, kind="movie"):
    """Lingua originale del film dal catalogo Cinemeta (lingua dichiarata, altrimenti primo paese di produzione)"""
    if not imdb.startswith("tt"):
        return ""
    if imdb in _FILM_LANG:
        return _FILM_LANG[imdb]
    lang = ""
    try:
        st, body, h = http("%s/meta/%s/%s.json" % (CINEMETA, "series" if kind == "series" else "movie", imdb), timeout=8)
        if st == 200:
            meta = json.loads(body.decode("utf-8")).get("meta") or {}
            for field in ("language", "languages", "spoken_languages"):
                v = meta.get(field)
                for x in (v if isinstance(v, list) else re.split(r"[,/]", str(v or ""))):
                    lang = lang or lang_code(str(x).strip())
            if not lang:
                c = meta.get("country")
                for x in (c if isinstance(c, list) else re.split(r"[,/]", str(c or ""))):
                    lang = lang or COUNTRY_LANG.get(str(x).strip().lower(), "")
    except Exception:
        lang = ""
    _FILM_LANG[imdb] = lang
    return lang


# ====================================================================== sottotitoli dentro i file di Real-Debrid
# Il file in streaming (decine di GB) non si può leggere tutto, ma Real-Debrid lo converte anche in uno streaming HLS
# ("transcode"): lì le tracce di sottotitoli dentro il file sono pezzetti WebVTT leggeri, che si scaricano in pochi secondi.
RD_API = "https://api.real-debrid.com/rest/1.0"


def is_rd_link(url):
    return bool(re.match(r"^https?://[^/]*real-debrid\.com/d/", url or ""))


def _rd_get(path, token, timeout=20):
    st, body, h = http(RD_API + path, headers={"Authorization": "Bearer " + token}, timeout=timeout)
    if st == 401:
        raise Fatal("Real-Debrid: chiave (token) non valida o scaduta")
    if st >= 400:
        raise Exception("Real-Debrid ha risposto %d: %s" % (st, body[:150].decode("utf-8", "replace")))
    return json.loads(body.decode("utf-8") or "null")


def rd_find_id(url, token):
    """Codice del file in Real-Debrid per il link che stai guardando (dall'elenco dei tuoi download)"""
    code = (re.search(r"/d/([^/]+)/", url) or [None, ""])[1]
    base = url.split("?")[0]
    for page in (1, 2, 3):
        items = _rd_get("/downloads?limit=100&page=%d" % page, token) or []
        for d in items:
            dl = (d.get("download") or "").split("?")[0]
            if dl == base or (code and "/d/%s/" % code in dl):
                return d.get("id")
        if len(items) < 100:
            break
    # non è tra i download: lo "sblocco" di nuovo (Real-Debrid restituisce lo stesso file con il suo codice)
    st, body, h = http(RD_API + "/unrestrict/link", data=urllib.parse.urlencode({"link": base}).encode(),
                       headers={"Authorization": "Bearer " + token, "Content-Type": "application/x-www-form-urlencoded"})
    if st == 200:
        return json.loads(body.decode("utf-8")).get("id")
    return None


def rd_sub_tracks(rd_id, token):
    """Tracce di sottotitoli del file secondo Real-Debrid: [{"lang", "name", "type"}]"""
    info = _rd_get("/streaming/mediaInfos/%s" % rd_id, token) or {}
    subs = ((info.get("details") or {}).get("subtitles")) or {}
    out = []
    for k, v in (subs.items() if isinstance(subs, dict) else enumerate(subs)):
        v = v or {}
        out.append({"lang": lang_code(v.get("lang_iso") or v.get("lang") or "") or "", "name": v.get("lang") or str(k),
                    "type": v.get("type") or "", "stream": v.get("stream")})
    return out


def _abs(base, ref):
    return urllib.parse.urljoin(base, ref.strip())


def rd_hls_subtitles(rd_id, token):
    """Sottotitoli dello streaming HLS di Real-Debrid: [(lingua, nome, url della playlist)]"""
    tr = _rd_get("/streaming/transcode/%s" % rd_id, token) or {}
    apple = tr.get("apple") or {}
    master = next(iter(apple.values()), "") if isinstance(apple, dict) else apple
    if not master:
        return []
    st, body, h = http(master, timeout=20)
    if st != 200:
        return []
    text = body.decode("utf-8", "replace")
    out = []
    for line in text.splitlines():
        if line.startswith("#EXT-X-MEDIA") and "TYPE=SUBTITLES" in line:
            attrs = dict(re.findall(r'([A-Z\-]+)=("[^"]*"|[^,]*)', line))
            uri = attrs.get("URI", "").strip('"')
            if uri:
                out.append((lang_code(attrs.get("LANGUAGE", "").strip('"')) or "", attrs.get("NAME", "").strip('"'), _abs(master, uri)))
    return out


def rd_download_vtt(playlist_url, workers=8):
    """Scarica tutti i pezzi WebVTT di una playlist di sottotitoli e li unisce in un unico .srt"""
    st, body, h = http(playlist_url, timeout=20)
    if st != 200:
        raise Exception("playlist dei sottotitoli non disponibile (%d)" % st)
    text = body.decode("utf-8", "replace")
    if "#EXTM3U" not in text:
        segs = [playlist_url]     # è già il file .vtt
    else:
        segs = [_abs(playlist_url, l) for l in text.splitlines() if l.strip() and not l.startswith("#")]
    from concurrent.futures import ThreadPoolExecutor

    def get(u):
        try:
            st2, b2, h2 = http(u, timeout=30)
            return b2.decode("utf-8", "replace") if st2 == 200 else ""
        except Exception:
            return ""
    with ThreadPoolExecutor(max_workers=workers) as ex:
        parts = list(ex.map(get, segs))
    cues, seen = [], set()
    first_map = None
    for part in parts:
        shift = 0
        m = re.search(r"X-TIMESTAMP-MAP=MPEGTS:(\d+),LOCAL:([\d:.]+)", part) or re.search(r"X-TIMESTAMP-MAP=LOCAL:([\d:.]+),MPEGTS:(\d+)", part)
        if m:
            mpegts, local = (int(m.group(1)), m.group(2)) if m.group(1).isdigit() else (int(m.group(2)), m.group(1))
            here = mpegts / 90.0 - (_ms(local) or 0)
            if first_map is None:
                first_map = here
            shift = int(here - first_map)     # i tempi sono relativi all'inizio dello streaming
        for c in parse_subs(part):
            key = (c["s"] + shift, c["t"])
            if key in seen:
                continue                       # frase ripetuta a cavallo di due pezzi
            seen.add(key)
            cues.append({"s": c["s"] + shift, "e": c["e"] + shift, "t": c["t"]})
    cues.sort(key=lambda c: c["s"])
    return cues


def cues_to_srt(cues):
    return "\n".join("%d\n%s --> %s\n%s\n" % (n, ms_srt(c["s"]), ms_srt(c["e"]), c["t"]) for n, c in enumerate(cues, 1))


# ====================================================================== sottotitoli dentro un .mkv in streaming
class LinkGone(Exception):
    pass


def http_range_reader(url, timeout=30):
    """Funzione read(offset, lunghezza) che legge solo quel pezzo del file con una richiesta Range.
    Ogni thread tiene aperta la sua connessione (keep-alive): i server come Real-Debrid chiudono le connessioni
    se se ne aprono troppe di fila, e così si evita anche una stretta di mano TLS per ogni frase.
    Se una richiesta fallisce: nuova connessione e altri tentativi, aspettando un po' di più ogni volta."""
    local = threading.local()
    state = {"url": url}
    opened, lock = set(), threading.Lock()

    def drop():
        c = getattr(local, "c", None)
        local.c = None
        if c is not None:
            with lock:
                opened.discard(c)
            try:
                c.close()
            except Exception:
                pass

    def close_all():
        """Chiude tutte le connessioni rimaste aperte (anche quelle dei thread finiti): il server le conta"""
        with lock:
            cs = list(opened)
            opened.clear()
        for c in cs:
            try:
                c.close()
            except Exception:
                pass

    def conn():
        if getattr(local, "c", None) is None:
            u = urllib.parse.urlsplit(state["url"])
            if u.scheme == "https":
                local.c = httpclient.HTTPSConnection(u.hostname, u.port, timeout=timeout)
            else:
                local.c = httpclient.HTTPConnection(u.hostname, u.port, timeout=timeout)
            with lock:
                opened.add(local.c)
        elif local.c not in opened:     # chiusa da close_all: ne apro un'altra
            local.c = None
            return conn()
        return local.c

    def read(offset, length):
        last = None
        for attempt in range(3):
            try:
                u = urllib.parse.urlsplit(state["url"])
                c = conn()
                c.request("GET", (u.path or "/") + ("?" + u.query if u.query else ""),
                          headers={"User-Agent": UA, "Range": "bytes=%d-%d" % (offset, offset + length - 1)})
                r = c.getresponse()
                if r.status in (301, 302, 303, 307, 308):
                    loc = r.getheader("Location", "")
                    drop()
                    state["url"] = urllib.parse.urljoin(state["url"], loc)
                    continue
                if r.status in (403, 404, 410):
                    drop()
                    raise LinkGone("link del video non più valido (%d)" % r.status)
                if r.status == 200:
                    data = r.read(length)
                    drop()      # il server manda tutto il file: chiudo
                    if offset > 0:
                        raise LinkGone("il server non permette di leggere solo una parte del file")
                    return data
                if r.status != 206:
                    r.read()
                    raise Exception("risposta %d" % r.status)
                data = r.read()
                if r.getheader("Connection", "").lower() == "close":
                    drop()
                return data[:length]
            except LinkGone:
                raise
            except Exception as e:
                last = e
                drop()
                time.sleep(min(0.4 * (2 ** attempt), 8))
        raise last
    read.close_all = close_all
    return read


def mkv_tracks(url):
    """Tracce di sottotitoli di testo dentro un .mkv raggiungibile via http: [{"num", "lang", "name", "codec", "forced"}]"""
    from . import mkvsubs
    reader = http_range_reader(url)
    m = mkvsubs.MkvSubtitles(reader).open()
    reader.close_all()
    out = []
    for t in m.subtitle_tracks():
        out.append(dict(t, lang=lang_code(t["lang"]) or t["lang"]))
    return out, m


def mkv_read(url, track, log=None, info=None, progress=None, known=None):
    """Frasi della traccia. In `info` (se dato): "totale" = frasi nell'indice, "mancanti" = quelle non lette,
    "lette" = tutte quelle lette (da passare come `known` la volta dopo, se mancava qualcosa)"""
    from . import mkvsubs
    reader = http_range_reader(url)
    try:
        m = mkvsubs.MkvSubtitles(reader, log).open()
        cues = m.read_track(track, progress=progress, known=known)
    finally:
        reader.close_all()
    if info is not None:
        info.update(totale=m.total, mancanti=m.missing, lette=getattr(m, "known", {}))
    return cues


def online_subtitles(imdb, langs, season="", episode="", filename="", info=None):
    """Sottotitoli disponibili su OpenSubtitles per quel film/puntata nelle lingue chieste: [(indirizzo, lingua)].
    In `info` (se dato) scrive cosa è successo, per il registro di Kodi."""
    info = info if info is not None else {}
    if not imdb.startswith("tt"):
        info["errore"] = "codice IMDb mancante"
        return []
    kind = "series" if season and episode else "movie"
    vid = imdb + (":%s:%s" % (int(season), int(episode)) if kind == "series" else "")
    tries = ["/filename=" + urllib.parse.quote(filename), ""] if filename else [""]
    subs, seen = [], set()
    for extra in tries:
        url = "%s/subtitles/%s/%s%s.json" % (OPENSUBS, kind, vid, extra)
        cached = _OS_CACHE.get(url)
        if cached and time.time() - cached[0] < 1800:
            info.setdefault("risposte", []).append("memoria")
            subs = cached[1]
            if subs:
                break
            continue
        try:
            st, body, h = http(url, headers={"Accept": "application/json"}, timeout=20)
        except Exception as e:
            info.setdefault("risposte", []).append("errore %r" % e)
            continue
        info.setdefault("risposte", []).append(st)
        if st != 200:
            info["inizio_risposta"] = body[:160].decode("utf-8", "replace")
            continue
        try:
            got = json.loads(body.decode("utf-8")).get("subtitles") or []
        except Exception:
            info["inizio_risposta"] = body[:160].decode("utf-8", "replace")
            continue
        for x in got:
            if x.get("url") and x["url"] not in seen:
                seen.add(x["url"])
                subs.append(x)
        _OS_CACHE[url] = (time.time(), list(subs))
        if subs:
            break
    info["totale"] = len(subs)
    info["lingue"] = sorted(set(str(x.get("lang", "")) for x in subs))[:40]
    out = []
    for lang in langs:
        codes = OS_CODES.get(lang, [lang])
        out += [(x["url"], lang) for x in subs if str(x.get("lang", "")).lower() in codes]
    return out


TEXT_SUB_CODECS = ("subrip", "srt", "ass", "ssa", "mov_text", "webvtt", "text")


def list_sub_streams(ffmpeg, media):
    """Tracce di sottotitoli dentro il file video: [(indice ffmpeg, lingua, codec, è_testo)]"""
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        p = subprocess.run([ffmpeg, "-nostdin", "-hide_banner", "-i", media], capture_output=True, timeout=60, creationflags=flags)
    except Exception:
        return []
    out = []
    for m in re.finditer(r"Stream #0:(\d+)(?:\[[^\]]*\])?(?:\(([a-z]{2,3})\))?: Subtitle: ([a-z_]+)", p.stderr.decode("utf-8", "replace")):
        codec = m.group(3)
        out.append((int(m.group(1)), FILE_TAGS.get(m.group(2) or "", m.group(2) or ""), codec, codec in TEXT_SUB_CODECS))
    return out


def extract_sub_stream(ffmpeg, media, index):
    """Testo .srt di una traccia di sottotitoli incorporata (solo quelle di testo, non le immagini)"""
    flags = 0x08000000 if os.name == "nt" else 0
    p = subprocess.run([ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-i", media, "-map", "0:%d" % index,
                        "-f", "srt", "-"], capture_output=True, timeout=300, creationflags=flags)
    text = p.stdout.decode("utf-8", "replace")
    if p.returncode != 0 or "-->" not in text:
        raise Exception("ffmpeg non riesce a leggere quella traccia di sottotitoli")
    return text


def _multipart(fields, file_field, filename, data, mime):
    boundary = uuid.uuid4().hex
    out = []
    for k, v in fields:
        out.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (boundary, k, v)).encode("utf-8"))
    out.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\nContent-Type: %s\r\n\r\n"
                % (boundary, file_field, filename, mime)).encode("utf-8"))
    out.append(data)
    out.append(("\r\n--%s--\r\n" % boundary).encode("utf-8"))
    return b"".join(out), "multipart/form-data; boundary=" + boundary


def whisper_request(path, settings, language="", prompt=""):
    stt = settings.get("stt", "groq") or "groq"
    local = stt == "local"
    openai = stt == "openai"
    base = (settings.get("stt_url") or "http://localhost:8000/v1") if local else \
        "https://api.openai.com/v1" if openai else "https://api.groq.com/openai/v1"
    model = settings.get("stt_model") or "whisper-large-v3-turbo"
    if openai and model.startswith("whisper-large"):
        model = "whisper-1"   # i modelli "large" sono di Groq: OpenAI ha whisper-1
    service = "OpenAI Whisper" if openai else "Il server di trascrizione" if local else "Groq Whisper"
    fields = [("model", model), ("response_format", "verbose_json"),
              ("temperature", "0")]
    if not local or settings.get("stt_words", True):
        # tempi delle singole parole: i sottotitoli cominciano quando comincia davvero la frase
        fields += [("timestamp_granularities[]", "word"), ("timestamp_granularities[]", "segment")]
    if language:
        fields.append(("language", language))
    if prompt:
        fields.append(("prompt", prompt[-400:]))
    with open(path, "rb") as f:
        body, ctype = _multipart(fields, "file", os.path.basename(path), f.read(), "audio/ogg")
    headers = {"Content-Type": ctype}
    if not local:
        key = settings.get("openai_key" if openai else "groq_key", "")
        if not key:
            raise Fatal("Manca la chiave %s nelle impostazioni dell'add-on (Trascrizione)" % ("OpenAI" if openai else "Groq"))
        headers["Authorization"] = "Bearer " + key
    for _ in range(4):
        st, raw, h = http(base.rstrip("/") + "/audio/transcriptions", body, headers, timeout=300)
        if st == 400 and local and settings.get("stt_words", True) and b"timestamp" in raw:
            s2 = dict(settings); s2["stt_words"] = False      # server locale senza i tempi delle parole
            return whisper_request(path, s2, language, prompt)
        quota_check(st, raw, h, service)          # quota finita: errore chiaro subito, niente attese infinite
        try:
            _check(st, raw, h, service)
        except RateLimited as e:
            time.sleep(e.wait)
            continue
        return json.loads(raw.decode("utf-8"))
    raise QuotaError("%s continua a rifiutare le richieste: riprova più tardi. La parte già trascritta è salvata." % service)


def _wait_seconds(text, headers):
    """Quanto aspettare secondo il servizio: intestazione Retry-After o "try again in 22m45.5s" nel messaggio"""
    try:
        w = float(headers.get("Retry-After") or headers.get("retry-after") or 0)
    except (TypeError, ValueError):
        w = 0
    m = re.search(r"try again in\s+(?:(\d+)h)?\s*(?:(\d+)m)?\s*(?:([\d.]+)s)?", text, re.I)
    if m and any(m.groups()):
        w = max(w, int(m.group(1) or 0) * 3600 + int(m.group(2) or 0) * 60 + float(m.group(3) or 0))
    return w


def _minutes(sec):
    sec = int(sec + 59) // 60
    return "%d ore e %d minuti" % (sec // 60, sec % 60) if sec >= 60 else "%d minut%s" % (sec, "o" if sec == 1 else "i")


def quota_check(status, raw, headers, service):
    """Errori che non passano aspettando qualche secondo: quota di audio del giorno o dell'ora finita, credito finito.
    Diventano un errore chiaro (Fatal) invece di tentativi che durano minuti."""
    text = raw.decode("utf-8", "replace") if isinstance(raw, bytes) else str(raw or "")
    if status == 402 or re.search(r"insufficient|credit balance|out of credits|no credits|billing|organization_restricted|exceeded your current quota", text, re.I):
        raise QuotaError("%s: credito o quota dell'account finiti. Controlla il tuo account (per Groq: console.groq.com). "
                    "La parte già trascritta è salvata." % service)
    if status != 429:
        return
    lim = re.search(r"Limit:?\s*(\d+)", text)
    hours = (" (%s ore di audio)" % ("%.1f" % (int(lim.group(1)) / 3600.0)).replace(".", ",")) if lim else ""
    wait = _wait_seconds(text, headers)
    if re.search(r"per day|ASPD|PerDay|daily", text, re.I):
        raise QuotaError("%s: hai finito i minuti di trascrizione gratuiti di oggi%s. %sLa parte già trascritta è salvata: "
                    "quando rifai partire la trascrizione riprende da lì." % (
                        service, hours, ("Si libera di nuovo tra circa %s. " % _minutes(wait)) if wait else "Si libera poco a poco nelle prossime ore. "))
    if re.search(r"per hour|ASPH", text, re.I) or wait > 120:
        raise QuotaError("%s: hai raggiunto il limite di audio trascritto in un'ora%s. Riprova tra %s: la parte già trascritta "
                    "è salvata e la trascrizione riprende da lì." % (service, hours, _minutes(wait or 3600)))


def _split_long(text, start, end):
    parts = [p for p in re.split(r"(?<=[.!?…])\s+", text) if p]
    if len(parts) <= 1 or end - start < 6:
        return [(start, end, text)]
    total = float(sum(len(p) for p in parts)) or 1.0
    out, t = [], start
    for p in parts:
        d = (end - start) * len(p) / total
        out.append((t, t + d, p))
        t += d
    return out


def whisper_lang(r):
    """Lingua riconosciuta da Whisper → sigla ("danish" → "da"; a volte arriva già la sigla)"""
    l = (r.get("language") or "").strip().lower()
    return WHISPER_LANGS.get(l) or (l if re.match(r"^[a-z]{2,3}$", l) else "")


def _conf(r):
    segs = r.get("segments") or []
    w = sum(max(0.2, (x.get("end") or 0) - (x.get("start") or 0)) for x in segs) or 1
    return sum((x.get("avg_logprob") or -1) * max(0.2, (x.get("end") or 0) - (x.get("start") or 0)) for x in segs) / w


def _piece_text(r):
    return " ".join((s.get("text") or "").strip() for s in (r.get("segments") or []))


def _seg_cues(sg, words, offset_ms):
    """Frasi di un segmento di Whisper con i tempi veri: dalla prima all'ultima parola pronunciata.
    Whisper a volte fa cominciare un segmento molto prima (durante musica o silenzio) o ci incolla parlato
    lontano: con i tempi delle parole il sottotitolo parte quando parte la voce, e si divide dove c'è una pausa lunga."""
    text = (sg.get("text") or "").strip()
    a, b = sg.get("start") or 0, sg.get("end") or 0
    ws = [w for w in words if (w.get("start") or 0) >= a - 0.3 and (w.get("end") or 0) <= b + 0.3 and (w.get("word") or "").strip()]
    out = []
    if ws:
        # pezzi separati da pause lunghe (oltre 2,5 s) dentro lo stesso segmento
        groups, cur = [], [ws[0]]
        for w in ws[1:]:
            if (w.get("start") or 0) - (cur[-1].get("end") or 0) > 2.5:
                groups.append(cur); cur = [w]
            else:
                cur.append(w)
        groups.append(cur)
        toks = text.split()
        if sum(len(g) for g in groups) == len(toks):
            k = 0
            for g in groups:
                part = " ".join(toks[k:k + len(g)]); k += len(g)
                out += _split_words(part, g)
        else:
            # le parole non coincidono con il testo: uso solo l'inizio e la fine veri
            out += _split_long(text, ws[0].get("start") or a, ws[-1].get("end") or b)
    else:
        out += _split_long(text, a, b)
    return [{"s": int(offset_ms + x * 1000), "e": int(offset_ms + max(y, x + 0.5) * 1000), "t": t} for x, y, t in out if t.strip()]


def _split_words(text, ws):
    """Divide in frasi (. ! ? …) usando i tempi delle parole"""
    toks = text.split()
    out, start = [], 0
    for i, t in enumerate(toks):
        if re.search(r"[.!?…]$", t) or i == len(toks) - 1:
            if i - start >= 0:
                out.append(((ws[start].get("start") or 0), (ws[i].get("end") or 0) + 0.15, " ".join(toks[start:i + 1])))
            start = i + 1
    return out


def speech_spans(ffmpeg, path):
    """Parti con suono (non silenzio) di un pezzo audio, in secondi: [(inizio, fine)]"""
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        p = subprocess.run([ffmpeg, "-nostdin", "-hide_banner", "-i", path, "-af", "silencedetect=noise=-32dB:d=0.6", "-f", "null", "-"],
                           capture_output=True, timeout=180, creationflags=flags)
    except Exception:
        return []
    err = p.stderr.decode("utf-8", "replace")
    dur = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", err)
    total = int(dur.group(1)) * 3600 + int(dur.group(2)) * 60 + float(dur.group(3)) if dur else 600.0
    spans, t = [], 0.0
    for m in re.finditer(r"silence_start:\s*([\d.]+)|silence_end:\s*([\d.]+)", err):
        if m.group(1) is not None:
            st = float(m.group(1))
            if st > t:
                spans.append((t, st))
        else:
            t = float(m.group(2))
    if t < total:
        spans.append((t, total))
    return spans


def audio_energy(ffmpeg, media, start, dur, timeout=240):
    """Energia della voce (300–3400 Hz) ogni 0,1 s in un tratto del film: [dB]. Si legge solo quel tratto
    (anche da un film in streaming: ffmpeg salta lì con le richieste Range)."""
    flags = 0x08000000 if os.name == "nt" else 0
    af = "aresample=16000,highpass=f=300,lowpass=f=3400,asetnsamples=n=1600:p=0,astats=metadata=1:reset=1," \
         "ametadata=mode=print:key=lavfi.astats.Overall.RMS_level:file=-"
    cmd = [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-ss", "%.2f" % max(0, start), "-t", "%.2f" % dur,
           "-i", media, "-vn", "-sn", "-map", "0:a:0", "-ac", "1", "-af", af, "-f", "null", "-"]
    p = subprocess.run(cmd, capture_output=True, timeout=timeout, creationflags=flags)
    text = p.stdout.decode("utf-8", "replace")
    # ogni valore con il suo tempo (pts_time): così la scala dei tempi è giusta anche se qualche pezzo manca
    out, t = [None] * int(dur * 10 + 1), None
    first = None
    for m in re.finditer(r"pts_time:([\d.]+)|RMS_level=(-?[\d.]+|-inf|inf|nan)", text):
        if m.group(1) is not None:
            t = float(m.group(1))
            if first is None:
                first = t
        elif t is not None:
            v = m.group(2)
            k = int(round((t - first) * 10))
            if 0 <= k < len(out):
                out[k] = -100.0 if v in ("-inf", "nan") else max(-100.0, float(v))
    last = -100.0
    for k in range(len(out)):          # buchi: valore precedente
        if out[k] is None:
            out[k] = last
        last = out[k]
    n = max((k for k in range(len(out)) if out[k] is not None and out[k] != -100.0), default=-1) + 1
    return out[:n]


SYNC_SCALES = (1.0, 25 / 23.976, 23.976 / 25, 25 / 24.0, 24 / 25.0)


def sync_score_tables(windows):
    """windows: [(inizio_s, [dB ogni 0,1 s])] → tabelle per il calcolo veloce (somme progressive dei valori normalizzati)"""
    tabs = []
    for t0, en in windows:
        if len(en) < 100:
            continue
        vals = sorted(en)
        med = vals[len(vals) // 2]
        spread = (vals[int(len(vals) * 0.9)] - vals[int(len(vals) * 0.1)]) or 1.0
        pre = [0.0]
        for v in en:
            pre.append(pre[-1] + (v - med) / spread)
        tabs.append((t0, len(en), pre))
    return tabs


def sync_score(cues, tabs, a, b):
    """Quanto le frasi (tempi trasformati t' = a·t + b) cadono dove c'è voce: media dell'energia normalizzata sotto le frasi"""
    tot, n = 0.0, 0
    for c in cues:
        s_ = a * c["s"] / 1000.0 + b
        e_ = a * c["e"] / 1000.0 + b
        for t0, ln, pre in tabs:
            i, j = int((s_ - t0) * 10), int((e_ - t0) * 10)
            if j <= 0 or i >= ln:
                continue
            i, j = max(0, i), min(ln, j)
            if j > i:
                tot += pre[j] - pre[i]
                n += j - i
    return (tot / n if n else -9.0), n


def best_sync(cues, windows, max_shift=90.0):
    """Spostamento (b, in secondi) e velocità (a) che mettono le frasi sopra la voce del film.
    Restituisce {"a", "b", "score", "base"}: base = punteggio senza modifiche."""
    tabs = sync_score_tables(windows)
    if not tabs:
        return None
    lo = min(t0 for t0, ln, pre in tabs) - max_shift - 30
    hi = max(t0 + ln / 10.0 for t0, ln, pre in tabs) + max_shift + 30
    near = [c for c in cues if lo * 1000 <= c["s"] <= hi * 1000 * 1.1]
    base, nb = sync_score(near, tabs, 1.0, 0.0)
    best = (base, 1.0, 0.0)
    for a in SYNC_SCALES:
        # per ogni velocità, lo spostamento che rimette in fase il centro dei tratti ascoltati
        mid = sum(t0 + ln / 20.0 for t0, ln, pre in tabs) / len(tabs)
        center = mid - a * mid
        k = -max_shift
        while k <= max_shift:
            sc, n = sync_score(near, tabs, a, center + k)
            if n >= 150 and sc > best[0]:
                best = (sc, a, center + k)
            k += 0.5
    sc, a, b0 = best
    b, k = b0, b0 - 0.6
    while k <= b0 + 0.6:
        s2, n = sync_score(near, tabs, a, k)
        if n >= 150 and s2 > sc:
            sc, b = s2, k
        k += 0.05
    return {"a": a, "b": round(b, 3), "score": round(sc, 3), "base": round(base, 3)}


def apply_sync(cues, a, b):
    return [dict(c, s=max(0, int(a * c["s"] + b * 1000)), e=max(0, int(a * c["e"] + b * 1000))) for c in cues]


def uncovered(spans, cues_sec, min_len=2.0, max_n=12, max_total=120.0):
    """Parti con suono dove non c'è nessuna frase trascritta (Whisper le ha saltate)"""
    out = []
    for a, b in spans:
        cur = a
        for x, y in sorted(cues_sec):
            if y < cur or x > b:
                continue
            if x - cur >= min_len:
                out.append((cur, x))
            cur = max(cur, y)
        if b - cur >= min_len:
            out.append((cur, b))
    merged = []
    for a, b in out:
        if merged and a - merged[-1][1] < 1.0:
            merged[-1] = (merged[-1][0], b)
        else:
            merged.append((a, b))
    merged = [(a, min(b, a + 30)) for a, b in merged]
    merged.sort(key=lambda x: -(x[1] - x[0]))
    pick, tot = [], 0.0
    for a, b in merged:
        if len(pick) >= max_n or tot + (b - a) > max_total:
            break
        pick.append((a, b)); tot += b - a
    return sorted(pick)


def cut_audio(ffmpeg, path, a, b, out):
    flags = 0x08000000 if os.name == "nt" else 0
    subprocess.run([ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-ss", "%.2f" % max(0, a - 0.3), "-t", "%.2f" % (b - a + 0.6),
                    "-i", path, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "libopus", "-b:a", "24k", out],
                   capture_output=True, timeout=120, creationflags=flags)
    return os.path.isfile(out) and os.path.getsize(out) > 200


def audio_duration(ffmpeg, media):
    """Durata in secondi (dalla riga «Duration:» di ffmpeg), 0 se non si capisce"""
    try:
        flags = 0x08000000 if os.name == "nt" else 0
        p = subprocess.run([ffmpeg, "-nostdin", "-hide_banner", "-i", media], capture_output=True, timeout=60, creationflags=flags)
        m = re.search(rb"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", p.stderr)
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else 0
    except Exception:
        return 0


def extract_piece(ffmpeg, media, workdir, n, piece_sec=600, stream=0):
    """Un pezzo da 10 minuti dell'audio (solo quello: «-ss» prima di «-i» salta direttamente lì, anche in streaming)"""
    out = os.path.join(workdir, "pezzo%03d.ogg" % n)
    cmd = [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-ss", str(n * piece_sec), "-i", media, "-t", str(piece_sec),
           "-map", "0:a:%d" % stream, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "libopus", "-b:a", "24k", out]
    flags = 0x08000000 if os.name == "nt" else 0
    subprocess.run(cmd, capture_output=True, creationflags=flags)
    return out if os.path.isfile(out) and os.path.getsize(out) > 2000 else None


def _do_piece(path, n, dom, prompt, settings, ffmpeg, workdir, should_stop, weak_hint=""):
    """Trascrive un pezzo (con la lingua dom, se già fissata). Restituisce (frasi, lingua fissata, lingua sentita)."""
    recent = []
    det = ""
    if dom:
        r = whisper_request(path, settings, dom, prompt)
    else:
        r = whisper_request(path, settings, "", prompt)
        det = whisper_lang(r)
        # lingua originale del film (dal catalogo): se Whisper ne riconosce un'altra, confronto le due versioni
        # e tengo quella del film, a meno che sia chiaramente peggiore
        if weak_hint and det and det != weak_hint and len(_piece_text(r)) >= 150:
            alt = whisper_request(path, settings, weak_hint, "")
            if _conf(alt) >= _conf(r) - 0.3 and guess_lang(_piece_text(alt)) in ("", weak_hint):
                r, det, dom = alt, weak_hint, weak_hint
        # la lingua si fissa solo con abbastanza parlato (non da una sigla musicale o da pochi secondi)
        if det and len(_piece_text(r)) >= 150:
            dom = det
            if guess_lang(_piece_text(r)) not in ("", det):
                r = whisper_request(path, settings, dom, prompt)   # ha scritto in un'altra lingua: rifaccio imponendola
    # controllo: testo in inglese in un film non inglese = Whisper ha tradotto invece di trascrivere
    if dom and dom != "en" and guess_lang(_piece_text(r)) == "en":
        r2 = whisper_request(path, settings, dom, "")
        if guess_lang(_piece_text(r2)) != "en":
            r = r2
    offset = n * 600 * 1000
    piece = []
    words = r.get("words") or []
    for sg in r.get("segments") or []:
        if is_junk(sg, recent):
            continue
        recent.append((sg.get("text") or "").strip())
        piece += _seg_cues(sg, words, offset)
    # parti con voce che Whisper ha saltato: le riascolto da sole (con la lingua del film)
    if settings.get("stt_gaps", True) and dom:
        spans = speech_spans(ffmpeg, path)
        holes = uncovered(spans, [((c["s"] - offset) / 1000.0, (c["e"] - offset) / 1000.0) for c in piece])
        for k, (a2, b2) in enumerate(holes):
            if should_stop and should_stop():
                break
            part = os.path.join(workdir, "buco%03d_%02d.ogg" % (n, k))
            if not cut_audio(ffmpeg, path, a2, b2, part):
                continue
            try:
                rr = whisper_request(part, settings, dom, " ".join(c["t"] for c in piece if c["s"] < offset + a2 * 1000)[-300:])
            except Fatal:
                raise
            except Exception:
                continue
            finally:
                try:
                    os.remove(part)
                except Exception:
                    pass
            start_ms = offset + max(0, a2 - 0.3) * 1000
            for sg in rr.get("segments") or []:
                if is_junk(sg, recent):
                    continue
                recent.append((sg.get("text") or "").strip())
                piece += [c for c in _seg_cues(sg, rr.get("words") or [], start_ms) if not any(
                    abs(c["s"] - p["s"]) < 400 and c["t"] == p["t"] for p in piece)]
        piece.sort(key=lambda c: c["s"])
    return piece, dom, det or dom


def transcribe(media, settings, workdir, on_progress=None, should_stop=None, hint="", done=None, on_piece=None, weak_hint="",
               audio_lang="", allow_dub=False, duration=0, workers=3):
    """Trascrizione dell'audio a pezzi da 10 minuti.
    La lingua si stabilisce una volta sola (impostazione "Lingua parlata", poi lingua della traccia audio indicata
    da Kodi, poi il primo pezzo con abbastanza parlato) e poi si impone a Whisper per tutti i pezzi: senza, Whisper
    a volte cambia lingua o scrive direttamente la traduzione in inglese invece di trascrivere.
    Più veloce (1.12): con la durata del film ogni pezzo si estrae da solo (prima si estraeva tutto l'audio del film
    prima di cominciare: minuti fermi, soprattutto in streaming) e fino a `workers` pezzi vanno a Whisper insieme.
    done: pezzi già trascritti {n: {"cues", "lang"}} (si riprende da dove si era fermata);
    on_piece(n, cues_del_pezzo, lingua): chiamata dopo ogni pezzo, per salvarlo."""
    ffmpeg = find_ffmpeg(settings.get("ffmpeg", ""))
    if not ffmpeg:
        raise Fatal("ffmpeg non trovato: installalo o indica il percorso nelle impostazioni dell'add-on")
    done = dict(done or {})
    dom = settings.get("stt_lang", "") or hint or next((d.get("lang") for d in done.values() if d.get("lang")), "")
    # la traccia audio nella lingua originale del film (non un doppiaggio, che spesso è la prima traccia)
    stream = pick_audio_stream(ffmpeg, media, audio_lang, allow_dub)
    dur = duration or 0
    if dur and dur > 0:
        total = max(1, int((dur + 599) // 600))
        get_path = lambda n: extract_piece(ffmpeg, media, workdir, n, 600, stream)
    else:
        if on_progress:
            on_progress(-1, 0)   # «leggo l'audio del film…»
        paths = extract_audio_pieces(ffmpeg, media, workdir, stream=stream)
        total = len(paths)
        get_path = lambda n: paths[n] if n < len(paths) else None
    results = {int(k): v["cues"] for k, v in done.items()}
    lock = threading.Lock()
    stopped = [False]

    def finish(n, piece, lang):
        with lock:
            results[n] = piece
            if on_piece:
                on_piece(n, piece, lang)

    todo = [n for n in range(total) if n not in results]
    if on_progress and todo:
        on_progress(len(results), total)
    # il primo pezzo da solo se la lingua non è ancora fissata (di solito la dice lui per tutti gli altri); poi in parallelo
    langs_seen = {}
    tries = 0
    while todo and not dom and tries < 1:
        tries += 1
        if should_stop and should_stop():
            stopped[0] = True
            break
        n = todo.pop(0)
        path = get_path(n)
        if not path:
            continue
        prompt = " ".join(c["t"] for c in (results.get(n - 1) or [])[-4:])
        piece, dom, heard = _do_piece(path, n, dom, prompt, settings, ffmpeg, workdir, should_stop, weak_hint)
        finish(n, piece, dom)
        heard = heard or guess_lang(" ".join(c["t"] for c in piece))
        if heard:
            langs_seen[heard] = langs_seen.get(heard, 0) + 1
        _rm(path)
        if on_progress:
            on_progress(len(results), total)

    def job(n):
        if stopped[0] or (should_stop and should_stop()):
            stopped[0] = True
            return
        path = get_path(n)
        if not path:
            return
        try:
            prompt = " ".join(c["t"] for c in (results.get(n - 1) or [])[-4:])
            piece, lang, heard = _do_piece(path, n, dom, prompt, settings, ffmpeg, workdir, should_stop, weak_hint if not dom else "")
            heard = lang or heard or guess_lang(" ".join(c["t"] for c in piece))
            if heard:
                with lock:
                    langs_seen[heard] = langs_seen.get(heard, 0) + 1
            finish(n, piece, lang)   # salvo solo la lingua fissata (quella sentita in un pezzo corto non basta per riprendere)
        finally:
            _rm(path)

    if todo and not stopped[0]:
        import concurrent.futures as cf
        with cf.ThreadPoolExecutor(max_workers=max(1, int(workers or 1))) as ex:
            futs = [ex.submit(job, n) for n in todo]
            pending = set(futs)
            # aspetto un secondo alla volta: intanto aggiorno la barra (Kodi la ridisegna solo da questo thread)
            while pending:
                ready, pending = cf.wait(pending, timeout=1.0)
                for f in ready:
                    try:
                        f.result()
                    except Fatal:
                        stopped[0] = True
                        for g in pending:
                            g.cancel()
                        raise
                if on_progress:
                    with lock:
                        n_ok = len(results)
                    on_progress(n_ok, total)
    if should_stop and should_stop():
        stopped[0] = True
    cues = []
    for n in sorted(results):
        cues += results[n]
    complete = not stopped[0] and all(n in results for n in range(total))
    if not dom and langs_seen:
        dom = max(langs_seen, key=langs_seen.get)   # la lingua della maggior parte dei pezzi
    return cues, dom, complete


def _rm(path):
    try:
        if path and os.path.isfile(path):
            os.remove(path)
    except Exception:
        pass

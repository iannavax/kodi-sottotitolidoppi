import json, re, time, urllib.parse, os, sys, threading
import asyncio
from playwright.async_api import async_playwright

EXT = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/v5/build/chrome"
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
AUDIO = open("/tmp/speech.wav", "rb").read()
WEBM = open("/tmp/speech.webm", "rb").read()
log = {"groq": [], "google": 0, "gemini": [], "errors": []}

def tr(x):
    # "traduzione" finta ma diversa dall'originale, come una vera: parole rovesciate
    return " ".join(w[::-1] for w in str(x).split())

def page_html(vid, has):
    return f"""<!doctype html><html><head><title>Video di prova - YouTube</title></head><body style="margin:0;background:#111">
<div id="movie_player" class="html5-video-player" style="position:relative;width:1000px;height:560px;background:#000;overflow:hidden">
  <video class="html5-main-video" style="width:100%;height:100%"></video>
  <div class="ytp-right-controls" style="position:absolute;top:0;right:0;display:flex"><button class="ytp-subtitles-button" aria-pressed="true">CC</button></div>
  <div class="ytp-caption-window-container" style="position:absolute;top:10px;left:10px;color:#fff">nativi</div>
</div>
<script>
const VID={json.dumps(vid)}, HAS={str(has).lower()};
// come il vero YouTube: il video arriva "a pezzi" (indirizzo blob:, non scaricabile)
if (VID.startsWith('diretta')) {{
  // come una diretta: MediaSource senza durata (Infinity)
  const ms = new MediaSource(); const v = document.querySelector('video'); v.src = URL.createObjectURL(ms);
  ms.addEventListener('sourceopen', async () => {{
    const sb = ms.addSourceBuffer('audio/webm; codecs="opus"');
    const data = await (await fetch('/media/speech.webm')).arrayBuffer();
    sb.addEventListener('updateend', () => {{ try {{ ms.duration = Infinity; }} catch (e) {{}} }}, {{ once: true }});
    sb.appendBuffer(data);
  }});
}} else fetch(VID.startsWith('noCapsBig') ? '/media/big.wav' : '/media/speech.wav').then(r=>r.blob()).then(b=>{{document.querySelector('video').src=URL.createObjectURL(b);}});
const p=document.getElementById('movie_player');
p.getVideoData=()=>({{video_id:VID}});
p.getPlayerResponse=()=>({{videoDetails:{{videoId:VID}},captions:HAS?{{playerCaptionsTracklistRenderer:{{captionTracks:[{{}}]}}}}:undefined}});
document.querySelector('video').addEventListener('click',e=>{{const v=e.target; v.paused?v.play():v.pause();}});
p.addEventListener('click',()=>{{window.__playerClicks=(window.__playerClicks||0)+1}});
const LANG=VID.startsWith('es')?'es':'en';
const askCaps=()=>{{const x=new XMLHttpRequest();x.open('GET','/api/timedtext?v='+VID+'&lang='+LANG+'&kind=asr&fmt=json3&pot=abc');x.send();}};
if(HAS) setTimeout(askCaps,400);
// come YouTube: il pulsante CC accende/spegne i sottotitoli e, riaccendendoli, li richiede di nuovo
document.querySelector('.ytp-subtitles-button').addEventListener('click',e=>{{const b=e.currentTarget; const on=b.getAttribute('aria-pressed')!=='true'; b.setAttribute('aria-pressed',String(on)); window.__ccClicks=(window.__ccClicks||0)+1; if(on&&HAS) askCaps();}});
</script></body></html>"""

def json3_long():
    events = []
    for i in range(120):
        events.append({"tStartMs": i * 3000, "dDurationMs": 2800, "segs": [{"utf8": f"this is sentence number {i+1}."}]})
    return {"events": events}

SHORT_LINES = ["Ja.", "we went to the market and bought bread", "Nej!", "Karen.", "Okay.", "then we walked home very slowly", "Tak."]
def json3_short():
    return {"events": [{"tStartMs": i * 2500, "dDurationMs": 2300, "segs": [{"utf8": l}]} for i, l in enumerate(SHORT_LINES)]}

def json3():
    words = "so we went to the market and bought some really fresh bread then we walked home slowly".split()
    events, t = [], 0
    for i in range(0, len(words), 4):
        grp = words[i:i+4]
        segs = [{"utf8": grp[0]}] + [{"utf8": " " + w, "tOffsetMs": 300*(k+1)} for k, w in enumerate(grp[1:])]
        events.append({"tStartMs": t, "dDurationMs": 3000, "segs": segs}); t += 1300
    # pausa lunga e seconda frase
    events.append({"tStartMs": t + 2500, "dDurationMs": 4000, "segs": [{"utf8": "it"}, {"utf8": " was", "tOffsetMs": 300}, {"utf8": " amazing", "tOffsetMs": 600}]})
    return {"events": events}

def ipa_fake(w):
    return "ˈ" + w.lower().replace("th", "θ").replace("sh", "ʃ").replace("ee", "iː")

def ipa_answer(who, user):
    words = json.loads(user)["words"]
    log.setdefault("ipa", []).append((who, list(words)))
    if os.environ.get("IPA_FAIL"):
        return json.dumps({"choices": [{"message": {"content": "non so"}}]})
    return json.dumps({"choices": [{"message": {"content": json.dumps({"ipa": {w: ipa_fake(w) for w in words}})}}]})

def multipart_file_size(body):
    m = re.search(rb'filename="audio\.wav"\r\nContent-Type: audio/wav\r\n\r\n', body)
    if not m: return -1
    start = m.end(); end = body.index(b"\r\n--", start)
    return end - start

async def handle(route, request):
    url = request.url
    if not url.startswith("http"):
        return await route.continue_()
    try:
        if url.startswith("https://www.youtube.com/media/speech.webm") or url.startswith("https://www.youtube-nocookie.com/media/speech.webm"):
            return await route.fulfill(status=200, content_type="audio/webm", body=WEBM)
        if url.startswith("https://www.youtube-nocookie.com/media/speech.wav"):
            return await route.fulfill(status=200, content_type="audio/wav", body=AUDIO)
        if re.match(r"https://www\.youtube(-nocookie)?\.com/embed/", url):
            u = urllib.parse.urlparse(url)
            vid = u.path.split("/")[2]
            ch = urllib.parse.parse_qs(u.query).get("channel", [""])[0]
            if vid == "live_stream": vid = "diretta" + ch   # il vero video della diretta del canale
            return await route.fulfill(status=200, content_type="text/html", body=page_html(vid, False))
        if url.startswith("https://www.youtube.com/watch"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            vid = q["v"][0]
            return await route.fulfill(status=200, content_type="text/html", body=page_html(vid, not vid.startswith("noCaps")))
        if url.startswith("https://example.test/"):
            path = urllib.parse.urlparse(url).path
            if path.endswith(".wav"):
                return await route.fulfill(status=200, content_type="audio/wav", body=AUDIO, headers={"Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*"})
            if path.endswith(".vtt"):
                vtt = "WEBVTT\n\n" + "\n".join(f"00:00:{i*3:02d}.000 --> 00:00:{i*3+2:02d}.800\nthis is caption number {i+1}.\n" for i in range(15))
                return await route.fulfill(status=200, content_type="text/vtt", body=vtt, headers={"Access-Control-Allow-Origin": "*"})
            pages = {
              "/video.html": '<h1>Un sito qualsiasi</h1><video id="v" src="/speech.wav" controls style="width:800px;height:450px;background:#000"></video>',
              "/track.html": '<video id="v" src="/speech.wav" controls crossorigin="anonymous" style="width:800px;height:450px;background:#000"><track kind="subtitles" srclang="en" src="/subs.vtt" default></video>',
              "/audio.html": '<h1>Podcast</h1><audio id="v" src="/speech.wav" controls></audio>',
              "/tvgarden.html": '<h1>Canale</h1><iframe id="f" src="https://www.youtube-nocookie.com/embed/abcdefghijk?autoplay=1" style="width:800px;height:450px;border:0" allow="autoplay"></iframe>',
              "/tvgarden-diretta.html": '<h1>Canale in diretta</h1><iframe id="f" src="https://www.youtube.com/embed/diretta1234?autoplay=1" style="width:800px;height:450px;border:0" allow="autoplay"></iframe>',
              "/iptv.html": '<h1>Sito IPTV</h1><video id="loro" src="/speech.wav" preload="auto" style="width:320px;height:180px;background:#000"></video><iframe id="f" src="https://www.youtube.com/embed/live_stream?channel=UCcccccccc" style="width:800px;height:450px;border:0" allow="autoplay"></iframe>',
              "/canaleA.html": '<iframe src="https://www.youtube.com/embed/live_stream?channel=UCaaaaaaaa" style="width:800px;height:450px;border:0" allow="autoplay"></iframe>',
              "/canaleB.html": '<iframe src="https://www.youtube.com/embed/live_stream?channel=UCbbbbbbbb" style="width:800px;height:450px;border:0" allow="autoplay"></iframe>',
              "/vimeo.html": '<h1>Come Vimeo</h1><video id="v" controls style="width:800px;height:450px;background:#000"></video><script>fetch("/speech.wav").then(r=>r.blob()).then(b=>{document.getElementById("v").src=URL.createObjectURL(b)})</script>',
            }
            if path in pages:
                return await route.fulfill(status=200, content_type="text/html", body=f"<!doctype html><html><head><title>Pagina {path}</title></head><body style='margin:20px'>{pages[path]}</body></html>")
            return await route.fulfill(status=404, body="")
        if url.startswith("https://www.youtube.com/media/big.wav"):
            return await route.fulfill(status=200, content_type="audio/wav", body=open("/tmp/big.wav","rb").read())
        if url.startswith("https://www.youtube.com/media/speech.wav"):
            return await route.fulfill(status=200, content_type="audio/wav", body=AUDIO, headers={"Accept-Ranges": "bytes"})
        if url.startswith("https://www.youtube.com/api/timedtext"):
            long = "v=long" in url
            if "v=shortCopy" in url:
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps(json3_short()))
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(json3_long() if long else json3()))
        if "/translate_tts" in url:
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            log.setdefault("tts", []).append((q.get("tl", [""])[0], q.get("q", [""])[0]))
            import io, wave as _w
            b = io.BytesIO(); ww = _w.open(b, "wb"); ww.setnchannels(1); ww.setsampwidth(2); ww.setframerate(16000); ww.writeframes(b"\x00\x10" * 8000); ww.close()
            return await route.fulfill(status=200, content_type="audio/mpeg", body=b.getvalue())
        if url.startswith("https://translate.googleapis.com/"):
            log["google"] += 1
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            text = q.get("q", [""])[0]
            if "bd" in q.get("dt", []) and q.get("sl", [""])[0] == "it":
                # traduzione inversa di una parola (dalla traduzione all'originale): la simulata rovescia le lettere
                log.setdefault("wordback", []).append(text)
                body = [[[tr(text), text]], [["sostantivo", [tr(text)]]], "it"]
            elif "bd" in q.get("dt", []):
                body = [[["pane", text]], [["sostantivo", ["pane", "pagnotta"]]], "en"]
            else:
                # i nomi Google li lascia uguali; le risposte brevi le traduce
                SHORT = {"ja.": "Sì.", "nej!": "No!", "tak.": "Grazie.", "karen.": "Karen.", "okay.": "Okay."}
                log.setdefault("gtexts", []).extend(text.split("\n"))
                body = [[["\n".join(SHORT.get(l.lower(), "IT[" + tr(l) + "]") for l in text.split("\n")), text]], None, "en"]
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
        if url.startswith("https://api.groq.com/openai/v1/audio/transcriptions"):
            if os.environ.get("GROQ_LIMIT") and len(log["groq"]) >= 2:
                # quota di Groq finita: "hour" = audio dell'ultima ora (ASH), "day" = audio del giorno (ASD)
                log["glimit"] = log.get("glimit", 0) + 1
                if os.environ["GROQ_LIMIT"] == "credit":
                    return await route.fulfill(status=402, content_type="application/json",
                        body=json.dumps({"error": {"message": "Your organization has insufficient credit balance. Please add credits.", "code": "insufficient_quota"}}))
                what = "audio seconds per day (ASD): Limit 28800" if os.environ["GROQ_LIMIT"] == "day" else "audio seconds per hour (ASH): Limit 7200"
                return await route.fulfill(status=429, content_type="application/json", headers={"retry-after": "130"},
                    body=json.dumps({"error": {"message": f"Rate limit reached for model `whisper-large-v3-turbo` on {what}, Used 7190, Requested 12. Please try again in 2m10s.", "type": "audio_seconds", "code": "rate_limit_exceeded"}}))
            if os.environ.get("GROQ_429") and len(log["groq"]) == 2 and not log.get("g429"):
                log["g429"] = True
                return await route.fulfill(status=429, content_type="application/json", headers={"retry-after": "3"}, body='{"error":{"message":"Rate limit reached"}}')
            raw = request.post_data_buffer or b""
            ctype = (await request.all_headers()).get("content-type", "")
            boundary = ctype.split("boundary=")[-1].encode()
            fm = re.search(rb'name="file"; filename="([^"]+)"\r\n[^\r]*\r\n\r\n', raw)
            fdata = raw[fm.end(): raw.index(b"\r\n--" + boundary, fm.end())] if fm else b""
            if fdata[:4] == b"RIFF":
                secs = (len(fdata) - 44) / int.from_bytes(fdata[28:32], "little")
            else:
                secs = 66.7
            log.setdefault("groq_files", []).append((fm.group(1).decode() if fm else "?", len(fdata)))
            lang_forced = re.search(rb'name="language"\r\n\r\n([a-z]+)', raw)
            lang_forced = lang_forced.group(1).decode() if lang_forced else ""
            n = len(log["groq"]) + 1
            log["groq"].append(round(secs, 2))
            log.setdefault("groq_lang", []).append(lang_forced)
            italian = os.environ.get("LANG_FLIP") and n == 2 and not lang_forced
            if os.environ.get("GROQ_LANG"):
                # Whisper simulato: il video passa dall'inglese all'italiano dal pezzo LANG_SWITCH_AT;
                # il pezzo MISDETECT viene riconosciuto (male) come italiano; il pezzo JUNK_AT è musica.
                import hashlib
                hkey = hashlib.md5(fdata).hexdigest()
                order = log.setdefault("audio_order", [])
                if hkey not in order: order.append(hkey)
                k = order.index(hkey) + 1
                true_lang = "it" if k >= int(os.environ.get("LANG_SWITCH_AT", "99")) else "en"
                text_for = lambda l: (f" questa è la frase italiana numero {k} del video" if l == "it" else f" this is english sentence number {k} of the video")
                if str(k) == os.environ.get("JUNK_AT"):
                    segs = [{"start": 0.3, "end": min(secs, 2.0), "text": " I'm sorry.", "no_speech_prob": 0.45, "avg_logprob": -0.7, "compression_ratio": 1.1}]
                    lang_out = "english"
                elif lang_forced:
                    good = lang_forced == true_lang
                    txt = text_for(lang_forced) if good else (" traduzione forzata numero " + str(k) if lang_forced == "it" else " forced translation number " + str(k))
                    segs = [{"start": 0.1, "end": max(0.5, secs - 0.1), "text": txt, "no_speech_prob": 0.02, "avg_logprob": -0.2 if good else -0.9}]
                    lang_out = {"it": "italian", "en": "english"}[lang_forced]
                else:
                    det = "it" if str(k) == os.environ.get("MISDETECT") else true_lang
                    good = det == true_lang
                    txt = text_for(det) if good else " traduzione sbagliata numero " + str(k)
                    segs = [{"start": 0.1, "end": max(0.5, secs - 0.1), "text": txt, "no_speech_prob": 0.02, "avg_logprob": -0.2 if good else -0.8}]
                    lang_out = {"it": "italian", "en": "english"}[det]
                mm = re.search(rb'name="model"\r\n\r\n([\w.-]+)', raw)
                model = mm.group(1).decode() if mm else ""
                if model == "whisper-large-v3":
                    for x in segs: x["text"] = x["text"].rstrip() + " (preciso)"
                log.setdefault("groq_req", []).append((k, lang_forced or "auto", segs[0]["text"].strip(), model))
                await asyncio.sleep(0.3)
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"language": lang_out, "segments": segs}))
            if os.environ.get("GROQ_LONG"):
                # un solo segmento enorme con più frasi, e i tempi delle parole
                txt = f"Chunk {n} starts here and it keeps going for a while. Then there is a second sentence, which is longer than the first one and has a comma. Ok?"
                ws = txt.replace(".", "").replace(",", "").replace("?", "").split()
                step = max(0.2, (secs - 0.4) / len(ws))
                body = {"language": "english", "segments": [{"start": 0.1, "end": secs - 0.2, "text": " " + txt, "no_speech_prob": 0.02, "avg_logprob": -0.3}],
                        "words": [{"word": w, "start": 0.1 + i * step, "end": 0.1 + i * step + step * 0.8} for i, w in enumerate(ws)]}
                await asyncio.sleep(0.4)
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
            if secs > 20:
                segs = [{"start": k * 6 + 0.2, "end": min(secs, k * 6 + 5.5), "text": f" parte {n} frase {k+1}", "no_speech_prob": 0.02, "avg_logprob": -0.3} for k in range(int(secs // 6))]
                if os.environ.get("GAP") and secs > 120:   # Whisper "salta" un minuto (60-120 s del pezzo)
                    segs = [x for x in segs if not (60 <= x["start"] < 120)]
            else:
                segs = [{"start": 0.1, "end": max(0.5, secs - 0.1), "text": (f" questa frase italiana {n}" if italian else f" frase numero {n}"), "no_speech_prob": 0.02, "avg_logprob": -0.3}]
            body = {"language": "italian" if italian else "english", "segments": segs}
            await asyncio.sleep(0.4)
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
        if url.startswith("https://api.mistral.ai/v1/chat/completions"):
            payload = json.loads(request.post_data or "{}")
            user = payload["messages"][1]["content"]
            log.setdefault("mistral", []).append(1)
            if payload["messages"][0]["content"].startswith("You align"):
                u = json.loads(user)
                its = u.get("items") or []
                content = json.dumps({"items": [{"pairs": [[w, w[::-1]] for w in it["translation"].replace("MIS[", "").replace("]", "").split()], "idioms": []} for it in its]})
            elif "Word:" in user or "Expression:" in user:
                content = json.dumps({"lemma": "", "pos": "", "meaning": "MISDEF", "explanation": "", "example": "", "example_translation": "", "lang": "en"})
            else:
                segs = json.loads(user)["segments"]
                sysmsg = payload["messages"][0]["content"]
                if '"src"' in sysmsg:
                    content = json.dumps({"src": segs, "t": ["MIS[" + tr(x) + "]" for x in segs]})
                else:
                    content = json.dumps({"t": ["MIS[" + tr(x) + "]" for x in segs]})
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": content}}]}))
        if url.startswith("https://generativelanguage.googleapis.com/"):
            now = time.time()
            g = log.setdefault("gcalls", [])
            rpm = int(os.environ.get("GEM_RPM", "10")); daily = int(os.environ.get("GEM_DAILY", "100000"))
            ok = [c for c in g if c[1] == 200]
            if len(ok) >= daily:
                g.append((now, "day"))
                return await route.fulfill(status=429, content_type="application/json", body='[{"error":{"code":429,"message":"You exceeded your current quota","status":"RESOURCE_EXHAUSTED","details":[{"@type":"type.googleapis.com/google.rpc.QuotaFailure","violations":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel-FreeTier"}]}]}}]')
            if len([c for c in g if now - c[0] < 60]) >= rpm:
                g.append((now, "min"))
                return await route.fulfill(status=429, content_type="application/json", body='[{"error":{"code":429,"message":"quota","details":[{"quotaId":"GenerateRequestsPerMinutePerProjectPerModel-FreeTier"},{"retryDelay":"10s"}]}}]')
            g.append((now, 200))
            payload = json.loads(request.post_data or "{}")
            user = payload["messages"][1]["content"]
            if payload["messages"][0]["content"].startswith("You are an expert phonetician"):
                return await route.fulfill(status=200, content_type="application/json", body=ipa_answer("gemini", user))
            if payload["messages"][0]["content"].startswith("You align"):
                u = json.loads(user)
                its = u.get("items") or [{"original": u.get("original"), "translation": u.get("translation")}]
                log.setdefault("align", []).append(its[0]["original"])
                log.setdefault("align_items", []).append(len(its))
                out_items = []
                for it in its:
                    tw = it["translation"].replace("GEM[", "").replace("MIS[", "").replace("]", "").split()
                    out_items.append({"pairs": [[w, w[::-1]] for w in tw], "idioms": [{"text": "fresh bread", "meaning": "MODO[pane appena fatto]"}] if "fresh bread" in it["original"] else []})
                pairs = out_items[0]["pairs"]
                if os.environ.get("ALIGN_GAPS"):   # il modello lascia vuoto l'originale per alcune parole
                    pairs = [[a, "" if k % 2 else b] for k, (a, b) in enumerate(pairs)]
                if os.environ.get("ALIGN_SHIFT"):   # il modello sbaglia di una: ogni parola collegata alla parola dopo
                    pairs = [[a, pairs[k + 1][1] if k + 1 < len(pairs) else b] for k, (a, b) in enumerate(pairs)]
                if os.environ.get("ALIGN_EXTRA"):   # nuovo formato: le parole dispari sono particelle della coppia seguente
                    objs, k = [], 0
                    while k < len(pairs):
                        if k % 2 and k + 1 < len(pairs):
                            objs.append({"t": pairs[k][0] + " " + pairs[k + 1][0], "o": pairs[k + 1][1], "extra": [pairs[k][0]]}); k += 2
                        else:
                            objs.append({"t": pairs[k][0], "o": pairs[k][1], "extra": []}); k += 1
                    pairs = objs
                if os.environ.get("ALIGN_FAIL"):
                    return await route.fulfill(status=500, content_type="application/json", body='{"error":{"message":"errore finto"}}')
                out_items[0]["pairs"] = pairs
                return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": json.dumps({"items": out_items})}}]}))
            if user.startswith("Expression:"):
                log.setdefault("expr", []).append(user.split('"')[1])
                content = json.dumps({"lemma": "", "pos": "espressione", "meaning": "ESPR[" + user.split('"')[1] + "]", "explanation": "Spiegazione dell'espressione.", "example": "", "example_translation": "", "lang": "en"})
            elif "Word:" in user and '"walked"' in user:
                content = json.dumps({"lemma": "walk", "pos": "verbo", "meaning": "camminare", "explanation": "", "example": "", "example_translation": "", "lang": "en", "expression": "walked home", "expression_meaning": "MODO[tornare a piedi]"})
            elif "Word:" in user:
                content = json.dumps({"lemma": "go", "pos": "verbo", "meaning": "andare (al passato)", "explanation": "Passato irregolare di go.", "example": "I went home.", "example_translation": "Sono andato a casa.", "lang": "en"})
            else:
                if os.environ.get("GEM_429") and not log.get("gem429"):
                    log["gem429"] = True
                    return await route.fulfill(status=429, content_type="application/json", body='{"error":{"code":429,"message":"quota","details":[{"retryDelay":"4s"}]}}')
                segs = json.loads(user)["segments"]
                log["gemini"].append(len(segs))
                await asyncio.sleep(float(os.environ.get("GEM_DELAY", "2.5")))   # Gemini lento
                content = json.dumps({"t": ["GEM[" + tr(s) + "]" for s in segs]})
                if os.environ.get("GEM_VERSIONED") and len(segs) == 1:
                    log["gver"] = log.get("gver", 0) + 1
                    content = json.dumps({"t": [f"GEM{log['gver']}[" + tr(segs[0]) + "]"]})
                mode = os.environ.get("GEM_MODE", "")
                sysmsg = payload["messages"][0]["content"]
                if '"src"' in sysmsg:
                    # traduzione con pulizia: originale corretto + traduzione; le frasi inventate diventano vuote
                    junk = os.environ.get("GEM_JUNK", "thanks for watching")
                    fix = lambda x: "" if junk in x.lower() else (x[:1].upper() + x[1:]).rstrip(".") + "."
                    src = [fix(x) for x in segs]
                    content = json.dumps({"src": src, "t": ["" if not x else "GEM[" + tr(x) + "]" for x in src]})
                if mode == "english": content = json.dumps({"t": ["the thing is that we are here and it is good " + str(k) for k, _ in enumerate(segs)]})
                if mode == "echo": content = json.dumps({"t": segs})
                if mode == "shortcopy": content = json.dumps({"t": [x if len(x.split()) <= 2 else "GEM[" + tr(x) + "]" for x in segs]})
                log.setdefault("gemsegs", []).append(list(segs))
                if mode == "echocomma": content = json.dumps({"t": [x.replace(" ", ", ", 1) for x in segs]})
                if mode == "shift" and len(segs) > 1:
                    # il modello mette tutto sotto la prima frase e lascia vuote le altre
                    content = json.dumps({"t": ["GEM[" + tr(" ".join(segs)) + "]"] + [""] * (len(segs) - 1)})
                if mode == "numbered": content = json.dumps({"t": [f"{k+1}. GEM[{tr(s)}]" for k, s in enumerate(segs)]})
                if mode == "bad" and not log.get("gbad"):
                    log["gbad"] = True
                    content = "Mi dispiace, non posso aiutarti con questo."
            return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": content}}]}))
        if url.startswith("https://api.groq.com/openai/v1/chat/completions"):
            payload = json.loads(request.post_data or "{}")
            if payload["messages"][0]["content"].startswith("You are an expert phonetician"):
                return await route.fulfill(status=200, content_type="application/json", body=ipa_answer("groq", payload["messages"][1]["content"]))
            return await route.fulfill(status=404, body="")
        return await route.fulfill(status=404, body="")
    except Exception as e:
        log["errors"].append(f"{url}: {e}")
        return await route.fulfill(status=500, body=str(e))

async def launch(p, user_dir="", env=None):
    ctx = await p.chromium.launch_persistent_context(user_dir, channel="chromium", headless=True, env=env,
        args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}", "--autoplay-policy=no-user-gesture-required"])
    await ctx.route("**/*", handle)
    sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
    # la prima richiesta del sottofondo sfugge al simulatore: la faccio a vuoto
    try: await sw.evaluate("fetch('https://example.test/riscaldamento').catch(()=>0)")
    except Exception: pass
    return ctx, sw

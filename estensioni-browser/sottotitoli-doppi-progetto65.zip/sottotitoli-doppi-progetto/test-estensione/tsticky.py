# 1.7.19: «Per questo video» ricordato per i video dopo (videoModeSticky); il menu globale resta com'è
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def run(p, sticky):
    ctx, sw = await launch(p, "", None)
    await sw.evaluate("chrome.storage.local.set({keys:{groq:'gsk_test', gemini:'AIza-test'}})")
    await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', transcribeMode:'live', videoModeSticky:'%s'})" % sticky)
    pg = await ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    await pg.goto("https://www.youtube.com/watch?v=noCapsSticky"); await pg.wait_for_timeout(1500)
    await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(5000)
    st = await sw.evaluate("chrome.storage.local.get('status').then(r => (r.status||{}).text)")
    glob = await sw.evaluate("chrome.storage.sync.get('transcribeMode').then(r => r.transcribeMode)")
    await ctx.close()
    return st, glob, errs
async def main():
    async with async_playwright() as p:
        a = await run(p, ""); b = await run(p, "off")
        print("sticky vuoto (segue la predefinita «mentre guardo»):", a[0]); print("sticky «spenta»:", b[0]); print("menu globale dopo:", a[1], b[1])
        ok = "spenta" not in (a[0] or "") and "spenta" in (b[0] or "") and a[1] == b[1] == "live"
        print("errori:", a[2] + b[2] if ok else a[2] + b[2] + ["la scelta ricordata non si applica"], log["errors"])
asyncio.run(main())

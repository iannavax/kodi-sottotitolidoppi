# Estensione unica 1.5.0: un popup solo (video + «📄 Pagine e PDF»), impostazioni con lo stesso nome tenute separate
# (pagine: pavEngine, pavRoman…), interruttori delle pagine che funzionano, nessun errore.
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        eid = sw.url.split("/")[2]
        await sw.evaluate("chrome.storage.local.set({keys:{gemini:'AIza-test'}})")
        pp = await ctx.new_page(); errs = []
        pp.on("pageerror", lambda e: errs.append(str(e)))
        await pp.goto(f"chrome-extension://{eid}/popup.html"); await pp.wait_for_timeout(1500)
        secs = await pp.evaluate("[...document.querySelectorAll('form > details > summary')].map(s=>s.textContent.trim())")
        print("1. sezioni:", secs, "| schede vecchie:", await pp.evaluate("document.querySelectorAll('.unica-tabs').length"))
        await pp.evaluate("document.querySelectorAll('details').forEach(d=>d.open=true)"); await pp.wait_for_timeout(500)
        await pp.select_option(".ds-tasks .ds-task-pages", "gemini"); await pp.wait_for_timeout(500)
        st = await sw.evaluate("chrome.storage.sync.get(['engine','pavEngine']).then(r=>JSON.stringify(r))")
        print("2. servizio delle pagine:", st, "| sottotitoli:", await pp.evaluate("document.getElementById('engine').value"))
        await pp.click("#p-selection"); await pp.click("#p-roman"); await pp.wait_for_timeout(400)
        st2 = await sw.evaluate("chrome.storage.sync.get(['selection','pavRoman','roman']).then(r=>JSON.stringify(r))")
        print("3. interruttori delle pagine:", st2)
        await pp.click("#p-on"); await pp.wait_for_timeout(300)
        on = await sw.evaluate("chrome.storage.sync.get('on').then(r=>r.on)")
        print("4. Parole al Volo spenta:", on is False, "| video ancora acceso:", await pp.is_checked("#enabled"))
        ok = len(secs) == 9 and "📄 Pagine e PDF" in secs and '"pavEngine":"gemini"' in st and '"selection":false' in st2 and '"pavRoman":true' in st2 and '"roman"' not in st2 and on is False
        print("errori:", errs if ok else errs + ["popup unico non va"], log["errors"])
        await ctx.close()
asyncio.run(main())

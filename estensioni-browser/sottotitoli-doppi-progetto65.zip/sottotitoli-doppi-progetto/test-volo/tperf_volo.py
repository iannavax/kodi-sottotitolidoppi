# 1.10.1: quanto costa aprire una scheda su una pagina grande, con Wiktionary vero (pagina da 400 KB)
import asyncio, os, sys, json, urllib.parse
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
WIKT = open(os.path.join(os.path.dirname(__file__), "fixtures", "wikt-embarazado.htm"), encoding="utf-8").read()
FILL = "".join(f'<p lang="es">Mi hermana está muy embarazada hoy y compramos pan fresco en el mercado número {i}, luego caminamos despacio hasta casa.</p>' for i in range(1500))
tvolo.PAGE = tvolo.PAGE.replace("</body>", FILL + "</body>")
orig = tvolo.handle
async def handle(route, request):
    url = request.url
    if url.startswith("https://en.wiktionary.org/w/api.php") and "action=parse" in url:
        page = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("page", [""])[0]
        return await route.fulfill(status=200, content_type="application/json", body=json.dumps({"parse": {"title": page, "text": WIKT}}, ensure_ascii=False))
    return await orig(route, request)
KEYS = ["ScriptDuration", "LayoutDuration", "RecalcStyleDuration", "LayoutCount", "RecalcStyleCount", "Nodes", "JSHeapUsedSize", "TaskDuration"]
async def metrics(cdp):
    m = await cdp.send("Performance.getMetrics")
    return {x["name"]: x["value"] for x in m["metrics"]}
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, viewport={"width": 1100, "height": 650},
                                                         args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        try: await sw.evaluate("fetch('https://example.test/x').catch(()=>0)")
        except Exception: pass
        await sw.evaluate("chrome.storage.sync.set({targetLang:'it', ipa:false, engine:'google', pavEngine:'google'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://example.test/p.html"); await pg.wait_for_timeout(2500)
        await pg.evaluate("window.__lt=[]; try{ new PerformanceObserver(l=>{for(const e of l.getEntries()) window.__lt.push(Math.round(e.duration))}).observe({entryTypes:['longtask']}) }catch(e){}")
        cdp = await ctx.new_cdp_session(pg); await cdp.send("Performance.enable")
        a = await metrics(cdp)
        b0 = await sw.evaluate("chrome.storage.local.getBytesInUse(null)")
        await pg.evaluate("document.body.insertAdjacentHTML('afterbegin', '<p id=\"es\" lang=\"es\">Mi hermana está embarazado hoy.</p>')")
        bx = await tvolo.word_box(pg, "es", "embarazado")
        await pg.mouse.move(5, 5); await pg.wait_for_timeout(300)
        await pg.mouse.move(bx["x"], bx["y"], steps=4)
        for s in (1, 4, 8):
            await pg.wait_for_timeout(1000 if s == 1 else 3000 if s == 4 else 4000)
            m = await metrics(cdp)
            print(f"+{s:>2}s", {k: round(m[k] - a[k], 3) for k in KEYS}, "| longtask:", await pg.evaluate("window.__lt"))
        b1 = await sw.evaluate("chrome.storage.local.getBytesInUse(null)")
        print("storage.local: +%d KB" % ((b1 - b0) // 1024), "| nodi scheda:", await pg.evaluate("document.querySelector('.pav-card')?document.querySelector('.pav-card').querySelectorAll('*').length:0"))
        ks = await sw.evaluate("chrome.storage.local.get(null).then(o=>Object.entries(o).map(([k,v])=>[k,JSON.stringify(v).length]).sort((a,b)=>b[1]-a[1]).slice(0,5))")
        print("chiavi più grandi:", ks)
        print("errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

# 5.21: lingua della trascrizione sbagliata = nessuna frase sullo schermo; il pulsante della lingua deve esserci lo stesso
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, sttLang:'ru'}).then(()=>chrome.storage.local.set({keys:{groq:'gsk-test'}}))")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=noCapsLingua"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()"); await pg.wait_for_timeout(20000)
        L = "(()=>{const o=document.querySelector('.dualsub-overlay'), b=document.querySelector('.dualsub-langbtn'); const cs=b&&getComputedStyle(b); return [o&&o.hidden, (document.querySelector('.dualsub-orig')||{}).textContent, b&&b.hidden, cs&&cs.display, cs&&cs.opacity, b&&b.textContent]})()"
        print("1. riquadro nascosto, frase, pulsante nascosto, display, opacità, sigla:", await pg.evaluate(L), "| pezzi a Whisper:", len(log["groq"]))
        print("   stato:", (await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)"))[:100])
        await pg.evaluate("document.querySelector('.dualsub-langbtn').click()"); await pg.wait_for_timeout(500)
        print("2. dopo il clic:", (await pg.evaluate("(document.querySelector('.dualsub-card')||{}).textContent||''"))[:120])
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

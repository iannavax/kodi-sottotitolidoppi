import json, re, time, urllib.parse, os, sys, threading
from playwright.sync_api import sync_playwright

EXT = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/v5/build/chrome"
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
AUDIO = open("/tmp/speech.wav", "rb").read()
log = {"groq": [], "google": 0, "gemini": [], "errors": []}

def tr(x):
    return " ".join(w[::-1] for w in str(x).split())

def page_html(vid, has):
    return f"""<!doctype html><html><head><title>Video di prova - YouTube</title></head><body style="margin:0;background:#111">
<div id="movie_player" class="html5-video-player" style="position:relative;width:1000px;height:560px;background:#000;overflow:hidden">
  <video class="html5-main-video" src="/media/speech.wav" style="width:100%;height:100%"></video>
  <button class="ytp-subtitles-button" aria-pressed="true" style="position:absolute;top:0;right:0">CC</button>
  <div class="ytp-caption-window-container" style="position:absolute;top:10px;left:10px;color:#fff">nativi</div>
</div>
<script>
const VID={json.dumps(vid)}, HAS={str(has).lower()};
const p=document.getElementById('movie_player');
p.getVideoData=()=>({{video_id:VID}});
p.getPlayerResponse=()=>({{videoDetails:{{videoId:VID}},captions:HAS?{{playerCaptionsTracklistRenderer:{{captionTracks:[{{}}]}}}}:undefined}});
document.querySelector('video').addEventListener('click',e=>{{const v=e.target; v.paused?v.play():v.pause();}});
p.addEventListener('click',()=>{{window.__playerClicks=(window.__playerClicks||0)+1}});
if(HAS) setTimeout(()=>{{const x=new XMLHttpRequest();x.open('GET','/api/timedtext?v='+VID+'&lang=en&kind=asr&fmt=json3&pot=abc');x.send();}},400);
</script></body></html>"""

def json3():
    words = "so we went to the market and bought some really fresh bread then we walked home slowly".split()
    events, t = [], 0
    for i in range(0, len(words), 4):
        grp = words[i:i+4]
        segs = [{"utf8": grp[0]}] + [{"utf8": " " + w, "tOffsetMs": 300*(k+1)} for k, w in enumerate(grp[1:])]
        events.append({"tStartMs": t, "dDurationMs": 3000, "segs": segs}); t += 1300
    # pausa lunga e seconda frase
    events.append({"tStartMs": t + 2500, "dDurationMs": 4000, "segs": [{"utf8": "it"}, {"utf8": " was", "tOffsetMs": 300}, {"utf8": " amazing", "tOffsetMs": 600}]})
    return {"events": events}

def multipart_file_size(body):
    m = re.search(rb'filename="audio\.wav"\r\nContent-Type: audio/wav\r\n\r\n', body)
    if not m: return -1
    start = m.end(); end = body.index(b"\r\n--", start)
    return end - start

def handle(route, request):
    url = request.url
    if not url.startswith("http"):
        return route.continue_()
    try:
        if url.startswith("https://www.youtube.com/watch"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            vid = q["v"][0]
            return route.fulfill(status=200, content_type="text/html", body=page_html(vid, vid != "noCaps"))
        if url.startswith("https://www.youtube.com/media/speech.wav"):
            return route.fulfill(status=200, content_type="audio/wav", body=AUDIO, headers={"Accept-Ranges": "bytes"})
        if url.startswith("https://www.youtube.com/api/timedtext"):
            return route.fulfill(status=200, content_type="application/json", body=json.dumps(json3()))
        if url.startswith("https://translate.googleapis.com/"):
            log["google"] += 1
            q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            text = q.get("q", [""])[0]
            if "bd" in q.get("dt", []):
                body = [[["pane", text]], [["sostantivo", ["pane", "pagnotta"]]], "en"]
            else:
                body = [[["\n".join("IT[" + tr(l) + "]" for l in text.split("\n")), text]], None, "en"]
            return route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
        if url.startswith("https://api.groq.com/openai/v1/audio/transcriptions"):
            size = multipart_file_size(request.post_data_buffer or b"")
            secs = (size - 44) / 32000 if size > 0 else -1
            n = len(log["groq"]) + 1
            log["groq"].append(round(secs, 2))
            body = {"language": "english", "segments": [{"start": 0.1, "end": max(0.5, secs - 0.1), "text": f" frase numero {n}", "no_speech_prob": 0.02, "avg_logprob": -0.3}]}
            time.sleep(0.4)
            return route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
        if url.startswith("https://generativelanguage.googleapis.com/"):
            payload = json.loads(request.post_data or "{}")
            user = payload["messages"][1]["content"]
            if "Word:" in user:
                content = json.dumps({"lemma": "go", "pos": "verbo", "meaning": "andare (al passato)", "explanation": "Passato irregolare di go.", "example": "I went home.", "example_translation": "Sono andato a casa.", "lang": "en"})
            else:
                segs = re.findall(r"^\d+\. (.*)$", user.split("Segments to translate")[1], re.M)
                log["gemini"].append(len(segs))
                time.sleep(float(os.environ.get("GEM_DELAY", "2.5")))   # Gemini lento
                content = json.dumps({"t": ["GEM[" + s + "]" for s in segs]})
            return route.fulfill(status=200, content_type="application/json", body=json.dumps({"choices": [{"message": {"content": content}}]}))
        return route.fulfill(status=404, body="")
    except Exception as e:
        log["errors"].append(f"{url}: {e}")
        return route.fulfill(status=500, body=str(e))

def launch(p):
    ctx = p.chromium.launch_persistent_context("", channel="chromium", headless=True,
        args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}", "--autoplay-policy=no-user-gesture-required"])
    ctx.route("**/*", handle)
    sw = ctx.service_workers[0] if ctx.service_workers else ctx.wait_for_event("serviceworker", timeout=10000)
    return ctx, sw

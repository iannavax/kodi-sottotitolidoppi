import asyncio, sys
from playwright.async_api import async_playwright
EXT=sys.argv[1]
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=10000)
        ext_id = sw.url.split("/")[2]
        for page in ["popup.html", "vocab.html"]:
            pg = await ctx.new_page(); errs=[]
            pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m: errs.append(m.type+": "+m.text))
            await pg.goto(f"chrome-extension://{ext_id}/{page}"); await pg.wait_for_timeout(1000)
            print(page, errs)
        await ctx.close()
asyncio.run(main())

# 5.14: dizionario di Google nella scheda (traduzioni con peso, definizioni, sinonimi), si spegne
import asyncio, os, sys, json
sys.path.insert(0, "/home/claude/e2e")
from charness import *
DSX = "(document.querySelector('.dualsub-card .dsx')||{}).innerText"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnSpell:false, learnFreq:false, etym:false, learnAudio:false, learnTable:false, learnGender:false, learnKnown:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/bread/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.evaluate("document.querySelector('video').pause()")
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("bread")).hover(); await pg.wait_for_timeout(2500)
        print("1. scheda:\n" + await pg.evaluate(DSX))
        print("   riga 'sostantivo: …' doppia:", await pg.evaluate("!!document.querySelector('.dualsub-card .dualsub-card-expl')"), "| titolo pane:", await pg.evaluate("(document.querySelector('.dualsub-card .dsx-altw')||{}).title"))
        await sw.evaluate("chrome.storage.sync.set({gdAlt:false, gdDefs:false, gdSyn:false})"); await pg.mouse.move(5, 5); await pg.wait_for_timeout(800)
        await words.nth(texts.index("bread")).hover(); await pg.wait_for_timeout(2000)
        print("2. spenti: dsx =", repr(await pg.evaluate(DSX)), "| riga dizionario di prima:", await pg.evaluate("(document.querySelector('.dualsub-card .dualsub-card-expl')||{}).textContent"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

# 1.7.29: messaggi sul video (trascrizione/traduzione), freccia ↺, modalità automatica con Whisper locale
import asyncio, sys
sys.path.insert(0, "/home/claude/e2e")
from charness import *
CH = "(()=>{const c=document.querySelector('.dualsub-statuschip'); return c? [c.hidden, c.textContent] : null})()"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({engine:'google', targetLang:'it', ipa:false, hoverPause:false, cleanAsr:true, cleanMode:'off', models:{local:'gemma4:e4b'}, localUrl:'http://localhost:11434/v1'})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=gdTest"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/market/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=40000)
        await pg.wait_for_timeout(1500)
        print("1. messaggi accesi:", await pg.evaluate(CH))
        await sw.evaluate("chrome.storage.sync.set({showStatusTrans:false})"); await pg.wait_for_timeout(1200)
        print("2. trascrizione spenta:", await pg.evaluate(CH))
        await sw.evaluate("chrome.storage.sync.set({showStatusTl:false})"); await pg.wait_for_timeout(1200)
        print("3. tutti spenti:", await pg.evaluate(CH))
        # freccia: cambio video → non resta
        await pg.evaluate("document.querySelector('video').pause()")
        await pg.locator(".dualsub-orig .dualsub-word").first.hover(); await pg.wait_for_timeout(700)
        print("4. dopo il passaggio sulla parola ↺:", await pg.evaluate("document.querySelector('.dualsub-backbtn').className"))
        await pg.goto("https://www.youtube.com/watch?v=noCapsOther"); await pg.wait_for_timeout(2500)
        print("5. altro video ↺:", await pg.evaluate("(document.querySelector('.dualsub-backbtn')||{}).className"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

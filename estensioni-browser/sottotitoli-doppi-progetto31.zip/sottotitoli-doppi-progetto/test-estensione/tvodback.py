# 1.6.3: video normale: quando parte la trascrizione il video torna indietro di 20 s (una volta sola); con 0 resta dov'è
import asyncio, sys, os
sys.path.insert(0, "/home/claude/e2e")
from charness import *
BACK = int(os.environ.get("BACK", "20"))
async def run(p, back):
    ctx, sw = await launch(p, "", None)
    await sw.evaluate(f"chrome.storage.sync.set({{engine:'google', targetLang:'it', transcribeMode:'off', cleanMode:'off', vodBack:{back}}}).then(()=>chrome.storage.local.set({{keys:{{groq:'gsk_test'}}}}))")
    pg = await ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    await pg.goto("https://www.youtube.com/watch?v=noCapsVod1"); await pg.wait_for_timeout(1500)
    await pg.evaluate("(()=>{const v=document.querySelector('video'); v.currentTime=40; v.play();})()")
    await pg.wait_for_timeout(1500)
    tab = await sw.evaluate("chrome.tabs.query({}).then(t=>t.find(x=>/noCapsVod1/.test(x.url)).id)")
    await sw.evaluate(f"chrome.tabs.sendMessage({tab}, {{type:'live', action:'start'}})")   # «Trascrivi l'audio di questo video» dal popup
    await pg.wait_for_timeout(5000)
    t1 = await pg.evaluate("document.querySelector('video').currentTime")
    st = await sw.evaluate("chrome.storage.local.get('status').then(r=>r.status&&r.status.text)")
    await ctx.close()
    return t1, st, errs
async def main():
    async with async_playwright() as p:
        t_on, st_on, e1 = await run(p, BACK)
        t_off, st_off, e2 = await run(p, 0)
        print(f"1. vodBack={BACK}: dopo 5 s il video è a {t_on:.1f} s | stato:", (st_on or "")[:110])
        print(f"2. vodBack=0: dopo 5 s il video è a {t_off:.1f} s")
        ok = (t_on < 40 - BACK + 12 if BACK else True) and t_off >= 40 and not e1 and not e2
        print("errori:", e1 + e2 if ok else e1 + e2 + ["torna indietro non va"], log["errors"])
asyncio.run(main())

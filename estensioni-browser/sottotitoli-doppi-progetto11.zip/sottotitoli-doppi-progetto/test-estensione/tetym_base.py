# Etimologia dalla parola madre nella scheda: «non trovata» → «prendila dalla parola madre…», scrivi la parola, salva;
# poi la riga dice da dove viene e il ⚑ permette di cambiarla. Uso: python3 tetym_base.py <estensione>
import asyncio, os, sys
os.environ.setdefault("NO_ALIGN_IDIOM", "1")
sys.path.insert(0, "/home/claude/e2e")
from charness import *
ETYM = "(document.querySelector('.dualsub-card .dsx-etym')||{}).innerText||'(nessuna)'"
async def main():
    async with async_playwright() as p:
        ctx, sw = await launch(p, "", None)
        await sw.evaluate("chrome.storage.sync.set({idioms:true, engine:'google', targetLang:'it', ipa:false, hoverPause:true, learnExamples:false, learnFreq:false, learnSpell:false})")
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("https://www.youtube.com/watch?v=ruIdiom"); await pg.wait_for_timeout(1200)
        await pg.evaluate("document.querySelector('video').play()")
        await pg.wait_for_function("/сожалению/.test((document.querySelector('.dualsub-orig')||{}).textContent||'')", timeout=30000)
        await pg.evaluate("document.querySelector('video').pause()"); await pg.wait_for_timeout(300)
        words = pg.locator(".dualsub-orig .dualsub-word"); texts = await words.all_inner_texts()
        await words.nth(texts.index("сожалению")).click(); await pg.wait_for_timeout(3000)
        print("1. prima:", (await pg.evaluate(ETYM)).replace("\n", " | "))
        # 🔍 cerca radice: le parole candidate (✓ = la forma è nella loro tabella), si sceglie con un clic
        await pg.locator(".dualsub-card .dsx-etym button", has_text="cerca radice").click(); await pg.wait_for_timeout(2500)
        print("   candidate:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-baselist button')].map(b=>b.textContent)"), "| ricerche:", log.get("wiktsearch"))
        await pg.locator(".dualsub-card .dsx-baselist button", has_text="сожаление").first.click(); await pg.wait_for_timeout(2500)
        print("2. dalla parola madre:", (await pg.evaluate(ETYM)).replace("\n", " | "))
        await pg.locator(".dualsub-card .dsx-etym button", has_text="⚑").click(); await pg.wait_for_timeout(300)
        print("3. ⚑:", await pg.evaluate("[...document.querySelectorAll('.dualsub-card .dsx-fix button')].map(b=>b.textContent)"))
        print("   salvata:", await sw.evaluate("chrome.storage.local.get('etymBase').then(r=>JSON.stringify(r.etymBase))"))
        print("errori:", errs, log["errors"])
        await ctx.close()
asyncio.run(main())

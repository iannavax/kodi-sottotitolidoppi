# Lettore PDF: testo in una codifica letto con un'altra (WinAnsi o MacRoman nel PDF). Per ogni caso crea un PDF,
# lo apre nel lettore e controlla che il testo esca giusto; i PDF già giusti (francese, tedesco…) non vanno toccati.
# Uso: python3 tpdf_enc.py <estensione>
import asyncio, os, sys, re
os.environ["PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS"] = "1"
from playwright.async_api import async_playwright
import tvolo
EXT = sys.argv[1]
# casi in cui pdf.js perde già qualcosa (byte che WinAnsi non usa → tutti "•", spazio non separabile → spazio):
# basta che il testo sia giusto quasi tutto
LOSSY = {"ru_866_win", "cs_utf8_win"}
CASES = [  # (nome, codifica vera dei byte, codifica dichiarata nel PDF, testo)
    ("cs_1250_win", "cp1250", "WinAnsiEncoding", "Příliš žluťoučký kůň úpěl ďábelské ódy. Večer jsme šli po nábřeží a dívali se na řeku, která tekla pomalu."),
    ("cs_1250_mac", "cp1250", "MacRomanEncoding", "Pánové, věčné skeptičtí a přezíraví, kteří své smutky vážete do kytek a znáte už život nazpaměť."),
    ("pl_iso2_win", "iso8859_2", "WinAnsiEncoding", "Zażółć gęślą jaźń. Wczoraj poszliśmy na długi spacer brzegiem rzeki i rozmawialiśmy o książkach."),
    ("ru_1251_win", "cp1251", "WinAnsiEncoding", "Привет, как дела? Вчера мы долго гуляли по набережной и разговаривали о книгах и музыке."),
    ("ru_koi8_win", "koi8_r", "WinAnsiEncoding", "Мороз и солнце; день чудесный! Еще ты дремлешь, друг прелестный, пора, красавица, проснись."),
    ("ru_866_win", "cp866", "WinAnsiEncoding", "Москва - столица России. Этот город очень большой, и в нём живёт много людей."),
    ("ru_1251_mac", "cp1251", "MacRomanEncoding", "Однажды весною, в час небывало жаркого заката, в Москве, на Патриарших прудах, появились два гражданина."),
    ("el_1253_win", "cp1253", "WinAnsiEncoding", "Καλημέρα σας. Χθες περπατήσαμε πολύ ώρα δίπλα στη θάλασσα και μιλήσαμε για βιβλία."),
    ("tr_1254_win", "cp1254", "WinAnsiEncoding", "Dün akşam arkadaşlarımla birlikte şehrin eski sokaklarında uzun bir yürüyüş yaptık ve çok güzel bir gün geçirdik."),
    ("lt_1257_win", "cp1257", "WinAnsiEncoding", "Vakar vakare ilgai vaikščiojome palei upę ir kalbėjomės apie knygas, muziką ir gyvenimą."),
    ("cs_utf8_win", "utf-8", "WinAnsiEncoding", "Příliš žluťoučký kůň úpěl ďábelské ódy. Večer jsme šli po nábřeží a dívali se na řeku."),
    ("fr_ok", "cp1252", "WinAnsiEncoding", "Où êtes-vous allés hier soir? Très déçu par l'élève, il est rentré à l'hôtel avec le garçon. Noël approche, ça fait plaisir."),
    ("de_ok", "cp1252", "WinAnsiEncoding", "Größere Mädchen gehen über die Straße. Für die Grüße danke ich dir, öfter möchte ich so schöne Tage erleben."),
    ("it_ok", "cp1252", "WinAnsiEncoding", "Perché non è venuto? Ieri sera abbiamo mangiato un'ottima pizza e poi siamo andati là, più vicino alla città."),
    ("sv_ok", "cp1252", "WinAnsiEncoding", "Igår gick vi en lång promenad längs ån och pratade om böcker. Det var en härlig dag på sjön."),
]
def esc(b): return b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)")
def make(path, codec, enc, text):
    words = text.split(" "); lines = []; cur = ""
    for w in words:
        if len(cur) + len(w) > 45: lines.append(cur.strip()); cur = ""
        cur += w + " "
    lines.append(cur.strip())
    body = b"BT /F1 16 Tf 50 740 Td "
    for i, l in enumerate(lines): body += (b"" if i == 0 else b" 0 -24 Td ") + b"(" + esc(l.encode(codec)) + b") Tj"
    stream = body + b" ET"
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
            b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Times-Roman /Encoding /" + enc.encode() + b" >>"]
    out = b"%PDF-1.4\n"; offs = []
    for i, o in enumerate(objs, 1): offs.append(len(out)); out += b"%d 0 obj\n" % i + o + b"\nendobj\n"
    x = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1) + b"".join(b"%010d 00000 n \n" % o for o in offs)
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, x)
    open(path, "wb").write(out)
for name, codec, enc, text in CASES: make(f"/tmp/enc_{name}.pdf", codec, enc, text)
async def handle(route, request):
    m = re.search(r"/(enc_\w+)\.pdf", request.url)
    if m: return await route.fulfill(status=200, content_type="application/pdf", body=open(f"/tmp/{m.group(1)}.pdf", "rb").read())
    return await tvolo.handle(route, request)
norm = lambda s: re.sub(r"\s+", "", s)
async def main():
    async with async_playwright() as p:
        ctx = await p.chromium.launch_persistent_context("", channel="chromium", headless=True, args=[f"--disable-extensions-except={EXT}", f"--load-extension={EXT}"])
        await ctx.route("**/*", handle)
        sw = ctx.service_workers[0] if ctx.service_workers else await ctx.wait_for_event("serviceworker", timeout=20000)
        eid = sw.url.split("/")[2]
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        ok = 0
        for name, codec, enc, text in CASES:
            await pg.goto(f"chrome-extension://{eid}/pdf.html?file=https%3A%2F%2Fexample.test%2Fenc_{name}.pdf"); await pg.wait_for_timeout(1800)
            got = await pg.evaluate("(document.querySelector('.textLayer')||{}).textContent||''")
            note = await pg.evaluate("document.getElementById('encNote').textContent")
            import difflib
            good = norm(got) == norm(text) or (name in LOSSY and difflib.SequenceMatcher(None, norm(got), norm(text)).ratio() >= 0.9); ok += good
            print(("OK  " if good else "NO  ") + f"{name:14} {note:32} {got[:70]}")
        # scelta a mano
        await pg.goto(f"chrome-extension://{eid}/pdf.html?file=https%3A%2F%2Fexample.test%2Fenc_ru_1251_win.pdf"); await pg.wait_for_timeout(1500)
        await pg.select_option("#enc", "none"); await pg.wait_for_timeout(1500)
        raw = await pg.evaluate("(document.querySelector('.textLayer')||{}).textContent||''")
        await pg.select_option("#enc", "cp1251"); await pg.wait_for_timeout(1500)
        man = await pg.evaluate("(document.querySelector('.textLayer')||{}).textContent||''")
        await pg.select_option("#enc", "auto"); await pg.wait_for_timeout(500)
        print("a mano: come nel PDF →", raw[:30], "| Windows-1251 →", man[:30])
        print(f"giusti {ok}/{len(CASES)}", "errori:", errs, tvolo.log["errors"])
        await ctx.close()
asyncio.run(main())

import asyncio, json
from playwright.async_api import async_playwright
SRC = open("/home/claude/sottotitoli-doppi-progetto/estensione/src/etym.js").read()
H = lambda l, t: f'<div class="mw-heading mw-heading{l}"><h{l}>{t}</h{l}></div>'
cell = lambda c, t: f'<td><span class="Cyrl" lang="ru">{c}</span><br><span lang="ru-Latn" class="tr Latn">{t}</span></td>'
html = '<div class="mw-parser-output">' + H(2, "Russian") + H(3, "Declension") + '<div class="NavFrame"><div class="NavContent"><table class="inflection-table"><tr><th></th><th>singular</th><th>plural</th></tr><tr><th>nominative</th>' + cell("исто́чник", "istóčnik") + cell("исто́чники", "istóčniki") + '</tr><tr><th>genitive</th>' + cell("исто́чника", "istóčnika") + '<td><span class="Cyrl" lang="ru">исто́чников</span>, <span class="Cyrl" lang="ru">источников</span><br><span class="tr Latn" lang="ru-Latn">istóčnikov</span></td></tr></table></div></div></div>'
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(channel="chromium", headless=True); pg = await b.new_page()
        await pg.set_content("<html><body></body></html>")
        await pg.evaluate("window.DS_EXT={storage:{local:{get:()=>Promise.resolve({}),set:()=>Promise.resolve()}},runtime:{sendMessage:()=>Promise.resolve({})}}")
        await pg.add_script_tag(content=SRC + "\nwindow.E=DS_ETYM;")
        t = await pg.evaluate("(h)=>E.extract(h,'ru').table", html)
        for r in t: print([(c["t"], c["tr"]) for c in r])
        await b.close()
asyncio.run(main())
